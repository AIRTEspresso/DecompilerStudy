/*
 * Decompiled with CFR 0.152.
 */
class Test {
    Test() {
    }

    /*
     * Enabled aggressive block sorting
     */
    int iMeth(int n, boolean bl) {
        int n2 = 1;
        block6: while (true) {
            if (n2 >= 342) {
                long l = n;
                return (int)l;
            }
            int n3 = 5;
            while (true) {
                if (n3 <= 1) continue block6;
                switch (114) {
                    case 120: {
                        switch (62) {
                            case 67: {
                                if (!bl) break;
                            }
                        }
                        break;
                    }
                }
            }
            break;
        }
    }
}

