class Test {
    int iMeth(int i2 , boolean b){
        int i3 = 1 , i4;
        while(i3 < 342)
            for(i4 = 5; i4 > 1; )
                switch(114){
                case 120 : switch(62){
                    case 67 : if(b)continue;
                }
            }
        long meth_res = i2;
        return(int)meth_res;
    }
}
