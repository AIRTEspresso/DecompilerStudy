class Test {
    int N;
    {
        short s1 = 14756 , sArr[][][]= new short[N][N][N];
        int i15 = 67;
        sArr[i15][i15][i15]= s1;
    }
}
