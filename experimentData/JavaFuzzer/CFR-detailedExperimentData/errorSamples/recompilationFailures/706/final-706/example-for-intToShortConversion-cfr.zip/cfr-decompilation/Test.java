/*
 * Decompiled with CFR 0.152.
 */
class Test {
    int N;

    Test() {
        int n = 14756;
        short[][][] sArray = new short[this.N][this.N][this.N];
        int n2 = 67;
        sArray[n2][n2][n2] = n;
    }
}

