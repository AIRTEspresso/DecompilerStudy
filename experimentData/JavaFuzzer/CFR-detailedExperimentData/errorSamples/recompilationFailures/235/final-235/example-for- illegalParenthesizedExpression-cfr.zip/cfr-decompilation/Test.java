/*
 * Decompiled with CFR 0.152.
 */
class Test {
    int N;

    Test() {
        int[][][] nArray = new int[this.N][this.N][this.N];
        Test.init(nArray, (Object)-12);
    }

    static void init(float[] fArray, float f) {
    }

    static void init(Object object, Object object2) {
    }
}

