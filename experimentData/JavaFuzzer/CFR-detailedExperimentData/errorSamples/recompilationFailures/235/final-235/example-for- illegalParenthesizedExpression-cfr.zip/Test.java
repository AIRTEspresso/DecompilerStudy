class Test {
    int N;
    {
        int iArr1[][][]= new int[N][N][N];
        init(iArr1 , - 12);
    }
    static void init(float[]a , float seed){
    }
    static void init(Object a , Object seed){
    }
}
