/*
 * Decompiled with CFR 0.152.
 */
class Test {
    double dFld;

    Test() {
        float f = 1.18f;
        while (true) {
            float f2;
            f -= 1.0f;
            if (!(f2 > 0.0f)) break;
            this.dFld = f;
        }
    }
}

