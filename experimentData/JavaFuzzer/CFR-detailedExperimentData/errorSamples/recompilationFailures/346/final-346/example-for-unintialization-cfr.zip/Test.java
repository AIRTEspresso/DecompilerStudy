class Test {
    double dFld;
    {
        float f = 1.18F;
        while(-- f > 0)dFld = f;
    }
}
