class Test {
    int N;
    {
        int i20 = 35;
        boolean bArr1[]= new boolean[N];
        switch(30){
            case 32 : {
                boolean b2 = false;
                bArr1[i20]= b2;
            }
            short s1 = 31371;
        }
    }
}
