/*
 * Decompiled with CFR 0.152.
 */
class Test {
    int N;

    Test() {
        int n = 35;
        boolean[] blArray = new boolean[this.N];
        switch (30) {
            case 32: {
                int n2;
                blArray[n] = n2 = 0;
                n2 = 31371;
            }
        }
    }
}

