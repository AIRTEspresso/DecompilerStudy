class Test {
    {
        int i = 11 , i19 = 35 , i20 = 58518 , i26 = 18457;
        switch(i19){
            case 84 : switch(i){
                        case 21 : while(i26 < 2)i20 += i26;
            }
        }
    }
}
