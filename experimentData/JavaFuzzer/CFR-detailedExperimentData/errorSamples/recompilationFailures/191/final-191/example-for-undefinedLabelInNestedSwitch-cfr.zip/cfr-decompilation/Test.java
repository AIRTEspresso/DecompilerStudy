/*
 * Decompiled with CFR 0.152.
 */
class Test {
    Test() {
        int n = 11;
        int n2 = 35;
        int n3 = 58518;
        int n4 = 18457;
        switch (n2) {
            case 84: {
                switch (n) {
                    case 21: {
                        while (n4 < 2) {
                            n3 += n4;
                        }
                        break block0;
                    }
                }
            }
        }
    }
}

