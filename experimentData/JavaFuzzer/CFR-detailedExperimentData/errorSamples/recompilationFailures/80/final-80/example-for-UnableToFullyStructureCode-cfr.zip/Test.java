class Test {
    void vMeth(){
        int i2 = 6;
        float f2 = 83.595F;
        switch(i2){
            case 81 : f2 = f2;
            case 82 : return;
        }
    }
}
