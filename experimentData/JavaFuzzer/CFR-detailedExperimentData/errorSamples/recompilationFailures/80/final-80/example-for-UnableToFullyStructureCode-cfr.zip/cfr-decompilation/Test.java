/*
 * Decompiled with CFR 0.152.
 */
class Test {
    Test() {
    }

    /*
     * Unable to fully structure code
     */
    void vMeth() {
        var1_1 = 6;
        var2_2 = 83.595f;
        switch (var1_1) {
            ** case 81:
lbl5:
            // 2 sources

            case 82: {
                return;
            }
        }
    }
}

