/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -23926L;
    public static volatile double dFld = 0.8183;
    public static boolean bFld = false;
    public static short sFld = (short)17403;
    public static int[] iArrFld = new int[400];
    public static int[][] iArrFld1 = new int[400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, byte by) {
        int n2 = 30062;
        int n3 = -46686;
        int n4 = 5;
        int[] nArray = new int[400];
        float f = -90.327f;
        boolean bl = false;
        double d = -2.36019;
        FuzzerUtils.init(nArray, 197);
        n2 = 1;
        n *= n;
        int n5 = n2;
        nArray[n5] = nArray[n5] << -121;
        f += (float)n2;
        n3 = 1;
        while (!bl) {
            instanceCount += (long)(n3 * n3);
            f -= (float)(n += 21 + n3 * n3);
            if (++n3 < 10) continue;
        }
        n <<= n;
        n = n3;
        vMeth2_check_sum += (long)(n + by + n2 + Float.floatToIntBits(f) + n3 + (bl ? 1 : 0) + n4) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(float f, int n, long l) {
        int n2 = 8;
        int n3 = 48179;
        int n4 = -2634;
        int n5 = 11;
        int[] nArray = new int[400];
        byte by = 67;
        FuzzerUtils.init(nArray, -44532);
        n2 = 1;
        while (++n2 < 294) {
            if (n2 != 0) {
                vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n) + l + (long)n2 + (long)by + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
                return;
            }
            if (n2 != 0) {
                vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n) + l + (long)n2 + (long)by + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
                return;
            }
            Test.vMeth2(n, by);
            n -= (int)dFld;
            n3 = 1;
            do {
                if ((n4 = 1) >= 1) continue;
                n = n2;
                dFld = n2;
                l = (long)((float)l + ((float)(n4 * n3 + n3) - f));
            } while (++n3 < 6);
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n) + l + (long)n2 + (long)by + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n) {
        float f = -1.482f;
        int n2 = -3;
        int n3 = 2;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -21294L);
        Test.vMeth1(f, n, instanceCount);
        instanceCount -= instanceCount;
        n = 1889396016;
        for (int n4 : iArrFld) {
            dFld = instanceCount;
            dFld += (double)(n4 >>= 14);
            for (n2 = 1; n2 < 4; ++n2) {
                if (bFld) {
                    n4 -= (int)dFld;
                    n = (int)((long)n + ((long)n2 | (long)f));
                    int n5 = n2 + 1;
                    lArray[n5] = lArray[n5] * (long)n2;
                    int n6 = n2;
                    iArrFld[n6] = iArrFld[n6] + (int)dFld;
                    continue;
                }
                n3 = n;
            }
        }
        vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -11;
        int n2 = -14;
        int n3 = -39188;
        int n4 = -11;
        int n5 = 63507;
        int n6 = -239;
        double d = -110.39228;
        long[] lArray = new long[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(lArray, -63188L);
        FuzzerUtils.init(fArray, -1.97f);
        for (n = 9; n < 292; ++n) {
            Test.vMeth(22804);
            if (bFld) break;
            n2 >>= -16641;
            if (bFld) {
                n2 <<= n2;
                int[] nArray = iArrFld1[n];
                int n7 = n + 1;
                nArray[n7] = nArray[n7] & n;
                instanceCount *= (long)n2;
                continue;
            }
            try {
                n2 = 42011 / n;
                n2 = n / iArrFld[n];
                n2 = 44609 % iArrFld1[n][n];
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n2 += 29333 + n * n;
            instanceCount = 3466816774L;
            sFld = (short)(sFld + (short)(n * n));
        }
        for (d = 1.0; d < 216.0; d += 1.0) {
            lArray[(int)(d - 1.0)] = -6215L;
            n4 = 1;
            do {
                n2 = 14;
                n2 *= (int)dFld;
                n3 *= n4;
                block16: for (n5 = 1; n5 < 1; ++n5) {
                    n2 = (int)d;
                    fArray[(int)d] = (float)d;
                    switch (n4 % 7 * 5 + 16) {
                        case 27: {
                            n6 += -2 + n5 * n5;
                            continue block16;
                        }
                        case 23: {
                            n6 = n;
                            n6 += n3;
                            continue block16;
                        }
                        case 37: {
                            try {
                                n3 = iArrFld1[n4 + 1][(int)(d + 1.0)] % 116;
                                n2 /= n6;
                                n3 = 255 / n5;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n6 += n5 * n5;
                            continue block16;
                        }
                        case 51: {
                            n3 = n2 <<= 27719;
                            continue block16;
                        }
                        case 22: {
                            instanceCount = n4;
                            continue block16;
                        }
                        case 42: {
                            int[] nArray = iArrFld1[n4 - 1];
                            int n8 = n5 - 1;
                            nArray[n8] = nArray[n8] * n4;
                            continue block16;
                        }
                        case 50: {
                            n6 = n;
                            continue block16;
                        }
                        default: {
                            instanceCount -= (long)n4;
                        }
                    }
                }
            } while (++n4 < 117);
        }
        FuzzerUtils.out.println("i i1 d1 = " + n + "," + n2 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i15 i16 i17 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i18 lArr1 fArr = " + n6 + "," + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld Test.iArrFld Test.iArrFld1 = " + sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -717);
        FuzzerUtils.init(iArrFld1, 39606);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

