/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1550508883L;
    public static int iFld = 2578;
    public static float fFld = 95.1016f;
    public static byte byFld = (byte)-52;
    public static boolean bFld = false;
    public static double dFld = -1.121504;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, int n2) {
        int n3 = 48793;
        int n4 = -105;
        int n5 = -7;
        int n6 = 43281;
        int n7 = -54161;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -38418L);
        for (n3 = 8; n3 < 150; n3 += 2) {
            n4 += n3;
            iFld += 60898 + n3 * n3;
            n2 += n3;
            int n8 = n3;
            lArray[n8] = lArray[n8] + instanceCount;
            n4 = n3;
            fFld = instanceCount;
            n5 = 1;
            while (n5 < 22) {
                n6 += n5 | n2;
                n7 = 1;
                while ((n7 += 2) < 2) {
                    int n9 = n3 + 1;
                    iArrFld[n9] = iArrFld[n9] - iFld;
                }
                iFld = (int)instanceCount;
                instanceCount += (long)n5;
                n6 += 0;
                int n10 = n5++;
                iArrFld[n10] = iArrFld[n10] * n2;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(lArray);
    }

    public static int iMeth1(int n, long l, long l2) {
        int n2 = -162;
        int n3 = -35;
        int n4 = 27130;
        int n5 = -105;
        double d = 114.112392;
        for (n2 = 7; n2 < 326; ++n2) {
            int n6 = 146;
            Test.vMeth(n6, n2);
            fFld *= (float)d;
            n3 += 159 + n2 * n2;
            n *= (int)l2;
            byFld = (byte)instanceCount;
            n3 ^= 0xFFFF685D;
            n6 += n2;
            try {
                iFld %= n;
                iFld = 42692 % n;
                Test.iArrFld[n2] = n3 % 37900;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            for (n4 = n2; n4 < 5; ++n4) {
                n5 -= n4;
                int n7 = n2 - 1;
                iArrFld[n7] = iArrFld[n7] << n;
                fFld *= (float)(l += -153L);
                n5 *= n4;
            }
        }
        long l3 = (long)n + l + l2 + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + (long)n5;
        iMeth1_check_sum += l3;
        return (int)l3;
    }

    public static int iMeth() {
        int n = -47621;
        int n2 = -7;
        int n3 = -26420;
        int n4 = 241;
        int n5 = 27100;
        int n6 = 53740;
        int n7 = -15099;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 3659750234294669490L);
        instanceCount = Math.abs(iFld--);
        iFld -= iFld;
        int n8 = ((n *= Math.abs((int)((long)n7 * 2476092117L)) * (Test.iMeth1(-58494, -6L, instanceCount) + n7)) >>> 1) % 400;
        lArray[n8] = lArray[n8] - 40156L;
        n2 = 266;
        do {
            instanceCount = n2;
            byFld = (byte)(byFld - (byte)dFld);
            for (n3 = 6; 1 < n3; --n3) {
                for (n5 = 1; n5 < 2; ++n5) {
                    n6 = (int)fFld;
                }
                iFld <<= n2;
                instanceCount += (long)n;
                n >>= n2;
                n += n3 ^ n3;
            }
        } while (--n2 > 0);
        long l = (long)(n + n7 + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -1;
        int n2 = -4801;
        int n3 = -11;
        int n4 = 14028;
        int n5 = -28969;
        int n6 = 8132;
        int n7 = -8;
        int n8 = 214;
        int n9 = 4;
        int n10 = 253;
        int n11 = 45857;
        int n12 = 160;
        int n13 = 0;
        int[] nArray = new int[400];
        float[][] fArray = new float[400][400];
        long[] lArray = new long[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(nArray, 32892);
        FuzzerUtils.init(fArray, -60.598f);
        FuzzerUtils.init(lArray, -2099759609912039697L);
        FuzzerUtils.init(blArray, true);
        n = 364;
        while (--n > 0) {
            n2 *= (int)((double)(instanceCount - 57L) + ((double)n + 54.13999) - (double)(-52516L + instanceCount));
            int n14 = n;
            int n15 = nArray[n14] - 1;
            nArray[n14] = n15;
            n2 = n15;
        }
        n2 = Test.iMeth();
        instanceCount >>= n2;
        for (n3 = 17; n3 < 304; ++n3) {
            iFld = -1818386673;
            for (n5 = 4; n5 < 88; ++n5) {
                instanceCount = (long)fFld;
                iFld += n5;
            }
            if (bFld) break;
        }
        FuzzerUtils.out.println("i i1 i21 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i22 i23 i24 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i25 i26 i27 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i28 i29 i30 = " + n10 + "," + n11 + "," + n12);
        FuzzerUtils.out.println("i31 iArr fArr = " + n13 + "," + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("lArr2 bArr = " + FuzzerUtils.checkSum(lArray) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.byFld Test.bFld Test.dFld = " + byFld + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 4);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

