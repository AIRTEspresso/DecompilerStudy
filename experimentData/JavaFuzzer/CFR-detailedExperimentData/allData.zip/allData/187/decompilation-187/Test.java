/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -62556L;
    public static volatile double dFld = -2.82475;
    public static byte byFld = (byte)11;
    public static float fFld = -124.883f;
    public static short[] sArrFld = new short[400];
    public int[] iArrFld = new int[400];
    public long[][][] lArrFld = new long[400][400][400];
    public long[] lArrFld1 = new long[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, float f) {
        int n2 = 8;
        int n3 = 141;
        int n4 = 34626;
        int n5 = 5878;
        int n6 = -15212;
        int n7 = -1;
        boolean bl = true;
        int n8 = -11268;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -130L);
        byFld = (byte)(byFld + (byte)(dFld -= (double)instanceCount));
        n += n;
        for (n2 = 1; 181 > n2; ++n2) {
            if (bl) {
                dFld += (double)instanceCount;
                continue;
            }
            for (n4 = 1; n4 < 9; ++n4) {
                n += -24 + n4 * n4;
                for (n6 = n4; n6 < 2; ++n6) {
                    n8 = (short)n6;
                    long[] lArray2 = lArray[n2];
                    int n9 = (n2 >>> 1) % 400;
                    lArray2[n9] = lArray2[n9] + (long)n4;
                    dFld = n5;
                    Test.sArrFld[n4] = 162;
                    int n10 = n4 + 1;
                    sArrFld[n10] = (short)(sArrFld[n10] & (short)n7);
                    n = (int)instanceCount;
                }
            }
        }
        vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + (bl ? 1 : 0) + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(lArray);
    }

    public static int iMeth1(boolean bl, int n, int n2) {
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 12);
        Test.vMeth(n, fFld);
        int n3 = (n >>> 1) % 400;
        nArray[n3] = nArray[n3] + n2;
        long l = (long)((bl ? 1 : 0) + (n -= 11) + n2) + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth(byte by) {
        int n = -9514;
        int n2 = -102;
        int n3 = 49280;
        int n4 = 91;
        int n5 = -149;
        int[] nArray = new int[400];
        float f = 79.444f;
        int n6 = -31119;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -8);
        FuzzerUtils.init(lArray, 7L);
        for (n = 10; 352 > n; ++n) {
            int n7 = n - 1;
            nArray[n7] = nArray[n7] - nArray[n + 1];
            block7: for (n3 = 5; n3 > 1; --n3) {
                instanceCount += (long)(n3 * n3);
                int n8 = n3;
                int n9 = nArray[n8] - 1;
                nArray[n8] = n9;
                n2 = (int)((long)(n3 + n2 + n9) + Math.max(lArray[n3 - 1], (long)(f + (float)by)));
                n2 += n3 ^ n;
                int n10 = n - 1;
                int n11 = nArray[n10] - 1;
                nArray[n10] = n11;
                n4 -= n11;
                n5 = 1;
                while (++n5 < 2) {
                    short s = (short)(n6 + (short)((float)Test.iMeth1(bl, n5, n) + fFld));
                    n6 = s;
                    by = (byte)(by - (byte)s);
                }
                try {
                    n4 = n5 / nArray[n3 + 1];
                    n2 = 1140166361 / n5;
                    n2 %= n3;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                switch (n3 % 2 * 5 + 99) {
                    case 107: {
                        n2 = n3;
                        int n12 = n3 - 1;
                        nArray[n12] = nArray[n12] - n4;
                        n2 &= n;
                        continue block7;
                    }
                    case 105: {
                        f = instanceCount;
                        continue block7;
                    }
                    default: {
                        f = n5;
                    }
                }
            }
        }
        long l = (long)(by + n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -54651;
        int n2 = 6;
        int n3 = -11716;
        int n4 = 11;
        int n5 = -32187;
        int n6 = -12;
        int n7 = 243;
        boolean bl = false;
        long l = 3654779942L;
        int n8 = -26734;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -21.37566);
        for (double d : dArray) {
            n += n * Test.iMeth(byFld);
            for (n2 = 3; 63 > n2; ++n2) {
                int n9 = n2 + 1;
                this.iArrFld[n9] = this.iArrFld[n9] + 219;
                n3 >>= byFld;
                instanceCount += (long)n2;
            }
            for (l = 3L; l < 63L; ++l) {
                n = 53183;
                instanceCount -= (long)n3;
                n4 = 2;
                n = (int)fFld;
                switch ((int)(l % 3L * 5L + 24L)) {
                    case 29: {
                        n5 = 1;
                        while (n5 < 2) {
                            n6 = 88;
                            n4 = (int)((long)n4 + ((long)n5 * l + (long)n3 - instanceCount));
                            n += n5;
                            byFld = (byte)(byFld | 0xC);
                            n6 += n5;
                            d *= (double)l;
                            n7 = n5++;
                        }
                        break;
                    }
                    case 27: {
                        n += 64048;
                        break;
                    }
                    case 31: {
                        n4 = n8;
                    }
                }
                bl = false;
                n7 &= 2;
                long[] lArray = this.lArrFld[(int)(l - 1L)][(int)(l + 1L)];
                int n10 = (int)l;
                lArray[n10] = lArray[n10] << n4;
                n6 = n;
            }
        }
        dFld = fFld;
        n4 += (int)instanceCount;
        n4 = (int)l;
        FuzzerUtils.out.println("i i15 i16 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("b3 l i17 = " + (bl ? 1 : 0) + "," + l + "," + n4);
        FuzzerUtils.out.println("i18 i19 i20 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("s2 dArr = " + n8 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
        FuzzerUtils.out.println("Test.fFld Test.sArrFld iArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("lArrFld lArrFld1 = " + FuzzerUtils.checkSum((Object[][])this.lArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld1));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)-12561);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

