/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -6729139300331859853L;
    public static volatile boolean bFld = false;
    public volatile long[] lArrFld = new long[400];
    public static long fMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(int n, long l, int n2) {
        int n3 = -26;
        int n4 = -1;
        boolean bl = false;
        boolean[][][] blArray = new boolean[400][400][400];
        float f = -85.332f;
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        for (n3 = 369; 16 < n3; n3 -= 3) {
            n <<= n4;
            blArray[n3 + 1][n3][n3 - 1] = bl;
        }
        vMeth1_check_sum += (long)n + (l >>= n4) + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f += -2.66792f) + FuzzerUtils.checkSum((Object[][])blArray);
    }

    public static void vMeth(int n, int n2, int n3) {
        int n4 = -16807;
        int n5 = -17420;
        int n6 = 12;
        int n7 = 8;
        int n8 = 0;
        int n9 = 12;
        int[] nArray = new int[400];
        int n10 = 57;
        float f = -46.459f;
        float[] fArray = new float[400];
        double d = 1.126533;
        FuzzerUtils.init(nArray, -51677);
        FuzzerUtils.init(fArray, -1.356f);
        n4 = 1;
        do {
            block19: for (n5 = 1; n5 < 6; ++n5) {
                switch (n4 % 9 + 44) {
                    case 44: {
                        Test.vMeth1(n3, instanceCount, -52);
                        block20: for (n7 = 1; n7 < 2; ++n7) {
                            instanceCount = n6;
                            n2 += n7 | n7;
                            if (bFld) continue block19;
                            n8 = -1;
                            if (bFld) continue block19;
                            switch (n4 % 7 + 28) {
                                case 28: 
                                case 29: {
                                    n6 >>>= (int)instanceCount;
                                    n10 = (byte)(n10 + (byte)((long)n7 * instanceCount + instanceCount - (long)n5));
                                    continue block20;
                                }
                                case 30: {
                                    if (n4 == 0) continue block20;
                                    vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n10 + Float.floatToIntBits(f) + n9) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                                    return;
                                }
                                case 31: {
                                    instanceCount = n2;
                                }
                                case 32: {
                                    n2 += 6;
                                    continue block20;
                                }
                                case 33: {
                                    n8 += (int)f;
                                    continue block20;
                                }
                                case 34: {
                                    if (!bFld) continue block20;
                                    continue block20;
                                }
                            }
                        }
                        continue block19;
                    }
                    case 45: {
                        instanceCount += (long)(-20130 + n5 * n5);
                        continue block19;
                    }
                    case 46: {
                        n3 -= n9;
                    }
                    case 47: {
                        n10 = (byte)(n10 + (byte)(-4L + (long)(n5 * n5)));
                    }
                    case 48: {
                        int n11 = n5;
                        fArray[n11] = fArray[n11] * (float)n4;
                        continue block19;
                    }
                    case 49: {
                        n += n5;
                    }
                    case 50: 
                    case 51: {
                        n6 *= (int)d;
                    }
                    case 52: {
                        n6 -= (int)f;
                    }
                }
            }
        } while (++n4 < 262);
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n10 + Float.floatToIntBits(f) + n9) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static float fMeth() {
        int n = 160;
        int n2 = -90;
        int n3 = -11;
        int n4 = -7;
        float f = -35.358f;
        double d = 0.54138;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -2522260819L);
        Test.vMeth(-21017, n, n);
        n2 = 1;
        block0: do {
            for (n3 = 1; n3 < 5; ++n3) {
                if (bFld) {
                    if (bFld) continue;
                    n4 += n3 ^ n;
                    int n5 = n3 + 1;
                    lArray[n5] = lArray[n5] - (long)n3;
                } else if (bFld) {
                    n4 = (int)instanceCount;
                    if (bFld) {
                        continue block0;
                    }
                } else {
                    n &= 5;
                }
                n4 <<= n4;
                n = (int)instanceCount;
                f = n4;
                d -= (double)instanceCount;
            }
        } while (++n2 < 354);
        long l = (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
        fMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 3;
        int n2 = -231;
        int n3 = 5;
        int n4 = 13324;
        int n5 = -142;
        int n6 = -7;
        int n7 = 1;
        int n8 = 198;
        int n9 = 0;
        int n10 = 46508;
        int n11 = -176;
        int[] nArray = new int[400];
        double d = 125.61015;
        float f = 1.144f;
        float[] fArray = new float[400];
        int n12 = -17564;
        int n13 = 11;
        FuzzerUtils.init(nArray, -186);
        FuzzerUtils.init(fArray, 1.519f);
        n = 1;
        do {
            instanceCount ^= 0xFFFFFFFFFFFFFFB0L;
            int n14 = n + 1;
            nArray[n14] = nArray[n14] + (int)((double)((float)n - -127.0f * Test.fMeth()) - d);
            f += (float)(n * n);
            n2 += n;
            n3 = 1;
            do {
                this.lArrFld[n + 1] = n2;
                n12 = (short)n3;
                nArray[n3 - 1] = 40967;
                n2 = (int)((float)n2 + ((float)n3 * (f += -165.0f) + (float)n - (float)instanceCount));
            } while (++n3 < 174);
            instanceCount -= (long)n2;
            n2 = (int)d;
            f = -4.3577936E8f;
            for (n4 = n; 174 > n4; ++n4) {
                n5 += n4;
                fArray[n4 + 1] = (float)d;
                n5 = -62464;
                f += (float)n13;
                int n15 = n4 + 1;
                nArray[n15] = nArray[n15] % (n3 | 1);
                for (n6 = 1; 1 > n6; ++n6) {
                    n12 = (short)(n12 + (short)n6);
                }
            }
            for (n8 = 5; n8 < 174; ++n8) {
                f -= (float)n4;
            }
        } while (++n < 144);
        n5 = n9;
        int n16 = (n2 >>> 1) % 400;
        this.lArrFld[n16] = this.lArrFld[n16] + (long)n8;
        for (n10 = 4; n10 < 247; ++n10) {
            n2 >>= (int)instanceCount;
            instanceCount *= (long)d;
        }
        FuzzerUtils.out.println("i d2 f3 = " + n + "," + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i18 i19 s = " + n2 + "," + n3 + "," + n12);
        FuzzerUtils.out.println("i21 i22 by1 = " + n4 + "," + n5 + "," + n13);
        FuzzerUtils.out.println("i23 i24 i25 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i26 i27 i28 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("iArr fArr1 = " + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld lArrFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

