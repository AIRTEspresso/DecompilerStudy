/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 4L;
    public static double dFld = -1.116122;
    public static float fFld = -24.797f;
    public static short sFld = (short)-3192;
    public static boolean bFld = false;
    public static volatile byte byFld = (byte)101;
    public static long iMeth_check_sum = 0L;
    public static long fMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;

    public static void vMeth() {
        int n = -32709;
        int n2 = -4;
        int n3 = 7;
        int[] nArray = new int[400];
        long[] lArray = new long[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(lArray, 1535816565L);
        FuzzerUtils.init(nArray, 158);
        FuzzerUtils.init(blArray, false);
        for (n = 7; n < 246; ++n) {
            lArray[n - 1] = n;
            n2 += n * n;
            n3 = 1;
            block11: while (++n3 < 7) {
                nArray[n] = n;
                try {
                    nArray[n3 - 1] = -54826 / n3;
                    n2 = n3 / n3;
                    n2 = nArray[n3] % n;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                int n4 = n3 - 1;
                nArray[n4] = nArray[n4] >> (int)instanceCount;
                n2 *= (int)instanceCount;
                n2 -= (int)dFld;
                try {
                    nArray[n] = n3 / -5462;
                    n2 = 619 % n2;
                    n2 = 33023 % nArray[n - 1];
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                blArray[n] = false;
                switch (n % 3 * 5 + 2) {
                    case 3: 
                    case 6: {
                        fFld += (float)(98 + n3 * n3);
                        n2 <<= n3;
                        instanceCount &= instanceCount;
                    }
                    case 5: {
                        try {
                            n2 %= n2;
                            n2 /= 21370;
                            n2 = n / 148821730;
                        }
                        catch (ArithmeticException arithmeticException) {}
                        continue block11;
                    }
                }
                n2 += n3;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
    }

    public static float fMeth(long l) {
        int n = 2;
        int n2 = -166;
        int[] nArray = new int[400];
        float f = 0.584f;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.269f);
        FuzzerUtils.init(nArray, 199);
        Test.vMeth();
        for (n = 3; 189 > n; ++n) {
            n2 += n - n2;
            fArray[n - 1] = n2;
        }
        f = 1.0f;
        do {
            dFld += (double)n;
            fFld = n2;
            n2 <<= 60455486;
            n2 += (int)((long)f | (long)fFld);
            n2 += n;
            n2 -= n;
            n2 -= n;
            n2 *= n2;
            sFld = (short)(sFld << (short)n);
        } while ((f += 1.0f) < 304.0f);
        long l2 = l + (long)n + (long)n2 + (long)Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
        fMeth_check_sum += l2;
        return l2;
    }

    public static int iMeth(int n) {
        int n2 = 36820;
        int n3 = 234;
        int n4 = 207;
        int n5 = -13;
        int[] nArray = new int[400];
        int n6 = 6559;
        short[] sArray = new short[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -36);
        FuzzerUtils.init(lArray, 1290L);
        FuzzerUtils.init(sArray, (short)22764);
        for (int n7 : nArray) {
            int n8 = (n7 >>> 1) % 400;
            int n9 = nArray[n8];
            nArray[n8] = n9 + 1;
            instanceCount = Math.max((long)(Test.fMeth(instanceCount) + (float)(n >>= n9)), instanceCount);
            for (n2 = 1; n2 < 4; ++n2) {
                n3 += (int)instanceCount;
                n <<= n7;
                sFld = (short)-33;
            }
            instanceCount |= instanceCount;
            if (!bFld) continue;
        }
        n4 = 2;
        while (237 > n4) {
            n3 = (int)((float)n3 + ((float)n4 + fFld));
            int n10 = n4++;
            sArray[n10] = (short)(sArray[n10] & n6);
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(sArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    /*
     * Unable to fully structure code
     */
    public void mainTest(String[] var1_1) {
        var2_2 = 6;
        var3_3 = -23733;
        var4_4 = -250;
        var5_5 = -14;
        var6_6 = 89;
        var7_7 = 55;
        var8_8 = 11;
        var9_9 = new int[400];
        var10_10 = -3198898865L;
        var12_11 = new long[400];
        var13_12 = new boolean[400][400];
        FuzzerUtils.init(var12_11, -19L);
        FuzzerUtils.init(var9_9, 0);
        FuzzerUtils.init(var13_12, true);
        Test.iMeth(var2_2);
        for (long var17_16 : var12_11) {
            for (var3_3 = 2; var3_3 < 63; ++var3_3) {
                v0 = (var2_2 >>> 1) % 400;
                var12_11[v0] = var12_11[v0] - (long)var2_2;
                var2_2 *= var3_3;
                var2_2 = (int)Test.instanceCount;
                switch (var3_3 % 2 * 5 + 62) {
                    case 64: {
                        var5_5 /= 11;
                        var4_4 += var3_3 + Test.sFld;
                        break;
                    }
                    default: {
                        v1 = var3_3 + 1;
                        var9_9[v1] = var9_9[v1] + (int)Test.instanceCount;
                        var5_5 = (int)(Test.fFld -= -4.0f);
                    }
                }
                var9_9[var3_3] = var3_3;
                var5_5 += var3_3 | Test.sFld;
                var4_4 = 57696;
                block89: for (var6_6 = 1; var6_6 < 2; ++var6_6) {
                    switch (var6_6 + 122) {
                        case 122: {
                            var17_16 = (long)((float)var17_16 + ((float)(var6_6 * var5_5 + var5_5) - Test.fFld));
                            var2_2 = (int)Test.fFld;
                            v2 = var3_3 - 1;
                            var9_9[v2] = var9_9[v2] >>> var7_7;
                            Test.dFld -= (double)var7_7;
                            continue block89;
                        }
                        case 123: {
                            var5_5 += var6_6 * var3_3;
                            var2_2 &= (int)Test.instanceCount;
                            continue block89;
                        }
                        case 124: {
                            switch ((var5_5 >>> 1) % 10 + 52) {
                                case 52: {
                                    var9_9[var3_3] = var3_3;
                                    var4_4 = 178;
                                    var2_2 -= 72;
                                    var17_16 *= (long)Test.fFld;
                                    break;
                                }
                                case 53: {
                                    var2_2 %= (int)(Test.instanceCount | 1L);
                                    break;
                                }
                                case 54: 
                                case 55: {
                                    var7_7 = (int)((long)var7_7 + ((long)var6_6 - Test.instanceCount));
                                    break;
                                }
                                case 56: {
                                    v3 = var6_6 - 1;
                                    var9_9[v3] = var9_9[v3] + (int)Test.dFld;
                                }
                                case 57: {
                                    var7_7 += var6_6 + var6_6;
                                    break;
                                }
                                case 58: {
                                    Test.fFld *= (float)var5_5;
                                    break;
                                }
                                case 59: {
                                    Test.instanceCount = (long)Test.dFld;
                                    break;
                                }
                                case 60: {
                                    Test.dFld += (double)var5_5;
                                    break;
                                }
                                case 61: {
                                    Test.instanceCount += (long)(var6_6 + var7_7);
                                }
                            }
                        }
                        case 125: {
                            v4 = var6_6;
                            var9_9[v4] = var9_9[v4] | var2_2;
                            continue block89;
                        }
                        case 126: {
                            var9_9[var6_6] = -14;
                        }
                        ** case 127:
lbl86:
                        // 2 sources

                        case 128: {
                            var5_5 = (int)((long)var5_5 + ((long)(var6_6 * var3_3) + var17_16 - (long)var2_2));
                            continue block89;
                        }
                        case 129: {
                            var2_2 += var6_6 * var2_2 + var8_8 - var8_8;
                            continue block89;
                        }
                        case 130: {
                            try {
                                var8_8 = var2_2 % var6_6;
                                var5_5 /= var3_3;
                                var8_8 = var9_9[var3_3 + 1] / var3_3;
                                continue block89;
                            }
                            catch (ArithmeticException var19_17) {
                                // empty catch block
                            }
                        }
                        case 131: {
                            continue block89;
                        }
                        case 132: {
                            var2_2 += var6_6;
                        }
                        case 133: {
                            var10_10 = var5_5;
                            continue block89;
                        }
                        case 134: {
                            v5 = var6_6;
                            var12_11[v5] = var12_11[v5] - (long)Test.fFld;
                            continue block89;
                        }
                        case 135: {
                            Test.dFld = Test.fFld;
                            continue block89;
                        }
                        case 136: {
                            v6 = var3_3;
                            var12_11[v6] = var12_11[v6] * -74L;
                            continue block89;
                        }
                        case 137: {
                            Test.dFld = var7_7;
                            continue block89;
                        }
                        case 138: {
                            var2_2 <<= var2_2;
                        }
                        case 139: {
                            var5_5 += 99;
                            continue block89;
                        }
                        case 140: {
                            var10_10 += (long)(var6_6 | var3_3);
                        }
                        case 141: {
                            v7 = var6_6;
                            var12_11[v7] = var12_11[v7] & var17_16;
                            continue block89;
                        }
                        case 142: {
                            var2_2 = var3_3;
                        }
                        case 143: {
                            var8_8 >>= 69;
                            continue block89;
                        }
                        case 144: {
                            var5_5 = 60370;
                            continue block89;
                        }
                        case 145: 
                        case 146: {
                            Test.sFld = (short)(Test.sFld + (short)Test.instanceCount);
                        }
                        case 147: {
                            Test.sFld = (short)(Test.sFld & -1);
                            continue block89;
                        }
                        case 148: {
                            var17_16 >>= var7_7;
                            continue block89;
                        }
                        case 149: {
                            Test.fFld -= (float)var10_10;
                            continue block89;
                        }
                        case 150: {
                            var8_8 = var6_6;
                            continue block89;
                        }
                        case 151: {
                            Test.dFld *= (double)var17_16;
                            continue block89;
                        }
                        case 152: {
                            Test.fFld *= (float)var8_8;
                            continue block89;
                        }
                        case 153: {
                            var7_7 += var2_2;
                            continue block89;
                        }
                        case 154: {
                            var4_4 += (int)var17_16;
                            continue block89;
                        }
                        case 155: {
                            Test.instanceCount -= 6161L;
                            continue block89;
                        }
                        case 156: {
                            Test.instanceCount <<= -12972;
                        }
                        case 157: {
                            Test.fFld += (float)(var6_6 * var5_5 + var7_7 - var7_7);
                            continue block89;
                        }
                        case 158: {
                            var13_12[var3_3][var3_3 + 1] = Test.bFld;
                        }
                        case 159: {
                            var4_4 -= var6_6;
                            continue block89;
                        }
                        case 160: {
                            var9_9[var6_6] = (int)var10_10;
                            continue block89;
                        }
                        case 161: {
                            var4_4 -= (int)var10_10;
                            continue block89;
                        }
                        case 162: {
                            var5_5 += (int)(-1.329f + (float)(var6_6 * var6_6));
                            continue block89;
                        }
                        case 163: {
                            var4_4 = 5;
                            continue block89;
                        }
                        case 164: {
                            var2_2 -= 50415;
                            continue block89;
                        }
                        case 165: {
                            var17_16 += 1583L;
                            continue block89;
                        }
                        case 166: {
                            Test.sFld = (short)var2_2;
                            continue block89;
                        }
                        case 167: {
                            var10_10 = -236L;
                        }
                        case 168: {
                            var8_8 += var6_6 - var8_8;
                            continue block89;
                        }
                        case 169: {
                            Test.sFld = (short)(Test.sFld + 18698);
                            continue block89;
                        }
                        case 170: {
                            var4_4 = 195304623;
                            continue block89;
                        }
                        case 171: {
                            var12_11[var3_3] = var3_3;
                            continue block89;
                        }
                        case 172: {
                            var7_7 += (int)(105L + (long)(var6_6 * var6_6));
                            continue block89;
                        }
                        case 173: {
                            Test.fFld *= (float)var5_5;
                            continue block89;
                        }
                        case 174: {
                            var5_5 -= var4_4;
                        }
                        case 175: {
                            var7_7 = var5_5;
                        }
                        case 176: {
                            var7_7 += var6_6 * var6_6;
                            continue block89;
                        }
                        case 177: {
                            var17_16 += (long)Test.byFld;
                            continue block89;
                        }
                        case 178: {
                            var8_8 <<= var3_3;
                        }
                        case 179: {
                            var2_2 -= var8_8;
                            continue block89;
                        }
                        case 180: {
                            var12_11[var3_3] = var2_2;
                            continue block89;
                        }
                        case 181: {
                            var8_8 ^= var6_6;
                            continue block89;
                        }
                        case 182: {
                            var9_9[var3_3 + 1] = 208;
                            continue block89;
                        }
                        case 183: {
                            var12_11[var3_3] = 10L;
                            continue block89;
                        }
                        case 184: {
                            v8 = var3_3 + 1;
                            var9_9[v8] = var9_9[v8] * var8_8;
                        }
                        case 185: {
                            Test.sFld = (short)(Test.sFld << -4623);
                            continue block89;
                        }
                        case 186: {
                            continue block89;
                        }
                        case 187: {
                            if (Test.bFld) continue block89;
                        }
                        case 188: {
                            v9 = var6_6 - 1;
                            var12_11[v9] = var12_11[v9] - 178L;
                            continue block89;
                        }
                        case 189: {
                            Test.dFld = var4_4;
                        }
                        case 190: {
                            var17_16 -= (long)var5_5;
                        }
                        case 191: {
                            Test.fFld += (float)((long)var6_6 - var17_16);
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i11 i12 i13 = " + var2_2 + "," + var3_3 + "," + var4_4);
        FuzzerUtils.out.println("i14 i15 i16 = " + var5_5 + "," + var6_6 + "," + var7_7);
        FuzzerUtils.out.println("i17 l2 lArr2 = " + var8_8 + "," + var10_10 + "," + FuzzerUtils.checkSum(var12_11));
        FuzzerUtils.out.println("iArr3 bArr1 = " + FuzzerUtils.checkSum(var9_9) + "," + FuzzerUtils.checkSum(var13_12));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + Test.instanceCount + "," + Double.doubleToLongBits(Test.dFld) + "," + Float.floatToIntBits(Test.fFld));
        FuzzerUtils.out.println("Test.sFld Test.bFld Test.byFld = " + Test.sFld + "," + (Test.bFld != false ? 1 : 0) + "," + Test.byFld);
        FuzzerUtils.out.println("vMeth_check_sum: " + Test.vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + Test.fMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + Test.iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

