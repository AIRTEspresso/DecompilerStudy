/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 42L;
    public int iFld = -12;
    public static double dFld = -2.22376;
    public static byte byFld = (byte)102;
    public static volatile short sFld = (short)-18140;
    public static volatile boolean bFld = false;
    public static int[] iArrFld = new int[400];
    public static volatile int[] iArrFld1 = new int[400];
    public static long byMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(long l) {
        int n = 62;
        int n2 = -47598;
        int n3 = -2;
        int n4 = 49440;
        int n5 = -63281;
        float f = 2.93f;
        int n6 = 40;
        int n7 = 22809;
        n = 1;
        while (++n < 286) {
            for (n2 = 1; n2 < 6; n2 += 2) {
                f += (float)(n2 * n2);
                int n8 = n;
                iArrFld[n8] = iArrFld[n8] << n6;
                n7 = (short)(n7 - (short)n);
                for (n4 = 1; n4 < 3; n4 += 2) {
                    n6 = (byte)(n6 & 0xFFFFFFDF);
                    dFld += (double)n4;
                    n5 += 97;
                    n5 += (int)f;
                    f = n;
                    f -= (float)n2;
                    n7 = (short)(n7 + (short)n4);
                    l += (long)n2;
                    int n9 = n4 - 1;
                    iArrFld[n9] = iArrFld[n9] * n4;
                }
            }
        }
        vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7 + (long)n4 + (long)n5;
    }

    public static void vMeth(boolean bl) {
        int n = -241;
        int n2 = 21261;
        int n3 = 148;
        int n4 = -13;
        int n5 = -710;
        float f = 119.36f;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 1.76494);
        Test.vMeth1(30317L);
        n = 138;
        block20: do {
            switch (n % 2 * 5 + 62) {
                case 68: {
                    block21: for (n2 = 22; 1 < n2; n2 -= 2) {
                        int n6 = n2 + 1;
                        iArrFld[n6] = iArrFld[n6] + n;
                        if (n != 0) {
                            vMeth_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
                            return;
                        }
                        instanceCount -= instanceCount;
                        dFld *= (double)n2;
                        n3 >>= (int)instanceCount;
                        switch (n % 8 + 47) {
                            case 47: {
                                switch (n2 % 5 + 127) {
                                    case 127: {
                                        for (n4 = 1; n4 < 3; ++n4) {
                                            int n7 = n;
                                            dArray[n7] = dArray[n7] % 1.64917504195884314E18;
                                            n5 = n2;
                                            dFld = f;
                                        }
                                        break;
                                    }
                                    case 128: {
                                        dFld *= 3.0;
                                        break;
                                    }
                                    case 129: {
                                        instanceCount >>= (int)instanceCount;
                                        break;
                                    }
                                    case 130: 
                                    case 131: {
                                        f += f;
                                    }
                                }
                                continue block21;
                            }
                            case 48: {
                                n5 = (int)((long)n5 + ((long)n2 ^ (long)f));
                                continue block21;
                            }
                            case 49: {
                                byFld = (byte)85;
                                continue block21;
                            }
                            case 50: {
                                n3 = -9;
                                continue block21;
                            }
                            case 51: {
                                f = n2;
                                continue block21;
                            }
                            case 52: {
                                n5 |= n;
                                continue block21;
                            }
                            case 53: {
                                if (n2 == 0) continue block21;
                                vMeth_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
                                return;
                            }
                            case 54: {
                                f += (float)(n2 - sFld);
                            }
                        }
                    }
                    continue block20;
                }
                case 70: 
            }
        } while ((n -= 2) > 0);
        vMeth_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static byte byMeth() {
        int n = -10222;
        int n2 = -29;
        int n3 = -120;
        int n4 = 3;
        int n5 = -121;
        int n6 = -5;
        float f = 1.154f;
        long l = 169L;
        for (n = 3; 286 > n; ++n) {
            n2 = (int)instanceCount;
            Test.vMeth(bFld);
            Test.iArrFld[n] = n2;
            f = (float)dFld;
            n2 += n * n;
        }
        iArrFld[375] = iArrFld[375] + n;
        for (n3 = 16; n3 < 380; ++n3) {
            for (n5 = 1; n5 < 5; ++n5) {
                l = 1L;
                while (++l < 2L) {
                    n4 *= n6;
                    if (n6 != 0) {
                        // empty if block
                    }
                    n4 = (int)l;
                    n6 += n6;
                    n2 = sFld;
                }
            }
        }
        long l2 = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6) + l;
        byMeth_check_sum += l2;
        return (byte)l2;
    }

    public void mainTest(String[] stringArray) {
        float f = 0.551f;
        float[] fArray = new float[400];
        int n = -7;
        int n2 = -12;
        int n3 = 1;
        int n4 = -1;
        int n5 = 0;
        int n6 = 217;
        int n7 = 173;
        int n8 = -22745;
        int n9 = 113;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -124.42827);
        FuzzerUtils.init(fArray, -2.114f);
        instanceCount -= (long)this.iFld++;
        f = (this.iFld + this.iFld) * (n | 0x1A);
        this.iFld = Test.byMeth();
        for (n2 = 6; n2 < 244; ++n2) {
            dArray[n2 - 1] = -20481.0;
            n *= (int)f;
        }
        for (int n10 : iArrFld) {
            if (bFld) {
                int n11 = (n >>> 1) % 400;
                iArrFld[n11] = iArrFld[n11] + n2;
                continue;
            }
            if (bFld) {
                for (n4 = 3; 63 > n4; ++n4) {
                    n10 *= byFld;
                }
                Test.iArrFld[(n2 >>> 1) % 400] = n2;
                n5 >>>= n3;
                continue;
            }
            if (bFld) {
                int n12 = (n10 >>> 1) % 400;
                iArrFld[n12] = iArrFld[n12] - n2;
                n5 -= (int)(instanceCount *= (long)n5);
                continue;
            }
            block8: for (n6 = 63; n6 > 2; --n6) {
                int n13 = n6;
                fArray[n13] = fArray[n13] + (float)n10;
                n10 = n;
                switch ((this.iFld >>> 1) % 3 * 5 + 80) {
                    case 84: {
                        n10 -= (int)instanceCount;
                        n3 |= n2;
                        Test.iArrFld1[n6 + 1] = 2;
                        for (n8 = 1; n8 < 2; n8 += 3) {
                            n5 = (int)((long)n5 + ((long)(n8 * n5) + instanceCount - instanceCount));
                            if (bFld) {
                                dFld = n4;
                                n10 += (int)f;
                                continue;
                            }
                            if (!bFld) continue;
                            f += (float)n8;
                        }
                        continue block8;
                    }
                    case 83: {
                        n10 |= n4;
                        continue block8;
                    }
                    case 90: {
                        int n14 = n6;
                        iArrFld1[n14] = iArrFld1[n14] ^ 0xFFFFFF53;
                        continue block8;
                    }
                    default: {
                        n5 -= n9;
                    }
                }
            }
        }
        FuzzerUtils.out.println("f i i17 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i18 i20 i21 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i22 i23 i24 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i25 dArr1 fArr = " + n9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.byFld Test.sFld Test.bFld = " + byFld + "," + sFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iArrFld Test.iArrFld1 = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 14);
        FuzzerUtils.init(iArrFld1, -82);
        byMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

