/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -27988L;
    public static double dFld = 122.101356;
    public static short sFld = (short)15807;
    public int iFld = -4428;
    public float fFld = -6.434f;
    public byte byFld = (byte)-53;
    public static volatile short[][] sArrFld = new short[400][400];
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        int n2 = 1;
        int n3 = -56780;
        int n4 = -141;
        int n5 = -11;
        int n6 = 13;
        int n7 = -50;
        int[] nArray = new int[400];
        float f = -102.76f;
        boolean bl = true;
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, 13751);
        FuzzerUtils.init(dArray, -66.129352);
        n = 11;
        short[] sArray = sArrFld[62];
        int n8 = (n >>> 1) % 400;
        sArray[n8] = (short)(sArray[n8] * (short)n);
        n2 = 162;
        while ((n2 -= 2) > 0) {
            for (n3 = 1; n3 < 19; ++n3) {
                f += (float)instanceCount;
                block16: for (n5 = n3; n5 < 2; ++n5) {
                    instanceCount = (long)dFld;
                    int n9 = n3 - 1;
                    nArray[n9] = nArray[n9] * n5;
                    switch ((n6 >>> 1) % 9 + 108) {
                        case 108: {
                            int n10 = n2;
                            dArray[n10] = dArray[n10] + (double)n2;
                            f *= (float)dFld;
                            continue block16;
                        }
                        case 109: 
                        case 110: {
                            switch (n3 % 2 * 5 + 75) {
                                case 77: {
                                    nArray[n3 - 1] = (int)dFld;
                                    n6 = (int)dFld;
                                    n += n5 * n5;
                                }
                                case 76: {
                                    n /= (int)(instanceCount | 1L);
                                }
                            }
                            continue block16;
                        }
                        case 111: {
                            f -= -4.0f;
                            continue block16;
                        }
                        case 112: {
                            n6 >>= sFld;
                            continue block16;
                        }
                        case 113: {
                            n6 += n6;
                            continue block16;
                        }
                        case 114: {
                            n6 += n4;
                            continue block16;
                        }
                        case 115: {
                            if (!bl) continue block16;
                            continue block16;
                        }
                        case 116: {
                            dArray[n3 + 1] = n7;
                            continue block16;
                        }
                        default: {
                            dFld -= (double)n7;
                        }
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + (bl ? 1 : 0) + n7) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static int iMeth() {
        int n = 9;
        int n2 = -117;
        int n3 = -42899;
        int n4 = -56960;
        int n5 = 24438;
        int n6 = 64112;
        int n7 = 37604;
        float f = 2.0f;
        int n8 = -16;
        for (n = 13; n < 227; n += 3) {
            for (n3 = 1; 22 > n3; ++n3) {
                f -= (float)(Math.max(Integer.reverseBytes(n4), (int)((long)n4 - instanceCount)) * n4++);
            }
            n4 = n4-- * n4;
            Test.vMeth1(n3);
        }
        for (n5 = 8; 345 > n5; ++n5) {
            n7 = 1;
            do {
                n2 *= n4;
                int n9 = n5;
                iArrFld[n9] = iArrFld[n9] * n8;
                Test.iArrFld[n5 - 1] = (int)instanceCount;
            } while (++n7 < 5);
            n6 = -44279;
        }
        instanceCount -= (long)n6;
        long l = n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + n7 + n8;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void vMeth(int n, int n2) {
        double d = -48.1075;
        int n3 = 42211;
        int n4 = 6;
        int n5 = -36103;
        int n6 = 58152;
        int n7 = -254;
        float f = 119.832f;
        d = -(n2++ - Test.iMeth());
        ++n2;
        block3: for (n3 = 9; n3 < 146; n3 += 3) {
            switch (112) {
                case 112: {
                    instanceCount <<= n4;
                    n4 += 4 + n3 * n3;
                    d = n3;
                    n5 = 1;
                    while (++n5 < 34) {
                        f += (float)n4;
                        for (n6 = 1; n6 < 1; ++n6) {
                            f -= (float)instanceCount;
                            if (n7 != 0) {
                                vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7;
                                return;
                            }
                            int n8 = n5;
                            iArrFld[n8] = iArrFld[n8] - (int)instanceCount;
                            n *= n;
                            n7 += n4;
                        }
                    }
                    continue block3;
                }
                default: {
                    instanceCount += (long)(n3 - sFld);
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7;
    }

    public void mainTest(String[] stringArray) {
        int n = -41499;
        int n2 = 1;
        int n3 = -64418;
        int n4 = 14535;
        boolean bl = false;
        this.vMeth(this.iFld, this.iFld);
        for (n = 1; n < 307; ++n) {
            this.iFld >>= this.iFld;
            n2 = this.iFld;
            this.fFld += (float)n;
            this.iFld &= n;
            n2 <<= -438499239;
            Test.iArrFld[n] = -12979;
            this.iFld += n * n;
            switch (n % 2 * 5 + 77) {
                case 83: {
                    dFld -= (double)n2;
                    this.iFld += n;
                    break;
                }
                case 84: {
                    for (n3 = 82; n3 > 5; n3 -= 3) {
                        int n5 = n + 1;
                        iArrFld[n5] = iArrFld[n5] - n;
                        dFld %= (double)(n3 | 1);
                        sFld = (short)(sFld + (short)(n3 ^ (n2 |= this.byFld)));
                        this.iFld += n3 * n3;
                        this.iFld = this.iFld;
                        this.fFld -= -31249.0f;
                        instanceCount += (long)n3;
                    }
                    this.iFld = (int)((long)this.iFld + ((long)(n * this.iFld + this.iFld) - instanceCount));
                }
            }
            n4 |= (int)instanceCount;
        }
        n4 = n;
        instanceCount -= (long)n;
        instanceCount <<= n4;
        FuzzerUtils.out.println("i21 i22 b1 = " + n + "," + (n2 >>= sFld) + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i23 i24 = " + n3 + "," + (n4 &= n));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.sFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + sFld);
        FuzzerUtils.out.println("iFld fFld byFld = " + this.iFld + "," + Float.floatToIntBits(this.fFld) + "," + this.byFld);
        FuzzerUtils.out.println("Test.sArrFld Test.iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)24112);
        FuzzerUtils.init(iArrFld, 12);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

