/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -44818L;
    public static boolean bFld = true;
    public static float fFld = 1.6f;
    public static short sFld = (short)13796;
    public static int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static volatile long[] lArrFld = new long[400];
    public double[] dArrFld = new double[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, int n2, long l) {
        float f = 0.462f;
        int n3 = -6076;
        int n4 = -3;
        double d = 0.70422;
        int n5 = -27677;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)-159L);
        instanceCount = l;
        lArray[((n -= (int)f) >>> 1) % 400][(n2 >>> 1) % 400][(n2 >>> 1) % 400] = (long)f;
        switch ((n >>> 1) % 7 * 5 + 72) {
            case 98: {
                n3 = 365;
                while (--n3 > 0) {
                    Test.iArrFld[n3] = n2;
                    n4 = 1;
                    while (++n4 < 5) {
                    }
                    switch (n3 % 1 + 109) {
                        case 109: {
                            n += n3;
                            instanceCount += l;
                        }
                    }
                    int n6 = n3;
                    iArrFld[n6] = iArrFld[n6] - (int)l;
                    if (n3 == 0) continue;
                    vMeth_check_sum += (long)(n + n2) + l + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + Double.doubleToLongBits(d) + (long)n5 + FuzzerUtils.checkSum((Object[][])lArray);
                    return;
                }
                break;
            }
            case 74: {
                f *= (float)n;
                break;
            }
            case 86: {
                d *= (double)f;
                break;
            }
            case 99: {
                n2 -= 62014;
            }
            case 89: {
                n2 = (int)f;
                break;
            }
            case 94: {
                f *= (float)n;
                break;
            }
            case 73: {
                Test.fArrFld[(n4 >>> 1) % 400] = n5;
                break;
            }
            default: {
                long[] lArray2 = lArray[(n2 >>> 1) % 400][(n4 >>> 1) % 400];
                int n7 = (n4 >>> 1) % 400;
                lArray2[n7] = lArray2[n7] + (long)n4;
            }
        }
        vMeth_check_sum += (long)(n + n2) + l + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + Double.doubleToLongBits(d) + (long)n5 + FuzzerUtils.checkSum((Object[][])lArray);
    }

    public static int iMeth1(int n) {
        int n2 = -12;
        int n3 = 2;
        int n4 = -137;
        int n5 = 27;
        int n6 = 8;
        int n7 = 1;
        int n8 = 59447;
        double d = -1.18361;
        double[] dArray = new double[400];
        float f = -2.967f;
        int n9 = -8378;
        long[] lArray = new long[400];
        FuzzerUtils.init(dArray, 2.124942);
        FuzzerUtils.init(lArray, 3202827185623507262L);
        n2 = 1;
        while (++n2 < 132) {
            Test.vMeth(n, n2, instanceCount);
        }
        int n10 = (n >>> 1) % 400;
        dArray[n10] = dArray[n10] - (double)n;
        instanceCount += instanceCount;
        for (n3 = 176; n3 > 7; --n3) {
            double d2 = 0.53432;
            d2 *= (double)n3;
            lArray[n3 - 1] = n3;
        }
        d += (double)n4;
        n4 += n2;
        for (n5 = 258; n5 > 13; --n5) {
            for (n7 = 1; n7 < 7; ++n7) {
                f += (float)(n7 * n8 + n9 - n5);
                int n11 = n7 - 1;
                iArrFld[n11] = iArrFld[n11] + n9;
            }
            n4 = (int)((long)n4 + ((long)n5 ^ instanceCount));
            f += (float)instanceCount;
        }
        long l = (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)Float.floatToIntBits(f) + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public int iMeth(int n, int n2) {
        int n3 = -50211;
        int n4 = -1;
        int n5 = 13705;
        int n6 = 35010;
        int n7 = 0;
        n3 = 362;
        while (--n3 > 0) {
            block9: for (n4 = 1; n4 < 5; ++n4) {
                switch ((n5 >>> 1) % 6 + 13) {
                    case 13: {
                        int n8 = n3 - 1;
                        iArrFld[n8] = iArrFld[n8] - Test.iMeth1(n4);
                        int n9 = n3 - 1;
                        lArrFld[n9] = lArrFld[n9] >> (int)instanceCount;
                        n5 = (int)((long)n5 + ((long)(n4 * n4) + instanceCount - instanceCount));
                        for (n6 = 1; n6 < 2; ++n6) {
                            n7 ^= n7;
                            instanceCount += (long)(-67 + n6 * n6);
                            Test.iArrFld[n6 + 1] = n4;
                            n += n6;
                            n2 += n3;
                        }
                        continue block9;
                    }
                    case 14: {
                        n += 60;
                        continue block9;
                    }
                    case 15: {
                        n7 >>= n4;
                    }
                    case 16: {
                        instanceCount += 253L;
                        continue block9;
                    }
                    case 17: {
                        int n10 = n3 - 1;
                        this.dArrFld[n10] = this.dArrFld[n10] + (double)n2;
                        continue block9;
                    }
                    case 18: {
                        instanceCount = n5;
                    }
                }
            }
        }
        long l = n + n2 + n3 + n4 + n5 + n6 + n7;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 251;
        int n2 = -10916;
        int n3 = -1;
        int n4 = -113;
        int n5 = -40603;
        int n6 = 59160;
        int n7 = 123;
        int n8 = -118;
        int n9 = 35168;
        int[] nArray = new int[400];
        double d = 0.57251;
        int n10 = -52;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(nArray, -63);
        FuzzerUtils.init(blArray, true);
        for (n = 7; n < 341; ++n) {
            instanceCount += (long)(n * n);
            n2 += n - n2;
            int[] nArray2 = FuzzerUtils.int1array(400, -29189);
            nArray = nArray2;
            nArray = nArray2;
            nArray = nArray2;
            nArray = nArray2;
            for (n3 = n; n3 < 75; n3 += 2) {
                n2 = this.iMeth(n, n4);
                n4 /= n2 | 1;
                d += 4.0;
                fFld += (float)n3;
                int n11 = n;
                iArrFld[n11] = iArrFld[n11] - n3;
            }
        }
        n5 = 1;
        do {
            blArray[n5] = bFld;
            instanceCount = n3;
            n2 += n2;
            fFld = (float)d;
            sFld = (short)instanceCount;
            n10 = (byte)(n10 - (byte)instanceCount);
        } while (++n5 < 325);
        for (n6 = 3; 122 > n6; ++n6) {
            fFld += (float)n6 * fFld + (float)n4 - (float)n4;
            n2 = n4;
            fFld = n4;
            n2 = n6;
            n4 = n7;
            for (n8 = n6; n8 < 211; ++n8) {
                Test.iArrFld[n6] = n7;
                n9 = (int)((float)n9 + ((float)(n8 * n8 + n6) - fFld));
                int n12 = n6 + 1;
                iArrFld[n12] = iArrFld[n12] - n4;
                instanceCount = n9;
                instanceCount -= instanceCount;
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 d3 i24 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("by i25 i26 = " + n10 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i27 i28 iArr = " + n8 + "," + n9 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.sFld Test.iArrFld Test.fArrFld = " + sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.lArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -22462);
        FuzzerUtils.init(fArrFld, 0.5f);
        FuzzerUtils.init(lArrFld, -26182552L);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

