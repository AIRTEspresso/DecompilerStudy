/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -6003932471390524530L;
    public static volatile int iFld = 24387;
    public short sFld = (short)30223;
    public static double[] dArrFld = new double[400];
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth1_check_sum;

    /*
     * Unable to fully structure code
     */
    public static int iMeth1(int var0, int var1_1, long var2_2) {
        var4_3 = -56.808f;
        var5_4 = 113.39f;
        var6_5 = 0.302f;
        var7_6 = new float[400];
        var8_7 = -10;
        var9_8 = -1;
        var10_9 = -12116;
        var11_10 = 26741;
        var12_11 = 232;
        var13_12 = 6;
        var14_13 = new int[400][400];
        var15_14 = 0.5746;
        var17_15 = true;
        var18_16 = -114;
        var19_17 = -10182;
        var20_18 = new short[400][400];
        var21_19 = new long[400];
        FuzzerUtils.init(var14_13, -22);
        FuzzerUtils.init(var7_6, 0.294f);
        FuzzerUtils.init(var21_19, -2105289493L);
        FuzzerUtils.init(var20_18, (short)8806);
        var1_1 *= var0;
        var4_3 = 1.0f;
        do {
            Test.instanceCount |= (long)var0;
            var8_7 = 1;
            block78: do {
                switch (var8_7 * 5 + 51) {
                    case 101: {
                        for (var9_8 = 1; var9_8 < 1; ++var9_8) {
                            var1_1 -= var0;
                            var15_14 -= (double)var2_2;
                        }
                        continue block78;
                    }
                    case 68: {
                        if (!var17_15) break;
                        var10_9 += var8_7 ^ var0;
                        var11_10 = 1;
                        while (--var11_10 > 0) {
                            v0 = var14_13[(int)var4_3];
                            v1 = var11_10;
                            v0[v1] = v0[v1] >> var0;
                            var0 = var11_10;
                            var7_6[var8_7] = 89.0f;
                            v2 = (int)var4_3;
                            var21_19[v2] = var21_19[v2] - (long)var1_1;
                        }
                        continue block78;
                    }
                    case 267: {
                        var0 -= 60;
                    }
                    case 133: {
                        var20_18[var8_7] = var20_18[(int)(var4_3 - 1.0f)];
                    }
                    case 138: {
                        var1_1 += var8_7;
                    }
                    case 199: {
                        var14_13[var8_7][(int)var4_3] = 2;
                    }
                    case 151: {
                        try {
                            var10_9 = var9_8 / var1_1;
                            var12_11 = var10_9 / var0;
                            var10_9 = var11_10 % -172;
                        }
                        catch (ArithmeticException var22_21) {
                            // empty catch block
                        }
                    }
                    case 78: {
                        v3 = var8_7;
                        var21_19[v3] = var21_19[v3] | (long)var8_7;
                        break;
                    }
                    case 154: {
                        var12_11 = 2;
                        break;
                    }
                    case 215: {
                        v4 = var14_13[(int)var4_3];
                        v5 = var8_7;
                        v4[v5] = v4[v5] ^ (int)var2_2;
                    }
                    ** case 325:
lbl77:
                    // 2 sources

                    case 195: {
                        v6 = (int)(var4_3 + 1.0f);
                        var21_19[v6] = var21_19[v6] * (long)var0;
                        break;
                    }
                    case 99: {
                        var5_4 += 2.0f;
                        break;
                    }
                    case 334: {
                        Test.instanceCount += (long)(14 + var8_7 * var8_7);
                        break;
                    }
                    case 97: {
                        var18_16 = (byte)(var18_16 >> (byte)var8_7);
                        break;
                    }
                    case 376: {
                        var1_1 = (int)var2_2;
                        break;
                    }
                    case 390: {
                        var10_9 = -160;
                    }
                    case 315: {
                        var1_1 &= var11_10;
                        break;
                    }
                    case 167: {
                        v7 = (int)(var4_3 - 1.0f);
                        var21_19[v7] = var21_19[v7] + (long)var4_3;
                        break;
                    }
                    case 157: {
                        var10_9 += var8_7;
                        break;
                    }
                    case 302: {
                        v8 = var14_13[var8_7 - 1];
                        v9 = (int)(var4_3 - 1.0f);
                        v8[v9] = v8[v9] - (int)Test.instanceCount;
                        break;
                    }
                    case 108: {
                        try {
                            var0 = 1636636196 / var14_13[var8_7 + 1][(int)var4_3];
                            var1_1 = var14_13[(int)(var4_3 + 1.0f)][(int)var4_3] % 1374888923;
                            var10_9 = var1_1 / var0;
                        }
                        catch (ArithmeticException var22_22) {
                            // empty catch block
                        }
                    }
                    case 165: {
                        var10_9 += var8_7;
                    }
                    case 185: {
                        Test.instanceCount <<= var9_8;
                        break;
                    }
                    case 382: 
                    case 399: {
                        var10_9 += var8_7 * var8_7;
                    }
                    case 202: {
                        var15_14 -= (double)var5_4;
                        break;
                    }
                    case 207: {
                        Test.instanceCount -= (long)var13_12;
                        break;
                    }
                    case 196: {
                        Test.instanceCount *= Test.instanceCount;
                    }
                    case 72: {
                        var13_12 -= (int)var2_2;
                        break;
                    }
                    case 216: {
                        v10 = var14_13[(int)(var4_3 - 1.0f)];
                        v11 = var8_7 + 1;
                        v10[v11] = v10[v11] * var8_7;
                    }
                    case 247: 
                    case 321: {
                        var5_4 += (float)Test.instanceCount;
                    }
                    case 270: {
                        var5_4 = 18.0f;
                    }
                    case 342: {
                        if (var12_11 == 0) break;
                        break;
                    }
                    case 53: {
                        if (var17_15) continue block78;
                    }
                    case 150: {
                        var1_1 = (int)Test.instanceCount;
                        break;
                    }
                    case 210: {
                        try {
                            var13_12 = var10_9 / var0;
                            var14_13[var8_7][(int)var4_3] = var12_11 % -197;
                            var14_13[var8_7 - 1][(int)var4_3] = 85 % var12_11;
                        }
                        catch (ArithmeticException var22_23) {
                            // empty catch block
                        }
                    }
                    case 251: {
                        var13_12 = var10_9;
                        break;
                    }
                    case 213: {
                        var1_1 += var10_9;
                    }
                    case 380: {
                        var1_1 = var19_17;
                        break;
                    }
                    case 328: {
                        try {
                            var0 = 198 / var12_11;
                            var10_9 = 48840 % var9_8;
                            var1_1 = var11_10 / var14_13[(int)var4_3][var8_7 + 1];
                        }
                        catch (ArithmeticException var22_24) {
                            // empty catch block
                        }
                    }
                    case 305: {
                        var1_1 += var10_9;
                        break;
                    }
                    case 80: {
                        var14_13[var8_7 + 1][var8_7 + 1] = 118;
                        break;
                    }
                    case 175: 
                    case 341: {
                        var14_13[(var9_8 >>> 1) % 400] = var14_13[var8_7 - 1];
                        break;
                    }
                    case 356: {
                        var1_1 += var8_7 * var8_7;
                        break;
                    }
                    case 272: {
                        var2_2 += (long)(var8_7 - var1_1);
                    }
                    case 330: {
                        var12_11 -= (int)Test.instanceCount;
                    }
                    case 308: {
                        var0 += var8_7;
                        break;
                    }
                    case 198: {
                        var12_11 += var8_7 * var8_7;
                        break;
                    }
                    case 332: {
                        Test.instanceCount += (long)(var8_7 * var13_12) + Test.instanceCount - var2_2;
                        break;
                    }
                    case 279: {
                        var10_9 ^= var0;
                    }
                    case 155: {
                        var21_19[var8_7 + 1] = 68L;
                        break;
                    }
                    case 378: {
                        Test.dArrFld[(int)var4_3] = var8_7;
                    }
                    case 194: {
                        var5_4 += 18.0f;
                        break;
                    }
                    case 283: {
                        var12_11 *= var9_8;
                        break;
                    }
                    case 246: {
                        var2_2 -= (long)var9_8;
                        break;
                    }
                    case 205: {
                        var10_9 <<= var8_7;
                    }
                    case 94: {
                        Test.dArrFld[(int)(var4_3 - 1.0f)] = var13_12;
                        break;
                    }
                    case 81: {
                        var13_12 += var8_7;
                        break;
                    }
                    case 316: {
                        v12 = var14_13[var8_7 - 1];
                        v13 = (int)(var4_3 + 1.0f);
                        v12[v13] = v12[v13] * var1_1;
                        break;
                    }
                    case 74: {
                        var12_11 = var11_10;
                    }
                    case 62: {
                        var13_12 += var8_7 ^ var13_12;
                        break;
                    }
                    case 374: {
                        var6_5 += (float)var8_7;
                        break;
                    }
                    case 379: {
                        Test.instanceCount += (long)var4_3;
                        break;
                    }
                    case 121: {
                        var2_2 -= (long)Test.iFld;
                        break;
                    }
                    case 263: {
                        var12_11 = (int)((long)var12_11 + ((long)var8_7 | (long)var5_4));
                        break;
                    }
                    case 59: {
                        var5_4 = var13_12;
                        break;
                    }
                    case 340: {
                        var13_12 += -63626 + var8_7 * var8_7;
                    }
                }
            } while (++var8_7 < 7);
        } while ((var4_3 += 1.0f) < 215.0f);
        var22_25 = (long)(var0 + var1_1) + var2_2 + (long)Float.floatToIntBits(var4_3) + (long)var8_7 + (long)var9_8 + (long)var10_9 + Double.doubleToLongBits(var15_14) + (long)var11_10 + (long)(var17_15 != false ? 1 : 0) + (long)var12_11 + (long)Float.floatToIntBits(var5_4) + (long)var18_16 + (long)var13_12 + (long)var19_17 + (long)Float.floatToIntBits(var6_5) + FuzzerUtils.checkSum(var14_13) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7_6)) + FuzzerUtils.checkSum(var21_19) + FuzzerUtils.checkSum(var20_18);
        Test.iMeth1_check_sum += var22_25;
        return (int)var22_25;
    }

    public static void vMeth(float f) {
        int n = 202;
        int n2 = -39;
        int n3 = 36255;
        n &= 0xF3E;
        for (n2 = 5; 129 > n2; ++n2) {
            n += n2 * n2;
            n = (int)((long)Test.iMeth1(n3, iFld, instanceCount) - instanceCount);
            n += iFld;
            iArrFld = FuzzerUtils.int1array(400, -17150);
            f += f;
        }
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3);
    }

    public static int iMeth() {
        int n = -111;
        int n2 = 45735;
        int n3 = 12;
        int n4 = 63689;
        int n5 = -24749;
        int n6 = -201;
        int n7 = -11;
        int n8 = -4;
        float f = 109.885f;
        double d = -6.56664;
        boolean bl = false;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -467464507L);
        for (n = 10; n < 314; ++n) {
            Test.vMeth(f);
            for (n3 = 1; n3 < 5; ++n3) {
                int n9 = 18;
                n4 += -49100 + n3 * n3;
                iFld -= n3;
                instanceCount >>= (iFld += n3);
                n9 = (byte)(n9 + (byte)(n3 + n));
            }
            for (n5 = 1; n5 < 5; ++n5) {
                if (n4 != 0) {
                    // empty if block
                }
                for (n7 = 2; n7 > 1; --n7) {
                    iFld += n7;
                    long[] lArray2 = lArray[n5];
                    int n10 = n5;
                    lArray2[n10] = lArray2[n10] - (long)d;
                    n6 = (int)instanceCount;
                    if (!bl) continue;
                }
            }
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6 + n7 + n8) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -130;
        int n2 = -26;
        int n3 = -9;
        int n4 = 143;
        int n5 = 245;
        int n6 = 222;
        int n7 = 8128;
        int n8 = 108;
        float f = -1.847f;
        float[] fArray = new float[400];
        boolean bl = true;
        FuzzerUtils.init(fArray, 58.1f);
        block17: for (n = 6; n < 274; ++n) {
            switch (n % 3 * 5 + 34) {
                case 40: {
                    for (n3 = 4; n3 < 94; ++n3) {
                        n2 += Test.iMeth();
                        Test.lArrFld[n + 1] = n8;
                        f -= 5.0f;
                        n5 = 1;
                        block19: do {
                            switch ((n6 >>> 1) % 10 + 116) {
                                case 116: {
                                    this.sFld = (short)(this.sFld * (short)n3);
                                    int n9 = n - 1;
                                    fArray[n9] = fArray[n9] - (float)(instanceCount += (long)n5);
                                    f *= (float)n;
                                }
                                case 117: {
                                    break;
                                }
                                case 118: 
                                case 119: {
                                    this.sFld = (short)(this.sFld + (short)(n5 + n2));
                                    instanceCount -= (long)n8;
                                    break;
                                }
                                case 120: {
                                    n6 -= (int)instanceCount;
                                    iFld = n4;
                                    try {
                                        Test.iArrFld[n5] = n6 % n6;
                                        n2 = n / -77;
                                        n6 = iArrFld[n5 - 1] % 27708;
                                    }
                                    catch (ArithmeticException arithmeticException) {}
                                    continue block19;
                                }
                                case 121: {
                                    instanceCount -= (long)n8;
                                    n7 += n5 * iFld + n5 - n;
                                    if (bl) {
                                        n7 += n7;
                                    } else if (bl) {
                                        iFld &= n3;
                                        Test.iArrFld[n] = n;
                                    }
                                    iFld -= (int)f;
                                }
                                case 122: {
                                    n2 *= -211;
                                    n6 += n6;
                                    n4 = (int)instanceCount;
                                    break;
                                }
                                case 123: {
                                    f += (float)n;
                                    int n10 = n3 + 1;
                                    lArrFld[n10] = lArrFld[n10] * -16444L;
                                    break;
                                }
                                case 124: {
                                    if (!bl) continue block19;
                                    break;
                                }
                                case 125: {
                                    n6 -= 54;
                                    break;
                                }
                                default: {
                                    int n11 = n5;
                                    iArrFld[n11] = iArrFld[n11] + n;
                                }
                            }
                        } while (++n5 < 2);
                    }
                    continue block17;
                }
                case 36: {
                    f = n5;
                    continue block17;
                }
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 by2 f5 = " + n4 + "," + n8 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i23 i24 i25 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("b2 fArr1 = " + (bl ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
        FuzzerUtils.out.println("Test.dArrFld Test.iArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 0.82587);
        FuzzerUtils.init(iArrFld, -144);
        FuzzerUtils.init(lArrFld, -4183428435L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

