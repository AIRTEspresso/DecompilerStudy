/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 14L;
    public int iFld = -11;
    public byte byFld = (byte)66;
    public static long lFld = 3769337865L;
    public short sFld = (short)-7028;
    public static int iFld1 = 205;
    public volatile double dFld = 63.66422;
    public int[] iArrFld = new int[400];
    public static int[] iArrFld1 = new int[400];
    public volatile short[] sArrFld = new short[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        int n4 = -12;
        int n5 = 45190;
        int n6 = 173;
        int n7 = -12999;
        int n8 = 156;
        int n9 = 29112;
        boolean bl = false;
        n3 >>= n;
        n4 = 1;
        do {
            lFld -= -7L;
            for (n5 = 5; n5 > 1; --n5) {
                n += n5;
                for (n7 = 1; n7 < 2; ++n7) {
                    n6 = (int)((long)n6 + ((long)n7 - lFld));
                    n6 = n2;
                    try {
                        n = iArrFld1[n4 + 1] / -1066630903;
                        n8 = 355998573 % n5;
                        n8 = n4 / 6628;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    int n10 = n5 + 1;
                    iArrFld1[n10] = iArrFld1[n10] - 1353235880;
                    instanceCount <<= -1;
                    if (bl) {
                        instanceCount += (long)n8;
                        instanceCount -= (long)n8;
                        continue;
                    }
                    n9 = bl ? (int)((short)(n9 << (short)n6)) : (int)((short)(n9 >> (short)n3));
                }
            }
        } while (++n4 < 320);
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + (bl ? 1 : 0));
    }

    public int iMeth(long l) {
        int n = -29;
        int n2 = 10;
        int n3 = -14416;
        int n4 = -5;
        int n5 = 216;
        int n6 = 211;
        double d = -81.62522;
        float f = 107.349f;
        int n7 = (this.iFld >>> 1) % 400;
        this.iArrFld[n7] = this.iArrFld[n7] | this.byFld - this.iArrFld[(this.iFld >>> 1) % 400];
        Test.vMeth1(this.iFld, this.iFld, this.iFld);
        for (n = 10; n < 227; ++n) {
            instanceCount = 3L;
            this.iArrFld[n + 1] = n2;
            for (n3 = n; n3 < 7; ++n3) {
                n5 = 1;
                while (++n5 < 1) {
                    switch (n5 % 9 * 5 + 14) {
                        case 48: {
                            l = n;
                            n4 = -112;
                            d = 2.0;
                            break;
                        }
                        case 45: {
                            f += (float)((long)(n5 * this.sFld + n6) - l);
                            break;
                        }
                        case 24: {
                            this.byFld = (byte)(this.byFld + (byte)(n5 + n2));
                            f = n4 += this.iFld;
                            break;
                        }
                        case 47: {
                            d = n4;
                            break;
                        }
                        case 39: {
                            f = n3;
                            break;
                        }
                        case 40: {
                            if (n == 0) break;
                            break;
                        }
                        case 49: {
                            this.iFld >>= n6;
                        }
                        case 35: {
                            l -= -2L;
                        }
                        case 37: {
                            instanceCount += (long)(n5 * iFld1 + n5 - n);
                        }
                    }
                }
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6;
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void vMeth(long l, long l2) {
        int n = -33822;
        int n2 = -6;
        int n3 = 58993;
        int n4 = 8;
        int n5 = 215;
        int n6 = 108;
        int[] nArray = new int[400];
        double d = 66.828;
        float f = 0.37f;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -9);
        FuzzerUtils.init(lArray, -9170342097933258973L);
        n = 1;
        do {
            if (bl) {
                n2 = 1;
                do {
                    for (n3 = 1; n3 < 1; ++n3) {
                        n4 += n4;
                    }
                    for (n5 = 1; n5 < 1; ++n5) {
                        switch (n % 1 + 27) {
                            default: 
                        }
                        try {
                            n6 = n / 6714;
                            nArray[n + 1] = -1128238398 / n;
                            n6 = n % 792512917;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                        nArray[n] = (int)((double)(lArray[n2 + 1] - (long)n2) - (double)(179 * this.iMeth(l)) * d);
                        n6 = 6;
                        iFld1 = -197;
                        switch ((this.iFld >>> 1) % 1 + 113) {
                            default: 
                        }
                        n4 = (int)((long)n4 + ((long)n5 | (long)f));
                    }
                    n4 = 63;
                    f = n4;
                } while (++n2 < 5);
                continue;
            }
            if (bl) {
                l2 = this.iFld;
                continue;
            }
            n4 += n;
        } while (++n < 313);
        vMeth_check_sum += l + l2 + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        float f = 3.172f;
        int n = -183;
        int n2 = -139;
        int n3 = 4;
        int n4 = -217;
        int n5 = -14;
        int n6 = 236;
        int n7 = 20515;
        boolean bl = true;
        long l = 25631L;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -121.117498);
        this.vMeth(instanceCount, -231L);
        f += (float)this.iFld;
        n = 1;
        do {
            iFld1 += this.sFld;
            this.iFld *= (int)this.dFld;
            n2 = 107;
            while (6 < n2) {
                this.iFld = (int)((long)this.iFld + ((long)n2 * instanceCount + (long)n3 - (long)n2));
                this.iFld -= n2;
                n4 = 1;
                if (2 > n4) {
                    instanceCount = n;
                }
                int n8 = n2 + 1;
                iArrFld1[n8] = iArrFld1[n8] << n3;
                int n9 = n2--;
                iArrFld1[n9] = iArrFld1[n9] * (int)f;
            }
            for (l = 107L; l > (long)n; l -= 2L) {
                iFld1 += (int)(l * (long)n6 + (long)n4 - (long)n5);
                lFld += l;
                n5 = n;
                int n10 = n + 1;
                this.iArrFld[n10] = this.iArrFld[n10] - n5;
                int n11 = (int)l;
                this.sArrFld[n11] = (short)(this.sArrFld[n11] * (short)l);
                instanceCount += 57L + l * l;
                iFld1 += (int)(l * (long)n + (long)n5 - (long)iFld1);
            }
            n5 *= this.sFld;
            n7 = 107;
            while (--n7 > 0) {
                this.iFld += n;
                Test.iArrFld1[n - 1] = this.sFld;
                this.dFld += -2.047484256E9;
                iFld1 += n7;
                int n12 = n;
                dArray[n12] = dArray[n12] + (double)n;
            }
        } while (++n < 235);
        FuzzerUtils.out.println("f2 i20 i21 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i22 i23 i24 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("b2 l3 i25 = " + (bl ? 1 : 0) + "," + l + "," + n6);
        FuzzerUtils.out.println("i26 dArr = " + n7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld byFld = " + instanceCount + "," + this.iFld + "," + this.byFld);
        FuzzerUtils.out.println("Test.lFld sFld Test.iFld1 = " + lFld + "," + this.sFld + "," + iFld1);
        FuzzerUtils.out.println("dFld iArrFld Test.iArrFld1 = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("sArrFld = " + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld1, 185);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

