/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -694741276L;
    public static long lFld = 0L;
    public static double dFld = -2.653;
    public static float fFld = -95.279f;
    public short sFld = (short)-16283;
    public static long[] lArrFld = new long[400];
    public int[][] iArrFld = new int[400][400];
    public float[] fArrFld = new float[400];
    public static long bMeth_check_sum;
    public static long fMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, int n2, int n3) {
        int n4 = -149;
        int n5 = 7;
        int n6 = 9;
        int n7 = 47618;
        int n8 = -214;
        int n9 = -26905;
        int n10 = -14341;
        int n11 = 9;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -18228);
        n -= n2;
        for (n4 = 7; n4 < 140; ++n4) {
            n6 = 1;
            while (++n6 < 12) {
                n3 += 14;
                n7 = 1;
                while (n7 < 1) {
                    int n12 = n7++;
                    nArray[n12] = nArray[n12] * n6;
                    n = n5;
                    lFld = 135L;
                }
            }
        }
        for (n9 = 16; n9 < 385; ++n9) {
            boolean bl = true;
            instanceCount = lFld;
            if (bl) {
                int n13 = n9;
                nArray[n13] = nArray[n13] + n7;
                continue;
            }
            if (bl) {
                n3 >>= n4;
                continue;
            }
            if (bl) {
                n5 += (int)(44073L + (long)(n9 * n9));
                continue;
            }
            try {
                n3 = n5 % nArray[n9];
                n11 = -52308 % n3;
                n10 /= nArray[n9];
                continue;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11) + FuzzerUtils.checkSum(nArray);
    }

    public static float fMeth() {
        float f = 32.17f;
        int n = 8;
        int n2 = -24951;
        int n3 = -5;
        int n4 = -110;
        int n5 = 4;
        int[] nArray = new int[400];
        boolean bl = false;
        double d = 0.94521;
        short[][][] sArray = new short[400][400][400];
        FuzzerUtils.init(nArray, -18037);
        FuzzerUtils.init((Object[][])sArray, (Object)-17943);
        f = lFld++;
        int n6 = n++;
        dFld = Short.reverseBytes((short)9910) - n;
        n = n6 * (int)dFld;
        Test.vMeth(n, n, -2923);
        int n7 = (n >>> 1) % 400;
        lArrFld[n7] = lArrFld[n7] << (int)instanceCount;
        lFld = n;
        for (n2 = 14; 313 > n2; ++n2) {
            n3 /= (int)((long)fFld | 1L);
            if (bl) break;
            for (d = (double)n2; d < 6.0; d += 1.0) {
                nArray[n2 + 1] = n4;
                n5 = 1;
                do {
                    f = -7.0f;
                    n4 += n4;
                    int n8 = n5;
                    nArray[n8] = nArray[n8] - n4;
                    short[] sArray2 = sArray[n5 + 1][n5 - 1];
                    int n9 = (int)(d + 1.0);
                    sArray2[n9] = (short)(sArray2[n9] * (short)fFld);
                } while (++n5 < 1);
            }
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + (bl ? 1 : 0)) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])sArray);
        fMeth_check_sum += l;
        return l;
    }

    public static boolean bMeth(float f) {
        boolean bl = true;
        int n = 60;
        int n2 = 0;
        int n3 = 11418;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -32364);
        bl = true;
        int n4 = (n >>> 1) % 400;
        lArrFld[n4] = lArrFld[n4] << (int)(-(instanceCount + lFld));
        for (n2 = 3; n2 < 146; ++n2) {
            nArray[n2] = (int)instanceCount;
            switch (n2 % 1 + 119) {
                case 119: {
                    instanceCount = (lFld << n3 << (int)((float)n3 + 0.82f)) - (long)(-(n + n3));
                }
            }
        }
        n = (int)((float)(151L + (long)(n2 - n3)) - (f + (float)n3) + (float)(--n3));
        n = (int)((float)(--instanceCount) + (-Test.fMeth() - 52843.0f));
        nArray[(n3 >>> 1) % 400] = n2;
        fFld *= -248.0f;
        long l = (long)(Float.floatToIntBits(f) + (bl ? 1 : 0) + n + n2 + n3) + FuzzerUtils.checkSum(nArray);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = -9;
        int n2 = 22319;
        int n3 = -34790;
        int n4 = -4;
        int n5 = -7;
        int n6 = -222;
        boolean bl = false;
        int n7 = -60;
        float f = -41.53f;
        for (n = 5; 298 > n && !(bl = Test.bMeth(fFld)); ++n) {
            lFld += (long)(n * n7 + n) - lFld;
            if (bl) break;
            fFld *= (float)n2;
            this.sFld = (short)n2;
            for (n3 = 5; n3 < 86; ++n3) {
                n4 += n3 ^ n3;
                for (n5 = 2; n5 > 1; --n5) {
                    instanceCount -= instanceCount;
                    try {
                        n2 = 26462 % n4;
                        this.iArrFld[n5 + 1][n5] = 15502 % n4;
                        n2 = -178 % this.iArrFld[n3][n - 1];
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    lFld += 50L;
                    this.iArrFld[(n6 >>> 1) % 400] = FuzzerUtils.int1array(400, 12);
                    int[] nArray = this.iArrFld[n + 1];
                    int n8 = n3;
                    nArray[n8] = nArray[n8] | n5;
                    n6 = n7;
                    if (bl) {
                        n4 = n3;
                        n2 += n5 ^ n4;
                    }
                    n4 = n6;
                    switch (n3 % 3 * 5 + 73) {
                        case 74: {
                            n2 = this.sFld;
                            int n9 = n5;
                            this.fArrFld[n9] = this.fArrFld[n9] + (float)n;
                            lFld += (long)n2;
                            break;
                        }
                        case 78: {
                            instanceCount += (long)(n5 * n3 + n3 - n6);
                            break;
                        }
                        case 75: {
                            n6 += n5;
                            f += (float)n7;
                        }
                    }
                    f *= (float)n4;
                }
                n2 += 107;
                n2 -= n3;
                dFld = lFld;
            }
        }
        FuzzerUtils.out.println("i i1 b = " + n + "," + n2 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("by i21 i22 = " + n7 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i23 i24 f2 = " + n5 + "," + n6 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.dFld = " + instanceCount + "," + lFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fFld sFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iArrFld fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 45L);
        bMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

