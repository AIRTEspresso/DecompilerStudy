/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -6544749673385377619L;
    public static double dFld = 1.3548;
    public static byte byFld = (byte)-67;
    public static float fFld = -67.281f;
    public static short sFld = (short)-20409;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1() {
        double d = 28.76195;
        double d2 = 2.79641;
        int n = -6771;
        int n2 = -15281;
        int n3 = 50483;
        int n4 = 10;
        int n5 = 11;
        int n6 = 15372;
        int n7 = -19966;
        float f = 0.176f;
        boolean bl = false;
        for (d = 3.0; d < 373.0; d += 1.0) {
            n7 = (short)(n7 << (short)n);
        }
        for (f = 6.0f; f < 236.0f; f += 1.0f) {
            for (d2 = (double)f; d2 < 7.0; d2 += 1.0) {
                n3 += (int)((double)0.851f + d2 * d2);
                instanceCount |= instanceCount;
                instanceCount -= instanceCount;
            }
            for (n4 = 7; 1 < n4; n4 -= 2) {
                n3 = -21637;
                n3 = (int)instanceCount;
                n6 = 1;
                while (++n6 < 3) {
                    if (n != 0) {
                        // empty if block
                    }
                    if (bl) continue;
                    fFld = -4.0f;
                }
            }
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n7 + (long)Float.floatToIntBits(f) + (long)n2 + Double.doubleToLongBits(d2) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static long lMeth(boolean bl, int n) {
        int n2 = 201;
        int n3 = 91;
        int n4 = -3952;
        int n5 = -8;
        int n6 = -541;
        for (n2 = 12; 284 > n2; n2 += 3) {
            block5: for (n4 = 1; n4 < 17; ++n4) {
                n >>>= --n3;
                n5 -= (int)instanceCount;
                switch (n4 % 2 * 5 + 102) {
                    case 111: {
                        n *= n5 - (-(n3 * n2) + iArrFld[n4]);
                        n -= Test.iMeth1();
                        continue block5;
                    }
                    case 104: {
                        n6 = 1;
                        while (++n6 < 2) {
                            n <<= byFld;
                            if (n6 != 0) {
                                // empty if block
                            }
                            fFld *= (float)n6;
                            n >>>= -164;
                            byFld = (byte)(byFld >> -6);
                        }
                        continue block5;
                    }
                }
            }
        }
        long l = (bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + n6;
        lMeth_check_sum += l;
        return l;
    }

    public static int iMeth() {
        int n = -10;
        int n2 = -13081;
        int n3 = 59614;
        int[] nArray = new int[400];
        float f = 2.246f;
        boolean bl = false;
        FuzzerUtils.init(nArray, -190);
        for (int n4 : nArray) {
            try {
                n4 /= n4;
                n4 %= n4;
                n4 = nArray[(n4 >>> 1) % 400] % n4;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            for (n = 1; n < 4; ++n) {
                n4 *= (int)(++instanceCount);
                n3 = 1;
                while ((n3 += 2) < 2) {
                    dFld -= (double)n3;
                    n2 = (int)((instanceCount *= (long)(n2 += n3 - n)) - (long)n3);
                    n4 = (int)(-((float)(n3 - -11) - (float)n * f));
                    byFld = (byte)(byFld * (byte)Test.lMeth(false, n3));
                    instanceCount *= instanceCount;
                    fFld = n4;
                    n4 += (int)instanceCount;
                }
            }
        }
        long l = (long)(n + n2 + n3 + Float.floatToIntBits(f) + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 177;
        int n2 = -148;
        int n3 = -28241;
        int n4 = 9;
        int n5 = 61;
        int n6 = -12;
        double d = 101.67855;
        double[] dArray = new double[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -121L);
        FuzzerUtils.init(dArray, -1.64031);
        instanceCount <<= (n -= Test.iMeth());
        sFld = (short)(sFld * (short)n);
        instanceCount *= (long)n;
        n += (int)instanceCount;
        n = sFld;
        byFld = (byte)(byFld + (byte)instanceCount);
        for (d = 2.0; d < 141.0; d += 1.0) {
            for (n3 = 9; n3 < 180; ++n3) {
                fFld = (float)dFld;
                n4 |= 0xE121;
                instanceCount = n3;
                n4 += n3 * n3;
                int n7 = (int)(d + 1.0);
                lArray[n7] = lArray[n7] >> byFld;
                n4 &= 0xFFFFFFF6;
                n4 += (int)(instanceCount *= -137L);
            }
            byFld = (byte)(byFld << (byte)n);
            n += 228;
            byFld = (byte)n4;
            instanceCount = 22244L;
            for (n5 = 2; 180 > n5; ++n5) {
                n4 %= (int)((long)dFld | 1L);
                n2 = sFld;
                fFld = n6;
            }
        }
        FuzzerUtils.out.println("i d2 i17 = " + n + "," + Double.doubleToLongBits(d) + "," + n2);
        FuzzerUtils.out.println("i18 i19 i20 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i21 lArr dArr = " + n6 + "," + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
        FuzzerUtils.out.println("Test.fFld Test.sFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + sFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -69);
        iMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

