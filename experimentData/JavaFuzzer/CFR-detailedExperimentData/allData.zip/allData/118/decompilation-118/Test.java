/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 21295L;
    public int iFld = -8;
    public static boolean bFld = true;
    public long[] lArrFld = new long[400];
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long bMeth_check_sum;

    public boolean bMeth() {
        float f = -94.316f;
        f *= f;
        long l = Float.floatToIntBits(f);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public void vMeth1() {
        boolean bl = true;
        int n = 10;
        int n2 = -234;
        int n3 = -46;
        int n4 = 14;
        int[] nArray = new int[400];
        double d = 0.127445;
        float f = 63.29f;
        FuzzerUtils.init(nArray, -189);
        bl = this.bMeth();
        for (n = 1; n < 247; ++n) {
            instanceCount = n2;
            block13: for (n3 = 1; n3 < 7; ++n3) {
                int n5 = n3 + 1;
                this.lArrFld[n5] = this.lArrFld[n5] - (long)n2;
                nArray[(n >>> 1) % 400] = n;
                d = 1.0;
                block14: while (true) {
                    double d2;
                    d += 1.0;
                    if (!(d2 < 2.0)) continue block13;
                    switch ((int)(d % 10.0 * 5.0 + 24.0)) {
                        case 32: {
                            n4 += n3;
                            n4 = n;
                            instanceCount = n;
                            f = -205.0f;
                            continue block14;
                        }
                        case 59: {
                            int n6 = n3;
                            nArray[n6] = nArray[n6] + 6;
                            n4 = n2;
                            continue block14;
                        }
                        case 35: {
                            n2 += (int)(d * d);
                            continue block14;
                        }
                        case 72: {
                            n4 = (int)instanceCount;
                            continue block14;
                        }
                        case 43: {
                            if (!bl) continue block14;
                            continue block14;
                        }
                        case 26: {
                            continue block14;
                        }
                        case 69: {
                            continue block14;
                        }
                        case 58: {
                            n4 *= (int)instanceCount;
                            continue block14;
                        }
                        case 62: {
                            n2 -= n;
                            continue block14;
                        }
                        case 65: {
                            n4 = (int)instanceCount;
                            continue block14;
                        }
                    }
                    instanceCount *= (long)d;
                }
            }
        }
        vMeth1_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
    }

    public void vMeth(int n, int n2) {
        int n3 = 33724;
        int n4 = -1406;
        int n5 = 48;
        int n6 = 7;
        int n7 = -21450;
        int n8 = 213;
        int[] nArray = new int[400];
        double d = 2.82964;
        int n9 = -92;
        int n10 = 32613;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, 3);
        FuzzerUtils.init(fArray, 2.564f);
        nArray[(n2 >>> 1) % 400] = n;
        block15: for (n3 = 10; n3 < 215; ++n3) {
            int n11 = n3;
            int n12 = n3;
            int n13 = nArray[n12] + 1;
            nArray[n12] = n13;
            this.lArrFld[n11] = this.lArrFld[n11] - (long)(fArray[47] + (float)n13);
            this.vMeth1();
            instanceCount += (long)n3;
            switch (n3 % 10 + 45) {
                case 45: {
                    block16: for (n5 = n3; n5 < 8; ++n5) {
                        d %= (double)(n4 | 1);
                        for (n7 = 1; 1 > n7; ++n7) {
                            float f = 0.801f;
                            f -= (float)instanceCount;
                            instanceCount = n4;
                        }
                        switch ((n6 >>> 1) % 1 * 5 + 58) {
                            case 60: {
                                this.lArrFld[n3] = -82L;
                                n += n5;
                                n8 &= n9;
                                continue block16;
                            }
                            default: {
                                n6 = n2;
                            }
                        }
                    }
                    continue block15;
                }
                case 46: {
                    n6 += n3 * n10;
                }
                case 47: {
                    n4 += 61659;
                }
                case 48: {
                    n6 &= (int)instanceCount;
                    continue block15;
                }
                case 49: {
                    n4 += n3 ^ this.iFld;
                    continue block15;
                }
                case 50: {
                    nArray[n3] = n4;
                    continue block15;
                }
                case 51: {
                    int n14 = n3 + 1;
                    nArray[n14] = nArray[n14] - -11099;
                }
                case 52: {
                    instanceCount = this.iFld;
                    continue block15;
                }
                case 53: {
                    n += n3;
                    continue block15;
                }
                case 54: {
                    n6 += n4;
                    continue block15;
                }
                default: {
                    nArray[n3] = n2;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + (long)n8 + (long)n9 + (long)n10 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void mainTest(String[] stringArray) {
        int n = -43100;
        int n2 = 6;
        int n3 = 10;
        int n4 = 44982;
        float f = -103.643f;
        float f2 = -88.139f;
        int n5 = -20050;
        this.vMeth(-36, -33116);
        block13: for (n = 21; n < 397; ++n) {
            try {
                n2 = this.iFld / 117;
                this.iFld %= n2;
                n2 = n / this.iFld;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            switch (n % 10 * 5 + 30) {
                case 67: {
                    for (n3 = 1; n3 < 67; ++n3) {
                        f += -55.0f;
                        this.lArrFld[n3 - 1] = n;
                        Test.iArrFld[n3] = 5;
                        if (bFld) {
                            int n6 = n - 1;
                            this.lArrFld[n6] = this.lArrFld[n6] * instanceCount;
                            n4 += 1604715977;
                        } else {
                            n2 *= 2;
                            n2 += n3 * n4 + this.iFld - n3;
                            f2 = 1.0f;
                            while (true) {
                                float f3;
                                f2 += 1.0f;
                                if (!(f3 < 2.0f)) break;
                                n2 += (int)(f2 * (float)instanceCount);
                                f = 5.0f;
                                instanceCount += (long)(f2 * (float)this.iFld + (float)n5 - (float)instanceCount);
                                n4 >>= -25805;
                                n4 = (int)((float)n4 + (48198.0f + f2 * f2));
                                f += f2 + (float)n4;
                                n4 -= n3;
                            }
                        }
                        n2 -= this.iFld;
                        n2 *= (int)(instanceCount += (long)n3);
                        if (bFld) break;
                    }
                    int n7 = n - 1;
                    iArrFld[n7] = iArrFld[n7] - -63;
                }
                case 51: {
                    this.iFld = (int)((long)this.iFld + ((long)n + instanceCount));
                }
                case 62: 
                case 76: {
                    instanceCount = this.iFld;
                    instanceCount += (long)(n * n) + instanceCount - (long)n;
                    continue block13;
                }
                case 39: {
                    this.iFld >>>= -83;
                }
                case 52: {
                    n2 += (int)instanceCount;
                    continue block13;
                }
                case 73: {
                    int n8 = n;
                    iArrFld[n8] = iArrFld[n8] >> n3;
                    continue block13;
                }
                case 34: {
                    int n9 = n - 1;
                    iArrFld[n9] = iArrFld[n9] >>> 1;
                    continue block13;
                }
                case 68: {
                    n4 += n5;
                    continue block13;
                }
                case 65: {
                    instanceCount = n;
                    continue block13;
                }
                default: {
                    instanceCount = -90L;
                }
            }
        }
        FuzzerUtils.out.println("i12 i13 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i15 f3 f4 = " + n4 + "," + Float.floatToIntBits(f) + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("s1 = " + n5);
        FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 8);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        bMeth_check_sum = 0L;
    }
}

