/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 1705898175L;
    public int iFld = -8304;
    public static byte byFld = (byte)-69;
    public static short sFld = (short)-18477;
    public static double[] dArrFld = new double[400];
    public static volatile boolean[] bArrFld = new boolean[400];
    public static int[] iArrFld = new int[400];
    public static volatile float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        vMeth1_check_sum += (long)(--n);
    }

    public static long lMeth(boolean bl, float f) {
        int n = -44614;
        int n2 = 106;
        int n3 = 76;
        int n4 = 0;
        int n5 = 59910;
        int n6 = -183;
        int n7 = -5;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -132);
        for (n = 1; 196 > n; ++n) {
            Test.vMeth1(n3);
            for (n4 = 1; n4 < 8; ++n4) {
                n2 = n3;
                int n8 = n + 1;
                nArray[n8] = nArray[n8] >> n3;
                n2 += n4;
                if (n3 != 0) {
                    // empty if block
                }
                for (n6 = 1; n6 < 2; ++n6) {
                    int n9 = n;
                    dArrFld[n9] = dArrFld[n9] / (double)(instanceCount | 1L);
                    try {
                        n2 = n4 / nArray[n6 - 1];
                        n3 = nArray[n4] / n5;
                        nArray[n6] = 23 / n4;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    bArrFld = FuzzerUtils.boolean1array(400, true);
                    int n10 = n - 1;
                    nArray[n10] = nArray[n10] & n2;
                    instanceCount -= (long)f;
                }
                int n11 = n + 1;
                nArray[n11] = nArray[n11] << (int)instanceCount;
            }
        }
        long l = (long)((bl ? 1 : 0) + Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth() {
        double d = -47.18541;
        double d2 = -77.11773;
        double d3 = 108.110919;
        boolean bl = true;
        float f = 46.42f;
        int n = -161;
        int n2 = 4;
        int n3 = 92;
        int n4 = 4;
        int n5 = -50265;
        int[][] nArray = new int[400][400];
        int n6 = 1643;
        FuzzerUtils.init(nArray, 7);
        d += (double)(Test.lMeth(bl, f) + (long)n);
        n /= n | 1;
        for (n2 = 271; n2 > 8; n2 -= 3) {
            n3 = n2;
            n3 *= (int)d;
            d -= (double)instanceCount;
            instanceCount = byFld;
            for (d2 = 1.0; d2 < 18.0; d2 += 1.0) {
                nArray[n2][(int)d2] = n3;
                for (d3 = (double)n2; 2.0 > d3; d3 += 1.0) {
                    n -= n4;
                    n6 = (short)d2;
                    Test.iArrFld[(int)d2] = 203;
                    byFld = (byte)(byFld + (byte)n3);
                }
            }
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)n + (long)n2 + (long)n3 + Double.doubleToLongBits(d2) + (long)n4 + Double.doubleToLongBits(d3) + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 19;
        int n2 = -101;
        int n3 = -124;
        int n4 = 15271;
        int n5 = -2;
        int n6 = 34445;
        int n7 = 11;
        int[] nArray = new int[400];
        float f = -25.873f;
        double d = -1.50751;
        double d2 = -118.124478;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 1);
        FuzzerUtils.init(lArray, 6194027090030472735L);
        n = 359;
        do {
            this.iFld = (int)((long)this.iFld + ((long)(n * n) + instanceCount - (long)n));
        } while ((n -= 3) > 0);
        int n8 = (n >>> 1) % 400;
        int n9 = nArray[n8] - (int)Math.abs((long)(f + (float)this.iFld));
        nArray[n8] = n9;
        this.iFld = n9;
        this.iFld += (int)((double)this.iFld - -(d - (double)instanceCount));
        nArray[20] = -this.iFld;
        for (d2 = 1.0; d2 < 323.0; d2 += 1.0) {
            Test.vMeth();
            block25: for (n3 = 1; n3 < 78; ++n3) {
                int n10 = (int)(d2 + 1.0);
                fArrFld[n10] = fArrFld[n10] + (float)n3;
                n5 = 1;
                do {
                    if (bl) continue;
                    d = -62758.0;
                    f += (float)(n5 * n5);
                    switch ((int)(d2 % 1.0 + 13.0)) {
                        case 13: {
                            instanceCount = 21976L;
                            n4 -= n2;
                            Test.iArrFld[n3 - 1] = (int)instanceCount;
                            this.iFld += n5;
                            break;
                        }
                    }
                    instanceCount += (long)(n5 ^ n4);
                } while (++n5 < 2);
                switch ((n2 >>> 1) % 3 * 5 + 47) {
                    case 50: {
                        block27: for (n6 = 1; n6 < 2; ++n6) {
                            switch ((n5 >>> 1) % 8 + 64) {
                                case 64: {
                                    instanceCount += (long)n6;
                                    switch (78) {
                                        case 75: {
                                            sFld = (short)(sFld << (short)n6);
                                            Test.iArrFld[n3] = n;
                                            n7 += n6 * n6;
                                            try {
                                                n2 = 2036700165 / n4;
                                                n4 = n2 / nArray[n3];
                                                n4 = n3 % -36330;
                                            }
                                            catch (ArithmeticException arithmeticException) {}
                                            break;
                                        }
                                        case 81: {
                                            try {
                                                this.iFld = n3 % iArrFld[n6];
                                                n7 = n4 / n3;
                                                n2 = 209 / n2;
                                            }
                                            catch (ArithmeticException arithmeticException) {}
                                            break;
                                        }
                                        default: {
                                            this.iFld += (int)(-117.773f + (float)(n6 * n6));
                                        }
                                    }
                                }
                                case 65: 
                                case 66: {
                                    n2 -= sFld;
                                    continue block27;
                                }
                                case 67: {
                                    f += (float)((long)n6 + instanceCount);
                                    continue block27;
                                }
                                case 68: {
                                    f += (float)n6 - f;
                                }
                                case 69: 
                                case 70: {
                                    n4 -= (int)d2;
                                    continue block27;
                                }
                                case 71: {
                                    lArray[n3 - 1] = -55L;
                                }
                            }
                        }
                        continue block25;
                    }
                    case 52: {
                        n2 += n;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i f d = " + n + "," + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("d1 i1 i15 = " + Double.doubleToLongBits(d2) + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i16 i17 b2 = " + n4 + "," + n5 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i18 i19 iArr = " + n6 + "," + n7 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.byFld = " + instanceCount + "," + this.iFld + "," + byFld);
        FuzzerUtils.out.println("Test.sFld Test.dArrFld Test.bArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
        FuzzerUtils.out.println("Test.iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 93.81697);
        FuzzerUtils.init(bArrFld, true);
        FuzzerUtils.init(iArrFld, -2);
        FuzzerUtils.init(fArrFld, -2.892f);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

