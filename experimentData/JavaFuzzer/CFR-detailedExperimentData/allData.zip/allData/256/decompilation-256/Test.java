/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -65247L;
    public static float fFld = 2.786f;
    public static int iFld = -5903;
    public static boolean bFld = true;
    public static long[][] lArrFld = new long[400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2() {
        int n = -10;
        int n2 = -90;
        int n3 = 194;
        int n4 = -1;
        int n5 = 95;
        int n6 = -48907;
        int[] nArray = new int[400];
        int n7 = -1192;
        double d = 28.6854;
        FuzzerUtils.init(nArray, -65265);
        block5: for (n = 3; n < 203; ++n) {
            instanceCount += (long)(0.904f + (float)(n * n));
            switch (n % 3 * 5 + 110) {
                case 113: {
                    continue block5;
                }
                case 116: {
                    for (n3 = 1; n3 < 8; ++n3) {
                        n2 = n4;
                        long[] lArray = lArrFld[n];
                        int n8 = n3;
                        lArray[n8] = lArray[n8] + (long)n4;
                        for (n5 = n3; n5 < 2; ++n5) {
                            n7 = (short)(n7 + (short)n5);
                            nArray = FuzzerUtils.int1array(400, 98);
                            d += d;
                            instanceCount = n2;
                            n4 = (int)instanceCount;
                        }
                        fFld = n;
                    }
                    continue block5;
                }
                case 124: {
                    instanceCount += (long)n7;
                }
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n) {
        int n2 = 194;
        int n3 = -20667;
        int n4 = 11;
        int n5 = 0;
        int n6 = -40355;
        int[] nArray = new int[400];
        float f = 99.47f;
        float f2 = 2.74f;
        int n7 = -81;
        FuzzerUtils.init(nArray, 30014);
        Test.vMeth2();
        n |= n;
        for (n2 = 12; n2 < 248; ++n2) {
            for (f = 1.0f; f < 7.0f; f += 1.0f) {
                for (f2 = f; f2 < 2.0f; f2 += 1.0f) {
                    fFld = 10.0f;
                    n6 >>= n3;
                    n5 ^= 0xED;
                    n3 += (int)((long)f2 ^ (long)n7);
                    n5 = iFld;
                }
                if (bFld) {
                    int n8 = n2 + 1;
                    nArray[n8] = nArray[n8] + (int)f;
                    n6 += n3;
                    instanceCount += (long)f;
                    continue;
                }
                n6 += (int)instanceCount;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + Float.floatToIntBits(f2) + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth() {
        Test.vMeth1(iFld);
        vMeth_check_sum += 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = 151;
        int n2 = -52938;
        int n3 = -9;
        int n4 = -5;
        int n5 = 195;
        int n6 = -199;
        int[] nArray = new int[400];
        int n7 = 7;
        int n8 = 18581;
        double d = -2.32484;
        FuzzerUtils.init(nArray, -53132);
        for (n = 13; 387 > n; ++n) {
            Test.vMeth();
        }
        n7 = (byte)n8;
        n7 = (byte)(n7 * (byte)fFld);
        n8 = 4726;
        iFld += n;
        n3 = 127;
        while (--n3 > 0) {
            iFld >>= (int)instanceCount;
            if (bFld) break;
            n2 = (int)((long)n2 + ((long)n3 * instanceCount + instanceCount - (long)n3));
            for (n4 = 197; 11 < n4; --n4) {
                n2 = (int)instanceCount;
                instanceCount = n4;
                n5 += n3;
                for (d = 2.0; d > 1.0; d -= 3.0) {
                    nArray[n3] = 12;
                    n2 += (int)(d * d);
                    n6 = -9;
                    if (bFld) {
                        n5 += (int)(instanceCount += (long)n7);
                        n2 >>= n;
                        n6 = (int)((double)n6 + (14.0 + d * d));
                    } else if (bFld) {
                        n6 = 91;
                        nArray[n4 + 1] = n2;
                        n5 <<= n4;
                    }
                    n5 = (int)((double)n5 + (202.0 + d * d));
                    iFld += (int)(204.0 + d * d);
                    n7 = (byte)(n7 % (byte)(n8 | 1));
                }
            }
        }
        FuzzerUtils.out.println("i i1 by1 = " + n + "," + n2 + "," + n7);
        FuzzerUtils.out.println("s1 i14 i15 = " + n8 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i16 d1 i17 = " + n5 + "," + Double.doubleToLongBits(d) + "," + n6);
        FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
        FuzzerUtils.out.println("Test.bFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 7796706057543378775L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

