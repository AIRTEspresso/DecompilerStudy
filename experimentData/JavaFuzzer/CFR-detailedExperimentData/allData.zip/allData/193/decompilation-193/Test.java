/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 3L;
    public static boolean bFld = false;
    public static double dFld = -30.90614;
    public static short sFld = (short)7699;
    public static byte byFld = (byte)41;
    public static int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(int n) {
        int n2 = 1;
        int n3 = 1313;
        int n4 = -9;
        int n5 = 5;
        int n6 = -44109;
        float f = -91.337f;
        if (bFld) {
            n2 = 1;
            while (++n2 < 308) {
                instanceCount += 89L;
            }
            n >>= (int)instanceCount;
        } else if (bFld) {
            n -= 12;
            for (n3 = 5; n3 < 291; ++n3) {
                Test.iArrFld[n3] = n;
                n = n2;
                f = n;
            }
            int n7 = ((n <<= (int)instanceCount) >>> 1) % 400;
            fArrFld[n7] = fArrFld[n7] + -238.0f;
        } else {
            for (n5 = 11; n5 < 239; ++n5) {
                instanceCount += -404788774760728131L + (long)(n5 * n5);
                instanceCount += (long)n6;
                if (bFld) break;
            }
        }
        long l = n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6;
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth1(float f) {
        int n = -126;
        int n2 = 1;
        int n3 = 20141;
        int n4 = 11810;
        int n5 = 63351;
        int n6 = -7;
        int n7 = -6;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 2L);
        for (n = 2; n < 254; ++n) {
            n2 += n;
            Test.lMeth(n2 *= (int)(--instanceCount));
            n2 += n;
        }
        n2 *= 14;
        for (n3 = 20; n3 < 386; ++n3) {
            n5 = 1;
            block14: while (++n5 < 5) {
                Test.iArrFld[n5] = n;
                int n8 = n3 + 1;
                fArrFld[n8] = fArrFld[n8] - (float)n5;
                switch (n5 % 10 * 5 + 100) {
                    case 150: {
                        n6 = 1;
                        do {
                            n2 += n6 + n6;
                            dFld = f;
                        } while (++n6 < 1);
                        continue block14;
                    }
                    case 128: {
                        n2 = sFld;
                        continue block14;
                    }
                    case 120: {
                        n4 += 96 + n5 * n5;
                        continue block14;
                    }
                    case 130: {
                        n2 -= n6;
                    }
                    case 113: {
                        n2 -= n7;
                    }
                    case 138: {
                        n2 >>= (int)instanceCount;
                        continue block14;
                    }
                    case 107: {
                        continue block14;
                    }
                    case 121: {
                        lArray[n5 + 1] = n;
                        continue block14;
                    }
                    case 104: {
                        Test.iArrFld[n5] = n7;
                        continue block14;
                    }
                    case 119: {
                        int n9 = n3 + 1;
                        iArrFld[n9] = iArrFld[n9] + -104;
                        continue block14;
                    }
                }
                n4 = -2;
            }
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n) {
        int n2 = 150;
        int n3 = 12314;
        int n4 = -42;
        int n5 = -29446;
        int n6 = -10;
        int n7 = 8;
        int n8 = 220;
        int n9 = -7;
        int n10 = -77;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, true);
        for (n2 = 8; n2 < 227; ++n2) {
            for (n4 = 1; n4 < 7; ++n4) {
                float f = -126.363f;
                Test.vMeth1(f);
                n5 -= (int)instanceCount;
            }
            int n11 = n2 + 1;
            iArrFld[n11] = iArrFld[n11] * n;
            for (n6 = n2; n6 < 7; ++n6) {
                Test.iArrFld[n2 + 1] = n5;
                Test.iArrFld[n6 + 1] = n7;
                n5 = -11;
                int n12 = n6 + 1;
                iArrFld[n12] = iArrFld[n12] + (int)instanceCount;
                for (n8 = 1; n8 < 1; ++n8) {
                    blArray[378] = bFld;
                    n7 >>= n2;
                    n7 = n10;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10) + FuzzerUtils.checkSum(blArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 10761;
        int n2 = 3;
        int n3 = 8168;
        int n4 = -3;
        int n5 = 10;
        int n6 = 203;
        int n7 = 7;
        int n8 = 112;
        int n9 = 59433;
        int n10 = -60872;
        float f = -1.493f;
        Test.vMeth(n);
        for (n2 = 8; n2 < 346; ++n2) {
            n *= 14;
            if (bFld) break;
            Test.iArrFld[n2 - 1] = (int)instanceCount;
            for (n4 = 74; n4 > 4; --n4) {
                instanceCount *= 65280L;
                n3 -= n2;
                for (n6 = n4; n6 < 2; ++n6) {
                    instanceCount >>= n6;
                }
                block22: for (n8 = 2; n8 > 1; --n8) {
                    bFld = false;
                    dFld = n2;
                    dFld -= (double)n2;
                    switch (n8 % 8 + 37) {
                        case 37: {
                            n7 *= (int)instanceCount;
                            if (bFld) continue block22;
                            instanceCount = n8;
                            instanceCount &= 0x40CL;
                            continue block22;
                        }
                        case 38: {
                            n7 = n6;
                            n7 = 74;
                            continue block22;
                        }
                        case 39: {
                            n3 += 74 + n8 * n8;
                            n3 = n2;
                            switch ((n8 >>> 1) % 7 + 104) {
                                case 104: {
                                    Test.iArrFld[n8] = byFld;
                                    f = (float)dFld;
                                    continue block22;
                                }
                                case 105: {
                                    instanceCount += (long)n8;
                                    continue block22;
                                }
                                case 106: {
                                    instanceCount += (long)byFld;
                                    n10 += n8 * n8;
                                    continue block22;
                                }
                                case 107: {
                                    n9 = -8372;
                                }
                                case 108: {
                                    instanceCount &= (long)n10;
                                    continue block22;
                                }
                                case 109: {
                                    Test.iArrFld[n8] = 52327;
                                    continue block22;
                                }
                                case 110: {
                                    instanceCount += (long)dFld;
                                    continue block22;
                                }
                            }
                            n7 -= n4;
                            continue block22;
                        }
                        case 40: {
                            f = (float)dFld;
                            continue block22;
                        }
                        case 41: {
                            n -= (int)dFld;
                            continue block22;
                        }
                        case 42: {
                            int n11 = n2;
                            iArrFld[n11] = iArrFld[n11] - n2;
                            continue block22;
                        }
                        case 43: {
                            int n12 = n4 + 1;
                            iArrFld[n12] = iArrFld[n12] / (n2 | 1);
                        }
                        case 44: {
                            fArrFld = FuzzerUtils.float1array(400, -113.619f);
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 i27 i28 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i29 i30 i31 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("f3 i32 = " + Float.floatToIntBits(f) + "," + n10);
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.sFld Test.byFld Test.iArrFld = " + sFld + "," + byFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 47);
        FuzzerUtils.init(fArrFld, 0.836f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

