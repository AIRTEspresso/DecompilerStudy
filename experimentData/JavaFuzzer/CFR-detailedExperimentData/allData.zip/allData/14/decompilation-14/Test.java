/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 156L;
    public static float fFld = 19.722f;
    public double dFld = 1.58438;
    public static int[] iArrFld = new int[400];
    public static volatile long[] lArrFld = new long[400];
    public static float[] fArrFld = new float[400];
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(short s, int n) {
        boolean bl = false;
        boolean[][] blArray = new boolean[400][400];
        int n2 = -2;
        int n3 = -51889;
        int[] nArray = new int[400];
        float f = 124.502f;
        double d = 1.117647;
        int n4 = -90;
        FuzzerUtils.init(nArray, 128);
        FuzzerUtils.init(blArray, true);
        for (int n5 : nArray) {
            blArray[(n >>> 1) % 400][(n5 >>> 1) % 400] = bl;
            n5 ^= 0xFFFF36F4;
            if (bl) {
                if (bl) {
                    block5: for (n2 = 1; 4 > n2 && !bl; ++n2) {
                        f += (float)(n2 * n2);
                        switch (n2 % 2 + 116) {
                            case 116: {
                                instanceCount += (long)n3;
                                f -= (float)n3;
                                continue block5;
                            }
                            case 117: {
                                d *= (double)n;
                                n = -32266;
                                f *= 83.0f;
                                d *= (double)n;
                            }
                        }
                    }
                    continue;
                }
                n5 -= n4;
                continue;
            }
            if (!bl) continue;
            n3 = n2;
        }
        vMeth1_check_sum += (long)(s + n + (bl ? 1 : 0) + n2 + n3 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n4 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
    }

    public static void vMeth() {
        int n = -145;
        int n2 = 119;
        int n3 = 188;
        int n4 = 8;
        int n5 = -9114;
        int n6 = -6;
        int n7 = -37628;
        short s = -19244;
        short[] sArray = new short[400];
        boolean bl = false;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 89.208f);
        FuzzerUtils.init(sArray, (short)656);
        Test.vMeth1(s, 61579);
        for (n2 = 7; n2 < 138 && !bl; ++n2) {
            if (bl) {
                n3 *= n;
                for (n4 = 1; 12 > n4; ++n4) {
                    int n8 = n4 + 1;
                    fArray[n8] = fArray[n8] - (float)n;
                    Test.iArrFld[n4] = n2;
                    n5 += n4 | n4;
                    instanceCount = n4;
                    n3 >>= n3;
                }
                continue;
            }
            if (bl) {
                for (n6 = 1; 12 > n6; ++n6) {
                    int n9 = n2 - 1;
                    sArray[n9] = (short)(sArray[n9] * (short)n4);
                    n3 = (int)((long)n3 + ((long)n6 | instanceCount));
                }
                vMeth_check_sum += (long)(n + s + n2 + n3 + (bl ? 1 : 0) + n4 + n5 + n6 + n7) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(sArray);
                return;
            }
            if (bl) break;
        }
        vMeth_check_sum += (long)(n + s + n2 + n3 + (bl ? 1 : 0) + n4 + n5 + n6 + n7) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(sArray);
    }

    public static boolean bMeth(int n, float f, short s) {
        int n2 = -114;
        int n3 = 103;
        int n4 = -50;
        int n5 = 36447;
        int n6 = -40149;
        int n7 = -140;
        boolean bl = false;
        Test.vMeth();
        int n8 = (n >>> 1) % 400;
        iArrFld[n8] = iArrFld[n8] >> (int)instanceCount;
        instanceCount = n;
        Test.iArrFld[(n >>> 1) % 400] = n;
        for (n2 = 12; n2 < 292; ++n2) {
            n3 = -5;
            Test.lArrFld[n2] = n3;
            n3 -= (int)instanceCount;
        }
        int n9 = (n >>> 1) % 400;
        fArrFld[n9] = fArrFld[n9] + 0.994f;
        for (n4 = 14; n4 < 312; ++n4) {
            instanceCount <<= n4;
        }
        int n10 = (n >>> 1) % 400;
        iArrFld[n10] = iArrFld[n10] + n2;
        for (n6 = 6; 380 > n6; n6 += 2) {
        }
        long l = n + Float.floatToIntBits(f) + s + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = 5;
        int n2 = 13;
        int n3 = -197;
        int n4 = 211;
        int n5 = -212;
        int n6 = -58016;
        int n7 = 18242;
        for (n = 9; 222 > n; ++n) {
            for (n3 = 5; n3 < 118; n3 += 2) {
                if (!Test.bMeth(n3, fFld, (short)n7)) continue;
            }
            n4 += n - n4;
            n2 += (int)fFld;
        }
        fFld += (float)n3;
        for (n5 = 18; n5 < 291; ++n5) {
            switch ((n3 >>> 1) % 1 + 97) {
                case 97: {
                    n2 += n;
                }
            }
            Test.lArrFld[n5 + 1] = n2;
            n2 ^= n4;
        }
        n4 = n7;
        n6 = -108;
        this.dFld *= (double)n3;
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 s3 i22 = " + (n4 -= n5) + "," + n7 + "," + n5);
        FuzzerUtils.out.println("i23 = " + n6);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld Test.fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -182);
        FuzzerUtils.init(lArrFld, -6087713711903524745L);
        FuzzerUtils.init(fArrFld, -4.232f);
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

