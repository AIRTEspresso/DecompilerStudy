/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -7198668973938529287L;
    public static volatile int iFld = -229;
    public short sFld = (short)-31446;
    public static int iFld1 = 10;
    public static volatile float[] fArrFld = new float[400];
    public static long vSmallMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vSmallMeth(long l, int n) {
        float f = -59.425f;
        iFld = (int)((long)iFld % (l | 1L));
        f = ++iFld;
        vSmallMeth_check_sum += l + (long)n + (long)Float.floatToIntBits(f);
    }

    public static void vMeth(int n, int n2) {
        float f = 2.806f;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 1.41799);
        Test.vSmallMeth(instanceCount, -1);
        int n3 = (n2 >>> 1) % 400;
        dArray[n3] = dArray[n3] + (double)f;
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static long lMeth(int n) {
        int n2 = -24;
        int n3 = -214;
        int n4 = -26449;
        int n5 = -238;
        int n6 = -1257;
        int n7 = 61902;
        int[] nArray = new int[400];
        float f = 0.785f;
        int n8 = -4;
        long l = 1243554974L;
        FuzzerUtils.init(nArray, -8);
        Test.vMeth(iFld, n);
        instanceCount += instanceCount;
        block4: for (n2 = 21; n2 < 349; ++n2) {
            iFld = n3;
            iFld |= (int)instanceCount;
            f -= f;
            for (n4 = n2; 5 > n4; ++n4) {
                instanceCount += (long)(n4 ^ n3);
                iFld = 123;
            }
            int n9 = n2;
            nArray[n9] = nArray[n9] - n8;
            switch (n2 % 2 * 5 + 100) {
                case 108: {
                    for (n6 = n2; n6 < 5; ++n6) {
                        Test.fArrFld[n2 - 1] = n6;
                        n3 = n7;
                        n5 += n6 * n6;
                    }
                    continue block4;
                }
                case 104: {
                    iFld = (int)l;
                    continue block4;
                }
                default: {
                    f += (float)n3;
                }
            }
        }
        long l2 = (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n8 + n6 + n7) + l + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 162;
        int n2 = -195;
        int n3 = -2;
        int n4 = 0;
        int n5 = 54892;
        int n6 = 2;
        int n7 = 225;
        int n8 = 14;
        int n9 = -48978;
        int n10 = 25990;
        int n11 = -189;
        int n12 = 1;
        float f = -1.923f;
        boolean bl = true;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)108);
        iFld <<= -11 + iFld;
        for (n = 340; n > 19; --n) {
            for (int i = 0; i < 62; ++i) {
                this.sFld = (short)(this.sFld - 1);
                Test.vSmallMeth((long)((float)this.sFld + (-1.0f + ((float)n - f)) - (float)instanceCount), (int)((Math.sqrt(-37.78289) + (double)(n2 ^ n)) * (double)((long)Math.min(n2, iFld) * (8L * (long)(--n2)))));
            }
            n2 = (int)(Test.lMeth(iFld) + instanceCount);
            if (bl) break;
            byArray[n] = (byte)f;
            n3 = 1;
            while (++n3 < 78) {
                n2 = (int)((long)n2 + ((long)n3 ^ instanceCount));
                iFld += n3 * n3;
            }
            n4 = 78;
            do {
                iFld = n3;
                n2 = n4--;
                f = iFld;
            } while (n4 > 0);
            n2 += iFld;
        }
        if (bl) {
            n5 = 1;
            while ((n5 += 3) < 186) {
                for (n6 = 1; n6 < n5; ++n6) {
                    iFld >>>= n4;
                    n2 = 47891;
                    instanceCount *= (long)f;
                    iFld = n8;
                    instanceCount = 27202L;
                    for (n9 = 1; n9 < 2; ++n9) {
                        n2 -= n8;
                        instanceCount += (long)n10;
                        iFld1 += n9 + n10;
                    }
                }
            }
            iFld1 >>= 10;
        } else if (bl) {
            for (n11 = 8; n11 < 160; ++n11) {
                instanceCount = (long)f;
            }
            iFld1 *= n4;
        } else {
            bl = false;
        }
        FuzzerUtils.out.println("i i1 f1 = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("b i12 i13 = " + (bl ? 1 : 0) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i14 i15 i16 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i17 i18 i19 = " + n8 + "," + n9 + "," + n10);
        FuzzerUtils.out.println("i20 i21 byArr = " + n11 + "," + n12 + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
        FuzzerUtils.out.println("Test.iFld1 Test.fArrFld = " + iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 0.479f);
        vSmallMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

