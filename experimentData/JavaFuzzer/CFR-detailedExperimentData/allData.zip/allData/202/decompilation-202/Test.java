/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2413526288303012764L;
    public static volatile short[] sArrFld = new short[400];
    public static long iMeth_check_sum;
    public static long sMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(float f, long l, long l2) {
        int n = 32561;
        int n2 = -34456;
        int n3 = -5;
        int n4 = 10;
        int n5 = -7;
        int n6 = 1;
        int n7 = 34833;
        int n8 = -59;
        int[] nArray = new int[400];
        double d = 2.110089;
        double d2 = 21.102981;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, -64);
        FuzzerUtils.init(fArray, 1.897f);
        for (n = 21; n < 351; ++n) {
            n2 <<= (int)l;
            n3 = 1;
            while (++n3 < 5) {
                n2 += n3 * n3;
                int n9 = n3;
                nArray[n9] = nArray[n9] + -1;
                l += (long)n3;
            }
        }
        for (d = 9.0; d < 289.0; d += 1.0) {
            n2 = n;
            l = n2;
            d2 = l2;
            for (n5 = 1; 6 > n5; ++n5) {
                fArray[(int)(d + 1.0)] = n4;
                n7 = 2;
                while ((double)n7 > d) {
                    l2 *= 1983042612573643745L;
                    --n7;
                }
                f += 0.668f;
            }
        }
        vMeth_check_sum += (long)Float.floatToIntBits(f) + l + l2 + (long)n + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + Double.doubleToLongBits(d2) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static short sMeth(float f, float f2, int n) {
        double d = -1.44768;
        int n2 = 4;
        int n3 = 55611;
        int n4 = 23807;
        int n5 = -21662;
        int n6 = -44272;
        int[] nArray = new int[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 13L);
        FuzzerUtils.init(nArray, 38707);
        d = 75.0;
        Test.vMeth(f, instanceCount, instanceCount);
        n -= 25;
        n = (int)d;
        for (n2 = 4; n2 < 235; ++n2) {
            for (n4 = n2; n4 < 7; ++n4) {
                n6 -= 36;
            }
            n3 += n2 + n6;
            n6 = -20321;
            nArray[n2 - 1] = (int)instanceCount;
            d = 138.0;
            n3 |= n;
            n3 = (int)instanceCount;
            int n7 = n2 - 1;
            lArray[n7] = lArray[n7] - (long)n;
        }
        long l = (long)(Float.floatToIntBits(f) + Float.floatToIntBits(f2) + n) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        sMeth_check_sum += l;
        return (short)l;
    }

    public static int iMeth(long l) {
        double d = -2.58044;
        int n = 36;
        int n2 = 2;
        int n3 = -60753;
        int n4 = -109;
        int n5 = -31278;
        int[] nArray = new int[400];
        int n6 = 1334;
        float f = -11.79f;
        FuzzerUtils.init(nArray, 6);
        for (d = 7.0; 248.0 > d; d += 3.0) {
            Test.sArrFld[(int)(d + 1.0)] = (short)l++;
        }
        n <<= (int)(-((long)n - (instanceCount - (long)n)));
        n6 = (short)(n - sArrFld[(n >>> 1) % 400] * Test.sMeth(f, f, n));
        n -= n;
        n += n;
        for (n2 = 14; n2 < 350; ++n2) {
            n3 += n2;
            n3 += n2 * n2;
            n6 = (short)(n6 << -6);
            for (n4 = 5; n4 > 1; --n4) {
                n5 = n2;
                n3 -= n4;
            }
            instanceCount += (long)(n2 * n2);
        }
        nArray[119] = nArray[119] >> n6;
        long l2 = l + Double.doubleToLongBits(d) + (long)n + (long)n6 + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -46445;
        int n2 = -9;
        int n3 = -504;
        int n4 = -4;
        int n5 = -22060;
        int[][][] nArray = new int[400][400][400];
        float f = 1.269f;
        int n6 = 8144;
        short[][][] sArray = new short[400][400][400];
        double d = 1.25554;
        double d2 = -114.77433;
        double[][] dArray = new double[400][400];
        long[] lArray = new long[400];
        FuzzerUtils.init((Object[][])nArray, (Object)-4);
        FuzzerUtils.init(lArray, 1L);
        FuzzerUtils.init((Object[][])sArray, (Object)-5904);
        FuzzerUtils.init(dArray, 2.125263);
        for (n = 2; n < 247; ++n) {
            n3 = 1;
            while (++n3 < 103) {
                f += (float)Test.iMeth(instanceCount);
                n2 = n6;
                n2 += n2;
                instanceCount += (long)(n3 * n3);
                d += (double)n3;
                d2 = 1.0;
                block25: do {
                    instanceCount >>>= n3;
                    switch (n % 6 + 3) {
                        case 3: {
                            try {
                                nArray[n3][n3 - 1][(n2 >>> 1) % 400] = n % n3;
                                n2 = 1509 / n2;
                                nArray[(int)(d2 + 1.0)][n3][n] = nArray[n3][n3][(int)d2] / nArray[(int)d2][(int)(d2 + 1.0)][n + 1];
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n2 = n;
                            n2 *= n6;
                        }
                        case 4: {
                            int n7 = n3;
                            lArray[n7] = lArray[n7] << n2;
                        }
                        case 5: {
                            n2 *= (int)d2;
                            n2 += n;
                            int[] nArray2 = nArray[(int)(d2 - 1.0)][(int)d2];
                            int n8 = (int)d2;
                            nArray2[n8] = nArray2[n8] + -30008;
                            break;
                        }
                        case 6: {
                            nArray[n3 - 1][(int)(d2 + 1.0)] = nArray[(n >>> 1) % 400][n + 1];
                            block9 : switch ((int)(d2 % 8.0 * 5.0 + 63.0)) {
                                case 71: {
                                    d += (double)instanceCount;
                                    break;
                                }
                                case 98: {
                                    n2 >>= n6;
                                    switch ((int)(d2 % 1.0 * 5.0 + 1.0)) {
                                        case 2: {
                                            n2 <<= n3;
                                            n2 -= n2;
                                            n2 += (int)(f *= (float)n3);
                                            break block9;
                                        }
                                    }
                                    n2 -= n6;
                                    break;
                                }
                                case 103: {
                                    double[] dArray2 = dArray[n + 1];
                                    int n9 = n - 1;
                                    dArray2[n9] = dArray2[n9] * (double)n;
                                }
                                case 96: {
                                    instanceCount = 45127L;
                                    break;
                                }
                                case 75: {
                                    n2 -= (int)instanceCount;
                                    break;
                                }
                                case 89: {
                                    n4 += (int)(d2 * (double)instanceCount + (double)n2 - (double)instanceCount);
                                    break;
                                }
                                case 94: {
                                    instanceCount += (long)d2;
                                }
                                case 92: {
                                    nArray[n][(int)d2] = nArray[(int)d2][(int)(d2 + 1.0)];
                                }
                            }
                            continue block25;
                        }
                        case 7: {
                            instanceCount = -46915L;
                            break;
                        }
                        case 8: {
                            f *= (float)n5;
                            break;
                        }
                        default: {
                            f -= f;
                        }
                    }
                } while ((d2 += 1.0) < 1.0);
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f s1 d4 = " + Float.floatToIntBits(f) + "," + n6 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("d5 i22 i23 = " + Double.doubleToLongBits(d2) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("iArr3 lArr1 sArr = " + FuzzerUtils.checkSum((Object[][])nArray) + "," + FuzzerUtils.checkSum(lArray) + "," + FuzzerUtils.checkSum((Object[][])sArray));
        FuzzerUtils.out.println("dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.sArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)9289);
        iMeth_check_sum = 0L;
        sMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

