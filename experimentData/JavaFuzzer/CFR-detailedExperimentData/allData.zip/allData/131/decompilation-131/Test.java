/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 7L;
    public byte byFld = (byte)-123;
    public static volatile int iFld = 7957;
    public static volatile double dFld = -65.26047;
    public static volatile float fFld = 0.954f;
    public static boolean bFld = true;
    public static short sFld = (short)-12381;
    public static double[] dArrFld = new double[400];
    public static int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(int n, long l, int n2) {
        int n3 = 0;
        int n4 = -46;
        int n5 = 231;
        int n6 = 31316;
        int n7 = 6;
        int n8 = 31185;
        int n9 = -11;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -4L);
        for (n3 = 2; n3 < 355; n3 += 3) {
            l -= -12L;
        }
        n5 = 1;
        while (++n5 < 333) {
            for (n6 = 5; n6 > 1; --n6) {
                n = n4;
                n2 = n4;
                n7 *= n5;
                int n10 = n5;
                dArrFld[n10] = dArrFld[n10] - (double)iFld;
                int n11 = n5 + 1;
                iArrFld[n11] = iArrFld[n11] * (int)l;
                lArray[n5 - 1] = (long)dFld;
            }
            if (bl) continue;
            int n12 = n5 - 1;
            iArrFld[n12] = iArrFld[n12] - n2;
            for (n8 = 1; n8 < 5; ++n8) {
                n7 ^= (int)(instanceCount += (long)n9);
            }
        }
        long l2 = (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)(bl ? 1 : 0) + (long)n8 + (long)n9 + FuzzerUtils.checkSum(lArray);
        lMeth_check_sum += l2;
        return l2;
    }

    public static int iMeth(double d, long l, int n) {
        int n2 = 171;
        int n3 = -11;
        int n4 = -3294;
        int n5 = -6215;
        int n6 = 4;
        int n7 = -72;
        n2 = 1;
        while (++n2 < 341) {
            if (bFld) {
                Test.lMeth(n, instanceCount, iFld);
                int n8 = n2;
                iArrFld[n8] = iArrFld[n8] - (int)fFld;
            }
            for (n3 = 1; n3 < 5; ++n3) {
                for (n5 = n3; n5 < 2; ++n5) {
                    int n9 = n3 + 1;
                    iArrFld[n9] = iArrFld[n9] << n4;
                    n7 = (byte)(n7 + (byte)n6);
                    if (bFld) {
                        switch ((n >>> 1) % 2 + 118) {
                            case 118: {
                                iFld += (int)instanceCount;
                                fFld += (float)(n5 * n3);
                                break;
                            }
                            case 119: {
                                fFld = n6;
                                Test.fArrFld[n2 - 1] = (float)dFld;
                                iFld += n5;
                                break;
                            }
                            default: {
                                instanceCount = (long)d;
                                break;
                            }
                        }
                        continue;
                    }
                    d -= (double)n4;
                }
            }
        }
        long l2 = Double.doubleToLongBits(d) + l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7;
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth(int n, int n2, float f) {
        int n3 = -66;
        int n4 = 47371;
        int n5 = 12;
        int n6 = -36219;
        int n7 = -13950;
        int n8 = 32;
        double d = -34.9041;
        boolean[][][] blArray = new boolean[400][400][400];
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        int n9 = n3;
        n3 = (byte)(n3 - 1);
        n -= (int)(dArrFld[2] * (double)n9);
        n4 = 1;
        do {
            n3 = (byte)Test.iMeth(-1.90511, instanceCount, iFld);
            f += (float)((long)n4 ^ (long)n4);
        } while (++n4 < 228);
        iFld <<= n2;
        for (n5 = 14; n5 < 224; ++n5) {
            dFld += (double)iFld;
            instanceCount = -1L;
            d = 1.0;
            do {
                block9: for (n7 = 1; n7 < 1; ++n7) {
                    switch (n5 % 5 + 16) {
                        case 16: {
                            sFld = (short)fFld;
                            continue block9;
                        }
                        case 17: {
                            instanceCount = n5;
                            continue block9;
                        }
                        case 18: {
                            n = (int)instanceCount;
                            continue block9;
                        }
                        case 19: {
                            instanceCount -= -61L;
                            continue block9;
                        }
                        default: {
                            if (!bFld) continue block9;
                        }
                    }
                }
            } while ((d += 1.0) < 8.0);
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + (long)n8 + FuzzerUtils.checkSum((Object[][])blArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 241;
        int n2 = -17202;
        int n3 = -11;
        int n4 = -12903;
        int n5 = 7;
        int n6 = 198;
        int n7 = -8;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -2L);
        n = 1;
        block10: while (++n < 264) {
            this.byFld = (byte)(this.byFld - (byte)(19819 * n));
            switch (((int)(instanceCount - (long)n) >>> 1) % 9 + 54) {
                case 54: {
                    Test.vMeth(-39985, -172, fFld);
                    iFld += n;
                    continue block10;
                }
                case 55: {
                    instanceCount = this.byFld;
                    continue block10;
                }
                case 56: {
                    iFld <<= n;
                    for (n2 = 5; n2 < 95; n2 += 2) {
                        for (n4 = 1; 3 > n4; ++n4) {
                            n3 -= (int)fFld;
                            n3 += this.byFld;
                            dFld = n;
                            n5 = this.byFld;
                            n3 <<= n;
                            iFld += -95 + n4 * n4;
                            this.byFld = (byte)n2;
                        }
                        instanceCount = sFld;
                        for (n6 = 1; n6 < 3; ++n6) {
                            n3 >>= (int)instanceCount;
                            dFld = iFld;
                            n7 -= n4;
                            Test.iArrFld[n2 - 1] = (int)dFld;
                            int n8 = n + 1;
                            lArray[n8] = lArray[n8] + instanceCount;
                        }
                        n3 -= (n5 -= (int)instanceCount);
                        int n9 = n2;
                        iArrFld[n9] = iArrFld[n9] * n4;
                        Test.fArrFld[n - 1] = n2;
                    }
                    continue block10;
                }
                case 57: {
                    int n10 = n;
                    fArrFld[n10] = fArrFld[n10] * (float)this.byFld;
                    continue block10;
                }
                case 58: 
                case 59: {
                    fFld -= (float)n7;
                }
                case 60: {
                    n5 += n * n6;
                }
                case 61: {
                    iArrFld = FuzzerUtils.int1array(400, 10);
                    continue block10;
                }
                case 62: {
                    n5 -= (int)instanceCount;
                    continue block10;
                }
            }
            fFld -= (float)n5;
        }
        FuzzerUtils.out.println("i i23 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i25 i26 i27 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i28 lArr1 = " + n7 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount byFld Test.iFld = " + instanceCount + "," + this.byFld + "," + iFld);
        FuzzerUtils.out.println("Test.dFld Test.fFld Test.bFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld Test.dArrFld Test.iArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 2.93474);
        FuzzerUtils.init(iArrFld, 61183);
        FuzzerUtils.init(fArrFld, -127.946f);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

