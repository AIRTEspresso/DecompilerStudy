/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -5L;
    public static double dFld = 0.1188;
    public float fFld = -2.494f;
    public static short sFld = (short)-20974;
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1(int n, int n2, int n3) {
        int n4 = -27733;
        int n5 = 185;
        int n6 = -12;
        int n7 = -17978;
        int[] nArray = new int[400];
        float f = 2.226f;
        int n8 = 11360;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 28981L);
        FuzzerUtils.init(nArray, 3);
        for (n4 = 4; n4 < 388; ++n4) {
            lArray[n4 - 1] = -316845889L;
            f -= (float)instanceCount;
            n6 = 4;
            do {
                n3 += n6 * n6;
                n2 *= (int)dFld;
                f = n8;
                dFld += (double)n6;
                nArray[n4 + 1] = n6--;
                f = instanceCount;
            } while (n6 > 0);
            instanceCount += (long)(n4 + n3);
            n7 = 1;
            do {
                n3 += n6;
            } while (++n7 < 4);
        }
        instanceCount = n3;
        long l = (long)(n + (n2 *= (int)instanceCount) + n3 + n4 + n5 + Float.floatToIntBits(f) + n6 + n8 + n7) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth() {
        int n = 13996;
        int n2 = 1;
        int n3 = 8207;
        int n4 = 192;
        int n5 = 1;
        int[] nArray = new int[400];
        float f = 20.329f;
        float f2 = 116.944f;
        float[] fArray = new float[400];
        int n6 = 13;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(nArray, -56399);
        FuzzerUtils.init(lArray, -13L);
        FuzzerUtils.init(fArray, 1.1f);
        for (n = 5; n < 175; ++n) {
            block8: for (n3 = 1; n3 < 9; ++n3) {
                nArray = nArray;
                nArray = nArray;
                instanceCount = (long)(-((float)((long)n2 - instanceCount) + -220.0f * ((float)instanceCount + f)));
                long[] lArray2 = lArray[n3];
                int n7 = n3 - 1;
                long l = lArray2[n7];
                lArray2[n7] = l + 1L;
                instanceCount /= l | 1L;
                switch (n % 3 + 12) {
                    case 12: {
                        n2 = n4++;
                        nArray[n] = (n2 + n3 + Test.iMeth1(n, n, n2)) * n2;
                        for (f2 = 1.0f; f2 < 2.0f; f2 += 1.0f) {
                            n6 = (byte)(n6 + (byte)(f2 * f2));
                            n4 += (int)((long)f2 | (long)f);
                            n4 += (int)(f2 * (float)n2 + (float)n - (float)n2);
                            try {
                                n2 = n4 % 27714;
                                nArray[n3] = -63375 % n3;
                                n2 = n4 / n3;
                                continue;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                        }
                        n2 = (int)((float)n2 + ((float)(n3 * n4 + n2) - f));
                        continue block8;
                    }
                    case 13: {
                        long[] lArray3 = lArray[n3 + 1];
                        int n8 = n - 1;
                        lArray3[n8] = lArray3[n8] - (long)n2;
                        continue block8;
                    }
                    case 14: {
                        fArray[n] = instanceCount;
                        continue block8;
                    }
                    default: {
                        n5 = 86;
                    }
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + Float.floatToIntBits(f2) + n5 + n6) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, int n2) {
        int n3 = -18385;
        Test.iMeth();
        instanceCount = n;
        n3 = (short)(n3 / 1);
        vMeth_check_sum += (long)(n + n2 + n3);
    }

    public void mainTest(String[] stringArray) {
        int n = 19;
        int n2 = -1;
        int n3 = 14;
        int n4 = -2241;
        int n5 = 8654;
        int n6 = -8;
        int n7 = -28321;
        int n8 = -121;
        int n9 = 53858;
        int n10 = 8;
        int n11 = 2;
        int n12 = -37154;
        int[] nArray = new int[400];
        long[] lArray = new long[400];
        boolean[][][] blArray = new boolean[400][400][400];
        FuzzerUtils.init(lArray, 3L);
        FuzzerUtils.init(nArray, -52838);
        FuzzerUtils.init((Object[][])blArray, (Object)false);
        Test.vMeth(n, n);
        dFld += (double)n;
        for (n2 = 8; 197 > n2; ++n2) {
            lArray[n2] = 1L;
            try {
                nArray[n2 + 1] = n2 % 155;
                n3 = (n %= 1405380339) % n;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            for (n4 = n2; 133 > n4; ++n4) {
                n5 -= n3;
                for (n6 = n2; n6 < 1; ++n6) {
                    int n13 = n6;
                    fArrFld[n13] = fArrFld[n13] + (float)n;
                    blArray[n6][n4 + 1] = blArray[n2 - 1][n4];
                    this.fFld *= (float)n7;
                    this.fFld = n6;
                    n = n4;
                    dFld = n2;
                    sFld = (short)(sFld + (short)((long)(n6 * n7) + instanceCount - (long)n4));
                    instanceCount >>= n4;
                    this.fFld -= (float)n5;
                    lArray[n4] = -26L;
                }
                int n14 = n2 + 1;
                nArray[n14] = nArray[n14] >> (int)instanceCount;
            }
        }
        n3 >>= sFld;
        instanceCount = n;
        blArray[(n5 >>> 1) % 400][(n2 >>> 1) % 400][((n3 -= n) >>> 1) % 400] = false;
        for (n8 = 9; n8 < 385; ++n8) {
            n10 = 1;
            do {
                for (n11 = 1; n11 < 4; n11 += 2) {
                    instanceCount = (long)((float)instanceCount + ((float)(n11 * sFld + n4) - this.fFld));
                    int n15 = n10 + 1;
                    lArray[n15] = lArray[n15] + (long)n11;
                    n5 = 5;
                }
            } while ((n10 += 3) < 67);
        }
        FuzzerUtils.out.println("i14 i15 i16 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i17 i18 i19 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i20 i21 i22 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i23 i24 i25 = " + n10 + "," + n11 + "," + n12);
        FuzzerUtils.out.println("lArr2 iArr2 bArr = " + FuzzerUtils.checkSum(lArray) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum((Object[][])blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.sFld Test.fArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 1.94f);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

