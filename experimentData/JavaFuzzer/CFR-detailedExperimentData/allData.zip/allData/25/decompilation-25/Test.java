/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 4L;
    public static int iFld = 0;
    public static float fFld = 81.434f;
    public static boolean bFld = true;
    public double dFld = 0.7376;
    public static long[] lArrFld = new long[400];
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n, int n2) {
        long l = 67L;
        int n3 = -15342;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 142);
        for (l = 7L; 126L > l; ++l) {
            int n4 = (int)l;
            nArray[n4] = nArray[n4] + (int)instanceCount;
            instanceCount -= (long)iFld;
            n -= 10;
        }
        fFld += -44338.0f;
        long l2 = (long)(n + n2) + l + (long)n3 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth1(int n, int n2, long l) {
        int n3 = 9;
        int n4 = -10850;
        int n5 = 4;
        int n6 = -10;
        int n7 = 28227;
        int[] nArray = new int[400];
        float f = -122.496f;
        int n8 = -19766;
        double d = -1.123341;
        FuzzerUtils.init(nArray, -21);
        n3 = 5;
        while (n3 < 184) {
            for (f = 1.0f; f < 9.0f; f += 1.0f) {
                n8 = (short)(n8 + (short)(f * (float)n5 + (float)n8 - (float)n2));
                instanceCount = Test.iMeth(-12773, n5);
                d += -43119.0;
                for (n6 = 1; n6 < 2; ++n6) {
                    d = fFld;
                    l -= (long)n7;
                    iFld <<= (int)instanceCount;
                }
                int n9 = n3 + 1;
                nArray[n9] = nArray[n9] * n3;
                n4 += (int)(f * f);
            }
            int n10 = n3++;
            nArray[n10] = nArray[n10] << (int)l;
            n5 += 8231;
        }
        iFld = (int)instanceCount;
        vMeth1_check_sum += (long)(n + n2) + l + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n8 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
    }

    public void vMeth(double d) {
        int n = 14;
        int n2 = 8461;
        int n3 = 2;
        int n4 = 50;
        int n5 = 49255;
        int[] nArray = new int[400];
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        float f = 1.57f;
        int n6 = 13523;
        FuzzerUtils.init(nArray, 30278);
        FuzzerUtils.init(blArray, false);
        boolean bl2 = bl;
        blArray[(n >>> 1) % 400] = bl2;
        bl = bl2 ^ bl;
        if (bl) {
            n -= Math.abs(nArray[(n >>> 1) % 400]);
            instanceCount = Math.abs((int)(4564187144736978884L << (int)(-244L - ((long)n & instanceCount)) << n - -23071));
        } else {
            block11: for (n2 = 13; n2 < 274; ++n2) {
                f += (float)(n2 * n2);
                if (bl) {
                    switch (n2 % 9 + 13) {
                        case 13: {
                            for (n4 = 1; n4 < 6; ++n4) {
                                Test.vMeth1(n2, iFld, instanceCount);
                                n5 *= n3;
                                n5 -= n3;
                                instanceCount += (long)(n4 * n4);
                                if (iFld != 0) {
                                    vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)(bl ? 1 : 0) + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
                                    return;
                                }
                                instanceCount = n5 *= n4;
                            }
                            continue block11;
                        }
                        case 14: {
                            f = 1.476f;
                        }
                        case 15: {
                            if (!bFld) continue block11;
                            break;
                        }
                        case 16: {
                            n5 = n3;
                            break;
                        }
                        case 17: {
                            fFld = (float)d;
                        }
                        case 18: {
                            n6 = (short)n;
                            break;
                        }
                        case 19: {
                            instanceCount = 88L;
                            break;
                        }
                        case 20: {
                            instanceCount -= (long)n5;
                        }
                        case 21: {
                            n >>>= n4;
                            break;
                        }
                        default: {
                            instanceCount += (long)n2;
                            break;
                        }
                    }
                    continue;
                }
                n3 = n2;
            }
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)(bl ? 1 : 0) + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -54;
        float f = 105.953f;
        int n2 = 7;
        int n3 = 5;
        int n4 = -53709;
        int n5 = 47867;
        int n6 = -35;
        int n7 = -131;
        int n8 = -38442;
        int n9 = -96;
        int n10 = 11073;
        this.vMeth(this.dFld);
        instanceCount *= (long)(iFld += -584236848);
        int n11 = (iFld >>> 1) % 400;
        this.iArrFld[n11] = this.iArrFld[n11] >> n;
        this.iArrFld[(Test.iFld >>> 1) % 400] = iFld;
        fFld -= (float)iFld;
        instanceCount -= (long)n;
        for (f = 5.0f; 165.0f > f; f += 1.0f) {
            bFld = false;
        }
        n3 = 1;
        block21: do {
            switch (n3 % 9 * 5 + 24) {
                case 33: {
                    iFld += -5 + n3 * n3;
                    iFld = (int)instanceCount;
                    block22: for (n4 = 3; n4 < 103; ++n4) {
                        for (n6 = 1; n6 < 2; ++n6) {
                            this.iArrFld[n4 - 1] = n3;
                            iFld = n2;
                            n10 = (short)n6;
                        }
                        switch (n3 % 2 * 5 + 67) {
                            case 76: {
                                iFld -= -6;
                                for (n8 = n3; n8 < 2; n8 += 3) {
                                    n9 *= -81;
                                    this.dFld += -189.0;
                                    n5 += n8;
                                }
                                switch (n4 % 4 * 5 + 120) {
                                    case 124: {
                                        n2 = n5;
                                    }
                                    case 133: {
                                        iFld *= n5;
                                        n5 += n4 * n4;
                                        n7 = 159;
                                    }
                                    case 123: {
                                        n9 = 163;
                                    }
                                    case 140: {
                                        iFld = n4;
                                    }
                                }
                                continue block22;
                            }
                            case 71: {
                                n = (byte)(n << (byte)instanceCount);
                                continue block22;
                            }
                            default: {
                                this.iArrFld = FuzzerUtils.int1array(400, 17119);
                            }
                        }
                    }
                    continue block21;
                }
                case 66: {
                    instanceCount += -6L;
                }
                case 28: {
                    instanceCount = n3;
                    break;
                }
                case 54: {
                    iFld = n6;
                    break;
                }
                case 58: {
                    instanceCount += 188L + (long)(n3 * n3);
                    break;
                }
                case 44: 
                case 68: {
                    n9 += n3;
                    break;
                }
                case 52: {
                    n7 += n9;
                    break;
                }
                case 45: {
                    n2 = (int)((long)n2 + (long)n3 * instanceCount);
                }
                default: {
                    iFld = n7;
                }
            }
        } while (++n3 < 244);
        FuzzerUtils.out.println("by f2 i16 = " + n + "," + Float.floatToIntBits(f) + "," + n2);
        FuzzerUtils.out.println("i17 i18 i19 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i20 i21 s2 = " + n6 + "," + n7 + "," + n10);
        FuzzerUtils.out.println("i22 i23 = " + n8 + "," + n9);
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld dFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iArrFld = " + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 3983984012L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

