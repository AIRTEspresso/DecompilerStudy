/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1686312975L;
    public static byte byFld = (byte)97;
    public static boolean bFld = false;
    public static short sFld = (short)-13813;
    public volatile double dFld = 0.104667;
    public static volatile long[] lArrFld = new long[400];
    public static byte[] byArrFld = new byte[400];
    public static int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth() {
        int n = 187;
        int n2 = -49407;
        int n3 = -141;
        int[] nArray = new int[400];
        float f = 118.929f;
        boolean bl = true;
        FuzzerUtils.init(nArray, -10);
        for (n = 1; 128 > n; ++n) {
            instanceCount -= (long)n2;
            n2 >>>= n;
            n2 += n2;
            n2 *= -6170;
        }
        nArray[(n2 >>> 1) % 400] = -248;
        f = byFld;
        n3 = 1;
        do {
            n2 += n3 ^ n3;
            n2 = (int)(instanceCount += (long)(-102 + n3 * n3));
            n2 *= (int)instanceCount;
        } while (++n3 < 248);
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth1(float f) {
        int n = -27;
        int n2 = -170;
        int n3 = -58143;
        int n4 = 1;
        int n5 = 49675;
        int n6 = 5;
        int[] nArray = new int[400];
        int n7 = 19168;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(nArray, 13);
        FuzzerUtils.init(blArray, false);
        try {
            for (n = 5; n < 137; ++n) {
                try {
                    n2 /= n;
                    n2 = 21500 % nArray[n];
                    n2 /= n;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                Test.lArrFld[n + 1] = n2--;
                for (n3 = 1; 12 > n3; ++n3) {
                    n7 = (short)(n7 - (short)n4++);
                    if (!bFld) continue;
                    for (n5 = 1; n5 < 2; ++n5) {
                        instanceCount = (long)n6-- + Test.lMeth();
                        instanceCount += (long)n5;
                        instanceCount >>= (int)instanceCount;
                        int n8 = n;
                        byArrFld[n8] = (byte)(byArrFld[n8] - (byte)n2);
                    }
                }
            }
        }
        catch (ArithmeticException arithmeticException) {
            n6 *= (int)instanceCount;
        }
        catch (UserDefinedExceptionTest userDefinedExceptionTest) {
            n6 >>= n6;
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n7 + n5 + n6) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
    }

    public void vMeth(int n) {
        float f = 3.363f;
        int n2 = 3;
        int n3 = 18399;
        int n4 = 476;
        int n5 = 213;
        int n6 = -225;
        double d = -48.466;
        double d2 = 85.109066;
        Test.vMeth1(f);
        for (n2 = 1; n2 < 209; ++n2) {
            n3 = (int)instanceCount;
            n4 = 1;
            if (n4 >= 8) continue;
        }
        vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)n6 + Double.doubleToLongBits(d2);
    }

    public void mainTest(String[] stringArray) {
        int n = 29183;
        int n2 = -6;
        int n3 = 62949;
        int n4 = 14;
        int n5 = 12;
        int n6 = -81;
        int n7 = 62174;
        int n8 = -64542;
        long l = 8L;
        boolean[][] blArray = new boolean[400][400];
        FuzzerUtils.init(blArray, true);
        for (n = 277; n > 12; --n) {
            this.vMeth(19035);
            byFld = (byte)n2;
            n3 = 1;
            while (!bFld) {
                instanceCount += (long)(n3 | n3);
                n2 %= n3 | 1;
                byFld = (byte)(byFld - (byte)n3);
                for (l = 1L; l < 1L; ++l) {
                    blArray[n - 1][n] = bFld;
                    n4 += (int)(l * (long)byFld + l - l);
                }
                n2 = (int)((long)n2 + ((long)n3 * instanceCount + (long)n2 - (long)n));
                n2 ^= (int)instanceCount;
                n4 = 2139298166;
                if (++n3 < 95) continue;
            }
            block11: for (n5 = 2; n5 < 95; ++n5) {
                n6 += n6;
                n6 += n5;
                switch (n5 % 6 + 107) {
                    case 107: {
                        n6 = sFld;
                        instanceCount += (long)this.dFld;
                        n7 = 1;
                        while (n7 < 2) {
                            lArrFld = FuzzerUtils.long1array(400, -1380765706L);
                            instanceCount += (long)n7;
                            instanceCount += (long)n7 ^ l;
                            this.dFld -= (double)(n8 += n2);
                            Test.fArrFld[n7 - 1] = n7;
                            n2 <<= 131;
                            n8 = n7++;
                        }
                        continue block11;
                    }
                    case 108: {
                        Test.iArrFld[n5] = n;
                    }
                    case 109: {
                        instanceCount += (long)n6;
                        continue block11;
                    }
                    case 110: {
                        n6 += n5;
                        continue block11;
                    }
                    case 111: {
                        n8 >>= n6;
                        continue block11;
                    }
                    case 112: {
                        n2 <<= 42434;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 i18 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("l i19 i20 = " + l + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i21 i22 i23 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("bArr1 = " + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.bFld = " + instanceCount + "," + byFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld dFld Test.lArrFld = " + sFld + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("Test.byArrFld Test.iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -12L);
        FuzzerUtils.init(byArrFld, (byte)-117);
        FuzzerUtils.init(iArrFld, -85);
        FuzzerUtils.init(fArrFld, 0.341f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

