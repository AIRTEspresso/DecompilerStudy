/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 6L;
    public static volatile float fFld = 66.652f;
    public static short sFld = (short)11214;
    public static int iFld = 2;
    public static double dFld = -1.89755;
    public static boolean bFld = false;
    public static long[] lArrFld = new long[400];
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long byMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(long l, long l2) {
        int n = 211;
        int n2 = -250;
        int n3 = 12;
        int n4 = -55901;
        int n5 = -11;
        double d = -1.74436;
        long l3 = -2715737770L;
        float f = -25.21f;
        int n6 = 18593;
        --l;
        n = 1;
        do {
            d = n;
            d *= d;
            for (n2 = n; n2 < 7; n2 += 2) {
                n3 += -187 + n2 * n2;
            }
            l2 >>>= n2;
            for (l3 = 7L; l3 > 1L; l3 -= 2L) {
                if (n != 0) {
                    vMeth1_check_sum += l + l2 + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + l3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6;
                    return;
                }
                n3 -= n;
                n4 = (int)l;
                for (f = 1.0f; 3.0f > f; f += 1.0f) {
                    n3 -= n2;
                    n3 = n6;
                }
                n5 += n3;
            }
        } while (++n < 242);
        vMeth1_check_sum += l + l2 + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + l3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6;
    }

    public static byte byMeth(double d) {
        int n = 6583;
        int n2 = 84;
        int n3 = 7;
        int n4 = 3;
        int n5 = 10;
        int n6 = -40160;
        int[] nArray = new int[400];
        boolean bl = false;
        FuzzerUtils.init(nArray, -26);
        fFld = instanceCount++;
        n = 5;
        while (n < 154) {
            Test.vMeth1(-156L, 3411951848L);
            nArray[(n2 >>> 1) % 400] = n++;
            n2 *= n2;
        }
        block1: for (n3 = 11; n3 < 223; ++n3) {
            if (bl) {
                n2 *= n;
                for (n5 = 1; n5 < 8; ++n5) {
                    fFld += (float)n5;
                    n6 += 6203;
                    if (bl) continue block1;
                }
                continue;
            }
            if (!bl) continue;
            int n7 = n3;
            nArray[n7] = nArray[n7] - -31951;
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
        byMeth_check_sum += l;
        return (byte)l;
    }

    public static void vMeth() {
        int n = 3;
        int n2 = -6;
        int n3 = -214;
        int n4 = 12;
        int n5 = -2;
        int n6 = -12;
        double d = 2.42552;
        boolean bl = false;
        for (n = 14; n < 373; ++n) {
            instanceCount = Test.byMeth(d);
            for (n3 = 1; 5 > n3; n3 += 3) {
                n2 -= n3;
                n2 += (int)(-9920L + (long)(n3 * n3));
                for (n5 = 5; n5 > n; n5 -= 3) {
                    fFld += (float)(n5 * n + sFld - n6);
                    n4 += n5 * n5;
                    n4 += 174;
                    n4 = 20;
                    if (bl) {
                        fFld += (float)sFld;
                        n6 -= n2;
                        n2 += n2;
                        continue;
                    }
                    if (bl) {
                        instanceCount += (long)(n5 * n5 + sFld - n);
                        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0);
                        return;
                    }
                    n6 += -147 + n5 * n5;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0);
    }

    public void mainTest(String[] stringArray) {
        int n = -11;
        int n2 = 0;
        int n3 = 6595;
        int n4 = -57;
        int n5 = 177;
        int n6 = -121;
        int n7 = -11;
        long l = -741191400L;
        int n8 = 111;
        float f = -13.977f;
        n -= 141;
        if (bFld) {
            Test.vMeth();
        } else {
            instanceCount = n7;
        }
        FuzzerUtils.out.println("i l3 i18 = " + n + "," + l + "," + n2);
        FuzzerUtils.out.println("i19 i20 by = " + n3 + "," + n4 + "," + n8);
        FuzzerUtils.out.println("i21 i22 f1 = " + n5 + "," + n6 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i23 = " + n7);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
        FuzzerUtils.out.println("Test.iFld Test.dFld Test.bFld = " + iFld + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.lArrFld iArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 2625323702L);
        vMeth_check_sum = 0L;
        byMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

