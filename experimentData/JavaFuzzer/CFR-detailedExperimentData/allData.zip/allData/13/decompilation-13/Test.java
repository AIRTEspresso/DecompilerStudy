/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -216L;
    public static float fFld = -61.376f;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n) {
        int n2 = 33;
        int n3 = 8;
        int n4 = -7;
        int n5 = 32523;
        int n6 = 6249;
        int n7 = 237;
        int[] nArray = new int[400];
        float f = 0.224f;
        int n8 = 24645;
        double d = -100.122643;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)-111);
        FuzzerUtils.init(nArray, -5993);
        n2 = 1;
        do {
            for (n3 = n2; 8 > n3; ++n3) {
                byArray[n3 + 1] = (byte)fFld;
                for (f = 1.0f; 1.0f > f; f += 1.0f) {
                    n -= n5;
                    int n9 = (int)(f + 1.0f);
                    byArray[n9] = (byte)(byArray[n9] * (byte)(n *= (n4 += (int)((long)f ^ (long)n8))));
                    n = n5;
                }
            }
            for (n6 = 1; 8 > n6; ++n6) {
                nArray[n6 + 1] = n;
                n5 *= (int)d;
                n4 = -2;
                n5 -= (int)fFld;
            }
        } while (++n2 < 212);
        long l = (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n8 + n6 + n7) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(byArray) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(double d) {
        int n = -51287;
        int n2 = 24534;
        int n3 = -36668;
        int n4 = -8;
        int[] nArray = new int[400];
        int n5 = 99;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, -30115);
        FuzzerUtils.init(fArray, -93.2f);
        for (int n6 : nArray) {
            double d2 = (199.0f + fFld) * (float)(instanceCount + (long)n6);
            ++n6;
            n6 = (int)(d2 - ((double)n6 + d * (double)n6));
            for (n = 1; n < 4; ++n) {
                d = n2;
                int n7 = n2--;
                int n8 = n;
                long l = lArrFld[n8] - 1L;
                lArrFld[n8] = l;
                int n9 = n;
                nArray[n9] = nArray[n9] >> Test.iMeth(n6 += (int)(d - (double)n7 + (double)l));
                for (n3 = 1; n3 < 2; ++n3) {
                    d = instanceCount;
                    n5 = (byte)(n5 + (byte)((long)n3 * instanceCount + (long)n5 - (long)n3));
                    n6 -= n3;
                }
            }
            fFld = n4;
            nArray[((n6 <<= n4) >>> 1) % 400] = (int)instanceCount;
            instanceCount *= (long)(n2 >>= 0);
            int n10 = (n3 >>> 1) % 400;
            fArray[n10] = fArray[n10] - (float)n3;
        }
        vMeth1_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth(int n, int n2, int n3) {
        double d = 1.23456;
        int n4 = -63777;
        int n5 = 9;
        int n6 = -10;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 60);
        Test.vMeth1(d);
        for (n4 = 157; n4 > 8; n4 -= 2) {
            if (n4 != 0) {
                vMeth_check_sum += (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
                return;
            }
            try {
                n = n6 / -56624;
                n6 = n % n2;
                n = nArray[n4] / nArray[n4];
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n3 += 45457 + n4 * n4;
            instanceCount = (long)((float)instanceCount + ((float)(n4 * n6 + n5) - fFld));
            n3 += n4;
        }
        vMeth_check_sum += (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -4;
        int n2 = -64252;
        int n3 = 40601;
        int n4 = 119;
        int n5 = 31;
        int[][] nArray = new int[400][400];
        int n6 = 22418;
        long l = -14L;
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        float f = 61.641f;
        int n7 = -67;
        double d = -2.117728;
        FuzzerUtils.init(nArray, 85);
        FuzzerUtils.init(blArray, false);
        n = nArray[(n >>> 1) % 400][(n >>> 1) % 400] + n * n6;
        Test.vMeth(n, n, n);
        instanceCount += (long)fFld;
        int[] nArray2 = nArray[(n >>> 1) % 400];
        nArray2[1] = nArray2[1] - n;
        l -= (long)n;
        for (n2 = 9; n2 < 268; ++n2) {
            blArray[n2] = bl;
            if (!bl) continue;
            fFld *= fFld;
            f = 1.0f;
            do {
                n4 = 1;
                while (++n4 < 1) {
                    instanceCount = n;
                    switch ((n4 >>> 1) % 6 + 100) {
                        case 100: {
                            n3 += n4 * n + n4 - n6;
                        }
                        case 101: {
                            nArray[n2 + 1][n2 + 1] = (int)l;
                            l ^= (long)n2;
                            n3 -= n3;
                            break;
                        }
                        case 102: {
                            l = n3;
                            instanceCount *= (long)n2;
                            int n8 = (int)(f - 1.0f);
                            lArrFld[n8] = lArrFld[n8] - 13864L;
                            break;
                        }
                        case 103: {
                            l <<= n7;
                            break;
                        }
                        case 104: 
                        case 105: {
                            n3 = (int)((long)n3 + ((long)n4 + l));
                            n3 = (int)((long)n3 + (long)n4 * l);
                            n3 = (int)fFld;
                            n5 = 1;
                        }
                    }
                    n3 = (int)d;
                    n7 = (byte)(n7 + (byte)(n4 * n4));
                }
            } while ((f += 1.0f) < 97.0f);
        }
        FuzzerUtils.out.println("i s l = " + n + "," + n6 + "," + l);
        FuzzerUtils.out.println("i20 i21 b = " + n2 + "," + n3 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("f1 i22 by1 = " + Float.floatToIntBits(f) + "," + n4 + "," + n7);
        FuzzerUtils.out.println("i23 d3 iArr = " + n5 + "," + Double.doubleToLongBits(d) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 210L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

