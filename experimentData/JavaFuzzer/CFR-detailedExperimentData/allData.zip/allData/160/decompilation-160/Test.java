/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -222L;
    public static int iFld = 31231;
    public double dFld = -25.42777;
    public static float fFld = 4.476f;
    public short sFld = (short)-6543;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2) {
        int n3 = -62787;
        int n4 = -7;
        int n5 = 15595;
        int n6 = 0;
        int n7 = -37579;
        int n8 = 51;
        int[] nArray = new int[400];
        int[] nArray2 = new int[400];
        int n9 = -9439;
        int n10 = 29;
        double d = 116.121409;
        FuzzerUtils.init(nArray, 6);
        FuzzerUtils.init(nArray2, 9);
        for (n3 = 7; n3 < 328; ++n3) {
            iFld += n3 * (n -= (int)instanceCount) + n2 - n4;
            block7: for (n5 = 1; n5 < 5; ++n5) {
                switch (n3 % 2 + 26) {
                    case 26: {
                        n2 = iFld;
                        if (n3 != 0) {
                            vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n9 + n7 + n8 + n10) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(nArray2);
                            return;
                        }
                        n9 = (short)(n9 - (short)n);
                        try {
                            n4 = n3 % n5;
                            nArray2[n3 + 1] = nArray[n5 + 1] / -48370;
                            n6 = iFld % n4;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                    case 27: {
                        for (n7 = 2; n7 > 1; n7 -= 3) {
                            n10 = (byte)(n10 * 55);
                            d = n5;
                            n4 -= (int)instanceCount;
                            iFld += n7;
                        }
                        continue block7;
                    }
                }
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n9 + n7 + n8 + n10) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(nArray2);
    }

    public static void vMeth1() {
        double d = -91.8643;
        int n = -112;
        int n2 = -6;
        int n3 = -10;
        int n4 = -54571;
        int n5 = 159;
        int[] nArray = new int[400];
        int n6 = -13900;
        int n7 = -76;
        FuzzerUtils.init(nArray, -191);
        Test.vMeth2(iFld, 18352);
        nArray[(Test.iFld >>> 1) % 400] = (int)fFld;
        d = instanceCount;
        iFld -= iFld;
        for (n = 3; n < 157; ++n) {
            n2 -= (int)instanceCount;
            n2 *= n6;
            instanceCount += (long)n;
            n3 = 10;
            do {
                n7 = (byte)d;
                for (n4 = 1; n4 < 1; ++n4) {
                    iFld -= (int)instanceCount;
                    fFld = n5;
                    fFld *= -14.0f;
                }
            } while (--n3 > 0);
        }
        vMeth1_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n6 + (long)n3 + (long)n7 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(short s) {
        int n = -11;
        long l = 92L;
        double d = 1.51951;
        n = 1;
        while (++n < 384) {
            instanceCount ^= l;
            fFld = (float)d;
            l = Math.min((int)((double)iFld - d), iFld);
            iFld >>= (int)l;
        }
        Test.vMeth1();
        vMeth_check_sum += (long)(s + n) + l + Double.doubleToLongBits(d);
    }

    public void mainTest(String[] stringArray) {
        float f = -28.479f;
        int n = -62635;
        int n2 = 24419;
        int n3 = 25205;
        int n4 = 38788;
        int n5 = -5;
        int n6 = 6;
        int n7 = 37;
        int[] nArray = new int[400];
        long l = -7L;
        boolean bl = false;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 123.4443);
        FuzzerUtils.init(nArray, 3);
        int n8 = (iFld >>> 1) % 400;
        int n9 = (iFld >>> 1) % 400;
        long l2 = lArrFld[n9];
        lArrFld[n9] = l2 - 1L;
        dArray[n8] = dArray[n8] + (double)l2;
        iFld = (int)((double)(-(iFld * iFld)) * (this.dFld + (double)-62.453f - ((double)f + this.dFld)));
        for (n = 5; 136 > n; ++n) {
            int n10 = -49;
            f += (float)((long)n * instanceCount + (long)n) - f;
            n2 += (int)(f - (float)(-159L + (long)n2 * instanceCount) - (f + (float)(n - n10)));
            block13: for (n3 = 8; n3 < 191; ++n3) {
                this.dFld = Math.max(instanceCount, lArrFld[n + 1]);
                n4 += n4;
                Test.vMeth((short)-655);
                switch ((iFld >>> 1) % 10 * 5 + 94) {
                    case 108: {
                        fFld += (float)n3;
                        int n11 = n3 - 1;
                        nArray[n11] = nArray[n11] - -1;
                        continue block13;
                    }
                    case 102: {
                        for (n5 = 1; n5 < 2; ++n5) {
                            int n12 = n;
                            dArray[n12] = dArray[n12] + (double)instanceCount;
                            n6 += n5 ^ iFld;
                        }
                        continue block13;
                    }
                    case 115: {
                        this.dFld += (double)0.835f;
                        iFld -= (int)instanceCount;
                        f += f;
                    }
                    case 117: {
                        for (l = 1L; l < 2L; ++l) {
                            instanceCount += l;
                            n7 += (int)(l - (long)n3);
                            n2 += (int)((float)(l * (long)n4) + fFld - (float)l);
                            int n13 = (int)(l + 1L);
                            nArray[n13] = nArray[n13] + n6;
                            n7 += n6;
                        }
                        dArray[n3 - 1] = 1.171f;
                        f += (float)n4;
                        continue block13;
                    }
                    case 142: {
                        this.dFld = 45909.0;
                        this.sFld = (short)(this.sFld << (short)n6);
                        continue block13;
                    }
                    case 112: {
                        instanceCount = n5;
                    }
                    case 113: {
                        n2 >>= n4;
                    }
                    case 138: {
                        iFld += n3;
                        continue block13;
                    }
                    case 118: {
                        continue block13;
                    }
                    case 116: {
                        n6 = (int)((long)n6 + ((long)n3 * l + instanceCount - (long)n3));
                    }
                    default: {
                        if (!bl) continue block13;
                    }
                }
            }
        }
        FuzzerUtils.out.println("f i i1 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i2 i3 i18 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i19 l1 i20 = " + n6 + "," + l + "," + n7);
        FuzzerUtils.out.println("b dArr iArr3 = " + (bl ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.fFld sFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -10L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

