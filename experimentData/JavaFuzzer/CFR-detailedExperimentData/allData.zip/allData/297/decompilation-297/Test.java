/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -122L;
    public static volatile long lFld = 5L;
    public double dFld = 103.106521;
    public boolean bFld = false;
    public static byte byFld = (byte)-35;
    public static int[] iArrFld = new int[400];
    public long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2() {
        int n = -41;
        int n2 = -13;
        int n3 = 14;
        int n4 = 20;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -2497875395594985310L);
        n = 1;
        do {
            float f = 18.51f;
            f *= (float)(n2 += n);
            Test.iArrFld[n + 1] = n2 = n4;
            instanceCount = n2 += n;
            n3 = 1;
            while (++n3 < 5) {
                instanceCount *= (long)n3;
                int n5 = n3;
                iArrFld[n5] = iArrFld[n5] + (int)f;
                n2 = n3;
                instanceCount = (long)f;
                n2 -= (int)f;
                try {
                    n2 = -129 % iArrFld[n3 - 1];
                    n2 /= iArrFld[n3];
                    n2 = n3 % 219;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n2 -= (int)f;
            }
        } while (++n < 351);
        vMeth2_check_sum += (long)(n + n2 + n4 + n3) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth1(int n, float f) {
        int n2 = 244;
        int n3 = 116;
        int n4 = -41780;
        int n5 = 35351;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)124);
        int n6 = (n >>> 1) % 400;
        byArray[n6] = (byte)(byArray[n6] - (byte)n--);
        Test.vMeth2();
        n *= (int)instanceCount;
        instanceCount = lFld;
        for (int n7 : iArrFld) {
            n = (int)instanceCount;
            n = n7;
            instanceCount -= 36232L;
            for (n2 = 1; n2 < 4; ++n2) {
                for (n4 = 1; 2 > n4; ++n4) {
                    n3 = n4;
                    instanceCount += (long)n4 * lFld + (long)n5 - (long)n4;
                    n5 += n5;
                    Test.iArrFld[n2 + 1] = n7;
                }
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum(byArray);
    }

    public static void vMeth(int n, int n2) {
        int n3 = 48;
        int n4 = 35273;
        int n5 = -11;
        int n6 = -11;
        int n7 = 6;
        float f = -63.844f;
        float f2 = -16.209f;
        double d = -2.77967;
        int n8 = 10;
        for (n3 = 313; n3 > 5; --n3) {
            Test.vMeth1(n4, f);
            instanceCount ^= (long)n;
            for (n5 = 1; n5 < 5; ++n5) {
                lFld += (long)n5;
                n2 >>>= n2;
                f += (float)instanceCount;
                n7 = n;
                n = (int)instanceCount;
                n6 /= (int)(instanceCount | 1L);
                f2 = (float)d;
                n8 = (byte)(n8 * (byte)n5);
                instanceCount += (long)n5;
            }
            lFld = n;
            n7 += (int)(-8.486f + (float)(n3 * n3));
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + n7 + Float.floatToIntBits(f2)) + Double.doubleToLongBits(d) + (long)n8;
    }

    public void mainTest(String[] stringArray) {
        int n = -68;
        int n2 = 56364;
        int n3 = 13;
        int n4 = 0;
        int n5 = -7126;
        int n6 = 56569;
        int n7 = -7;
        int n8 = -59600;
        int n9 = -17537;
        float f = -95.906f;
        long l = -46641L;
        int n10 = -15818;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)22106);
        FuzzerUtils.out.println("i i1 f = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i19 i20 i21 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i22 i23 i24 = " + n6 + "," + n7 + "," + (n8 += n10));
        FuzzerUtils.out.println("l1 i25 s = " + l + "," + n9 + "," + n10);
        FuzzerUtils.out.println("sArr = " + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount Test.lFld dFld = " + instanceCount + "," + lFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("bFld Test.byFld Test.iArrFld = " + (this.bFld ? 1 : 0) + "," + byFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 44430);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

