/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -8651291483224068383L;
    public static volatile int iFld = 208;
    public short sFld = (short)1909;
    public static short[] sArrFld = new short[400];
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;

    public static void vMeth(long l, double d) {
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 0);
        int n = iFld;
        iFld >>>= 17;
        iFld = n - (int)(l - (long)(iFld - -nArray[381]));
        vMeth_check_sum += l + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth1(int n, int n2) {
        long l = -12L;
        int n3 = 6;
        int n4 = -34128;
        int n5 = -220;
        int n6 = 23890;
        int[] nArray = new int[400];
        boolean bl = true;
        float f = -2.165f;
        FuzzerUtils.init(nArray, 47014);
        int n7 = (n >>> 1) % 400;
        sArrFld[n7] = (short)(sArrFld[n7] * (short)(iFld - -3788 - Math.abs(14) - 127));
        Test.vMeth(instanceCount, -127.106268);
        int n8 = (iFld >>> 1) % 400;
        nArray[n8] = nArray[n8] >> iFld;
        n >>>= -8108;
        for (l = 5L; l < 332L; ++l) {
            for (n4 = (int)l; n4 < 5; ++n4) {
                try {
                    n = n4 % iFld;
                    n5 = n2 % n4;
                    n = nArray[(int)l] / -939022363;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                nArray[n4] = n5;
                n3 *= iFld;
                int n9 = (int)l;
                nArray[n9] = nArray[n9] + iFld;
            }
        }
        n6 = 1;
        while (++n6 < 373) {
            n2 += (int)(f += (float)n2);
            iFld = -6;
        }
        long l2 = (long)(n + n2) + l + (long)n3 + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)n6 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    public static int iMeth() {
        float f = 38.733f;
        int n = -32929;
        int n2 = 13;
        int n3 = 27508;
        int n4 = 89;
        int[] nArray = new int[400];
        int n5 = 18;
        boolean bl = true;
        int n6 = 7711;
        FuzzerUtils.init(nArray, -6405);
        iFld = (int)((float)Test.iMeth1(iFld, iFld) * f);
        block13: for (int n7 : nArray) {
            instanceCount = iFld;
            f = n7;
            switch ((n7 >>> 1) % 2 * 5 + 90) {
                case 98: {
                    for (n = 1; 4 > n; ++n) {
                        block15: for (n3 = 1; n3 < 2; ++n3) {
                            iFld -= n3;
                            switch (n3 % 5 + 97) {
                                case 97: {
                                    int n8 = n;
                                    nArray[n8] = nArray[n8] * (int)f;
                                    n5 = (byte)(n5 >>> (byte)n2);
                                    if (bl) {
                                        n2 = n3;
                                        continue block15;
                                    }
                                    n7 += n3;
                                    n6 = -124;
                                    continue block15;
                                }
                                case 98: {
                                    n7 = iFld;
                                    continue block15;
                                }
                                case 99: {
                                    iFld = (int)instanceCount;
                                    continue block15;
                                }
                                case 100: {
                                    try {
                                        n2 = iFld % 356175627;
                                        n7 = iFld % 199;
                                        nArray[n + 1] = iFld % -4448;
                                    }
                                    catch (ArithmeticException arithmeticException) {}
                                    continue block15;
                                }
                                case 101: {
                                    n2 += iFld;
                                }
                            }
                        }
                    }
                    continue block13;
                }
                case 100: {
                    n4 += 177;
                }
            }
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + (bl ? 1 : 0) + n6) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        double d = 2.18213;
        double[] dArray = new double[400];
        int n = -10398;
        int n2 = -116;
        int n3 = -51794;
        int n4 = 25092;
        int n5 = 11;
        int n6 = 2;
        int n7 = -93;
        int n8 = 2;
        float f = -2.267f;
        int n9 = 13;
        FuzzerUtils.init(dArray, -96.81267);
        Test.vMeth(Test.iMeth() * iFld, d);
        switch ((iFld >>> 1) % 1 + 13) {
            default: 
        }
        iFld = 10070;
        for (n = 12; 298 > n; ++n) {
            for (n3 = 1; n3 < 88; ++n3) {
                f -= 90.0f;
                n4 *= n3;
                for (n5 = 1; n5 < 2; ++n5) {
                    instanceCount = 200L;
                    switch (n3 % 1 * 5 + 105) {
                        case 108: {
                            n4 += n5;
                            break;
                        }
                        default: {
                            int n10 = n5;
                            sArrFld[n10] = (short)(sArrFld[n10] * (short)n5);
                            n2 -= n9;
                        }
                    }
                    instanceCount = n5;
                    iFld = (int)((long)iFld + ((long)n5 ^ instanceCount));
                    int n11 = n5 + 1;
                    this.iArrFld[n11] = this.iArrFld[n11] + iFld;
                    this.sFld = (short)-7;
                }
                this.iArrFld[n3 - 1] = n3;
                n7 = 1;
                while (2 > n7) {
                    instanceCount = -87L;
                    this.sFld = (short)(this.sFld - (short)f);
                    f += (float)(n7 * (n4 += (int)f) + n8 - iFld);
                    n6 = n7++;
                    d *= d;
                    instanceCount += -4L;
                }
            }
        }
        FuzzerUtils.out.println("d1 i11 i12 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("i13 i14 f2 = " + n3 + "," + n4 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i15 i16 by1 = " + n5 + "," + n6 + "," + n9);
        FuzzerUtils.out.println("i17 i18 dArr = " + n7 + "," + n8 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
        FuzzerUtils.out.println("Test.sArrFld iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)13224);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

