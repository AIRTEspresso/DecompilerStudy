/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 268906671L;
    public static float fFld = -1.843f;
    public static byte byFld = (byte)-67;
    public static int iFld = 48874;
    public static boolean bFld = true;
    public static short sFld = (short)-19932;
    public static long[] lArrFld = new long[400];
    public short[] sArrFld = new short[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1(long l) {
        int n = -31;
        int n2 = -35598;
        int n3 = 13954;
        int n4 = -61852;
        int n5 = 122;
        double d = -112.79484;
        boolean bl = true;
        for (n = 7; n < 129; ++n) {
            n2 = 1;
            d = fFld;
            instanceCount = n2;
            d -= -46548.0;
            for (n3 = 1; 13 > n3; ++n3) {
                if (bl) continue;
                l -= -10L;
                n4 = -9;
            }
            n4 += n * n;
            n5 = 1;
            while (++n5 < 13) {
                n4 += 20272;
                n2 = (int)fFld;
                n2 *= n2;
                fFld -= (float)byFld;
            }
        }
        long l2 = l + (long)n + (long)n2 + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5;
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth() {
        int n = -2;
        int[] nArray = new int[400];
        boolean bl = true;
        FuzzerUtils.init(nArray, 61524);
        instanceCount += (long)(-Math.max(Test.iMeth1(instanceCount), n));
        n -= n;
        int n2 = (n >>> 1) % 400;
        nArray[n2] = nArray[n2] - -2;
        fFld -= (float)n;
        vMeth_check_sum += (long)(n + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth() {
        int n = -9;
        int n2 = 1;
        int n3 = -14;
        int n4 = -20634;
        int n5 = -159;
        int[] nArray = new int[400];
        long l = 20298L;
        FuzzerUtils.init(nArray, 6);
        Test.vMeth();
        fFld = iFld;
        for (n = 13; n < 378; ++n) {
            for (n3 = 1; n3 < 5; ++n3) {
                int n6 = n + 1;
                nArray[n6] = nArray[n6] | byFld;
                int n7 = n3;
                nArray[n7] = nArray[n7] ^ 5;
                block10: for (l = 1L; l < 2L; ++l) {
                    Test.lArrFld[(int)l] = n;
                    int n8 = (int)(l + 1L);
                    lArrFld[n8] = lArrFld[n8] * (long)n;
                    n4 += (int)instanceCount;
                    switch (30) {
                        case 30: 
                        case 31: {
                            n5 += 16616;
                            n4 = 109;
                            n5 *= (int)fFld;
                            continue block10;
                        }
                        case 32: {
                            if (bFld) continue block10;
                        }
                        case 33: {
                            n5 += iFld;
                            continue block10;
                        }
                        case 34: {
                            sFld = (short)(sFld + (short)(l | (long)fFld));
                            continue block10;
                        }
                        case 35: {
                            int n9 = (int)l;
                            lArrFld[n9] = lArrFld[n9] >> iFld;
                            continue block10;
                        }
                        case 36: {
                            n5 = 1;
                            continue block10;
                        }
                        default: {
                            instanceCount += l - (long)iFld;
                        }
                    }
                }
            }
        }
        long l2 = (long)(n + n2 + n3 + n4) + l + (long)n5 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 11387;
        int n2 = -12;
        int n3 = 52;
        int n4 = -151;
        int n5 = 27;
        int n6 = -12;
        int n7 = 39187;
        int n8 = 21111;
        int n9 = -12;
        int[] nArray = new int[400];
        float f = 2.582f;
        double d = 2.5768;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(nArray, -14);
        FuzzerUtils.init(lArray, 2641272992L);
        int[] nArray2 = nArray;
        nArray = nArray2;
        nArray = nArray2;
        nArray = nArray2;
        nArray[69] = nArray[69] + 163;
        n = n--;
        n = (int)((long)n - instanceCount--);
        f -= (float)(++n + Test.iMeth());
        iFld += n;
        for (n2 = 1; 151 > n2; ++n2) {
            n4 = 7;
            while (n4 < 167) {
                f += (float)iFld;
                int n10 = n4++;
                nArray[n10] = nArray[n10] - iFld;
                n3 >>= iFld;
                n5 ^= (n |= (int)instanceCount);
            }
            iFld *= n3;
            if (bFld) continue;
            for (n6 = n2; n6 < 167; ++n6) {
                n5 = (int)instanceCount;
            }
            instanceCount += (long)n2 * instanceCount + (long)n7 - (long)n2;
            f += (float)n7;
            for (n8 = 4; n8 < 167; ++n8) {
                if (bFld) continue;
                int n11 = n8;
                nArray[n11] = nArray[n11] + (int)d;
                n += n8 * n7 + sFld - n6;
                fFld = 0.101f;
                n5 ^= n2;
            }
        }
        for (int n12 : nArray) {
            lArray[(n >>> 1) % 400][(n6 >>> 1) % 400] = n8;
            fFld = n5;
            this.sArrFld[(Test.iFld >>> 1) % 400] = -28362;
        }
        FuzzerUtils.out.println("i f i12 = " + n + "," + Float.floatToIntBits(f) + "," + n2);
        FuzzerUtils.out.println("i13 i14 i15 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i16 i17 i18 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i19 d1 iArr = " + n9 + "," + Double.doubleToLongBits(d) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("Test.iFld Test.bFld Test.sFld = " + iFld + "," + (bFld ? 1 : 0) + "," + sFld);
        FuzzerUtils.out.println("Test.lArrFld sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 97L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

