/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2852157046L;
    public static int iFld = 11;
    public float fFld = 0.99f;
    public static short[] sArrFld = new short[400];
    public static long vSmallMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        int n4 = -63634;
        int n5 = 26;
        int n6 = -46396;
        int n7 = 2;
        int[] nArray = new int[400];
        float f = -44.323f;
        int n8 = -267;
        int n9 = -51;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -24056);
        FuzzerUtils.init(lArray, 2513115404534364896L);
        nArray[((Test.iFld &= (int)Test.instanceCount) >>> 1) % 400] = (int)instanceCount;
        for (long l : lArray) {
            for (n4 = 1; n4 < 4; ++n4) {
                for (n6 = 1; 2 > n6; ++n6) {
                    n5 -= n5;
                    int n10 = n4;
                    nArray[n10] = nArray[n10] & n2;
                    n = (int)f;
                    int n11 = n6 + 1;
                    nArray[n11] = nArray[n11] + iFld;
                    n9 = (byte)(n9 + (byte)n5);
                    n2 *= -4;
                    l = (long)((float)l + ((float)(n6 * n6) + (f -= (float)n) - (float)n6));
                }
                n7 += n8;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f) + n8 + n9) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n) {
        long l = 26575L;
        long[] lArray = new long[400];
        double d = -2.6092;
        double d2 = 98.79058;
        int n2 = 12;
        int n3 = 5623;
        float f = 1.64f;
        FuzzerUtils.init(lArray, -8L);
        l = 349L;
        do {
            Test.vMeth1(n, -153, iFld);
            iFld += (int)(l * l);
        } while (--l > 0L);
        d = 1.0;
        block1: while (true) {
            double d3;
            d += 1.0;
            if (!(d3 < 187.0)) break;
            instanceCount += (long)(d * (double)n + (double)l - (double)n);
            n = -182;
            instanceCount = -5L;
            instanceCount = n;
            d2 = 1.0;
            while (true) {
                if (!(9.0 > d2)) continue block1;
                iFld += (int)(d2 * (double)n2 + (double)iFld - (double)n3);
                instanceCount += -86L;
                n = (int)l;
                iFld *= (int)f;
                int n4 = (int)d;
                lArray[n4] = lArray[n4] + (long)n;
                instanceCount += (long)d2;
                d2 += 2.0;
            }
            break;
        }
        vMeth_check_sum += (long)n + l + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(lArray);
    }

    public static void vSmallMeth(long l, int n) {
        Test.vMeth(5835);
        iFld /= n | 1;
        vSmallMeth_check_sum += l + (long)n;
    }

    public void mainTest(String[] stringArray) {
        int n = 16414;
        int n2 = -45584;
        int n3 = -59418;
        int n4 = -67;
        int n5 = 15;
        int n6 = -5406;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 1.382f);
        Test.sArrFld[(Test.iFld >>> 1) % 400] = (short)(iFld &= (int)(instanceCount * 180L ^ 0xFFFFFFFFFFFFFFFFL));
        ++n;
        n = (int)((this.fFld -= 1.0f) + (float)n - (float)(-n * (n6 - n)));
        for (n2 = 290; n2 > 2; --n2) {
            n3 = (int)((float)instanceCount++ + this.fFld);
        }
        for (int i = 0; i < 282; ++i) {
            Test.vSmallMeth(instanceCount, n3);
        }
        n3 += n;
        for (n4 = 7; n4 < 137; ++n4) {
            n >>= n4;
        }
        FuzzerUtils.out.println("i s i1 = " + n + "," + n6 + "," + n2);
        FuzzerUtils.out.println("i2 i14 i15 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)19782);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

