/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2045395048L;
    public byte byFld = (byte)-23;
    public static int iFld = 49267;
    public static volatile int iFld1 = 36669;
    public static short sFld = (short)27557;
    public static volatile float fFld = 1.39f;
    public static int[][] iArrFld = new int[400][400];
    public static float[] fArrFld = new float[400];
    public static long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(double d) {
        Test.iArrFld[(Test.iFld >>> 1) % 400][(Test.iFld >>> 1) % 400] = iFld;
        vMeth_check_sum += Double.doubleToLongBits(d);
    }

    public static int iMeth1(byte by, int n) {
        double d = 0.6885;
        int n2 = -9;
        int n3 = -169;
        int n4 = 149;
        int n5 = 31927;
        int n6 = 49957;
        int n7 = 39110;
        boolean bl = false;
        Test.vMeth(d);
        for (n2 = 3; n2 < 149; ++n2) {
            for (n4 = 11; 1 < n4; n4 -= 2) {
                n3 >>>= n5;
                Test.iArrFld[n2] = iArrFld[n2 + 1];
                int[] nArray = iArrFld[n4 - 1];
                int n8 = n2 - 1;
                nArray[n8] = nArray[n8] & n5;
            }
            n += n2;
            n6 = 1;
            while (n6 < 11) {
                Test.iArrFld[n2][n2 + 1] = n2;
                instanceCount <<= iFld1;
                n7 -= 122;
                int[] nArray = iArrFld[n6 - 1];
                int n9 = n6++;
                nArray[n9] = nArray[n9] - -21208;
            }
        }
        long l = (long)(by + n) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)n6 + (long)n7;
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth(int n, int n2) {
        float f = -95.459f;
        int n3 = 0;
        int n4 = -125;
        int n5 = -3;
        int n6 = 76;
        int n7 = -72;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 236L);
        int n8 = (n2 >>> 1) % 400;
        fArrFld[n8] = fArrFld[n8] + (float)(-87 - n2--);
        int n9 = (n >>> 1) % 400;
        lArray[n9] = lArray[n9] * (long)(((float)n2 + (f + (float)instanceCount)) * (float)Test.iMeth1((byte)47, iFld1));
        n *= (int)f;
        for (n3 = 17; n3 < 293; ++n3) {
            n4 >>= -14;
            sFld = (short)(sFld - (short)instanceCount);
            if (bl) {
                n7 = (byte)(n7 << (byte)iFld1);
                n7 = (byte)instanceCount;
                for (n5 = 6; 1 < n5; n5 -= 2) {
                    n4 = iFld;
                    int[] nArray = iArrFld[n5 - 1];
                    int n10 = n3;
                    nArray[n10] = nArray[n10] + -983216869;
                    iFld -= (int)instanceCount;
                }
                continue;
            }
            if (bl) {
                f += (float)((long)n3 + instanceCount);
                continue;
            }
            int[] nArray = iArrFld[n3 + 1];
            int n11 = n3 - 1;
            nArray[n11] = nArray[n11] / (sFld | 1);
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n7 + n5 + n6 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 11;
        int n2 = -3;
        int n3 = 11;
        int n4 = 29847;
        int n5 = -224;
        int n6 = -216;
        int n7 = -37466;
        int n8 = 9;
        long l = -6L;
        float f = -118.151f;
        boolean bl = true;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 0.111897);
        for (n = 325; n > 19; n -= 2) {
            for (l = (long)n; 164L > l; ++l) {
                n2 += -iArrFld[(int)l][(int)(l - 1L)] - (this.byFld + -32130) - n * Test.iMeth(iFld, n3);
                sFld = (short)(sFld + (short)(l * l));
            }
            block18: for (n4 = 1; n4 < 164; ++n4) {
                Test.iArrFld[n] = iArrFld[n + 1];
                int[] nArray = iArrFld[n - 1];
                int n9 = n;
                nArray[n9] = nArray[n9] + (int)l;
                n2 += n4;
                switch ((iFld1 >>> 1) % 9 * 5 + 35) {
                    case 41: 
                    case 63: {
                        instanceCount *= l;
                        n6 = 1;
                        while (n6 < 2) {
                            int n10 = n;
                            lArrFld[n10] = lArrFld[n10] ^ 7L;
                            instanceCount += (long)(-50642 + n6 * n6);
                            int[] nArray2 = iArrFld[n4 - 1];
                            int n11 = n6++;
                            nArray2[n11] = nArray2[n11] + -36247;
                            n2 >>= n5;
                        }
                        continue block18;
                    }
                    case 55: {
                        Test.lArrFld[n4 - 1] = instanceCount;
                        continue block18;
                    }
                    case 46: {
                        instanceCount += (long)(n4 * n4);
                        try {
                            Test.iArrFld[n - 1][n4 - 1] = n % -100;
                            Test.iArrFld[n4][n + 1] = 2123209591 / iFld;
                            n5 = iArrFld[n + 1][n] / 695888026;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                    case 73: {
                        for (f = 2.0f; f > 1.0f; f -= 1.0f) {
                            int n12 = (int)f;
                            dArray[n12] = dArray[n12] - (double)n3;
                            n5 += (int)(f - (float)n3);
                            switch (n4 % 2 * 5 + 124) {
                                case 134: {
                                    Test.iArrFld[(int)(f + 1.0f)][n4 - 1] = n;
                                    Test.iArrFld[n4 - 1] = iArrFld[n4 - 1];
                                }
                                case 132: {
                                    fFld = instanceCount;
                                    n2 += n7;
                                    n2 >>= 4741;
                                }
                            }
                            n2 = (int)instanceCount;
                            n5 = -12;
                            n5 += (int)((long)f ^ (long)f);
                        }
                        continue block18;
                    }
                    case 70: {
                        if (!bl) continue block18;
                        continue block18;
                    }
                    case 78: {
                        n8 = n7;
                        continue block18;
                    }
                    case 52: {
                        n7 -= n5;
                    }
                    case 42: {
                        instanceCount <<= n5;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 l = " + n + "," + n2 + "," + l);
        FuzzerUtils.out.println("i2 i16 i17 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i18 i19 f1 = " + n6 + "," + n7 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i20 b2 dArr = " + n8 + "," + (bl ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount byFld Test.iFld = " + instanceCount + "," + this.byFld + "," + iFld);
        FuzzerUtils.out.println("Test.iFld1 Test.sFld Test.fFld = " + iFld1 + "," + sFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iArrFld Test.fArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -140);
        FuzzerUtils.init(fArrFld, -2.671f);
        FuzzerUtils.init(lArrFld, -9098027689776070920L);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

