/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1L;
    public static long lFld = -5L;
    public static int iFld = 36272;
    public static byte byFld = (byte)-38;
    public static short sFld = (short)28385;
    public int iFld1 = 57097;
    public static double dFld = -1.80568;
    public static volatile float fFld = 0.693f;
    public int[][] iArrFld = new int[400][400];
    public static long[] lArrFld = new long[400];
    public volatile byte[] byArrFld = new byte[400];
    public int[] iArrFld1 = new int[400];
    public static long vMeth_check_sum;
    public static long dMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(long l) {
        int n = -33606;
        int n2 = 216;
        int n3 = 54593;
        int n4 = -8;
        int n5 = 53979;
        int n6 = 2;
        int n7 = 174;
        int[] nArray = new int[400];
        int n8 = -53;
        boolean bl = true;
        float f = -17.598f;
        FuzzerUtils.init(nArray, 124);
        l = iFld;
        n = 1;
        while (++n < 218) {
            for (n2 = 1; n2 < 7; ++n2) {
                for (n4 = 1; n4 < 2; ++n4) {
                    n8 = (byte)(n8 + (byte)(n4 * iFld + n4 - n2));
                }
                if (bl) continue;
                for (n6 = 1; n6 < 2; ++n6) {
                    n3 -= (int)lFld;
                    n3 >>= -49;
                    Test.lArrFld[n + 1] = n5 += (int)l;
                    int n9 = n6 - 1;
                    nArray[n9] = nArray[n9] * (int)lFld;
                    n3 = (int)l;
                    n8 = (byte)(n8 * (byte)f);
                }
            }
            n5 >>= n6;
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n8 + (long)(bl ? 1 : 0) + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public double dMeth(int n, long l, int n2) {
        float f = 0.237f;
        int n3 = -29204;
        int n4 = -2;
        int n5 = -6;
        int n6 = 65;
        double d = 125.50555;
        int n7 = 3970;
        n2 += (int)(instanceCount / (long)(this.iArrFld[(n2 >>> 1) % 400][(n >>> 1) % 400] | 1));
        block8: for (int n8 : this.byArrFld) {
            switch (((int)(f + (float)n) >>> 1) % 2 * 5 + 118) {
                case 120: {
                    for (n3 = 1; 4 > n3; ++n3) {
                        n4 += n + n8 + n4;
                        n += n4;
                        block10: for (n5 = 1; n5 < 2; n5 += 2) {
                            d = lFld++;
                            Test.iMeth(l);
                            instanceCount += (long)(n5 * n5);
                            switch ((n5 >>> 1) % 2 + 47) {
                                case 47: {
                                    lFld += (long)n5;
                                    n4 = n2;
                                    continue block10;
                                }
                                case 48: {
                                    lFld >>= (int)instanceCount;
                                    n += n7;
                                }
                                default: {
                                    n6 = n8;
                                }
                            }
                        }
                    }
                    continue block8;
                }
                case 119: {
                    n2 <<= n;
                }
            }
        }
        long l2 = (long)n + l + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d) + (long)n7;
        dMeth_check_sum += l2;
        return l2;
    }

    public void vMeth(int n, byte by) {
        int n2 = 35108;
        int n3 = 4681;
        int n4 = -184;
        int n5 = 109;
        int n6 = 90;
        int n7 = -4;
        int[] nArray = new int[400];
        boolean bl = false;
        float f = -45.98f;
        short[] sArray = new short[400];
        FuzzerUtils.init(nArray, -21917);
        FuzzerUtils.init(sArray, (short)7118);
        n = -this.iArrFld[10][(n >>> 1) % 400];
        switch (((int)(instanceCount - -122L) >>> 1) % 7 + 101) {
            case 101: {
                n2 = 1;
                do {
                    n *= n;
                    for (n3 = 1; n3 < 12; ++n3) {
                        int[] nArray2 = this.iArrFld[n2 + 1];
                        int n8 = n2 + 1;
                        int n9 = nArray2[n8];
                        nArray2[n8] = n9 + 1;
                        n >>>= n9;
                        for (n5 = 1; 2 > n5; ++n5) {
                            int[] nArray3 = this.iArrFld[n5];
                            int n10 = n5;
                            int n11 = nArray3[n10] - 1;
                            nArray3[n10] = n11;
                            n = n11;
                            int n12 = n5 - 1;
                            lArrFld[n12] = lArrFld[n12] + lFld++;
                            n -= (int)this.dMeth(n3, instanceCount, iFld);
                            iFld -= (int)instanceCount;
                            if (bl) continue;
                            lFld += (long)(n5 | n7);
                            n6 = -42613;
                            this.iArrFld[n5][n3 + 1] = 1923122714;
                        }
                    }
                } while (++n2 < 129);
                break;
            }
            case 102: {
                int n13 = (n7 >>> 1) % 400;
                lArrFld[n13] = lArrFld[n13] - (long)n3;
                break;
            }
            case 103: {
                n7 &= iFld;
            }
            case 104: {
                sArray[(Test.iFld >>> 1) % 400] = (short)n4;
            }
            case 105: {
                n4 += n;
            }
            case 106: {
                n7 = n;
                break;
            }
            case 107: {
                n7 -= by;
            }
            default: {
                f -= (float)n7;
            }
        }
        vMeth_check_sum += (long)(n + by + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0) + n7 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(sArray);
    }

    public void mainTest(String[] stringArray) {
        float f = 104.706f;
        float f2 = 0.712f;
        int n = -116;
        int n2 = 6;
        int n3 = -30510;
        int n4 = -41;
        int n5 = -311;
        int n6 = 45774;
        int n7 = 149;
        int n8 = 7;
        int n9 = 177;
        int n10 = 66;
        int n11 = -13;
        boolean bl = false;
        this.vMeth(0, byFld);
        for (int n12 : this.iArrFld1) {
            iFld = (int)lFld;
            iFld = n12;
            int n13 = (iFld >>> 1) % 400;
            this.iArrFld1[n13] = this.iArrFld1[n13] >> -11301;
            f = lFld;
            sFld = (short)(sFld - (short)instanceCount);
            iFld *= iFld;
            this.iArrFld[(Test.iFld >>> 1) % 400][45] = iFld;
            iFld = this.iFld1;
            n = 1;
            while (++n < 63 && !bl) {
                this.iFld1 = n;
                f = (float)dFld;
            }
        }
        this.iArrFld[(this.iFld1 >>> 1) % 400][(Test.iFld >>> 1) % 400] = iFld;
        iFld += iFld;
        iFld <<= byFld;
        for (n2 = 5; 257 > n2; ++n2) {
            for (n4 = 4; n4 < 100; ++n4) {
                for (n6 = 1; n6 < 2; ++n6) {
                    f2 += (float)((long)n6 | (long)f);
                    instanceCount = (long)((float)instanceCount + ((float)n6 * fFld + (float)n6 - (float)n3));
                }
                n3 += 33846;
                for (n8 = 2; n8 > 1; --n8) {
                    n7 += (int)(23.539f + (float)(n8 * n8));
                }
                n9 <<= n;
            }
            byFld = (byte)(byFld + (byte)(n2 | n5));
            for (n10 = 6; n10 < 100; ++n10) {
                try {
                    n9 = this.iFld1 % 204;
                    n9 = n11 / 44138;
                    n5 = iFld / n9;
                    continue;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
            }
        }
        FuzzerUtils.out.println("f3 i22 b2 = " + Float.floatToIntBits(f) + "," + n + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i23 i24 i25 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i26 i27 i28 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("f4 i29 i30 = " + Float.floatToIntBits(f2) + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i31 i32 = " + n10 + "," + n11);
        FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.iFld = " + instanceCount + "," + lFld + "," + iFld);
        FuzzerUtils.out.println("Test.byFld Test.sFld iFld1 = " + byFld + "," + sFld + "," + this.iFld1);
        FuzzerUtils.out.println("Test.dFld Test.fFld iArrFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.lArrFld byArrFld iArrFld1 = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld1));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 12L);
        vMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

