/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -5L;
    public int iFld = 143;
    public static int iFld1 = -25963;
    public static float fFld = 2.984f;
    public static long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = 79;
        int n2 = 14;
        int n3 = 184;
        int n4 = 68;
        int n5 = -63;
        int[] nArray = new int[400];
        boolean bl = true;
        long l = 57L;
        FuzzerUtils.init(nArray, -7090);
        block7: for (n = 11; n < 336; ++n) {
            n2 += n * n;
            if (n != 0) {
                vMeth1_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + n4) + l + (long)n5 + FuzzerUtils.checkSum(nArray);
                return;
            }
            nArray[n + 1] = n;
            n2 = 127;
            switch (n % 5 * 5 + 116) {
                case 133: {
                    if (bl) continue block7;
                    block8: for (n3 = 1; n3 < 5; ++n3) {
                        for (l = (long)n; 2L > l; ++l) {
                            n4 = (int)l;
                            if ((n2 += (int)instanceCount) != 0) {
                                vMeth1_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + n4) + l + (long)n5 + FuzzerUtils.checkSum(nArray);
                                return;
                            }
                            n4 += (int)(l * (long)n2 + (long)n - (long)n4);
                            if (bl) continue block8;
                        }
                    }
                    continue block7;
                }
                case 128: {
                    continue block7;
                }
                case 131: {
                    n2 ^= 0xFFFFFF31;
                    continue block7;
                }
                case 141: {
                    int n6 = n + 1;
                    nArray[n6] = nArray[n6] + -13728;
                }
                case 140: {
                    continue block7;
                }
                default: {
                    nArray[n] = (int)instanceCount;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + n4) + l + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth() {
        int n = 23;
        int n2 = 46095;
        int n3 = -27211;
        int n4 = -9;
        int n5 = 222;
        int n6 = -36752;
        int[] nArray = new int[400];
        boolean bl = false;
        float f = -20.36f;
        int n7 = -104;
        FuzzerUtils.init(nArray, 3);
        for (n = 6; 180 > n; ++n) {
            Test.vMeth1();
            int n8 = n + 1;
            nArray[n8] = nArray[n8] * n;
            instanceCount <<= n;
            if (bl) continue;
            for (n3 = 1; n3 < 9; n3 += 3) {
                nArray[n + 1] = n4;
                f *= f;
            }
            n2 += n3;
        }
        for (n5 = 6; n5 < 140; ++n5) {
            int n9 = -1947;
            instanceCount += (long)n5 | instanceCount;
            if (bl) {
                instanceCount <<= n7;
                n2 = (int)((long)n2 + ((long)n5 ^ (long)f));
                n7 = (byte)n5;
                continue;
            }
            f += (float)((long)(n5 * n9 + n5) - instanceCount);
        }
        vMeth_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(int n) {
        int n2 = -233;
        int n3 = -131;
        int n4 = -36580;
        int[][] nArray = new int[400][400];
        float f = -58.967f;
        int n5 = 83;
        long l = -9L;
        boolean bl = false;
        int n6 = 15254;
        FuzzerUtils.init(nArray, 0);
        Test.vMeth();
        n2 = 1;
        do {
            n3 -= n2;
        } while (++n2 < 246);
        n -= (int)f;
        int[] nArray2 = nArray[(n3 >>> 1) % 400];
        int n7 = (n3 >>> 1) % 400;
        nArray2[n7] = nArray2[n7] & (int)instanceCount;
        n4 = 1;
        while (++n4 < 133) {
            n5 = (byte)n4;
            if (n != 0) {
                // empty if block
            }
            n >>= n4;
            l = 1L;
            while (++l < 12L) {
                n3 += (int)l;
                n3 -= n6;
                int[] nArray3 = nArray[(n >>> 1) % 400];
                int n8 = (int)(l - 1L);
                nArray3[n8] = nArray3[n8] & n;
                nArray[(int)(l - 1L)] = nArray[(int)l];
            }
        }
        long l2 = (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5) + l + (long)(bl ? 1 : 0) + (long)n6 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 8;
        int n2 = -226;
        int n3 = -3;
        int n4 = 8371;
        int[] nArray = new int[400];
        long l = -9170598587590241171L;
        int n5 = 24302;
        float f = 0.728f;
        float[] fArray = new float[400];
        boolean bl = true;
        FuzzerUtils.init(fArray, -1.1015f);
        FuzzerUtils.init(nArray, -13);
        n = 1;
        block15: while ((n += 2) < 364) {
            n2 -= (int)((float)Math.min((int)(2.605f + (92.597f + (float)(n + n))), n2) + fArray[n]);
            if (bl) {
                n2 = Test.iMeth(n);
                switch (n % 4 * 5 + 99) {
                    case 100: {
                        instanceCount -= (long)n2;
                        n2 = n;
                        continue block15;
                    }
                    case 110: {
                        instanceCount += (long)n ^ instanceCount;
                        this.iFld = 39826;
                        instanceCount *= (long)this.iFld;
                        continue block15;
                    }
                }
                this.iFld = this.iFld;
                for (l = (long)n; 138L > l; ++l) {
                    iFld1 -= 1482667220;
                    this.iFld = n5;
                    block17: for (f = (float)n; f < 1.0f; f += 1.0f) {
                        instanceCount -= instanceCount;
                        fFld += (float)n2;
                        n3 = 0;
                        switch ((int)(f % 9.0f * 5.0f + 63.0f)) {
                            case 84: {
                                n3 *= n;
                                continue block17;
                            }
                            case 77: {
                                Test.lArrFld[(int)f] = iFld1;
                                continue block17;
                            }
                            case 102: {
                                n4 -= (int)instanceCount;
                                iFld1 += (int)instanceCount;
                                n2 += (int)f;
                                continue block17;
                            }
                            case 87: {
                                n3 >>= 214;
                                n2 >>= this.iFld;
                                continue block17;
                            }
                            case 86: {
                                n4 *= 214;
                                continue block17;
                            }
                            case 88: {
                                instanceCount -= l;
                            }
                            case 95: {
                                n4 += 66;
                            }
                            case 71: {
                                instanceCount += (long)(f * (float)this.iFld);
                                continue block17;
                            }
                            case 94: {
                                this.iFld = (int)((float)this.iFld + (-81.0f + f * f));
                            }
                        }
                    }
                }
                continue;
            }
            nArray[n - 1] = (int)instanceCount;
        }
        FuzzerUtils.out.println("i i1 l2 = " + n + "," + n2 + "," + l);
        FuzzerUtils.out.println("i19 s2 f2 = " + n3 + "," + n5 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i20 b3 fArr = " + n4 + "," + (bl ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.iFld1 = " + instanceCount + "," + this.iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.fFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 32608L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

