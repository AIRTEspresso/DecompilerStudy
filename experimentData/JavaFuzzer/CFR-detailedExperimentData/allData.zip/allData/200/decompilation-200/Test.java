/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 3677L;
    public static volatile boolean bFld = false;
    public static int iFld = 37466;
    public int iFld1 = 39050;
    public static volatile int[] iArrFld = new int[400];
    public float[] fArrFld = new float[400];
    public volatile long[] lArrFld = new long[400];
    public static long vSmallMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        double d = 2.6701;
        int n2 = -28;
        int n3 = -121;
        int n4 = 124;
        int n5 = -67;
        int n6 = 7;
        float f = 0.524f;
        float[] fArray = new float[400];
        int n7 = -31039;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-7701);
        FuzzerUtils.init(fArray, 0.4f);
        if (bFld) {
            n -= 2;
            for (int n8 : iArrFld) {
                d -= (double)n2;
                try {
                    n %= n8;
                    n8 /= n;
                    n8 = 89 / n8;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                block8: for (n3 = 1; n3 < 4; ++n3) {
                    if (bFld) continue;
                    switch ((n >>> 1) % 3 + 79) {
                        case 79: {
                            n = (int)instanceCount;
                        }
                        case 80: {
                            for (n5 = n3; n5 < 2; ++n5) {
                                instanceCount = (long)((float)instanceCount + ((float)n5 * f + (float)n7 - (float)n));
                                Test.iArrFld[n3 + 1] = (int)(instanceCount *= (long)f);
                                int n9 = n3 + 1;
                                sArray[n9] = (short)(sArray[n9] - (short)n6);
                                int n10 = n3 - 1;
                                iArrFld[n10] = iArrFld[n10] + (int)f;
                            }
                            continue block8;
                        }
                        case 81: {
                            n8 += n3 ^ n5;
                            continue block8;
                        }
                        default: {
                            instanceCount = 450198295L;
                        }
                    }
                }
            }
            vMeth1_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + FuzzerUtils.checkSum(sArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
            return;
        }
        if (bFld) {
            iArrFld[257] = iArrFld[257] + 1;
        } else {
            n6 += n4;
        }
        vMeth1_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + FuzzerUtils.checkSum(sArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth(int n, int n2) {
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 244L);
        Test.vMeth1(n2);
        instanceCount -= instanceCount;
        int n3 = (n >>> 1) % 400;
        lArray[n3] = lArray[n3] + (long)n2;
        lArray[(n2 >>> 1) % 400] = instanceCount;
        vMeth_check_sum += (long)(n + n2) + FuzzerUtils.checkSum(lArray);
    }

    public static void vSmallMeth(int n, int n2, short s) {
        Test.vMeth(n2, -52028);
        vSmallMeth_check_sum += (long)((n >>>= n2) + n2 + s);
    }

    public void mainTest(String[] stringArray) {
        int n = -35318;
        int n2 = -185;
        int n3 = 46;
        int n4 = -9;
        int n5 = 159;
        int n6 = 4;
        int n7 = -8;
        short s = -30473;
        double d = -2.117285;
        float f = -82.563f;
        long l = 10L;
        for (int i = 0; i < 158; ++i) {
            Test.vSmallMeth(n, n, s);
        }
        instanceCount = n;
        for (n2 = 13; n2 < 248; ++n2) {
            n = n3;
            n3 /= n | 1;
            n4 = 3;
            while (n4 < 107) {
                switch ((n >>> 1) % 1 + 41) {
                    case 41: {
                        n += (int)d;
                        n3 += n4;
                        break;
                    }
                    default: {
                        this.fArrFld[n4] = n4;
                        f += (float)(n4 * n5 + n - n5);
                    }
                }
                n3 <<= -59098;
                n = n2;
                for (n6 = 1; n6 < 2; ++n6) {
                    l += instanceCount;
                    d = n;
                    bFld = true;
                    f = n;
                    instanceCount &= (long)(n7 -= n3);
                    try {
                        n5 = iArrFld[n2 - 1] % -36362;
                        iFld = -8115 / n2;
                        n5 = -1 % n;
                        continue;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                n3 = 57453;
                int n8 = n4++;
                this.lArrFld[n8] = this.lArrFld[n8] * (long)n;
                n5 += (int)l;
            }
            int n9 = n2 + 1;
            iArrFld[n9] = iArrFld[n9] & n5;
            instanceCount >>= 14;
            l += (long)(n2 | n3);
            n = n5;
            n3 *= 63470;
        }
        FuzzerUtils.out.println("i10 s2 i11 = " + n + "," + s + "," + n2);
        FuzzerUtils.out.println("i12 i13 i14 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("d1 f2 i15 = " + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f) + "," + n6);
        FuzzerUtils.out.println("i16 l = " + n7 + "," + (l ^= (long)n3));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + iFld);
        FuzzerUtils.out.println("iFld1 Test.iArrFld fArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -6);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

