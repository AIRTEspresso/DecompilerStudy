/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2034554388294346798L;
    public static volatile int iFld = 54234;
    public static double dFld = -1.29473;
    public static boolean bFld = false;
    public static int[] iArrFld = new int[400];
    public static short[] sArrFld = new short[400];
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2, int n3) {
        int n4 = -14;
        int n5 = 14944;
        int n6 = -6838;
        int n7 = 64016;
        int n8 = -10;
        int n9 = -60950;
        int n10 = -4;
        double d = 14.66578;
        int n11 = 34;
        float f = 2.271f;
        for (n4 = 236; n4 > 4; --n4) {
            for (n6 = 1; n6 < 7; ++n6) {
                if (iFld != 0) {
                    vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + Double.doubleToLongBits(d) + (long)n11 + (long)n8 + (long)n9 + (long)n10 + (long)Float.floatToIntBits(f);
                    return;
                }
                instanceCount -= (long)n7;
                instanceCount *= instanceCount;
            }
            instanceCount = (long)d;
            n11 = (byte)d;
        }
        Test.sArrFld[26] = (short)n;
        n8 = 1;
        while (++n8 < 380) {
            n5 = n6;
            for (n9 = 1; 4 > n9; ++n9) {
                instanceCount = (long)d;
                int n12 = n8;
                iArrFld[n12] = iArrFld[n12] * n8;
                f *= 2.819f;
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + Double.doubleToLongBits(d) + (long)n11 + (long)n8 + (long)n9 + (long)n10 + (long)Float.floatToIntBits(f);
    }

    public static void vMeth1(int n) {
        int n2 = 62902;
        int n3 = -60;
        int n4 = -218;
        int n5 = -217;
        int n6 = 2938;
        int n7 = 36;
        int[] nArray = new int[400];
        float f = 109.65f;
        float[] fArray = new float[400];
        boolean bl = false;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 2.125508);
        FuzzerUtils.init(fArray, -1.429f);
        FuzzerUtils.init(nArray, -44480);
        for (n2 = 8; n2 < 277; ++n2) {
            int n8 = n2;
            iArrFld[n8] = iArrFld[n8] * (int)Long.reverseBytes(++instanceCount);
            Test.vMeth2(n, n, n);
            iFld += n2;
            int n9 = n2 - 1;
            iArrFld[n9] = iArrFld[n9] + n3;
            instanceCount *= (long)n2;
            n += n3;
            block14: for (n4 = 1; 6 > n4; ++n4) {
                n = n4;
                switch (n4 % 10 * 5 + 93) {
                    case 112: 
                    case 141: {
                        int n10 = n4 + 1;
                        dArray[n10] = dArray[n10] / (double)(instanceCount | 1L);
                        continue block14;
                    }
                    case 122: {
                        for (n6 = n4; n6 < 2; ++n6) {
                            Test.lArrFld[352] = instanceCount;
                            n7 = n4;
                            instanceCount += (long)n6 ^ instanceCount;
                        }
                        continue block14;
                    }
                    case 120: {
                        if (n3 == 0) continue block14;
                        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f) + (bl ? 1 : 0)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
                        return;
                    }
                    case 105: {
                        int n11 = n4 + 1;
                        fArray[n11] = fArray[n11] + (float)n6;
                        continue block14;
                    }
                    case 135: {
                        n7 = (int)((long)n7 + ((long)n4 ^ (long)f));
                        continue block14;
                    }
                    case 109: {
                        try {
                            iFld = 12524 % n2;
                            n5 = iFld % n;
                            Test.iArrFld[n2] = -114 % iArrFld[n2 - 1];
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                    case 123: {
                        iArrFld = nArray;
                        continue block14;
                    }
                    case 102: {
                        if (bl) continue block14;
                    }
                    case 103: {
                        int n12 = n2;
                        lArrFld[n12] = lArrFld[n12] * (long)n7;
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f) + (bl ? 1 : 0)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(float f, int n, int n2) {
        int n3 = 191;
        int n4 = -206;
        int n5 = 141;
        int n6 = -3;
        boolean bl = false;
        int n7 = -13;
        Test.vMeth1(n2);
        n2 = (int)dFld;
        block0: for (n3 = 2; 166 > n3; ++n3) {
            int n8 = -14529;
            f = -57754.0f;
            n8 = (short)(n8 + (short)((long)n3 * (instanceCount += 37L) + (long)n3 - (long)n2));
            for (n5 = 10; n5 > n3; n5 -= 2) {
                n2 = n4 += n5 | n3;
                if (bl) continue block0;
                n7 = 115;
                n -= (int)instanceCount;
                n4 = (int)instanceCount;
                n6 -= 1113893104;
                iFld = (int)((float)iFld + ((float)n5 - f));
            }
        }
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0) + n7);
    }

    public void mainTest(String[] stringArray) {
        double d = -69.29982;
        int n = 0;
        int n2 = -137;
        int n3 = -10;
        int n4 = -6323;
        int n5 = 38814;
        int n6 = -36987;
        int n7 = -67;
        int n8 = 22345;
        int n9 = -13;
        int n10 = 8;
        int[][] nArray = new int[400][400];
        float f = -4.442f;
        long l = -36101L;
        FuzzerUtils.init(nArray, 3);
        d -= (double)iFld;
        block0: for (n = 12; n < 196; ++n) {
            n2 = n2--;
            Test.vMeth(f, iFld, n);
            iArrFld = FuzzerUtils.int1array(400, 6);
            instanceCount = n;
            for (n3 = 7; n3 < 136; ++n3) {
            }
            for (l = 1L; l < 136L; ++l) {
                n5 += (int)f;
                iFld += n3;
                instanceCount <<= n;
                if (bFld) continue block0;
                n2 = iFld -= (int)d;
            }
        }
        for (n6 = 348; n6 > 6; n6 -= 2) {
            n2 *= (int)instanceCount;
            Test.iArrFld[n6 + 1] = (int)instanceCount;
            if (bFld) {
                for (n8 = 1; n8 < 147; ++n8) {
                    iFld = n3;
                    n7 -= (int)instanceCount;
                    n10 = 2;
                    do {
                        --instanceCount;
                        instanceCount += (long)n6;
                        n4 += n10;
                    } while (--n10 > 0);
                    iFld = (int)l;
                }
                continue;
            }
            n2 += n6 - n5;
        }
        FuzzerUtils.out.println("d i i1 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("f3 i26 i27 = " + Float.floatToIntBits(f) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("l i28 i29 = " + l + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i30 i31 i32 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i33 iArr1 = " + n10 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.bFld Test.iArrFld Test.sArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -52);
        FuzzerUtils.init(sArrFld, (short)22622);
        FuzzerUtils.init(lArrFld, -1L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

