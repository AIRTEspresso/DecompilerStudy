/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -60085L;
    public static byte byFld = (byte)-3;
    public static float fFld = 125.127f;
    public static double dFld = -2.2675;
    public static int iFld = 12;
    public boolean bFld = true;
    public static short sFld = (short)22065;
    public static float[] fArrFld = new float[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2) {
        double d = -1.69204;
        int n3 = 5;
        int n4 = -1;
        int n5 = -184;
        int n6 = -17594;
        int n7 = -61718;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 21259);
        d = 1.0;
        while (true) {
            double d2;
            d += 1.0;
            if (!(d2 < 137.0)) break;
            n2 >>= n;
            instanceCount += (long)n;
        }
        block9: for (n3 = 219; 2 < n3; --n3) {
            switch (n3 % 6 * 5 + 99) {
                case 120: {
                    instanceCount += (long)(42248 + n3 * n3);
                    instanceCount ^= instanceCount;
                    n5 = 1;
                    do {
                        for (n6 = 1; n6 < 3; ++n6) {
                            dFld *= 9.0;
                            n2 += n6 * n;
                            n2 -= (int)(fFld -= (float)(n += 182));
                        }
                    } while ((n5 += 2) < 7);
                    instanceCount &= 0xFFFFFFFFFFFFFFDDL;
                    continue block9;
                }
                case 118: {
                    dFld += -14589.0;
                }
                case 105: {
                    fFld = n7;
                    continue block9;
                }
                case 117: {
                    n += 232;
                    continue block9;
                }
                case 100: {
                    nArray[n3] = n7;
                    continue block9;
                }
                case 111: {
                    instanceCount -= 0L;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n) {
        int n2 = -12;
        int n3 = -133;
        int n4 = 4;
        int n5 = 158;
        int n6 = -47214;
        int n7 = 0;
        int n8 = -6;
        int[] nArray = new int[400];
        boolean bl = false;
        float f = 1.405f;
        float[][][] fArray = new float[400][400][400];
        int n9 = 14175;
        long[] lArray = new long[400];
        long[][][] lArray2 = new long[400][400][400];
        FuzzerUtils.init(nArray, 135);
        FuzzerUtils.init(lArray, -1392964188L);
        FuzzerUtils.init((Object[][])lArray2, (Object)-1046417596L);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(-96.943f));
        byte by = byFld;
        byFld = (byte)(by + 1);
        instanceCount += (long)(n - by);
        n2 = 1;
        while (++n2 < 232) {
            switch (n2 + 117) {
                case 117: {
                    n = (int)(--instanceCount);
                    for (n3 = 1; n3 < 7; ++n3) {
                        instanceCount *= (long)((float)(instanceCount + (long)(n4 += n3) + (long)(n3 + n2)) - ((float)instanceCount - 2.689f - fFld));
                        Test.vMeth1(n4, -8536);
                        dFld += (double)n2;
                        for (n5 = n3; n5 < 2 && !bl; ++n5) {
                            byFld = (byte)-22;
                        }
                        for (f = (float)n2; f < 2.0f; f += 1.0f) {
                            fFld += f * (float)instanceCount;
                            n4 += (int)(f - (float)n4);
                        }
                    }
                    break;
                }
                case 118: {
                    instanceCount %= (long)(n4 | 1);
                    break;
                }
                case 119: {
                    instanceCount = n3;
                    break;
                }
                case 120: {
                    instanceCount >>= n3;
                    break;
                }
                case 121: 
                case 122: {
                    break;
                }
                case 123: {
                    n4 = n5;
                    break;
                }
                case 124: {
                    n = (int)((long)n + ((long)(n2 * n) + instanceCount - (long)n6));
                    break;
                }
                case 125: {
                    fFld += f;
                    break;
                }
                case 126: {
                    break;
                }
                case 127: {
                    n6 = n3;
                }
                case 128: {
                    instanceCount = n2;
                }
                case 129: {
                    try {
                        n6 = -45037 / nArray[(n3 >>> 1) % 400];
                        n7 = n4 % 48939;
                        n7 = -25073 % n6;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    break;
                }
                case 130: {
                    fFld += (float)n2;
                    break;
                }
                case 131: {
                    int n10 = n2 - 1;
                    nArray[n10] = nArray[n10] + n4;
                }
                case 132: {
                    int n11 = n2 + 1;
                    nArray[n11] = nArray[n11] << n5;
                    break;
                }
                case 133: {
                    int n12 = n2 - 1;
                    lArray[n12] = lArray[n12] * (long)n5;
                    break;
                }
                case 134: {
                    dFld = instanceCount;
                    break;
                }
                case 135: {
                    n += n2;
                    break;
                }
                case 136: {
                    if (!bl) break;
                    break;
                }
                case 137: {
                    if (bl) break;
                }
                case 138: {
                    n = n6;
                }
                case 139: {
                    n4 >>= n4;
                    break;
                }
                case 140: {
                    break;
                }
                case 141: {
                    n *= 1;
                    break;
                }
                case 142: {
                    n8 *= n2;
                }
                case 143: {
                    n6 ^= n6;
                    break;
                }
                case 144: {
                    try {
                        n6 = 54 / n5;
                        nArray[n2] = n6 % -34365;
                        n8 = nArray[n2 - 1] % 170;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    break;
                }
                case 145: {
                    n6 >>>= n4;
                    break;
                }
                case 146: {
                    fFld += (float)(1L + (long)(n2 * n2));
                    break;
                }
                case 147: {
                    n7 -= n7;
                }
                case 148: 
                case 149: {
                    n4 = n2;
                    break;
                }
                case 150: {
                    byFld = (byte)4;
                    break;
                }
                case 151: {
                    break;
                }
                case 152: {
                    n4 *= 94;
                    break;
                }
                case 153: {
                    n6 = (int)instanceCount;
                    break;
                }
                case 154: {
                    n -= n7;
                    break;
                }
                case 155: {
                    dFld += (double)instanceCount;
                    break;
                }
                case 156: {
                    nArray[n2 - 1] = (int)instanceCount;
                }
                case 157: {
                    n6 += n2 * n2;
                    break;
                }
                case 158: {
                    break;
                }
                case 159: {
                    n4 += n7;
                    break;
                }
                case 160: {
                    n7 = (int)((long)n7 + ((long)n2 - instanceCount));
                    break;
                }
                case 161: {
                    instanceCount += (long)(n2 * n3 + n2 - n3);
                }
                case 162: {
                    dFld -= (double)n;
                    break;
                }
                case 163: {
                    instanceCount -= (long)dFld;
                }
                case 164: {
                    n8 -= n8;
                }
                case 165: {
                    n7 %= (int)(instanceCount | 1L);
                    break;
                }
                case 166: {
                    n9 = (short)(n9 + (short)instanceCount);
                    break;
                }
                case 167: {
                    nArray[n2 + 1] = -7;
                    break;
                }
                case 168: {
                    instanceCount = iFld;
                    break;
                }
                case 169: 
                case 170: {
                    lArray2[n2 - 1][n2] = FuzzerUtils.long1array(400, -212L);
                    break;
                }
                case 171: {
                    iFld -= n;
                }
                case 172: {
                    n = n7;
                    break;
                }
                case 173: {
                    instanceCount += instanceCount;
                    break;
                }
                case 174: {
                    instanceCount *= (long)n7;
                    break;
                }
                case 175: {
                    n4 = (int)((long)n4 + (long)n2 * instanceCount);
                    break;
                }
                case 176: {
                    n8 = -34;
                    break;
                }
                case 177: {
                    n8 = (int)instanceCount;
                    break;
                }
                case 178: {
                    break;
                }
                case 179: {
                    n7 *= (int)f;
                    break;
                }
                case 180: 
                case 181: {
                    iFld += n5;
                }
                case 182: {
                    n += n2 ^ n8;
                    break;
                }
                case 183: 
                case 184: {
                    iFld >>= n2;
                    break;
                }
                case 185: {
                    instanceCount += (long)n;
                    break;
                }
                case 186: {
                    instanceCount += (long)(n2 + n8);
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0) + Float.floatToIntBits(f) + n7 + n8 + n9) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum((Object[][])lArray2) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray));
    }

    public int iMeth(long l, int n, short s) {
        int n2 = -8;
        int n3 = -4;
        int n4 = 14;
        int n5 = 24;
        int n6 = -34437;
        int[] nArray = new int[400];
        double d = -1.19643;
        FuzzerUtils.init(nArray, 7);
        for (n2 = 189; n2 > 10; n2 -= 3) {
            float f;
            float f2 = f = 1.885f;
            f += 1.0f;
            f = f2 - ((float)(--n3 + (n - n2)) - f);
            for (d = (double)n2; d < 26.0; d += 1.0) {
                Test.vMeth(n4);
                byFld = (byte)(byFld - (byte)n2);
                n += (int)d;
                for (n5 = 1; n5 < 1; ++n5) {
                    int n7 = n2;
                    nArray[n7] = nArray[n7] + (int)d;
                    n3 = n4;
                    this.bFld = false;
                    n += n5 * n6 + n3 - byFld;
                    instanceCount = iFld;
                    dFld = iFld;
                    byFld = (byte)(byFld + (byte)(207 + n5 * n5));
                }
            }
        }
        long l2 = l + (long)n + (long)s + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -157;
        int n2 = 101;
        int n3 = 4;
        int n4 = -93;
        int n5 = -20696;
        int n6 = 6;
        int n7 = -118;
        int n8 = 25946;
        int n9 = 12196;
        int n10 = -7197;
        int[] nArray = new int[400];
        long l = -61015L;
        FuzzerUtils.init(nArray, -64688);
        for (n = 3; n < 239; ++n) {
            for (n3 = 1; n3 < 106; ++n3) {
                n4 = this.iMeth(-6L, n3, sFld) * n4;
                n2 = (int)instanceCount;
                l = 2L;
                while (--l > 0L) {
                    iFld ^= 0xC824C242;
                    instanceCount -= (long)n;
                    n4 = (int)dFld;
                    fFld = n5 *= n3;
                    iFld = n4;
                    instanceCount -= (long)n2;
                    instanceCount -= (long)n5;
                    instanceCount -= (long)n5;
                }
                for (n6 = 1; n6 < 2; n6 += 3) {
                    n4 %= byFld | 1;
                    n5 += n6 ^ iFld;
                }
                n4 = n6;
                instanceCount *= (long)fFld;
            }
            n7 = (int)((float)n7 + ((float)((long)(n * n7) + l) - fFld));
            n2 += n4;
            int n11 = n;
            fArrFld[n11] = fArrFld[n11] + -9.0f;
            n8 = 1;
            do {
                n2 += n8;
                switch (93) {
                    case 91: {
                        iFld = n2;
                        for (n9 = n; n9 < 1; ++n9) {
                            n7 += n9 * n3;
                            n7 += n6;
                            nArray[n9 - 1] = n;
                        }
                    }
                    case 93: {
                        n2 *= sFld;
                    }
                }
            } while (++n8 < 106);
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 l1 i26 = " + n4 + "," + l + "," + n5);
        FuzzerUtils.out.println("i27 i28 i29 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i30 i31 iArr3 = " + n9 + "," + n10 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.dFld Test.iFld bFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld Test.fArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 42.749f);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

