/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -54790L;
    public static int iFld = -3069;
    public short sFld = (short)26871;
    public static byte byFld = (byte)29;
    public static float fFld = 6.198f;
    public static short sFld1 = (short)30345;
    public static boolean bFld = true;
    public static double dFld = -43.102962;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(float f) {
        int n = 13641;
        int n2 = 2218;
        int n3 = 3;
        int n4 = -32055;
        n = 7;
        while (n < 135) {
            int n5 = n++;
            iArrFld[n5] = iArrFld[n5] - n2;
            n3 <<= (iFld += n4);
        }
        Test.iArrFld[(n2 >>> 1) % 400] = iFld;
        instanceCount -= instanceCount;
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n4 + (n3 += 8738));
    }

    public static void vMeth(int n) {
        float f = 0.272f;
        int n2 = 1;
        int n3 = -6;
        int n4 = -14;
        int n5 = 31108;
        int n6 = 8;
        int n7 = 146;
        Test.vMeth1(f);
        f += (float)(n ^= 3);
        for (n2 = 211; n2 > 13; --n2) {
            int n8 = n2 - 1;
            iArrFld[n8] = iArrFld[n8] | n;
            n3 = (int)instanceCount;
            if (n != 0) {
                vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7);
                return;
            }
            for (n4 = n2; 8 > n4; ++n4) {
                Test.iArrFld[n4 - 1] = n3 /= byFld | 1;
                f = n4;
                n3 >>= (int)instanceCount;
            }
        }
        for (n6 = 1; n6 < 238; ++n6) {
            iFld += n6 ^ n7;
            int n9 = n6 - 1;
            iArrFld[n9] = iArrFld[n9] - (int)f;
        }
        vMeth_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7);
    }

    public static long lMeth() {
        int n = 39033;
        int n2 = 237;
        int n3 = -249;
        int n4 = 4844;
        int n5 = 1;
        double d = 2.56475;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, 169L);
        for (n = 10; n < 315; ++n) {
            Test.vMeth(n2);
            block23: for (n3 = 1; n3 < 5; ++n3) {
                instanceCount <<= iFld;
                instanceCount >>>= 133;
                switch (n3 % 10 + 85) {
                    case 85: {
                        n2 = 5;
                    }
                    case 86: {
                        iArrFld = FuzzerUtils.int1array(400, -5);
                        n5 = 1;
                        block24: while (++n5 < 2) {
                            long[] lArray2 = lArray[n3];
                            int n6 = n - 1;
                            lArray2[n6] = lArray2[n6] - (long)d;
                            instanceCount -= (long)n5;
                            switch (n % 8 * 5 + 18) {
                                case 46: {
                                    iFld -= (int)fFld;
                                    n4 = n;
                                    fFld -= 20838.0f;
                                    continue block24;
                                }
                                case 55: {
                                    n2 += n5 * n5;
                                    continue block24;
                                }
                                case 49: {
                                    iFld *= (int)d;
                                }
                                case 47: {
                                    int n7 = n;
                                    iArrFld[n7] = iArrFld[n7] / (iFld | 1);
                                    continue block24;
                                }
                                case 23: {
                                    continue block24;
                                }
                                case 33: {
                                    n2 += n3;
                                }
                                case 31: {
                                    iFld += n5 + sFld1;
                                    continue block24;
                                }
                                case 45: {
                                    iFld = (int)d;
                                    continue block24;
                                }
                            }
                            fFld += (float)n5;
                        }
                        continue block23;
                    }
                    case 87: {
                        if (!bFld) continue block23;
                        continue block23;
                    }
                    case 88: {
                        n2 = (int)((float)n2 + ((float)(n3 * iFld) + fFld - fFld));
                        continue block23;
                    }
                    case 89: {
                        instanceCount &= (long)n2;
                        continue block23;
                    }
                    case 90: {
                        iFld *= n4;
                    }
                    case 91: {
                        n4 += n3 * n3 + byFld - n2;
                        continue block23;
                    }
                    case 92: {
                        instanceCount -= instanceCount;
                    }
                    case 93: {
                        Test.iArrFld[n3 - 1] = n3;
                    }
                    case 94: {
                        continue block23;
                    }
                    default: {
                        long[] lArray3 = lArray[n - 1];
                        int n8 = n + 1;
                        lArray3[n8] = lArray3[n8] >> (int)instanceCount;
                    }
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
        lMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 14536;
        int n2 = 14;
        int n3 = 242;
        int n4 = -9;
        int n5 = 60061;
        int n6 = 56;
        float f = 1.48f;
        float[] fArray = new float[400];
        double[] dArray = new double[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(dArray, -18.122034);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(fArray, -55.61f);
        for (n = 1; n < 269; ++n) {
            if (bFld) {
                for (f = 4.0f; f < 94.0f; f += 1.0f) {
                    for (n4 = (int)f; n4 < 2; ++n4) {
                        int n7 = n;
                        dArray[n7] = dArray[n7] * (double)(Math.abs(n2 - 57207) + iFld);
                        int n8 = (int)f;
                        int n9 = iArrFld[n8] - 1;
                        iArrFld[n8] = n9;
                        this.sFld = (short)(this.sFld % (short)(n9 | 1));
                        if (bFld) {
                            Test.lMeth();
                            n3 = n4;
                            switch ((n2 >>> 1) % 1 + 1) {
                                case 1: {
                                    n5 += n4 | n;
                                    try {
                                        n5 = n4 % n;
                                        n2 = iFld % n4;
                                        iFld = n3 % n2;
                                    }
                                    catch (ArithmeticException arithmeticException) {
                                        // empty catch block
                                    }
                                    blArray[(int)f] = bFld;
                                    instanceCount = 56L;
                                }
                            }
                        }
                        n3 += n;
                        n2 = (int)instanceCount;
                        n2 = n;
                        n3 = (int)instanceCount;
                        Test.iArrFld[n] = iFld;
                        n3 -= (int)instanceCount;
                        iFld = (int)instanceCount;
                    }
                    n2 *= n;
                }
                continue;
            }
            if (bFld) {
                dFld -= (double)instanceCount;
                instanceCount <<= n4;
                continue;
            }
            if (bFld) {
                fArray[n] = n5;
                byFld = (byte)12;
                Test.lArrFld[n + 1] = n;
                continue;
            }
            n6 = 94;
            while (--n6 > 0) {
                instanceCount -= (long)n;
                instanceCount += 76236999L + (long)(n6 * n6);
            }
        }
        FuzzerUtils.out.println("i i1 f = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i2 i3 i4 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i20 dArr bArr = " + n6 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
        FuzzerUtils.out.println("Test.byFld Test.fFld Test.sFld1 = " + byFld + "," + Float.floatToIntBits(fFld) + "," + sFld1);
        FuzzerUtils.out.println("Test.bFld Test.dFld Test.iArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -236);
        FuzzerUtils.init(lArrFld, -54453L);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

