/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -3099474333537191129L;
    public float fFld = 29.269f;
    public double dFld = -57.18327;
    public static volatile float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(int n) {
        double d = -1.13784;
        double d2 = 0.90818;
        long l = 24502L;
        int n2 = 8;
        d = d2;
        for (l = 227L; l > 13L; l -= 3L) {
            n2 -= (n &= (int)l);
        }
        long l2 = (long)n + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + l + (long)n2;
        lMeth_check_sum += l2;
        return l2;
    }

    public static int iMeth(int n, int n2, long l) {
        int n3 = -250;
        int n4 = -22;
        int n5 = -13;
        int n6 = -7;
        int[] nArray = new int[400];
        boolean bl = true;
        float f = 0.893f;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -59938);
        FuzzerUtils.init(lArray, 3282737081295925556L);
        n2 = (int)(instanceCount - (long)n2 + (long)n2 + (long)(n2 + n2) * ((long)n2 - instanceCount));
        n3 = 1;
        while (++n3 < 309) {
            n &= (int)Test.lMeth(n);
            n2 |= n3;
            n2 = -10;
            for (n4 = n3; n4 < 5; ++n4) {
                n6 = 1;
                while (++n6 < 1) {
                    n5 = (int)l;
                    f = n2;
                    if (n5 == 0) continue;
                }
                nArray[n4] = n2;
                n += n6;
                instanceCount += l;
            }
        }
        int n7 = (n6 >>> 1) % 400;
        lArray[n7] = lArray[n7] * (long)n4;
        long l2 = (long)(n + n2) + l + (long)n3 + (long)(bl ? 1 : 0) + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth() {
        float f = 91.443f;
        int n = -3;
        int n2 = -53817;
        int n3 = -4;
        int n4 = -53;
        int n5 = -136;
        int n6 = -1;
        int[] nArray = new int[400];
        double d = 0.46309;
        double d2 = -53.130981;
        double[] dArray = new double[400];
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(dArray, -113.85435);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(nArray, -20971);
        f = Test.iMeth(n, n, instanceCount) + n;
        dArray[(n >>> 1) % 400] = 10105.0;
        for (d = 4.0; 386.0 > d; d += 1.0) {
            for (n3 = 1; n3 < 4; ++n3) {
                d2 -= 5.0;
                instanceCount *= instanceCount;
                instanceCount >>>= (int)instanceCount;
                n4 += (int)(-10L + (long)(n3 * n3));
                for (n5 = 1; n5 < 2; ++n5) {
                    blArray[n5] = bl;
                    f += (float)n4;
                    n4 *= n;
                    n4 += n5 * n5;
                    n = (int)instanceCount;
                }
            }
        }
        int n7 = (n4 >>> 1) % 400;
        nArray[n7] = nArray[n7] << -41926;
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + Double.doubleToLongBits(d2) + (long)n5 + (long)n6 + (long)(bl ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -39671;
        int n2 = -13;
        int n3 = -8;
        int n4 = 143;
        int n5 = -106;
        int n6 = -58827;
        int[][] nArray = new int[400][400];
        boolean bl = true;
        int n7 = -6874;
        double[] dArray = new double[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(dArray, 1.28224);
        FuzzerUtils.init(nArray, -22388);
        FuzzerUtils.init(lArray, 35192L);
        Test.vMeth();
        n = 1;
        block14: while (++n < 160) {
            n2 = 230;
            try {
                n2 %= 209;
                n2 /= n2;
                n2 = n / n2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            if (bl) continue;
            n2 += n;
            switch (n % 10 + 55) {
                case 55: {
                    if (!bl) {
                        int[] nArray2 = nArray[n];
                        int n8 = n - 1;
                        nArray2[n8] = nArray2[n8] - (int)instanceCount;
                        n2 += n - n2;
                    }
                    instanceCount += (long)n7;
                    n3 = 2;
                    while (n3 < 157) {
                        this.fFld += (float)(15667 + n3 * n3);
                        n4 = (int)instanceCount;
                        n4 += n3 * n3;
                        int[] nArray3 = nArray[n3 + 1];
                        int n9 = n3;
                        nArray3[n9] = nArray3[n9] + n;
                        int[] nArray4 = nArray[n3];
                        int n10 = n3++;
                        nArray4[n10] = nArray4[n10] + n;
                        n4 -= n;
                        n5 >>= -19;
                    }
                    continue block14;
                }
                case 56: {
                    n7 = (short)(n7 - 10318);
                    continue block14;
                }
                case 57: {
                    n2 += n5;
                    continue block14;
                }
                case 58: {
                    nArray[n - 1][n] = n2;
                    nArray[n - 1] = nArray[n];
                    n6 = 157;
                    while ((n6 -= 3) > 0) {
                        this.dFld -= (double)n3;
                        n5 = 182;
                        this.fFld += (float)(n6 * n6);
                    }
                    continue block14;
                }
                case 59: {
                    Test.fArrFld[n - 1] = n2;
                }
                case 60: {
                    n4 = (int)((long)n4 + ((long)n * instanceCount + (long)n7 - (long)n));
                    continue block14;
                }
                case 61: {
                    continue block14;
                }
                case 62: {
                    n2 -= (int)instanceCount;
                    continue block14;
                }
                case 63: {
                    n2 = n3;
                    continue block14;
                }
                case 64: {
                    n4 += n;
                    continue block14;
                }
            }
            n7 = (short)(n7 - (short)this.dFld);
        }
        FuzzerUtils.out.println("i14 i15 b2 = " + n + "," + n2 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("s i16 i17 = " + n7 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i18 i19 dArr1 = " + n5 + "," + n6 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("iArr2 lArr1 = " + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount fFld dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, -40.976f);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

