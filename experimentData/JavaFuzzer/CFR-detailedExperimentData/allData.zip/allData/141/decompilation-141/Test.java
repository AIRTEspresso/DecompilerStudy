/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -9019415368366877483L;
    public static volatile boolean bFld = false;
    public static short sFld = (short)10356;
    public static volatile float fFld = 62.337f;
    public volatile int iFld = 13;
    public static int[] iArrFld = new int[400];
    public static long vSmallMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth() {
        int n = -141;
        int n2 = 0;
        int n3 = -16415;
        int n4 = -87;
        int n5 = -40727;
        double d = -77.115893;
        float f = -38.11f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 0L);
        for (int n6 : iArrFld) {
            n6 *= -1;
            n -= (int)instanceCount;
            for (n2 = 1; 4 > n2; ++n2) {
                int n7 = n2 - 1;
                lArray[n7] = lArray[n7] - (long)n3;
                Test.iArrFld[n2 + 1] = 10;
                n >>= (n3 -= (int)d);
                f += (float)n2;
                try {
                    n3 = n2 / n6;
                    n = iArrFld[n2] % n2;
                    n %= 37622;
                    continue;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
            }
            n3 = n6;
            int n8 = (n6 >>> 1) % 400;
            iArrFld[n8] = iArrFld[n8] - -5;
        }
        for (n4 = 21; n4 < 351; ++n4) {
            n >>= -64364;
            n5 -= n2;
        }
        long l = (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth() {
        int n = -112;
        int n2 = -4;
        int n3 = -197;
        int n4 = -3033;
        int n5 = -10711;
        int[][][] nArray = new int[400][400][400];
        int[][] nArray2 = new int[400][400];
        float f = 61.757f;
        double d = 42.8349;
        double d2 = 53.84925;
        FuzzerUtils.init((Object[][])nArray, (Object)9);
        FuzzerUtils.init(nArray2, 5);
        for (n = 294; n > 10; --n) {
            int[] nArray3 = nArray[n][n - 1];
            int n6 = n + 1;
            int n7 = nArray3[n6] - 1;
            nArray3[n6] = n7;
            instanceCount = Math.abs(n7);
            instanceCount = (long)((double)n * (2.0 - -((double)f - d)));
            int[][] nArray4 = FuzzerUtils.int2array(400, -54362);
            nArray2 = nArray4;
            nArray2 = nArray4;
            nArray2 = nArray4;
            nArray2 = nArray4;
            n2 = Test.iMeth();
            f *= f;
        }
        for (d2 = 6.0; 334.0 > d2; d2 += 1.0) {
            n3 *= 5;
            f -= (float)d;
        }
        nArray2[(n3 >>> 1) % 400][(n >>> 1) % 400] = n2;
        n2 = (int)instanceCount;
        for (n4 = 13; n4 < 269; ++n4) {
            f = n3;
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f %= 83.0f)) + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum((Object[][])nArray) + FuzzerUtils.checkSum(nArray2);
    }

    public static void vSmallMeth(int n) {
        Test.vMeth();
        vSmallMeth_check_sum += (long)n;
    }

    public void mainTest(String[] stringArray) {
        int n = -6997;
        int n2 = 3;
        int n3 = 10;
        int n4 = 61748;
        int n5 = 53900;
        int n6 = 199;
        int n7 = -209;
        int n8 = 20174;
        int n9 = -32;
        int n10 = -59;
        int n11 = 44839;
        int n12 = 10857;
        int n13 = 1;
        int n14 = 0;
        int n15 = -49854;
        double d = -1.5458;
        double[][] dArray = new double[400][400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(dArray, -5.52689);
        FuzzerUtils.init(byArray, (byte)-42);
        for (int i = 0; i < 173; ++i) {
            Test.vSmallMeth(n);
        }
        double[] dArray2 = dArray[(n >>> 1) % 400];
        dArray2[359] = dArray2[359] * (double)n;
        for (n2 = 9; n2 < 147; ++n2) {
            for (n4 = 1; 182 > n4; ++n4) {
                instanceCount -= -17L;
                for (n6 = 1; n6 < 2; ++n6) {
                    n7 -= 11199;
                    n = n5;
                    bFld = false;
                    try {
                        n3 = 176 % n3;
                        n8 = -105 % n2;
                        n3 = n2 / -72;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    int n16 = n2 + 1;
                    iArrFld[n16] = iArrFld[n16] + n;
                    n5 += n6 - sFld;
                    n8 = n3;
                }
                if (bFld) break;
                d = n2;
                n5 = (int)fFld;
                n9 = 1;
                do {
                    int n17 = n2 + 1;
                    iArrFld[n17] = iArrFld[n17] - n3;
                    int n18 = n2 + 1;
                    byArray[n18] = (byte)(byArray[n18] + (byte)n);
                } while (++n9 < 2);
                n5 += n4;
            }
            fFld += (float)n4;
        }
        int n19 = (this.iFld >>> 1) % 400;
        iArrFld[n19] = iArrFld[n19] * n6;
        for (n10 = 145; 2 < n10; --n10) {
            block8: for (n12 = n10; 175 > n12; ++n12) {
                for (n14 = 1; n14 < 1; ++n14) {
                    n8 = 42417;
                    if (bFld) continue block8;
                    n += n3;
                    n11 *= (int)instanceCount;
                }
            }
        }
        FuzzerUtils.out.println("i12 i13 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i15 i16 i17 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i18 i19 d3 = " + n7 + "," + n8 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i20 i21 i22 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("i23 i24 i25 = " + n12 + "," + n13 + "," + n14);
        FuzzerUtils.out.println("i26 dArr byArr = " + n15 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.sFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + sFld);
        FuzzerUtils.out.println("Test.fFld iFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -131);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

