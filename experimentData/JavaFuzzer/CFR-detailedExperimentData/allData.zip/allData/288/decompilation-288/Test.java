/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -1648678541L;
    public static float fFld = -41.324f;
    public static byte byFld = (byte)-39;
    public static double dFld = 121.9915;
    public boolean[] bArrFld = new boolean[400];
    public static long[] lArrFld = new long[400];
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;
    public static long lMeth1_check_sum;

    public static long lMeth1(double d, long l) {
        int n = -231;
        int n2 = -100;
        int n3 = -41799;
        int n4 = -11;
        int n5 = 151;
        int n6 = 5;
        int[] nArray = new int[400];
        float f = -2.85f;
        int n7 = 26557;
        boolean bl = true;
        int n8 = 4;
        FuzzerUtils.init(nArray, -193);
        instanceCount -= (long)fFld;
        if (bl) {
            n = 242;
            block0: while (--n > 0) {
                for (f = 1.0f; f < 7.0f; f += 1.0f) {
                    nArray[n + 1] = n2;
                    n2 += (int)(f * (float)n7);
                    for (n3 = 2; n3 > 1; --n3) {
                        n4 *= n;
                        n2 *= -78089762;
                    }
                    if (bl) continue block0;
                    n8 = (byte)(n8 - n8);
                    for (n5 = 1; n5 < 2; ++n5) {
                        n6 -= n2;
                        n2 = n8;
                        n2 *= n3;
                    }
                }
            }
        } else if (bl) {
            n2 += n3;
        } else {
            n6 -= n5;
        }
        long l2 = Double.doubleToLongBits(d) + l + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n7 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n8 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
        lMeth1_check_sum += l2;
        return l2;
    }

    public static int iMeth() {
        int n = 39837;
        int n2 = -21276;
        int n3 = -39748;
        int n4 = -155;
        int n5 = 3;
        int[] nArray = new int[400];
        float f = 0.824f;
        float[] fArray = new float[400];
        boolean bl = true;
        double d = 0.3236;
        int n6 = 10602;
        FuzzerUtils.init(fArray, -2.301f);
        FuzzerUtils.init(nArray, 15339);
        for (n = 3; 168 > n; ++n) {
            block11: for (f = 1.0f; f < 10.0f; f += 1.0f) {
                n2 += (int)(f - (float)n3);
                switch ((int)(f % 8.0f * 5.0f + 96.0f)) {
                    case 120: {
                        n3 = n3++;
                        instanceCount = n3;
                    }
                    case 109: {
                        fArray[n + 1] = Test.lMeth1(d, instanceCount);
                        n2 += (int)(f - f);
                        for (n4 = 1; n4 < 2; ++n4) {
                            fFld -= (float)n5;
                            instanceCount <<= n;
                            n2 += n4 * n4;
                            n2 += 79;
                        }
                    }
                    case 108: {
                        n6 = (short)(n6 * (short)instanceCount);
                        continue block11;
                    }
                    case 121: {
                        fFld += (float)instanceCount;
                        continue block11;
                    }
                    case 106: {
                        continue block11;
                    }
                    case 111: {
                        instanceCount += (long)(f * f);
                        continue block11;
                    }
                    case 117: {
                        fFld += (float)n5;
                    }
                    case 113: {
                        n2 <<= 1;
                    }
                }
            }
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + (bl ? 1 : 0)) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static long lMeth(long l, int n, int n2) {
        long l2 = 1050116900L;
        long[] lArray = new long[400];
        int n3 = 64773;
        int n4 = -2;
        int n5 = -39;
        int n6 = 7;
        int[] nArray = new int[400];
        double d = 0.1193;
        float[] fArray = new float[400];
        FuzzerUtils.init(lArray, -11L);
        FuzzerUtils.init(fArray, -2.631f);
        FuzzerUtils.init(nArray, 190);
        for (l2 = 1L; l2 < 281L; ++l2) {
            block22: for (n4 = 1; n4 < 6; ++n4) {
                int n7 = -61395;
                instanceCount += (long)n4;
                n5 *= n;
                d -= (double)Test.iMeth();
                switch (n4 % 9 + 66) {
                    case 66: {
                        switch ((int)(l2 % 3L * 5L + 73L)) {
                            case 80: {
                                n5 &= n3;
                                if (n != 0) {
                                    // empty if block
                                }
                                n6 = 1;
                                do {
                                    byFld = (byte)(byFld ^ 0xFFFFFFF1);
                                    switch (n4 % 4 + 53) {
                                        case 53: {
                                            int n8 = (int)(l2 + 1L);
                                            lArray[n8] = lArray[n8] - (long)fFld;
                                            n ^= n5;
                                            break;
                                        }
                                        case 54: {
                                            lArray[n4 - 1] = n3;
                                            break;
                                        }
                                        case 55: {
                                            instanceCount = -10L;
                                        }
                                        case 56: {
                                            fArray[n4 + 1] = (float)d;
                                        }
                                        default: {
                                            n3 += n2;
                                        }
                                    }
                                } while (++n6 < 2);
                            }
                            case 85: {
                                n3 = n6;
                                break;
                            }
                            case 79: {
                                n = (int)((long)n + ((long)(n4 * n3 + n4) - l));
                            }
                        }
                        continue block22;
                    }
                    case 67: {
                        n7 &= n6;
                        continue block22;
                    }
                    case 68: {
                        nArray[n4 + 1] = (int)l;
                        continue block22;
                    }
                    case 69: {
                        int n9 = (int)l2;
                        nArray[n9] = nArray[n9] >>> 8;
                        continue block22;
                    }
                    case 70: 
                    case 71: {
                        l = 5104L;
                        continue block22;
                    }
                    case 72: {
                        n2 >>= n4;
                        continue block22;
                    }
                    case 73: {
                        n7 += n4 - n5;
                        continue block22;
                    }
                    case 74: {
                        d -= (double)n;
                    }
                }
            }
        }
        long l3 = l + (long)n + (long)n2 + l2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l3;
        return l3;
    }

    public void mainTest(String[] stringArray) {
        long l = 7044678282479838156L;
        int n = -235;
        int n2 = 4;
        int n3 = 1;
        int n4 = -3;
        int n5 = 22825;
        int n6 = -12;
        int n7 = 127;
        int n8 = 4;
        int n9 = -38749;
        int n10 = -49;
        int[] nArray = new int[400];
        int n11 = -25931;
        boolean bl = false;
        float f = -10.84f;
        FuzzerUtils.init(nArray, -323);
        l = 1L;
        do {
            try {
                n = nArray[(int)l] % n;
                n = 18807 % n;
                n /= n;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        } while (++l < 371L);
        block11: for (n2 = 10; n2 < 382; n2 += 2) {
            n ^= (int)Test.lMeth(l, n, n);
            fFld *= (float)n11;
            this.bArrFld[n2] = bl;
            n3 += n2;
            n3 = n2;
            for (n4 = 2; n4 < 135; ++n4) {
                n3 += n4;
                n3 -= byFld;
            }
            switch (n2 % 7 + 63) {
                case 63: {
                    n += n;
                    n5 += n2 * n2 + n3 - n11;
                    continue block11;
                }
                case 64: 
                case 65: {
                    n3 = 39931;
                    for (n6 = 3; n6 < 135; ++n6) {
                        for (n8 = 1; n8 < 2; ++n8) {
                            n3 <<= n8;
                            lArrFld = FuzzerUtils.long1array(400, -212898003798579950L);
                            n7 = 10280;
                            n /= (int)((long)fFld | 1L);
                        }
                        int n12 = n2;
                        nArray[n12] = nArray[n12] * (int)dFld;
                        f = 1.0f;
                        if (!(2.0f > f)) continue;
                        n -= (int)f;
                        n = (int)((float)n + (-157.0f + f * f));
                    }
                    continue block11;
                }
                case 66: {
                    int n13 = n2;
                    nArray[n13] = nArray[n13] << n3;
                    continue block11;
                }
                case 67: {
                    nArray[n2 - 1] = (int)dFld;
                    continue block11;
                }
                case 68: {
                    fFld += (float)n11;
                    continue block11;
                }
                case 69: {
                    n7 = n4;
                }
            }
        }
        FuzzerUtils.out.println("l i i1 = " + l + "," + n + "," + n2);
        FuzzerUtils.out.println("i2 s2 b2 = " + n3 + "," + n11 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i21 i22 i23 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i24 i25 i26 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("f2 i27 iArr = " + Float.floatToIntBits(f) + "," + n10 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("Test.dFld bArrFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(this.bArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -13528L);
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        lMeth1_check_sum = 0L;
    }
}

