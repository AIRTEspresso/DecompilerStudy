/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 860701209L;
    public int iFld = -6;
    public static double dFld = 112.82618;
    public boolean bFld = false;
    public float fFld = -2.148f;
    public int iFld1 = 61239;
    public short sFld = (short)-16465;
    public static float[] fArrFld = new float[400];
    public static boolean[] bArrFld = new boolean[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(long l, short s, byte by) {
        int n = 116;
        int n2 = 222;
        int n3 = 10809;
        int n4 = 45960;
        int[] nArray = new int[400];
        float f = -1.877f;
        float[] fArray = new float[400];
        double d = -1.76724;
        double d2 = -2.18497;
        short[] sArray = new short[400];
        FuzzerUtils.init(nArray, 36361);
        FuzzerUtils.init(fArray, 0.791f);
        FuzzerUtils.init(sArray, (short)-1473);
        n -= 88;
        block6: for (n2 = 20; n2 < 355; ++n2) {
            int n5 = n2 + 1;
            nArray[n5] = nArray[n5] + (n3 -= (int)(f -= (float)d));
            n3 <<= n2;
            n -= (int)d;
            switch (101) {
                case 98: {
                    int n6 = n2;
                    fArray[n6] = fArray[n6] + (float)n;
                    n = (int)l;
                    n *= (int)instanceCount;
                }
                case 99: {
                    for (d2 = 1.0; d2 < 5.0; d2 += 1.0) {
                        l = n4;
                    }
                    n4 = -25;
                    continue block6;
                }
                case 100: {
                    continue block6;
                }
                case 101: {
                    n += n2;
                    continue block6;
                }
                default: {
                    f = instanceCount;
                }
            }
        }
        long l2 = l + (long)s + (long)by + (long)n + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n4 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(sArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void vMeth1(int n) {
        int n2 = 25729;
        int n3 = 17541;
        int[] nArray = new int[400];
        short s = 21855;
        byte by = -33;
        float f = -76.726f;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)6L);
        FuzzerUtils.init(nArray, -2);
        for (n2 = 11; n2 < 319; ++n2) {
            this.iFld = Test.iMeth(-2221516662478642684L, s, by);
            n3 = (int)dFld;
            s = (short)(s - (short)f);
            n3 = this.iFld;
        }
        instanceCount -= instanceCount;
        instanceCount *= instanceCount;
        long[] lArray2 = lArray[(this.iFld >>> 1) % 400][(n2 >>> 1) % 400];
        int n4 = (n2 >>> 1) % 400;
        lArray2[n4] = lArray2[n4] - (long)n;
        int n5 = (n2 >>> 1) % 400;
        fArrFld[n5] = fArrFld[n5] + (float)n2;
        this.bFld = this.bFld;
        vMeth1_check_sum += (long)((n <<= n2) + n2 + n3 + s + by + Float.floatToIntBits(f)) + FuzzerUtils.checkSum((Object[][])lArray) + FuzzerUtils.checkSum(nArray);
    }

    public void vMeth(int n, long l, double d) {
        int n2 = -163;
        int n3 = -62;
        int n4 = -1542;
        int n5 = 8;
        int[] nArray = new int[400];
        int n6 = 3442;
        double[][] dArray = new double[400][400];
        FuzzerUtils.init(dArray, 126.36653);
        FuzzerUtils.init(nArray, -12577);
        for (n2 = 16; n2 < 353; ++n2) {
            this.vMeth1(-32056);
            n6 = (short)(n6 + (short)((long)n2 - instanceCount));
            this.iFld >>= 51;
            this.iFld >>= this.iFld;
            if (this.bFld) continue;
            this.iFld = (int)((float)this.iFld + ((float)(n2 * n + n6) - this.fFld));
            if (this.bFld) {
                double[] dArray2 = dArray[n2 + 1];
                int n7 = n2 - 1;
                dArray2[n7] = dArray2[n7] + (double)n;
            } else {
                if (this.bFld) continue;
                n -= (int)dFld;
            }
            n4 = 1;
            while (n4 < 5) {
                this.fFld += (float)(-130 + n4 * n4);
                if (this.iFld1 != 0) {
                    vMeth_check_sum += (long)n + l + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n6 + (long)n4 + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(nArray);
                    return;
                }
                nArray[n2 - 1] = n4++;
            }
        }
        vMeth_check_sum += (long)n + l + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n6 + (long)n4 + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -193;
        int n2 = -13;
        int n3 = -3;
        int n4 = -40;
        int n5 = 45;
        int[] nArray = new int[400];
        double d = 89.103368;
        double[][] dArray = new double[400][400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)-62);
        FuzzerUtils.init(nArray, -23504);
        FuzzerUtils.init(dArray, 2.109179);
        this.iFld = byArray[(this.iFld >>> 1) % 400];
        this.vMeth(this.iFld, 4085723069L, dFld);
        for (byte by : byArray) {
            instanceCount = -403528749L;
            by = (byte)this.sFld;
            this.fFld -= (float)this.iFld1;
        }
        nArray[396] = -10;
        instanceCount = (long)this.fFld;
        this.sFld = (short)(this.sFld - (short)this.iFld1);
        n = 275;
        block10: while (--n > 0) {
            this.bFld = this.bFld;
            d = 1.0;
            block11: while (true) {
                double d2;
                d += 1.0;
                if (!(d2 < 91.0)) continue block10;
                this.iFld = (int)instanceCount;
                this.fFld += (float)(d * (double)instanceCount + (double)n - (double)n);
                for (n2 = n; n2 < 1; ++n2) {
                    instanceCount = this.iFld1;
                }
                double[] dArray2 = dArray[(int)(d - 1.0)];
                int n6 = n - 1;
                dArray2[n6] = dArray2[n6] + (double)n;
                n4 = 1;
                while (true) {
                    if (n4 >= 1) continue block11;
                    dFld -= (double)n4;
                    byArray[n + 1] = (byte)instanceCount;
                    n5 += n4 * n4;
                    this.iFld = -163;
                    switch (n4 % 7 + 54) {
                        case 54: {
                            dArray[n - 1][n + 1] = n5;
                            instanceCount += instanceCount;
                            instanceCount = n3;
                        }
                        case 55: {
                            n3 = (int)((float)n3 + ((float)n4 * this.fFld + (float)n2 - (float)instanceCount));
                            this.fFld = this.iFld1;
                            this.bFld = this.bFld;
                            int n7 = n4 + 1;
                            nArray[n7] = nArray[n7] + 1;
                            break;
                        }
                        case 56: {
                            this.fFld -= (float)n2;
                        }
                        case 57: {
                            break;
                        }
                        case 58: {
                            n5 = (int)this.fFld;
                            break;
                        }
                        case 59: {
                            n3 += n4;
                            break;
                        }
                        case 60: {
                            nArray = FuzzerUtils.int1array(400, 10);
                            break;
                        }
                        default: {
                            Test.bArrFld[n4] = this.bFld;
                        }
                    }
                    ++n4;
                }
                break;
            }
        }
        FuzzerUtils.out.println("i12 d3 i13 = " + n + "," + Double.doubleToLongBits(d) + "," + n2);
        FuzzerUtils.out.println("i14 i15 i16 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("byArr iArr3 dArr1 = " + FuzzerUtils.checkSum(byArray) + "," + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("bFld fFld iFld1 = " + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(this.fFld) + "," + this.iFld1);
        FuzzerUtils.out.println("sFld Test.fArrFld Test.bArrFld = " + this.sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 2.96f);
        FuzzerUtils.init(bArrFld, false);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

