/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 12L;
    public static float fFld = 2.137f;
    public static volatile short sFld = (short)-5507;
    public static double dFld = 2.98592;
    public static int iFld = 7;
    public boolean bFld = false;
    public static int[] iArrFld = new int[400];
    public volatile double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(long l) {
        int n = 35915;
        int n2 = -63271;
        int n3 = -245;
        int n4 = 13;
        int n5 = 30318;
        int n6 = -14;
        int n7 = 58;
        int n8 = -9265;
        int n9 = -10;
        boolean bl = true;
        double d = -1.63441;
        for (n = 4; n < 170; ++n) {
            fFld += (float)n;
            n2 = (int)l;
            n2 = sFld;
            for (n3 = 1; n3 < 10; ++n3) {
                instanceCount -= -6L;
            }
            sFld = (short)(sFld ^ (short)n3);
        }
        n4 <<= n;
        for (n5 = 17; n5 < 387; n5 += 3) {
            sFld = (short)(sFld * (short)n3);
            n2 -= n7;
            bl = false;
            for (n8 = 13; n8 > 1; n8 -= 3) {
                n6 = (int)((float)n6 + ((float)n8 - fFld));
                d += (double)n6;
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)(bl ? 1 : 0) + (long)n8 + (long)n9 + Double.doubleToLongBits(d);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth1(long l) {
        int n = -188;
        int n2 = 61329;
        int n3 = 82;
        int n4 = -52645;
        int n5 = -150;
        int n6 = 34;
        int n7 = 70;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 37341L);
        n -= Test.iMeth(l);
        for (n2 = 1; 196 > n2; ++n2) {
            for (n4 = 1; 8 > n4; ++n4) {
                n = -187;
            }
            n3 += 13;
            n6 = 1;
            do {
                n += n7;
            } while (++n6 < 8);
            n3 >>= (int)instanceCount;
            n5 += n2 * n2;
            n += n2;
            if (n4 != 0) {
                vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(lArray);
                return;
            }
            Test.iArrFld[n2 + 1] = (int)instanceCount;
        }
        lArray[(n2 >>> 1) % 400] = n4;
        vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)(n5 >>>= n7) + (long)n6 + (long)n7 + FuzzerUtils.checkSum(lArray);
    }

    public void vMeth(int n, int n2, int n3) {
        int n4 = 70;
        int n5 = -4;
        int n6 = 21012;
        int[] nArray = new int[400];
        boolean bl = true;
        FuzzerUtils.init(nArray, -58173);
        for (int n7 : nArray) {
            Test.vMeth1(instanceCount);
            n2 = n7;
            n4 = 1;
            block11: do {
                instanceCount -= (long)n3;
                switch (n4 % 9 * 5 + 21) {
                    case 27: {
                        n <<= n2;
                        if (!bl) break;
                        break;
                    }
                    case 23: 
                    case 39: {
                        for (n5 = 1; 1 > n5; ++n5) {
                            nArray = FuzzerUtils.int1array(400, -93);
                            n7 += n7;
                            n7 += (int)(instanceCount *= (long)dFld);
                            instanceCount = n2;
                            n -= 14;
                        }
                        continue block11;
                    }
                    case 66: {
                        n6 = n2;
                        break;
                    }
                    case 45: {
                        if (bl) continue block11;
                    }
                    case 26: {
                        fFld = instanceCount;
                        break;
                    }
                    case 52: {
                        break;
                    }
                    case 38: {
                        n += n7;
                        break;
                    }
                    case 25: {
                        sFld = (short)(sFld >> (short)n3);
                    }
                }
            } while (++n4 < 4);
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + (bl ? 1 : 0) + n5 + n6) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 13788;
        int n2 = 206;
        int n3 = -2;
        int n4 = -166;
        int n5 = -126;
        int n6 = -2554;
        int n7 = -6;
        int n8 = -19;
        int n9 = 4;
        double d = 0.14337;
        this.vMeth(iFld, iFld, iFld);
        if (this.bFld) {
            for (n = 11; n < 393; ++n) {
                sFld = (short)n;
                iFld += iFld;
                instanceCount += -46409L;
                for (n3 = 4; n3 < 66; ++n3) {
                    sFld = (short)n;
                    n4 -= n3;
                    iFld <<= -52206;
                }
            }
            int n10 = (n2 >>> 1) % 400;
            iArrFld[n10] = iArrFld[n10] + (int)instanceCount;
            for (d = 12.0; d < 239.0; d += 1.0) {
                n5 *= n;
                this.dArrFld[(int)d] = n4;
                Test.iArrFld[(int)(d + 1.0)] = n3;
                if (this.bFld) {
                    for (n6 = 111; n6 > 5; n6 -= 3) {
                        n7 += n2;
                        block8: for (n8 = 1; n8 < 4; ++n8) {
                            instanceCount -= (long)fFld;
                            if (!this.bFld) continue;
                            switch ((int)(d % 2.0 + 43.0)) {
                                case 43: {
                                    fFld += (float)n;
                                    n4 -= (int)instanceCount;
                                    iFld -= n2;
                                    continue block8;
                                }
                                case 44: {
                                    n2 = n9;
                                    n5 = (int)((long)n5 + ((long)n8 * instanceCount + (long)n2 - (long)n));
                                    n9 += 41313;
                                    continue block8;
                                }
                                default: {
                                    iFld = n;
                                }
                            }
                        }
                    }
                    continue;
                }
                iFld >>= n4;
            }
        } else {
            dFld = 4.258766189E9;
        }
        FuzzerUtils.out.println("i22 i23 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i25 d1 i26 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("i27 i28 i29 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i30 = " + n9);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
        FuzzerUtils.out.println("Test.dFld Test.iFld bFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iArrFld dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -9);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

