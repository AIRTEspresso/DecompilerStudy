/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3864190133524760347L;
    public int iFld = -15;
    public static float fFld = -39.414f;
    public static boolean bFld = true;
    public static short sFld = (short)19145;
    public long lFld = 111L;
    public double dFld = -98.128087;
    public double dFld1 = 47.86497;
    public byte byFld = (byte)-63;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long dMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        int n4 = -16036;
        int n5 = 14;
        int n6 = 150;
        int n7 = -184;
        int n8 = -23629;
        double d = -1.56213;
        double[] dArray = new double[400];
        float f = 70.671f;
        int n9 = 22;
        long[] lArray = new long[400];
        FuzzerUtils.init(dArray, 0.20585);
        FuzzerUtils.init(lArray, -3063671024401328456L);
        switch ((n2 >>> 1) % 4 + 47) {
            case 47: {
                for (n4 = 6; 138 > n4; ++n4) {
                    n3 = 45452;
                    fFld -= (float)n;
                    d += (double)n2;
                    if (n4 != 0) {
                        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(lArray);
                        return;
                    }
                    n3 *= n4;
                    d += (double)instanceCount;
                    n3 = 12;
                    n3 += n4 * n4;
                    for (f = 1.0f; f < 12.0f; f += 1.0f) {
                        for (n7 = 1; n7 < 2; ++n7) {
                            instanceCount += (long)(n7 * n2 + n2 - n7);
                        }
                    }
                }
                break;
            }
            case 48: {
                n >>= 203;
                break;
            }
            case 49: {
                instanceCount = n4;
            }
            case 50: {
                dArray[(n2 >>> 1) % 400] = instanceCount;
            }
            default: {
                lArray[0] = n2;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(lArray);
    }

    public double dMeth(float f, long l, long l2) {
        boolean bl = false;
        long l3 = -1047996405L;
        int n = -101;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -134);
        this.iFld >>= (int)(++l2);
        Test.vMeth1(-14, this.iFld, this.iFld);
        l3 = 1L;
        while (++l3 < 157L) {
            double d = -39.67477;
            Test.lArrFld[(int)l3] = this.iFld;
            switch (65) {
                case 61: {
                    int n2 = (int)(l3 + 1L);
                    nArray[n2] = nArray[n2] + n;
                    sFld = (short)(sFld + (short)(l3 + (long)sFld));
                    l2 *= (long)this.iFld;
                    break;
                }
                case 62: {
                    this.iFld *= (int)d;
                    this.iFld *= this.iFld;
                }
                case 63: {
                    Test.lArrFld[(int)(l3 - 1L)] = this.iFld;
                    this.iFld = this.iFld;
                    this.iFld += (int)(l3 ^ (long)this.iFld);
                    break;
                }
                case 64: {
                    this.iFld <<= this.iFld;
                }
                case 65: {
                    instanceCount |= (long)this.iFld;
                    break;
                }
                case 66: {
                    this.iFld = 5;
                }
            }
        }
        long l4 = (long)Float.floatToIntBits(f) + l + l2 + (long)(bl ? 1 : 0) + l3 + (long)n + FuzzerUtils.checkSum(nArray);
        dMeth_check_sum += l4;
        return l4;
    }

    public void vMeth() {
        int n = -244;
        int n2 = -3;
        int n3 = -49;
        int n4 = 16630;
        int n5 = -118;
        int n6 = 149;
        int[] nArray = new int[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, 12);
        FuzzerUtils.init(dArray, -2.27171);
        this.iFld = (int)(-this.dMeth(fFld, -5515384168490525178L, 1144697354L) - (double)this.iFld);
        this.lFld -= (long)fFld;
        this.dFld = this.iFld;
        block4: for (n = 7; 327 > n; ++n) {
            n2 = 80;
            int n7 = n;
            nArray[n7] = nArray[n7] - (int)this.lFld;
            this.iFld >>= this.iFld;
            fFld = this.iFld;
            switch (n % 2 * 5 + 119) {
                case 129: {
                    for (n3 = 1; n3 < 5; ++n3) {
                        for (n5 = 2; n5 > n3; --n5) {
                            n6 >>>= (int)instanceCount;
                            this.lFld &= (long)n2;
                        }
                    }
                    Test.lArrFld[n] = instanceCount;
                    continue block4;
                }
                case 125: {
                    n6 |= 0xFFFFFFF9;
                    continue block4;
                }
                default: {
                    int n8 = n - 1;
                    dArray[n8] = dArray[n8] - 71.0;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public void mainTest(String[] stringArray) {
        int n = -1;
        int n2 = 6;
        int n3 = 164;
        int n4 = -11;
        int n5 = 4361;
        int n6 = -37518;
        int n7 = 1;
        int n8 = 8;
        int[] nArray = new int[400];
        long l = 3207255790L;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, -29101);
        FuzzerUtils.init(fArray, 0.187f);
        this.vMeth();
        sFld = (short)180;
        int n9 = (this.iFld >>> 1) % 400;
        fArray[n9] = fArray[n9] - (float)this.iFld;
        for (n = 4; n < 196; ++n) {
            this.dFld1 += this.dFld;
            for (n3 = 8; n3 < 131; ++n3) {
                this.iFld += -12089 + n3 * n3;
                this.byFld = (byte)(this.byFld ^ (byte)n4);
                this.iFld += n3;
                this.iFld = this.iFld;
                n4 *= this.iFld;
                for (n5 = 1; n5 < 2; ++n5) {
                    n6 = n2;
                    this.dFld1 = this.lFld;
                    nArray[n3] = (int)instanceCount;
                    n4 += n;
                    this.lFld >>= -31433;
                    instanceCount = 96L;
                    sFld = (short)(sFld + (short)n5);
                    this.lFld += l;
                    fFld += (float)n5 * fFld + (float)(n4 += n2) - (float)n;
                }
                n6 += n6;
                n2 += 47470 + n3 * n3;
                if (bFld) continue;
                for (n7 = 1; 2 > n7; ++n7) {
                    instanceCount -= (long)n2;
                    int n10 = n + 1;
                    nArray[n10] = nArray[n10] + n6;
                }
            }
        }
        FuzzerUtils.out.println("i14 i15 i16 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i17 i18 i19 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("l3 i20 i21 = " + l + "," + n7 + "," + n8);
        FuzzerUtils.out.println("iArr2 fArr = " + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.sFld lFld = " + (bFld ? 1 : 0) + "," + sFld + "," + this.lFld);
        FuzzerUtils.out.println("dFld dFld1 byFld = " + Double.doubleToLongBits(this.dFld) + "," + Double.doubleToLongBits(this.dFld1) + "," + this.byFld);
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 5185700968123384073L);
        vMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

