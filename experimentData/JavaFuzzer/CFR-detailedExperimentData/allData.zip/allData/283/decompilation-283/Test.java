/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 676462310L;
    public static volatile double dFld = 1.60385;
    public static short sFld = (short)-7647;
    public static byte[] byArrFld = new byte[400];
    public static float[] fArrFld = new float[400];
    public static int[] iArrFld = new int[400];
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        int n4 = 14;
        int n5 = -1;
        int n6 = 221;
        int n7 = 100;
        int n8 = -173;
        int n9 = 14;
        int n10 = -196;
        float f = 2.321f;
        double d = 0.118152;
        int n11 = 29556;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 143L);
        for (n4 = 7; n4 < 157; ++n4) {
            n3 = (int)f;
        }
        block7: for (n6 = 4; n6 < 149; ++n6) {
            switch ((n7 >>> 1) % 4 * 5 + 13) {
                case 27: {
                    n7 = (int)instanceCount;
                    n5 >>>= n7;
                    int n12 = n6 + 1;
                    lArray[n12] = lArray[n12] ^ (long)n7;
                    for (d = 1.0; d < 11.0; d += 1.0) {
                        for (n9 = n6; n9 < 2; ++n9) {
                            n7 ^= (int)(++instanceCount);
                            n3 += n9 * n9;
                            n += 1013919762;
                        }
                    }
                }
                case 32: {
                    int n13 = n6 + 1;
                    byArrFld[n13] = (byte)(byArrFld[n13] + (byte)n7);
                    continue block7;
                }
                case 24: {
                    n10 = (int)((long)n10 + ((long)n6 ^ instanceCount));
                    continue block7;
                }
                case 33: {
                    f += (float)(n6 * n7) + f - (float)instanceCount;
                    continue block7;
                }
                default: {
                    n11 = (short)(n11 << -7);
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f) + n6 + n7) + Double.doubleToLongBits(d) + (long)n8 + (long)n9 + (long)n10 + (long)n11 + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n, double d, int n2) {
        boolean bl = true;
        int n3 = -21994;
        int n4 = -20455;
        int n5 = 11877;
        int[] nArray = new int[400];
        float f = 0.125f;
        int n6 = -21;
        int n7 = -5222;
        short[][] sArray = new short[400][400];
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(sArray, (short)-32186);
        FuzzerUtils.init((Object[][])lArray, (Object)54980L);
        FuzzerUtils.init(nArray, -19709);
        sArray[(n >>> 1) % 400][(n2 >>> 1) % 400] = (short)(n2-- - -63588);
        for (n3 = 13; n3 < 293; ++n3) {
            f += (float)(n3 * n3 + n4 - n);
            Test.vMeth1(23955, -32589, n3);
            n5 = 1;
            block15: while (++n5 < 6) {
                n = (int)((long)n + ((long)(n5 * n2 + n5) - instanceCount));
                n >>>= (int)instanceCount;
                n4 -= n2;
                switch ((n2 >>> 1) % 10 + 124) {
                    case 124: {
                        n4 = n *= n3;
                        lArray[n3 - 1][n3 + 1][n3] = n6;
                        continue block15;
                    }
                    case 125: {
                        int n8 = n5;
                        nArray[n8] = nArray[n8] - n7;
                        continue block15;
                    }
                    case 126: {
                        bl = false;
                        continue block15;
                    }
                    case 127: {
                        int n9 = n3;
                        fArrFld[n9] = fArrFld[n9] * (float)n2;
                    }
                    case 128: {
                        instanceCount = n2;
                    }
                    case 129: {
                        try {
                            n4 = n / -2124804010;
                            n2 = 1245464536 / n3;
                            n2 = -1491358623 % n;
                        }
                        catch (ArithmeticException arithmeticException) {}
                        continue block15;
                    }
                    case 130: {
                        nArray = FuzzerUtils.int1array(400, 5);
                        continue block15;
                    }
                    case 131: {
                        n += n2;
                        continue block15;
                    }
                    case 132: {
                        n4 ^= n3;
                    }
                    case 133: {
                        n = -246;
                        continue block15;
                    }
                }
                f += (float)n4;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)(bl ? 1 : 0) + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(sArray) + FuzzerUtils.checkSum((Object[][])lArray) + FuzzerUtils.checkSum(nArray);
    }

    public static long lMeth(int n, long l) {
        int n2 = 9;
        int n3 = 0;
        int n4 = 0;
        int n5 = -12;
        int n6 = 44242;
        int n7 = 28339;
        int n8 = 18;
        int n9 = 241;
        int[] nArray = new int[400];
        float f = 1.118f;
        FuzzerUtils.init(nArray, 63358);
        n2 = 1;
        while (++n2 < 256) {
            n3 = 1;
            while (n3 < 6) {
                boolean bl = false;
                Test.vMeth(n3, dFld, n2);
                n = n3++;
            }
            n4 -= 23821;
            try {
                n = nArray[n2] % n2;
                n4 = -23133 / n;
                nArray[n2] = n3 % -30131;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n -= n2;
            n5 = 1;
            do {
                nArray[n5] = (int)f;
            } while (++n5 < 6);
            n = n2;
        }
        for (n6 = 11; n6 < 332; ++n6) {
            for (n8 = 5; n8 > 1; --n8) {
                n9 &= (int)l;
                n4 ^= n2;
            }
        }
        long l2 = (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7 + (long)n8 + (long)n9 + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -11760;
        int n2 = 16739;
        int n3 = 159;
        int n4 = 211;
        int n5 = 176;
        int n6 = -7;
        int n7 = -5;
        float f = 0.608f;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -51467L);
        if (bl) {
            n = 1;
            do {
                f = (float)Test.lMeth(-10, instanceCount) + f;
                for (n2 = 3; n2 < 169; ++n2) {
                    n3 |= (int)instanceCount;
                    Test.iArrFld[n2 - 1] = n;
                    n4 = 1;
                    do {
                        n3 = (int)((long)n3 + ((long)n4 | (long)f));
                        f += (float)n4;
                        n3 += n4 * n4;
                        n3 = 12;
                        int n8 = n2 + 1;
                        iArrFld[n8] = iArrFld[n8] * (int)instanceCount;
                        n3 -= 6;
                        sFld = (short)n2;
                        n3 = n2;
                        f -= (float)instanceCount;
                        instanceCount &= (long)n3;
                    } while (++n4 < 2);
                    block7: for (n5 = 1; n5 < 2; ++n5) {
                        boolean bl2 = true;
                        f = 24357.0f;
                        Test.iArrFld[n2] = n6;
                        Test.fArrFld[n5 - 1] = f;
                        n3 = (int)(instanceCount *= (long)n3);
                        switch (n2 % 2 * 5 + 109) {
                            case 117: {
                                instanceCount *= (long)sFld;
                                continue block7;
                            }
                            case 111: {
                                if (bl2) {
                                    instanceCount += (long)n3;
                                    continue block7;
                                }
                                bl2 = true;
                                lArray[n5 + 1] = n4;
                            }
                        }
                    }
                }
            } while (++n < 148);
        } else {
            n6 = n7;
        }
        FuzzerUtils.out.println("i f i25 = " + n + "," + Float.floatToIntBits(f) + "," + n2);
        FuzzerUtils.out.println("i26 i27 i28 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i29 b3 i30 = " + n6 + "," + (bl ? 1 : 0) + "," + n7);
        FuzzerUtils.out.println("lArr2 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.sFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + sFld);
        FuzzerUtils.out.println("Test.byArrFld Test.fArrFld Test.iArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(byArrFld, (byte)101);
        FuzzerUtils.init(fArrFld, -1.566f);
        FuzzerUtils.init(iArrFld, 14);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

