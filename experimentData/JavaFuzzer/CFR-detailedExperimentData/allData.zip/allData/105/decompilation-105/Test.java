/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2384593840L;
    public int iFld = 5;
    public static float fFld = -1.614f;
    public static boolean bFld = true;
    public static short sFld = (short)17155;
    public double dFld = 22.101494;
    public int iFld1 = -57;
    public long[] lArrFld = new long[400];
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long vMeth2_check_sum = 0L;

    public static void vMeth2() {
        int n = -42;
        int n2 = 203;
        int n3 = -10;
        int n4 = 10839;
        int n5 = -84;
        int n6 = -146;
        int n7 = -57;
        double d = -61.91178;
        for (n = 3; n < 123; ++n) {
            if (n2 != 0) {
                vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n7 + n5 + n6) + Double.doubleToLongBits(d);
                return;
            }
            n2 &= n2;
            for (n3 = 1; n3 < 13 && !bFld; ++n3) {
                n2 = n7;
                n4 += n4;
                if (bFld) {
                    for (n5 = 1; n5 < 2; ++n5) {
                        n4 += n5 * n5;
                        n7 = (byte)instanceCount;
                        n6 += n5;
                    }
                    continue;
                }
                n2 += n3 | n4;
                n4 = (int)d;
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n7 + n5 + n6) + Double.doubleToLongBits(d);
    }

    public static void vMeth1(long l) {
        long l2 = -2613817603206054323L;
        long l3 = -6428L;
        int n = 9;
        int n2 = -229;
        int n3 = -64427;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-1223);
        fFld = l2++;
        for (l3 = 2L; l3 < 343L; ++l3) {
            n = (int)((long)n + (-54L + l3 * l3));
            Test.vMeth2();
            for (n2 = 1; n2 < 5; ++n2) {
                n = (int)fFld;
                n3 -= 1602019451;
                n3 <<= -48160;
                int n4 = (int)(l3 + 1L);
                sArray[n4] = (short)(sArray[n4] + -17462);
                n3 >>>= (n *= -2);
                n >>= n;
                n = (int)((float)n + ((float)(n2 * n + n) - fFld));
                n3 %= -40;
            }
        }
        vMeth1_check_sum += l + l2 + l3 + (long)n + (long)n2 + (long)n3 + FuzzerUtils.checkSum(sArray);
    }

    public static void vMeth() {
        int n = 48880;
        int n2 = 37416;
        int n3 = -40901;
        int[] nArray = new int[400];
        int n4 = 85;
        FuzzerUtils.init(nArray, 1);
        n = 1;
        do {
            for (n2 = 14; n2 > 1; --n2) {
                float f = -16.463f;
                f -= (float)n3;
                Test.vMeth1(instanceCount);
                fFld += (float)((long)n2 * instanceCount + instanceCount - (long)n);
                n3 *= n4;
                n3 += n2;
                n3 += (int)instanceCount;
                n3 -= n4;
                n3 += n2;
                instanceCount = n;
            }
            instanceCount += (long)(-211 + n * n);
            int n5 = n;
            nArray[n5] = nArray[n5] * sFld;
            n3 *= 32427;
        } while ((n += 2) < 216);
        vMeth_check_sum += (long)(n + n2 + n3 + n4) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -202;
        int n2 = -56001;
        int n3 = 0;
        int n4 = -14;
        int n5 = -36414;
        int n6 = 133;
        int n7 = 15540;
        int n8 = -4;
        int[] nArray = new int[400];
        float f = -53.503f;
        FuzzerUtils.init(nArray, -112);
        this.iFld -= -19;
        n = 379;
        while (--n > 0) {
            for (n2 = n; n2 < 66; ++n2) {
                int n9 = n;
                this.lArrFld[n9] = this.lArrFld[n9] >> n2;
                Test.vMeth();
                this.iFld *= (int)fFld;
                n4 = 1;
                do {
                    nArray[n4 + 1] = (int)this.dFld;
                    n3 = (int)instanceCount;
                    this.iFld = this.iFld;
                } while ((n4 += 3) < 1);
                n3 = (int)instanceCount;
                bFld = true;
                n3 *= (int)instanceCount;
                this.dFld -= (double)n;
            }
        }
        int n10 = (n >>> 1) % 400;
        this.lArrFld[n10] = this.lArrFld[n10] + -188L;
        this.iFld <<= (int)instanceCount;
        n3 -= n3;
        instanceCount += (long)this.iFld;
        n5 = 1;
        while (++n5 < 285) {
            n3 += n5;
            n3 <<= -4;
        }
        try {
            for (f = 3.0f; f < 188.0f; f += 1.0f) {
                n3 <<= -30083;
                for (n7 = (int)f; n7 < 136; ++n7) {
                    n8 += n8;
                    this.iFld1 = (int)((float)this.iFld1 + ((float)n7 + fFld));
                }
            }
        }
        catch (ArithmeticException arithmeticException) {
            n8 <<= 7;
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i15 i16 f1 = " + n4 + "," + n5 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i17 i18 i19 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.sFld dFld = " + (bFld ? 1 : 0) + "," + sFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("iFld1 lArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

