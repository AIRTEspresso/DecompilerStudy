/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1L;
    public static float fFld = -2.495f;
    public static boolean bFld = false;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static short[] sArrFld = new short[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1(short s) {
        int n = 26171;
        int n2 = -11;
        int n3 = -34839;
        int n4 = 238;
        int n5 = -164;
        int n6 = -132;
        int n7 = -60640;
        double d = 0.13735;
        double d2 = 1.75463;
        long l = -10L;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.1003f);
        switch ((n >>> 1) % 7 + 34) {
            case 34: {
                for (d = 4.0; d < 163.0; d += 1.0) {
                    n += (int)(d * (double)n + (double)n - (double)instanceCount);
                    l = 1L;
                    do {
                        instanceCount = l++;
                    } while (l < 10L);
                    int n8 = (int)(d - 1.0);
                    iArrFld[n8] = iArrFld[n8] + n2;
                    n *= n2;
                }
                for (d2 = 7.0; d2 < 286.0; d2 += 1.0) {
                    n4 = 1;
                    do {
                        for (n5 = 1; 1 > n5; n5 += 3) {
                            n6 *= n2;
                            if (n4 != 0) {
                                // empty if block
                            }
                            instanceCount <<= n6;
                            if (n == 0) continue;
                        }
                    } while (++n4 < 6);
                }
                break;
            }
            case 35: {
                fFld += (float)l;
                break;
            }
            case 36: {
                n = (int)l;
                break;
            }
            case 37: {
                n3 = 1151735093;
            }
            case 38: {
                n *= n3;
                break;
            }
            case 39: {
                n7 += n3;
                break;
            }
            case 40: {
                fFld += (float)n;
            }
        }
        long l2 = (long)(s + n) + Double.doubleToLongBits(d) + (long)n2 + l + Double.doubleToLongBits(d2) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth() {
        int n = -40514;
        int n2 = 52449;
        int n3 = -250;
        int n4 = -73;
        int n5 = -1747;
        int n6 = -239;
        int n7 = 27274;
        double d = -1.1404;
        boolean bl = false;
        for (n = 3; n < 183; ++n) {
            fFld = Test.iMeth1((short)8120) * n;
            n2 &= n7;
            n2 += n * n2;
            int n8 = n;
            iArrFld[n8] = iArrFld[n8] ^ (int)instanceCount;
            for (n3 = 1; n3 < 9; ++n3) {
                int n9 = n3 - 1;
                iArrFld[n9] = iArrFld[n9] >>> n;
                for (n5 = 1; n5 < 2 && !bl; ++n5) {
                    d += -4319.0;
                    n4 = (int)((float)n4 + (float)n5 * fFld);
                }
            }
            try {
                n2 = -26247 / n2;
                Test.iArrFld[n + 1] = -177 / n;
                n2 = n4 / iArrFld[n + 1];
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n6 += n * n5 + n6 - (n2 += n);
        }
        vMeth_check_sum += (long)(n + n2 + n7 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0);
    }

    public static int iMeth(int n, long l, int n2) {
        int n3 = -177;
        int n4 = 21705;
        int n5 = 82;
        int n6 = -66;
        int n7 = -11;
        long l2 = -16066L;
        double d = -2.98944;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 66.57911);
        Test.vMeth();
        for (n3 = 8; 259 > n3; n3 += 3) {
            instanceCount += (long)(n3 * n2 + n2 - n2);
            l += (long)(n3 * n3);
            fFld += (float)n3;
            for (n5 = 1; 19 > n5; ++n5) {
                n4 *= n;
                instanceCount += (long)(n5 * n5);
                int n8 = n5;
                lArrFld[n8] = lArrFld[n8] + (long)n2;
                l = n6;
                for (l2 = 1L; 2L > l2; ++l2) {
                    int n9;
                    n2 = n9 = 17592;
                    d = n7;
                    fFld = n6;
                    dArray[n5 + 1] = n5;
                }
            }
        }
        long l3 = (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + l2 + (long)n7 + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l3;
        return (int)l3;
    }

    public void mainTest(String[] stringArray) {
        int n = -41463;
        int n2 = 147;
        int n3 = -11;
        int n4 = 135;
        int n5 = -116;
        int n6 = -13;
        int n7 = 58;
        int n8 = -2;
        double d = -2.14807;
        int n9 = 54;
        int n10 = -10059;
        n *= Test.iMeth(n, instanceCount, n) - n;
        n2 = 282;
        while (--n2 > 0) {
            fFld += (float)((long)n2 * instanceCount + (long)(n -= (int)instanceCount) - instanceCount);
        }
        for (n3 = 6; n3 < 178; ++n3) {
            instanceCount *= instanceCount;
            n5 = 1;
            while (++n5 < 146) {
                for (n6 = 1; n6 < 1; ++n6) {
                    fFld += (float)((long)n6 * instanceCount);
                    if (bFld) continue;
                    n4 = n7;
                    n4 *= (int)d;
                    n4 = n9;
                    instanceCount += (long)(n6 * n6);
                }
                n10 = (short)(n10 - 48);
                instanceCount = n;
                instanceCount = n3;
                switch ((n7 >>> 1) % 5 * 5 + 20) {
                    case 37: 
                    case 38: {
                        n9 = (byte)(n9 - n9);
                        fFld -= (float)n7;
                        n = n6;
                        break;
                    }
                    case 26: {
                        fFld += 66.0f;
                        n10 = (short)(n10 + (short)n5);
                        n8 = 1;
                        do {
                            int n11 = n3;
                            sArrFld[n11] = (short)(sArrFld[n11] | (short)instanceCount);
                            int n12 = n3 + 1;
                            iArrFld[n12] = iArrFld[n12] + n;
                            int n13 = n3;
                            iArrFld[n13] = iArrFld[n13] * 150;
                            instanceCount -= (long)n9;
                        } while (++n8 < 1);
                        break;
                    }
                    case 21: {
                        instanceCount += (long)(n5 * n9);
                        break;
                    }
                    case 31: {
                        instanceCount += (long)(n5 * n5);
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i22 i23 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i24 i25 i26 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i27 d4 by = " + n7 + "," + Double.doubleToLongBits(d) + "," + n9);
        FuzzerUtils.out.println("s3 i28 = " + n10 + "," + n8);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld Test.sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -8275);
        FuzzerUtils.init(lArrFld, -4028306867L);
        FuzzerUtils.init(sArrFld, (short)-15163);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

