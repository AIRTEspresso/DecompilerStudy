/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -57488L;
    public static long[] lArrFld = new long[400];
    public volatile int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2() {
        int n = -11;
        int n2 = -29532;
        int n3 = -14;
        int n4 = 12;
        int n5 = -7;
        int[] nArray = new int[400];
        int n6 = 6;
        boolean bl = true;
        double d = -55.90724;
        FuzzerUtils.init(nArray, 175);
        n = -14;
        for (n2 = 15; n2 < 306; ++n2) {
            if (bl) {
                for (n4 = 6; n4 > n2; --n4) {
                    try {
                        n3 = nArray[n4] % n4;
                        n3 = n4 / -46140;
                        n3 = n5 / -1812897527;
                        continue;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
            } else {
                n5 -= n6;
                n = n3;
                int n7 = n2 + 1;
                nArray[n7] = nArray[n7] << (int)instanceCount;
            }
            n -= n2;
            n += -102 + n2 * n2;
            int n8 = n2 + 1;
            nArray[n8] = nArray[n8] * -243;
            instanceCount -= (long)d;
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0)) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(long l) {
        int n = 1746;
        int n2 = 13;
        int n3 = -4;
        int n4 = 58;
        int[] nArray = new int[400];
        long l2 = -218L;
        int n5 = 84;
        int n6 = -20484;
        FuzzerUtils.init(nArray, -22546);
        Test.vMeth2();
        for (n = 389; 18 < n; --n) {
            n2 = 123;
            instanceCount -= -108L;
            for (l2 = 1L; l2 < 5L; ++l2) {
                double d = 2.82676;
                float f = -93.234f;
                nArray = FuzzerUtils.int1array(400, -7896);
                n5 = (byte)(n5 * (byte)l);
                n2 = 2;
                d -= 154.0;
                f += (float)n2;
            }
            n4 = 1;
            do {
                n3 >>= (int)instanceCount;
                n6 = (short)(n6 >>> (short)n2);
                n3 <<= 6;
            } while (++n4 < 5);
        }
        vMeth1_check_sum += l + (long)n + (long)n2 + l2 + (long)n3 + (long)n5 + (long)n4 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(long l, byte by, long l2) {
        int n = 4;
        int n2 = -35923;
        int n3 = 158;
        int n4 = 24892;
        int n5 = 61261;
        int n6 = -104;
        int n7 = 11679;
        int[] nArray = new int[400];
        int n8 = -929;
        short[] sArray = new short[400];
        long l3 = 7L;
        boolean bl = false;
        FuzzerUtils.init(nArray, -9);
        FuzzerUtils.init(sArray, (short)17566);
        n = 267;
        while (--n > 0) {
            n2 += n;
            Test.vMeth1(l2);
            n8 = -5;
            for (n3 = 6; n3 > 1; --n3) {
                for (l3 = 2L; l3 > (long)n3; --l3) {
                    int n9 = n3 + 1;
                    nArray[n9] = nArray[n9] + n;
                }
                for (n6 = 1; n6 < 2; n6 += 2) {
                    switch ((n3 >>> 1) % 2 + 120) {
                        case 120: 
                        case 121: {
                            instanceCount = -14L;
                            break;
                        }
                        default: {
                            bl = false;
                            int n10 = n - 1;
                            fArrFld[n10] = fArrFld[n10] * (float)n5;
                        }
                    }
                    int n11 = n3 + 1;
                    nArray[n11] = nArray[n11] | (int)l3;
                    int n12 = n3 + 1;
                    sArray[n12] = (short)(sArray[n12] >> (short)n7);
                }
            }
        }
        vMeth_check_sum += l + (long)by + l2 + (long)n + (long)n2 + (long)n8 + (long)n3 + (long)n4 + l3 + (long)n5 + (long)n6 + (long)n7 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(sArray);
    }

    public void mainTest(String[] stringArray) {
        long l = 20266L;
        int n = 104;
        int n2 = -26;
        int n3 = -29459;
        int n4 = -4;
        int n5 = 10;
        int n6 = -33;
        byte[] byArray = new byte[400];
        boolean bl = false;
        float f = -80.438f;
        double[] dArray = new double[400];
        FuzzerUtils.init(byArray, (byte)-108);
        FuzzerUtils.init(dArray, 2.67153);
        instanceCount = instanceCount++ + instanceCount;
        for (l = 6L; l < 340L; ++l) {
            int n7 = (int)(l - 1L);
            long l2 = lArrFld[n7] + 1L;
            lArrFld[n7] = l2;
            int n8 = n6 = (int)((byte)(n6 * (byte)(l2 * (long)((n + n) % (--n | 1)))));
            n6 = (byte)(n6 - 1);
            this.iArrFld[(int)(l - 1L)] = n8 + n ^ --n;
            int n9 = (int)l;
            int n10 = this.iArrFld[n9];
            this.iArrFld[n9] = n10 + 1;
            instanceCount += (long)n10;
            if (bl) {
                n6 = (byte)(n6 >> (byte)n);
                int n11 = (int)(l + 1L);
                long l3 = lArrFld[n11] + 1L;
                lArrFld[n11] = l3;
                instanceCount = l3;
                byArray[(int)(l + 1L)] = (byte)l3;
                Test.vMeth(instanceCount, (byte)-113, l);
            } else {
                f += (float)l;
                int n12 = (int)(l - 1L);
                this.iArrFld[n12] = this.iArrFld[n12] ^ (int)l;
            }
            f += (float)l;
            this.iArrFld[(int)l] = 77;
            f = n;
        }
        for (n2 = 254; n2 > 1; n2 -= 2) {
            Test.lArrFld[n2] = n;
            for (n4 = 12; 199 > n4; ++n4) {
                Test.lArrFld[n2 + 1] = -14L;
                switch (n2 % 1 * 5 + 1) {
                    case 2: {
                        n5 *= (int)(instanceCount <<= (n3 += n4));
                    }
                }
                int n13 = n4;
                this.iArrFld[n13] = this.iArrFld[n13] - 9;
                int n14 = n2;
                this.iArrFld[n14] = this.iArrFld[n14] << -14;
                f += f;
                f = n4;
            }
        }
        FuzzerUtils.out.println("l i by = " + l + "," + n + "," + n6);
        FuzzerUtils.out.println("b2 f1 i17 = " + (bl ? 1 : 0) + "," + Float.floatToIntBits(f) + "," + n2);
        FuzzerUtils.out.println("i18 i19 i20 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("byArr dArr = " + FuzzerUtils.checkSum(byArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.lArrFld iArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 2368852000L);
        FuzzerUtils.init(fArrFld, 125.129f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

