/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -3010636510L;
    public static volatile double dFld = -106.101249;
    public long lFld = -213L;
    public static short sFld = (short)-14224;
    public byte byFld = (byte)114;
    public static int[] iArrFld = new int[400];
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;
    public static long fMeth_check_sum;

    public static float fMeth(int n, int n2, int n3) {
        int n4 = -493;
        int n5 = -82;
        int n6 = 43966;
        int n7 = -39349;
        int n8 = -3;
        int n9 = 0;
        double d = -29.112939;
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        for (n4 = 7; n4 < 182; ++n4) {
            int n10 = n4;
            iArrFld[n10] = iArrFld[n10] - (int)instanceCount;
            int n11 = n4;
            iArrFld[n11] = iArrFld[n11] << n2;
            d += (double)n4;
            blArray[n4] = bl;
            n = -4;
            for (n6 = 9; n6 > 1; n6 -= 3) {
                for (n8 = n4; 5 > n8; ++n8) {
                    n2 -= (int)instanceCount;
                    n3 >>>= n8;
                    if (bl) break;
                    n5 -= n8;
                    if (n2 == 0) continue;
                }
                n3 *= n9;
                Test.iArrFld[n6 - 1] = (int)instanceCount;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + (long)n6 + (long)n7 + (long)n8 + (long)n9 + FuzzerUtils.checkSum(blArray);
        fMeth_check_sum += l;
        return l;
    }

    public static int iMeth(byte by) {
        int n = 7;
        int n2 = -80;
        int n3 = -8;
        int n4 = 5024;
        int n5 = 11;
        double d = 2.21364;
        double[] dArray = new double[400];
        float f = 1.97f;
        boolean bl = false;
        FuzzerUtils.init(dArray, 89.62794);
        switch (((int)((double)n + -2.3076) >>> 1) % 2 + 121) {
            case 121: {
                n2 = 1;
                while (++n2 < 191) {
                    Test.fMeth(12, -82, n);
                }
                n += n;
                n -= 112;
                break;
            }
            case 122: {
                n3 = 1;
                block17: while (++n3 < 238) {
                    d /= (double)(n3 | 1);
                    switch (n3 % 10 + 81) {
                        case 81: {
                            d *= (double)n3;
                            n = n3;
                            for (n4 = 1; n4 < 7; ++n4) {
                                instanceCount -= (long)n3;
                                n5 &= n4;
                            }
                            continue block17;
                        }
                        case 82: {
                            instanceCount = (long)((float)instanceCount + ((float)(n3 * n4) + f - (float)by));
                        }
                        case 83: {
                            instanceCount += (long)n3;
                            continue block17;
                        }
                        case 84: {
                            n5 |= n5;
                            continue block17;
                        }
                        case 85: {
                            if (!bl) continue block17;
                            continue block17;
                        }
                        case 86: {
                            instanceCount *= (long)n3;
                            continue block17;
                        }
                        case 87: {
                            n = n2;
                            continue block17;
                        }
                        case 88: {
                            instanceCount = n;
                        }
                        case 89: {
                            int n6 = n3 - 1;
                            iArrFld[n6] = iArrFld[n6] >> -10291;
                            continue block17;
                        }
                        case 90: {
                            by = (byte)n;
                        }
                    }
                    int n7 = n3 + 1;
                    dArray[n7] = dArray[n7] - (double)n4;
                }
                break;
            }
            default: {
                instanceCount = (long)f;
            }
        }
        long l = (long)(by + n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public static long lMeth(int n, long l, int n2) {
        int n3 = -2;
        int n4 = 29;
        int n5 = 3;
        int n6 = 14;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -3816269848L);
        instanceCount += (long)(--n);
        l += (long)Test.iMeth((byte)78);
        for (n3 = 374; n3 > 16; n3 -= 3) {
            int n7 = n3 + 1;
            iArrFld[n7] = iArrFld[n7] + (int)dFld;
            n5 = 1;
            while (n5 < 13) {
                instanceCount = n2;
                n2 += n5 + (n4 >>= n5);
                int n8 = n5;
                iArrFld[n8] = iArrFld[n8] - n4;
                n = n6;
                Test.iArrFld[n5 + 1] = 14;
                l += (long)(-82.667f + (float)(n5 * n5));
                n *= n2;
                long[] lArray2 = lArray[n3];
                int n9 = n5++;
                lArray2[n9] = lArray2[n9] >> -39;
            }
            if (n6 == 0) continue;
        }
        long l2 = (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(lArray);
        lMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 20;
        int n2 = -13;
        int n3 = 10;
        int n4 = -193;
        int n5 = 227;
        int n6 = -22548;
        int n7 = 138;
        int n8 = 54241;
        float f = 0.873f;
        boolean bl = true;
        n >>= (int)Test.lMeth(n, this.lFld, n);
        n -= (int)instanceCount;
        n2 = 1;
        do {
            for (n3 = 4; n3 < 65; n3 += 2) {
                for (n5 = 1; 3 > n5; ++n5) {
                    int n9 = n2 - 1;
                    iArrFld[n9] = iArrFld[n9] << 10;
                    this.lFld -= (long)n;
                    dFld = this.lFld;
                    n6 *= 1;
                }
                n6 *= sFld;
                this.byFld = (byte)(this.byFld + (byte)n4);
                n4 += n;
                instanceCount += (long)dFld;
                dFld -= (double)f;
                n = (int)((long)n + ((long)n3 ^ (long)f));
                n += n5;
                block13: for (n7 = 1; 3 > n7; ++n7) {
                    n += n3;
                    f -= (float)dFld;
                    switch (n2 % 6 + 2) {
                        case 2: {
                            n4 = n5;
                            int n10 = n2 + 1;
                            iArrFld[n10] = iArrFld[n10] * n3;
                            n8 *= n4;
                            continue block13;
                        }
                        case 3: {
                            if (bl) continue block13;
                            instanceCount += (long)(n7 * n7);
                        }
                        case 4: {
                            this.byFld = (byte)n3;
                            n8 *= (int)dFld;
                            int n11 = n7;
                            iArrFld[n11] = iArrFld[n11] ^ (int)instanceCount;
                            n8 = (int)f;
                        }
                        case 5: {
                            try {
                                n = -169 / n5;
                                n4 = 62797 % n8;
                                n6 = n5 % 1521408199;
                            }
                            catch (ArithmeticException arithmeticException) {}
                            continue block13;
                        }
                        case 6: {
                            this.byFld = (byte)(this.byFld >> (byte)n3);
                        }
                        case 7: {
                            if (!bl) continue block13;
                            continue block13;
                        }
                    }
                }
            }
        } while (++n2 < 386);
        FuzzerUtils.out.println("i i21 i22 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i23 i24 i25 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f1 i26 i27 = " + Float.floatToIntBits(f) + "," + n7 + "," + n8);
        FuzzerUtils.out.println("b2 = " + (bl ? 1 : 0));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld lFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + this.lFld);
        FuzzerUtils.out.println("Test.sFld byFld Test.iArrFld = " + sFld + "," + this.byFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 6);
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
    }
}

