/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 12L;
    public static float fFld = 0.935f;
    public static int iFld = -55522;
    public byte byFld = (byte)55;
    public static volatile boolean bFld = true;
    public static double dFld = 0.80005;
    public int iFld1 = -48997;
    public long[] lArrFld = new long[400];
    public double[] dArrFld = new double[400];
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth2_check_sum;

    public void vMeth1() {
        float f = -75.997f;
        int n = -236;
        int[] nArray = new int[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, 2127);
        FuzzerUtils.init(dArray, 26.43003);
        iFld ^= (int)((float)this.byFld - ((fFld -= 1.0f) + (float)(instanceCount * instanceCount)));
        for (f = 291.0f; f > 13.0f; f -= 1.0f) {
            n = 54663;
            this.lArrFld[(int)(f + 1.0f)] = (long)nArray[(int)f] * -40101L;
            int n2 = (int)f;
            double d = dArray[n2];
            dArray[n2] = d - 1.0;
            if ((double)(--instanceCount) == d) continue;
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth2(int n, int n2) {
        int n3 = 128;
        int n4 = 11;
        int n5 = -52445;
        int n6 = -89;
        int n7 = -47524;
        int n8 = 23965;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, true);
        int n9 = (n2 >>> 1) % 400;
        iArrFld[n9] = iArrFld[n9] - iFld;
        n3 = 1;
        do {
            instanceCount += (long)(-115 + n3 * n3);
            blArray[n3 - 1] = true;
            for (n4 = 5; n4 > 1; n4 -= 2) {
                n5 *= n3;
                for (n6 = 3; n6 > 1; --n6) {
                    iFld -= n;
                    n -= (n5 *= (int)fFld);
                    n2 += 23144;
                }
                n7 += n4 * n5 + n2 - n8;
                n2 += n4;
            }
        } while (++n3 < 370);
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(blArray);
    }

    public static int iMeth(float f, int n, double d) {
        int n2 = 11;
        int n3 = -38628;
        int n4 = -36;
        int n5 = 19;
        int n6 = 21786;
        int n7 = -14824;
        int n8 = 24200;
        Test.vMeth2(n, n);
        iFld += n;
        n = iFld;
        instanceCount = -3821629553L;
        try {
            n2 = 1;
            while (++n2 < 308) {
                iFld += (int)instanceCount;
                instanceCount += (long)(n2 * n2);
                for (n3 = 1; n3 < 5; n3 += 3) {
                    n8 = (short)(n8 + (short)(n3 * n4 + n - n2));
                    for (n5 = 1; n5 < 5; ++n5) {
                        iFld += -1523203516;
                        try {
                            n6 = iArrFld[n3 - 1] % -17280;
                            iFld = n6 % n2;
                            n = n5 / n7;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                        n4 += (int)(19.23f + (float)(n5 * n5));
                    }
                }
            }
        }
        catch (NullPointerException nullPointerException) {}
        long l = (long)(Float.floatToIntBits(f) + n) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n8 + (long)n5 + (long)n6 + (long)n7;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void vMeth(int n, long l) {
        int n2 = 22936;
        int n3 = -70;
        int n4 = 9;
        int n5 = 2508;
        int n6 = -229;
        int n7 = -53809;
        int[] nArray = new int[400];
        double d = -108.45439;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.855f);
        FuzzerUtils.init(nArray, 0);
        for (n2 = 20; n2 < 372; ++n2) {
            fFld += (float)Math.max(++instanceCount, (long)(223 * --n));
            int n8 = n2 - 1;
            float f = fArray[n8] + 1.0f;
            fArray[n8] = f;
            fFld += (float)Math.min(n, -57273) + f + (float)((long)n3-- / ((long)((float)l + fFld) | 1L));
            this.vMeth1();
            l &= (long)nArray[(iFld >>> 1) % 400];
            n3 += (int)((float)Math.abs(Long.reverseBytes(instanceCount)) - Math.abs((float)(-7.0 - this.dArrFld[n2])));
        }
        n >>= (int)((long)(++n3) - instanceCount-- * (long)Test.iMeth(fFld, n2, dFld));
        n3 -= (int)fFld;
        n -= n2;
        block1: for (n4 = 187; 11 < n4; --n4) {
            d = 1.0;
            block2: while (true) {
                double d2;
                d += 1.0;
                if (!(d2 < 9.0)) continue block1;
                l = 0L;
                n6 = 1;
                while (true) {
                    if (1 <= n6) continue block2;
                    iFld += n6 * n6 + this.iFld1 - n5;
                    fArray = FuzzerUtils.float1array(400, 42.755f);
                    ++n6;
                }
                break;
            }
        }
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 24532;
        int n2 = -5;
        int n3 = 183;
        int n4 = -20111;
        int n5 = 4;
        int n6 = -15424;
        float f = 39.995f;
        this.vMeth(iFld, instanceCount);
        this.iFld1 += iFld;
        n = 1;
        while (++n < 287) {
            Test.iArrFld[n - 1] = iFld;
            this.iFld1 = n6;
            int n7 = n;
            this.lArrFld[n7] = this.lArrFld[n7] & 0xFFFFFFFFFFFFFFFDL;
            Test.iArrFld[n] = n;
        }
        for (int n8 : iArrFld) {
            for (n2 = 1; n2 < 63; n2 += 3) {
                n3 += n2 ^ n8;
                for (f = 1.0f; f < 4.0f; f += 1.0f) {
                    Test.iArrFld[(int)f] = 1167285468;
                    Test.iArrFld[(int)f] = (int)instanceCount;
                    instanceCount += (long)n4;
                    instanceCount += (long)(f * (float)n8 + (float)iFld - (float)this.iFld1);
                    this.iFld1 += -6;
                    this.iFld1 <<= n2;
                }
                dFld = n3;
                try {
                    n8 = n4 % -50283;
                    Test.iArrFld[n2] = -104 / n8;
                    n3 /= n2;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n5 = 1;
                while (++n5 < 4) {
                    n4 = -133;
                    instanceCount = n2;
                    n6 = (short)n3;
                    try {
                        iFld = -120 / iArrFld[n5];
                        Test.iArrFld[n5] = 842860189 / iArrFld[n2];
                        this.iFld1 = iArrFld[n5 - 1] % n;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n3 = n;
                }
                n3 -= (int)fFld;
                int n9 = n2 + 1;
                this.lArrFld[n9] = this.lArrFld[n9] - (long)(n3 += n2 + n4);
                n4 += n5;
                n4 *= n8;
            }
        }
        FuzzerUtils.out.println("i22 s2 i24 = " + n + "," + n6 + "," + n2);
        FuzzerUtils.out.println("i25 f2 i26 = " + n3 + "," + Float.floatToIntBits(f) + "," + n4);
        FuzzerUtils.out.println("i27 = " + n5);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
        FuzzerUtils.out.println("byFld Test.bFld Test.dFld = " + this.byFld + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("iFld1 lArrFld dArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(this.lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -166);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

