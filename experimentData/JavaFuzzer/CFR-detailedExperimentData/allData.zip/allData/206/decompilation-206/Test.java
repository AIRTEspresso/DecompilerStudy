/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -46520L;
    public static volatile byte byFld = (byte)121;
    public static short sFld = (short)22404;
    public static float fFld = -24.197f;
    public static long vMeth_check_sum = 0L;
    public static long byMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(int n, float f, int n2) {
        int n3 = -12;
        int n4 = 63555;
        int n5 = 26395;
        int n6 = -5614;
        int n7 = -3;
        int n8 = -9;
        int n9 = 7;
        int n10 = 14;
        int[] nArray = new int[400];
        double d = -74.81373;
        double d2 = 55.117826;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(nArray, 11);
        FuzzerUtils.init((Object[][])lArray, (Object)798186012L);
        n = -994581114;
        for (n3 = 1; 182 > n3; n3 += 2) {
            n &= n3;
            n4 = n3;
            n2 >>= n4;
        }
        for (n5 = 12; n5 < 392; ++n5) {
            for (d = 1.0; d < 4.0; d += 1.0) {
                long[] lArray2 = lArray[n5 - 1][n5 + 1];
                int n11 = n5;
                lArray2[n11] = lArray2[n11] + (long)n6;
            }
            n2 += n5 * n5;
            byFld = (byte)(byFld + (byte)((float)n5 - f));
            for (n8 = 1; n8 < 4; ++n8) {
                for (d2 = 1.0; d2 < 2.0; d2 += 1.0) {
                    n4 = n;
                    n6 = (int)instanceCount;
                }
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(d2) + (long)n10 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])lArray);
    }

    public static byte byMeth(long l, int n, long l2) {
        int n2 = -77;
        int n3 = 6;
        int n4 = -2;
        int n5 = -16491;
        int[] nArray = new int[400];
        float f = 2.422f;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -23852L);
        FuzzerUtils.init(nArray, 5);
        n2 = 1;
        while (++n2 < 166) {
            Test.vMeth1(n2, f, n);
            for (n3 = 1; n3 < 10; ++n3) {
                n5 = 1;
                block5: while (++n5 < 2) {
                    l2 = n;
                    lArray[n2][n3 - 1] = n2;
                    int n6 = n3 + 1;
                    nArray[n6] = nArray[n6] - n;
                    switch (n5 % 1 * 5 + 12) {
                        case 17: {
                            n += n5;
                            int n7 = n3;
                            nArray[n7] = nArray[n7] + n4;
                            n4 = byFld;
                            continue block5;
                        }
                    }
                    sFld = (short)(sFld * (short)n5);
                    l >>= (n += 10);
                }
            }
        }
        long l3 = l + (long)n + l2 + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        byMeth_check_sum += l3;
        return (byte)l3;
    }

    public static void vMeth(long l, boolean bl) {
        double d = 1.312;
        int n = -149;
        int[][][] nArray = new int[400][400][400];
        float f = -2.668f;
        FuzzerUtils.init((Object[][])nArray, (Object)-55);
        for (d = 273.0; d > 16.0; d -= 1.0) {
            Test.byMeth(-28650L, n, instanceCount);
            sFld = (short)(sFld + (short)(d * (double)n + (double)f - (double)f));
            nArray[(int)d][(int)(d - 1.0)] = nArray[(int)(d - 1.0)][(int)(d - 1.0)];
        }
        vMeth_check_sum += l + (long)(bl ? 1 : 0) + Double.doubleToLongBits(d) + (long)n + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum((Object[][])nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -178;
        int n2 = 163;
        int n3 = 20472;
        int n4 = -12500;
        int n5 = 35715;
        int n6 = 243;
        int[] nArray = new int[400];
        long l = 4L;
        long l2 = 1618798475L;
        long[] lArray = new long[400];
        double d = 99.117018;
        double[] dArray = new double[400];
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(nArray, 60213);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(lArray, -9L);
        FuzzerUtils.init(dArray, 0.812);
        for (n = 3; n < 134; ++n) {
            n2 >>>= nArray[n + 1];
            blArray[n] = true;
            int n7 = n + 1;
            long l3 = lArray[n7] - 1L;
            lArray[n7] = l3;
            n2 = (int)l3;
            Test.vMeth(instanceCount, true);
            for (l = 3L; 191L > l; ++l) {
                n3 = n;
                d -= (double)n3;
                n3 = 250;
                n3 >>= 43978;
                instanceCount -= (long)(n2 -= 105);
                int n8 = (int)(l + 1L);
                lArray[n8] = lArray[n8] << -13;
            }
            for (n4 = 11; n4 < 191; ++n4) {
                n3 += n4;
                int n9 = n;
                lArray[n9] = lArray[n9] & (long)n;
                n3 >>= n3;
                for (l2 = 2L; l2 > 1L; --l2) {
                    n3 = 6202;
                    int n10 = n4;
                    dArray[n10] = dArray[n10] - d;
                    fFld *= (float)n;
                    n2 = (int)l2;
                    n2 = 4;
                    nArray[n + 1] = n4;
                    bl = true;
                    n3 += (int)(l2 + instanceCount);
                    byFld = (byte)(byFld + (byte)(l2 * l2));
                    byFld = (byte)-88;
                }
            }
        }
        FuzzerUtils.out.println("i i1 l3 = " + n + "," + n2 + "," + l);
        FuzzerUtils.out.println("i18 d3 i19 = " + n3 + "," + Double.doubleToLongBits(d) + "," + n4);
        FuzzerUtils.out.println("i20 l4 i21 = " + n5 + "," + l2 + "," + n6);
        FuzzerUtils.out.println("b1 iArr bArr = " + (bl ? 1 : 0) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("lArr dArr = " + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + byFld + "," + sFld);
        FuzzerUtils.out.println("Test.fFld = " + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

