/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3446703931L;
    public static byte byFld = (byte)-2;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long fMeth_check_sum = 0L;

    public static float fMeth(double d, int n) {
        int n2 = -15561;
        int n3 = -99;
        int n4 = -1;
        int n5 = -11861;
        int n6 = -153;
        int n7 = -191;
        int n8 = 6;
        int n9 = 12;
        float f = 0.884f;
        int n10 = 28365;
        for (n2 = 4; n2 < 124; ++n2) {
            for (n4 = 1; n4 < 13; ++n4) {
                instanceCount -= (long)n4;
                for (n6 = n2; n6 < 2; ++n6) {
                    n7 &= (int)(instanceCount *= -4424L);
                    n3 -= (int)f;
                    n = n5;
                    n7 = n10;
                }
                f += (float)n2;
            }
            d += (double)f;
            n10 = (short)(n10 - (short)n3);
        }
        for (n8 = 1; n8 < 294; ++n8) {
            d = n;
            f *= (float)instanceCount;
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + (long)n10 + (long)n8 + (long)n9;
        fMeth_check_sum += l;
        return l;
    }

    /*
     * Unable to fully structure code
     */
    public static void vMeth1(int var0, long var1_1) {
        var3_2 = 23800;
        var4_3 = 0.122986;
        var6_4 = new double[400];
        var7_5 = true;
        var8_6 = -2;
        var9_7 = 181;
        var10_8 = new int[400];
        var11_9 = new float[400];
        var12_10 = new long[400][400][400];
        FuzzerUtils.init(var6_4, -111.25194);
        FuzzerUtils.init(var11_9, 1.344f);
        FuzzerUtils.init(var10_8, 13);
        FuzzerUtils.init((Object[][])var12_10, (Object)7L);
        var3_2 = (short)(var3_2 - (short)(Test.fMeth(var4_3, -14) * (float)var0));
        var6_4[(var0 >>> 1) % 400] = -13.0;
        block16: for (var8_6 = 2; var8_6 < 239; ++var8_6) {
            switch (93) {
                case 89: {
                    var0 *= var9_7;
                    Test.instanceCount >>>= 123;
                    var0 -= var9_7;
                    continue block16;
                }
                case 90: {
                    switch ((var8_6 >>> 1) % 6 * 5 + 4) {
                        case 34: {
                            if (!var7_5) ** GOTO lbl31
                            v0 = var8_6;
                            var11_9[v0] = var11_9[v0] - (float)var4_3;
                            var3_2 = (short)(var3_2 + (short)(var8_6 * var8_6));
                            ** GOTO lbl33
lbl31:
                            // 1 sources

                            if (!var7_5) {
                                var0 += var8_6;
                            }
                        }
lbl33:
                        // 5 sources

                        case 10: {
                            var9_7 += (int)var1_1;
                        }
                        case 31: {
                            Test.byFld = (byte)(Test.byFld * (byte)var0);
                        }
                        case 20: {
                            var10_8[var8_6 - 1] = -249;
                        }
                        case 8: {
                            var12_10[var8_6][var8_6 + 1][var8_6 - 1] = var8_6;
                            break;
                        }
                        case 7: {
                            var9_7 += var0;
                            break;
                        }
                        default: {
                            var0 = var9_7;
                        }
                    }
                }
                case 91: {
                    v1 = var8_6 + 1;
                    var10_8[v1] = var10_8[v1] * (int)var4_3;
                    continue block16;
                }
                case 92: {
                    continue block16;
                }
                case 93: {
                    var11_9[var8_6 + 1] = -1.0f;
                    continue block16;
                }
                case 94: {
                    v2 = var8_6 - 1;
                    var10_8[v2] = var10_8[v2] << var0;
                    continue block16;
                }
                default: {
                    Test.instanceCount = var8_6;
                }
            }
        }
        Test.vMeth1_check_sum += (long)var0 + var1_1 + (long)var3_2 + Double.doubleToLongBits(var4_3) + (long)(var7_5 != false ? 1 : 0) + (long)var8_6 + (long)var9_7 + Double.doubleToLongBits(FuzzerUtils.checkSum(var6_4)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11_9)) + FuzzerUtils.checkSum(var10_8) + FuzzerUtils.checkSum((Object[][])var12_10);
    }

    public static void vMeth(int n, int n2) {
        int n3 = 9;
        int n4 = -12;
        int n5 = 39;
        int[][][] nArray = new int[400][400][400];
        boolean bl = false;
        FuzzerUtils.init((Object[][])nArray, (Object)13);
        n ^= n;
        n2 ^= (n2 - (n2 - n2)) * n;
        Test.vMeth1(-64855, instanceCount);
        n3 = 1;
        while (++n3 < 155) {
            if (n3 != 0) {
                vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + (bl ? 1 : 0)) + FuzzerUtils.checkSum((Object[][])nArray);
                return;
            }
            n2 = (int)instanceCount;
            for (n4 = 1; n4 < 10; ++n4) {
                float f = 2.1011f;
                n2 -= (int)(instanceCount *= -117L);
                n2 = byFld;
                n2 = (int)((long)n2 + ((long)n4 * instanceCount + (long)n5 - (long)n4));
                if (bl) {
                    n5 += (int)(-2.18f + (float)(n4 * n4));
                    f -= (float)instanceCount;
                    continue;
                }
                n2 >>= -168;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + (bl ? 1 : 0)) + FuzzerUtils.checkSum((Object[][])nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -19130;
        n *= -n;
        Test.vMeth(5, n);
        n = 55;
        FuzzerUtils.out.println("i = " + n);
        FuzzerUtils.out.println("Test.instanceCount Test.byFld = " + instanceCount + "," + byFld);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

