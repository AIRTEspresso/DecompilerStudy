/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1332573968L;
    public static float fFld = 7.613f;
    public static short sFld = (short)9739;
    public static byte byFld = (byte)41;
    public static double dFld = -2.128732;
    public static boolean bFld = true;
    public static volatile int iFld = 28865;
    public static long vMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(long l, int n) {
        int n2 = -86;
        int n3 = -27186;
        int n4 = -33291;
        int n5 = -10;
        int n6 = 30;
        int n7 = 7;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 73.434f);
        block0: for (n2 = 3; 242 > n2; n2 += 3) {
            for (n4 = 1; n4 < 19; n4 += 3) {
                n3 >>= n2;
                n += (int)fFld;
                byFld = (byte)(l |= 0xEEL);
            }
            if (bFld) {
                n3 += n2;
                sFld = (short)(sFld >> -143);
                for (n6 = 19; 1 < n6; n6 -= 2) {
                    l = (long)dFld;
                    l >>= n5;
                    if (bFld) continue block0;
                    l += (long)n6;
                    if (n == 0) continue;
                    vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                    return;
                }
                continue;
            }
            int n8 = (n4 >>> 1) % 400;
            fArray[n8] = fArray[n8] * (float)n5;
        }
        vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static int iMeth(int n, int n2) {
        int n3 = 11;
        int n4 = 51248;
        int n5 = 101;
        int n6 = -23606;
        int n7 = -185;
        int n8 = -16542;
        int n9 = -58896;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -38440);
        int n10 = (n2 >>> 1) % 400;
        nArray[n10] = nArray[n10] - Math.abs(n2 / (n | 1) + (n2 + sFld));
        int n11 = (n2 >>> 1) % 400;
        int n12 = nArray[n11] + 1;
        nArray[n11] = n12;
        n2 = (int)(instanceCount - (long)n2 - (long)n12);
        for (n3 = 6; n3 < 237; ++n3) {
            fFld += (float)n3;
            Test.vMeth1(instanceCount, n -= 9);
            for (n5 = 1; n5 < 7; ++n5) {
                n2 += n5 * n + n2 - n6;
                fFld = n6;
            }
            n += n3 * n3;
        }
        sFld = (short)(sFld + (short)fFld);
        for (n7 = 9; n7 < 266; ++n7) {
            n9 = 1;
            do {
                byFld = (byte)instanceCount;
                try {
                    n4 %= n5;
                    n6 = n9 / n9;
                    n8 = n7 / nArray[n7 - 1];
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
            } while (++n9 < 6);
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, long l) {
        int n2 = -61669;
        int n3 = -152;
        int n4 = 0;
        int n5 = 0;
        int n6 = 55;
        int n7 = 15770;
        int[][] nArray = new int[400][400];
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 1.263f);
        FuzzerUtils.init(nArray, -12);
        if (bFld) {
            for (n2 = 7; n2 < 189; ++n2) {
                Test.iMeth(n3, 2);
                for (n4 = 1; n4 < 9; ++n4) {
                    try {
                        n3 = n5 % 151;
                        n = n4 % 156;
                        n3 = 986784701 % n2;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    int n8 = n2 - 1;
                    fArray[n8] = fArray[n8] * 7.0f;
                    for (n6 = 2; n6 > 1; --n6) {
                        n = (int)((long)n + ((long)n6 - l));
                        nArray[n2 + 1] = nArray[n6];
                        l = instanceCount;
                        n += n4;
                        l <<= (int)instanceCount;
                        try {
                            n7 = n2 % -23;
                            n = n4 / -37367;
                            nArray[n4 + 1][n2 + 1] = n % n5;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                        n += n3;
                    }
                }
            }
        } else if (bFld) {
            iFld -= sFld;
        }
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -16644;
        int n2 = 15;
        int n3 = -32052;
        int n4 = 12;
        int n5 = -39497;
        int n6 = -13;
        int n7 = -53024;
        int n8 = -11;
        int[] nArray = new int[400];
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(nArray, -16655);
        FuzzerUtils.init((Object[][])lArray, (Object)-31221L);
        n += (int)(fFld -= 1.0f);
        Test.vMeth(iFld, instanceCount);
        n2 = 1;
        block7: while (++n2 < 372) {
            switch (n2 % 7 * 5 + 55) {
                case 59: 
                case 89: {
                    n -= (int)(instanceCount &= (long)n2);
                    n = (int)((long)n + ((long)n2 * instanceCount + (long)n2 - (long)n2));
                    continue block7;
                }
                case 67: {
                    for (n3 = 2; n3 < 68; ++n3) {
                        iFld = (int)dFld;
                        instanceCount = n;
                        n = (int)((float)n + ((float)n3 * fFld + (float)iFld - (float)n2));
                        n = 39212;
                        iFld = (int)fFld;
                        for (n5 = 1; n5 < 2; ++n5) {
                            fFld += (float)n5;
                            n >>= -8;
                            nArray[n5 - 1] = (int)instanceCount;
                            n6 = n5;
                            n4 = (int)((long)n4 + ((long)n5 * (instanceCount >>= n6) + (long)(iFld -= n3) - instanceCount));
                            iFld += (int)instanceCount;
                            long[] lArray2 = lArray[n2][n2];
                            int n9 = n3 - 1;
                            lArray2[n9] = lArray2[n9] - (long)n2;
                        }
                    }
                }
                case 70: {
                    for (n7 = 68; n7 > 1; n7 -= 2) {
                        iFld += (int)dFld;
                        fFld += (float)instanceCount;
                        n = n5;
                    }
                    continue block7;
                }
                case 64: {
                    n8 -= n;
                    continue block7;
                }
                case 62: 
                case 81: {
                    byFld = (byte)(byFld - (byte)instanceCount);
                    continue block7;
                }
            }
            n = n7;
        }
        FuzzerUtils.out.println("i i24 i25 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 i27 i28 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i29 i30 iArr2 = " + n7 + "," + n8 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum((Object[][])lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
        FuzzerUtils.out.println("Test.byFld Test.dFld Test.bFld = " + byFld + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iFld = " + iFld);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

