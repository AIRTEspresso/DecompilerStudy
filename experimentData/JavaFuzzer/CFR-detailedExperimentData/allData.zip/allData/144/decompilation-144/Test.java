/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1331392317368199387L;
    public static int iFld = 241;
    public volatile float fFld = 0.213f;
    public static int iFld1 = -1;
    public volatile boolean bFld = true;
    public double dFld = -32.37157;
    public volatile long[] lArrFld = new long[400];
    public int[] iArrFld = new int[400];
    public static long dMeth_check_sum = 0L;
    public static long lMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;

    public int iMeth(double d, int n, int n2) {
        int n3 = 27204;
        int n4 = -55;
        int n5 = -4;
        int n6 = -14;
        int n7 = -68;
        n3 = 1;
        while (++n3 < 390) {
            instanceCount *= (long)iFld;
            n2 *= n3;
            for (n4 = 1; 4 > n4; n4 += 3) {
                for (n6 = 1; n6 < 4; ++n6) {
                    this.fFld -= -46619.0f;
                    iFld += n6 | n3;
                    n7 /= n4 | 1;
                    if (this.bFld) {
                        n = (int)(d += -19554.0);
                        switch ((iFld >>> 1) % 1 * 5 + 67) {
                            case 68: {
                                n *= iFld;
                                iFld = iFld1;
                                n5 = n;
                            }
                        }
                        continue;
                    }
                    n2 -= n3;
                }
            }
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7;
        iMeth_check_sum += l;
        return (int)l;
    }

    public long lMeth(int n) {
        double d = -2.56817;
        int n2 = 1886;
        int n3 = 11541;
        int n4 = 12;
        int n5 = -10;
        int n6 = -212;
        int n7 = 40200;
        int n8 = 8;
        iFld <<= (int)instanceCount;
        iFld = this.iMeth(d, iFld1, iFld1);
        this.iArrFld[(Test.iFld >>> 1) % 400] = (int)instanceCount;
        for (n2 = 228; n2 > 12; --n2) {
            n = 6312;
            d -= -166.0;
            for (n4 = 1; n4 < 7; ++n4) {
                for (n6 = 2; n6 > 1; --n6) {
                    d -= (double)this.fFld;
                    iFld1 *= (int)this.fFld;
                    instanceCount += instanceCount;
                    n5 = n2;
                    n5 = n3;
                    n7 += n6 | (n8 *= 56162);
                }
            }
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8;
        lMeth_check_sum += l;
        return l;
    }

    public double dMeth() {
        int n = 2;
        int n2 = 61;
        int n3 = -4;
        int n4 = 3790;
        int n5 = 11;
        int n6 = -114;
        int n7 = -11929;
        int n8 = -91;
        int n9 = -10896;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -2.32f);
        n = 21;
        while (n < 349) {
            n2 *= n2;
            fArray[n - 1] = (long)n2 - instanceCount - this.lMeth(-10053);
            iFld = (int)instanceCount;
            iFld1 = n++;
            this.dFld += (double)instanceCount;
            iFld &= n2;
        }
        n8 = (byte)(n8 + (byte)n);
        for (n3 = 12; n3 < 344; ++n3) {
            n5 = 1;
            while (++n5 < 5) {
                iFld &= n9;
                this.fFld -= this.fFld;
                for (n6 = 1; n6 < 1; ++n6) {
                    if (n6 != 0) {
                        // empty if block
                    }
                    int n10 = n6 + 1;
                    this.lArrFld[n10] = this.lArrFld[n10] + (long)iFld1;
                    n7 -= n3;
                }
            }
        }
        long l = (long)(n + n2 + n8 + n3 + n4 + n5 + n9 + n6 + n7) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        dMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        double d = 3.58387;
        double[] dArray = new double[400];
        int n = -1;
        int n2 = 50158;
        int n3 = 183;
        int n4 = 75;
        int n5 = -30656;
        int n6 = 113;
        boolean[] blArray = new boolean[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(dArray, 65.23246);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(fArray, 2.5f);
        int n7 = (iFld >>> 1) % 400;
        this.lArrFld[n7] = this.lArrFld[n7] + (long)(-((double)this.iArrFld[115] * (d * 18557.0)));
        for (int n8 : this.iArrFld) {
            n = 3;
            if (n >= 63) continue;
            iFld = (int)((double)Math.abs(n5 + n2) + dArray[n]);
            for (n3 = 1; n3 < 2; ++n3) {
                boolean bl = false;
                boolean bl2 = instanceCount > (long)n8;
                bl = bl2;
                bl = bl2;
                blArray[n + 1] = bl2;
                if (bl2) continue;
                int n9 = n3;
                long l = this.lArrFld[n9] - 1L;
                this.lArrFld[n9] = l;
                iFld -= (int)((long)n6 + 5637493953923160993L * (long)(--n4) + l);
                switch (n3 % 2 + 48) {
                    case 48: {
                        int n10 = n6;
                        n6 = (byte)(n6 - 1);
                        this.fFld *= (float)n10;
                        this.dMeth();
                        iFld -= n2;
                        break;
                    }
                    case 49: {
                        instanceCount += (long)(n3 * n3);
                        n2 += 12;
                        break;
                    }
                }
                switch ((n >>> 1) % 2 * 5 + 123) {
                    case 129: {
                        n6 = (byte)(n6 >>> (byte)instanceCount);
                        int n11 = n - 1;
                        this.iArrFld[n11] = this.iArrFld[n11] + n2;
                        switch ((n8 >>> 1) % 1 * 5 + 17) {
                            case 22: {
                                iFld1 = n;
                                n8 += 13132;
                                fArray[n + 1] = 1.0f;
                            }
                        }
                        this.fFld += (float)(n3 * iFld) + this.fFld - (float)n3;
                        break;
                    }
                    case 130: {
                        this.iArrFld[n3] = n2;
                        iFld += (int)this.dFld;
                        iFld <<= n;
                    }
                }
                instanceCount += (long)(n3 * n3);
            }
            try {
                iFld = this.iArrFld[(iFld1 >>> 1) % 400] / 1986380531;
                n4 = n3 / -48368;
                this.iArrFld[n] = 244 / n2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            instanceCount += 188L;
            n6 = (byte)(n6 + (byte)(n * n2 + n2 - iFld));
            iFld -= (int)this.dFld;
        }
        FuzzerUtils.out.println("d i1 i2 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("s i3 i4 = " + n5 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("by dArr bArr = " + n6 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("fArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.iFld1 bFld dFld = " + iFld1 + "," + (this.bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("lArrFld iArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

