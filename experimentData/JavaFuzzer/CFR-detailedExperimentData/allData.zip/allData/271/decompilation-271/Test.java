/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 7L;
    public static float fFld = 2.406f;
    public static byte byFld = (byte)-39;
    public static int iFld = -1;
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, short s) {
        double d = -2.32033;
        double[] dArray = new double[400];
        int n2 = 2;
        int n3 = -6;
        int n4 = 22904;
        int n5 = 4694;
        int[][] nArray = new int[400][400];
        long l = -11L;
        int n6 = -78;
        boolean bl = false;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, 33696);
        FuzzerUtils.init(dArray, -29.5127);
        FuzzerUtils.init(fArray, -1.43f);
        d += (double)n;
        for (n2 = 7; n2 < 280; ++n2) {
            block8: for (l = (long)n2; l < 6L; ++l) {
                switch (n2 % 5 * 5 + 63) {
                    case 71: {
                        instanceCount <<= (int)instanceCount;
                        n5 = 1;
                        do {
                            nArray[n5][n5] = n3;
                            nArray[n2 - 1][(int)(l - 1L)] = 147;
                            int n7 = n5 - 1;
                            dArray[n7] = dArray[n7] * -41679.0;
                            instanceCount = n4;
                            n6 = (byte)(n6 - (byte)n);
                            instanceCount *= (long)d;
                            n += n2;
                        } while (++n5 < 1);
                        continue block8;
                    }
                    case 86: {
                        d *= -2.36221;
                        continue block8;
                    }
                    case 80: {
                        fArray[n2 - 1] = n5;
                    }
                    case 78: {
                        n3 += 2;
                        continue block8;
                    }
                    case 67: {
                        n3 <<= (int)instanceCount;
                    }
                }
            }
        }
        vMeth2_check_sum += (long)(n + s) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + l + (long)n4 + (long)n5 + (long)n6 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth1(int n) {
        int n2 = -6;
        int n3 = 3;
        int n4 = -172;
        int n5 = 0;
        int n6 = 1;
        int n7 = 12660;
        int n8 = 18974;
        boolean bl = false;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)-71);
        n = n-- + (int)((long)n * ((long)n - instanceCount - (long)n * instanceCount));
        for (n2 = 4; 303 > n2; ++n2) {
            short s = -4934;
            int n9 = n2;
            byArray[n9] = (byte)(byArray[n9] + 5);
            if (bl) {
                n8 = (short)Math.max(22, n3);
                continue;
            }
            if (bl) {
                Test.vMeth2(n, s);
                n4 = (int)((float)n4 + ((float)n2 * fFld + (float)n4 - (float)n2));
                byFld = (byte)(byFld >> (byte)n4);
                switch (n2 % 3 + 84) {
                    case 84: {
                        n5 = 6;
                        while ((n5 -= 3) > 0) {
                            n3 += n5;
                            iArrFld = FuzzerUtils.int1array(400, 40173);
                            instanceCount += (long)(n5 * n5);
                            int n10 = n2;
                            iArrFld[n10] = iArrFld[n10] * 192;
                            byFld = (byte)(byFld + (byte)(n5 * iFld + iFld - n4));
                        }
                        break;
                    }
                    case 85: {
                        iFld += n2;
                        break;
                    }
                    case 86: {
                        n6 *= n7;
                    }
                }
                continue;
            }
            n = bl ? n2 : (int)instanceCount;
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n8 + n4 + n5 + n6 + n7 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(byArray);
    }

    public void vMeth(long l, int n) {
        float f = 2.403f;
        int n2 = -34406;
        int n3 = -45717;
        int n4 = 92;
        int n5 = 35047;
        int n6 = 5;
        int n7 = 43199;
        int n8 = -25568;
        double d = 2.6251;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 7L);
        float f2 = f;
        f = f2 + 1.0f;
        instanceCount -= (long)f2;
        for (n2 = 9; 236 > n2; ++n2) {
            Test.vMeth1(n2);
            for (n4 = 1; 7 > n4; ++n4) {
                iFld -= n2;
                f = byFld;
            }
            fFld += (float)(n2 * iFld + n3 - n2);
            int n9 = n2 + 1;
            lArray[n9] = lArray[n9] - instanceCount;
            n3 = 20766;
            int n10 = n2;
            iArrFld[n10] = iArrFld[n10] & n8;
            for (n6 = 1; n6 < 7; ++n6) {
                n3 = (int)l;
            }
            n7 += (int)(3355258990889740001L + (long)(n2 * n2));
            n += (int)d;
        }
        vMeth_check_sum += l + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n8 + (long)n6 + (long)n7 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        float f = 0.317f;
        int n = 14;
        int n2 = 140;
        int n3 = 199;
        int n4 = 44388;
        int n5 = 238;
        double d = 71.121114;
        double[][][] dArray = new double[400][400][400];
        boolean bl = true;
        int n6 = -8714;
        long[] lArray = new long[400];
        FuzzerUtils.init((Object[][])dArray, (Object)-7.98574);
        FuzzerUtils.init(lArray, -48250L);
        f = 1.0f;
        do {
            this.vMeth(instanceCount, iFld);
        } while ((f += 1.0f) < 215.0f);
        byFld = (byte)instanceCount;
        iFld *= (int)instanceCount;
        iFld += iFld;
        for (n = 7; 389 > n; ++n) {
            for (n3 = 1; n3 < 66; ++n3) {
                iFld = n5;
                d = 1.0;
                do {
                    switch ((n2 >>> 1) % 2 + 107) {
                        case 107: {
                            iFld <<= n3;
                            iFld += n2;
                            break;
                        }
                        case 108: {
                            Test.iArrFld[n - 1] = n3;
                            n4 += (int)d;
                            iFld += (int)instanceCount;
                            iFld += (int)instanceCount;
                        }
                        default: {
                            double[] dArray2 = dArray[(int)d][n3 + 1];
                            int n7 = n3 + 1;
                            dArray2[n7] = dArray2[n7] * (double)instanceCount;
                            int n8 = (int)d;
                            iArrFld[n8] = iArrFld[n8] * n5;
                            if (!bl) break;
                            lArray[n3] = n2;
                            int n9 = (int)(d - 1.0);
                            lArray[n9] = lArray[n9] << n;
                            iFld = n4;
                            n2 = (int)((double)n2 + (308.0 + d * d));
                        }
                    }
                    int n10 = n3;
                    iArrFld[n10] = iArrFld[n10] - n2;
                    n6 = (short)(n6 - (short)n4);
                    int n11 = n3 - 1;
                    iArrFld[n11] = iArrFld[n11] - (n4 += (int)instanceCount);
                } while ((d += 1.0) < 2.0);
                n4 -= (int)fFld;
            }
        }
        FuzzerUtils.out.println("f i19 i20 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i21 i22 i23 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("d2 b2 s4 = " + Double.doubleToLongBits(d) + "," + (bl ? 1 : 0) + "," + n6);
        FuzzerUtils.out.println("dArr1 lArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])dArray)) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("Test.iFld Test.iArrFld = " + iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -4029);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

