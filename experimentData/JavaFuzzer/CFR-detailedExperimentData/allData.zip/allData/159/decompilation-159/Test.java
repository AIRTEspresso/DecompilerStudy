/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 79L;
    public int iFld = -3;
    public static float fFld = -1.311f;
    public static boolean bFld = true;
    public static double dFld = 0.98551;
    public byte byFld = (byte)93;
    public int iFld1 = -6207;
    public static float fFld1 = 17.148f;
    public int[][] iArrFld = new int[400][400];
    public static long bMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;

    public static void vMeth(long l, int n) {
        int n2 = -4;
        int n3 = 17884;
        int n4 = -14876;
        int n5 = 2730;
        int n6 = 0;
        int n7 = -6;
        int n8 = -9;
        int n9 = -106;
        long l2 = 242L;
        long[] lArray = new long[400];
        float[] fArray = new float[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(lArray, -9L);
        FuzzerUtils.init(fArray, 3.569f);
        FuzzerUtils.init(dArray, -100.96964);
        n2 = 1;
        block5: do {
            lArray = FuzzerUtils.long1array(400, 6L);
            for (l2 = 1L; l2 < 8L; ++l2) {
                instanceCount = n2;
            }
            for (n4 = 1; n4 < 8; ++n4) {
                n5 <<= (int)instanceCount;
            }
            switch (n2 % 3 * 5 + 90) {
                case 101: {
                    n5 ^= (int)instanceCount;
                    instanceCount -= (long)n3;
                    for (n6 = n2; n6 < 8; ++n6) {
                        for (n8 = 1; n8 < 1; ++n8) {
                            int n10 = -27;
                            dFld += dFld;
                            int n11 = n2;
                            fArray[n11] = fArray[n11] - (float)l;
                            n10 = (byte)(n10 + (byte)(45 + n8 * n8));
                        }
                    }
                    continue block5;
                }
                case 105: {
                    n7 = (int)((long)n7 + ((long)n2 * l2 + l2 - (long)n9));
                }
                case 94: 
            }
        } while (++n2 < 194);
        vMeth_check_sum += l + (long)n + (long)n2 + l2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static int iMeth(int n, int n2, int n3) {
        int n4 = -3;
        int n5 = -79;
        int n6 = 108;
        int n7 = 33566;
        int n8 = 40034;
        int n9 = 2;
        int n10 = -55934;
        int n11 = 99;
        double[][] dArray = new double[400][400];
        FuzzerUtils.init(dArray, -2.31288);
        n4 = 1;
        do {
            instanceCount *= (long)(++n);
        } while (++n4 < 265);
        Test.vMeth(instanceCount, -11);
        for (n5 = 3; n5 < 126; ++n5) {
            for (n7 = 13; n5 < n7; --n7) {
                n8 *= n;
                instanceCount = n7;
                n3 %= n7 | 1;
                for (n9 = n5; 1 > n9; ++n9) {
                    instanceCount += instanceCount;
                    dArray[n5 + 1] = FuzzerUtils.double1array(400, 72.82947);
                    n2 = n;
                    n8 = n11;
                }
                instanceCount *= (long)n7;
                n6 >>= 135;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10 + n11) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public static boolean bMeth(long l, int n, int n2) {
        int n3 = 92;
        float f = 0.163f;
        float f2 = -117.318f;
        int n4 = 86;
        int n5 = 11;
        int n6 = 21913;
        int n7 = 12;
        int[] nArray = new int[400];
        long[] lArray = new long[400];
        short[] sArray = new short[400];
        FuzzerUtils.init(nArray, -58175);
        FuzzerUtils.init(lArray, -5950751739634349034L);
        FuzzerUtils.init(sArray, (short)17374);
        n3 = (byte)(n3 + (byte)Math.max((n << (int)l) - nArray[47], (int)((-168.0f - (fFld - (float)n2)) * (fFld += (float)n2))));
        f = 1.0f;
        do {
            float f3 = fFld;
            fFld = f3 + 1.0f;
            n2 >>>= (int)((float)((long)Short.reverseBytes((short)-12927) + ((long)n - ++instanceCount)) - ((float)instanceCount - f3));
            nArray = nArray;
            nArray = nArray;
        } while ((f += 1.0f) < 183.0f);
        bFld = n < Test.iMeth(-4, 23834, n2);
        switch ((n2 >>> 1) % 5 * 5 + 83) {
            case 89: {
                block9: for (n4 = 13; n4 < 268; ++n4) {
                    n5 &= n2;
                    try {
                        n5 /= n4;
                        n2 = -231 % n2;
                        n5 = n % -65249;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    fFld = n;
                    l = n;
                    f2 = 1.0f;
                    block10: while (true) {
                        float f4;
                        f2 += 1.0f;
                        if (!(f4 < 6.0f)) continue block9;
                        n6 = 1;
                        while (true) {
                            if (1 <= n6) continue block10;
                            n7 = (int)f2;
                            instanceCount *= (long)n7;
                            ++n6;
                        }
                        break;
                    }
                }
                break;
            }
            case 107: {
                lArray[(n2 >>> 1) % 400] = (long)f2;
                break;
            }
            case 85: {
                nArray[(n2 >>> 1) % 400] = n4;
                break;
            }
            case 95: 
            case 103: {
                n -= 3;
                break;
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f2) + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(sArray);
        bMeth_check_sum += l2;
        return l2 % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        short s = 628;
        int n = 1;
        int n2 = 17;
        int n3 = -6;
        int n4 = 8;
        int n5 = 19569;
        int n6 = -6;
        int n7 = -13;
        int n8 = -36174;
        int n9 = -26243;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -1348721604L);
        try {
            short s2 = (short)(s + (short)this.iFld);
            s = s2;
            this.iFld &= -(s2 - Short.reverseBytes(s));
            Test.bMeth(instanceCount, -39869, 6);
            this.iFld = this.iFld;
            this.byFld = (byte)(this.byFld % (byte)((long)dFld | 1L));
        }
        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            for (n = 9; n < 265; ++n) {
                instanceCount <<= n;
                if (bFld) {
                    for (n3 = 2; n3 < 98; ++n3) {
                        this.iFld -= n2;
                    }
                    continue;
                }
                for (n5 = 2; 98 > n5; ++n5) {
                    fFld *= (float)n3;
                    block22: for (n7 = 1; n7 < 2; ++n7) {
                        n4 = n;
                        this.iArrFld[n5 - 1][n7] = n;
                        n4 >>= -44981;
                        switch (n5 % 5 * 5 + 32) {
                            case 56: {
                                instanceCount -= (long)n7;
                                continue block22;
                            }
                            case 36: {
                                switch (n7 % 9 * 5 + 56) {
                                    case 69: {
                                        this.iFld += -53180 + n7 * n7;
                                        n6 -= n3;
                                        lArray[n7 + 1] = n;
                                        instanceCount += (long)(-185 + n7 * n7);
                                    }
                                    case 75: 
                                    case 93: {
                                        n4 = -28;
                                        this.iFld += this.iFld;
                                        instanceCount += (long)(93.434f + (float)(n7 * n7));
                                        int[] nArray = this.iArrFld[n7 + 1];
                                        int n10 = n7;
                                        nArray[n10] = nArray[n10] - -970703437;
                                        continue block22;
                                    }
                                    case 72: {
                                        this.iFld = (int)((long)this.iFld + ((long)(n7 * this.byFld + n2) - instanceCount));
                                    }
                                    case 84: {
                                        try {
                                            n8 = this.iFld1 / this.iFld;
                                            n4 = this.iArrFld[n7 + 1][n] % -5603;
                                            n9 = n6 / n6;
                                        }
                                        catch (ArithmeticException arithmeticException) {
                                            // empty catch block
                                        }
                                    }
                                    case 98: {
                                        n8 = n4;
                                    }
                                    case 85: 
                                    case 95: {
                                        if (!bFld) continue block22;
                                        continue block22;
                                    }
                                    case 82: {
                                        fFld1 = this.iFld1;
                                    }
                                }
                                this.iFld1 >>= n8;
                                continue block22;
                            }
                            case 42: {
                                n8 <<= (int)instanceCount;
                                continue block22;
                            }
                            case 49: {
                                n2 += (int)(0.8f + (float)(n7 * n7));
                                continue block22;
                            }
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("s i25 i26 = " + s + "," + n + "," + n2);
        FuzzerUtils.out.println("i27 i28 i29 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i30 i31 i32 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i33 lArr2 = " + n9 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.dFld byFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld) + "," + this.byFld);
        FuzzerUtils.out.println("iFld1 Test.fFld1 iArrFld = " + this.iFld1 + "," + Float.floatToIntBits(fFld1) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

