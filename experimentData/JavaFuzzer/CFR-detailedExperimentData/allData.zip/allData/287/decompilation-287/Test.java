/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 2L;
    public static volatile long lFld = 50L;
    public static boolean bFld = false;
    public float fFld = -1.773f;
    public static long fMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long dMeth_check_sum = 0L;

    public static double dMeth(int n, int n2, boolean bl) {
        float f = 1.949f;
        double d = -1.112982;
        int n3 = -214;
        int n4 = 2;
        int n5 = 5895;
        int n6 = 37;
        int n7 = 53;
        int[] nArray = new int[400];
        int n8 = 28882;
        FuzzerUtils.init(nArray, 117);
        f -= (float)d;
        for (n3 = 122; n3 > 5; --n3) {
            n8 = (short)(n8 + (short)n3);
            instanceCount = n3;
            n2 <<= n2;
            n -= 107;
            instanceCount *= lFld;
            instanceCount = 64338L;
            d = 16717.0;
            for (n5 = 1; 13 > n5; ++n5) {
                n7 = 1;
                do {
                    n2 -= (int)lFld;
                } while (++n7 < 2);
            }
        }
        long l = (long)(n + n2 + (bl ? 1 : 0) + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n8 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
        dMeth_check_sum += l;
        return l;
    }

    public static int iMeth(short s, int n) {
        boolean bl = true;
        int n2 = -168;
        int n3 = 37;
        int[] nArray = new int[400];
        float f = -1.838f;
        FuzzerUtils.init(nArray, -10);
        instanceCount = Math.max(n--, (int)(Test.dMeth(n, n, bl) + (double)n));
        for (int n4 : nArray) {
            n4 <<= n;
            for (n2 = 1; n2 < 4; ++n2) {
                f *= (float)n2;
                n4 += n2 - n;
                lFld += (long)(n2 * n2);
            }
            n4 *= n;
            if (bl) {
                s = (short)(s | 0xFFFFB61A);
                lFld -= (long)n4;
            }
            n4 = -126;
            if (n != 0) {
                // empty if block
            }
            int n5 = (n4 >>> 1) % 400;
            nArray[n5] = nArray[n5] - n2;
            n3 <<= n2;
        }
        long l = (long)(s + n + (bl ? 1 : 0) + n2 + n3 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static float fMeth() {
        short s = -23274;
        int n = -8;
        int n2 = -11;
        int n3 = 11;
        int n4 = 10;
        int n5 = -9;
        double d = 0.94587;
        float f = 2.221f;
        float[] fArray = new float[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(fArray, -2.662f);
        FuzzerUtils.init(blArray, true);
        Test.iMeth(s, n);
        for (float f2 : fArray) {
            for (n2 = 1; n2 < 4; ++n2) {
                n += 41;
            }
            if (bFld) continue;
            for (n4 = 1; n4 < 4; ++n4) {
                n &= n;
                instanceCount += (long)n4 * instanceCount + (long)n5 - (long)(n += s);
                blArray[n4] = bFld;
                n -= 123;
            }
            d += (double)(n <<= n2);
        }
        f -= -7.0f;
        f = n3;
        long l = (long)(s + n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(blArray);
        fMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = -62;
        int n2 = 37535;
        int n3 = -34787;
        int n4 = -58939;
        int n5 = -186;
        int n6 = 39027;
        int[] nArray = new int[400];
        int n7 = 15;
        short s = 8185;
        double d = 124.88787;
        FuzzerUtils.init(nArray, -168);
        n = n++;
        for (n2 = 1; 260 > n2; ++n2) {
            n3 += -85 + n2 * n2;
            n4 = 1;
            do {
                n3 |= Math.abs(n3 * n7);
                block10: for (n5 = 1; n5 < 1; ++n5) {
                    n6 = (int)((double)n6-- - ((double)Short.reverseBytes(s) + d));
                    s = (short)(s + (short)(Test.fMeth() + (float)n6 + (float)n4));
                    n = n2;
                    n6 = (int)((float)n6 + ((float)(n5 * n4 + n) - this.fFld));
                    int n8 = n4 - 1;
                    nArray[n8] = nArray[n8] + n3;
                    n6 += 8;
                    switch (n2 % 5 + 63) {
                        case 63: {
                            d = instanceCount;
                            switch (n5 % 1 * 5 + 112) {
                                case 117: {
                                    n += n5 + n4;
                                    n -= n5;
                                    break;
                                }
                                default: {
                                    int n9 = n5 + 1;
                                    nArray[n9] = nArray[n9] * n;
                                }
                            }
                            n3 = (int)((float)n3 + ((float)n5 * this.fFld + (float)n6 - (float)n2));
                        }
                        case 64: 
                        case 65: 
                        case 66: {
                            d = n5;
                            continue block10;
                        }
                        case 67: {
                            n3 = 1;
                            n3 <<= -241;
                            this.fFld += (float)n5;
                            lFld *= lFld;
                        }
                    }
                }
                n7 = 31;
                s = (short)(s - 243);
                n6 *= (int)instanceCount;
            } while (++n4 < 97);
            n6 <<= n6;
            n3 = n6;
            n += n2;
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 by i4 = " + n4 + "," + n7 + "," + n5);
        FuzzerUtils.out.println("i5 s d = " + n6 + "," + s + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.bFld = " + instanceCount + "," + lFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("fFld = " + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

