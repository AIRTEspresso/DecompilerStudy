/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3576743641427970674L;
    public static int[] iArrFld = new int[400];
    public static volatile double[] dArrFld = new double[400];
    public static float[] fArrFld = new float[400];
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, byte by, short s) {
        double d = -1.129178;
        int n2 = 58684;
        int n3 = 23824;
        int n4 = -16;
        float f = 122.329f;
        float[] fArray = new float[400];
        boolean bl = false;
        FuzzerUtils.init(fArray, 0.857f);
        n = (int)instanceCount;
        d = by;
        n2 = 1;
        do {
            n *= n;
            switch (((n3 += n2 * n2) >>> 1) % 10 + 112) {
                case 112: {
                    n3 += 41024 + n2 * n2;
                }
                case 113: {
                    n += n2 * n + n3 - s;
                    break;
                }
                case 114: {
                    n3 &= n3;
                    break;
                }
                case 115: {
                    n4 = 1;
                    while (++n4 < 7) {
                        n3 += 0 + n4 * n4;
                    }
                    instanceCount += 41L + (long)(n2 * n2);
                    instanceCount += (long)(n2 * n2);
                    break;
                }
                case 116: {
                    n3 = (int)((float)n3 + ((float)((long)n2 * instanceCount) + f - f));
                    break;
                }
                case 117: {
                    break;
                }
                case 118: {
                    bl = false;
                    break;
                }
                case 119: {
                    n = (int)instanceCount;
                }
                case 120: {
                    n3 += n2 * n3 + n4 - n4;
                    break;
                }
                case 121: {
                    s = 0;
                    break;
                }
                default: {
                    n = (int)instanceCount;
                }
            }
        } while (++n2 < 224);
        vMeth1_check_sum += (long)(n + by + s) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static int iMeth(int n, int n2, int n3) {
        short s = -15448;
        int n4 = 18;
        int n5 = 4;
        int n6 = 9;
        int n7 = -241;
        int n8 = 2820;
        double d = -2.33613;
        float f = 0.537f;
        int n9 = 10;
        Test.vMeth1(n3, (byte)58, s);
        for (n4 = 13; n4 < 324; ++n4) {
            d = -3.5626879521929318E18;
            Test.fArrFld[n4 + 1] = n5;
            for (n6 = n4; n6 < 5; ++n6) {
                n *= (int)f;
                d /= (double)((long)f | 1L);
                try {
                    n2 = n6 % n7;
                    n3 = n6 % n;
                    n3 = iArrFld[n6 + 1] % 35313;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n8 = 1;
                block8: while (++n8 < 1) {
                    switch ((n5 >>> 1) % 2 * 5 + 26) {
                        case 36: {
                            n9 = (byte)n;
                            n7 = (int)instanceCount;
                            continue block8;
                        }
                        case 28: {
                            instanceCount -= -62370L;
                            f += (float)(-8L + (long)(n8 * n8));
                            n3 = -17405;
                            continue block8;
                        }
                    }
                    n = n5;
                }
            }
        }
        long l = (long)(n + n2 + n3 + s + n4 + n5) + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + (long)n8 + (long)n9;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void vMeth() {
        int n = -12497;
        int n2 = 45755;
        int n3 = 3;
        int n4 = -11;
        int n5 = 19782;
        int n6 = 129;
        int n7 = 32230;
        double d = -1.6744;
        instanceCount += (long)Test.iMeth(n, n, n);
        n = 14;
        d -= (double)instanceCount;
        instanceCount -= (long)n;
        for (n2 = 12; n2 < 287; ++n2) {
            n *= n3;
            for (n4 = 6; n4 > 1; --n4) {
                n = n5;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7;
    }

    public void mainTest(String[] stringArray) {
        int n = 4;
        int n2 = -123;
        int n3 = 13;
        int n4 = -6;
        int n5 = -10;
        int n6 = 77;
        int n7 = 172;
        int n8 = -22957;
        int n9 = -35403;
        int n10 = 12;
        int n11 = 11998;
        float f = -117.313f;
        for (n = 8; n < 145; ++n) {
            this.vMeth();
            int n12 = n;
            iArrFld[n12] = iArrFld[n12] * n;
        }
        Test.lArrFld[((n2 += 2) >>> 1) % 400] = n;
        n2 = 9;
        for (n3 = 9; n3 < 154; n3 += 3) {
            n4 += n3 * n3;
            n11 = 7;
            n11 = (short)(n11 + (short)(n3 * n3));
            n5 = 1;
            while (++n5 < 275) {
                for (n6 = 2; n3 < n6; --n6) {
                    Test.iArrFld[n5] = n5;
                    Test.iArrFld[n3] = (int)instanceCount;
                    Test.dArrFld[n3] = 6.20961168E8;
                }
                n11 = (short)(n11 - (short)f);
                instanceCount = n4;
                block17: for (n8 = 1; n8 < 2; ++n8) {
                    n4 = -8;
                    n7 += n8 * n5 + n - n6;
                    try {
                        n9 = 199 % n3;
                        n2 = n % -127;
                        Test.iArrFld[n3 - 1] = 1566000365 % n;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    int n13 = n5;
                    iArrFld[n13] = iArrFld[n13] | n2;
                    int n14 = n5 - 1;
                    iArrFld[n14] = iArrFld[n14] * n7;
                    switch (n3 % 8 + 25) {
                        case 25: {
                            n4 = n8;
                            try {
                                n4 = n6 / n4;
                                n2 = n9 / n9;
                                n7 = n9 / n4;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n7 = n10;
                            ++n4;
                            continue block17;
                        }
                        case 26: {
                            instanceCount = 0L;
                            f += (float)(n8 * n8);
                            continue block17;
                        }
                        case 27: {
                            n7 += (int)instanceCount;
                            continue block17;
                        }
                        case 28: {
                            n10 = n;
                            continue block17;
                        }
                        case 29: 
                        case 30: {
                            n9 -= n5;
                            continue block17;
                        }
                        case 31: {
                            instanceCount = n5;
                            continue block17;
                        }
                        case 32: {
                            n11 = 9525;
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 i22 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i23 s2 i24 = " + n4 + "," + n11 + "," + n5);
        FuzzerUtils.out.println("i25 i26 f3 = " + n6 + "," + n7 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i27 i28 i29 = " + n8 + "," + n9 + "," + n10);
        FuzzerUtils.out.println("Test.instanceCount Test.iArrFld Test.dArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.fArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 84);
        FuzzerUtils.init(dArrFld, 14.75313);
        FuzzerUtils.init(fArrFld, -2.37f);
        FuzzerUtils.init(lArrFld, 3133525093405025388L);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

