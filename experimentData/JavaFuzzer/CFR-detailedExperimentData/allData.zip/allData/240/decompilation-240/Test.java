/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2L;
    public static int iFld = -12;
    public static byte byFld = (byte)-70;
    public static boolean bFld = true;
    public static short sFld = (short)14539;
    public static double dFld = 90.59275;
    public static volatile int[] iArrFld = new int[400];
    public static long[][] lArrFld = new long[400][400];
    public float[][] fArrFld = new float[400][400];
    public static long dMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2) {
        int n3 = 170;
        int n4 = 0;
        int n5 = 48;
        int n6 = 29321;
        int n7 = 8;
        int n8 = -10226;
        int n9 = 54068;
        float f = 0.6f;
        int n10 = 13480;
        for (n3 = 213; n3 > 13; --n3) {
            n2 ^= n4;
            f += (float)instanceCount;
            iFld *= (n2 -= byFld);
            for (n5 = 1; n5 < 8; ++n5) {
                iFld -= n4;
                n10 = (short)(n10 + (short)((long)n5 | (long)f));
            }
            for (n7 = 1; 8 > n7; ++n7) {
                iFld += n7 ^ iFld;
                iFld += (int)f;
                n9 = 1;
                do {
                    int n11 = -13;
                    try {
                        Test.iArrFld[n7] = n8 / -24101;
                        n8 = iArrFld[n7] % 32037;
                        n2 = iArrFld[n3] / n11;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n8 *= (int)f;
                } while (++n9 < 2);
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + n10 + n7 + n8 + n9);
    }

    public static void vMeth(long l, long l2, long l3) {
        int n = 62705;
        int n2 = -215;
        int n3 = -25868;
        int n4 = -114;
        int n5 = 7;
        int n6 = -76;
        int n7 = 34805;
        float f = 1.596f;
        float f2 = -2.906f;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 1.45109);
        for (n = 3; 206 > n; ++n) {
            iFld = (int)((long)iFld + ((long)(n * iFld) + l3 - (long)n));
            Test.vMeth1(-38359, n2);
            n2 += n2;
        }
        for (n3 = 4; n3 < 310; ++n3) {
            for (n5 = 1; n5 < 5; n5 += 3) {
                byFld = (byte)(byFld + (byte)l);
                n4 /= (int)((long)f | 1L);
                try {
                    n4 = n6 % iFld;
                    n6 = 13911 % n;
                    iFld = iArrFld[n5 - 1] / n2;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                for (f2 = 5.0f; f2 > (float)n3 && !bFld; f2 -= 1.0f) {
                    long[] lArray = lArrFld[n3 + 1];
                    int n8 = n5;
                    lArray[n8] = lArray[n8] | (long)n4;
                    sFld = (short)(sFld * (short)n4);
                    l2 >>>= n3;
                }
            }
        }
        vMeth_check_sum += l + l2 + l3 + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)Float.floatToIntBits(f2) + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static double dMeth(int n, int n2, int n3) {
        int n4 = 6;
        int n5 = 181;
        int n6 = -59;
        int n7 = -8;
        int n8 = -63;
        int n9 = -134;
        int n10 = 8;
        int[] nArray = new int[400];
        double d = 0.117402;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, -13);
        FuzzerUtils.init(fArray, 0.15f);
        nArray[(n3 >>> 1) % 400] = (int)((long)(--n) * (instanceCount | 0xE9L));
        block0: for (n4 = 1; n4 < 328; ++n4) {
            n5 = nArray[n4];
            for (n6 = 1; 5 > n6; ++n6) {
                boolean bl = true;
                instanceCount %= (long)(n6 << --n7 | 1);
                if (bl) continue block0;
                Test.vMeth(instanceCount, instanceCount, instanceCount);
            }
        }
        iFld = n4;
        sFld = (short)n2;
        for (n8 = 18; n8 < 320; ++n8) {
            int n11 = n8 + 1;
            nArray[n11] = nArray[n11] - 41;
            n10 = 1;
            do {
                d -= (double)iFld;
                int n12 = n10 + 1;
                fArray[n12] = fArray[n12] * (float)n7;
                iFld |= sFld;
            } while (++n10 < 5);
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        dMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 160;
        int n2 = -11;
        int n3 = 0;
        int n4 = 166;
        int n5 = 31;
        int n6 = 8;
        int n7 = -37812;
        int n8 = -22309;
        float f = -1.192f;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -30.86004);
        int n9 = iFld;
        iFld -= (int)Test.dMeth(130, iFld, iFld);
        iFld = n9 << -iFld;
        block12: for (n = 13; n < 323; ++n) {
            try {
                iFld = -759257638 % iFld;
                n2 = -17885 / iArrFld[n];
                n2 = iFld / iFld;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            instanceCount += (long)n;
            for (n3 = 1; n3 < 81; ++n3) {
                instanceCount *= (long)n4;
                n4 *= -48;
                dFld -= -8.0;
                n2 = (int)f;
            }
            n4 &= n3;
            this.fArrFld[n + 1] = this.fArrFld[n - 1];
            switch (n % 8 * 5 + 37) {
                case 39: {
                    n2 = (int)instanceCount;
                    continue block12;
                }
                case 72: {
                    instanceCount -= (long)n;
                    continue block12;
                }
                case 76: {
                    for (n5 = 3; n5 < 81; ++n5) {
                        dFld += (double)n2;
                        sFld = (short)(sFld + (short)(n5 * n5));
                        n2 += n5;
                        instanceCount += (long)n5;
                        for (n7 = 1; n7 < 2; ++n7) {
                            long[] lArray = lArrFld[n7 + 1];
                            int n10 = n5 - 1;
                            lArray[n10] = lArray[n10] - instanceCount;
                            dFld = instanceCount += (long)byFld;
                            int n11 = n7 - 1;
                            dArray[n11] = dArray[n11] + 53644.0;
                        }
                        n6 += n8;
                        instanceCount += (long)dFld;
                        f -= (float)iFld;
                    }
                    n2 = n;
                }
                case 70: {
                    instanceCount = (long)((float)instanceCount + ((float)n * f + (float)n4 - (float)byFld));
                    continue block12;
                }
                case 50: 
                case 53: 
                case 74: {
                    try {
                        Test.iArrFld[n] = n % iArrFld[n];
                        n8 = iArrFld[n - 1] / -34681;
                        Test.iArrFld[n + 1] = n2 % -124;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    continue block12;
                }
                case 56: {
                    n2 += 8;
                    continue block12;
                }
            }
        }
        FuzzerUtils.out.println("i27 i28 i29 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i30 f3 i31 = " + n4 + "," + Float.floatToIntBits(f) + "," + n5);
        FuzzerUtils.out.println("i32 i33 i34 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("dArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + byFld);
        FuzzerUtils.out.println("Test.bFld Test.sFld Test.dFld = " + (bFld ? 1 : 0) + "," + sFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 212);
        FuzzerUtils.init(lArrFld, 13L);
        dMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

