/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 827199520796677453L;
    public static int iFld = -56638;
    public static double[][] dArrFld = new double[400][400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, float f, boolean bl) {
        int n2 = 24091;
        int n3 = -175;
        int n4 = 222;
        int n5 = 44;
        int[] nArray = new int[400];
        double d = -1.58659;
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, -225);
        FuzzerUtils.init(fArray, -22.102f);
        n2 = 1;
        while (++n2 < 350) {
            block1 : switch (n2 % 2 + 45) {
                case 45: {
                    iFld += n;
                    try {
                        iFld = n2 % 4694;
                        n = n2 / n2;
                        nArray[n2 + 1] = iFld / n;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                case 46: {
                    if (bl) {
                        fArray[n2 - 1] = n;
                        break;
                    }
                    switch (n2 % 3 + 10) {
                        case 10: 
                        case 11: {
                            for (n3 = n2; n3 < 5; ++n3) {
                                instanceCount += (long)(n3 * iFld + n4 - iFld);
                                switch (n2 % 1 * 5 + 30) {
                                    default: 
                                }
                                iFld -= n3;
                                n5 = 1;
                                while (++n5 < 1) {
                                    iFld += (int)d;
                                    iFld = (int)instanceCount;
                                    f *= (float)n5;
                                }
                            }
                        }
                        case 12: {
                            int n6 = n2;
                            nArray[n6] = nArray[n6] * n4;
                            break block1;
                        }
                    }
                    n4 += n4;
                }
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + (bl ? 1 : 0) + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth(int n) {
        double d = 2.2807;
        int n2 = 18468;
        int n3 = 26;
        int n4 = -9;
        int n5 = 140;
        int n6 = 4;
        int n7 = -144;
        boolean bl = true;
        float f = -9.649f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 74L);
        n2 = (short)(n2 + 1);
        d = n2;
        block6: for (n3 = 121; n3 > 7; --n3) {
            Test.vMeth1(n, 0.676f, bl);
            n = (int)((long)n + ((long)n3 ^ (long)f));
            switch (n3 % 4 + 12) {
                case 12: {
                    d += (double)n4;
                    n4 += n3;
                    continue block6;
                }
                case 13: {
                    f += -5.0f;
                    if (!bl) continue block6;
                    continue block6;
                }
                case 14: {
                    instanceCount = 13L;
                    n5 = 1;
                    do {
                        for (n6 = 1; n6 < 1; ++n6) {
                            lArray[n6 + 1] = n4;
                            d += -171.0;
                            iFld <<= (int)instanceCount;
                        }
                    } while (++n5 < 14);
                    continue block6;
                }
                case 15: {
                    instanceCount += (long)(n3 * iFld);
                }
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(lArray);
    }

    public static int iMeth() {
        double d = -76.35665;
        int n = -184;
        int n2 = 2;
        int n3 = 14778;
        int[] nArray = new int[400];
        boolean bl = true;
        float f = 0.816f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -8L);
        FuzzerUtils.init(nArray, 146);
        Test.vMeth(iFld);
        for (d = 10.0; d < 228.0 && !bl; d += 1.0) {
            f = instanceCount;
            n2 = 1;
            do {
                lArray[(int)d] = -57974L;
                switch ((int)(d % 4.0 + 124.0)) {
                    case 124: {
                        if (n != 0) {
                            // empty if block
                        }
                        n3 = 1;
                        do {
                            switch (n3 % 1 + 22) {
                                case 22: {
                                    n = (int)instanceCount;
                                    n = (int)f;
                                    n = (int)instanceCount;
                                    break;
                                }
                                default: {
                                    f *= (float)n2;
                                }
                            }
                        } while (--n3 > 0);
                        break;
                    }
                    case 125: {
                        iFld = (int)((long)iFld + ((long)(n2 * n + iFld) - instanceCount));
                        break;
                    }
                    case 126: {
                        iFld -= iFld;
                        break;
                    }
                    case 127: {
                        int n4 = (int)d;
                        nArray[n4] = nArray[n4] - iFld;
                    }
                }
            } while (++n2 < 7);
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -238;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -63462);
        int n2 = (n >>> 1) % 400;
        nArray[n2] = nArray[n2] ^ Test.iMeth();
        FuzzerUtils.out.println("i iArr = " + n + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dArrFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, -49.68167);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

