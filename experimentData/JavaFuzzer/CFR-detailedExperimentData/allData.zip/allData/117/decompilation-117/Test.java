/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 49988L;
    public static int iFld = 14104;
    public static int iFld1 = -127;
    public static int[] iArrFld = new int[400];
    public static short[] sArrFld = new short[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2() {
        int n = -58723;
        int n2 = 9;
        int n3 = -6;
        int n4 = -4;
        int n5 = 4;
        int[] nArray = new int[400];
        float f = 73.164f;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 65.871f);
        FuzzerUtils.init(nArray, -49);
        n = 1;
        while (++n < 276) {
            iFld = 50789;
            int n6 = n;
            fArray[n6] = fArray[n6] + (float)iFld;
            iFld = 737250344;
            nArray[n] = 214;
            iFld = n;
            block4: for (n2 = 1; n2 < 6; ++n2) {
                instanceCount = iFld1;
                int n7 = n2 + 1;
                nArray[n7] = nArray[n7] * (int)instanceCount;
                switch (n % 1 + 109) {
                    case 109: {
                        iFld = (int)instanceCount;
                        for (n4 = 1; n4 < 2; ++n4) {
                            f = 2656.0f;
                            iFld |= n3;
                        }
                        continue block4;
                    }
                    default: {
                        n5 += (int)f;
                    }
                }
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1() {
        int n = -3;
        int n2 = 0;
        int n3 = 6;
        int n4 = -41464;
        int n5 = 19521;
        int[] nArray = new int[400];
        float f = -1.2f;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 29352);
        FuzzerUtils.init(lArray, 1661686759729466649L);
        n -= (int)f;
        n2 = 1;
        do {
            Test.vMeth2();
            n = n3;
            n += (int)instanceCount;
            n = 8;
            if (bl) break;
            n = iFld;
            for (n4 = 1; n4 < 9; ++n4) {
                double d = -116.115108;
                int n6 = n2 - 1;
                nArray[n6] = nArray[n6] - -14;
                switch (n4 % 1 + 50) {
                    case 50: {
                        lArray[n4 + 1] = n3;
                    }
                }
                d = 8.0;
                f += (float)n3;
            }
        } while (++n2 < 185);
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + n2 + n3 + (bl ? 1 : 0) + n4 + n5) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n, int n2) {
        int n3 = -65397;
        int n4 = -6;
        int n5 = 74;
        int n6 = -177;
        int n7 = 29118;
        int n8 = 88;
        int n9 = 199;
        int n10 = 51039;
        double d = 0.4802;
        short[] sArray = new short[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(sArray, (short)31517);
        FuzzerUtils.init(lArray, -8434740146338999967L);
        Test.vMeth1();
        for (n3 = 368; 5 < n3; n3 -= 2) {
            iFld1 ^= n4;
            iFld1 >>= n;
            int n11 = n3 + 1;
            sArray[n11] = (short)(sArray[n11] | (short)instanceCount);
            instanceCount += (long)n2;
        }
        int n12 = (iFld1 >>> 1) % 400;
        lArray[n12] = lArray[n12] >>> iFld1;
        n4 >>= n4;
        d = n2;
        for (n5 = 4; n5 < 341; ++n5) {
            for (n7 = 1; n7 < 5; ++n7) {
                for (n9 = 2; n9 > 1; --n9) {
                    iFld = n8;
                    n = (int)instanceCount;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)n10 + FuzzerUtils.checkSum(sArray) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -6580;
        int n2 = -7;
        int n3 = 14;
        int n4 = -4396;
        int n5 = 118;
        int n6 = 10;
        int n7 = -253;
        int n8 = -12685;
        int n9 = 19835;
        int n10 = 247;
        boolean bl = false;
        float f = 0.687f;
        int n11 = 3933;
        int n12 = -46;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -44435L);
        Test.vMeth(iFld, 0);
        for (n = 9; n < 365; ++n) {
            iFld1 <<= iFld1;
            instanceCount += (long)(n | iFld);
            instanceCount = n2;
            iFld1 = iFld;
            instanceCount -= (long)n;
        }
        iFld1 = n;
        int n13 = (n >>> 1) % 400;
        lArray[n13] = lArray[n13] * (long)n2;
        int n14 = (n >>> 1) % 400;
        lArray[n14] = lArray[n14] * (long)n;
        for (n3 = 374; n3 > 22; n3 -= 3) {
            for (n5 = 5; n5 < 214; ++n5) {
                for (n7 = n5; n7 < 2; ++n7) {
                    Test.iArrFld[n3] = (int)(instanceCount += (long)(n7 * n3 + n5 - iFld1));
                    iFld1 = n5;
                    n6 += n7 - n6;
                    iFld1 = (int)instanceCount;
                    instanceCount = iFld1;
                    instanceCount = iFld;
                    instanceCount += (long)n7 * instanceCount + instanceCount - instanceCount;
                    n8 *= n8;
                }
                instanceCount += (long)n2;
                try {
                    iFld = iArrFld[n5] % 48513;
                    n2 = -207 % n4;
                    Test.iArrFld[n5 - 1] = -24542 % n8;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                f += (float)(n5 * n8 + n2 - n11);
            }
            for (n9 = 6; n9 < 214; ++n9) {
                n8 = 2;
                n12 = (byte)(n12 * (byte)n2);
                int n15 = n9 - 1;
                sArrFld[n15] = (short)(sArrFld[n15] >>> (short)iFld1);
            }
        }
        FuzzerUtils.out.println("i20 i21 b1 = " + n + "," + n2 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i22 i23 i24 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i25 i26 i27 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("f2 s i28 = " + Float.floatToIntBits(f) + "," + n11 + "," + n9);
        FuzzerUtils.out.println("i29 by lArr2 = " + n10 + "," + n12 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.iArrFld Test.sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 105);
        FuzzerUtils.init(sArrFld, (short)20522);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

