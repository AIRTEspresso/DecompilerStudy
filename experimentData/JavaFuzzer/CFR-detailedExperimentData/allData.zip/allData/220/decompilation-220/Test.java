/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -4071716049L;
    public static byte byFld = (byte)-4;
    public static float fFld = 79.222f;
    public static double dFld = 126.128416;
    public static boolean bFld = true;
    public static int iFld = -5;
    public static int[] iArrFld = new int[400];
    public static long fMeth_check_sum;
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1(double d, int n) {
        int n2 = -4;
        int n3 = 14;
        int n4 = -6;
        int n5 = -13051;
        int[][] nArray = new int[400][400];
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -186);
        FuzzerUtils.init(lArray, -4L);
        for (n2 = 6; n2 < 205; ++n2) {
            instanceCount = (long)fFld;
            fFld += (float)instanceCount;
            d *= (double)instanceCount;
            for (n4 = 1; n4 < 8; ++n4) {
                nArray[n2][n2] = (int)instanceCount;
                n = 2;
                n3 %= n | 1;
                n5 += (int)instanceCount;
                n3 += n3;
                instanceCount -= (long)n4;
                n3 -= 58143;
                dFld -= (double)n4;
            }
            if (n5 != 0) {
                // empty if block
            }
            int n6 = n2 + 1;
            lArray[n6] = lArray[n6] * (long)n5;
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth() {
        int n = -13;
        int n2 = -181;
        int n3 = -177;
        int n4 = 48;
        int n5 = -51;
        n = 1;
        while (++n < 252) {
            fFld += (float)(-n + (Test.iMeth1(dFld, 40797) - n));
            if (bFld) break;
            if (n != 0) {
                // empty if block
            }
            for (n2 = 6; n2 > 1; --n2) {
                for (n4 = n; 2 > n4; ++n4) {
                    n5 = n2;
                    n5 += 59603;
                    fFld = instanceCount;
                    n5 -= n5;
                }
            }
            byFld = (byte)(byFld * (byte)n2);
            n5 = (int)instanceCount;
            int n6 = n - 1;
            iArrFld[n6] = iArrFld[n6] * -1841375820;
            instanceCount += (long)(n - n3);
            int n7 = n;
            iArrFld[n7] = iArrFld[n7] / (int)((long)fFld | 1L);
        }
        long l = n + n2 + n3 + n4 + n5;
        iMeth_check_sum += l;
        return (int)l;
    }

    public static float fMeth() {
        int n = -8;
        int n2 = 14;
        int n3 = 2;
        block9: for (n = 6; n < 125; ++n) {
            fFld = Test.iMeth();
            switch ((n >>> 1) % 4 + 11) {
                case 11: {
                    switch (n % 1 * 5 + 7) {
                        case 11: {
                            fFld += (float)(n - n);
                            Test.iArrFld[n] = 33712;
                            continue block9;
                        }
                    }
                    n2 *= n2;
                    instanceCount += (long)(n + n);
                    if (bFld) continue block9;
                    n3 = 1;
                    do {
                        Test.iArrFld[n] = n2;
                        n2 -= n3;
                        n2 += n2;
                        n2 = 76;
                    } while (++n3 < 13);
                    continue block9;
                }
                case 12: {
                    n2 = n3;
                }
                case 13: {
                    byFld = (byte)n;
                    continue block9;
                }
                case 14: {
                    instanceCount = n2;
                }
            }
        }
        long l = n + n2 + n3;
        fMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 62713;
        int n2 = -4;
        int n3 = -159;
        int n4 = -1;
        int n5 = -57275;
        int n6 = 0;
        int n7 = -76;
        int n8 = -245;
        double d = -98.6628;
        float f = 0.628f;
        float[] fArray = new float[400];
        int n9 = -6096;
        long[] lArray = new long[400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(lArray, 48934L);
        FuzzerUtils.init(byArray, (byte)-71);
        FuzzerUtils.init(fArray, 37.761f);
        lArray = lArray;
        lArray = lArray;
        instanceCount = Integer.reverseBytes(Math.abs(14395));
        for (n = 344; 4 < n; --n) {
            n3 = 1;
            while (++n3 < 74) {
                double d2 = d;
                d = d2 + 1.0;
                float f2 = f;
                f = f2 - 1.0f;
                byFld = (byte)((double)(-144 + --n2) - d2 + (double)(f2 - (float)(instanceCount + (long)n2)));
                if (instanceCount-- > (long)(byArray[n + 1] = (byte)(-n4--))) continue;
                f += (float)((long)(n3 * n3 + byFld) - instanceCount);
                for (n5 = 1; n5 < 1; ++n5) {
                    instanceCount += (long)(n5 + n6);
                    int n10 = n3;
                    fArray[n10] = fArray[n10] * ((float)(n3 - n9) + Test.fMeth() - 63.0f);
                    try {
                        Test.iArrFld[n5] = iArrFld[n + 1] / iArrFld[370];
                        n6 = n2 % -100;
                        n2 = -136669383 % n3;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n2 = (int)instanceCount;
                    int n11 = n5 + 1;
                    lArray[n11] = lArray[n11] / (long)(n4 | 1);
                    n2 *= (int)instanceCount;
                    d -= (double)n3;
                    n4 += n5 ^ n3;
                    instanceCount = (long)((float)instanceCount + ((float)((long)n5 * instanceCount) + fFld - (float)(n6 -= 1142)));
                }
                n2 *= byFld;
            }
            n6 <<= n6;
            f += -6.5252849E18f;
            n4 -= 58;
            f += f;
            for (n7 = 3; n7 < 74; ++n7) {
                dFld += (double)n8;
                int n12 = n7 + 1;
                lArray[n12] = lArray[n12] - instanceCount;
                instanceCount += (long)n7 * instanceCount + (long)n4 - instanceCount;
                f *= (float)iFld;
                Test.iArrFld[n7 - 1] = 11;
                iFld >>= (int)instanceCount;
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("d f i3 = " + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f) + "," + n4);
        FuzzerUtils.out.println("i4 i5 s = " + n5 + "," + n6 + "," + n9);
        FuzzerUtils.out.println("i19 i20 lArr = " + n7 + "," + n8 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("byArr fArr = " + FuzzerUtils.checkSum(byArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.dFld Test.bFld Test.iFld = " + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0) + "," + iFld);
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -9);
        fMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

