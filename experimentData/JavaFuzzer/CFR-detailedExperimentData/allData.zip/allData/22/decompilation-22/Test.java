/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 5449956700307727638L;
    public static int iFld = -5;
    public static float fFld = -124.618f;
    public static byte byFld = (byte)74;
    public static boolean bFld = false;
    public static short sFld = (short)-31319;
    public static byte[] byArrFld = new byte[400];
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long fMeth_check_sum;

    public static float fMeth() {
        int n = 30806;
        double d = -1.48171;
        double[] dArray = new double[400];
        int n2 = -226;
        int n3 = 211;
        int n4 = -45744;
        int n5 = 3;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -745590333L);
        FuzzerUtils.init(dArray, 122.114756);
        for (byte by : byArrFld) {
            iFld = (int)instanceCount;
            n = (short)iFld;
        }
        iFld += (int)d;
        fFld -= -16.10104f;
        n2 = 1;
        while (++n2 < 239) {
            n3 = 1;
            do {
                iFld = (int)((float)iFld + ((float)(n3 * n3) + fFld - (float)iFld));
                lArray[n3 + 1] = lArray[n3];
                int n6 = n2;
                dArray[n6] = dArray[n6] + -5.4740311899065528E18;
                for (n4 = 1; n4 < 1; ++n4) {
                    byFld = (byte)iFld;
                    int n7 = n3 + 1;
                    iArrFld[n7] = iArrFld[n7] - (int)fFld;
                }
                iFld += -122 + n3 * n3;
            } while (++n3 < 7);
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        fMeth_check_sum += l;
        return l;
    }

    public static int iMeth1(long l, float f, int n) {
        int n2 = 2;
        int n3 = 11291;
        int n4 = 307;
        int n5 = 153;
        int n6 = -2;
        double d = 1.57526;
        long l2 = -34939L;
        Test.fMeth();
        n2 = 1;
        while (++n2 < 269) {
            iFld = n = n2;
            for (n3 = 1; n3 < 6; ++n3) {
                for (n5 = n2; n5 < 2; ++n5) {
                    n += 40207;
                    n6 >>>= (int)l;
                    iFld += (int)(d -= (double)n5);
                    try {
                        n4 = n3 % n6;
                        n = iArrFld[n2 - 1] / iFld;
                        n6 = 235 / n2;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n4 += n5;
                    iFld >>= (int)l2;
                    int n7 = n3 + 1;
                    iArrFld[n7] = iArrFld[n7] + n2;
                    instanceCount &= (long)n2;
                }
            }
        }
        long l3 = l + (long)Float.floatToIntBits(f) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d) + l2;
        iMeth1_check_sum += l3;
        return (int)l3;
    }

    public static int iMeth(float f, float f2, short s) {
        int n = -59;
        int n2 = -57;
        int n3 = 125;
        int n4 = 7;
        int[][] nArray = new int[400][400];
        int n5 = 67;
        long l = 3281820677L;
        double d = -61.73448;
        double[] dArray = new double[400];
        float[][] fArray = new float[400][400];
        FuzzerUtils.init(nArray, -6);
        FuzzerUtils.init(dArray, 21.24085);
        FuzzerUtils.init(fArray, -2.486f);
        n = 321;
        while ((n -= 3) > 0) {
            iFld = (int)((float)nArray[n][n] - ((float)(iFld - n5) - ((float)iFld + f2)));
            for (l = (long)n; 15L > l; ++l) {
                iFld = (int)(--instanceCount);
                iFld = Test.iMeth1(instanceCount, -1.719f, n);
                s = (short)(s + (short)n);
                for (n3 = 1; n3 < 1; ++n3) {
                    int n6 = n3 - 1;
                    dArray[n6] = dArray[n6] + (double)n4;
                    n2 = iFld;
                }
            }
            iFld += n2;
            n2 += n;
        }
        n2 -= 26243;
        if (bFld) {
            instanceCount += (long)n;
        } else if (bFld) {
            fArray[(n4 >>> 1) % 400][(Test.iFld >>> 1) % 400] = 38730.0f;
        } else if (bFld) {
            d = s;
        }
        long l2 = (long)(Float.floatToIntBits(f) + Float.floatToIntBits(f2) + s + n + n5) + l + (long)n2 + (long)n3 + (long)n4 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        double d = -36.46758;
        int n = 135;
        int n2 = 239;
        int n3 = -20600;
        int n4 = 10;
        int n5 = -33963;
        int n6 = 11;
        int n7 = -1;
        int n8 = 45;
        int n9 = 12;
        int n10 = 61;
        int n11 = -31384;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, true);
        switch ((Test.iMeth(fFld, fFld, sFld) >>> 1) % 10 + 100) {
            case 100: {
                sFld = (short)(sFld - (short)d);
                break;
            }
            case 101: 
            case 102: {
                for (n = 134; n > 4; --n) {
                    instanceCount <<= byFld;
                    byFld = (byte)(byFld + (byte)iFld);
                    for (n3 = 7; 193 > n3; ++n3) {
                        if (bFld) continue;
                        n2 += (int)fFld;
                        n5 = 1;
                        do {
                            n2 >>= n4;
                            fFld = n3;
                            d = instanceCount;
                            n4 += n5 * n5;
                            n2 += (int)fFld;
                        } while (++n5 < 2);
                        n2 -= iFld;
                        n2 -= 49535;
                    }
                    byFld = (byte)(byFld + (byte)n3);
                    if (bFld) break;
                    for (n6 = 10; n6 < 193; ++n6) {
                        iFld += n6;
                    }
                    n2 <<= (int)instanceCount;
                }
                for (n8 = 6; n8 < 157; ++n8) {
                    if (bFld) continue;
                    for (n10 = 6; n10 < 166; ++n10) {
                        int n12 = n8 + 1;
                        iArrFld[n12] = iArrFld[n12] - iFld;
                        n9 += n5;
                    }
                    int n13 = n8 + 1;
                    iArrFld[n13] = iArrFld[n13] + n8;
                }
                break;
            }
            case 103: {
                n11 -= 1061;
            }
            case 104: {
                blArray[(n10 >>> 1) % 400] = bFld;
            }
            case 105: {
                n7 = (int)instanceCount;
                break;
            }
            case 106: {
                instanceCount = n5;
                break;
            }
            case 107: {
                break;
            }
            case 108: {
                n4 += sFld;
                break;
            }
            case 109: {
                n7 = n;
                break;
            }
            default: {
                int n14 = (n >>> 1) % 400;
                iArrFld[n14] = iArrFld[n14] - (int)instanceCount;
            }
        }
        FuzzerUtils.out.println("d3 i14 i15 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("i16 i17 i18 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i19 i20 i21 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i22 i23 i24 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.byFld Test.bFld Test.sFld = " + byFld + "," + (bFld ? 1 : 0) + "," + sFld);
        FuzzerUtils.out.println("Test.byArrFld Test.iArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(byArrFld, (byte)-72);
        FuzzerUtils.init(iArrFld, -217);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        fMeth_check_sum = 0L;
    }
}

