/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1092153931L;
    public static int iFld = -14;
    public volatile int iFld1 = -89;
    public float fFld = 0.767f;
    public static boolean bFld = false;
    public static int iFld2 = 63846;
    public short sFld = (short)12618;
    public static long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(short s) {
        int n = -203;
        int n2 = 3;
        int n3 = -167;
        int n4 = 2;
        int[] nArray = new int[400];
        float f = -1.716f;
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, 136);
        FuzzerUtils.init(dArray, 2.9201);
        if (bFld) {
            n = 1;
            while ((n += 3) < 346) {
                int n5 = n;
                nArray[n5] = nArray[n5] - n;
                dArray[n + 1] = n;
                instanceCount += (long)(n * n + iFld - n);
                f = n;
                if (n != 0) {
                    vMeth_check_sum += (long)(s + n + Float.floatToIntBits(f) + n2 + n3 + n4) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
                    return;
                }
                nArray[n - 1] = -6;
            }
            int n6 = (iFld >>> 1) % 400;
            dArray[n6] = dArray[n6] - (double)n;
            for (n2 = 4; n2 < 329; ++n2) {
                n4 = 1;
                while (++n4 < 5) {
                    instanceCount -= instanceCount;
                    n3 *= n;
                    instanceCount >>= n4;
                }
            }
        } else {
            vMeth_check_sum += (long)(s + n + Float.floatToIntBits(f) + n2 + n3 + n4) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
            return;
        }
        vMeth_check_sum += (long)(s + n + Float.floatToIntBits(f) + n2 + n3 + n4) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static int iMeth1(int n) {
        int n2 = -13136;
        int n3 = 1;
        int n4 = -21373;
        int n5 = 33438;
        int n6 = 226;
        long l = 30266L;
        short s = -21802;
        float[][] fArray = new float[400][400];
        FuzzerUtils.init(fArray, -18.822f);
        n2 = 1;
        while (++n2 < 287) {
            for (l = 1L; l < 6L; ++l) {
                Test.vMeth(s);
                iFld -= iFld;
                block7: for (n4 = 1; n4 < 2; ++n4) {
                    float f = -43.654f;
                    fArray[n2][(int)(l + 1L)] = n6;
                    n6 *= -8;
                    n3 *= (int)l;
                    switch ((n4 >>> 1) % 4 * 5 + 16) {
                        case 33: {
                            f += (float)n6;
                            iFld *= (int)l;
                            continue block7;
                        }
                        case 26: {
                            f = instanceCount;
                        }
                        case 31: {
                            n5 = 34056;
                            instanceCount += (long)n4;
                            n >>= (int)l;
                            continue block7;
                        }
                    }
                }
            }
        }
        long l2 = (long)(n + n2) + l + (long)n3 + (long)s + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    public static int iMeth(int n, int n2) {
        boolean bl = true;
        int n3 = 5565;
        int n4 = 162;
        int n5 = 42;
        int n6 = -5;
        int n7 = 29426;
        int n8 = 127;
        int n9 = -13;
        int n10 = 3421;
        int[] nArray = new int[400];
        float f = 0.2f;
        double d = 59.97539;
        FuzzerUtils.init(nArray, 3);
        bl = Test.iMeth1(iFld) <= n3;
        for (n4 = 4; n4 < 238; n4 += 2) {
            int n11 = n4 - 1;
            nArray[n11] = nArray[n11] - iFld;
            for (n6 = 1; n6 < 13; ++n6) {
                iFld = (int)((long)iFld + ((long)n6 | (long)f));
            }
            for (n8 = 1; n8 < 13; ++n8) {
                iFld2 -= (n9 >>= -12);
                n3 = (short)(n3 + (short)(-29013L + (long)(n8 * n8)));
                n10 = 1;
                while (++n10 < 2) {
                    instanceCount = n8;
                    int n12 = n10;
                    nArray[n12] = nArray[n12] + n7;
                    instanceCount += (long)(n10 ^ n2);
                    if (iFld == 0) continue;
                }
                d -= 166.0;
            }
        }
        long l = (long)(n + n2 + (bl ? 1 : 0) + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f) + n8 + n9 + n10) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        double d = -1.111049;
        int n = -35552;
        int n2 = -8;
        int n3 = 11115;
        int n4 = 6;
        int n5 = 23886;
        int[] nArray = new int[400];
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        int n6 = -93;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -1651258823L);
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(nArray, 0);
        switch ((iFld-- >>> 1) % 9 * 5) {
            case 15: {
                d = iFld;
                instanceCount += (long)(d - (double)((long)iFld - instanceCount) + d);
            }
            case 5: {
                n = 1;
                do {
                    for (n2 = 2; n2 < 168; ++n2) {
                        n4 = 1;
                        block37: do {
                            iFld += n4 * n4;
                            switch (n4 % 10 * 5 + 126) {
                                case 170: {
                                    instanceCount += (long)(-116.246f + (float)(n4 * n4));
                                    this.iFld1 += n4;
                                    if (!bl) continue block37;
                                    break;
                                }
                                case 154: {
                                    instanceCount = (long)(-15032.0f - (-2.27f - (float)Math.max(n5, -14)) - (float)iFld - (this.fFld -= 1.0f));
                                    n5 -= Test.iMeth(64579, 12);
                                    n3 = n;
                                    d = iFld2;
                                    break;
                                }
                                case 157: {
                                    this.iFld1 -= iFld;
                                    break;
                                }
                                case 176: {
                                    break;
                                }
                                case 144: {
                                    n3 = n5;
                                    n5 = (int)this.fFld;
                                    iFld2 *= -992432826;
                                    switch ((n3 >>> 1) % 10 + 85) {
                                        case 85: {
                                            n5 = 80333139;
                                            break;
                                        }
                                        case 86: {
                                            lArray[n4] = instanceCount;
                                            this.iFld1 %= iFld | 1;
                                        }
                                        case 87: {
                                            this.iFld1 = iFld2;
                                        }
                                        case 88: {
                                            if (bl) break;
                                            instanceCount += (long)n4;
                                            break;
                                        }
                                        case 89: {
                                            n3 ^= (int)instanceCount;
                                            break;
                                        }
                                        case 90: {
                                            instanceCount = n6;
                                            break;
                                        }
                                        case 91: {
                                            if (bFld) break;
                                        }
                                        case 92: {
                                            n5 += n4 * n4;
                                            break;
                                        }
                                        case 93: {
                                            instanceCount = this.iFld1;
                                            break;
                                        }
                                        case 94: {
                                            this.iFld1 += n4 * iFld2 + n4 - n5;
                                            break;
                                        }
                                        default: {
                                            this.fFld *= (float)n5;
                                            break;
                                        }
                                    }
                                    continue block37;
                                }
                                case 160: {
                                    this.iFld1 = (int)this.fFld;
                                    break;
                                }
                                case 171: {
                                    lArray[n4 + 1] = instanceCount;
                                    break;
                                }
                                case 152: {
                                    this.iFld1 *= (int)instanceCount;
                                    break;
                                }
                                case 173: {
                                    int n7 = n2 + 1;
                                    nArray[n7] = nArray[n7] * n;
                                    break;
                                }
                                case 162: {
                                    this.iFld1 -= this.iFld1;
                                    break;
                                }
                                default: {
                                    instanceCount >>= n3;
                                }
                            }
                        } while (++n4 < 2);
                    }
                } while ((n += 2) < 299);
            }
            case 44: {
                int n8 = (n3 >>> 1) % 400;
                nArray[n8] = nArray[n8] * (int)this.fFld;
            }
            case 11: {
                iFld2 += -1208575172;
                break;
            }
            case 6: {
                instanceCount -= (long)n4;
            }
            case 18: {
                instanceCount -= (long)n4;
                break;
            }
            case 1: {
                instanceCount = n;
            }
            case 3: {
                this.iFld1 = -12;
                break;
            }
            case 29: {
                this.sFld = (short)(this.sFld << 1);
            }
        }
        FuzzerUtils.out.println("d i i1 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("i2 i3 b = " + n3 + "," + n4 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i4 by lArr = " + n5 + "," + n6 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("bArr iArr2 = " + FuzzerUtils.checkSum(blArray) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld iFld1 = " + instanceCount + "," + iFld + "," + this.iFld1);
        FuzzerUtils.out.println("fFld Test.bFld Test.iFld2 = " + Float.floatToIntBits(this.fFld) + "," + (bFld ? 1 : 0) + "," + iFld2);
        FuzzerUtils.out.println("sFld Test.lArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -1585976315551056196L);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

