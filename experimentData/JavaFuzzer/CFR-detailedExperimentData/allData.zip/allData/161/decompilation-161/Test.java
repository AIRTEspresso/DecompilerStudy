/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3479512115273054217L;
    public static volatile short sFld = (short)7380;
    public static float fFld = 1.146f;
    public static boolean bFld = false;
    public static byte byFld = (byte)-60;
    public static long[] lArrFld = new long[400];
    public boolean[][] bArrFld = new boolean[400][400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth() {
        int n = 8;
        int n2 = -60145;
        int n3 = -19194;
        int n4 = 8;
        int[] nArray = new int[400];
        int n5 = -98;
        FuzzerUtils.init(nArray, 40232);
        n += (int)fFld;
        n += n;
        n = (int)instanceCount;
        for (long l : lArrFld) {
            n2 = (int)instanceCount;
            nArray[(n2 >>> 1) % 400] = (int)instanceCount;
            l -= l;
            int n6 = (n2 >>> 1) % 400;
            nArray[n6] = nArray[n6] - n;
            for (n3 = 1; n3 < 4; ++n3) {
                n4 = n3;
                n5 = (byte)n3;
                n = n4;
                n2 = -89;
                n4 -= 252;
                n2 -= (int)fFld;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth1(int n) {
        int n2 = -59434;
        int n3 = 11177;
        int n4 = -138;
        int n5 = -53;
        long l = 4L;
        n2 = 1;
        while (++n2 < 325) {
            n -= (int)((float)n2 + ((fFld -= 1.0f) + (float)(n * n2)));
            Test.vMeth();
            n |= 0xFFFFFFFB;
            n -= (int)instanceCount;
            bFld = false;
            for (l = 5L; l > 1L; l -= 3L) {
                n3 = 58;
                for (n4 = 1; n4 < 5; ++n4) {
                }
                fFld = n;
                n5 += (int)fFld;
                n5 = sFld;
            }
        }
        long l2 = (long)(n + n2) + l + (long)n3 + (long)n4 + (long)n5;
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    /*
     * Unable to fully structure code
     */
    public static int iMeth() {
        var0 = -146;
        var1_1 = -71;
        var2_2 = -8245;
        var3_3 = -30168L;
        var5_4 = 2.5068;
        var0 = 1;
        do {
            Test.iMeth1(var0);
            var1_1 = 1;
            do {
                if (var1_1 != 0) {
                    // empty if block
                }
                block12: for (var3_3 = 1L; var3_3 < 1L; ++var3_3) {
                    Test.fFld -= (float)var1_1;
                    v0 = (int)var3_3;
                    Test.lArrFld[v0] = Test.lArrFld[v0] + (long)var0;
                    var5_4 = var2_2 += 34004;
                    Test.instanceCount += var3_3 * var3_3 + (long)var0 - Test.instanceCount;
                    var2_2 *= var2_2;
                    switch ((int)(var3_3 % 8L * 5L + 59L)) {
                        case 95: {
                            Test.fFld = -53.574f;
                            Test.instanceCount >>= 63;
                            var2_2 = 2;
                            continue block12;
                        }
                        ** case 66:
lbl28:
                        // 2 sources

                        case 60: {
                            Test.byFld = (byte)(Test.byFld << -17);
                        }
                        case 91: {
                            Test.instanceCount >>= (int)Test.instanceCount;
                        }
                        case 85: {
                            var2_2 += (int)(var3_3 * (long)var0 + Test.instanceCount - (long)var0);
                            continue block12;
                        }
                        case 62: {
                            var2_2 <<= var0;
                            continue block12;
                        }
                        case 70: {
                            var2_2 += (int)(var3_3 ^ (long)var2_2);
                            continue block12;
                        }
                        case 89: {
                            if (var2_2 == 0) continue block12;
                            continue block12;
                        }
                        default: {
                            Test.fFld = var1_1;
                        }
                    }
                }
            } while (++var1_1 < 7);
        } while (++var0 < 221);
        var7_5 = (long)(var0 + var1_1) + var3_3 + (long)var2_2 + Double.doubleToLongBits(var5_4);
        Test.iMeth_check_sum += var7_5;
        return (int)var7_5;
    }

    public void mainTest(String[] stringArray) {
        int n = -8627;
        int n2 = -2;
        int n3 = -106;
        int n4 = 47758;
        int n5 = -59;
        int n6 = 53087;
        int n7 = -183;
        int n8 = 11387;
        int n9 = 57;
        int[][] nArray = new int[400][400];
        double d = -9.3033;
        long l = -11L;
        FuzzerUtils.init(nArray, 26369);
        int[] nArray2 = nArray[(n >>> 1) % 400];
        nArray2[381] = nArray2[381] >> (int)(instanceCount <<= sFld - n + (n ^ n) + Test.iMeth());
        block9: for (n2 = 7; n2 < 171; ++n2) {
            n3 = n = (int)d;
            if (bFld) {
                this.bArrFld[n2][n2 + 1] = bFld;
                fFld *= (float)n2;
            }
            for (n4 = 7; 153 > n4; ++n4) {
                instanceCount |= 0xFFFFFFFFFFFF6E62L;
                nArray[n4][n2 + 1] = n5;
            }
            switch (n2 % 2 + 53) {
                case 53: {
                    instanceCount -= (long)n3;
                    try {
                        n = n5 % -244;
                        n5 = nArray[n2 - 1][n2 - 1] % -146;
                        n = n5 / -37733;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n5 = (int)instanceCount;
                    continue block9;
                }
                case 54: {
                    fFld += (float)(n2 * n2);
                    continue block9;
                }
                default: {
                    n3 <<= n3;
                    for (n6 = n2; 153 > n6; ++n6) {
                        switch (n6 % 2 + 80) {
                            case 80: 
                            case 81: {
                                int[] nArray3 = nArray[n6 + 1];
                                int n10 = n6 + 1;
                                nArray3[n10] = nArray3[n10] >>> n2;
                                n -= n4;
                                n5 -= n5;
                                d = n6;
                            }
                        }
                        n5 = (int)instanceCount;
                        n3 = n7;
                        n5 = n;
                        for (n8 = 1; n8 > 1; --n8) {
                            n3 = n9;
                            l = n4;
                            int[] nArray4 = nArray[n6 + 1];
                            int n11 = n6 + 1;
                            nArray4[n11] = nArray4[n11] - (int)fFld;
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i13 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("d1 i15 i16 = " + Double.doubleToLongBits(d) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i17 i18 i19 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i20 l3 iArr1 = " + n9 + "," + l + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + sFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.byFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + byFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("bArrFld = " + FuzzerUtils.checkSum(this.bArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -3705431464775492841L);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

