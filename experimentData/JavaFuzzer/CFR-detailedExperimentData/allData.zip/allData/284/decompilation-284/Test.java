/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 42421L;
    public static boolean bFld = false;
    public static byte byFld = (byte)-86;
    public static double dFld = 48.119739;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(long l, int n, long l2) {
        int n2 = 31712;
        int n3 = 6;
        int n4 = -64675;
        int n5 = -51026;
        int n6 = 7;
        int n7 = -104;
        int n8 = -13;
        int[] nArray = new int[400];
        double d = -1.9785;
        boolean bl = true;
        FuzzerUtils.init(nArray, 57286);
        for (n2 = 10; n2 < 293; ++n2) {
            n = n2;
            if (n != 0) {
                vMeth2_check_sum += l + (long)n + l2 + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)n8 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
                return;
            }
            int n9 = n2;
            lArrFld[n9] = lArrFld[n9] | instanceCount;
            for (n4 = n2; n4 < 6; ++n4) {
                l = n4;
                int n10 = n4 - 1;
                nArray[n10] = nArray[n10] - -20;
                int n11 = n2;
                nArray[n11] = nArray[n11] - -11370;
                if (n3 != 0) {
                    vMeth2_check_sum += l + (long)n + l2 + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)n8 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
                    return;
                }
                instanceCount += (long)(n4 * n3 + n) - l2;
                n = (int)l2;
            }
            for (d = 1.0; d < 6.0; d += 1.0) {
                for (n7 = 1; n7 < 2; ++n7) {
                    n8 -= 29455;
                    bl = false;
                }
            }
        }
        vMeth2_check_sum += l + (long)n + l2 + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)n8 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(double d, int n, double d2) {
        double d3 = -104.51921;
        int n2 = -3;
        int n3 = -23382;
        int n4 = -11;
        int n5 = 20;
        int n6 = -6;
        int[][] nArray = new int[400][400];
        FuzzerUtils.init(nArray, -5);
        Test.vMeth2(instanceCount, n, instanceCount);
        for (d3 = 8.0; d3 < 195.0; d3 += 1.0) {
            n3 = 1;
            while (++n3 < 9) {
                n2 += n3;
                switch ((n >>> 1) % 8 * 5 + 76) {
                    case 112: {
                        int[] nArray2 = nArray[n3];
                        int n7 = n3 - 1;
                        nArray2[n7] = nArray2[n7] | (int)(instanceCount *= (long)n);
                        break;
                    }
                    case 105: {
                        for (n4 = 1; n4 > 1; --n4) {
                            instanceCount += (long)(n4 + n);
                            n += n4;
                            bFld = false;
                            n5 = n2 = n3;
                            n2 += n2;
                        }
                        break;
                    }
                    case 104: {
                        n2 = 45380;
                    }
                    case 90: {
                        break;
                    }
                    case 89: {
                        byFld = (byte)(byFld << (byte)n);
                        break;
                    }
                    case 83: {
                        try {
                            n = nArray[(n2 >>> 1) % 400][(int)(d3 - 1.0)] % n2;
                            n2 = n % 495600166;
                            n = n4 % 203;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                    case 111: {
                        int[] nArray3 = nArray[(int)(d3 - 1.0)];
                        int n8 = (int)(d3 + 1.0);
                        nArray3[n8] = nArray3[n8] + (int)d3;
                        break;
                    }
                    case 95: {
                        try {
                            n5 = 1833900443 % n5;
                            n5 = -21927 / n4;
                            n = n4 / n6;
                            break;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                }
            }
        }
        vMeth1_check_sum += Double.doubleToLongBits(d) + (long)n + Double.doubleToLongBits(d2) + Double.doubleToLongBits(d3) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n, int n2) {
        double d = -1.21148;
        int n3 = 13;
        int n4 = -7;
        int n5 = 14;
        int n6 = 9447;
        int n7 = -63;
        int n8 = -3125;
        int[] nArray = new int[400];
        float f = -32.939f;
        FuzzerUtils.init(nArray, 13);
        Test.vMeth1(d, n2, d);
        instanceCount <<= n2;
        nArray[(n3 >>> 1) % 400] = n2;
        n3 = (int)d;
        n3 = n2;
        for (n4 = 3; n4 < 169; ++n4) {
            int n9 = n4 + 1;
            nArray[n9] = nArray[n9] + (int)d;
            for (n6 = 1; n6 < 10; ++n6) {
                f *= -2.0f;
                n += 37072;
                n7 += n6;
                n8 = 1;
                while ((n8 += 2) < 2) {
                    instanceCount = n;
                    instanceCount += (long)(n8 - n6);
                    nArray[n8] = n;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + (long)n8 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -7535;
        int n2 = 48174;
        int n3 = -16433;
        int n4 = -240;
        int n5 = -2;
        int n6 = 53507;
        int n7 = -13;
        int n8 = 62;
        int n9 = 74;
        int n10 = 127;
        int n11 = 19866;
        int n12 = -17917;
        int n13 = -203;
        int[] nArray = new int[400];
        float f = -87.472f;
        FuzzerUtils.init(nArray, 24590);
        n = 1;
        block16: while (++n < 226) {
            for (n2 = n; n2 < 111; n2 += 2) {
                Test.vMeth(n2, n);
                f = n3;
                for (n4 = 1; n4 < 1 && !bFld; ++n4) {
                    int n14 = n2 - 1;
                    nArray[n14] = nArray[n14] >> (int)instanceCount;
                    n5 >>= n2;
                    f += (float)n4;
                    f += (float)n4;
                    int n15 = n2 + 1;
                    nArray[n15] = nArray[n15] - (int)dFld;
                    instanceCount += (long)(n4 ^ n3);
                }
                int n16 = n + 1;
                nArray[n16] = nArray[n16] - n3;
                nArray[n2] = 6;
                if (bFld) continue block16;
            }
        }
        for (n6 = 7; n6 < 158; ++n6) {
            dFld -= dFld;
            byFld = (byte)(byFld - (byte)n3);
            block20: for (n8 = n6; n8 < 166; n8 += 3) {
                n9 += n8 - n7;
                n10 = 1;
                do {
                    instanceCount = -59826L;
                } while (++n10 < 1);
                switch (n8 % 7 * 5 + 42) {
                    case 64: {
                        switch (n6 % 5 + 107) {
                            case 107: {
                                n11 = n8;
                                if (n11 >= 1) break;
                                nArray[n11] = n2;
                                n7 = (int)((long)n7 + ((long)(n11 * n6) + instanceCount - instanceCount));
                                break;
                            }
                            case 108: {
                                n12 = -4;
                                break;
                            }
                            case 109: {
                                n13 *= (int)f;
                                break;
                            }
                            case 110: {
                                nArray[n6] = 19;
                                break;
                            }
                            case 111: {
                                n3 += n8 | n5;
                            }
                        }
                    }
                    case 54: {
                        n3 += n8 * n8;
                        continue block20;
                    }
                    case 45: {
                        n5 *= (int)f;
                    }
                    case 76: {
                        if (!bFld) continue block20;
                        continue block20;
                    }
                    case 52: {
                        instanceCount += (long)(n8 + n);
                        continue block20;
                    }
                    case 70: {
                        nArray[n8 - 1] = (int)f;
                        continue block20;
                    }
                    case 68: {
                        f += (float)n4;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f1 i25 i26 = " + Float.floatToIntBits(f) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i27 i28 i29 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i30 i31 i32 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("i33 i34 iArr3 = " + n12 + "," + n13 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.byFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + byFld);
        FuzzerUtils.out.println("Test.dFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 39886L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

