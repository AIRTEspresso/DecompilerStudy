/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3628910667L;
    public static double dFld = 2.79858;
    public static float fFld = -60.894f;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        float f = 96.689f;
        boolean bl = true;
        int n2 = -20611;
        int n3 = -10611;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 23.91101);
        instanceCount = n;
        f += (float)n;
        dFld += 0.0;
        f -= 80.0f;
        for (n2 = 1; n2 < 191; n2 += 3) {
            int n4 = n2;
            iArrFld[n4] = iArrFld[n4] % (n | 1);
            instanceCount = n3;
            instanceCount %= (long)(n3 | 1);
            n <<= n;
            n3 -= 14958;
            instanceCount = n2;
            int n5 = n2 + 1;
            dArray[n5] = dArray[n5] - 1264.0;
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + (bl ? 1 : 0) + n2 + n3) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth(int n, int n2) {
        float f = 7.519f;
        boolean bl = false;
        int n3 = 3;
        int n4 = 27288;
        int n5 = 19328;
        int n6 = -17676;
        Test.vMeth1(n2);
        f = -14.0f;
        n = n2;
        n3 = 1;
        while (++n3 < 333) {
            block5: for (n4 = 1; n4 < 5; ++n4) {
                if (bl) continue;
                if (n2 != 0) {
                    vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + (bl ? 1 : 0) + n3 + n4 + n5 + n6);
                    return;
                }
                f += (float)instanceCount;
                n2 *= 16;
                switch (n4 % 2 + 51) {
                    case 51: {
                        int n7 = n3 + 1;
                        iArrFld[n7] = iArrFld[n7] ^ n6;
                        n2 <<= (int)instanceCount;
                        continue block5;
                    }
                    case 52: {
                        n2 -= n;
                    }
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + (bl ? 1 : 0) + n3 + n4 + n5 + n6);
    }

    public static int iMeth(float f) {
        int n = -12;
        int n2 = -49981;
        int n3 = -14;
        int n4 = -61863;
        int n5 = 30784;
        short[][] sArray = new short[400][400];
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -7222466420424892458L);
        FuzzerUtils.init(sArray, (short)22852);
        for (n = 9; n < 233; ++n) {
            int n6 = n + 1;
            lArray[n6] = lArray[n6] + (long)n;
            for (n3 = 1; n3 < 7; ++n3) {
                Test.vMeth(n4, n);
            }
            lArray[n + 1] = n3;
            instanceCount = 152L;
            n2 += n;
            n2 += n + n2;
            sArray[n][n] = (short)n;
            n4 *= n;
        }
        n5 = (short)f;
        if (bl) {
            n2 = 74;
            n4 >>>= n2;
        } else {
            n4 += (int)instanceCount;
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(sArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -233;
        int n2 = -135;
        int n3 = -7;
        int n4 = 166;
        int n5 = 8;
        int n6 = -43722;
        int n7 = -63123;
        int n8 = -30339;
        int n9 = -11;
        int n10 = -46;
        int n11 = -3;
        int[] nArray = new int[400];
        boolean bl = false;
        float f = -37.797f;
        FuzzerUtils.init(nArray, -9);
        for (n = 2; n < 371; ++n) {
            for (n3 = 2; 68 > n3; ++n3) {
                nArray[n - 1] = -(n2-- + (n4 <<= 222));
                n2 |= 0xB7CC;
                dFld = 63.34771;
                n4 += 15;
                int n12 = n3 - 1;
                nArray[n12] = nArray[n12] ^ n;
            }
            n2 = n4 += n3;
            dFld = fFld;
        }
        for (n5 = 8; 392 > n5; ++n5) {
            for (n7 = n5; n7 < 66; ++n7) {
                switch ((n6 >>> 1) % 1 + 89) {
                    case 89: {
                        n6 <<= -8;
                        for (f = 1.0f; f < 1.0f; f += 2.0f) {
                            n4 -= n5;
                            if (bl) break;
                            n4 = (int)instanceCount;
                            n4 <<= n8;
                            instanceCount /= (long)(n6 | 1);
                        }
                        n4 += 5123;
                    }
                }
                for (n10 = 1; n10 < 1; ++n10) {
                    if (bl) continue;
                    n2 += 53660;
                    n4 <<= n9;
                    if (bl) continue;
                    --n11;
                }
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 b3 i16 = " + n4 + "," + (bl ? 1 : 0) + "," + n5);
        FuzzerUtils.out.println("i17 i18 i19 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("f3 i20 i21 = " + Float.floatToIntBits(f) + "," + n9 + "," + n10);
        FuzzerUtils.out.println("i22 iArr = " + n11 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -4);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

