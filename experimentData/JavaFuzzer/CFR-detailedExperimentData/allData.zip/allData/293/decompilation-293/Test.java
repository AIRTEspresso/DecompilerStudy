/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2322956587539681484L;
    public static float fFld = -2.775f;
    public static double dFld = 8.7092;
    public static short sFld = (short)28341;
    public int iFld = 6591;
    public static volatile long[] lArrFld = new long[400];
    public static long vSmallMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        int n4 = -120;
        int n5 = -17;
        int n6 = -60891;
        int n7 = -241;
        int n8 = 44;
        int n9 = 1;
        int n10 = -200;
        int[] nArray = new int[400];
        int[][][] nArray2 = new int[400][400][400];
        long[][][] lArray = new long[400][400][400];
        float[][] fArray = new float[400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)3015630487L);
        FuzzerUtils.init(fArray, -2.562f);
        FuzzerUtils.init(nArray, -6);
        FuzzerUtils.init((Object[][])nArray2, (Object)-10);
        lArray[(n2 >>> 1) % 400][(n3 >>> 1) % 400][(n2 >>> 1) % 400] = n3;
        n4 = 384;
        while ((n4 -= 2) > 0) {
            lArray[n4 - 1][n4 - 1][n4 - 1] = n4;
            for (n5 = 8; n5 > n4; --n5) {
                for (n7 = 1; n7 < 1; ++n7) {
                    float[] fArray2 = fArray[n5 - 1];
                    int n11 = n7 + 1;
                    fArray2[n11] = fArray2[n11] - (float)instanceCount;
                    float[] fArray3 = fArray[n5];
                    int n12 = n5 + 1;
                    fArray3[n12] = fArray3[n12] - (float)dFld;
                    n3 += sFld;
                    instanceCount += (long)(38815 + n7 * n7);
                }
                for (n9 = 1; n9 < 1; ++n9) {
                    try {
                        n = -1299865018 % n7;
                        n8 = n4 % nArray[n4 - 1];
                        nArray2[n9 + 1][n5 - 1][n5] = n % -27922;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    sFld = (short)fFld;
                    n *= n9;
                    instanceCount += instanceCount;
                    nArray[n4 - 1] = -182;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10) + FuzzerUtils.checkSum((Object[][])lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])nArray2);
    }

    public static void vMeth(boolean bl, int n) {
        float f = -16.386f;
        float[] fArray = new float[400];
        int n2 = 13;
        int n3 = 209;
        int n4 = 14;
        int n5 = -18420;
        int n6 = 4894;
        int n7 = 14;
        long l = -2L;
        long[] lArray = new long[400];
        long[] lArray2 = new long[400];
        int n8 = -11;
        FuzzerUtils.init(lArray, -34068L);
        FuzzerUtils.init(fArray, -1.992f);
        FuzzerUtils.init(lArray2, 571902546L);
        n = (int)(-6.0f + ((float)n + fFld) - (float)n);
        n = n++ << n;
        fFld *= -55306.0f - (float)n * f - (float)lArray[(n >>> 1) % 400];
        for (n2 = 4; n2 < 213; ++n2) {
            block16: for (n4 = 8; n4 > 1; n4 -= 2) {
                n5 -= 8;
                switch (n4 % 2 + 127) {
                    case 127: {
                        Test.vMeth1(n, n3, -22300);
                        switch (n2 % 9 * 5 + 111) {
                            case 153: {
                                l = n2;
                                while (l < 3L) {
                                    n3 <<= (int)instanceCount;
                                    f = -106.35549f;
                                    instanceCount = l++;
                                    n6 = n;
                                    n3 = 14;
                                }
                            }
                            case 113: {
                                n7 = n5;
                                break;
                            }
                            case 128: {
                                if (bl) break;
                            }
                            case 156: {
                                int n9 = n4 - 1;
                                fArray[n9] = fArray[n9] * (float)n6;
                                break;
                            }
                            case 131: {
                                instanceCount = n4;
                                break;
                            }
                            case 136: {
                                n5 *= n7;
                                break;
                            }
                            case 150: {
                                instanceCount += (long)n4;
                            }
                            case 140: {
                                instanceCount -= -6249500597848774621L;
                                break;
                            }
                            case 139: {
                                n = n8;
                            }
                        }
                        continue block16;
                    }
                    case 128: {
                        n8 = (byte)n2;
                        continue block16;
                    }
                    default: {
                        int n10 = n2 - 1;
                        lArray2[n10] = lArray2[n10] ^ (long)n5;
                    }
                }
            }
        }
        vMeth_check_sum += (long)((bl ? 1 : 0) + n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5) + l + (long)n6 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray2);
    }

    public static void vSmallMeth(int n) {
        boolean bl = true;
        Test.vMeth(bl, n);
        instanceCount += (long)n;
        vSmallMeth_check_sum += (long)(n + (bl ? 1 : 0));
    }

    public void mainTest(String[] stringArray) {
        int n = -146;
        int n2 = -3;
        int n3 = 99;
        int n4 = -11;
        int n5 = 8;
        int n6 = -11739;
        int n7 = 11;
        int n8 = 44;
        int n9 = -3;
        int n10 = -3;
        int n11 = -7;
        int[][] nArray = new int[400][400];
        boolean bl = false;
        FuzzerUtils.init(nArray, -132);
        for (int i = 0; i < 382; ++i) {
            Test.vSmallMeth(-50856);
        }
        n <<= (int)instanceCount;
        for (n2 = 7; 193 > n2; n2 += 2) {
            n *= sFld;
        }
        int n12 = (n3 >>> 1) % 400;
        lArrFld[n12] = lArrFld[n12] + (long)n2;
        n >>= n;
        n3 <<= n2;
        n -= n;
        for (n4 = 18; 396 > n4; ++n4) {
            block3: for (n6 = 4; n6 < 67; ++n6) {
                nArray[n4 - 1] = nArray[n4 + 1];
                n &= n5;
                for (n8 = 1; n8 < 2; ++n8) {
                    n7 = 2;
                    n7 -= n8;
                    n7 += n5;
                    instanceCount += (long)(n8 * n9 + n9) - instanceCount;
                    instanceCount = n4;
                    n5 = this.iFld;
                    int[] nArray2 = nArray[n4];
                    int n13 = n6 + 1;
                    nArray2[n13] = nArray2[n13] - n;
                }
                for (n10 = n4; n10 < 2; n10 += 3) {
                    instanceCount = n3;
                    this.iFld = (int)((long)this.iFld + ((long)n10 - instanceCount));
                    fFld *= (float)n;
                    if (bl) {
                        if (bl) continue block3;
                        n3 += n7;
                        continue;
                    }
                    if (bl) {
                        int[] nArray3 = nArray[n4];
                        int n14 = n10 - 1;
                        nArray3[n14] = nArray3[n14] << this.iFld;
                        n5 = 13420;
                        continue;
                    }
                    instanceCount ^= (long)n9;
                }
            }
        }
        FuzzerUtils.out.println("i18 i19 i20 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 i22 i23 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i24 i25 i26 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i27 i28 b2 = " + n10 + "," + n11 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.sFld iFld Test.lArrFld = " + sFld + "," + this.iFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 13748L);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

