/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 137134303L;
    public static boolean bFld = true;
    public static short sFld = (short)-24267;
    public static byte byFld = (byte)3;
    public double dFld = 0.84604;
    public static volatile int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth() {
        double d = 5.56812;
        int n = 0;
        int n2 = 129;
        int n3 = 59;
        int n4 = 103;
        int n5 = 136;
        int n6 = -205;
        int n7 = 34094;
        float f = 66.436f;
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 175L);
        FuzzerUtils.init(fArray, 2.114f);
        for (d = 261.0; d > 6.0; d -= 1.0) {
            int n8 = (int)(d + 1.0);
            iArrFld[n8] = iArrFld[n8] - n;
        }
        for (n2 = 8; n2 < 281; ++n2) {
            try {
                Test.iArrFld[n2] = 40975 % n3;
                n3 %= n2;
                n3 %= iArrFld[n2];
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n4 = 1;
            do {
                instanceCount += (long)n2;
            } while (++n4 < 6);
            n5 = 1;
            while (++n5 < 6) {
            }
            n *= n6;
        }
        if (bFld) {
            fArray = FuzzerUtils.float1array(400, -7.732f);
        } else {
            n6 /= (int)(instanceCount | 1L);
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(int n, int n2) {
        int n3 = -1;
        int n4 = 5424;
        int n5 = 7203;
        int n6 = 42863;
        int n7 = -29387;
        int n8 = 11232;
        long l = -51064L;
        float f = 1.571f;
        n3 = 1;
        while (++n3 < 316) {
            for (l = 1L; l < 5L; ++l) {
                int n9 = n;
                n >>= Test.iMeth();
                n = n9 + n;
                n4 = sFld;
                n2 = (int)((long)n2 + (209L + l * l));
                for (n5 = (int)l; n5 < 2; ++n5) {
                    n2 = sFld;
                    instanceCount += (long)(n5 - n6);
                    n4 = (int)(f += -102.0f);
                    n2 += (int)(181L + (long)(n5 * n5));
                    n6 += n4;
                }
                for (n7 = 1; n7 < 2; ++n7) {
                    instanceCount = 0L;
                    n8 += n7;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3) + l + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)n7 + (long)n8;
    }

    public static void vMeth(int n, int n2, float f) {
        double d = 120.74754;
        int n3 = -19386;
        int n4 = 14;
        int n5 = 9;
        int n6 = 29659;
        int n7 = -10;
        int n8 = 20846;
        int n9 = -116;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -51.905f);
        Test.vMeth1(n, -209);
        for (d = 8.0; d < 152.0; d += 1.0) {
            instanceCount = n2;
        }
        int n10 = (n2 >>> 1) % 400;
        fArray[n10] = fArray[n10] + (float)n3;
        for (n4 = 5; n4 < 268; ++n4) {
            n5 <<= n2;
            Test.iArrFld[n4] = (int)f;
        }
        int[] nArray = iArrFld;
        int n11 = nArray.length;
        for (int i = 0; i < n11; ++i) {
            int n12;
            n = n12 = nArray[i];
        }
        for (n6 = 10; 253 > n6; ++n6) {
            byFld = (byte)(byFld + (byte)(n6 * n6));
            n7 <<= (int)instanceCount;
            for (n8 = 1; 7 > n8; ++n8) {
                instanceCount += (long)n9;
            }
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void mainTest(String[] stringArray) {
        int n = -14;
        int n2 = 8;
        int n3 = 54338;
        int n4 = 231;
        int n5 = 10981;
        int n6 = -223;
        int n7 = -50376;
        int n8 = 1;
        float f = 67.374f;
        long l = 334838838L;
        Test.vMeth(n, n, f);
        iArrFld[41] = iArrFld[41] * (int)this.dFld;
        n2 = 1;
        while (++n2 < 321) {
            n &= sFld;
            n6 -= (int)this.dFld;
            n4 += (int)l;
            n6 += 117 + n2 * n2;
            n8 = 1;
            while (++n8 < 78) {
                f /= -57173.0f;
                n += -90 + n8 * n8;
                instanceCount >>>= 28192;
                int n9 = n2 - 1;
                iArrFld[n9] = iArrFld[n9] + (int)l;
            }
        }
        FuzzerUtils.out.println("i25 f3 i26 = " + n + "," + Float.floatToIntBits(f) + "," + n2);
        FuzzerUtils.out.println("i27 i28 i29 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i30 l1 i31 = " + n6 + "," + l + "," + n7);
        FuzzerUtils.out.println("i32 = " + n8);
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.sFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + sFld);
        FuzzerUtils.out.println("Test.byFld dFld Test.iArrFld = " + byFld + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -58212);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

