/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1065939410768721658L;
    public static short sFld = (short)-17924;
    public static boolean bFld = true;
    public volatile int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(byte by, int n, int n2) {
        int n3 = 13;
        int n4 = -182;
        int n5 = -98;
        int n6 = 12;
        int n7 = -119;
        float f = 2.118f;
        double d = 2.7693;
        n2 = 389038952;
        for (n3 = 5; n3 < 163; ++n3) {
            n4 += (int)instanceCount;
            for (n5 = n3; n5 < 10; ++n5) {
                n6 += n5 * n5;
                d += -12.0;
            }
            try {
                n = -664335621 / n3;
                n2 = -12 % n6;
                n2 = n5 % 110;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            instanceCount += (long)n3 * instanceCount + (long)n - (long)sFld;
        }
        n7 = 1;
        do {
            n *= -24630;
            d += (double)(n4 <<= (int)(instanceCount -= (long)(n6 += n7 * n7)));
        } while ((n7 += 3) < 330);
        long l = (long)(by + n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6) + Double.doubleToLongBits(d) + (long)n7;
        iMeth_check_sum += l;
        return (int)l;
    }

    /*
     * Unable to fully structure code
     */
    public static void vMeth1(int var0, int var1_1, int var2_2) {
        var3_3 = 108;
        var4_4 = 48428;
        var5_5 = -248;
        var6_6 = 11;
        var7_7 = 149;
        var8_8 = 80;
        var9_9 = 7156431638399464735L;
        var11_10 = 2.37983;
        var13_11 = 92.659f;
        var14_12 = false;
        var0 ^= Test.iMeth(var3_3, var0, -59014);
        var4_4 = 1;
        while (++var4_4 < 381) {
            switch (var4_4 % 2 + 126) {
                case 126: {
                    if (!var14_12) ** GOTO lbl34
                    for (var5_5 = 1; var5_5 < 4; ++var5_5) {
                        var2_2 += var5_5 * var0;
                        if (var14_12) {
                            Test.instanceCount -= (long)var2_2;
                            for (var7_7 = 1; var7_7 < 2; ++var7_7) {
                                var15_13 = true;
                                var9_9 = Test.instanceCount;
                                var11_10 += -13.0;
                                var9_9 = (long)((float)var9_9 + ((float)var7_7 * var13_11 + (float)var9_9 - (float)var2_2));
                                var8_8 &= (int)Test.instanceCount;
                            }
                            continue;
                        }
                        if (var14_12) {
                            var13_11 *= (float)var0;
                            continue;
                        }
                        if (!var14_12) continue;
                    }
                    ** GOTO lbl38
lbl34:
                    // 1 sources

                    if (var14_12) {
                        var1_1 += var4_4 * var8_8;
                    } else {
                        var13_11 += (float)(var4_4 + var8_8);
                    }
                }
lbl38:
                // 4 sources

                case 127: {
                    var2_2 += 793010601;
                }
            }
        }
        Test.vMeth1_check_sum += (long)(var0 + var1_1 + var2_2 + var3_3 + var4_4 + var5_5 + var6_6 + var7_7 + var8_8) + var9_9 + Double.doubleToLongBits(var11_10) + (long)Float.floatToIntBits(var13_11) + (long)(var14_12 != false ? 1 : 0);
    }

    public static void vMeth(int n) {
        int n2 = 22;
        int n3 = 10;
        int n4 = -168;
        int n5 = 1808;
        int n6 = 8;
        int n7 = 55450;
        int n8 = -165;
        int[] nArray = new int[400];
        double d = -2.47648;
        float f = -1.305f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 902049967L);
        FuzzerUtils.init(nArray, -185);
        for (n2 = 10; n2 < 337; ++n2) {
            for (n4 = n2; n4 < 5; ++n4) {
                Test.vMeth1(n3, n, n5);
            }
            n5 = n4;
            d = f;
            lArray[n2 - 1] = 83L;
            n3 += sFld;
            f += (float)sFld;
        }
        n6 = 1;
        while ((n6 += 3) < 275) {
            n7 = 17;
            while (n7 > 1) {
                lArray[n6 + 1] = n2;
                int n9 = n7--;
                nArray[n9] = nArray[n9] - n8;
                n <<= n3;
            }
            instanceCount -= (long)n8;
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 5;
        int n2 = -56907;
        int n3 = 0;
        int n4 = -38985;
        int n5 = 221;
        int n6 = -4528;
        int[] nArray = new int[400];
        double d = -2.26414;
        float f = -77.26f;
        int n7 = -56;
        FuzzerUtils.init(nArray, -3);
        Test.vMeth(-3);
        n = 1;
        while (++n < 290) {
            for (n2 = n; n2 < 87; ++n2) {
                int n8 = -11930;
                n4 = 1;
                while (--n4 > 0) {
                    n3 += n4;
                }
                for (n5 = n2; n5 < 1; ++n5) {
                    f = instanceCount;
                    n6 += 143;
                    n3 >>>= -16235;
                    n6 += (int)(1.626f + (float)(n5 * n5));
                    n6 = 14809;
                }
                n6 = (int)((long)n6 + ((long)n2 * instanceCount + (long)sFld - (long)n));
                n8 += (int)instanceCount;
            }
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 d3 f3 = " + n4 + "," + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("by2 i27 i28 = " + n7 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + sFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 0.235f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

