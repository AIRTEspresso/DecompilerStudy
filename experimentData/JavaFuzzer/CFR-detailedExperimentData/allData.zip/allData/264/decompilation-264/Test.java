/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 25949L;
    public static double dFld = 1.60341;
    public static int iFld = 234;
    public static boolean bFld = false;
    public static int iFld1 = 3;
    public static float fFld = 0.339f;
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long fMeth_check_sum;

    public static float fMeth(long l) {
        int n = -10;
        int n2 = -3;
        int n3 = 10;
        int n4 = -131;
        int n5 = 56273;
        float f = 2.512f;
        for (n = 8; n < 225; ++n) {
            n2 += n;
            for (n3 = 7; n3 > n; --n3) {
                l = n3;
                n5 = 1;
                do {
                    n4 *= (int)l;
                    dFld = l;
                    n2 = (int)l;
                    l += (long)(n5 + n2);
                    f *= (float)n2;
                    lArrFld = FuzzerUtils.long1array(400, -6L);
                } while (++n5 < 1);
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f);
        fMeth_check_sum += l2;
        return l2;
    }

    public static void vMeth1(int n, long l) {
        long l2 = -5885814242179828052L;
        n = (int)(-((float)(-lArrFld[(n >>> 1) % 400]) - Test.fMeth(l2)));
        vMeth1_check_sum += (long)n + l + l2;
    }

    public static void vMeth(int n, int n2, int n3) {
        int n4 = -214;
        int n5 = 5;
        int n6 = 28963;
        int n7 = -9357;
        int n8 = 7;
        int n9 = 11;
        float f = -3.636f;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-12627);
        for (n4 = 277; n4 > 12; --n4) {
            for (n6 = 1; n6 < 6; ++n6) {
                sArray[n6 + 1] = (short)n3++;
                Test.vMeth1(208, instanceCount);
                n7 += (int)dFld;
                for (n8 = 1; n8 < 2; ++n8) {
                    n9 -= 6;
                    f += 12.0f;
                    instanceCount *= instanceCount;
                    n5 = n2;
                    iFld += -242;
                    if (bFld) continue;
                    n7 <<= n6;
                    n3 = 579060275;
                    if (!bFld) continue;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(sArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 10;
        int n2 = 47999;
        int n3 = -9;
        int n4 = 7;
        int n5 = -40872;
        int n6 = -76;
        int n7 = 1;
        int n8 = 7;
        int n9 = 7;
        int n10 = -48;
        long l = 59668411734707021L;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 64.49329);
        Test.vMeth(iFld, iFld, iFld1);
        for (n = 16; 263 > n; ++n) {
            for (n3 = n; n3 < 102; ++n3) {
                for (n5 = 1; 1 < n5; --n5) {
                    dFld = 30023.0;
                    n7 += n7;
                    switch ((iFld >>> 1) % 5 + 27) {
                        case 27: {
                            n6 *= 1;
                            break;
                        }
                        case 28: {
                            n10 = (byte)(n10 - (byte)instanceCount);
                            iFld1 *= (int)dFld;
                            iFld = n4;
                            break;
                        }
                        case 29: {
                            dFld -= (double)n4;
                            n2 = -23612;
                            int n11 = n3;
                            lArrFld[n11] = lArrFld[n11] - instanceCount;
                            n7 = n4;
                            break;
                        }
                        case 30: {
                            n7 = n4;
                            fFld *= (float)instanceCount;
                            break;
                        }
                    }
                    n4 *= (int)fFld;
                }
            }
            l = n;
            if (l >= 102L) continue;
            n2 += 100;
        }
        FuzzerUtils.out.println("i15 i16 i17 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i18 i19 i20 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i21 by l3 = " + n7 + "," + n10 + "," + l);
        FuzzerUtils.out.println("i22 i23 dArr = " + n8 + "," + n9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
        FuzzerUtils.out.println("Test.bFld Test.iFld1 Test.fFld = " + (bFld ? 1 : 0) + "," + iFld1 + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -8173476577053773151L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        fMeth_check_sum = 0L;
    }
}

