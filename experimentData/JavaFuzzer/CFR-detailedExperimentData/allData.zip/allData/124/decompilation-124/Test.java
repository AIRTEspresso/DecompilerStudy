/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 4278281980L;
    public static short sFld = (short)-24456;
    public static boolean bFld = false;
    public static float fFld = 2.386f;
    public volatile byte byFld = (byte)2;
    public static volatile float[] fArrFld = new float[400];
    public long[] lArrFld = new long[400];
    public byte[] byArrFld = new byte[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(int n, boolean bl, int n2) {
        double d = 3.84741;
        double[] dArray = new double[400];
        int n3 = 49439;
        int n4 = -241;
        int n5 = 1;
        int n6 = 102;
        int n7 = -105;
        int[][] nArray = new int[400][400];
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 14L);
        FuzzerUtils.init(dArray, -68.84704);
        FuzzerUtils.init(nArray, 4332);
        d *= (double)instanceCount;
        for (n3 = 6; n3 < 138; ++n3) {
            int n8 = n3 + 1;
            lArray[n8] = lArray[n8] + (long)n4;
            instanceCount -= (long)n2;
            n2 = (int)d;
            instanceCount = (long)fFld;
        }
        for (n5 = 4; n5 < 373; ++n5) {
            n = -91;
            n4 += n3;
        }
        int n9 = (n6 >>> 1) % 400;
        dArray[n9] = dArray[n9] - (double)n4;
        nArray[(n5 >>> 1) % 400][(n3 >>> 1) % 400] = n6;
        instanceCount -= (long)n4;
        long l = (long)((n *= n7) + (bl ? 1 : 0) + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)(n4 += 306195405) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth1() {
        double d = -1.23577;
        double d2 = -2.76994;
        int n = -14;
        int n2 = 115;
        int n3 = -21357;
        int n4 = 168;
        int n5 = 168;
        int n6 = -4;
        int n7 = -8673;
        int n8 = -1;
        int[] nArray = new int[400];
        int n9 = 83;
        float f = 2.133f;
        FuzzerUtils.init(nArray, 11);
        for (d = 290.0; d > 9.0; d -= 1.0) {
            sFld = (short)(sFld * (short)((float)n - ((float)n + -1.194f + (float)n)));
            instanceCount += (long)(n + ((n & n) - Integer.reverseBytes(n)));
            instanceCount &= (long)n--;
        }
        int n10 = (n >>> 1) % 400;
        nArray[2] = nArray[2] + 1;
        nArray[n10] = nArray[n10] - (int)((long)(n * n9 - (n - n)) - instanceCount * (long)nArray[2]);
        for (n2 = 4; n2 < 334; ++n2) {
            float f2 = f;
            f = f2 - 1.0f;
            bFld = (float)((long)(n3 - n2) - instanceCount) < Math.abs(f2);
            block8: for (n4 = 1; n4 < 5; ++n4) {
                n5 = (int)(f * (float)((long)n3 % (instanceCount | 1L) - (long)(n4 + n3)));
                switch (n4 % 2 * 5 + 86) {
                    case 91: {
                        for (n6 = 1; n6 < 2; ++n6) {
                            nArray[n2] = -671314614;
                            sFld = (short)(sFld - 1);
                            instanceCount &= (long)(-671314614 << (int)instanceCount >> (int)((double)sFld - -(d2 += 1.0)));
                            int n11 = n6 - 1;
                            nArray[n11] = nArray[n11] * n--;
                            ++n3;
                            n3 = (int)(((long)n3 - (-3335545688L - (long)(sFld + n5))) / (long)(Math.max(n7, n - -153) | 1));
                            n8 += n6 * n7;
                        }
                        continue block8;
                    }
                    case 92: {
                        try {
                            n7 = 2834 / n7;
                            n3 = nArray[n4 - 1] / -163;
                            nArray[n4 - 1] = 53557 % nArray[n2 + 1];
                        }
                        catch (ArithmeticException arithmeticException) {}
                        continue block8;
                    }
                    default: {
                        n = (int)((long)Math.max(-70, n2) + Test.lMeth(3, bFld, n7));
                        n8 += n;
                    }
                }
            }
        }
        vMeth1_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n9 + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(d2) + (long)n8 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(byte by) {
        int n = 13;
        int n2 = -10;
        int n3 = 14628;
        int n4 = -245;
        int n5 = -2;
        int n6 = -161;
        int[] nArray = new int[400];
        float f = 106.101f;
        double d = -79.96836;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 9);
        FuzzerUtils.init(lArray, -54925L);
        for (n = 21; n < 392; ++n) {
            for (n3 = 1; n3 < 5; ++n3) {
                n4 = n2--;
                instanceCount += (long)n3;
                n5 = 1;
                do {
                    try {
                        n2 = n4 % 14923;
                        nArray[n + 1] = -1213247365 / n;
                        n2 = n / n5;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                } while (++n5 < 2);
                if (n3 != 0) {
                    vMeth_check_sum += (long)(by + n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
                    return;
                }
                int n7 = n3;
                lArray[n7] = lArray[n7] * 38L;
                int n8 = n3 - 1;
                int n9 = nArray[n8] - 1;
                nArray[n8] = n9;
                nArray[n] = Math.min(Math.min(n2 * -41532, (int)(f * (float)instanceCount)), n9);
                Test.vMeth1();
                n4 >>= n5;
                int n10 = n + 1;
                nArray[n10] = nArray[n10] * (int)instanceCount;
                d = 1.0;
                do {
                    n4 += (int)d;
                    n6 = 4;
                } while ((d += 1.0) < 2.0);
            }
        }
        vMeth_check_sum += (long)(by + n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 10;
        int n2 = 44231;
        int n3 = 20;
        int n4 = 54258;
        int n5 = 10;
        int n6 = 51192;
        int n7 = -5393;
        int[][] nArray = new int[400][400];
        long l = -6984477168613311786L;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -2.49867);
        FuzzerUtils.init(nArray, -67);
        n += 62056;
        Test.vMeth(this.byFld);
        n2 = 1;
        while (++n2 < 331) {
            n = sFld;
            n = -99;
        }
        for (double d : dArray) {
            int n8 = (n2 >>> 1) % 400;
            fArrFld[n8] = fArrFld[n8] + (float)sFld;
            for (n3 = 3; n3 < 63; ++n3) {
                n4 = n2;
                if (bFld) continue;
                for (l = 1L; l < 2L; ++l) {
                    nArray[(int)(l - 1L)][(int)(l + 1L)] = (int)l;
                    sFld = (short)(sFld + (short)instanceCount);
                    if (bFld) {
                        this.lArrFld = this.lArrFld;
                        if (!bFld) continue;
                        break;
                    }
                    instanceCount -= instanceCount;
                    instanceCount >>>= n2;
                }
                fFld += (float)(n3 + n5);
                n4 += this.byFld;
                for (n6 = 1; 2 > n6; ++n6) {
                    nArray[n6 - 1][n6 + 1] = n4;
                    instanceCount += (long)(n6 * n6);
                    fFld %= (float)(l | 1L);
                    sFld = (short)n6;
                    instanceCount += -4256195689L + (long)(n6 * n6);
                    instanceCount += (long)sFld;
                    int n9 = n3 - 1;
                    this.byArrFld[n9] = (byte)(this.byArrFld[n9] & (byte)n3);
                    n7 = n4;
                }
                n7 -= n6;
            }
        }
        FuzzerUtils.out.println("i i22 i23 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i24 l i25 = " + n4 + "," + l + "," + n5);
        FuzzerUtils.out.println("i26 i27 dArr1 = " + n6 + "," + n7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + sFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld byFld Test.fArrFld = " + Float.floatToIntBits(fFld) + "," + this.byFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lArrFld byArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 0.988f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

