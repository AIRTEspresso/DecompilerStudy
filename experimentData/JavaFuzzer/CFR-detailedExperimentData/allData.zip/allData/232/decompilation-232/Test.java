/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 60531L;
    public double dFld = -104.96747;
    public boolean bFld = true;
    public static volatile byte byFld = (byte)67;
    public int[][] iArrFld = new int[400][400];
    public static int[] iArrFld1 = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = -2200;
        int n2 = -68;
        int n3 = 272;
        int n4 = 89;
        int n5 = 196;
        double d = -2.27109;
        float f = -2.561f;
        long l = 7047316164572904437L;
        boolean bl = true;
        int n6 = -2126;
        n = 1;
        block7: do {
            switch ((n >>> 1) % 6 + 103) {
                case 103: {
                    if (n != 0) {
                        vMeth1_check_sum += (long)n + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + l + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)n6;
                        return;
                    }
                    d = f;
                    n2 += n2;
                    break;
                }
                case 104: {
                    n3 = 1;
                    block8: while (++n3 < 5) {
                        for (l = 1L; l < 1L; ++l) {
                            n2 = (int)instanceCount;
                            n4 += (int)(l * (long)n2 + l - instanceCount);
                            instanceCount >>= n3;
                        }
                        n5 = 1;
                        do {
                            n4 >>= n4;
                            n4 -= 206;
                            if (bl) continue block8;
                            n4 = (int)((float)n4 + ((float)(n5 * n3 + n6) - f));
                        } while (++n5 < 1);
                    }
                    continue block7;
                }
                case 105: {
                    n4 = n3;
                }
                case 106: 
                case 107: {
                    f += (float)((long)(n * n) + instanceCount - (long)n2);
                    break;
                }
                case 108: {
                    n6 = (short)(n6 + (short)(n * n));
                    break;
                }
                default: {
                    n4 = n6;
                }
            }
        } while (++n < 301);
        vMeth1_check_sum += (long)n + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + l + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)n6;
    }

    public static void vMeth(int n) {
        long l = -374L;
        double d = -49.123755;
        double d2 = -37.22115;
        int n2 = 0;
        int n3 = 217;
        int n4 = -8;
        float f = -15.14f;
        float[][][] fArray = new float[400][400][400];
        byte[] byArray = new byte[400];
        short[] sArray = new short[400];
        FuzzerUtils.init(byArray, (byte)-116);
        FuzzerUtils.init(sArray, (short)-5612);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(-2.684f));
        instanceCount += Math.max(instanceCount, instanceCount) - (long)byArray[(n >>> 1) % 400];
        n = n++ - (int)((long)n * (instanceCount - (long)n) + Math.abs(4269128188L * (long)n));
        Test.vMeth1();
        n *= n;
        n = (int)instanceCount;
        l = 1L;
        do {
            int n5 = (int)(l + 1L);
            sArray[n5] = (short)(sArray[n5] - (short)d);
            int n6 = (int)l;
            iArrFld1[n6] = iArrFld1[n6] << n;
            for (d2 = 6.0; d2 > 1.0; d2 -= 1.0) {
                float[] fArray2 = fArray[(int)(l + 1L)][(int)(d2 - 1.0)];
                int n7 = (int)(l + 1L);
                fArray2[n7] = fArray2[n7] * 22826.0f;
                n2 += (int)(d2 * d2);
                for (n3 = 1; n3 < 2; ++n3) {
                    instanceCount %= (long)(n4 | 1);
                    instanceCount -= (long)f;
                }
            }
        } while (++l < 283L);
        vMeth_check_sum += (long)n + l + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(byArray) + FuzzerUtils.checkSum(sArray) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray));
    }

    public static int iMeth(int n, int n2, int n3) {
        int n4 = -62669;
        int n5 = -77;
        int n6 = -183;
        int n7 = -4;
        int n8 = -58;
        int n9 = 13;
        double d = 0.95156;
        float f = 34.384f;
        int n10 = -29931;
        long[] lArray = new long[400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(lArray, -57635L);
        FuzzerUtils.init(byArray, (byte)-29);
        n4 = 1;
        while (++n4 < 226) {
            int n11 = n4;
            int n12 = iArrFld1[n11];
            iArrFld1[n11] = n12 + 1;
            instanceCount = -n12;
            int n13 = n4 - 1;
            long l = lArray[n13];
            lArray[n13] = l - 1L;
            n3 *= (int)l;
            instanceCount = (long)(-14.0 + d);
            Test.vMeth(n4);
        }
        n2 *= n3;
        for (n5 = 20; 354 > n5; ++n5) {
            n7 = 1;
            do {
                for (n8 = n7; n8 < 1; ++n8) {
                    n2 -= n4;
                    f += (float)n8 + f;
                }
                f += (float)n4;
                int n14 = n5 - 1;
                lArray[n14] = lArray[n14] - (long)n10;
                instanceCount += instanceCount;
            } while (++n7 < 5);
        }
        long l = (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)Float.floatToIntBits(f) + (long)n10 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(byArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        float f = -12.851f;
        float[] fArray = new float[400];
        int n = -22373;
        int n2 = 241;
        int n3 = -6;
        int n4 = -6721;
        int n5 = 0;
        short[] sArray = new short[400];
        byte[] byArray = new byte[400];
        boolean[] blArray = new boolean[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(sArray, (short)-13660);
        FuzzerUtils.init(byArray, (byte)102);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(lArray, 13L);
        FuzzerUtils.init(fArray, 7.917f);
        int[] nArray = this.iArrFld[(n >>> 1) % 400];
        int n6 = (n >>> 1) % 400;
        int n7 = nArray[n6] - 1;
        nArray[n6] = n7;
        f += (float)(this.dFld -= (double)n7);
        n /= Test.iMeth(n, n, n) + n | 1;
        for (int n8 : iArrFld1) {
            if (this.bFld) break;
            block22: for (n2 = 1; n2 < 63; ++n2) {
                int[] nArray2 = this.iArrFld[n2 + 1];
                int n9 = n2 - 1;
                nArray2[n9] = nArray2[n9] + n;
                byFld = (byte)(byFld >> (byte)(n += n2));
                switch (n2 % 9 * 5 + 113) {
                    case 144: {
                        int n10 = n2 + 1;
                        sArray[n10] = (short)(sArray[n10] * (short)n2);
                        block23: for (n4 = 1; 2 > n4; ++n4) {
                            n3 += (int)instanceCount;
                            if (this.bFld) continue;
                            switch (83) {
                                case 77: {
                                    int n11 = n4;
                                    byArray[n11] = (byte)(byArray[n11] >> (byte)instanceCount);
                                    blArray[n4 + 1] = this.bFld;
                                    n3 *= (int)this.dFld;
                                    lArray[n4 + 1] = instanceCount;
                                }
                                case 90: {
                                    n5 = (int)((long)n5 + ((long)(n4 * n2 + n3) - (instanceCount -= (long)n4)));
                                    continue block23;
                                }
                                case 51: {
                                    n3 += n4;
                                    f += 10.0f;
                                    n8 += n4 * n4;
                                    continue block23;
                                }
                                case 64: {
                                    int n12 = n4 + 1;
                                    iArrFld1[n12] = iArrFld1[n12] | (int)instanceCount;
                                    n8 = n4;
                                    continue block23;
                                }
                                case 83: {
                                    continue block23;
                                }
                                case 73: {
                                    n5 -= 213;
                                    continue block23;
                                }
                                case 58: {
                                    fArray[n2] = (float)this.dFld;
                                    continue block23;
                                }
                                case 68: {
                                    n = n2;
                                    continue block23;
                                }
                                case 67: {
                                    n8 *= n3;
                                    continue block23;
                                }
                                default: {
                                    n3 += n5;
                                }
                            }
                        }
                        continue block22;
                    }
                    case 151: 
                    case 153: {
                        n3 -= n4;
                    }
                    case 133: {
                        n5 -= (int)instanceCount;
                        continue block22;
                    }
                    case 158: {
                        instanceCount += (long)(39 + n2 * n2);
                        continue block22;
                    }
                    case 129: {
                        n8 -= 8;
                        continue block22;
                    }
                    case 137: {
                        int[] nArray3 = this.iArrFld[n2];
                        int n13 = n2 + 1;
                        nArray3[n13] = nArray3[n13] + n8;
                        continue block22;
                    }
                    case 155: {
                        n8 = n4;
                        continue block22;
                    }
                    case 143: {
                        n8 *= n4;
                        continue block22;
                    }
                    default: {
                        n = (int)this.dFld;
                    }
                }
            }
        }
        FuzzerUtils.out.println("f i i20 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i21 i22 i23 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("sArr1 byArr2 bArr = " + FuzzerUtils.checkSum(sArray) + "," + FuzzerUtils.checkSum(byArray) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("lArr1 fArr1 = " + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount dFld bFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld iArrFld Test.iArrFld1 = " + byFld + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld1, -14);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

