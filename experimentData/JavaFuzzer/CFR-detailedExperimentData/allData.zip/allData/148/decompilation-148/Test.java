/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -7L;
    public double dFld = -59.36948;
    public static volatile int iFld = 70;
    public static int iFld1 = 1328;
    public static byte byFld = (byte)-5;
    public static float fFld = 1.37f;
    public static int iFld2 = -37124;
    public short sFld = (short)-21197;
    public static double[] dArrFld = new double[400];
    public static byte[] byArrFld = new byte[400];
    public static short[] sArrFld = new short[400];
    public static long[][] lArrFld = new long[400][400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1() {
        float f = 114.875f;
        int n = -4;
        int n2 = 7813;
        int n3 = 41;
        int n4 = -11;
        int n5 = 10;
        int n6 = 42848;
        double d = 0.81882;
        iFld += iFld;
        f = iFld;
        for (n = 15; 293 > n; ++n) {
            int n7 = n + 1;
            dArrFld[n7] = dArrFld[n7] + (double)n;
            for (n3 = n; n3 < 6; ++n3) {
                int n8 = -26440;
                Test.byArrFld[n3] = (byte)iFld;
                for (n5 = 1; n5 < 1; ++n5) {
                    int n9 = n5 + 1;
                    dArrFld[n9] = dArrFld[n9] + (double)f;
                    instanceCount ^= 0xFFFFFFFFFFFFFF4FL;
                    instanceCount += (long)n3;
                }
                n8 = (short)d;
                n2 = 13;
                d -= (double)n4;
                n6 = -1;
                iFld = (int)instanceCount;
            }
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, long l) {
        int n2 = 23979;
        int n3 = 0;
        int n4 = 1174;
        int n5 = 135;
        int[] nArray = new int[400];
        float f = -30.798f;
        boolean bl = true;
        FuzzerUtils.init(nArray, -16508);
        if (bl) {
            int n6 = (n >>> 1) % 400;
            n >>= n;
            nArray[n6] = nArray[n6] + (n + Test.iMeth1() + -18514);
            n <<= iFld;
            instanceCount *= (long)iFld;
        } else if (bl) {
            if (bl) {
                n2 = 1;
                do {
                    for (n3 = 1; n3 < 5; ++n3) {
                        instanceCount += -8L;
                        n4 >>= -1574304524;
                        n -= (int)l;
                        n5 = 1;
                        while (++n5 < 2) {
                            instanceCount -= (long)n5;
                            f = -4.0f;
                        }
                    }
                } while (++n2 < 331);
            } else if (!bl) {
                f *= (float)l;
            }
        } else {
            int n7 = (n5 >>> 1) % 400;
            nArray[n7] = nArray[n7] + n5;
        }
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth() {
        double d = -101.18504;
        boolean bl = false;
        int n = 651;
        int n2 = -14;
        int[] nArray = new int[400];
        long l = -4L;
        FuzzerUtils.init(nArray, -35082);
        Test.vMeth(9323, 205L);
        if (bl) {
            int n3 = (iFld1 >>> 1) % 400;
            nArray[n3] = nArray[n3] * iFld;
            int n4 = (iFld >>> 1) % 400;
            sArrFld[n4] = (short)(sArrFld[n4] + -25134);
            d = instanceCount;
            byFld = (byte)(byFld - (byte)iFld1);
        } else {
            try {
                nArray = FuzzerUtils.int1array(400, -46273);
                nArray[342] = 2625;
                iFld1 = -16070;
                for (n = 323; 12 < n; n -= 3) {
                    if (iFld1 == 0) continue;
                }
            }
            catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                iFld1 = iFld;
            }
            catch (NullPointerException nullPointerException) {
                l >>>= iFld;
            }
        }
        long l2 = Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + (long)n + (long)n2 + l + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 136;
        int n2 = 4;
        int n3 = 51409;
        int n4 = 0;
        int n5 = -50894;
        int n6 = 23808;
        int n7 = 4;
        int n8 = 12709;
        int n9 = 14;
        int[] nArray = new int[400];
        float f = 0.885f;
        FuzzerUtils.init(nArray, -35);
        this.dFld -= (double)Test.iMeth() - this.dFld;
        block35: for (n = 325; n > 17; --n) {
            iFld1 &= 0xE4;
            instanceCount += (long)this.dFld;
            int n10 = n + 1;
            nArray[n10] = nArray[n10] + 2;
            switch (75) {
                case 79: {
                    for (f = 2.0f; f < 82.0f; f += 1.0f) {
                        n2 += (int)this.dFld;
                        iFld -= n3;
                    }
                    n3 += n3;
                    this.dFld *= (double)iFld2;
                    continue block35;
                }
                case 102: {
                    block37: for (n4 = 2; n4 < 82; ++n4) {
                        int n11 = n - 1;
                        nArray[n11] = nArray[n11] >> (int)instanceCount;
                        iFld += n4 - n5;
                        long[] lArray = lArrFld[n4];
                        int n12 = n - 1;
                        lArray[n12] = lArray[n12] << byFld;
                        this.dFld += 5.9053043563246377E18;
                        fFld -= (float)this.sFld;
                        switch (n4 % 6 + 41) {
                            case 41: {
                                switch (n % 8 + 107) {
                                    case 107: {
                                        block38: for (n6 = 1; n6 < 2; ++n6) {
                                            n5 = n2;
                                            byFld = (byte)n8;
                                            iFld = this.sFld;
                                            try {
                                                iFld1 = -10253 % n6;
                                                nArray[n4] = 50624 / iFld2;
                                                iFld2 = n % 38026;
                                            }
                                            catch (ArithmeticException arithmeticException) {
                                                // empty catch block
                                            }
                                            switch ((iFld1 >>> 1) % 1 * 5 + 58) {
                                                case 62: {
                                                    instanceCount *= (long)n6;
                                                    Test.lArrFld[n4][n] = iFld;
                                                    continue block38;
                                                }
                                                default: {
                                                    n8 += n6;
                                                }
                                            }
                                        }
                                        break;
                                    }
                                    case 108: {
                                        instanceCount += (long)n4 ^ instanceCount;
                                        break;
                                    }
                                    case 109: {
                                        instanceCount >>>= 10198;
                                        break;
                                    }
                                    case 110: {
                                        int n13 = n - 1;
                                        nArray[n13] = nArray[n13] % (int)(instanceCount | 1L);
                                    }
                                    case 111: {
                                        Test.lArrFld[n - 1] = lArrFld[n - 1];
                                        break;
                                    }
                                    case 112: {
                                        Test.lArrFld[n4 - 1][n4] = -14L;
                                    }
                                    case 113: {
                                        n7 -= 1401629452;
                                        break;
                                    }
                                    case 114: {
                                        n2 += 43477 + n4 * n4;
                                        break;
                                    }
                                    default: {
                                        iFld2 += n4 * n4;
                                    }
                                }
                            }
                            case 42: {
                                instanceCount ^= (long)iFld2;
                                continue block37;
                            }
                            case 43: {
                                int n14 = n;
                                nArray[n14] = nArray[n14] + n7;
                            }
                            case 44: {
                                int n15 = n4;
                                nArray[n15] = nArray[n15] + -2244;
                                continue block37;
                            }
                            case 45: {
                                iFld2 >>= (int)instanceCount;
                                continue block37;
                            }
                            case 46: {
                                n5 += n4 * n5 + n3 - iFld;
                            }
                        }
                    }
                    continue block35;
                }
                case 75: {
                    fFld = f;
                    continue block35;
                }
                case 98: {
                    instanceCount += (long)n;
                    continue block35;
                }
                case 80: {
                    n3 = (int)this.dFld;
                    continue block35;
                }
                case 113: {
                    byFld = (byte)(byFld + (byte)instanceCount);
                    continue block35;
                }
                case 96: {
                    int n16 = n + 1;
                    nArray[n16] = nArray[n16] >> n9;
                    continue block35;
                }
                case 84: {
                    this.dFld = -1.5438132247448407E18;
                    continue block35;
                }
                case 89: {
                    n5 <<= n;
                    continue block35;
                }
                case 94: {
                    iFld1 += n | n2;
                }
            }
        }
        FuzzerUtils.out.println("i13 i14 f2 = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i15 i16 i17 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i18 i19 i20 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i21 iArr2 = " + n9 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + iFld);
        FuzzerUtils.out.println("Test.iFld1 Test.byFld Test.fFld = " + iFld1 + "," + byFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iFld2 sFld Test.dArrFld = " + iFld2 + "," + this.sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.byArrFld Test.sArrFld Test.lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 15.99761);
        FuzzerUtils.init(byArrFld, (byte)-94);
        FuzzerUtils.init(sArrFld, (short)2505);
        FuzzerUtils.init(lArrFld, -8L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

