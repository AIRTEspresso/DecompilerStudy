/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 46856L;
    public boolean bFld = false;
    public static int iFld = 126;
    public float fFld = 0.737f;
    public static boolean[] bArrFld = new boolean[400];
    public static long[] lArrFld = new long[400];
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(float f, int n) {
        int n2 = -128;
        int n3 = 157;
        int n4 = 4;
        int n5 = 10926;
        int n6 = -3;
        int[] nArray = new int[400];
        int n7 = -111;
        boolean bl = true;
        long l = -9132390761175264722L;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -10);
        FuzzerUtils.init(lArray, 30797L);
        for (n2 = 13; n2 < 211; ++n2) {
            try {
                n = -49647 % n2;
                n3 = n2 % -110;
                n = -116 % n2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            block3: for (n4 = 1; n4 < 8; ++n4) {
                n6 = 1;
                do {
                    int n8 = n6;
                    nArray[n8] = nArray[n8] * n7;
                    instanceCount *= (long)f;
                    lArray[n2] = n6;
                    nArray[n4 - 1] = n5 >>>= n7;
                    if (bl) continue block3;
                    n &= 0xFFFFFF6C;
                    n5 -= n6;
                    instanceCount += (long)n6 | l;
                    n5 >>>= 100275026;
                } while (++n6 < 2);
            }
        }
        long l2 = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0)) + l + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth(int n, short s) {
        float f = 1.823f;
        long l = 4L;
        int n2 = 7;
        int n3 = 62;
        int n4 = 25090;
        int n5 = 34;
        int n6 = -13;
        int[] nArray = new int[400];
        boolean bl = true;
        int n7 = -51;
        FuzzerUtils.init(nArray, -3);
        n += Integer.reverseBytes((int)((long)n * instanceCount - instanceCount));
        s = (short)Test.iMeth(f, n);
        n = 8;
        for (l = 7L; l < 253L && !bl; ++l) {
            n2 >>= n2;
            s = (short)(s + (short)(l * l));
            n >>= (int)l;
            for (n3 = (int)l; 7 > n3; ++n3) {
                int n8 = (int)l;
                nArray[n8] = nArray[n8] * n7;
                if (bl) continue;
                f += (float)n3;
                for (n5 = 1; n5 > 1 && !bl; --n5) {
                    n4 ^= 0x25CA;
                }
            }
        }
        vMeth_check_sum += (long)(n + s + Float.floatToIntBits(f)) + l + (long)n2 + (long)(bl ? 1 : 0) + (long)n3 + (long)n4 + (long)n7 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public boolean bMeth(float f, int n, int n2) {
        short s = 21130;
        int n3 = -4;
        int n4 = -138;
        int n5 = -217;
        int n6 = 46094;
        int n7 = 10;
        int[] nArray = new int[400];
        int n8 = 6;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -119);
        FuzzerUtils.init(lArray, 369598138L);
        Test.vMeth(33, s);
        nArray[(n3 >>> 1) % 400] = 208;
        n3 += (int)instanceCount;
        for (n4 = 130; n4 > 6; n4 -= 3) {
            int n9 = n4;
            lArray[n9] = lArray[n9] - (long)s;
            for (n6 = n4; n6 < 37; ++n6) {
                n = -2;
                int n10 = n4;
                nArray[n10] = nArray[n10] + iFld;
                lArray[n4 - 1] = n4;
                n = (int)((long)n + ((long)n6 * instanceCount + (long)n2 - (long)n));
                n += n6 ^ (n7 <<= n4);
            }
            lArray[n4] = n8;
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + s + n3 + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = 4696;
        int n2 = -208;
        int n3 = -11;
        int n4 = -10;
        int n5 = 2;
        int n6 = -221;
        int n7 = 18005;
        int n8 = -11;
        int[] nArray = new int[400];
        float f = -119.337f;
        double d = -2.93573;
        double[] dArray = new double[400];
        int n9 = -369;
        FuzzerUtils.init(dArray, -121.49904);
        FuzzerUtils.init(nArray, 4);
        this.bFld = this.bMeth(this.fFld, iFld, iFld);
        this.fFld %= (float)(iFld | 1);
        block13: for (n = 13; n < 220; ++n) {
            n2 -= 4564;
            if (!this.bFld) continue;
            switch (n % 8 + 80) {
                case 80: {
                    for (f = (float)n; f < 121.0f; f += 1.0f) {
                        n3 += (int)f;
                        n3 -= (n2 &= 0x3B59);
                        this.bFld = this.bFld;
                    }
                    dArray[n + 1] = iFld;
                    n3 += (int)instanceCount;
                    int n10 = n + 1;
                    nArray[n10] = nArray[n10] >> n2;
                    continue block13;
                }
                case 81: {
                    for (d = 6.0; d < 121.0; d += 1.0) {
                        iFld -= 248;
                    }
                    nArray[n] = iFld;
                    block16: for (n5 = n; n5 < 121; ++n5) {
                        this.fFld = instanceCount;
                        n7 = 1;
                        while (n7 < 1) {
                            switch (n7 % 1 + 65) {
                                case 65: {
                                    instanceCount = (long)this.fFld;
                                    int n11 = n7;
                                    nArray[n11] = nArray[n11] - (int)instanceCount;
                                }
                            }
                            if (this.bFld) continue block16;
                            n2 -= (int)(instanceCount *= -1L);
                            n2 = n8;
                            n4 = (int)((float)n4 + ((float)n7 * f + (float)n5 - (float)n9));
                            n8 = -59481;
                            int n12 = n7++;
                            nArray[n12] = nArray[n12] + n5;
                        }
                    }
                    continue block13;
                }
                case 82: {
                    int n13 = n + 1;
                    lArrFld[n13] = lArrFld[n13] + (long)f;
                    continue block13;
                }
                case 83: {
                    this.fFld += (float)n;
                    continue block13;
                }
                case 84: {
                    n2 = iFld;
                }
                case 85: {
                    int n14 = n + 1;
                    nArray[n14] = nArray[n14] + 6763;
                    continue block13;
                }
                case 86: {
                    nArray[n - 1] = (int)this.fFld;
                    continue block13;
                }
                case 87: {
                    this.fFld = instanceCount;
                }
            }
        }
        FuzzerUtils.out.println("i19 i20 f3 = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i21 d i22 = " + n3 + "," + Double.doubleToLongBits(d) + "," + n4);
        FuzzerUtils.out.println("i23 i24 i25 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i26 s2 dArr = " + n8 + "," + n9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount bFld Test.iFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + iFld);
        FuzzerUtils.out.println("fFld Test.bArrFld Test.lArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(bArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(bArrFld, false);
        FuzzerUtils.init(lArrFld, 6620249178618566476L);
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

