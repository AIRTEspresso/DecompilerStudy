/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 199L;
    public static boolean bFld = true;
    public volatile double dFld = 1.45337;
    public static long iMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long bMeth_check_sum = 0L;

    public static boolean bMeth(int n, int n2) {
        long l = 0L;
        int n3 = -13;
        int n4 = 5;
        int n5 = -35481;
        int n6 = 53675;
        int n7 = -8;
        int n8 = 26720;
        int[] nArray = new int[400];
        double d = -2.119147;
        FuzzerUtils.init(nArray, 39814);
        for (l = 5L; l < 224L; l += 2L) {
            for (n4 = 1; 14 > n4; ++n4) {
                d -= (double)n5;
                d *= (double)n4;
                if (n5 != 0) {
                    return (int)((long)(n + n2) + l + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(nArray)) % 2 > 0;
                }
                nArray[n4 + 1] = -788283488;
                n5 <<= n5;
                n -= 152;
                n5 *= n3;
            }
            for (n6 = 1; n6 < 14; ++n6) {
                n3 <<= n5;
                n3 -= n8;
                n5 += n6 * n6;
                n8 = n2;
            }
        }
        long l2 = (long)(n + n2) + l + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(nArray);
        bMeth_check_sum += l2;
        return l2 % 2L > 0L;
    }

    public static void vMeth(int n, long l, int n2) {
        int n3 = 28238;
        int n4 = 127;
        int n5 = 44526;
        int n6 = 11;
        int n7 = 40730;
        int[] nArray = new int[400];
        double d = -9.95535;
        int n8 = 97;
        int n9 = -28405;
        FuzzerUtils.init(nArray, -11668);
        bFld = Test.bMeth(n, n);
        n2 = n;
        for (n3 = 3; 149 > n3; ++n3) {
            int n10 = n3 - 1;
            nArray[n10] = nArray[n10] * n4;
            for (d = (double)n3; d < 11.0; d += 1.0) {
                n4 += (int)d;
                for (n6 = 1; n6 < 1; ++n6) {
                    n4 -= 26;
                    n |= n8;
                    n5 += n6 - n7;
                    int n11 = n6 + 1;
                    nArray[n11] = nArray[n11] * n9;
                    n9 = (short)(l *= (long)n6);
                }
            }
        }
        n9 = (short)(n9 & 0x10D);
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(long l, short s) {
        int n = 61572;
        int n2 = -8;
        int n3 = 61250;
        int n4 = -126;
        int n5 = 92;
        int[] nArray = new int[400];
        double d = 0.74282;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(nArray, -126);
        FuzzerUtils.init((Object[][])lArray, (Object)-100L);
        l <<= 9;
        Test.vMeth(n, instanceCount, n);
        n -= n;
        d = n;
        for (n2 = 13; 338 > n2; ++n2) {
            n3 = n;
            for (n4 = n2; n4 < 5; ++n4) {
                try {
                    n3 = n4 / n5;
                    n = n5 / n2;
                    n = nArray[n4] / -17;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n = (int)instanceCount;
                n = 207;
                long[] lArray2 = lArray[n2][n4 + 1];
                int n6 = n2;
                lArray2[n6] = lArray2[n6] - (long)s;
                n = 233;
            }
        }
        long l2 = l + (long)s + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])lArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 60018;
        int n2 = -12710;
        int n3 = 47048;
        int n4 = 61882;
        int n5 = -12;
        int n6 = -13792;
        int n7 = 5;
        int n8 = -119;
        int[] nArray = new int[400];
        float f = -2.53f;
        float[] fArray = new float[400];
        int n9 = 7816;
        long l = 9630L;
        long[] lArray = new long[400];
        int n10 = -117;
        FuzzerUtils.init(fArray, 0.899f);
        FuzzerUtils.init(lArray, -969976997L);
        FuzzerUtils.init(nArray, 116);
        for (n = 11; n < 290; ++n) {
            instanceCount += (long)(n * n2 + n - n2);
        }
        for (n3 = 212; n3 > 8; n3 -= 3) {
            float f2;
            f += 1.0f;
            bFld = (float)(--n4) <= (-2.0f + f2) * (float)n;
            n5 = 1;
            while (++n5 < 368) {
                instanceCount *= (long)(Test.iMeth(instanceCount, (short)n9) * n2);
            }
            n6 = 1;
            while (++n6 < 368) {
                fArray[17] = fArray[17] - (float)n3;
                instanceCount = 174L;
                instanceCount = (long)((float)instanceCount + (float)n6 * f);
            }
            n2 |= n4;
        }
        for (l = 2L; l < 165L; ++l) {
            n8 = 1;
            do {
                n2 = n4 = (int)((float)n4 + ((float)n8 * f + (float)n3 - (float)n3));
                f = n4;
                n7 += 38591 + n8 * n8;
                n10 = (byte)(n10 >> (byte)(n2 |= (int)instanceCount));
                this.dFld = l;
                n2 >>= n2;
                n4 = 1;
            } while ((n8 += 2) < 154);
            int n11 = (int)l;
            lArray[n11] = lArray[n11] + -37944L;
            n4 += (int)(l ^ (long)n);
            n4 = n3;
            instanceCount >>>= n10;
            n7 = n9;
        }
        this.dFld *= (double)l;
        n4 += n4;
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 f i4 = " + n4 + "," + Float.floatToIntBits(f) + "," + n5);
        FuzzerUtils.out.println("s2 i25 l3 = " + n9 + "," + n6 + "," + l);
        FuzzerUtils.out.println("i26 i27 by1 = " + n7 + "," + n8 + "," + n10);
        FuzzerUtils.out.println("fArr lArr1 iArr3 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum(lArray) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

