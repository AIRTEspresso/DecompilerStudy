/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 43L;
    public static double dFld = 1.7067;
    public static volatile boolean bFld = false;
    public static double[][] dArrFld = new double[400][400];
    public static int[] iArrFld = new int[400];
    public static volatile long[] lArrFld = new long[400];
    public byte[][] byArrFld = new byte[400][400];
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n) {
        int n2 = -1;
        int n3 = 197;
        int n4 = -7;
        int n5 = -21;
        int n6 = -1643;
        int n7 = 63323;
        boolean bl = false;
        int n8 = 49;
        float f = 103.462f;
        for (n2 = 2; 160 > n2; ++n2) {
            for (n4 = 1; 10 > n4; ++n4) {
                n5 += (int)(dFld -= (double)instanceCount);
                for (n6 = 1; n6 < 2; ++n6) {
                    n3 = n4;
                    if (n != 0) {
                        // empty if block
                    }
                    double[] dArray = dArrFld[n6];
                    int n9 = n2;
                    dArray[n9] = dArray[n9] * (double)instanceCount;
                }
                n7 += n4 * n5 + n - n2;
            }
            n3 = n7;
            if (!bl) continue;
        }
        n8 = (byte)instanceCount;
        Test.iArrFld[(n2 >>> 1) % 400] = n6;
        n7 = (int)f;
        Test.lArrFld[(n6 >>> 1) % 400] = instanceCount;
        long l = n + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0) + n8 + Float.floatToIntBits(f);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, int n2, int n3) {
        int n4 = 9;
        int n5 = 41889;
        int n6 = -2;
        int n7 = 37738;
        double d = 68.129823;
        float f = -2.928f;
        instanceCount += (long)n3;
        for (n4 = 7; n4 < 146; ++n4) {
            n = n2++;
            if (bFld) {
                d -= (double)Test.iMeth(n);
                int n8 = (n3 >>> 1) % 400;
                lArrFld[n8] = lArrFld[n8] >> n5;
            }
            bFld = true;
            int n9 = n4 + 1;
            iArrFld[n9] = iArrFld[n9] & (int)instanceCount;
            f -= (float)n2;
            n3 >>= -186;
            if (n != 0) {
                vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7;
                return;
            }
            for (n6 = 1; n6 < 11; ++n6) {
                n2 = n;
                if (n4 != 0) {
                    vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7;
                    return;
                }
                n7 = 1118122118;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7;
    }

    public static long lMeth(long l, int n) {
        int n2 = 9;
        int n3 = 17008;
        int n4 = 37475;
        int n5 = 43607;
        int n6 = -7;
        int n7 = 6;
        int n8 = 1;
        long l2 = -2480036132L;
        int n9 = 118;
        Test.vMeth(n, n, n);
        n >>= (int)instanceCount;
        n *= -71;
        try {
            Test.lArrFld[(n >>> 1) % 400] = 31923L;
            n = (int)dFld;
            for (n2 = 3; 334 > n2; ++n2) {
                for (l2 = 1L; l2 < 5L; ++l2) {
                    for (n5 = 1; n5 < 2; ++n5) {
                        instanceCount = n4;
                    }
                    for (n7 = (int)l2; 2 > n7; n7 += 2) {
                        int n10 = (int)(l2 - 1L);
                        iArrFld[n10] = iArrFld[n10] - n9;
                        n8 = n4;
                        n3 = 85;
                    }
                }
            }
        }
        catch (NullPointerException nullPointerException) {
            l += -12L;
        }
        long l3 = l + (long)n + (long)n2 + (long)n3 + l2 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9;
        lMeth_check_sum += l3;
        return l3;
    }

    public void mainTest(String[] stringArray) {
        double d = 0.4767;
        int n = -119;
        int n2 = 10;
        int n3 = 0;
        int n4 = -60776;
        int n5 = -1;
        int n6 = 0;
        int n7 = -4329;
        int n8 = -13;
        int n9 = 6;
        float f = 2.519f;
        float[] fArray = new float[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(fArray, -40.79f);
        d = Test.lMeth(instanceCount, n);
        block20: for (n2 = 7; n2 < 162; ++n2) {
            f += (float)(n2 * n + n3 - n);
            switch (15) {
                case 9: {
                    n3 >>= n;
                    continue block20;
                }
                case 10: {
                    n = (int)((long)n + ((long)(n2 * n2 + n3) - instanceCount));
                    n3 = n2;
                    continue block20;
                }
                case 11: {
                    n = (int)((long)n + ((long)n2 * instanceCount + (long)n3 - (long)n));
                    n4 = 1;
                    do {
                        switch (n4 % 8 * 5 + 103) {
                            case 112: {
                                blArray[n2 + 1] = bFld;
                                this.byArrFld[n4 + 1] = this.byArrFld[n4];
                                for (n5 = 1; n5 < 1; ++n5) {
                                    n6 = n4;
                                    n7 += n5;
                                    n7 += n5 * n5;
                                    byte[] byArray = this.byArrFld[n5];
                                    int n10 = n5 - 1;
                                    byArray[n10] = (byte)(byArray[n10] * (byte)n4);
                                }
                                n += n4 ^ n7;
                                break;
                            }
                            case 106: {
                                f = n4;
                                break;
                            }
                            case 115: 
                            case 124: {
                                n3 += n4;
                                n6 = (int)instanceCount;
                                int n11 = n4 - 1;
                                iArrFld[n11] = iArrFld[n11] ^ n7;
                            }
                            case 114: {
                                fArray[n4 + 1] = n2;
                                for (n8 = 1; 1 > n8; ++n8) {
                                    n3 += n7;
                                    n += n8 * n2;
                                    n3 = n2;
                                }
                            }
                            case 140: {
                                n += n5;
                                break;
                            }
                            case 111: {
                                instanceCount >>= n2;
                                break;
                            }
                            case 126: {
                                n6 += 99 + n4 * n4;
                            }
                            default: {
                                instanceCount <<= n2;
                            }
                        }
                    } while (++n4 < 162);
                    continue block20;
                }
                case 12: {
                    n *= -62298;
                }
                case 13: {
                    n6 = 852093173;
                    continue block20;
                }
                case 14: {
                    instanceCount -= instanceCount;
                }
                case 15: {
                    instanceCount = n3;
                    continue block20;
                }
                case 16: 
                case 17: {
                    f = n8;
                    continue block20;
                }
                case 18: {
                    n9 += n2 * n2;
                }
            }
        }
        FuzzerUtils.out.println("d i22 i23 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("i24 f2 i25 = " + n3 + "," + Float.floatToIntBits(f) + "," + n4);
        FuzzerUtils.out.println("i26 i27 i28 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i29 i30 bArr = " + n8 + "," + n9 + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dArrFld Test.iArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("byArrFld = " + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 91.129012);
        FuzzerUtils.init(iArrFld, 5);
        FuzzerUtils.init(lArrFld, -7418724081430529930L);
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

