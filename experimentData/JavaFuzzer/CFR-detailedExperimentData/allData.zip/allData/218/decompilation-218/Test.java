/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 2877520852L;
    public float fFld = 1.642f;
    public static int iFld = 26114;
    public byte byFld = (byte)-62;
    public static volatile long[] lArrFld = new long[400];
    public static short[] sArrFld = new short[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2) {
        int n3 = -13243;
        int n4 = 52806;
        int n5 = -142;
        int[] nArray = new int[400];
        int[] nArray2 = new int[400];
        boolean bl = true;
        double d = 0.121;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -77);
        FuzzerUtils.init(nArray2, -20489);
        FuzzerUtils.init(lArray, 6561997257802867438L);
        n3 = (short)(n3 - 2);
        n2 >>= n;
        for (n4 = 200; n4 > 6; --n4) {
            instanceCount = -9L;
            if (bl) break;
            d = 1.0;
            do {
                nArray[n4 - 1] = 6;
                instanceCount += (long)d;
                instanceCount *= instanceCount;
                n2 -= 174;
                int n6 = n4 + 1;
                nArray2[n6] = nArray2[n6] >> 4;
                instanceCount >>= n4;
                int n7 = (int)(d + 1.0);
                nArray[n7] = nArray[n7] - 1;
                int n8 = (int)d;
                lArray[n8] = lArray[n8] + -23891L;
                n -= n4;
            } while ((d += 1.0) < 8.0);
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + (bl ? 1 : 0)) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(nArray2) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n, int n2) {
        double d = 116.22305;
        double d2 = 26.94027;
        double[] dArray = new double[400];
        int n3 = 10;
        int n4 = -53309;
        int n5 = -20;
        int n6 = 10;
        int[][] nArray = new int[400][400];
        float f = 10.96f;
        float[][][] fArray = new float[400][400][400];
        FuzzerUtils.init(nArray, 81);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(-1.349f));
        FuzzerUtils.init(dArray, 5.110394);
        for (d = 5.0; d < 149.0; d += 1.0) {
            Test.vMeth1(n2, n);
            for (n4 = 1; 11 > n4; ++n4) {
                n6 = 1;
                do {
                    instanceCount += (long)n6 | instanceCount;
                } while (++n6 < 2);
                d2 -= (double)n4;
                f = n2;
                n5 = 54417;
                int[] nArray2 = nArray[n4];
                int n7 = (int)(d - 1.0);
                nArray2[n7] = nArray2[n7] >> n2;
            }
        }
        f = 111.0f;
        instanceCount = n4;
        fArray[(n3 >>> 1) % 400][(n5 >>> 1) % 400][(n >>> 1) % 400] = -42614.0f;
        n2 = iFld;
        iFld = n5 = (int)instanceCount;
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d2) + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static int iMeth(float f, int n, int n2) {
        int n3 = 14;
        int n4 = 644;
        int n5 = -65049;
        int n6 = 172;
        int n7 = 9;
        int[] nArray = new int[400];
        double d = 2.117393;
        FuzzerUtils.init(nArray, 57977);
        for (n3 = 5; 333 > n3; ++n3) {
            int n8 = n2;
            n2 -= Math.max((int)(instanceCount - 7343052530477782916L), (int)((float)instanceCount - f));
            n2 = n8 - n2;
            n *= (int)((double)((long)n2 + ((long)n4 + instanceCount)) * (d *= (double)((long)n4 + instanceCount)));
            Test.vMeth(iFld, n2);
            d -= -8510.0;
            n5 = 5;
            do {
                for (n6 = n5; n6 < 1; ++n6) {
                    instanceCount &= instanceCount;
                    int n9 = n6 + 1;
                    nArray[n9] = nArray[n9] - iFld;
                    int n10 = n6 - 1;
                    lArrFld[n10] = lArrFld[n10] - (long)n4;
                    instanceCount = -14484L;
                    f = n2;
                    n7 >>= n5;
                    f += (float)(53286 + n6 * n6);
                }
            } while (--n5 > 0);
            n2 -= n5;
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 64914;
        int n2 = 62731;
        int n3 = 6;
        int n4 = -179;
        int n5 = 1;
        int[] nArray = new int[400];
        double d = -90.12598;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -1.525f);
        FuzzerUtils.init(nArray, 4124);
        block13: for (n = 12; n < 374; ++n) {
            int n6 = n + 1;
            fArray[n6] = fArray[n6] - -4.11633954E18f;
            n2 = (int)((float)n2++ - (float)n * this.fFld + (float)Long.reverseBytes(instanceCount));
            switch (n % 2 * 5 + 28) {
                case 34: {
                    n2 >>>= (int)(Math.abs(this.fFld += 1.0f) % (float)(Test.iMeth(-79.489f, n2, -12623) + n | 1));
                    switch (n % 8 + 103) {
                        case 103: {
                            n2 <<= iFld;
                            break;
                        }
                        case 104: 
                        case 105: {
                            for (n3 = 2; n3 < 70; ++n3) {
                                int n7 = n + 1;
                                nArray[n7] = nArray[n7] + n2;
                                n4 <<= n4;
                            }
                            this.byFld = (byte)(this.byFld - (byte)n4);
                            this.byFld = (byte)(this.byFld >> (byte)n2);
                            int n8 = n - 1;
                            nArray[n8] = nArray[n8] * (int)this.fFld;
                            break;
                        }
                        case 106: {
                            n4 = 13;
                            this.fFld = n2;
                            int n9 = n;
                            nArray[n9] = nArray[n9] + n4;
                            break;
                        }
                        case 107: {
                            int n10 = n;
                            lArrFld[n10] = lArrFld[n10] + (long)n4;
                            d = n4;
                            n4 += n * n;
                            n4 %= n4 | 1;
                            break;
                        }
                        case 108: {
                            iFld >>= 155;
                        }
                        case 109: {
                            n4 = (int)instanceCount;
                            n2 &= iFld;
                            break;
                        }
                        case 110: {
                            this.fFld += (float)n4;
                            int n11 = n;
                            sArrFld[n11] = (short)(sArrFld[n11] - (short)n);
                        }
                    }
                    n5 = 1;
                    do {
                        fArray[n5 + 1] = instanceCount;
                        iFld += n2;
                    } while (++n5 < 70);
                    continue block13;
                }
                case 37: {
                    instanceCount += (long)n;
                }
            }
        }
        FuzzerUtils.out.println("i i1 i19 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i20 d5 i21 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("fArr iArr4 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + iFld);
        FuzzerUtils.out.println("byFld Test.lArrFld Test.sArrFld = " + this.byFld + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 9L);
        FuzzerUtils.init(sArrFld, (short)22098);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

