/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 743154865L;
    public static int iFld = 48177;
    public static byte byFld = (byte)-86;
    public static short sFld = (short)-21802;
    public static boolean bFld = true;
    public int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(long l, long l2, int n) {
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -105);
        int n2 = (n >>> 1) % 400;
        nArray[n2] = nArray[n2] >>> 32737;
        vMeth1_check_sum += l + l2 + (long)n + FuzzerUtils.checkSum(nArray);
    }

    public static long lMeth(long l) {
        float f = -1.827f;
        float f2 = 2.176f;
        int n = -9;
        int n2 = -217;
        int n3 = -14;
        int n4 = 11;
        int n5 = -229;
        int[] nArray = new int[400];
        boolean bl = true;
        FuzzerUtils.init(nArray, -162);
        Test.vMeth1(l, instanceCount, iFld);
        for (f = 7.0f; f < 122.0f; f += 1.0f) {
            for (n2 = 1; n2 < 14; ++n2) {
                nArray[n2] = 0;
                iFld += n2 * byFld + n2 - sFld;
            }
            n += 36124;
            for (n4 = 1; n4 < 14; ++n4) {
                if (iFld != 0) {
                    // empty if block
                }
                if (bl) continue;
                l = 0L;
                iFld >>>= n4;
                n3 -= n2;
                f2 = 48486.0f;
            }
            n3 += (int)(f * (float)n3 + (float)n - (float)n);
        }
        long l2 = l + (long)Float.floatToIntBits(f) + (long)(n >>>= n5) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f2) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l2;
        return l2;
    }

    public void vMeth(int n) {
        long l = -25L;
        int n2 = -130;
        int n3 = 7;
        int n4 = 40732;
        int n5 = 19417;
        int n6 = 34;
        float f = -28.436f;
        double d = -103.87417;
        double d2 = 2.8014;
        for (l = 6L; l < 150L; ++l) {
            n3 = 1;
            while (++n3 < 11) {
                n2 |= (int)((Test.lMeth(l) - (long)iFld) * instanceCount);
            }
            if (bFld) break;
            n -= n3;
            n += (int)(l * l);
            f = (float)d;
            block8: for (d2 = 1.0; 11.0 > d2; d2 += 1.0) {
                switch ((int)(d2 % 4.0 + 2.0)) {
                    case 2: {
                        instanceCount >>= iFld;
                        n5 = 1;
                        while (n5 < 2) {
                            sFld = (short)n4;
                            n = n5++;
                            int n7 = (int)d2;
                            this.iArrFld[n7] = this.iArrFld[n7] + (int)d2;
                            this.iArrFld[(int)d2] = (int)l;
                        }
                    }
                    case 3: {
                        n6 += (int)f;
                    }
                    case 4: {
                        iFld <<= n5;
                        continue block8;
                    }
                    case 5: {
                        n6 >>= n6;
                        continue block8;
                    }
                    default: {
                        n4 = (int)((double)n4 + (35.0 + d2 * d2));
                    }
                }
            }
        }
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n4 + (long)n5 + (long)n6;
    }

    public void mainTest(String[] stringArray) {
        int n = 142;
        int n2 = 41;
        int n3 = -228;
        int n4 = 33520;
        int n5 = -52152;
        int n6 = 40904;
        int n7 = -8;
        int n8 = 59824;
        int n9 = -34714;
        int n10 = 210;
        int n11 = 185;
        double d = -123.3001;
        float f = -1.274f;
        boolean[] blArray = new boolean[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(lArray, 18827L);
        n = n--;
        this.vMeth(n);
        for (n2 = 13; n2 < 358; ++n2) {
            iFld += (int)d;
            iFld += (int)instanceCount;
            instanceCount -= (long)n4;
            n3 *= -29991;
            n += n2;
            n4 = (int)d;
        }
        n3 += 152;
        block1: for (n5 = 168; n5 > 8; n5 -= 3) {
            n7 = 129;
            do {
                d = instanceCount;
                n4 <<= n4;
            } while (--n7 > 0);
            for (n8 = 17; 344 > n8; ++n8) {
                for (n10 = n5; n10 < 2; ++n10) {
                    float f2 = -88.276f;
                    this.iArrFld[n8] = n3;
                    int n12 = n10 + 1;
                    fArrFld[n12] = fArrFld[n12] * (float)instanceCount;
                    instanceCount >>= n9;
                    if (bFld) continue;
                    n3 *= (int)f2;
                    f2 = n8;
                    byFld = (byte)(byFld - (byte)instanceCount);
                }
                int n13 = n8 + 1;
                this.iArrFld[n13] = this.iArrFld[n13] * (int)d;
                f *= (float)n2;
                blArray[n8] = true;
                int n14 = n8;
                lArray[n14] = lArray[n14] - -1L;
                n4 += n8;
                if (bFld) continue block1;
            }
        }
        FuzzerUtils.out.println("i i13 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("d2 i15 i16 = " + Double.doubleToLongBits(d) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i17 i18 i19 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i20 i21 i22 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("f4 bArr lArr = " + Float.floatToIntBits(f) + "," + FuzzerUtils.checkSum(blArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + byFld);
        FuzzerUtils.out.println("Test.sFld Test.bFld iArrFld = " + sFld + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 2.25f);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

