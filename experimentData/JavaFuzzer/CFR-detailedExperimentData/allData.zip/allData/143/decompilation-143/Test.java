/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 7709079513175631415L;
    public static int iFld = -22204;
    public double dFld = -2.91153;
    public static float fFld = -1.24f;
    public static byte byFld = (byte)-34;
    public static double dFld1 = 100.68138;
    public static volatile boolean bFld = false;
    public static byte[] byArrFld = new byte[400];
    public static volatile double[] dArrFld = new double[400];
    public static float[] fArrFld = new float[400];
    public static long bMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth() {
        int n = -4;
        int n2 = 7398;
        int n3 = 4524;
        int n4 = -56;
        int n5 = -22877;
        int n6 = -11;
        int n7 = -110;
        int n8 = -1;
        int[] nArray = new int[400];
        int n9 = 31184;
        double d = 33.110441;
        int n10 = -126;
        FuzzerUtils.init(nArray, 12);
        iFld = -252;
        for (n = 2; n < 272; ++n) {
            iFld += n;
            iFld += n2;
        }
        for (n3 = 7; 387 > n3; ++n3) {
            fFld += (float)n2;
        }
        block12: for (n5 = 13; n5 < 297; ++n5) {
            n6 = n9;
            switch (n5 % 6 + 43) {
                case 43: {
                    n2 -= n6;
                    for (n7 = 1; 6 > n7; ++n7) {
                        d = n10;
                        int n11 = n5 - 1;
                        nArray[n11] = nArray[n11] + n5;
                        int n12 = n5 - 1;
                        byArrFld[n12] = (byte)(byArrFld[n12] >> (byte)n5);
                        try {
                            n4 = n7 / n4;
                            nArray[n7] = n / n5;
                            nArray[n7] = nArray[n7 + 1] / iFld;
                            continue;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                }
                case 44: {
                    n4 += n5;
                    continue block12;
                }
                case 45: {
                    iFld += n;
                    continue block12;
                }
                case 46: {
                    nArray[n5 + 1] = n5;
                    continue block12;
                }
                case 47: {
                    n4 = 9;
                    continue block12;
                }
                case 48: {
                    n8 = (int)instanceCount;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n9 + n7 + n8) + Double.doubleToLongBits(d) + (long)n10 + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(int n, int n2, int n3) {
        int n4 = -28202;
        int n5 = -88;
        int n6 = -2;
        int n7 = -56755;
        int n8 = -7;
        int n9 = 63264;
        int[][] nArray = new int[400][400];
        int[] nArray2 = new int[400];
        int n10 = 17743;
        boolean bl = false;
        FuzzerUtils.init(nArray, 137);
        FuzzerUtils.init(nArray2, 10);
        for (n4 = 3; n4 < 360; ++n4) {
            iFld = n2 = (int)Math.abs((long)n3 + instanceCount);
            Test.vMeth();
            n6 = 1;
            do {
                n7 = 1;
                while (++n7 < 1) {
                    n3 = n5;
                    instanceCount -= (long)fFld;
                }
                n10 = (short)(n10 - 56);
            } while (++n6 < 5);
            n2 = (int)((float)n2 + ((float)n4 * fFld + (float)instanceCount - (float)n7));
        }
        int[] nArray3 = nArray[(n7 >>> 1) % 400];
        int n11 = (n4 >>> 1) % 400;
        nArray3[n11] = nArray3[n11] - byFld;
        for (int n12 : nArray2) {
            n8 = 1;
            while (n8 < 4) {
                bl = true;
                n2 -= (int)dFld1;
                int n13 = n8++;
                nArray2[n13] = nArray2[n13] - (int)fFld;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n10 + n8 + n9 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(nArray2);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static boolean bMeth(int n, int n2) {
        int n3 = -7;
        int n4 = 58;
        int n5 = -94;
        int n6 = -9;
        int[] nArray = new int[400];
        long l = -37580L;
        long[][] lArray = new long[400][400];
        long[] lArray2 = new long[400];
        FuzzerUtils.init(nArray, -191);
        FuzzerUtils.init(lArray, -2006617079L);
        FuzzerUtils.init(lArray2, 1644995907L);
        int n7 = (n2 >>> 1) % 400;
        nArray[n7] = nArray[n7] & 0x8D75;
        if (bFld) {
            n = (int)((long)Test.iMeth(iFld, iFld, 49048) + -149430473L);
            for (n3 = 9; 195 > n3; ++n3) {
                long[] lArray3 = lArray[n3 - 1];
                int n8 = n3 + 1;
                lArray3[n8] = lArray3[n8] - -15871L;
                l = 1L;
                do {
                    block11: for (n5 = 1; n5 < 1; n5 += 3) {
                        switch (n5 % 7 + 44) {
                            case 44: {
                                iFld = n6;
                                n4 *= -12;
                                n -= (int)fFld;
                                fFld -= (float)instanceCount;
                                continue block11;
                            }
                            case 45: {
                                iFld = 8;
                                nArray[n5] = n3;
                                n6 += -3441 + n5 * n5;
                                continue block11;
                            }
                            case 46: {
                                int n9 = n3 - 1;
                                dArrFld[n9] = dArrFld[n9] + (double)l;
                                continue block11;
                            }
                            case 47: {
                                dFld1 = 4.9984419067641201E18;
                                continue block11;
                            }
                            case 48: {
                                if (n6 != 0) {
                                    return (int)((long)(n + n2 + n3 + n4) + l + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(lArray2)) % 2 > 0;
                                }
                            }
                            case 49: {
                                n -= n4;
                                continue block11;
                            }
                            case 50: {
                                n2 += n5 * n4 + n4 - n4;
                                continue block11;
                            }
                        }
                    }
                } while (++l < 9L);
            }
        } else if (bFld) {
            // empty if block
        }
        long l2 = (long)(n + n2 + n3 + n4) + l + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(lArray2);
        bMeth_check_sum += l2;
        return l2 % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = -14;
        int n2 = 3;
        int n3 = 23;
        int n4 = -193;
        int n5 = 14;
        int n6 = -112;
        int n7 = 8;
        int n8 = -143;
        int n9 = -17035;
        int n10 = -229;
        int n11 = 115;
        int[] nArray = new int[400];
        float f = 29.446f;
        double d = -1.126296;
        int n12 = -10674;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)-2L);
        FuzzerUtils.init(nArray, 77);
        Test.byArrFld[82] = (byte)iFld;
        long[] lArray2 = lArray[69][(iFld >>> 1) % 400];
        long l = lArray2[324] - (long)iFld;
        lArray2[324] = l;
        instanceCount += (long)iFld - ((long)(this.dFld + (double)instanceCount) >> (int)l);
        for (n = 10; 208 > n; ++n) {
            if (Test.bMeth(iFld, n)) continue;
            for (f = 4.0f; f < 127.0f; f += 1.0f) {
                for (n4 = 1; 2 > n4 && !bFld; ++n4) {
                }
            }
            n2 += (int)instanceCount;
            n2 += n2;
            fFld += (float)(n - iFld);
            for (d = 6.0; d < 127.0; d += 1.0) {
                iFld += (int)(d * (double)instanceCount);
                fFld += (float)n2;
            }
            instanceCount %= (long)(n6 | 1);
            instanceCount += (long)n;
        }
        for (n7 = 6; n7 < 214; ++n7) {
            for (n9 = 121; 7 < n9; n9 -= 2) {
                n11 = 3;
                do {
                    fFld -= (float)n12;
                    lArray[n9][n9 - 1][n11] = instanceCount;
                    n10 = (int)((long)n10 + ((long)(n11 * n6 + n11) - instanceCount));
                    n8 = n4;
                    int n13 = n9 - 1;
                    nArray[n13] = nArray[n13] - n8;
                    n8 *= n6;
                    switch (n7 % 2 + 107) {
                        case 107: {
                            nArray = FuzzerUtils.int1array(400, 43629);
                            n5 = n8;
                            int n14 = n9 - 1;
                            dArrFld[n14] = dArrFld[n14] + (double)n5;
                            iFld += n11 | n8;
                            break;
                        }
                        case 108: {
                            n2 <<= 60;
                            break;
                        }
                        default: {
                            fFld += (float)instanceCount;
                        }
                    }
                } while (--n11 > 0);
            }
        }
        FuzzerUtils.out.println("i i1 f = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i26 i27 i28 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("d1 i29 i30 = " + Double.doubleToLongBits(d) + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i31 i32 i33 = " + n8 + "," + n9 + "," + n10);
        FuzzerUtils.out.println("i34 s2 lArr = " + n11 + "," + n12 + "," + FuzzerUtils.checkSum((Object[][])lArray));
        FuzzerUtils.out.println("iArr4 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.fFld Test.byFld Test.dFld1 = " + Float.floatToIntBits(fFld) + "," + byFld + "," + Double.doubleToLongBits(dFld1));
        FuzzerUtils.out.println("Test.bFld Test.byArrFld Test.dArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(byArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(byArrFld, (byte)103);
        FuzzerUtils.init(dArrFld, 2.44158);
        FuzzerUtils.init(fArrFld, 1.69f);
        bMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

