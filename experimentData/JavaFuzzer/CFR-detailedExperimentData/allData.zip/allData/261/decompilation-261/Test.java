/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 118L;
    public int iFld = 58665;
    public volatile float fFld = 105.646f;
    public static double dFld = 21.125562;
    public static byte byFld = (byte)-96;
    public static short sFld = (short)11635;
    public double dFld1 = 15.18372;
    public static long[] lArrFld = new long[400];
    public short[][][] sArrFld = new short[400][400][400];
    public int[] iArrFld = new int[400];
    public static double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2) {
        n = n2;
        vMeth2_check_sum += (long)(n + n2);
    }

    public static void vMeth1(int n, long l) {
        int n2 = 7;
        int n3 = 4;
        int n4 = 9;
        int n5 = -14;
        int n6 = 25864;
        int n7 = -3869;
        int n8 = 1612;
        int[] nArray = new int[400];
        int n9 = -8858;
        boolean bl = false;
        FuzzerUtils.init(nArray, -1);
        Test.vMeth2(n += (int)l--, n);
        int n10 = (n >>> 1) % 400;
        lArrFld[n10] = lArrFld[n10] + l;
        block11: for (n2 = 10; n2 < 312; ++n2) {
            int n11 = -38;
            n11 = (byte)(n11 + (byte)(n2 + n3));
            switch (n2 % 9 * 5 + 121) {
                case 139: {
                    for (n4 = n2; 5 > n4; ++n4) {
                        for (n6 = n4; n6 < 1; ++n6) {
                            n9 = (short)(n9 & (short)n6);
                            --n3;
                            n <<= -14;
                            l = -22472L;
                            if (!bl) continue;
                        }
                        n7 *= n3;
                        int n12 = n2 - 1;
                        nArray[n12] = nArray[n12] + (int)dFld;
                    }
                    continue block11;
                }
                case 141: {
                    instanceCount -= (long)n2;
                }
                case 122: {
                    instanceCount = n7;
                }
                case 125: {
                    instanceCount = l;
                    continue block11;
                }
                case 157: {
                    n = -115;
                    continue block11;
                }
                case 166: {
                    n3 += (int)l;
                    continue block11;
                }
                case 147: {
                    instanceCount -= (long)n6;
                    continue block11;
                }
                case 159: {
                    n7 *= n8;
                    continue block11;
                }
                case 152: {
                    n5 = n6;
                }
            }
        }
        vMeth1_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n9 + (long)(bl ? 1 : 0) + (long)n8 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n, long l) {
        int n2 = -110;
        int n3 = -243;
        int n4 = -5;
        int n5 = -12;
        int[] nArray = new int[400];
        float f = 0.733f;
        FuzzerUtils.init(nArray, -15513);
        for (n2 = 12; n2 < 343; ++n2) {
            Test.vMeth1(107, -3L);
            byFld = (byte)(byFld >>> (byte)n);
            int n6 = n2 + 1;
            nArray[n6] = nArray[n6] + (int)dFld;
            int n7 = n2 - 1;
            lArrFld[n7] = lArrFld[n7] * (long)n;
            f = 1.0f;
            do {
                sFld = (short)-19;
                for (n4 = (int)f; n4 < 1; ++n4) {
                    nArray[(int)f] = n3;
                    if (n == 0) continue;
                    vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
                    return;
                }
                switch ((n5 >>> 1) % 9 + 119) {
                    case 119: {
                        n5 = (int)instanceCount;
                        n5 >>= n3;
                        break;
                    }
                    case 120: {
                        n3 += (int)(f * (float)l + (float)l - (float)instanceCount);
                        n += n5;
                        break;
                    }
                    case 121: {
                        n5 = (int)dFld;
                        break;
                    }
                    case 122: {
                        break;
                    }
                    case 123: {
                        n5 += (int)(f * (float)n4 + f - (float)n);
                        break;
                    }
                    case 124: {
                        n5 &= 0xAC7E;
                    }
                    case 125: {
                        l -= (long)byFld;
                        break;
                    }
                    case 126: {
                        break;
                    }
                    case 127: {
                        int n8 = (int)(f + 1.0f);
                        nArray[n8] = nArray[n8] - n3;
                    }
                }
            } while ((f += 1.0f) < 5.0f);
        }
        vMeth_check_sum += (long)n + l + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -9;
        int n2 = -56;
        int n3 = -61707;
        int n4 = -193;
        int n5 = -89;
        int n6 = 4;
        int n7 = 27519;
        int n8 = 8;
        int n9 = -4;
        int n10 = -18154;
        boolean bl = false;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.108f);
        fArray[(this.iFld >>> 1) % 400] = this.fFld;
        for (n = 5; n < 172; ++n) {
            Test.vMeth(n, -7389263707675291169L);
            this.iFld = (int)instanceCount;
            if (bl) break;
            short[] sArray = this.sArrFld[n + 1][n - 1];
            int n11 = n - 1;
            sArray[n11] = (short)(sArray[n11] % (short)((long)this.fFld | 1L));
            this.iFld += n * n;
            int n12 = (this.iFld >>> 1) % 400;
            this.iArrFld[n12] = this.iArrFld[n12] - n;
            for (n3 = 4; n3 < 150; ++n3) {
                n2 = n;
                this.fFld += (float)n4;
            }
            n4 -= n3;
            int n13 = n;
            this.iArrFld[n13] = this.iArrFld[n13] - (int)instanceCount;
            n4 += n;
        }
        for (n5 = 7; n5 < 221; ++n5) {
            sFld = (short)n5;
            int n14 = n5 - 1;
            dArrFld[n14] = dArrFld[n14] + dFld;
            n6 += n5;
            for (n7 = n5; n7 < 117; ++n7) {
                instanceCount += (long)n7 - instanceCount;
                sFld = (short)(sFld * 14);
            }
            n2 += n5 + n2;
        }
        FuzzerUtils.out.println("i i1 b1 = " + n + "," + n2 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i18 i19 i20 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i21 i22 i23 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i24 i25 fArr = " + n9 + "," + n10 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.dFld Test.byFld Test.sFld = " + Double.doubleToLongBits(dFld) + "," + byFld + "," + sFld);
        FuzzerUtils.out.println("dFld1 Test.lArrFld sArrFld = " + Double.doubleToLongBits(this.dFld1) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.sArrFld));
        FuzzerUtils.out.println("iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 26450288L);
        FuzzerUtils.init(dArrFld, 1.94222);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

