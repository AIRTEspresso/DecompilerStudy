/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 184L;
    public static boolean bFld = false;
    public static byte byFld = (byte)97;
    public static double dFld = -118.123343;
    public static int iFld = -39966;
    public static float[] fArrFld = new float[400];
    public volatile short[] sArrFld = new short[400];
    public static double[] dArrFld = new double[400];
    public byte[] byArrFld = new byte[400];
    public static long vSmallMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, int n2, short s) {
        double d = 0.19451;
        long l = 60782L;
        int n3 = 33135;
        int n4 = 41659;
        int n5 = -49521;
        int n6 = -27;
        int[] nArray = new int[400];
        float f = -2.342f;
        float f2 = -32.13f;
        float f3 = -90.347f;
        int n7 = -11;
        FuzzerUtils.init(nArray, -6);
        d += (double)s;
        for (l = 17L; 396L > l; ++l) {
            f += (float)l;
            int n8 = (int)(l + 1L);
            nArray[n8] = nArray[n8] - (n3 += 981943660);
        }
        n = (int)f2;
        for (f3 = 15.0f; f3 < 255.0f; f3 += 1.0f) {
            if (bFld) continue;
            n2 = n7;
            f += f3 * (float)n4 + (float)n2 - (float)n2;
            n5 = 7;
            while ((float)n5 > f3) {
                s = (short)n6;
                f2 += (float)n5;
                n6 = -11361;
                n5 -= 2;
            }
        }
        vMeth_check_sum += (long)(n + n2 + s) + Double.doubleToLongBits(d) + l + (long)n3 + (long)Float.floatToIntBits(f) + (long)Float.floatToIntBits(f2) + (long)Float.floatToIntBits(f3) + (long)n4 + (long)n7 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(int n, int n2) {
        float f = 39.32f;
        int n3 = -7;
        int n4 = -99;
        int n5 = -38992;
        int n6 = -13182;
        int n7 = 23621;
        int n8 = 65037;
        int n9 = 40963;
        int[] nArray = new int[400];
        long l = 1622L;
        FuzzerUtils.init(nArray, -21378);
        Test.vMeth(n2, 24286, (short)-19034);
        n = (int)f;
        nArray[94] = nArray[94] - byFld;
        n2 *= 652834599;
        for (n3 = 16; n3 < 396; ++n3) {
            f -= (float)n4;
            for (n5 = 1; n5 < 4; ++n5) {
                if (!bFld) continue;
            }
        }
        for (n7 = 3; n7 < 183; ++n7) {
            n8 += (int)dFld;
            instanceCount += (long)n7 - instanceCount;
            for (l = 1L; l < 9L; ++l) {
                n += (int)(l ^ instanceCount);
                n += (int)((float)l * f);
                n6 = n9;
            }
        }
        long l2 = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6 + n7 + n8) + l + (long)n9 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vSmallMeth(int n, double d) {
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 28529);
        int n2 = (n >>> 1) % 400;
        nArray[n2] = nArray[n2] * (int)(-113.332f + (float)(n * Test.iMeth(n, n)));
        n += n;
        vSmallMeth_check_sum += (long)n + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 2;
        int n2 = -23963;
        int n3 = -56147;
        int n4 = -12;
        int n5 = 11;
        int n6 = 145;
        int n7 = -55;
        int[] nArray = new int[400];
        float f = -84.794f;
        FuzzerUtils.init(nArray, 99);
        instanceCount = n;
        for (n2 = 19; n2 < 378; ++n2) {
            n3 += n2;
            for (int i = 0; i < 62; ++i) {
                Test.vSmallMeth(n, dFld);
            }
            f += (float)((long)(n2 * n) + instanceCount - (long)n3);
            n3 -= n3;
            nArray[n2 + 1] = n;
            dFld -= (double)n;
            n3 = (int)((long)n3 + ((long)n2 ^ (long)f));
            n3 += n3;
            n3 += (int)instanceCount;
        }
        n4 = 1;
        do {
            int n8 = n4;
            nArray[n8] = nArray[n8] << (iFld += n);
            f /= (float)(instanceCount | 1L);
            instanceCount += (long)n4 ^ instanceCount;
            this.sArrFld[n4] = (short)n3;
            for (n5 = n4; n5 < 68; ++n5) {
                n7 = 1;
                block19: do {
                    n3 += 89;
                    switch (n4 % 9 * 5 + 63) {
                        case 65: {
                            byFld = 1;
                        }
                        case 74: {
                            switch (n7 % 2 + 4) {
                                default: 
                            }
                            Test.dArrFld[n5 + 1] = iFld;
                            byFld = (byte)(byFld - (byte)f);
                            break;
                        }
                        case 71: {
                            int n9 = n7 + 1;
                            nArray[n9] = nArray[n9] + (int)(instanceCount += (long)n7);
                            f += (float)(-28802 + n7 * n7);
                            this.byArrFld[n5 + 1] = (byte)instanceCount;
                            break;
                        }
                        case 90: {
                            iFld *= (int)dFld;
                            break;
                        }
                        case 108: {
                            n -= n5;
                            break;
                        }
                        case 70: {
                            try {
                                nArray[n4] = n6 / 28732;
                                iFld = n / n4;
                                n3 = n7 % 1635724932;
                            }
                            catch (ArithmeticException arithmeticException) {}
                            continue block19;
                        }
                        case 89: {
                            f *= -98.124825f;
                            break;
                        }
                        case 98: {
                            instanceCount += (long)iFld;
                        }
                        case 75: {
                            n6 += n7;
                            break;
                        }
                        default: {
                            byFld = (byte)(byFld + (byte)n7);
                        }
                    }
                } while (++n7 < 1);
            }
        } while (++n4 < 373);
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f5 i21 i22 = " + Float.floatToIntBits(f) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i23 i24 iArr3 = " + n6 + "," + n7 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.byFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + byFld);
        FuzzerUtils.out.println("Test.dFld Test.iFld Test.fArrFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("sArrFld Test.dArrFld byArrFld = " + FuzzerUtils.checkSum(this.sArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 1.598f);
        FuzzerUtils.init(dArrFld, 0.99626);
        vSmallMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

