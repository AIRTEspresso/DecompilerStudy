/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1318088676L;
    public static double dFld = 0.87392;
    public static boolean bFld = false;
    public static short sFld = (short)-420;
    public static long vMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long iMeth1_check_sum = 0L;

    public static int iMeth1(double d) {
        int n = -18454;
        int n2 = 104;
        int n3 = -2;
        double[] dArray = new double[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(dArray, -8.89364);
        FuzzerUtils.init(lArray, -3489466803L);
        n = 1;
        do {
            int n4 = n + 1;
            dArray[n4] = dArray[n4] - (double)instanceCount;
        } while (++n < 130);
        int n5 = (n >>> 1) % 400;
        dArray[n5] = dArray[n5] - (double)instanceCount;
        for (n2 = 14; 236 > n2; ++n2) {
            n3 -= (int)instanceCount;
            n3 = (int)((long)n3 + ((long)n2 * instanceCount + (long)n - (long)n));
            n3 -= n3;
            d += 136.0;
            n3 += 8796 + n2 * n2;
            int n6 = n2 + 1;
            lArray[n6] = lArray[n6] + -53770L;
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth() {
        int n = 54889;
        int n2 = 10;
        int n3 = 245;
        int n4 = -65;
        int n5 = -64298;
        int[] nArray = new int[400];
        float f = 0.1013f;
        boolean[] blArray = new boolean[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, -101);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(dArray, 6.59892);
        block10: for (n = 4; n < 283; ++n) {
            instanceCount += (long)n;
            switch ((n2 >>> 1) % 7 + 20) {
                case 20: 
                case 21: {
                    Test.iMeth1(dFld);
                    nArray[n + 1] = -13;
                    n2 = (int)instanceCount;
                    instanceCount = n2;
                    continue block10;
                }
                case 22: {
                    instanceCount += (long)(-9157 + n * n);
                    instanceCount <<= (n2 += n * n);
                    continue block10;
                }
                case 23: {
                    blArray[n - 1] = bFld;
                    for (n3 = 1; n3 < 6; ++n3) {
                        int n6 = n + 1;
                        nArray[n6] = nArray[n6] << n5;
                        dArray[n + 1] = n3;
                    }
                    continue block10;
                }
                case 24: {
                    try {
                        n4 = n2 % n;
                        n4 = -29401 % n3;
                        nArray[n] = nArray[n - 1] % -7197;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                case 25: {
                    if (!bFld) continue block10;
                    continue block10;
                }
                case 26: {
                    instanceCount *= (long)n3;
                    continue block10;
                }
                default: {
                    f = n3;
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(long l) {
        int n = 14;
        int n2 = 210;
        int n3 = 137;
        int n4 = -7;
        int n5 = -195;
        int n6 = 32067;
        int n7 = -6;
        int n8 = -14;
        int n9 = -60534;
        int[][][] nArray = new int[400][400][400];
        int n10 = 72;
        byte[][][] byArray = new byte[400][400][400];
        float f = -121.456f;
        double[] dArray = new double[400];
        FuzzerUtils.init((Object[][])nArray, (Object)10);
        FuzzerUtils.init((Object[][])byArray, (Object)-100);
        FuzzerUtils.init(dArray, 40.70373);
        for (n = 154; n > 4; --n) {
            l = Test.iMeth();
            nArray[n - 1][n + 1][n + 1] = (int)l;
            sFld = (short)(sFld + (short)instanceCount);
            byte[] byArray2 = byArray[n][n + 1];
            int n11 = n - 1;
            byArray2[n11] = (byte)(byArray2[n11] >> n10);
        }
        for (n3 = 1; n3 < 284; ++n3) {
            for (n5 = n3; 6 > n5; ++n5) {
                n6 |= (int)instanceCount;
            }
            n7 = 6;
            do {
                for (n8 = 1; 1 > n8; ++n8) {
                    n9 >>= -64076;
                    l += (long)(n8 * n8);
                    n6 <<= 10;
                    n4 += (int)f;
                    dArray = FuzzerUtils.double1array(400, 2.90576);
                    n2 = 1293536941;
                }
            } while (--n7 > 0);
        }
        vMeth_check_sum += l + (long)n + (long)n2 + (long)n10 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum((Object[][])nArray) + FuzzerUtils.checkSum((Object[][])byArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public void mainTest(String[] stringArray) {
        float f = -1.733f;
        float[] fArray = new float[400];
        int n = 4;
        int n2 = 9;
        int n3 = -163;
        int n4 = -55476;
        int n5 = 197;
        int n6 = -128;
        int[][] nArray = new int[400][400];
        byte[] byArray = new byte[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -29);
        FuzzerUtils.init(byArray, (byte)-8);
        FuzzerUtils.init(fArray, 32.335f);
        FuzzerUtils.init(lArray, -5L);
        Test.vMeth(instanceCount);
        f *= (float)dFld;
        int[] nArray2 = nArray[(n >>> 1) % 400];
        int n7 = (n >>> 1) % 400;
        nArray2[n7] = nArray2[n7] >> n;
        sFld = (short)(sFld * (short)n);
        n <<= (int)instanceCount;
        try {
            byArray[84] = -107;
        }
        catch (UserDefinedExceptionTest userDefinedExceptionTest) {
            n2 = 1;
            block2: do {
                instanceCount += (long)n;
                instanceCount += (long)(n2 + n2);
                instanceCount >>= sFld;
                int[] nArray3 = nArray[n2 + 1];
                int n8 = n2 + 1;
                nArray3[n8] = nArray3[n8] >>> n2;
                int[] nArray4 = nArray[n2 - 1];
                int n9 = n2;
                nArray4[n9] = nArray4[n9] >> n;
                int n10 = n2;
                fArray[n10] = fArray[n10] * (float)sFld;
                for (n5 = 204; n5 > n2; --n5) {
                    n -= (int)instanceCount;
                    int[] nArray5 = nArray[n5];
                    int n11 = n2;
                    nArray5[n11] = nArray5[n11] % (n6 | 1);
                    lArray[n2 - 1] = instanceCount;
                    n4 |= 0xFFFFFFD6;
                    if (bFld) continue block2;
                }
            } while (++n2 < 123);
        }
        FuzzerUtils.out.println("f2 i17 i18 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i19 i20 i21 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i22 iArr2 byArr1 = " + n6 + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("fArr lArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld = " + sFld);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

