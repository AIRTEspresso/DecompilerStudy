/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -4896260308601194030L;
    public static volatile float fFld = -97.216f;
    public static short sFld = (short)-10287;
    public static byte byFld = (byte)-22;
    public static int[] iArrFld = new int[400];
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1() {
        double d = 100.75751;
        double d2 = -1.91412;
        int n = -3;
        int n2 = 170;
        int n3 = 14;
        int n4 = 196;
        int n5 = 0;
        float f = -71.42f;
        d *= (double)instanceCount;
        d2 -= (double)instanceCount;
        for (n = 9; n < 320; ++n) {
            for (n3 = 5; n3 > 1; n3 -= 3) {
                boolean bl = false;
                fFld *= (float)d;
                n4 >>= n4;
                if (bl) {
                    for (f = 1.0f; f < 5.0f; f += 1.0f) {
                        n4 += (int)(f * f);
                        instanceCount += (long)d2;
                        n2 += n2;
                        sFld = (short)(sFld + sFld);
                        n5 += n5;
                        n5 = byFld;
                    }
                }
                Test.iArrFld[n] = n2;
            }
        }
        long l = Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5;
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth(int n, int n2) {
        int n3 = -26135;
        int n4 = 120;
        int n5 = -72;
        int n6 = -14;
        int n7 = 15849;
        int n8 = 7573;
        int n9 = 2;
        boolean bl = true;
        double d = 0.70164;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 142960554L);
        for (n3 = 19; n3 < 384; ++n3) {
            lArray[n3 + 1] = iArrFld[n3] * Test.iMeth1() + n;
            if (bl) break;
            for (n5 = 1; n5 < 5; ++n5) {
                if (bl) {
                    try {
                        Test.iArrFld[n3 + 1] = n6 % -1322244732;
                        n6 = n5 % -54194;
                        n2 = n5 / iArrFld[n3 + 1];
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n4 = (int)((long)n4 + ((long)n5 * instanceCount + (long)n2 - (long)n));
                    n7 = (int)instanceCount;
                    n8 = 2;
                    do {
                        n4 >>= n4;
                        n = (int)instanceCount;
                        d = n9;
                        n6 = (int)instanceCount;
                    } while ((n8 -= 3) > 0);
                    continue;
                }
                instanceCount = (long)fFld;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + (bl ? 1 : 0) + n5 + n6 + n7 + n8) + Double.doubleToLongBits(d) + (long)n9 + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public long lMeth(int n, int n2) {
        int n3 = 203;
        int n4 = -202;
        int n5 = 234;
        int n6 = 33;
        int n7 = -54699;
        int n8 = 9;
        n -= Test.iMeth(n, n);
        n2 <<= sFld;
        for (n3 = 169; n3 > 7; n3 -= 3) {
            instanceCount |= (long)n2;
            instanceCount ^= (long)n4;
            for (n5 = 1; n5 < 28; ++n5) {
                for (n7 = 1; n7 < 2; ++n7) {
                    n4 &= n5;
                    instanceCount += (long)n7;
                    instanceCount += (long)n7;
                }
                n6 /= -47;
                instanceCount = n4;
                n = (int)((long)n + ((long)n5 ^ instanceCount));
            }
        }
        iArrFld[388] = iArrFld[388] * n;
        long l = n + n2 + n3 + n4 + n5 + n6 + n7 + n8;
        lMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = -29049;
        int n2 = 131;
        int n3 = -9940;
        int n4 = -13;
        n <<= (int)((float)(this.lMeth(n, n) * (long)n) - fFld);
        instanceCount += 10L;
        for (n2 = 2; n2 < 164; ++n2) {
            n3 ^= n4;
            byFld = (byte)sFld;
            n4 += 25200;
        }
        int n5 = (n3 >>> 1) % 400;
        iArrFld[n5] = iArrFld[n5] ^ (int)instanceCount;
        instanceCount = n;
        FuzzerUtils.out.println("i i23 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i25 = " + n4);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
        FuzzerUtils.out.println("Test.byFld Test.iArrFld = " + byFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 43661);
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

