/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 3032226234022873105L;
    public static float fFld = 1.207f;
    public static double dFld = 0.4622;
    public int iFld = -49138;
    public int iFld1 = 14;
    public int[] iArrFld = new int[400];
    public volatile long[] lArrFld = new long[400];
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long vMeth2_check_sum = 0L;

    public static void vMeth2(double d) {
        int n = -11;
        int n2 = -4;
        int n3 = 32;
        int n4 = -7;
        int n5 = -7;
        int n6 = -145;
        int n7 = 179;
        int n8 = 110;
        int n9 = 103;
        boolean bl = true;
        int n10 = 9273;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -32.3747);
        n = 1;
        while (++n < 177) {
            int n11 = n - 1;
            dArray[n11] = dArray[n11] - (double)n;
            n2 = 1;
            do {
                fFld -= (float)n2;
                for (n3 = 1; 1 < n3; --n3) {
                    n9 = (byte)(n9 + (byte)instanceCount);
                    fFld = n3;
                    instanceCount += (long)n3;
                    instanceCount -= -123L;
                }
                if (!bl) continue;
            } while (++n2 < 9);
        }
        for (n5 = 6; n5 < 189; ++n5) {
            instanceCount *= (long)d;
            for (n7 = 1; n7 < 9; ++n7) {
                n10 = (short)instanceCount;
            }
        }
        vMeth2_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n9 + (long)(bl ? 1 : 0) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n10 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth1(int n) {
        int n2 = -32591;
        int n3 = -4;
        int n4 = 96;
        int n5 = 32;
        int n6 = 24;
        int n7 = -248;
        int[] nArray = new int[400];
        float f = -122.842f;
        float[] fArray = new float[400];
        double d = -2.94347;
        int n8 = 31877;
        FuzzerUtils.init(nArray, 197);
        FuzzerUtils.init(fArray, 4.473f);
        for (n2 = 1; n2 < 180; ++n2) {
            for (n4 = 1; n4 < 9; ++n4) {
                float f2 = f;
                f = f2 + 1.0f;
                instanceCount = (long)((float)(-16757 / ((n5 /= (int)(instanceCount | 1L)) | 1)) + -f2);
                n3 |= (int)(-((long)n4 % ((long)d | 1L) - (long)n8));
                Test.vMeth2(119.124321);
                d = n;
            }
            n3 = 90;
            for (n6 = 1; 9 > n6; ++n6) {
                n += n6;
            }
            instanceCount += (long)(n2 * n7 + n7 - n2);
            fArray[n2 - 1] = n5;
            fFld -= (float)n6;
            nArray[n2 + 1] = (int)d;
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n8 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth(short s, int n) {
        float f = -80.315f;
        int n2 = 11869;
        int n3 = 14;
        int n4 = 14;
        int n5 = -32022;
        int n6 = -28666;
        int n7 = -207;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 1);
        Test.vMeth1(n);
        fFld *= fFld;
        block5: for (f = 4.0f; f < 197.0f; f += 1.0f) {
            --n2;
            s = (short)(s + (short)f);
            n3 = 8;
            do {
                n2 *= (int)f;
            } while ((n3 -= 2) > 0);
            switch ((int)(f % 4.0f + 35.0f)) {
                case 35: 
                case 36: {
                    for (n4 = (int)f; n4 < 8; ++n4) {
                        int n8 = n4;
                        nArray[n8] = nArray[n8] - n;
                        n2 += (int)f;
                        instanceCount = -42617L;
                        for (n6 = 1; n6 > 1; n6 -= 2) {
                            n7 = (int)instanceCount;
                            n5 -= n2;
                        }
                    }
                    continue block5;
                }
                case 37: {
                    n = 1;
                    continue block5;
                }
                case 38: {
                    n7 *= (int)fFld;
                }
                default: {
                    int n9 = (int)f;
                    nArray[n9] = nArray[n9] + n6;
                }
            }
        }
        vMeth_check_sum += (long)(s + n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -139;
        int n2 = 11;
        int n3 = 75;
        int n4 = -211;
        int n5 = 152;
        int n6 = 53797;
        int n7 = 8;
        int n8 = 185;
        int n9 = -35606;
        int n10 = 220;
        int n11 = 24813;
        int n12 = -144;
        int n13 = 105;
        int n14 = -18;
        int n15 = -6786;
        boolean bl = false;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -2.482f);
        Test.vMeth((short)24513, n);
        switch ((n >>> 1) % 10 * 5 + 88) {
            case 110: {
                for (n2 = 1; n2 < 378; ++n2) {
                    for (n4 = 67; n2 < n4; --n4) {
                        n5 *= 25632;
                        for (n6 = 1; n6 < 1; ++n6) {
                            int n16 = n6;
                            fArray[n16] = fArray[n16] * (float)n3;
                            n7 >>= n14;
                            this.iArrFld[n2 + 1] = n8;
                            fFld += (float)instanceCount;
                            n3 += n6 | n3;
                        }
                        instanceCount -= (long)n;
                        n8 += (int)dFld;
                    }
                    dFld += 54190.0;
                    if (bl) {
                        for (n9 = 2; 67 > n9; ++n9) {
                            n11 = 1;
                            do {
                                this.iArrFld[n11] = (int)dFld;
                                fFld += (float)n15;
                                n = n4;
                                instanceCount += (long)n11;
                            } while (++n11 < 2);
                            n5 -= n8;
                            this.lArrFld[n9] = 120L;
                            n10 = 44;
                            instanceCount += 23L + (long)(n9 * n9);
                            for (n12 = 2; 1 < n12; n12 -= 2) {
                                n5 = this.iFld;
                            }
                            instanceCount = n13;
                        }
                        continue;
                    }
                    instanceCount *= instanceCount;
                }
                break;
            }
            case 93: {
                n15 = (short)(n15 * (short)n13);
            }
            case 125: {
                instanceCount *= (long)n12;
                break;
            }
            case 119: {
                this.lArrFld[(this.iFld >>> 1) % 400] = 77L;
                break;
            }
            case 96: 
            case 98: 
            case 136: {
                n10 = n3;
            }
            case 104: {
                n3 = (int)instanceCount;
            }
            case 97: {
                n3 <<= n10;
                break;
            }
            case 101: {
                n3 <<= -12;
                break;
            }
            default: {
                n7 += n;
            }
        }
        FuzzerUtils.out.println("i22 i23 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i25 i26 i27 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i28 by1 i29 = " + n7 + "," + n14 + "," + n8);
        FuzzerUtils.out.println("i30 i31 i32 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("s3 i33 i34 = " + n15 + "," + n12 + "," + n13);
        FuzzerUtils.out.println("b1 fArr1 = " + (bl ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("iFld iFld1 iArrFld = " + this.iFld + "," + this.iFld1 + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

