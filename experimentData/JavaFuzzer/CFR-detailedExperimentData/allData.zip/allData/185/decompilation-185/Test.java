/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -7508667705143825334L;
    public static boolean bFld = false;
    public static float fFld = 0.493f;
    public static byte byFld = (byte)122;
    public static volatile double dFld = -111.16741;
    public int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long[] lArrFld = new long[400];
    public volatile short[][] sArrFld = new short[400][400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long fMeth_check_sum;

    public static float fMeth(long l, int n) {
        double d = -1.8347;
        int n2 = 7;
        int n3 = 1;
        int n4 = 5;
        int n5 = 11;
        int n6 = 24803;
        d -= 2265.0;
        n = (int)l;
        for (n2 = 10; n2 < 331; ++n2) {
            n *= n;
            n6 = (short)l;
            Test.lArrFld[n2] = n2;
            n3 *= n3;
            if (bFld) continue;
            for (n4 = 1; n4 < 5; ++n4) {
                n3 = n;
            }
            n3 = (int)(fFld -= (float)byFld);
            d = n5;
        }
        long l2 = l + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n6 + (long)n4 + (long)n5;
        fMeth_check_sum += l2;
        return l2;
    }

    public static void vMeth(int n) {
        int n2 = 35427;
        int n3 = 53006;
        int n4 = -19049;
        int n5 = 38056;
        int n6 = 3;
        int n7 = -60282;
        int n8 = -11;
        int n9 = 17629;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        n = (int)(fArrFld[(n >>> 1) % 400] + ((float)(instanceCount * instanceCount) + Test.fMeth(114L, n)));
        for (n2 = 7; n2 < 321; ++n2) {
            for (n4 = n2; n4 < 5; ++n4) {
                n5 *= n4;
                int n10 = n2 - 1;
                fArrFld[n10] = fArrFld[n10] - -3.26008576E9f;
            }
            int n11 = n2 - 1;
            fArrFld[n11] = fArrFld[n11] * (float)n4;
            byFld = (byte)(byFld + (byte)((long)(n2 * n) + instanceCount - (long)n4));
            for (n6 = 1; n6 < 5; ++n6) {
                n8 = 1;
                block12: while (++n8 < 2) {
                    n5 += n8 + n8;
                    switch (n6 % 7 * 5 + 60) {
                        case 69: {
                            n3 = -1618743523;
                            continue block12;
                        }
                        case 87: {
                            if (bFld) continue block12;
                            vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9) + FuzzerUtils.checkSum(blArray);
                            return;
                        }
                        case 80: {
                            n += (int)instanceCount;
                            continue block12;
                        }
                        case 88: {
                            instanceCount <<= n8;
                            continue block12;
                        }
                        case 68: {
                            fFld += -187.0f;
                            continue block12;
                        }
                        case 75: {
                            blArray[n8] = bFld;
                            continue block12;
                        }
                        case 66: {
                            dFld -= (double)n2;
                        }
                    }
                    dFld -= -14.0;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9) + FuzzerUtils.checkSum(blArray);
    }

    public static int iMeth(boolean bl, int n, int n2) {
        int n3 = -1;
        int n4 = 4;
        int n5 = -132;
        int n6 = -1407;
        int[][][] nArray = new int[400][400][400];
        FuzzerUtils.init((Object[][])nArray, (Object)-51563);
        Test.vMeth(n);
        for (float f : fArrFld) {
            dFld = instanceCount;
            fFld -= (float)n2;
            instanceCount -= instanceCount;
            n2 = n;
            n2 = 0;
        }
        for (n3 = 4; n3 < 392; ++n3) {
            n5 = 4;
            block7: while (--n5 > 0) {
                switch (6) {
                    case 4: 
                    case 5: {
                        fFld += (float)dFld;
                        continue block7;
                    }
                    case 6: {
                        nArray[n3 - 1][n3 - 1][n5] = (int)instanceCount;
                        continue block7;
                    }
                    case 7: {
                        n6 = 1;
                        do {
                            n2 = n6;
                        } while ((n6 -= 3) > 0);
                        n2 >>= 19737;
                        continue block7;
                    }
                }
                nArray[n5][n3][n5 - 1] = 40945;
            }
        }
        long l = (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum((Object[][])nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -6;
        int n2 = 9;
        int n3 = 251;
        int n4 = -2;
        int n5 = -4;
        float f = 0.16f;
        long l = -3L;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)-101);
        this.iArrFld[43] = this.iArrFld[43] >> Test.iMeth(bFld, n, n);
        lArrFld[5] = lArrFld[5] + (long)n;
        n += n;
        for (int n6 : this.iArrFld) {
            for (n2 = 63; n2 > 1; n2 -= 2) {
                n6 %= n6 | 1;
                n6 -= 82;
                int n7 = n2 + 1;
                byArray[n7] = (byte)(byArray[n7] - byFld);
                instanceCount *= (long)n3;
                for (f = 1.0f; f < 3.0f; f += 1.0f) {
                    n6 *= n4;
                    n4 -= n2;
                }
                l = 1L;
                do {
                    switch ((int)(l % 4L * 5L + 71L)) {
                        case 84: {
                            if (bFld) {
                                n += (int)l;
                                short[] sArray = this.sArrFld[(int)(l + 1L)];
                                int n8 = n2;
                                sArray[n8] = (short)(sArray[n8] * (short)n2);
                                n += (int)l;
                            }
                            n3 -= n2;
                            int n9 = (int)l;
                            lArrFld[n9] = lArrFld[n9] + (long)n2;
                            n5 = -191;
                            break;
                        }
                        case 82: {
                            n6 *= n5;
                            instanceCount = n4;
                            fFld = -37624.0f;
                            break;
                        }
                        case 89: {
                            n += (int)(l * l);
                            int n10 = (int)(l - 1L);
                            this.iArrFld[n10] = this.iArrFld[n10] >>> (int)l;
                            int n11 = n2 - 1;
                            this.iArrFld[n11] = this.iArrFld[n11] + n4;
                            break;
                        }
                        case 85: {
                            fFld += (float)l;
                            break;
                        }
                        default: {
                            instanceCount *= (long)n2;
                        }
                    }
                } while (++l < 3L);
            }
        }
        FuzzerUtils.out.println("i20 i22 i23 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f1 i24 l1 = " + Float.floatToIntBits(f) + "," + n4 + "," + l);
        FuzzerUtils.out.println("i25 byArr = " + n5 + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.byFld Test.dFld iArrFld = " + byFld + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.fArrFld Test.lArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 111.209f);
        FuzzerUtils.init(lArrFld, -293861417053480438L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
    }
}

