/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -32298L;
    public static float fFld = 1.78f;
    public static float[][] fArrFld = new float[400][400];
    public static short[] sArrFld = new short[400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long lMeth1_check_sum;

    public static long lMeth1(int n) {
        double d = -1.1255;
        int n2 = -4;
        int n3 = 1665;
        int n4 = 29681;
        int[] nArray = new int[400];
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        int n5 = -9717;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, 1178025789L);
        FuzzerUtils.init(nArray, -40446);
        FuzzerUtils.init(blArray, true);
        for (d = 382.0; d > 8.0; d -= 2.0) {
            if (bl) {
                lArray[(int)d][(int)(d + 1.0)] = n;
                instanceCount -= 8173192795504588315L;
            } else {
                n2 += (int)(d * (double)n2 + (double)n - (double)n2);
            }
            n2 -= (n -= 2);
            nArray = FuzzerUtils.int1array(400, 62);
            block10: for (n3 = 1; n3 < 9; ++n3) {
                blArray[(int)(d + 1.0)] = true;
                switch ((int)(d % 8.0 * 5.0 + 39.0)) {
                    case 50: {
                        n4 = (int)d;
                        continue block10;
                    }
                    case 67: {
                        n += 174;
                        continue block10;
                    }
                    case 45: 
                    case 56: {
                        n5 = (short)(n5 + 16667);
                        continue block10;
                    }
                    case 75: {
                        instanceCount -= instanceCount;
                        continue block10;
                    }
                    case 51: {
                        n <<= (int)instanceCount;
                        continue block10;
                    }
                    case 44: {
                        n4 = (int)((float)n4 + ((float)(n3 * n4) + fFld - (float)n3));
                    }
                    case 49: {
                        nArray[n3] = (int)instanceCount;
                    }
                }
            }
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)(bl ? 1 : 0) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
        lMeth1_check_sum += l;
        return l;
    }

    public static long lMeth() {
        int n = 55977;
        int n2 = 100;
        int n3 = -104;
        int n4 = 1;
        int n5 = -7;
        int n6 = -7;
        int[] nArray = new int[400];
        int n7 = -91;
        boolean bl = true;
        FuzzerUtils.init(nArray, -13);
        n = 1;
        do {
            for (n2 = 1; n2 < 7; ++n2) {
                int n8 = n;
                sArrFld[n8] = (short)(sArrFld[n8] + (short)instanceCount);
                for (n4 = 1; 2 > n4; ++n4) {
                    n5 = (int)instanceCount;
                    n7 = (byte)(n7 + (byte)(n4 * n + n5 - n3));
                    instanceCount = n2;
                    n3 = n5;
                    n5 -= n4;
                    if (!bl) continue;
                }
                nArray[n] = n4;
                n5 = n6;
                bl = true;
            }
        } while (++n < 221);
        long l = (long)(n + n2 + n3 + n4 + n5 + n7 + (bl ? 1 : 0) + n6) + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth(int n, int n2, double d) {
        int n3 = -6061;
        int n4 = -2;
        int[] nArray = new int[400];
        boolean bl = true;
        int n5 = -108;
        FuzzerUtils.init(nArray, -179);
        for (n3 = 248; 7 < n3; --n3) {
            n2 = n4 = (n <<= (int)(-(Math.abs(instanceCount) + -8L * Test.lMeth())));
            n2 = -2083620938;
            if (n3 != 0) {
                vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5 + FuzzerUtils.checkSum(nArray);
                return;
            }
            n2 -= (int)fFld;
            n2 ^= (int)instanceCount;
            n2 -= 5007;
            if (bl) {
                switch (59) {
                    case 59: {
                        nArray[n3 + 1] = (int)(instanceCount %= (long)fFld | 1L);
                        n *= n4;
                        float[] fArray = fArrFld[n3 - 1];
                        int n6 = n3;
                        fArray[n6] = fArray[n6] / (float)(n2 | 1);
                    }
                    case 60: {
                        n4 = (int)d;
                    }
                }
                continue;
            }
            fFld += (float)n5;
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -178;
        int n2 = 35940;
        int n3 = -31163;
        int n4 = 212;
        int n5 = -41705;
        int n6 = 60665;
        int n7 = 11;
        int[] nArray = new int[400];
        double d = 0.10765;
        int n8 = 7489;
        long l = -241L;
        FuzzerUtils.init(nArray, -14);
        int n9 = (n >>> 1) % 400;
        instanceCount = (long)((d - -4121.0) * 65379.0);
        nArray[n9] = nArray[n9] + (int)instanceCount;
        switch (((int)(instanceCount - 11000L) >>> 1) % 2 * 5 + 43) {
            case 48: {
                int n10 = n >>= (int)instanceCount;
                float[] fArray = fArrFld[(n >>> 1) % 400];
                float f = fArray[0] + 1.0f;
                fArray[0] = f;
                ++n;
                n = n10 << (int)(f + (float)(instanceCount - (long)n));
                Test.vMeth(n, n, d);
                for (int n11 : nArray) {
                    instanceCount -= -154L;
                    for (n2 = 3; n2 < 63; ++n2) {
                        n8 = (short)(n8 << (short)n11);
                        int n12 = n2;
                        nArray[n12] = nArray[n12] >> (int)(instanceCount += (long)(n2 * n2));
                        fFld += (float)(n2 * n) + fFld - (float)n2;
                        n3 = 53684;
                        n = (int)d;
                        n3 <<= (int)instanceCount;
                    }
                    nArray[(n2 >>> 1) % 400] = n2;
                    for (n4 = 3; n4 < 63; ++n4) {
                        n11 += n5;
                        n3 += n4 + n3;
                        for (n6 = n4; n6 < 2; ++n6) {
                            ++n;
                            n7 = 35;
                            fFld = n11;
                            switch (n4 % 2 * 5 + 98) {
                                case 101: 
                                case 102: {
                                    n7 += n;
                                    n7 *= (int)l;
                                    n11 += n6 ^ n11;
                                    n7 = n;
                                }
                            }
                            int n13 = n4;
                            nArray[n13] = nArray[n13] << (int)l;
                        }
                    }
                }
                break;
            }
            case 50: {
                break;
            }
            default: {
                n5 -= n5;
            }
        }
        FuzzerUtils.out.println("i d i16 = " + n + "," + Double.doubleToLongBits(d) + "," + n2);
        FuzzerUtils.out.println("i17 s1 i18 = " + n3 + "," + n8 + "," + n4);
        FuzzerUtils.out.println("i19 i20 i21 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("l iArr = " + l + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.fArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 1.816f);
        FuzzerUtils.init(sArrFld, (short)18506);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        lMeth1_check_sum = 0L;
    }
}

