/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -20946L;
    public static int iFld = 3;
    public boolean bFld = false;
    public static long lFld = 125L;
    public static int[] iArrFld = new int[400];
    public static long lMeth_check_sum;
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static long lMeth(int n) {
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 182);
        nArray[67] = nArray[67] >> (int)instanceCount;
        long l = (long)n + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth1(int n, int n2) {
        int n3 = -44967;
        int n4 = 2;
        int n5 = -4;
        int n6 = 1;
        int n7 = -150;
        int n8 = -3;
        int n9 = -40438;
        int[] nArray = new int[400];
        long l = 0L;
        float f = -127.634f;
        double d = 0.2123;
        int n10 = 2548;
        short[] sArray = new short[400];
        FuzzerUtils.init(nArray, -12);
        FuzzerUtils.init(sArray, (short)15552);
        for (n3 = 10; n3 < 179; ++n3) {
            for (l = (long)n3; 9L > l; ++l) {
                f = n3;
            }
            for (n6 = 1; n6 < 9; ++n6) {
                n8 = 1;
                while (++n8 < 2) {
                    nArray[n6] = (int)l;
                    d -= (double)l;
                }
                int n11 = n3 - 1;
                sArray[n11] = (short)(sArray[n11] * (short)l);
                n9 = 1;
                while (++n9 < 2) {
                    instanceCount -= instanceCount;
                    n += (int)f;
                }
                n2 *= n10;
                n = -216;
                int n12 = n3 - 1;
                nArray[n12] = nArray[n12] * (int)l;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4) + l + (long)n5 + (long)Float.floatToIntBits(f) + (long)n6 + (long)n7 + (long)n8 + Double.doubleToLongBits(d) + (long)n9 + (long)n10 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(sArray);
    }

    public static void vMeth(int n, int n2, int n3) {
        int n4 = -5;
        int n5 = 214;
        int n6 = -54274;
        int n7 = 0;
        int n8 = -7;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -190);
        Test.vMeth1(iFld, n2);
        n = n3;
        n4 = 1;
        while (++n4 < 352) {
            for (n5 = 1; n5 < 5; ++n5) {
                n7 = 1;
                do {
                    boolean bl = false;
                    int n9 = n7;
                    nArray[n9] = nArray[n9] - (int)instanceCount;
                    if (bl) {
                        instanceCount = iFld;
                        instanceCount = iFld;
                        if (n6 != 0) {
                            vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(nArray);
                            return;
                        }
                        iFld = (int)instanceCount;
                        continue;
                    }
                    if (bl) {
                        try {
                            n8 = n / n5;
                            n8 = n7 % -52543;
                            n2 = 20406 % n7;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                        if (n != 0) {
                            vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(nArray);
                            return;
                        }
                        iFld = n8;
                        continue;
                    }
                    n8 += n7 * n4 + n7 - n8;
                } while (++n7 < 2);
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(nArray);
    }

    public static boolean bMeth(int n, long l, long l2) {
        int n2 = 36264;
        int n3 = -166;
        int n4 = -38507;
        int n5 = -14;
        float f = 0.373f;
        int n6 = -23543;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 83L);
        n2 = 1;
        do {
            Test.vMeth(iFld, 179, 125);
            try {
                n = -45456 / n;
                n = n2 / 11925;
                iFld = 195 % iFld;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n /= (int)((long)f | 1L);
            n3 = 1;
            if (n3 >= 11) continue;
            double d = -1.71475;
            f += (float)n5;
            iFld %= n6 | 1;
            n5 *= n4;
        } while (++n2 < 137);
        long l3 = (long)n + l + l2 + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(lArray);
        bMeth_check_sum += l3;
        return l3 % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        float f = 2.274f;
        float f2 = -51.605f;
        float f3 = -124.129f;
        int n = 4863;
        int n2 = 0;
        int n3 = -70;
        int n4 = -6;
        int n5 = -20928;
        int n6 = -59152;
        int n7 = -230;
        double d = 0.6727;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, true);
        f = 1.0f;
        while (!Test.bMeth(iFld = (int)Test.lMeth(iFld), -4L, instanceCount)) {
            iFld -= (int)f;
            n = 1;
            while (++n < 194 && !this.bFld) {
                f2 += (float)(n * n + iFld - iFld);
                for (n2 = 1; 1 > n2; ++n2) {
                    f2 *= (float)n3;
                    n3 += n2;
                    n3 = (int)((long)n3 + ((long)n2 | instanceCount));
                }
                n4 = 1;
                do {
                    n3 += n4 * n2 + n3 - iFld;
                    if (this.bFld) continue;
                    d = n2;
                    instanceCount += (long)n3;
                    Test.iArrFld[n + 1] = n3;
                } while (++n4 < 1);
            }
            try {
                n3 = iFld / 55378;
                iFld = 240 / n;
                n3 = -1105412431 / n3;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            instanceCount = n2;
            instanceCount = n;
            instanceCount -= 30933L;
            blArray[(int)(f + 1.0f)] = this.bFld;
            lFld = n3;
            if ((f += 1.0f) < 129.0f) continue;
        }
        iFld += 99;
        for (n5 = 167; 5 < n5; --n5) {
            n6 = n3;
            int n8 = n5 + 1;
            iArrFld[n8] = iArrFld[n8] >> n4;
            n7 = 155;
            do {
                instanceCount += (long)n4;
            } while (--n7 > 0);
            f2 += (float)(n5 * n2) + f3 - (float)n7;
        }
        FuzzerUtils.out.println("f i23 f3 = " + Float.floatToIntBits(f) + "," + n + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("i24 i25 i26 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("d2 i27 i28 = " + Double.doubleToLongBits(d) + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i29 f4 bArr = " + n7 + "," + Float.floatToIntBits(f3) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld bFld = " + instanceCount + "," + iFld + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.lFld Test.iArrFld = " + lFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -36523);
        lMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

