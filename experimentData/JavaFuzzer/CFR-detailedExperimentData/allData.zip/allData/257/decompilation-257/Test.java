/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 45803L;
    public static int iFld = 34175;
    public byte byFld = (byte)-110;
    public volatile double dFld = 0.74703;
    public boolean bFld = false;
    public volatile short sFld = (short)-2749;
    public int iFld1 = -11;
    public static int[] iArrFld = new int[400];
    public long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        float f = -37.791f;
        float f2 = -1.832f;
        double d = 79.95961;
        int n2 = 50303;
        int n3 = 1;
        int n4 = 64321;
        int n5 = -231;
        boolean bl = true;
        f = 219.0f;
        while (true) {
            float f3;
            f -= 2.0f;
            if (!(f3 > 0.0f)) break;
            d += (double)instanceCount;
            n2 = 1;
            while (n2 < 14) {
                Test.iArrFld[(int)f] = n;
                n += n;
                bl = false;
                n3 %= (int)(instanceCount | 1L);
                n <<= iFld;
                n3 = n2++;
            }
            if (bl) continue;
            f2 += 62.205f;
            int n6 = (int)f;
            iArrFld[n6] = iArrFld[n6] / -1140288642;
        }
        for (n4 = 9; n4 < 364; ++n4) {
            try {
                n5 = 255 / n4;
                iFld = -1069863247 / n5;
                n = -136820661 % n2;
                continue;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        }
        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f2) + (long)n4 + (long)n5;
    }

    public static long lMeth(byte by) {
        Test.vMeth1(142);
        long l = by;
        lMeth_check_sum += l;
        return l;
    }

    public void vMeth(int n, int n2, byte by) {
        double d = 2.95095;
        int n3 = -9;
        int n4 = -11469;
        int n5 = 0;
        int n6 = 160;
        int n7 = 5;
        int n8 = -68;
        float f = -20.621f;
        int n9 = (n2 >>> 1) % 400;
        int n10 = (n >>> 1) % 400;
        long l = this.lArrFld[n10];
        this.lArrFld[n10] = l - 1L;
        iArrFld[n9] = iArrFld[n9] - (int)((long)Integer.reverseBytes(53530 >> (int)l) * (Test.lMeth((byte)-89) * 1507375961L));
        d = instanceCount;
        for (n3 = 6; n3 < 320; ++n3) {
            int n11 = n3 - 1;
            iArrFld[n11] = iArrFld[n11] - (int)f;
            block7: for (n5 = 1; n5 < 5; ++n5) {
                n6 |= n6;
                switch (n3 % 4 + 43) {
                    case 43: {
                        for (n7 = 1; n7 < 2; ++n7) {
                            n = (int)((long)n + ((long)n7 * instanceCount + (long)n8 - (long)n));
                            n6 = 7;
                            iFld = n4 -= n8;
                            d = n8;
                            int n12 = n5;
                            this.lArrFld[n12] = this.lArrFld[n12] - (long)n2;
                            f -= f;
                        }
                        continue block7;
                    }
                    case 44: {
                        n2 += -7985 + n5 * n5;
                        continue block7;
                    }
                    case 45: {
                        instanceCount += (long)n5;
                        continue block7;
                    }
                    case 46: {
                        n6 -= n;
                    }
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + by) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + (long)n8;
    }

    public void mainTest(String[] stringArray) {
        int n = -235;
        int n2 = 5;
        int n3 = 10925;
        int n4 = -49468;
        int n5 = 229;
        int n6 = -116;
        int n7 = -135;
        int n8 = -50606;
        int n9 = -3;
        float f = 0.249f;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)5);
        block70: for (n = 8; n < 317; ++n) {
            instanceCount = n;
            n2 = (int)(-Math.abs(instanceCount));
            switch (n + 51) {
                case 51: {
                    this.vMeth(n2, n2, this.byFld);
                    continue block70;
                }
                case 52: {
                    n2 += n + n2;
                    n3 = n;
                    if (n3 < 81) {
                        n5 = 1;
                        while (n5 < 1) {
                            int n10 = n5++;
                            iArrFld[n10] = iArrFld[n10] - (int)f;
                            n4 += (int)this.dFld;
                            n2 >>>= 269236742;
                            n2 ^= iFld;
                            n4 += 0;
                            n4 = n3;
                        }
                    }
                }
                case 53: {
                    f = instanceCount;
                }
                case 54: {
                    instanceCount = n5;
                    continue block70;
                }
                case 55: {
                    continue block70;
                }
                case 56: {
                    n8 += n;
                }
                case 57: 
                case 58: 
                case 59: {
                    n6 *= (int)instanceCount;
                    continue block70;
                }
                case 60: {
                    n6 -= 30;
                }
                case 61: {
                    iFld <<= (int)instanceCount;
                    continue block70;
                }
                case 62: {
                    this.dFld = instanceCount;
                    continue block70;
                }
                case 63: {
                    f = n9;
                }
                case 64: {
                    instanceCount -= -24581L;
                }
                case 65: {
                    n6 = n2;
                }
                case 66: {
                    n6 = n9;
                }
                case 67: {
                    try {
                        n8 = -49751630 % iFld;
                        n4 = n7 % n8;
                        n2 = -239 / n3;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    continue block70;
                }
                case 68: {
                    this.bFld = this.bFld;
                    continue block70;
                }
                case 69: {
                    n2 >>= n6;
                }
                case 70: {
                    f = n5;
                    continue block70;
                }
                case 71: {
                    int n11 = n;
                    iArrFld[n11] = iArrFld[n11] - 9;
                }
                case 72: {
                    f += -13.0f;
                    continue block70;
                }
                case 73: {
                    if (!this.bFld) continue block70;
                    continue block70;
                }
                case 74: {
                    n6 = (int)this.dFld;
                    continue block70;
                }
                case 75: {
                    continue block70;
                }
                case 76: {
                    n4 -= n5;
                    continue block70;
                }
                case 77: {
                    n6 += n4;
                    continue block70;
                }
                case 78: {
                    n2 -= 12;
                    continue block70;
                }
                case 79: {
                    n8 *= this.sFld;
                    continue block70;
                }
                case 80: {
                    n4 <<= n2;
                }
                case 81: {
                    n8 >>= n;
                    continue block70;
                }
                case 82: {
                    f += (float)((long)(n * n8 + n7) - instanceCount);
                    continue block70;
                }
                case 83: {
                    this.byFld = (byte)(this.byFld << (byte)n6);
                }
                case 84: {
                    n6 >>= 61865;
                    continue block70;
                }
                case 85: {
                    n8 += 800768368;
                }
                case 86: {
                    f += (float)iFld;
                    continue block70;
                }
                case 87: {
                    this.bFld = this.bFld;
                }
                case 88: {
                    this.dFld -= (double)instanceCount;
                    continue block70;
                }
                case 89: {
                    this.sFld = (short)(this.sFld + (short)(n * n));
                    continue block70;
                }
                case 90: {
                    n2 += n * n;
                    continue block70;
                }
                case 91: {
                    n4 += this.sFld;
                    continue block70;
                }
                case 92: {
                    this.lArrFld = FuzzerUtils.long1array(400, 9169L);
                    continue block70;
                }
                case 93: {
                    if (!this.bFld) continue block70;
                    continue block70;
                }
                case 94: {
                    this.sFld = (short)(this.sFld - 31910);
                    continue block70;
                }
                case 95: {
                    int n12 = n - 1;
                    iArrFld[n12] = iArrFld[n12] >>> (int)instanceCount;
                    continue block70;
                }
                case 96: {
                    if (!this.bFld) continue block70;
                    continue block70;
                }
                case 97: 
                case 98: {
                    n4 *= n7;
                    continue block70;
                }
                case 99: {
                    n4 = (int)((long)n4 + ((long)n * instanceCount + (long)n3 - (long)n));
                }
                case 100: {
                    this.byFld = (byte)(this.byFld + (byte)((float)n * f + (float)this.byFld - (float)n5));
                    continue block70;
                }
                case 101: {
                    n8 -= 36639;
                    continue block70;
                }
                case 102: {
                    iFld %= 1;
                    continue block70;
                }
                case 103: {
                    instanceCount += (long)n6;
                }
                case 104: {
                    f = (float)this.dFld;
                }
                case 105: {
                    instanceCount += (long)(n - iFld);
                    continue block70;
                }
                case 106: {
                    this.byFld = (byte)n9;
                }
                case 107: {
                    iFld >>= n8;
                }
                case 108: {
                    instanceCount = n7;
                }
                case 109: {
                    this.dFld += (double)n9;
                }
                case 110: {
                    n2 = n;
                    continue block70;
                }
                case 111: {
                    n6 = n9;
                    continue block70;
                }
                case 112: {
                    this.iFld1 >>>= n5;
                    continue block70;
                }
                case 113: {
                    instanceCount >>>= (int)instanceCount;
                    continue block70;
                }
                case 114: {
                    n4 = (int)((float)n4 + ((float)n * f + (float)n7 - (float)n7));
                    continue block70;
                }
                case 115: {
                    instanceCount += (long)n;
                    continue block70;
                }
                case 116: 
                case 117: {
                    this.iFld1 *= 1;
                    continue block70;
                }
                case 118: {
                    n8 *= (int)this.dFld;
                    continue block70;
                }
                case 119: {
                    n2 <<= n3;
                    continue block70;
                }
                case 120: {
                    n4 &= 0xFFFFFFF2;
                    continue block70;
                }
                default: {
                    Test.iArrFld[n + 1] = n6;
                }
            }
        }
        FuzzerUtils.out.println("i i1 i15 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i16 i17 i18 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f3 i19 i20 = " + Float.floatToIntBits(f) + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i21 byArr = " + n9 + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld byFld = " + instanceCount + "," + iFld + "," + this.byFld);
        FuzzerUtils.out.println("dFld bFld sFld = " + Double.doubleToLongBits(this.dFld) + "," + (this.bFld ? 1 : 0) + "," + this.sFld);
        FuzzerUtils.out.println("iFld1 Test.iArrFld lArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 2);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

