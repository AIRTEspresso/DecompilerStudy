/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 55909L;
    public volatile byte byFld = (byte)21;
    public static boolean bFld = true;
    public double dFld = -1.87946;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(float f, boolean bl) {
        int n = -12;
        int n2 = 30000;
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + (bl ? 1 : 0) + (n -= n2) + n2);
    }

    /*
     * Unable to fully structure code
     */
    public static boolean bMeth() {
        var0 = 205;
        var1_1 = -10;
        var2_2 = -4;
        var3_3 = 11;
        var4_4 = 1.889f;
        var5_5 = new float[400];
        var6_6 = false;
        var7_7 = -1.113372;
        var9_8 = -2.122995;
        var11_9 = -14312;
        FuzzerUtils.init(var5_5, 4.362f);
        for (var0 = 217; var0 > 4; --var0) {
            Test.vMeth(var4_4, var6_6);
            Test.instanceCount += (long)(var0 * (var1_1 += var0) + var0 - var1_1);
            var1_1 += 119;
            v0 = var0 - 1;
            Test.iArrFld[v0] = Test.iArrFld[v0] + (int)Test.instanceCount;
        }
        var1_1 = (int)Test.instanceCount;
        switch ((var0 >>> 1) % 10 + 18) {
            case 18: {
                Test.iArrFld[5] = Test.iArrFld[5] % (int)(Test.instanceCount | 1L);
                var7_7 = 1.0;
                do {
                    var12_10 = -2.34221;
                    var12_10 = var0;
                    for (var2_2 = 1; var2_2 < 7; ++var2_2) {
                        Test.instanceCount <<= var0;
                        var1_1 *= var11_9;
                    }
                } while ((var7_7 += 1.0) < 215.0);
            }
            case 19: {
                var4_4 += (float)Test.instanceCount;
                break;
            }
            case 20: {
                var1_1 += var0;
            }
            case 21: {
                var9_8 *= (double)Test.instanceCount;
                break;
            }
            ** case 22:
            ** case 23:
lbl41:
            // 2 sources

            case 24: {
                var1_1 += (int)Test.instanceCount;
            }
            case 25: 
            case 26: {
                var9_8 -= (double)Test.instanceCount;
            }
            case 27: {
                var3_3 += 53102;
                break;
            }
            default: {
                var5_5[(var2_2 >>> 1) % 400] = Test.instanceCount;
            }
        }
        var12_11 = (long)(var0 + var1_1 + Float.floatToIntBits(var4_4) + (var6_6 != false ? 1 : 0)) + Double.doubleToLongBits(var7_7) + (long)var2_2 + (long)var3_3 + (long)var11_9 + Double.doubleToLongBits(var9_8) + Double.doubleToLongBits(FuzzerUtils.checkSum(var5_5));
        Test.bMeth_check_sum += var12_11;
        return var12_11 % 2L > 0L;
    }

    public int iMeth(int n) {
        double d = 2.47596;
        int n2 = 41874;
        int n3 = -5;
        int n4 = -3;
        int n5 = 14;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -3609588869374174902L);
        long l = (long)iArrFld[(n >>> 1) % 400] * ((long)n * instanceCount);
        long l2 = instanceCount - 1L;
        instanceCount = l2;
        instanceCount = l2;
        instanceCount = l + l2;
        for (d = 10.0; d < 164.0; d += 1.0) {
            lArray = FuzzerUtils.long2array(400, -745058389391775611L);
            long[] lArray2 = lArray[(int)d];
            int n6 = (int)(d + 1.0);
            lArray2[n6] = lArray2[n6] - (long)n2--;
            Test.bMeth();
            n -= (int)d;
            n3 = 1;
            while (++n3 < 10) {
                n += n3 - n3;
                n2 = this.byFld;
                block0 : switch ((int)(d % 10.0 * 5.0 + 116.0)) {
                    case 127: {
                        instanceCount = n2;
                        for (n4 = 1; n4 < 1; ++n4) {
                            n2 &= n;
                            n += n4 ^ n3;
                            if (bFld) break block0;
                        }
                        break;
                    }
                    case 163: {
                        instanceCount &= (long)n4;
                    }
                    case 135: {
                        this.byFld = (byte)(this.byFld + (byte)n5);
                        break;
                    }
                    case 124: 
                    case 160: {
                        n2 *= this.byFld;
                    }
                    case 121: {
                        n += n3 * n4 + n5 - n5;
                        break;
                    }
                    case 131: {
                        break;
                    }
                    case 123: {
                        n5 += n3;
                        break;
                    }
                    case 162: {
                        n5 += (int)instanceCount;
                        break;
                    }
                    case 120: {
                        n = -29;
                    }
                }
            }
        }
        long l3 = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l3;
        return (int)l3;
    }

    public void mainTest(String[] stringArray) {
        int n = -236;
        int n2 = 10;
        int n3 = -25;
        int n4 = 2;
        int n5 = 0;
        int n6 = 175;
        int n7 = -13;
        int n8 = 5;
        int n9 = -229;
        int n10 = 29903;
        int n11 = -10;
        int n12 = -14;
        float f = 0.553f;
        int n13 = 29954;
        instanceCount = this.iMeth(n);
        for (n2 = 183; n2 > 5; --n2) {
            n -= this.byFld;
        }
        for (n4 = 13; n4 < 352; ++n4) {
            this.dFld -= 209.0;
            n -= (int)f;
            bFld = false;
            for (n6 = n4; n6 < 74; ++n6) {
                n >>= -27937;
                n -= n6;
                for (n8 = 1; n8 < 1; ++n8) {
                    if (bFld) continue;
                    f += (float)n8;
                    n5 = (int)instanceCount;
                    n9 = n3;
                    if (bFld) {
                        n10 &= (int)instanceCount;
                        n3 += (int)(-34808L + (long)(n8 * n8));
                        n7 += (int)(-14L + (long)(n8 * n8));
                        n10 *= 145;
                    }
                    n3 = 2;
                    n7 += (int)this.dFld;
                }
                for (n11 = 1; 1 > n11; ++n11) {
                    instanceCount = n10;
                    instanceCount -= (long)n13;
                    if (bFld) continue;
                    n13 = (short)(n13 - (short)instanceCount);
                    instanceCount = 182L;
                }
                n3 = (int)((long)n3 + ((long)(n6 * n7) + instanceCount - (long)n3));
            }
        }
        FuzzerUtils.out.println("i10 i11 i12 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i13 i14 f2 = " + n4 + "," + n5 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i15 i16 i17 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i18 i19 i20 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("i21 s2 = " + n12 + "," + n13);
        FuzzerUtils.out.println("Test.instanceCount byFld Test.bFld = " + instanceCount + "," + this.byFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("dFld Test.iArrFld = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -64100);
        iMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

