/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -252L;
    public static int iFld = 205;
    public static short sFld = (short)32195;
    public static float fFld = -65.822f;
    public byte byFld = (byte)97;
    public volatile int iFld1 = 95;
    public static double[] dArrFld = new double[400];
    public static float[][] fArrFld = new float[400][400];
    public static boolean[] bArrFld = new boolean[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long iMeth2_check_sum;

    public static int iMeth2() {
        double d = 0.80496;
        int n = -180;
        int n2 = 87;
        int[] nArray = new int[400];
        long l = -3484110969561352279L;
        float f = 119.386f;
        boolean bl = true;
        FuzzerUtils.init(nArray, -26657);
        d = iFld;
        for (n = 10; n < 252; ++n) {
            int n3 = n - 1;
            nArray[n3] = nArray[n3] + sFld;
            n2 = 1;
            iFld -= iFld;
            l = 1L;
            do {
                f += (float)l;
                iFld = (int)l;
                n2 += (int)(l * l);
                Test.dArrFld[(int)l] = n;
                n2 = -22725;
                if (bl) continue;
                n2 += sFld;
            } while (++l < 7L);
            n2 -= 4955;
            f /= (float)((long)f | 1L);
        }
        long l2 = Double.doubleToLongBits(d) + (long)n + (long)n2 + l + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
        iMeth2_check_sum += l2;
        return (int)l2;
    }

    public static int iMeth1(float f) {
        int n = -112;
        int n2 = -67;
        int n3 = -2;
        int n4 = 64287;
        int n5 = -59583;
        int n6 = 7;
        int[] nArray = new int[400];
        boolean bl = true;
        int n7 = 115;
        FuzzerUtils.init(nArray, -10);
        iFld = Test.iMeth2();
        for (n = 4; n < 375; ++n) {
            double d = 0.64899;
            for (n3 = 1; n3 < 5; ++n3) {
                n2 -= n3;
                instanceCount *= (long)(n4 += n3);
                n4 = (int)((float)n4 + ((float)n3 - f));
            }
            iFld += n7;
            for (n5 = 1; n5 < 5; ++n5) {
                if (n != 0) {
                    // empty if block
                }
                n6 = n7;
                instanceCount = n2;
            }
            nArray[n - 1] = (int)d;
        }
        bl = true;
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + (bl ? 1 : 0) + n7 + n5 + n6) + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth(long l) {
        int n = 241;
        int n2 = 13;
        int n3 = -8726;
        int n4 = 14;
        int n5 = 44889;
        int[] nArray = new int[400];
        double d = -1.7973;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -50L);
        FuzzerUtils.init(nArray, -3);
        n = 1;
        while (++n < 221) {
            int n6 = n;
            lArray[n6] = lArray[n6] >> iFld--;
            sFld = (short)(sFld + (short)(n * n));
        }
        Test.iMeth1(124.606f);
        iFld += (int)instanceCount;
        n2 = 18;
        while (n2 < 302) {
            for (n4 = 1; n4 < 6; ++n4) {
                d += (double)n3;
                instanceCount <<= n3;
            }
            int n7 = n2++;
            nArray[n7] = nArray[n7] - 12;
        }
        nArray[(n >>> 1) % 400] = n2;
        fFld -= (float)l;
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)(n5 -= n) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        double d = 1.97296;
        int n = -12400;
        int n2 = 41;
        int n3 = 20;
        int n4 = -4;
        int n5 = -56;
        int n6 = -620;
        int n7 = -45478;
        int n8 = 4;
        int[] nArray = new int[400];
        long l = -8632283117275854122L;
        boolean bl = true;
        FuzzerUtils.init(nArray, -11);
        int n9 = (iFld >>> 1) % 400;
        double d2 = d;
        d = d2 + 1.0;
        nArray[n9] = nArray[n9] >> (int)((double)Math.max(iFld, iFld) + d2 + (double)Test.iMeth(instanceCount));
        for (n = 2; n < 179; ++n) {
            iFld = (int)instanceCount;
            for (n3 = 2; n3 < 142; ++n3) {
                sFld = (short)(sFld + (short)n3);
                Test.fArrFld[n3][n3] = n4;
                for (l = (long)n3; l < 2L; ++l) {
                    this.byFld = (byte)(this.byFld << (byte)this.iFld1);
                    if (bl || bl) continue;
                    instanceCount = (long)fFld;
                    n2 = (int)fFld;
                    n2 = 3;
                    bArrFld = FuzzerUtils.boolean1array(400, true);
                }
                instanceCount -= (long)fFld;
                int n10 = n3 - 1;
                nArray[n10] = nArray[n10] - (int)l;
                n2 -= (int)l;
                instanceCount -= -7L;
            }
            n4 <<= 159;
            for (n6 = 2; n6 < 142; ++n6) {
                n5 = 803;
                n8 = 1;
                while (++n8 < 2) {
                    n7 = this.iFld1;
                    try {
                        n4 = 87 % n3;
                        n4 = n5 % n7;
                        n7 = -201373032 % this.iFld1;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n5 = (int)(fFld -= (float)n);
                    bl = false;
                }
            }
        }
        FuzzerUtils.out.println("d i13 i14 = " + Double.doubleToLongBits(d) + "," + n + "," + n2);
        FuzzerUtils.out.println("i15 i16 l2 = " + n3 + "," + n4 + "," + l);
        FuzzerUtils.out.println("i17 b2 i18 = " + n5 + "," + (bl ? 1 : 0) + "," + n6);
        FuzzerUtils.out.println("i19 i20 iArr = " + n7 + "," + n8 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
        FuzzerUtils.out.println("Test.fFld byFld iFld1 = " + Float.floatToIntBits(fFld) + "," + this.byFld + "," + this.iFld1);
        FuzzerUtils.out.println("Test.dArrFld Test.fArrFld Test.bArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
        FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 0.93006);
        FuzzerUtils.init(fArrFld, 2.57f);
        FuzzerUtils.init(bArrFld, true);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        iMeth2_check_sum = 0L;
    }
}

