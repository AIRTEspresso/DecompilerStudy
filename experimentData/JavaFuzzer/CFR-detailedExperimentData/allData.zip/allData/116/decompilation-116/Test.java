/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -8933235804963499611L;
    public static boolean bFld = false;
    public int iFld = -43857;
    public static int[] iArrFld = new int[400];
    public static double[] dArrFld = new double[400];
    public static long vSmallMeth_check_sum;
    public static long vMeth_check_sum;
    public static long sMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vSmallMeth(int n, int n2, int n3) {
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 60.671f);
        fArray[(n2 >>> 1) % 400] = -6.0f;
        vSmallMeth_check_sum += (long)(n + n2 + n3) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static void vMeth1(double d, float f, int n) {
        int n2 = 167;
        int n3 = -44421;
        int n4 = -28074;
        int n5 = -11;
        int n6 = -234;
        int n7 = 244;
        int n8 = -213;
        int[] nArray = new int[400];
        long l = 6838349389279639813L;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -14);
        FuzzerUtils.init(lArray, 95L);
        nArray[46] = n;
        for (n2 = 4; n2 < 326; ++n2) {
            instanceCount = n;
            instanceCount += instanceCount;
        }
        int n9 = (n2 >>> 1) % 400;
        lArray[n9] = lArray[n9] & 0xAL;
        for (n4 = 156; n4 > 6; --n4) {
            nArray[n4 + 1] = (int)instanceCount;
            n3 = (int)instanceCount;
            f -= (float)n2;
            for (l = 11L; l > 1L; l -= 2L) {
                instanceCount += l - l;
                n5 += 166;
            }
        }
        for (n7 = 2; n7 < 201; ++n7) {
            n3 += n7;
            n8 += n7 * n7;
        }
        vMeth1_check_sum += Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + l + (long)n6 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public static short sMeth(long l, long l2, int n) {
        double d = 108.69093;
        float f = -34.42f;
        int n2 = -18284;
        int n3 = 12;
        int n4 = -38321;
        int n5 = 112;
        int n6 = -46295;
        int n7 = 10397;
        int n8 = -11;
        int n9 = -41008;
        int n10 = 1899;
        int[] nArray = new int[400];
        int[][][] nArray2 = new int[400][400][400];
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 3188266214L);
        FuzzerUtils.init(nArray, 204);
        FuzzerUtils.init((Object[][])nArray2, (Object)-62320);
        Test.vMeth1(d, f, -35740);
        n2 = 128;
        do {
            lArray[n2] = n;
            for (n3 = 12; n3 > n2; --n3) {
                f -= (float)n4;
                f = (float)d;
                for (n5 = 1; n5 > 1; --n5) {
                    l2 -= (long)d;
                    instanceCount = (long)((float)instanceCount + ((float)n5 * f + (float)n6 - (float)n2));
                    f += (float)(n5 * n + n6 - n);
                }
            }
            nArray[n2] = n6;
        } while (--n2 > 0);
        for (n7 = 6; 272 > n7; ++n7) {
            for (n9 = 1; 6 > n9; ++n9) {
                f = 8.0f;
            }
        }
        long l3 = l + l2 + (long)n + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)n10 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])nArray2);
        sMeth_check_sum += l3;
        return (short)l3;
    }

    public static void vMeth(boolean bl, int n, int n2) {
        int n3 = 151;
        int n4 = 239;
        int n5 = 11;
        int n6 = -32;
        int n7 = 16;
        int n8 = -201;
        float f = 0.673f;
        for (n3 = 10; 265 > n3; ++n3) {
            Test.vSmallMeth(n3, (int)((long)n2++ % ((long)Test.sMeth(instanceCount, instanceCount, n3) + instanceCount | 1L)), 206);
            if (bl) {
                instanceCount = n3;
                int n9 = n3 + 1;
                iArrFld[n9] = iArrFld[n9] - n4;
                n2 += n3;
                n4 = (int)((long)n4 + ((long)n3 * instanceCount + (long)n - instanceCount));
            }
            for (n5 = 1; n5 < 6; ++n5) {
                f -= (float)instanceCount;
                n6 *= n4;
                int n10 = n5;
                dArrFld[n10] = dArrFld[n10] + (double)n2;
                for (n7 = 1; n7 < 2; ++n7) {
                    if (n != 0) {
                        vMeth_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f) + n7 + n8);
                        return;
                    }
                    n *= (int)instanceCount;
                    n -= 49;
                }
            }
        }
        vMeth_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f) + n7 + n8);
    }

    public void mainTest(String[] stringArray) {
        int n = 960;
        int n2 = 0;
        int n3 = -9;
        int n4 = -13;
        int n5 = -16687;
        int n6 = 161;
        int n7 = -235;
        int[][] nArray = new int[400][400];
        float f = 1.797f;
        double d = -72.86975;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 0);
        FuzzerUtils.init(lArray, -7L);
        for (int i = 0; i < 204; ++i) {
            Test.vSmallMeth(n++, --n, n);
        }
        Test.vMeth(bFld, n *= (int)(f -= 1.0f), n);
        n ^= n;
        block22: for (n2 = 1; n2 < 192; ++n2) {
            switch (n2 % 2 * 5 + 121) {
                case 126: {
                    for (n4 = 131; n4 > n2; --n4) {
                        block24: for (n6 = 1; n6 < 1; ++n6) {
                            int n8 = n6 - 1;
                            iArrFld[n8] = iArrFld[n8] * (int)(instanceCount += (long)(n6 | n6));
                            switch (n2 % 1 + 21) {
                                case 21: {
                                    int n9 = n2 - 1;
                                    iArrFld[n9] = iArrFld[n9] >>> -13;
                                    instanceCount |= (long)n3;
                                    instanceCount = n2;
                                }
                            }
                            switch (n6 % 10 * 5 + 91) {
                                case 116: {
                                    n3 >>>= (int)instanceCount;
                                    n5 = (int)instanceCount;
                                    if (bFld) {
                                        n7 = (int)instanceCount;
                                        continue block24;
                                    }
                                    n7 += n6 * n6;
                                    f -= (float)n4;
                                    continue block24;
                                }
                                case 122: {
                                    n3 &= n4;
                                }
                                case 110: {
                                    n7 = n3;
                                    n += n6 * n6;
                                    continue block24;
                                }
                                case 118: {
                                    n3 += n6;
                                    int n10 = n2 - 1;
                                    lArray[n10] = lArray[n10] >> n4;
                                    n = (int)instanceCount;
                                }
                                case 115: {
                                    continue block24;
                                }
                                case 96: {
                                    this.iFld += n6 | n5;
                                    continue block24;
                                }
                                case 129: {
                                    n7 += n6 | n2;
                                    continue block24;
                                }
                                case 126: {
                                    try {
                                        this.iFld = nArray[n6 - 1][n4] / n2;
                                        n5 = this.iFld / n;
                                        nArray[n4][n2 + 1] = -679811288 % this.iFld;
                                    }
                                    catch (ArithmeticException arithmeticException) {}
                                    continue block24;
                                }
                                case 109: {
                                    n5 += (int)d;
                                    continue block24;
                                }
                                case 134: 
                            }
                        }
                    }
                    continue block22;
                }
                case 131: {
                    n -= (int)d;
                }
            }
        }
        FuzzerUtils.out.println("i3 f i30 = " + n + "," + Float.floatToIntBits(f) + "," + n2);
        FuzzerUtils.out.println("i31 i32 i33 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i34 i35 d2 = " + n6 + "," + n7 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("iArr3 lArr2 = " + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + this.iFld);
        FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 93);
        FuzzerUtils.init(dArrFld, -106.100693);
        vSmallMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        sMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

