/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 31948L;
    public static volatile boolean bFld = true;
    public static int iFld = 59888;
    public static short sFld = (short)3058;
    public static double dFld = -90.111661;
    public static short[] sArrFld = new short[400];
    public static byte[] byArrFld = new byte[400];
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;
    public static long dMeth_check_sum;

    public static double dMeth() {
        int n = -14;
        int n2 = -6;
        int n3 = 8;
        float f = 41.916f;
        double d = 126.78193;
        double d2 = 0.108195;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -77.101621);
        for (n = 11; n < 355; ++n) {
            f -= f;
            d = 1.0;
            do {
                int n4 = -25675;
                instanceCount += instanceCount;
                n4 = (short)f;
                d2 = 1.0;
                do {
                    instanceCount += (long)n;
                    f += (float)d;
                    f -= -8989.0f;
                    instanceCount -= (long)(n2 += (int)((long)d2 ^ (long)n));
                } while ((d2 += 1.0) < 1.0);
                n2 -= (int)instanceCount;
                dArray[n + 1] = n3;
            } while ((d += 1.0) < 5.0);
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n3 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        dMeth_check_sum += l;
        return l;
    }

    public static int iMeth(long l, int n, int n2) {
        float f = 2.321f;
        float f2 = -123.208f;
        int n3 = -230;
        int n4 = 12;
        int n5 = 8537;
        int n6 = -17190;
        int[] nArray = new int[400];
        long l2 = -3793330418L;
        long[] lArray = new long[400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(lArray, 3903266759103189862L);
        FuzzerUtils.init(nArray, 14);
        FuzzerUtils.init(byArray, (byte)-103);
        f = 1.0f;
        do {
            block8: for (n3 = (int)f; n3 < 7; n3 += 3) {
                int n7 = (int)(f + 1.0f);
                lArray[n7] = lArray[n7] << (int)((double)(n * (11 * --n2)) + Math.abs(Test.dMeth()));
                bFld = true;
                switch ((n3 >>> 1) % 5 + 2) {
                    case 2: {
                        for (n5 = 1; 1 > n5; ++n5) {
                            if (bFld) continue;
                            l2 = -363309613L;
                            n4 = (int)((long)n4 + ((long)(n5 * n4 + n3) - l2));
                            f2 += (float)(n5 * n5);
                            nArray[n3 - 1] = 1870944173;
                            int n8 = n5 + 1;
                            byArray[n8] = (byte)(byArray[n8] ^ (byte)n2);
                            n *= -159;
                        }
                        continue block8;
                    }
                    case 3: {
                        n4 = (int)instanceCount;
                        continue block8;
                    }
                    case 4: {
                        n4 += 111;
                        continue block8;
                    }
                    case 5: {
                        n4 += n3 - n3;
                        continue block8;
                    }
                    case 6: {
                        n6 = (int)f;
                    }
                }
            }
        } while ((f += 1.0f) < 235.0f);
        long l3 = l + (long)n + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + l2 + (long)Float.floatToIntBits(f2) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(byArray);
        iMeth_check_sum += l3;
        return (int)l3;
    }

    public static long lMeth() {
        int n = 156;
        int n2 = -100;
        int n3 = 16;
        int n4 = -30874;
        int n5 = 41;
        int n6 = -47;
        int n7 = -25;
        int n8 = -89;
        int n9 = 5;
        float f = 21.808f;
        switch ((Test.iMeth(instanceCount, iFld, n) >>> 1) % 4 * 5 + 60) {
            case 70: {
                for (n2 = 306; n2 > 2; --n2) {
                    iFld <<= n2;
                    instanceCount += (long)(n2 + n);
                    sArrFld = FuzzerUtils.short1array(400, (short)-7719);
                }
                n4 = 1;
                do {
                    for (n5 = 1; 5 > n5; ++n5) {
                        iFld += n5 * n3 + n3 - iFld;
                        n -= n9;
                        iFld >>= n3;
                        for (n7 = 1; n7 < 2; ++n7) {
                            n3 = 174;
                            sFld = (short)(sFld - (short)dFld);
                            n8 -= iFld;
                            n9 = (byte)(n9 + (byte)n2);
                        }
                    }
                } while (++n4 < 329);
                break;
            }
            case 74: {
                f = instanceCount;
            }
            case 67: 
            case 72: {
                f -= (float)n5;
                break;
            }
            default: {
                n6 = n2;
            }
        }
        long l = n + n2 + n3 + n4 + n5 + n6 + n9 + n7 + n8 + Float.floatToIntBits(f);
        lMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 21031;
        int n2 = -1851;
        int n3 = -204;
        int n4 = -949;
        int n5 = -4751;
        int n6 = 69;
        int n7 = 21208;
        int n8 = 0;
        int[][][] nArray = new int[400][400][400];
        float f = -119.498f;
        float f2 = 46.82f;
        int n9 = -29;
        long[] lArray = new long[400];
        FuzzerUtils.init((Object[][])nArray, (Object)-50323);
        FuzzerUtils.init(lArray, 8757L);
        n = Integer.reverseBytes((int)((long)(n - n) + --instanceCount));
        n -= (int)(Test.lMeth() * (long)n);
        int[] nArray2 = nArray[(iFld >>> 1) % 400][(iFld >>> 1) % 400];
        int n10 = (iFld >>> 1) % 400;
        nArray2[n10] = nArray2[n10] & (int)instanceCount;
        block2: for (n2 = 5; n2 < 180; ++n2) {
            nArray[n2 + 1][n2 + 1][n2] = n;
            iFld -= n2;
            iFld >>>= n2;
            sFld = (short)(sFld + (short)dFld);
            for (f = 8.0f; f < 143.0f; f += 3.0f) {
                dFld += (double)n2;
                n5 = 1;
                while (++n5 < 4) {
                    n6 = n2;
                    n6 *= n2;
                    int[] nArray3 = nArray[n5 + 1][n2];
                    int n11 = n5 - 1;
                    nArray3[n11] = nArray3[n11] | sFld;
                    n += n5 | (n4 -= n);
                    f2 -= (float)n9;
                    n6 = 970;
                    instanceCount += (long)(n5 * n4 + n6 - n3);
                    try {
                        iFld = 25 / n5;
                        n3 = -28 / n6;
                        n = iFld / 47;
                    }
                    catch (ArithmeticException arithmeticException) {}
                }
                if (bFld) {
                    if (bFld) continue block2;
                    for (n7 = 1; n7 < 4; ++n7) {
                        f2 -= (float)instanceCount;
                        instanceCount = sFld;
                        int[] nArray4 = nArray[n2][(int)f];
                        int n12 = n7 + 1;
                        nArray4[n12] = nArray4[n12] + (int)f;
                        n = n4;
                        iFld += n7 * n7;
                    }
                    continue;
                }
                if (bFld) {
                    f2 += f * f;
                    continue;
                }
                int n13 = (int)(f + 1.0f);
                byArrFld[n13] = (byte)(byArrFld[n13] / (byte)(iFld | 1));
            }
        }
        FuzzerUtils.out.println("i i18 i19 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f4 i20 i21 = " + Float.floatToIntBits(f) + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i22 f5 by1 = " + n6 + "," + Float.floatToIntBits(f2) + "," + n9);
        FuzzerUtils.out.println("i23 i24 iArr1 = " + n7 + "," + n8 + "," + FuzzerUtils.checkSum((Object[][])nArray));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + iFld);
        FuzzerUtils.out.println("Test.sFld Test.dFld Test.sArrFld = " + sFld + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("Test.byArrFld = " + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)-24248);
        FuzzerUtils.init(byArrFld, (byte)90);
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
    }
}

