/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 30605L;
    public int iFld = -38635;
    public static short sFld = (short)2324;
    public static int iFld1 = 8;
    public static boolean bFld = false;
    public boolean bFld1 = false;
    public static int[] iArrFld = new int[400];
    public static double[] dArrFld = new double[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(float f) {
        int n = 202;
        int n2 = 4;
        int n3 = 54;
        int n4 = 41;
        int n5 = 104;
        double d = 1.8612;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 2648983453L);
        n *= 11;
        for (n2 = 343; 7 < n2; n2 -= 2) {
            n -= (int)instanceCount;
            int n6 = n2 + 1;
            iArrFld[n6] = iArrFld[n6] >> n3;
            int n7 = n2;
            iArrFld[n7] = iArrFld[n7] + (int)f;
            for (n4 = 1; n4 < 9; ++n4) {
                int n8 = n2;
                dArrFld[n8] = dArrFld[n8] * (double)n4;
            }
            instanceCount += -2471792388101766201L;
            int n9 = n2 + 1;
            lArray[n9] = lArray[n9] - (long)n5;
            f *= -135.0f;
            n5 -= (int)d;
        }
        instanceCount >>= 57233;
        instanceCount += (long)n4;
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
    }

    public static int iMeth1() {
        int n = -11;
        int n2 = -43;
        int n3 = -12985;
        int n4 = 4;
        int n5 = -14;
        int n6 = 141;
        int n7 = 10;
        float f = 2.307f;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -3134388285L);
        n >>>= (int)lArray[(n >>> 1) % 400];
        n = 45291;
        Test.vMeth(f);
        for (n2 = 13; n2 < 290; ++n2) {
            block5: for (n4 = 1; n4 < 6; n4 += 2) {
                instanceCount += (long)(n4 * sFld);
                for (n6 = 1; n6 < 3; ++n6) {
                    if (bl) continue;
                    n7 >>>= (int)instanceCount;
                    n5 += (int)instanceCount;
                }
                switch (n2 % 2 * 5 + 16) {
                    case 22: {
                        n3 += n4 ^ n3;
                        n7 += n4;
                        continue block5;
                    }
                    case 23: {
                        instanceCount += (long)n3;
                        n += n4;
                        continue block5;
                    }
                    default: {
                        n5 += 10;
                    }
                }
            }
        }
        long l = (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth(int n, int n2, float f) {
        int n3 = 53037;
        int n4 = 33;
        int n5 = 10;
        int n6 = 24893;
        int n7 = 4;
        int n8 = -5;
        int n9 = -190;
        int n10 = 9;
        int n11 = 7;
        int n12 = -21;
        double d = -6.6663;
        boolean bl = true;
        boolean[] blArray = new boolean[400];
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init((Object[][])lArray, (Object)-2765748243573170087L);
        for (n3 = 196; 7 < n3; n3 -= 3) {
            for (n5 = n3; 24 > n5; ++n5) {
                Test.iArrFld[n5 + 1] = n7;
                n12 = (byte)(n12 * (byte)n7++);
            }
            block12: for (d = 1.0; d < 24.0; d += 1.0) {
                blArray[n3] = bl;
                n >>= n6-- >> Test.iMeth1();
                iFld1 = n3;
                int n13 = n3 - 1;
                iArrFld[n13] = iArrFld[n13] * (int)(f += (float)(d * (double)instanceCount + (double)n2 - (double)n2));
                switch (n3 % 8 + 46) {
                    case 46: {
                        f += (float)d;
                        for (n9 = 1; n9 < 2; ++n9) {
                            instanceCount += instanceCount;
                            instanceCount <<= n5;
                        }
                        continue block12;
                    }
                    case 47: {
                        n = n6;
                        continue block12;
                    }
                    case 48: {
                        long[] lArray2 = lArray[n3 + 1][(int)d];
                        int n14 = (int)(d + 1.0);
                        lArray2[n14] = lArray2[n14] + (long)n11;
                        continue block12;
                    }
                    case 49: {
                        n6 = n9;
                        continue block12;
                    }
                    case 50: {
                        continue block12;
                    }
                    case 51: {
                        instanceCount &= (long)n7;
                    }
                    case 52: {
                        Test.iArrFld[n3] = (int)instanceCount;
                        continue block12;
                    }
                    case 53: 
                }
            }
        }
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6 + n7 + n12) + Double.doubleToLongBits(d) + (long)n8 + (long)(bl ? 1 : 0) + (long)n9 + (long)n10 + (long)n11 + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum((Object[][])lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        float f = 110.93f;
        int n = 5274;
        int n2 = 30670;
        int n3 = -24787;
        int n4 = 61226;
        int n5 = -4;
        int n6 = 11;
        int n7 = -12;
        int n8 = 174;
        double d = -116.124496;
        int n9 = 92;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -3L);
        this.iFld >>= (int)(-7L - (long)iArrFld[(this.iFld >>> 1) % 400] + ((instanceCount &= 0xFFFFFFFFFFFFFFFAL) + (long)this.iFld) + (long)Test.iMeth(this.iFld, iFld1, f));
        instanceCount -= (long)this.iFld;
        int n10 = (iFld1 >>> 1) % 400;
        lArray[n10] = lArray[n10] >> iFld1;
        n = 1;
        while (++n < 323) {
            switch ((this.iFld >>> 1) % 10 + 74) {
                case 74: {
                    this.iFld += 13;
                    this.iFld *= -3;
                    d += (double)instanceCount;
                    break;
                }
                case 75: {
                    this.iFld = (int)f;
                    if (bFld) {
                        try {
                            this.iFld = iArrFld[n - 1] / -119;
                            iFld1 = iArrFld[n] / iFld1;
                            iFld1 = n % iFld1;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                }
                case 76: {
                    for (n2 = n; n2 < 78; ++n2) {
                        d -= (double)n;
                        switch (89) {
                            case 89: {
                                f += (float)n;
                                break;
                            }
                            case 90: {
                                for (n4 = 1; n4 < 1; n4 += 3) {
                                    this.iFld -= this.iFld;
                                }
                                for (n6 = 1; n6 < 1; ++n6) {
                                    n9 = (byte)instanceCount;
                                    f += 12376.0f;
                                    n5 = n2;
                                }
                                this.iFld >>= 1205108582;
                                n9 = (byte)(n9 + (byte)(127.642f + (float)(n2 * n2)));
                                break;
                            }
                            case 91: {
                                bFld = this.bFld1;
                                bFld = this.bFld1;
                                this.iFld = 1;
                            }
                        }
                        instanceCount += (long)n2 * instanceCount + (long)iFld1 - instanceCount;
                        int n11 = n;
                        lArray[n11] = lArray[n11] + instanceCount;
                    }
                    break;
                }
                case 77: {
                    n5 = n7;
                    break;
                }
                case 78: {
                    n5 >>>= n;
                }
                case 79: {
                    iFld1 -= -13;
                    break;
                }
                case 80: {
                    n8 -= 24120;
                    break;
                }
                case 81: {
                    instanceCount >>= -65003;
                    break;
                }
                case 82: {
                    dArrFld = FuzzerUtils.double1array(400, 2.75698);
                }
                case 83: {
                    n3 = (int)d;
                }
            }
        }
        FuzzerUtils.out.println("f3 i23 d2 = " + Float.floatToIntBits(f) + "," + n + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i24 i25 i26 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i27 i28 i29 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("by1 i30 lArr3 = " + n9 + "," + n8 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.sFld = " + instanceCount + "," + this.iFld + "," + sFld);
        FuzzerUtils.out.println("Test.iFld1 Test.bFld bFld1 = " + iFld1 + "," + (bFld ? 1 : 0) + "," + (this.bFld1 ? 1 : 0));
        FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -216);
        FuzzerUtils.init(dArrFld, -116.86471);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

