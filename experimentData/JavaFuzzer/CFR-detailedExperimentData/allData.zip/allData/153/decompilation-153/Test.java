/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 6951135113443121899L;
    public static float fFld = -1.63f;
    public static double dFld = 26.112492;
    public static boolean bFld = true;
    public static volatile long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2) {
        boolean bl = true;
        int n3 = 18345;
        int n4 = -52;
        int n5 = 15;
        int[] nArray = new int[400];
        float f = -55.706f;
        double d = 1.26081;
        long l = -29882L;
        long l2 = 0L;
        FuzzerUtils.init(nArray, 39179);
        n2 *= n2;
        n = 178;
        n3 = 1;
        do {
            int n6 = n3;
            nArray[n6] = nArray[n6] - (int)f;
            for (d = 1.0; d < 8.0; d += 1.0) {
                nArray[n3 + 1] = (int)d;
                int n7 = n3 - 1;
                nArray[n7] = nArray[n7] + (int)instanceCount;
                for (l = (long)d; l < 2L; ++l) {
                    n2 = n;
                    instanceCount -= (long)d;
                    f -= (float)d;
                    if (!bl) continue;
                    try {
                        n4 = 198 % nArray[n3 + 1];
                        n /= n;
                        n4 = 80 / n5;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n5 = (int)l2;
                }
            }
        } while (++n3 < 208);
        vMeth1_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n4 + l + (long)n5 + l2 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(double d, byte by) {
        int n = -13;
        int n2 = -2;
        int n3 = -4;
        int n4 = -10;
        int n5 = 219;
        boolean bl = false;
        int n6 = 27020;
        Test.vMeth1(n, n);
        for (n2 = 9; n2 < 184; ++n2) {
            fFld -= (float)n2;
            n4 = 9;
            do {
                n3 += (int)instanceCount;
            } while (--n4 > 0);
            if (bl) break;
            n = (int)((long)n + ((long)(n2 * n4) + instanceCount - instanceCount));
            n |= n;
            n3 += n2 * n2 + n4 - n;
        }
        n5 = (int)d;
        instanceCount -= (long)n4;
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)by + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)(n5 += n6) + (long)n6;
    }

    public int iMeth(int n, float f, int n2) {
        int n3 = 12484;
        int n4 = 4;
        int n5 = -8;
        int n6 = -5;
        int n7 = -31319;
        int n8 = 4;
        int n9 = 39;
        boolean bl = false;
        for (n3 = 10; n3 < 174; ++n3) {
            Test.vMeth(dFld, (byte)n9);
            if (bl) {
                n = (int)instanceCount;
                switch ((n4 >>> 1) % 1 + 91) {
                    case 91: {
                        n5 = 1;
                        block4: do {
                            f *= (float)n4;
                            n6 = n9;
                            for (n7 = 1; n7 > n5; --n7) {
                                if (bl) continue;
                                lArrFld = FuzzerUtils.long1array(400, 91L);
                                n8 ^= n7;
                                instanceCount = n5;
                                n2 += n7 + n4;
                                if (bl) continue block4;
                            }
                        } while (++n5 < 10);
                        break;
                    }
                    default: {
                        n += 130;
                        break;
                    }
                }
                continue;
            }
            dFld -= (double)n8;
        }
        long l = n + Float.floatToIntBits(f) + n2 + n3 + n4 + n9 + n5 + n6 + n7 + n8 + (bl ? 1 : 0);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -193;
        int n2 = 34913;
        int n3 = 129;
        int n4 = 9;
        int n5 = -3;
        int n6 = 14;
        int n7 = -5;
        int n8 = 17884;
        int[] nArray = new int[400];
        int n9 = 19104;
        short[] sArray = new short[400];
        int n10 = -82;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 20056);
        FuzzerUtils.init(sArray, (short)13116);
        FuzzerUtils.init(lArray, 61L);
        for (n = 15; n < 392; ++n) {
            int n11 = n;
            int n12 = nArray[n11] + 1;
            nArray[n11] = n12;
            n9 = (short)(n9 - (short)((double)n12 + (double)this.iMeth(n2, 2.6f, n2) * dFld));
            if (bFld) continue;
            n2 -= 147;
            block7: for (n3 = n; n3 < 67; ++n3) {
                switch (n3 % 2 * 5 + 17) {
                    case 18: {
                        nArray[n] = (int)instanceCount;
                        n10 = (byte)(n10 + (byte)n3);
                        for (n5 = 1; n5 > 1; n5 -= 3) {
                            if (bFld) continue;
                            dFld = n2;
                            instanceCount += (long)(n5 * n9 + n10 - (n2 -= n6));
                            int n13 = n3;
                            sArray[n13] = (short)(sArray[n13] + (short)n4);
                            int n14 = n3 - 1;
                            nArray[n14] = nArray[n14] + n2;
                            instanceCount += (long)n5 * instanceCount + instanceCount - (long)n5;
                            n4 /= n2 | 1;
                        }
                        instanceCount -= (long)n6;
                        continue block7;
                    }
                    case 26: {
                        lArrFld = lArray;
                        try {
                            n2 = n3 % n2;
                            n2 = n % n6;
                            n4 = n / nArray[n3 - 1];
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                        for (n7 = 1; 1 > n7 && !bFld; ++n7) {
                            n9 = (short)(n9 + (short)n3);
                            n2 -= n;
                            fFld *= (float)dFld;
                            int n15 = n + 1;
                            lArrFld[n15] = lArrFld[n15] + instanceCount;
                        }
                        continue block7;
                    }
                    default: {
                        n2 ^= n6;
                        instanceCount += -230L + (long)(n3 * n3);
                    }
                }
            }
            n2 -= 26551;
            n2 >>= n6;
        }
        FuzzerUtils.out.println("i i1 s = " + n + "," + n2 + "," + n9);
        FuzzerUtils.out.println("i20 i21 by2 = " + n3 + "," + n4 + "," + n10);
        FuzzerUtils.out.println("i22 i23 i24 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i25 iArr sArr = " + n8 + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.bFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -29681L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

