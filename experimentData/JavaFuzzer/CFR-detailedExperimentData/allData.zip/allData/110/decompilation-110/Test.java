/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 3510175330L;
    public static double dFld = -1.90633;
    public static int iFld = 151;
    public static boolean bFld = true;
    public static float fFld = -1.903f;
    public static int iFld1 = -98;
    public float[] fArrFld = new float[400];
    public double[] dArrFld = new double[400];
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long byMeth_check_sum = 0L;

    public static byte byMeth(long l) {
        int n = 0;
        int n2 = 1;
        int n3 = -8;
        int n4 = 134;
        int n5 = 6;
        int n6 = 25681;
        int[] nArray = new int[400];
        double[][] dArray = new double[400][400];
        float[][] fArray = new float[400][400];
        FuzzerUtils.init(nArray, -90);
        FuzzerUtils.init(dArray, -116.38173);
        FuzzerUtils.init(fArray, 0.695f);
        for (n = 7; n < 383; n += 3) {
            nArray[n + 1] = n;
            nArray[n + 1] = 1708639143;
            if (bFld) continue;
            double[] dArray2 = dArray[n - 1];
            int n7 = n;
            dArray2[n7] = dArray2[n7] - dFld;
            int n8 = n + 1;
            nArray[n8] = nArray[n8] * iFld;
            for (n3 = 1; n3 < 13; ++n3) {
                float[] fArray2 = fArray[n3];
                int n9 = n + 1;
                fArray2[n9] = fArray2[n9] + -96.24669f;
                n2 *= iFld;
                n4 = 119;
                iFld += n3 * iFld;
                dFld -= 6.0;
                for (n5 = 1; 2 > n5; ++n5) {
                    instanceCount = 11L;
                    fFld += -12.0f;
                }
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        byMeth_check_sum += l2;
        return (byte)l2;
    }

    public static void vMeth1() {
        int n = 18301;
        int n2 = 6;
        int n3 = 90;
        int n4 = 242;
        int n5 = -10;
        int[][][] nArray = new int[400][400][400];
        double[] dArray = new double[400];
        boolean[][][] blArray = new boolean[400][400][400];
        FuzzerUtils.init((Object[][])nArray, (Object)189);
        FuzzerUtils.init(dArray, -1.38009);
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        iFld -= iFld + Test.byMeth(instanceCount);
        instanceCount = iFld;
        int[] nArray2 = nArray[(iFld >>> 1) % 400][(iFld >>> 1) % 400];
        int n6 = (iFld >>> 1) % 400;
        nArray2[n6] = nArray2[n6] * iFld;
        try {
            dFld = -65.86675;
            iFld -= n;
            fFld *= (float)instanceCount;
        }
        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            for (n2 = 3; n2 < 366; ++n2) {
                if (bFld) continue;
                iFld /= 58217;
                for (n4 = 1; n4 < 5 && !bFld; ++n4) {
                    dArray[n4 - 1] = dFld;
                    blArray[n2 + 1][n2 + 1][n4] = false;
                    n >>= n3;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum((Object[][])nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum((Object[][])blArray);
    }

    public static void vMeth(int n) {
        int n2 = 5;
        int n3 = 88;
        int n4 = -127;
        int n5 = 63718;
        int n6 = -36655;
        int[] nArray = new int[400];
        int n7 = -23;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 22851);
        FuzzerUtils.init(lArray, -1L);
        if (bFld) {
            for (n2 = 8; n2 < 395; ++n2) {
                instanceCount = n2;
                n7 = (byte)(n7 >> (byte)(++n3));
                Test.vMeth1();
                n4 = 1;
                do {
                    iFld |= n3;
                    n5 = 1;
                    while (n5 < 1) {
                        int n8 = n5++;
                        nArray[n8] = nArray[n8] << (int)instanceCount;
                        instanceCount *= (long)n4;
                        n %= -134705901;
                        if (bFld) break;
                        fFld = n6;
                        instanceCount >>= n3;
                    }
                    int n9 = n2 - 1;
                    lArray[n9] = lArray[n9] & instanceCount;
                } while (++n4 < 4);
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n7 + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    /*
     * Unable to fully structure code
     */
    public void mainTest(String[] var1_1) {
        var2_2 = 65017;
        var3_3 = 3;
        var4_4 = 72;
        var5_5 = 0;
        var6_6 = 61824;
        var7_7 = 1;
        var8_8 = 17987;
        var9_9 = -179;
        var10_10 = 35156;
        var11_11 = 128;
        var12_12 = 7;
        var13_13 = -182;
        var14_14 = new int[400][400];
        var15_15 = 6;
        var16_16 = 17318;
        var17_17 = new long[400];
        FuzzerUtils.init(var14_14, 8);
        FuzzerUtils.init(var17_17, -47807L);
        v0 = (var2_2 >>> 1) % 400;
        v1 = var2_2--;
        v2 = (var2_2 >>> 1) % 400;
        v3 = this.dArrFld[v2] - 1.0;
        this.dArrFld[v2] = v3;
        this.fArrFld[v0] = (float)(((double)v1 - v3) * (double)var2_2);
        for (var3_3 = 8; var3_3 < 268; ++var3_3) {
            Test.instanceCount = -56804L - ((long)(var4_4 - -3) + 26507L % ((long)(Test.dFld += 1.0) | 1L));
        }
        Test.vMeth(-59020);
        switch ((var4_4 >>> 1) % 10 + 20) {
            case 20: {
                break;
            }
            case 21: {
                var2_2 = var15_15;
                break;
            }
            case 22: {
                for (var5_5 = 2; var5_5 < 351; ++var5_5) {
                    Test.instanceCount |= (long)var5_5;
                    var4_4 >>= var6_6;
                }
                break;
            }
            case 23: {
                var7_7 = 190;
                while (--var7_7 > 0) {
                    for (var8_8 = var7_7; var8_8 < 132; var8_8 += 2) {
                        Test.iFld1 = var4_4;
                        for (var10_10 = 1; var10_10 < 1; ++var10_10) {
                            var14_14[var7_7 + 1][var8_8 - 1] = Test.iFld1;
                            if (Test.bFld) {
                                Test.dFld %= (double)(var3_3 | 1);
                                var2_2 += var10_10 * var3_3 + var5_5 - (var9_9 += var10_10 - Test.iFld);
                                Test.fFld += (float)((long)var10_10 * Test.instanceCount + Test.instanceCount - (long)var5_5);
                            }
                            Test.instanceCount += (long)var15_15;
                        }
                        var4_4 = Test.iFld1;
                        for (var12_12 = 1; var12_12 < 1; ++var12_12) {
                            Test.fFld += (float)var3_3;
                        }
                        Test.iFld = var16_16;
                    }
                    Test.instanceCount -= Test.instanceCount;
                    Test.iFld |= (int)Test.instanceCount;
                }
            }
            case 24: {
                var17_17[0] = var7_7;
            }
            case 25: {
                var2_2 += var5_5;
                break;
            }
            case 26: {
                var15_15 = (byte)var9_9;
            }
            case 27: {
                v4 = (var11_11 >>> 1) % 400;
                var17_17[v4] = var17_17[v4] - Test.instanceCount;
                break;
            }
            ** case 28:
lbl75:
            // 2 sources

            case 29: 
        }
        FuzzerUtils.out.println("i i1 i2 = " + var2_2 + "," + var3_3 + "," + var4_4);
        FuzzerUtils.out.println("by1 i20 i21 = " + var15_15 + "," + var5_5 + "," + var6_6);
        FuzzerUtils.out.println("i22 i23 i24 = " + var7_7 + "," + var8_8 + "," + var9_9);
        FuzzerUtils.out.println("i25 i26 i27 = " + var10_10 + "," + var11_11 + "," + var12_12);
        FuzzerUtils.out.println("i28 s iArr3 = " + var13_13 + "," + var16_16 + "," + FuzzerUtils.checkSum(var14_14));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(var17_17));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + Test.instanceCount + "," + Double.doubleToLongBits(Test.dFld) + "," + Test.iFld);
        FuzzerUtils.out.println("Test.bFld Test.fFld Test.iFld1 = " + (Test.bFld != false ? 1 : 0) + "," + Float.floatToIntBits(Test.fFld) + "," + Test.iFld1);
        FuzzerUtils.out.println("fArrFld dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("byMeth_check_sum: " + Test.byMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + Test.vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + Test.vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

