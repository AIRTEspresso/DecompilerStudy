/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3L;
    public short sFld = (short)4906;
    public volatile boolean[] bArrFld = new boolean[400];
    public boolean[] bArrFld1 = new boolean[400];
    public volatile int[] iArrFld = new int[400];
    public static long iMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(long l) {
        int n = -13;
        int n2 = 201;
        int n3 = -40535;
        int n4 = 52359;
        int[][] nArray = new int[400][400];
        int n5 = -100;
        float f = 19.738f;
        float f2 = 1.285f;
        boolean bl = true;
        FuzzerUtils.init(nArray, -23420);
        n += n;
        n = n5;
        f = 1.0f;
        do {
            n2 = 1;
            while (++n2 < 7) {
                block7: for (n3 = 1; n3 < 1; ++n3) {
                    switch ((int)(f % 5.0f + 67.0f)) {
                        case 67: {
                            n4 = (int)((long)n4 + ((long)n3 - instanceCount));
                            continue block7;
                        }
                        case 68: {
                            if (bl) continue block7;
                            f2 -= -41761.0f;
                            n *= 195;
                            continue block7;
                        }
                        case 69: {
                            int[] nArray2 = nArray[n2];
                            int n6 = n2;
                            nArray2[n6] = nArray2[n6] + (int)l;
                            n >>>= n;
                            continue block7;
                        }
                        default: {
                            f2 -= (float)n4;
                        }
                    }
                }
            }
        } while ((f += 1.0f) < 232.0f);
        vMeth1_check_sum += l + (long)n + (long)n5 + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f2) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth() {
        int n = 173;
        int n2 = -8759;
        int n3 = 7;
        int n4 = 48;
        int n5 = -203;
        int n6 = -39454;
        int n7 = 8;
        int[] nArray = new int[400];
        float f = 97.63f;
        FuzzerUtils.init(nArray, 0);
        Test.vMeth1(instanceCount);
        for (n = 13; n < 388; ++n) {
            instanceCount = n;
            for (n3 = n; n3 < 5; ++n3) {
                n4 = (int)instanceCount;
                n2 = n;
                n4 += n3;
            }
            instanceCount += (long)n;
            int n8 = n;
            nArray[n8] = nArray[n8] | n3;
            n5 = 5;
            block13: do {
                f += (float)(n5 * n5);
                switch (79) {
                    case 103: {
                        for (n6 = 3; n6 > n5; --n6) {
                            try {
                                n2 = -124 / nArray[164];
                                n4 = n3 / -17995;
                                n2 = n7 / nArray[n5];
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            instanceCount -= (long)n3;
                        }
                        continue block13;
                    }
                    case 80: {
                        try {
                            n7 = -200 / n4;
                            n7 = 1775423490 % n6;
                            n4 = 40496 / n;
                        }
                        catch (ArithmeticException arithmeticException) {}
                        continue block13;
                    }
                    case 81: {
                        n4 *= (int)instanceCount;
                        break;
                    }
                    case 99: 
                    case 104: {
                        n2 += n5;
                        break;
                    }
                    case 92: {
                        n2 = n5;
                        break;
                    }
                    default: {
                        n7 += n5 - n3;
                    }
                }
            } while ((n5 -= 3) > 0);
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f) + n6 + n7) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(int n) {
        float f = -1.169f;
        int n2 = -22;
        int n3 = -11936;
        int n4 = -7;
        int n5 = -71;
        int n6 = 230;
        int n7 = -38420;
        int n8 = 228;
        int[] nArray = new int[400];
        int n9 = -59;
        boolean bl = false;
        FuzzerUtils.init(nArray, -37605);
        n *= (int)((float)n + (-(f - f) + (float)nArray[(n >>> 1) % 400]));
        --n;
        n = Integer.reverseBytes(n) / (Math.min((int)(31086L + ((long)n - instanceCount)), n) | 1);
        for (n2 = 5; n2 < 162; ++n2) {
            for (n4 = n2; n4 < 10; ++n4) {
                n5 >>= (int)instanceCount--;
                int n10 = n2 - 1;
                nArray[n10] = nArray[n10] + (n3 - Math.min(n4, n3)) * Math.abs(--n);
                n6 = 1;
                while (++n6 < 1) {
                    n9 = (byte)(n9 - (byte)(Integer.reverseBytes(n6) * (n5 + n6) % (++n5 | 1)));
                }
                Test.vMeth();
                n7 = 1;
                while (n7 > 1) {
                    n8 += n6;
                    nArray[n4 - 1] = n4;
                    int n11 = n7--;
                    nArray[n11] = nArray[n11] & 0xA;
                    n = n2;
                }
            }
        }
        long l = (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n9 + (bl ? 1 : 0) + n7 + n8) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        double d = 19.106742;
        int n = 13;
        int n2 = -34574;
        int n3 = -36;
        int n4 = -180;
        int n5 = -187;
        boolean bl = true;
        boolean bl2 = false;
        boolean bl3 = false;
        int n6 = 12;
        for (d = 10.0; 185.0 > d; d += 1.0) {
            float f = -73.358f;
            bl = f >= (float)this.sFld == (bl ^ bl) != (instanceCount > 200L | (bl | bl));
            this.bArrFld[(int)(d + 1.0)] = bl2;
            n = Test.iMeth(n);
            f = instanceCount;
            n = bl ? (n += (int)f) : (int)instanceCount;
            n += n6;
            for (n2 = 8; n2 < 143; ++n2) {
                f -= -42.0f;
                n6 = (byte)(n6 >> (byte)instanceCount);
                bl2 = bl;
                block13: for (n4 = (int)d; 2 > n4; ++n4) {
                    this.bArrFld1[(n3 >>> 1) % 400] = bl;
                    n3 += n4 * n4;
                    n3 >>= 11;
                    switch (77) {
                        case 77: {
                            int n7 = n4;
                            this.iArrFld[n7] = this.iArrFld[n7] & n;
                            this.iArrFld[(int)(d + 1.0)] = n5;
                            if (bl3) {
                                f *= (float)n3;
                                n3 += n4 * n2;
                                f += (float)n4;
                            }
                            switch (n4 % 1 + 106) {
                                case 106: {
                                    n3 = n;
                                }
                            }
                            continue block13;
                        }
                        case 78: {
                            n ^= n4;
                            continue block13;
                        }
                        case 79: {
                            n -= (int)d;
                            continue block13;
                        }
                        case 80: {
                            bl3 = bl2;
                        }
                        default: {
                            try {
                                n3 = n4 % this.iArrFld[n4];
                                n3 = -38772 / n4;
                                n = this.iArrFld[n2 + 1] / 2132987612;
                                continue block13;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("d i b = " + Double.doubleToLongBits(d) + "," + n + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("b1 by2 i20 = " + (bl2 ? 1 : 0) + "," + n6 + "," + n2);
        FuzzerUtils.out.println("i21 i22 i23 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("b4 = " + (bl3 ? 1 : 0));
        FuzzerUtils.out.println("Test.instanceCount sFld bArrFld = " + instanceCount + "," + this.sFld + "," + FuzzerUtils.checkSum(this.bArrFld));
        FuzzerUtils.out.println("bArrFld1 iArrFld = " + FuzzerUtils.checkSum(this.bArrFld1) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

