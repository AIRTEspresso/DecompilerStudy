/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2L;
    public static double dFld = -1.43384;
    public boolean bFld = true;
    public static byte byFld = (byte)18;
    public static long vSmallMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1() {
        int n = 52282;
        int n2 = 63745;
        int n3 = -36503;
        int n4 = -192;
        int n5 = 26016;
        int[] nArray = new int[400];
        float f = 1.23f;
        int n6 = -7560;
        long l = 44635L;
        long[] lArray = new long[400];
        byte[] byArray = new byte[400];
        FuzzerUtils.init(lArray, 2555038843L);
        FuzzerUtils.init(nArray, -21805);
        FuzzerUtils.init(byArray, (byte)88);
        for (n = 266; n > 9; --n) {
            lArray[n - 1] = n;
            instanceCount >>= (int)instanceCount;
            for (n3 = 6; n3 > 1; --n3) {
                int n7 = n;
                nArray[n7] = nArray[n7] + 38549;
                n4 += n5;
                f += (float)(21722 + n3 * n3);
                dFld = n6;
            }
            instanceCount += (long)(69 + n * n);
            n5 >>>= n4;
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f) + n6) + l + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(byArray);
    }

    public static void vMeth(boolean bl, int n, int n2) {
        int n3 = -1;
        int n4 = -210;
        int n5 = 61;
        int n6 = 12;
        float f = -115.688f;
        Test.vMeth1();
        n3 = 6;
        if (n3 < 125) {
            for (n5 = 1; n5 < 13; ++n5) {
                instanceCount = n;
            }
        }
        vMeth_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f));
    }

    public static void vSmallMeth() {
        boolean bl = false;
        int n = -242;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -8);
        Test.vMeth(bl, n, n);
        nArray[10] = 96;
        vSmallMeth_check_sum += (long)((bl ? 1 : 0) + n) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 20767;
        int n2 = -171;
        int n3 = 53658;
        int n4 = -63109;
        int n5 = -14385;
        int n6 = 3691;
        int n7 = -14208;
        int n8 = 8;
        int n9 = 4;
        int[] nArray = new int[400];
        float f = 16.997f;
        float f2 = -53.762f;
        float f3 = 47.1005f;
        int n10 = -15362;
        double[][][] dArray = new double[400][400][400];
        FuzzerUtils.init(nArray, 73);
        FuzzerUtils.init((Object[][])dArray, (Object)36.7684);
        for (int i = 0; i < 675; ++i) {
            Test.vSmallMeth();
        }
        instanceCount = n;
        f = 172.0f;
        block13: while (true) {
            float f4;
            f -= 2.0f;
            if (!(f4 > 0.0f)) break;
            for (f2 = f; f2 < 291.0f; f2 += 2.0f) {
                dFld -= -4.0;
                n += (int)f2;
                instanceCount += -14L;
                instanceCount = -38L;
                n = n2;
            }
            n += (int)instanceCount;
            n3 = 4;
            while (true) {
                if (n3 >= 291) continue block13;
                for (n5 = 1; n5 < 2; ++n5) {
                    dFld = n4;
                    n2 &= n5;
                    n10 = (short)(n10 + 15259);
                }
                block17: for (n7 = 1; 2 > n7; ++n7) {
                    n6 *= n3;
                    n2 = n10;
                    if (this.bFld) {
                        n4 = (int)instanceCount;
                        n8 += n7;
                        if (!this.bFld) continue;
                        continue;
                    }
                    n = (int)((long)n + ((long)n7 - instanceCount));
                    int n11 = (int)(f + 1.0f);
                    nArray[n11] = nArray[n11] + 10;
                    switch (((n6 += (int)instanceCount) >>> 1) % 10 + 127) {
                        case 127: {
                            dArray[n3 - 1][(int)(f - 1.0f)][n7 - 1] = n6;
                            continue block17;
                        }
                        case 128: {
                            dFld += (double)n7;
                            n4 += n7;
                            continue block17;
                        }
                        case 129: {
                            n4 += -192 + n7 * n7;
                            continue block17;
                        }
                        case 130: {
                            n8 -= n5;
                        }
                        case 131: {
                            int n12 = n3;
                            nArray[n12] = nArray[n12] + n5;
                            continue block17;
                        }
                        case 132: {
                            f3 += (float)instanceCount;
                            continue block17;
                        }
                        case 133: {
                            n6 ^= (int)instanceCount;
                            continue block17;
                        }
                        case 134: {
                            n = byFld;
                            continue block17;
                        }
                        case 135: {
                            instanceCount += (long)n;
                        }
                        case 136: {
                            n2 ^= n3;
                            continue block17;
                        }
                        default: {
                            n9 = (int)((float)n9 + ((float)((long)n7 * instanceCount) + f2 - (float)instanceCount));
                        }
                    }
                }
                ++n3;
            }
            break;
        }
        FuzzerUtils.out.println("i12 f2 f3 = " + n + "," + Float.floatToIntBits(f) + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("i13 i14 i15 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i16 i17 s1 = " + n5 + "," + n6 + "," + n10);
        FuzzerUtils.out.println("i18 i19 f4 = " + n7 + "," + n8 + "," + Float.floatToIntBits(f3));
        FuzzerUtils.out.println("i20 iArr2 dArr = " + n9 + "," + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld = " + byFld);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

