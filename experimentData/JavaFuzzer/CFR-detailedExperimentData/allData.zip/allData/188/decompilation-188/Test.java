/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 3260064452L;
    public volatile int iFld = -42144;
    public static volatile boolean bFld = true;
    public static float fFld = 0.42f;
    public double dFld = -1.40777;
    public static byte byFld = (byte)-85;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = -8;
        int n2 = 18148;
        int n3 = 199;
        int n4 = -4;
        int n5 = 22154;
        float f = 33.128f;
        boolean bl = false;
        long l = 7590L;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 0.2025);
        n = 4850;
        if (bl) {
            f -= (float)n;
        } else {
            n2 = 1;
            while (++n2 < 127) {
                for (n3 = 1; n3 < 12; ++n3) {
                    int n6 = n2 + 1;
                    dArray[n6] = dArray[n6] * (double)n2;
                    n = (int)l;
                    if (n != 0) {
                        vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + (bl ? 1 : 0) + n2 + n3 + n4) + l + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
                        return;
                    }
                    if (bl) continue;
                    n = 9;
                    n5 = 1;
                    do {
                        int n7 = -201;
                        n7 = n = -52591;
                        f += (float)n5;
                    } while (++n5 < 2);
                }
            }
            vMeth1_check_sum += (long)(n + Float.floatToIntBits(f) + (bl ? 1 : 0) + n2 + n3 + n4) + l + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
            return;
        }
        vMeth1_check_sum += (long)((n *= (int)f) + Float.floatToIntBits(f) + (bl ? 1 : 0) + n2 + n3 + n4) + l + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth(int n) {
        int n2 = 53;
        int n3 = -42547;
        int n4 = -10421;
        int n5 = -63;
        int n6 = -168;
        double d = -71.113772;
        float f = -32.553f;
        Test.vMeth1();
        for (n2 = 4; 241 > n2; ++n2) {
            for (d = 1.0; d < 7.0; d += 1.0) {
                n <<= n4;
                if (n2 != 0) {
                    vMeth_check_sum += (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f);
                    return;
                }
                instanceCount += (long)d;
                Test.iArrFld[(int)(d - 1.0)] = n2;
                Test.lArrFld[n2 + 1] = n2;
                n4 >>>= n4;
                try {
                    Test.iArrFld[(int)d] = -803490057 % n3;
                    n4 = 65329 % n4;
                    n3 = n2 % iArrFld[n2 - 1];
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n4 += (int)(d * (double)n2 + (double)n3 - (double)n2);
            }
            for (n5 = 1; n5 < 7; ++n5) {
                Test.iArrFld[n2] = (int)instanceCount;
                n6 <<= n;
                n4 += (int)f;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f);
    }

    public static int iMeth() {
        int n = -30984;
        int n2 = 172;
        int n3 = -78;
        int n4 = 32361;
        int n5 = -22207;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -1.23681);
        Test.vMeth(n);
        n2 = 1;
        while (++n2 < 294) {
            n = n5;
        }
        n = -29776;
        for (n3 = 10; 175 > n3; n3 += 3) {
            Test.iArrFld[n3 + 1] = n3;
            fFld *= (float)(n >>>= -9);
            int n6 = n3 + 1;
            iArrFld[n6] = iArrFld[n6] - n;
        }
        fFld -= 0.177f;
        dArray[(n3 >>> 1) % 400] = n;
        long l = (long)((n += 60544) + n2 + n5 + n3 + n4) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        boolean bl = true;
        float f = 78.393f;
        int n = -4189;
        int n2 = 10;
        int n3 = -20;
        int n4 = 15;
        int n5 = -14;
        int n6 = -80;
        int n7 = -5;
        int n8 = 12;
        bl = this.iFld > this.iFld & bl | (float)Test.iMeth() != f;
        this.dFld = 3.0;
        this.iFld = (int)f;
        n = (short)(n - 6811);
        this.iFld -= this.iFld;
        instanceCount = this.iFld;
        n2 = 1;
        do {
            instanceCount += (long)this.iFld;
        } while ((n2 += 2) < 255);
        this.iFld = -84;
        Test.iArrFld[(n2 >>> 1) % 400] = n2;
        n = (short)(n << (short)this.iFld);
        this.iFld *= n2;
        n3 = 380;
        while ((n3 -= 3) > 0) {
            n4 = 1;
            while (++n4 < 197) {
                instanceCount += (long)(n4 - n4);
                this.iFld += n4 * n4;
                fFld += (float)byFld;
            }
            switch (n3 % 2 + 9) {
                case 9: {
                    Test.lArrFld[n3 + 1] = (long)f;
                    block7: for (n5 = n3; n5 < 197; ++n5) {
                        for (n7 = 1; n7 < 1; ++n7) {
                            f %= 5.0f;
                            this.dFld += this.dFld;
                            this.dFld += (double)this.iFld;
                            if (bFld) continue block7;
                            this.dFld = n4;
                            bl = false;
                            Test.iArrFld[n3] = n6;
                        }
                    }
                    break;
                }
                case 10: {
                    Test.iArrFld[n3 - 1] = n3;
                }
            }
        }
        FuzzerUtils.out.println("b f2 s1 = " + (bl ? 1 : 0) + "," + Float.floatToIntBits(f) + "," + n);
        FuzzerUtils.out.println("i16 i17 i18 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i19 i20 i21 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i22 = " + n8);
        FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld dFld Test.byFld = " + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld) + "," + byFld);
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -129);
        FuzzerUtils.init(lArrFld, 1461668461105384269L);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

