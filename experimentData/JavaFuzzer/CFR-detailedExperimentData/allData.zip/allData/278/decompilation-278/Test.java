/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1351516201L;
    public static int iFld = 218;
    public static double dFld = -43.97286;
    public float fFld = -96.26f;
    public int[] iArrFld = new int[400];
    public boolean[] bArrFld = new boolean[400];
    public static long vMeth_check_sum = 0L;
    public static long byMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(byte by, int n, int n2) {
        int n3 = 57909;
        int n4 = 3520;
        int n5 = 52;
        int n6 = -55162;
        int[] nArray = new int[400];
        float f = 1.63f;
        boolean bl = false;
        FuzzerUtils.init(nArray, -8);
        for (n3 = 3; n3 < 328; ++n3) {
            double d = 0.12976;
            instanceCount = n4;
            f = (float)d;
            block9: for (n5 = 1; 5 > n5; ++n5) {
                n4 += 10;
                switch ((n2 >>> 1) % 6 * 5 + 27) {
                    case 41: {
                        iFld = 20;
                        continue block9;
                    }
                    case 45: {
                        iFld *= 6;
                        n6 *= n4;
                    }
                    case 40: {
                        iFld *= n5;
                        if (bl) continue block9;
                        d = instanceCount;
                        iFld /= n4 | 1;
                    }
                    case 34: {
                        n4 += (int)(35004L + (long)(n5 * n5));
                    }
                    case 57: {
                        instanceCount += (long)n2;
                        continue block9;
                    }
                    case 28: {
                        n6 = (int)instanceCount;
                        continue block9;
                    }
                    default: {
                        n2 *= n6;
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(by + n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + (bl ? 1 : 0)) + FuzzerUtils.checkSum(nArray);
    }

    public static byte byMeth(int n, int n2, int n3) {
        byte by = -100;
        int n4 = -64987;
        int n5 = 13;
        int n6 = -36836;
        int n7 = 84;
        int n8 = -11;
        float f = 12.16f;
        int n9 = 23476;
        long l = 186L;
        long[] lArray = new long[400];
        boolean bl = false;
        FuzzerUtils.init(lArray, 234L);
        Test.vMeth1(by, n, iFld);
        n4 = -48831;
        int n10 = (n >>> 1) % 400;
        lArray[n10] = lArray[n10] + 30L;
        for (f = 7.0f; f < 149.0f; f += 1.0f) {
            n6 = 1;
            while (++n6 < 11) {
                n >>= n6;
            }
            n7 = 1;
            block2: while (++n7 < 11) {
                n2 = -4;
                n9 = (short)dFld;
                for (l = (long)f; l < 1L; ++l) {
                    if (bl) {
                        n4 += (int)l;
                    }
                    if (bl) {
                        instanceCount *= (long)n;
                        n4 <<= 13;
                        continue;
                    }
                    if (bl) {
                        if (!bl) continue;
                        continue;
                    }
                    if (bl) {
                        if (!bl) continue;
                        continue block2;
                    }
                    iFld &= 0x4DEF;
                }
            }
        }
        long l2 = (long)(n + n2 + n3 + by + n4 + Float.floatToIntBits(f) + n5 + n6 + n7 + n9) + l + (long)n8 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(lArray);
        byMeth_check_sum += l2;
        return (byte)l2;
    }

    public static void vMeth(int n, double d) {
        int n2 = 1979;
        int n3 = 1;
        int n4 = -8734;
        int n5 = 55147;
        int n6 = 7;
        int n7 = -10;
        int[] nArray = new int[400];
        boolean bl = true;
        FuzzerUtils.init(nArray, 8);
        int[] nArray2 = nArray;
        nArray = nArray2;
        nArray = nArray2;
        nArray = nArray2;
        nArray[(Test.iFld >>> 1) % 400] = n2 = (int)((short)(n2 - 1));
        n = -(n-- + nArray[241]);
        for (n3 = 10; 183 > n3; ++n3) {
            iFld += n3 * iFld + n4 - n;
            if ((bl = Test.byMeth(9621, iFld *= (int)(instanceCount += (long)(-53498 + n3 * n3)), n4 = (int)((long)n4 + ((long)(n3 * n5) + instanceCount - (long)n3))) != -118) || bl) {
                n5 = iFld;
                continue;
            }
            for (n6 = 1; n6 < 9; ++n6) {
                int n8 = -37;
                n4 = n3;
                n8 = (byte)(n8 * (byte)instanceCount);
                n2 = (short)(n2 * (short)n3);
                iFld &= n4;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -56983;
        int n2 = 0;
        int n3 = -8298;
        int n4 = -13;
        int n5 = -7;
        int n6 = 31206;
        int n7 = 21623;
        int n8 = 94;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 42.116294);
        iFld = iFld-- - iFld;
        n = 1;
        block15: while (++n < 311) {
            switch (n % 6 + 5) {
                case 5: {
                    Test.vMeth(n, dFld);
                }
                case 6: {
                    instanceCount >>= iFld;
                    this.iArrFld = this.iArrFld;
                    iFld += n;
                    continue block15;
                }
                case 7: {
                    for (n2 = 2; n2 < 81; ++n2) {
                        block17: for (n4 = 1; 2 > n4; ++n4) {
                            boolean bl = false;
                            switch (n % 5 * 5 + 6) {
                                case 11: {
                                    n3 <<= -46723;
                                    n5 += n5;
                                    continue block17;
                                }
                                case 29: {
                                    this.bArrFld[n - 1] = bl;
                                    n3 >>= n7;
                                    instanceCount <<= n7;
                                    continue block17;
                                }
                                case 17: {
                                    n5 = (int)((long)n5 + ((long)(n4 * n2) + instanceCount - instanceCount));
                                    continue block17;
                                }
                                case 19: {
                                    n7 = (short)n8;
                                    if (bl) continue block17;
                                    if (bl) {
                                        this.iArrFld = this.iArrFld;
                                        continue block17;
                                    }
                                    if (bl) {
                                        this.iArrFld[n2] = n3;
                                        this.fFld += (float)n6;
                                        n6 %= n | 1;
                                        n3 += -2 + n4 * n4;
                                        continue block17;
                                    }
                                    n7 = (short)instanceCount;
                                    instanceCount = (long)this.fFld;
                                    this.iArrFld[n + 1] = n;
                                    continue block17;
                                }
                                case 28: {
                                    this.fFld += this.fFld;
                                }
                            }
                        }
                    }
                    continue block15;
                }
                case 8: {
                    instanceCount = n6;
                    continue block15;
                }
                case 9: {
                    iFld += n2;
                    continue block15;
                }
                case 10: {
                    n5 <<= n5;
                }
            }
            n7 = (short)(n7 - (short)instanceCount);
        }
        FuzzerUtils.out.println("i i21 i22 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i23 i24 s2 = " + n4 + "," + n5 + "," + n7);
        FuzzerUtils.out.println("by3 i25 dArr = " + n8 + "," + n6 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("fFld iArrFld bArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.bArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

