/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -5L;
    public static byte byFld = (byte)-99;
    public static double dFld = -2.54905;
    public short sFld = (short)-11226;
    public static int[] iArrFld = new int[400];
    public volatile long[][][] lArrFld = new long[400][400][400];
    public static long vMeth_check_sum;
    public static long dMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(long l, int n) {
        int n2 = -250;
        int n3 = 6438;
        int n4 = -51747;
        int n5 = 4;
        int n6 = 112;
        int n7 = -1;
        int n8 = 12;
        int n9 = 208;
        int n10 = 88;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)-72);
        for (n2 = 356; n2 > 20; --n2) {
            for (n4 = 1; n4 < 5; ++n4) {
                n5 &= n5;
                n5 = n2;
                n5 = n4;
                n += n4;
                for (n6 = n4; n6 < 2; ++n6) {
                    n7 = -1401111136;
                }
                l >>>= (n3 += n4 * n4);
                n8 += n4 * n2 + n6 - n5;
                byFld = (byte)-27;
            }
            for (n9 = 1; n9 < 5; ++n9) {
                int n11 = (n2 >>> 1) % 400;
                iArrFld[n11] = iArrFld[n11] | n8;
                int n12 = n2 - 1;
                byArray[n12] = (byte)(byArray[n12] + (byte)n4);
            }
        }
        vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)n10 + FuzzerUtils.checkSum(byArray);
    }

    public static double dMeth(int n, int n2) {
        int n3 = 36754;
        int n4 = -3;
        int n5 = -6;
        int n6 = 53;
        double d = -67.17575;
        float f = -1.27f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -708057116794659751L);
        Test.vMeth1(instanceCount, n);
        n <<= n2;
        n += (int)instanceCount;
        n3 = 1;
        while (++n3 < 205) {
            n2 *= (int)instanceCount;
            n4 = 1;
            do {
                Test.iArrFld[n3 - 1] = -144;
                instanceCount += (long)(n4 - n3);
                for (n5 = 1; n5 < 1; ++n5) {
                    int n7 = n3 - 1;
                    lArray[n7] = lArray[n7] * (long)n5;
                }
                Test.iArrFld[n3] = n3;
                n6 = (int)d;
            } while (++n4 < 8);
            n = (int)((float)n + ((float)(n3 * byFld + n3) - f));
        }
        n2 = -8;
        n2 = byFld;
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(lArray);
        dMeth_check_sum += l;
        return l;
    }

    public static void vMeth(byte by, long l, long l2) {
        int n = 6;
        int n2 = 69;
        int n3 = -61078;
        int n4 = 82;
        int n5 = -22522;
        float f = 115.269f;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -1248685713359125201L);
        int n6 = (n >>> 1) % 400;
        lArray[n6] = lArray[n6] * (long)Test.dMeth(n, n);
        for (n2 = 3; n2 < 206; ++n2) {
            for (n4 = n2; n4 < 8; ++n4) {
                n5 = -7;
                if (bl) {
                    n |= n4;
                    dFld -= (double)n5;
                    n5 += 27919 + n4 * n4;
                    continue;
                }
                if (bl) {
                    Test.iArrFld[n4 + 1] = n5;
                    n3 -= n2;
                    switch (n2 % 1 * 5 + 78) {
                        case 80: {
                            n += n4 * n4;
                            n3 *= n5;
                            Test.iArrFld[n2] = 5;
                            f = 4.0f;
                        }
                    }
                    continue;
                }
                if (!bl) continue;
                f += (float)(-27767 + n4 * n4);
            }
        }
        vMeth_check_sum += (long)by + l + l2 + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -179;
        int n2 = 4;
        int n3 = -26800;
        int n4 = -64239;
        int n5 = 4;
        int n6 = 8;
        boolean bl = false;
        float f = 1.895f;
        long l = -11L;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)14060);
        for (n = 4; 333 > n; ++n) {
            Test.vMeth((byte)-9, instanceCount, instanceCount);
            if (bl) {
                n3 = 1;
                while (++n3 < 76) {
                    n2 = 12;
                    this.lArrFld[n3 + 1][n + 1][n3] = (long)dFld;
                    n2 += n;
                    for (n4 = 1; n4 < 1; ++n4) {
                        instanceCount += (long)n4;
                        instanceCount = (long)dFld;
                        this.sFld = (short)(this.sFld + (short)(n4 | (n2 += 8)));
                        n5 += 6;
                        n5 += n5;
                        f -= (float)(n2 *= (int)instanceCount);
                    }
                    block13: for (l = 1L; l < 1L; ++l) {
                        instanceCount *= (long)n2;
                        n5 += (int)(l * l);
                        if (bl) {
                            switch ((int)(l % 9L + 126L)) {
                                case 126: 
                                case 127: {
                                    n5 += (int)((float)l + (f += (float)n3));
                                    int n7 = (int)(l - 1L);
                                    iArrFld[n7] = iArrFld[n7] + (int)l;
                                    break;
                                }
                                case 128: {
                                    bl = true;
                                    instanceCount += l + (long)n;
                                    break;
                                }
                                case 129: {
                                    break;
                                }
                                case 130: {
                                    n6 = n4;
                                }
                                case 131: {
                                    n2 <<= n2;
                                    break;
                                }
                                case 132: {
                                    instanceCount = byFld;
                                }
                                case 133: {
                                    n6 += (int)((float)(l * l + (long)n5) - f);
                                    break;
                                }
                                case 134: {
                                    if (!bl) continue block13;
                                    break;
                                }
                                default: {
                                    byFld = (byte)(byFld >> (byte)n4);
                                    break;
                                }
                            }
                            continue;
                        }
                        byFld = (byte)(byFld << (byte)n);
                    }
                }
                continue;
            }
            if (bl) {
                Test.iArrFld[n] = (int)instanceCount;
                continue;
            }
            int n8 = n - 1;
            iArrFld[n8] = iArrFld[n8] * n2;
        }
        FuzzerUtils.out.println("i i1 i23 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i24 i25 b1 = " + n4 + "," + n5 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("f2 l3 i26 = " + Float.floatToIntBits(f) + "," + l + "," + n6);
        FuzzerUtils.out.println("sArr = " + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.dFld = " + instanceCount + "," + byFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("sFld Test.iArrFld lArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -2747);
        vMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

