/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -26853L;
    public static byte byFld = (byte)91;
    public static short sFld = (short)22461;
    public static volatile int iFld = -182;
    public static boolean bFld = false;
    public static float fFld = -61.758f;
    public static boolean[] bArrFld = new boolean[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(byte by, int n) {
        int n2 = -647;
        int n3 = -3;
        int n4 = -6123;
        int n5 = 1;
        int n6 = 8981;
        int n7 = 178;
        int n8 = -2;
        int[] nArray = new int[400];
        float f = -2.806f;
        FuzzerUtils.init(nArray, 33462);
        n2 = 1;
        block6: do {
            n += n2 ^ n;
            n /= 215196806;
            sFld = (short)(sFld + (short)((long)n2 * instanceCount + (long)(n >>= 8) - instanceCount));
            f += (float)instanceCount;
            switch (n2 % 2 + 89) {
                case 89: {
                    for (n3 = 1; n3 < 6; ++n3) {
                        n4 |= n3;
                    }
                }
                case 90: {
                    for (n5 = 1; n5 < 6; ++n5) {
                        n7 += (int)f;
                        n8 = 1;
                        do {
                            n6 += n8;
                            try {
                                n7 = nArray[n8 + 1] % -127;
                                nArray[n2 + 1] = n3 / -989867320;
                                n6 = iFld / -476362724;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n6 = n7;
                        } while (++n8 < 2);
                    }
                    continue block6;
                }
                default: {
                    Test.bArrFld[n2 - 1] = bFld;
                }
            }
        } while (++n2 < 274);
        long l = (long)(by + n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6 + n7 + n8) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(long l, int n) {
        int n2 = -3;
        int n3 = 0;
        int n4 = 5;
        int n5 = -16105;
        int n6 = -32;
        int n7 = 31192;
        int[] nArray = new int[400];
        float f = 7.325f;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -21148);
        FuzzerUtils.init(lArray, 9007L);
        for (n2 = 8; 149 > n2; ++n2) {
            byFld = (byte)(byFld * (byte)(Test.iMeth((byte)-20, n) + n));
            n *= -39877;
            n = (int)((long)n + ((long)(n2 * n3 + n3) - l));
            int n8 = n2 + 1;
            nArray[n8] = nArray[n8] + byFld;
            for (n4 = 1; n4 < 11; ++n4) {
                iFld = (int)((long)iFld + ((long)(n4 * n5 + n) - instanceCount));
                n5 += n;
                for (n6 = 1; n6 < 2; ++n6) {
                    int n9 = n2;
                    nArray[n9] = nArray[n9] >> byFld;
                    n5 = n7;
                }
                n7 += (int)f;
                n -= 219;
            }
        }
        vMeth1_check_sum += l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n, long l) {
        long l2 = -2609573023L;
        int n2 = 249;
        int n3 = -2;
        int n4 = -6;
        int n5 = -19773;
        int n6 = 228;
        int n7 = 14;
        int[] nArray = new int[400];
        float f = -1.49f;
        FuzzerUtils.init(nArray, -11);
        Test.vMeth1(instanceCount, n);
        for (l2 = 7L; l2 < 251L; ++l2) {
            iFld -= (int)f;
            instanceCount >>= -2;
        }
        for (n3 = 262; 13 < n3; --n3) {
            fFld += (float)(n3 * n);
        }
        n5 = 1;
        do {
            iFld += n;
            switch (n5 % 1 * 5 + 123) {
                case 127: {
                    for (n6 = 9; n6 > 1; --n6) {
                        n4 = (int)((long)n4 + ((long)(n6 * n4) + l2 - (long)n6));
                        n -= iFld;
                        int n8 = n6 - 1;
                        nArray[n8] = nArray[n8] & n4;
                        iFld = (int)l;
                    }
                }
            }
        } while (++n5 < 172);
        vMeth_check_sum += (long)n + l + l2 + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -5;
        int n2 = -8;
        int n3 = 5700;
        int n4 = -13;
        int n5 = 151;
        int n6 = 56909;
        int n7 = 28700;
        int n8 = 8;
        int[][][] nArray = new int[400][400][400];
        double d = 1.15459;
        FuzzerUtils.init((Object[][])nArray, (Object)0);
        Test.vMeth(45065, instanceCount);
        n = 1;
        block14: do {
            iFld = n;
            instanceCount = -53819L;
            n2 = 1;
            while (++n2 < 72) {
                instanceCount += instanceCount;
                for (n3 = 1; n3 < 1; ++n3) {
                    n4 += n3;
                }
                iFld >>= n4;
            }
            try {
                n4 = iFld % -35808;
                n4 = -33188 % iFld;
                n4 = n2 % 2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            d += -7.0;
            switch (n % 4 + 86) {
                case 86: {
                    d *= -6715.0;
                    break;
                }
                case 87: {
                    n4 = (int)instanceCount;
                    try {
                        nArray[n + 1][n - 1][n - 1] = 8863 % n3;
                        iFld = (n4 /= n2) % 28967;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                case 88: {
                    n4 -= 21;
                    if (bFld) {
                        nArray[n][n - 1][n + 1] = -4;
                        for (n5 = n; n5 < 72; ++n5) {
                            for (n7 = 1; n7 < 1; ++n7) {
                                n6 += n7;
                            }
                            switch (n % 2 + 28) {
                                case 28: {
                                    instanceCount -= (long)n6;
                                }
                                case 29: {
                                    nArray[(n4 >>> 1) % 400][n - 1][n5 + 1] = iFld;
                                    n8 = (int)instanceCount;
                                    n8 = n5;
                                }
                            }
                        }
                        continue block14;
                    }
                    if (!bFld) continue block14;
                    iFld = -4;
                    continue block14;
                }
                case 89: {
                    instanceCount -= (long)n6;
                }
                default: {
                    instanceCount += (long)n7;
                }
            }
        } while (++n < 350);
        FuzzerUtils.out.println("i22 i23 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i25 d i26 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("i27 i28 i29 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum((Object[][])nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + byFld + "," + sFld);
        FuzzerUtils.out.println("Test.iFld Test.bFld Test.fFld = " + iFld + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bArrFld = " + FuzzerUtils.checkSum(bArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(bArrFld, false);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

