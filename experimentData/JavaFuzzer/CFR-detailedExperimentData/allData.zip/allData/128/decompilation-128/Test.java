/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -989642660582499141L;
    public boolean bFld = false;
    public static byte byFld = (byte)-4;
    public float fFld = 118.63f;
    public static volatile float[] fArrFld = new float[400];
    public static double[] dArrFld = new double[400];
    public static int[][] iArrFld = new int[400][400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(int n, int n2) {
        int n3 = -10;
        double d = 2.119435;
        float f = 0.994f;
        n3 = 1;
        while (++n3 < 388) {
            n += n3 * n3;
            d = n3;
            n2 *= (int)f;
            n = (int)((long)n + ((long)n3 + instanceCount));
            n >>= 170;
        }
        long l = (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth() {
        int n = -28;
        int n2 = -46995;
        int n3 = 72;
        int n4 = -3;
        int n5 = -2;
        int n6 = 2;
        int n7 = 0;
        int[] nArray = new int[400];
        double d = 2.55003;
        float f = -2.149f;
        boolean bl = true;
        FuzzerUtils.init(nArray, -69);
        n = n << n--;
        Test.lMeth(-14, n);
        if (bl) {
            for (n2 = 14; n2 < 303; ++n2) {
                for (n4 = 6; n4 > 1; n4 -= 3) {
                    n3 = (int)instanceCount;
                    int n8 = n4;
                    nArray[n8] = nArray[n8] - 1755221272;
                    instanceCount -= instanceCount;
                    d *= 13.0;
                    n5 = (int)instanceCount;
                    d = n5;
                    for (n6 = 1; n6 < 6; ++n6) {
                        instanceCount += (long)n6;
                        f += 22732.0f;
                    }
                }
            }
            vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
            return;
        }
        if (bl) {
            n3 = n2;
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)n6 + (long)n7 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(float f) {
        int n = 83;
        int n2 = 186;
        int n3 = 0;
        int n4 = 179;
        int n5 = 2;
        int n6 = 10;
        int n7 = 0;
        int n8 = -7826;
        double d = -35.37211;
        Test.vMeth();
        for (n = 4; n < 165; ++n) {
            n2 *= n2;
            f = n2 *= n;
            n2 = 50507;
            n2 = (int)((long)n2 + ((long)n - (instanceCount += (long)n8)));
            block11: for (n3 = n; n3 < 10; ++n3) {
                switch (n % 8 + 26) {
                    case 26: {
                        d = 5.0;
                        for (n5 = 1; n5 < 1; n5 += 3) {
                            instanceCount += (long)(n5 * n7);
                            byFld = (byte)(byFld << (byte)n4);
                        }
                        continue block11;
                    }
                    case 27: {
                        n4 += n3;
                        continue block11;
                    }
                    case 28: {
                        n4 *= (int)f;
                        continue block11;
                    }
                    case 29: {
                        n2 *= n6;
                    }
                    case 30: {
                        instanceCount >>>= n5;
                    }
                    case 31: {
                        n7 += n3;
                        continue block11;
                    }
                    case 32: {
                        f += (float)d;
                        continue block11;
                    }
                    case 33: {
                        instanceCount += (long)(n3 * n5 + n7 - n2);
                    }
                }
            }
        }
        long l = (long)(Float.floatToIntBits(f) + n + n2 + n8 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 37890;
        int n2 = 54462;
        int n3 = -9;
        int n4 = 10;
        int n5 = 11;
        int[] nArray = new int[400];
        int n6 = -12741;
        FuzzerUtils.init(nArray, -174);
        this.bFld = 3579882441071966691L * (long)(byFld * n) <= (long)Test.iMeth(this.fFld);
        for (int n7 : nArray) {
            n2 = 1;
            do {
                double d = 1.128552;
                nArray[n2 + 1] = n2;
                d = -105.0;
                for (n3 = 1; 1 > n3; ++n3) {
                    n = (int)((float)n + ((float)n3 + this.fFld));
                    n7 = -32488;
                    if (this.bFld) {
                        n4 = n3;
                        this.fFld += (float)(n3 * n3 + n3 - n4);
                        continue;
                    }
                    nArray[n3 + 1] = n;
                }
                instanceCount = (long)this.fFld;
                n5 = 1;
                do {
                    n4 += n4;
                    n7 = (int)((long)n7 + ((long)(n5 * n + n3) - instanceCount));
                    n7 *= (n -= (int)d);
                    n7 += n5;
                    switch (n2 % 2 + 85) {
                        case 85: {
                            break;
                        }
                        case 86: {
                            d *= (double)instanceCount;
                            break;
                        }
                        default: {
                            n = (int)this.fFld;
                        }
                    }
                    instanceCount += (long)n5 * instanceCount + (long)n3 - (long)n4;
                    this.fFld = this.fFld;
                    this.fFld += (float)(n5 - n6);
                    int n8 = n5 - 1;
                    nArray[n8] = nArray[n8] - 97;
                } while (++n5 < 1);
                int n9 = n2 - 1;
                dArrFld[n9] = dArrFld[n9] + -28675.0;
            } while (++n2 < 63);
        }
        FuzzerUtils.out.println("i i19 i20 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 i22 s1 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount bFld Test.byFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + byFld);
        FuzzerUtils.out.println("fFld Test.fArrFld Test.dArrFld = " + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 85.12f);
        FuzzerUtils.init(dArrFld, -2.71362);
        FuzzerUtils.init(iArrFld, 1);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

