/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1450631406L;
    public static double dFld = 119.83042;
    public static boolean bFld = false;
    public static volatile byte byFld = (byte)103;
    public static volatile long[] lArrFld = new long[400];
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = 3;
        int n2 = -39164;
        int n3 = 137;
        int n4 = -204;
        int n5 = -12;
        int n6 = -13;
        int n7 = -937;
        double d = 0.67195;
        n -= n;
        for (n2 = 9; n2 < 333; ++n2) {
            n3 += n;
            n4 = 1;
            while (++n4 < 5) {
                for (d = 1.0; d < 1.0; d += 1.0) {
                    n5 %= -99;
                    instanceCount += (long)n2;
                    instanceCount += (long)d;
                }
            }
            if (bFld) continue;
            n3 -= 223;
            n5 = (int)instanceCount;
            for (n6 = 1; n6 < 5; ++n6) {
                instanceCount = n6;
            }
            n5 += n2 * n4 + n7 - n7;
        }
        dFld += (double)instanceCount;
        vMeth1_check_sum += (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7;
    }

    public static int iMeth(long l, int n) {
        int n2 = -11;
        int n3 = -80;
        int n4 = -8163;
        int n5 = -19863;
        int n6 = -160;
        float f = 51.948f;
        int n7 = 11005;
        for (n2 = 9; 214 > n2; ++n2) {
            f *= (float)((91L * (long)(n2 + n7) + (long)n3) * 14106L);
            n4 = 1;
            while (++n4 < 8) {
                Test.vMeth1();
                for (n5 = 1; n5 < 1; ++n5) {
                    int n8 = n2 + 1;
                    iArrFld[n8] = iArrFld[n8] + n7;
                    n3 = (int)instanceCount;
                    n6 += n5 * n5;
                    n = (int)instanceCount;
                    n6 -= (n3 >>= (n += n5));
                    if (!bFld) continue;
                }
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f) + (long)n7 + (long)n4 + (long)n5 + (long)n6;
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth(long l, int n, long l2) {
        int n2 = 8074;
        int n3 = -5;
        int n4 = 22163;
        int n5 = -21607;
        int n6 = 4;
        int n7 = 5;
        int n8 = -11307;
        int[] nArray = new int[400];
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        int n9 = -109;
        float[][][] fArray = new float[400][400][400];
        FuzzerUtils.init(nArray, -51910);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(51.22f));
        FuzzerUtils.init(blArray, false);
        int n10 = nArray[4];
        nArray[4] = n10 - 1;
        n -= (int)((double)n2 + (double)n * dFld - (double)n10);
        for (n3 = 4; n3 < 190; ++n3) {
            if (!bl) continue;
            for (n5 = 9; n5 > 1; n5 -= 3) {
                n9 = (byte)(n9 + (byte)(16999 + n5 * n5));
                for (n7 = 5; n7 > n5; --n7) {
                    fArray[n7 - 1][n5][n7 + 1] = (long)n - ++l2;
                    bl = n-- <= n4 + Test.iMeth(l, n6);
                    l *= (long)n5;
                    try {
                        n4 = 95 / n;
                        Test.iArrFld[n5 + 1] = iArrFld[n5 + 1] / -8809;
                        n4 = 1112982427 / n4;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n6 = n3;
                    n8 += 36;
                }
                n4 += n5 * n5;
                n <<= 0;
            }
        }
        vMeth_check_sum += l + (long)n + l2 + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5 + (long)n6 + (long)n9 + (long)n7 + (long)n8 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)) + FuzzerUtils.checkSum(blArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -202;
        int n2 = -3770;
        int n3 = -131;
        int n4 = 72;
        int n5 = 217;
        int n6 = 41262;
        int n7 = 52563;
        int n8 = 146;
        int n9 = 10;
        int n10 = -41757;
        int n11 = 1373;
        n -= 14;
        n ^= (int)lArrFld[(n >>> 1) % 400];
        for (n2 = 245; 15 < n2; --n2) {
            float f = 1.48f;
            n3 = (int)instanceCount;
            Test.vMeth(instanceCount, n3, instanceCount);
            if (bFld) continue;
            n3 = (int)f;
            instanceCount = (long)dFld;
            byFld = (byte)(byFld + (byte)f);
            f *= 6.0f;
            n8 = 1;
            do {
                instanceCount += (long)n7;
                f = n11;
                for (n9 = 1; 1 > n9; ++n9) {
                    n *= n;
                    Test.iArrFld[n8 - 1] = (int)instanceCount;
                    n5 = (int)((float)n5 + ((float)((long)n9 * instanceCount + instanceCount) - f));
                    instanceCount >>= n3;
                }
            } while (++n8 < 109);
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i23 i24 s2 = " + n4 + "," + n5 + "," + n11);
        FuzzerUtils.out.println("i25 i26 i27 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i28 i29 = " + n9 + "," + n10);
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld Test.lArrFld Test.iArrFld = " + byFld + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 180L);
        FuzzerUtils.init(iArrFld, -2);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

