/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 970087989L;
    public static float fFld = 23.629f;
    public static byte byFld = (byte)-4;
    public static boolean bFld = true;
    public static long[] lArrFld = new long[400];
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long bMeth_check_sum;

    public static boolean bMeth() {
        int n = -42;
        int n2 = 5;
        int n3 = 12664;
        int n4 = -56065;
        int n5 = 16886;
        int n6 = -156;
        int n7 = 21107;
        int[][] nArray = new int[400][400];
        FuzzerUtils.init(nArray, 61);
        int n8 = (n >>> 1) % 400;
        lArrFld[n8] = lArrFld[n8] + (long)n;
        instanceCount += (long)n;
        n = (int)instanceCount;
        n2 = 1;
        do {
            nArray[n2][n2 + 1] = 29268;
        } while (++n2 < 356);
        for (n3 = 14; n3 < 263; ++n3) {
            instanceCount = n4;
            fFld -= (float)instanceCount;
            for (n5 = 1; 7 > n5; ++n5) {
                try {
                    n = n2 / n3;
                    nArray[n3 - 1][n5] = 135 % n5;
                    n6 = nArray[n5 - 1][n3] / nArray[n3 + 1][n5];
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n6 = -116;
                n7 -= n7;
                n7 <<= (int)instanceCount;
                n6 = n2;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public static void vMeth(int n) {
        int n2 = 43001;
        int n3 = -5;
        int n4 = -18838;
        int n5 = -132;
        int n6 = 165;
        int[][] nArray = new int[400][400];
        float f = -52.108f;
        FuzzerUtils.init(nArray, 5);
        for (n2 = 208; n2 > 6; n2 -= 3) {
            int n7 = 22006;
            n = (int)((long)n + ((long)(n2 * n3 + n) - instanceCount));
            n3 -= (int)((float)instanceCount + f);
            long l = --instanceCount - (long)(++n);
            --n;
            n = (int)(l + (long)n);
            if (Test.bMeth()) {
                if (n3 != 0) {
                    vMeth_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray);
                    return;
                }
                n3 = n = n - n++;
                n3 = Integer.reverseBytes(n3);
                n7 = (short)(n7 * (short)instanceCount);
            }
            for (n4 = 1; n4 < 23; ++n4) {
                int[] nArray2 = nArray[n4 - 1];
                int n8 = n4;
                nArray2[n8] = nArray2[n8] - n4;
                n6 = 1;
                do {
                    n5 <<= -122;
                    fFld = instanceCount;
                    instanceCount = n6;
                } while (++n6 < 2);
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(double d, int n) {
        int n2 = -166;
        int n3 = 9;
        int n4 = -1;
        int n5 = 5;
        int n6 = 6;
        int n7 = 24433;
        int[] nArray = new int[400];
        boolean bl = true;
        long l = -1234202050064652872L;
        FuzzerUtils.init(nArray, 11);
        n = (int)instanceCount;
        Test.vMeth(n);
        byFld = (byte)(byFld - -31);
        block4: for (n2 = 309; n2 > 6; n2 -= 3) {
            switch ((n2 >>> 1) % 2 * 5 + 102) {
                case 109: {
                    bl = true;
                    continue block4;
                }
                case 110: {
                    n7 += (n3 += n);
                    continue block4;
                }
                default: {
                    l *= (long)n4;
                }
            }
        }
        long l2 = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + (long)(bl ? 1 : 0) + (long)n4 + (long)n5 + (long)n6 + (long)n7 + l + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -3;
        int n2 = 28;
        int n3 = 9;
        int n4 = -46591;
        int n5 = -10;
        int n6 = -7;
        int n7 = 61;
        long l = 30031L;
        int n8 = 24496;
        try {
            n += Integer.reverseBytes(Test.iMeth(22.111932, n));
            instanceCount -= (long)n;
            instanceCount = n;
        }
        catch (UserDefinedExceptionTest userDefinedExceptionTest) {
            for (l = 4L; 240L > l; ++l) {
                n2 -= n2;
            }
            for (n3 = 9; 231 > n3; ++n3) {
                n4 <<= -8;
                n = (int)((float)n + ((float)n3 * fFld + (float)n - (float)instanceCount));
                n -= (int)instanceCount;
            }
            n2 = -34601;
            n5 = 1;
            do {
                n2 = n3;
                n8 = (short)(n8 + (short)((long)n5 | (long)fFld));
                for (n6 = n5; n6 < 73; ++n6) {
                    iArrFld = FuzzerUtils.int1array(400, 61056);
                    n8 = (short)n2;
                }
            } while (++n5 < 346);
        }
        n8 = (short)(n8 * (short)n);
        FuzzerUtils.out.println("i l1 i22 = " + n + "," + l + "," + n2);
        FuzzerUtils.out.println("i23 i24 i25 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("s1 i26 i27 = " + n8 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("Test.bFld Test.lArrFld Test.iArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 0L);
        FuzzerUtils.init(iArrFld, -200);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
    }
}

