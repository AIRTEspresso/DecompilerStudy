/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 119L;
    public float fFld = 0.86f;
    public volatile double dFld = 1.1487;
    public byte byFld = (byte)-100;
    public int iFld = -12;
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public void vMeth1() {
        int n = 25239;
        int n2 = 185;
        int n3 = -31917;
        int n4 = -13;
        int n5 = 115;
        long l = 173L;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 8L);
        this.iFld = this.iFld;
        n = 1;
        do {
            this.iFld %= n | 1;
            this.iFld >>>= (int)(instanceCount <<= -43505);
            n5 = (byte)n;
            this.iFld += 54123;
            int n6 = n + 1;
            lArray[n6] = lArray[n6] - (long)this.fFld;
            this.iFld >>= (int)instanceCount;
            this.iFld -= (int)instanceCount;
            instanceCount = this.iFld;
        } while (++n < 355);
        for (n2 = 375; n2 > 18; n2 -= 3) {
            for (l = 1L; l < 13L; ++l) {
                n3 &= (int)l;
                n4 += 1533772819;
            }
        }
        vMeth1_check_sum += (long)(n + n5 + n2 + n3) + l + (long)n4 + FuzzerUtils.checkSum(lArray);
    }

    public int iMeth(float f, int n, int n2) {
        long l = 322988233L;
        long[] lArray = new long[400];
        int n3 = 39944;
        int n4 = 166;
        FuzzerUtils.init(lArray, -34428L);
        this.vMeth1();
        for (l = 20L; l < 357L; ++l) {
            int n5 = (int)(l - 1L);
            this.iArrFld[n5] = this.iArrFld[n5] - (int)l;
            n4 = 1;
            while (++n4 < 5) {
                int n6 = n4 - 1;
                this.iArrFld[n6] = this.iArrFld[n6] - this.iFld;
                lArray[(int)l] = n2;
                n *= (int)this.dFld;
                this.iFld = n3;
                instanceCount = (long)this.fFld;
                n2 += n2;
            }
            n3 ^= 0xFFFFFFA0;
            n3 = (int)l;
            this.iFld = (int)l;
            n2 = (int)instanceCount;
        }
        this.byFld = (byte)n;
        long l2 = (long)(Float.floatToIntBits(f) + n + n2) + l + (long)n3 + (long)n4 + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void vMeth(long l, long l2, int n) {
        double d = 38.125686;
        int n2 = -28390;
        int n3 = -57210;
        int n4 = 4;
        int n5 = 27585;
        int n6 = 104;
        int n7 = 8266;
        int[] nArray = new int[400];
        int[] nArray2 = new int[400];
        FuzzerUtils.init(nArray, -136);
        FuzzerUtils.init(nArray2, 46784);
        for (d = 3.0; d < 194.0; d += 1.0) {
            if (!((float)instanceCount >= this.fFld)) continue;
        }
        for (n3 = 12; n3 < 365; ++n3) {
            int n8 = n3 - 1;
            int n9 = nArray[n8];
            nArray[n8] = n9 - 1;
            this.dFld -= (double)n9;
            for (n5 = 1; n5 < 5; ++n5) {
                l2 += (long)(n5 * n2) + l2 - (long)this.byFld;
                this.fFld *= (float)(--instanceCount + (long)(-this.iMeth(this.fFld, n7, n3)));
                n += n5 * n6;
                int n10 = n3 + 1;
                nArray2[n10] = nArray2[n10] << n7;
                n2 += n5 ^ n5;
                n2 = 10;
                n += (int)this.fFld;
                this.iFld += n5;
                l += (long)n5;
                l = n4;
            }
        }
        vMeth_check_sum += l + l2 + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(nArray2);
    }

    public void mainTest(String[] stringArray) {
        int n = -200;
        int n2 = 240;
        int n3 = 208;
        int n4 = -26960;
        boolean bl = false;
        double d = -99.123034;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 13L);
        this.vMeth(instanceCount, instanceCount, this.iFld);
        this.fFld *= (float)this.dFld;
        this.fFld = -71.0f;
        instanceCount -= 28707L;
        this.iArrFld = this.iArrFld;
        this.dFld -= (double)0.666f;
        this.iFld *= this.iFld;
        this.iFld = -3;
        ++this.iFld;
        n = 1;
        while (++n < 319) {
            instanceCount *= (long)n;
            this.fFld = n4;
            n2 = 1;
            while (++n2 < 79) {
                this.iFld += n2 + n2;
                if (!bl) continue;
            }
            instanceCount -= (long)n2;
            d = this.fFld;
            this.iArrFld[n + 1] = n2;
            this.iFld -= n2;
            bl = true;
            lArray[n] = 98L;
            this.iFld += n ^ n4;
        }
        this.iFld *= this.iFld;
        n3 = 1;
        while (++n3 < 167) {
            try {
                this.iFld = 69748159 / this.iArrFld[n3];
                this.iFld = this.iArrFld[(this.iFld >>> 1) % 400] % -11;
                this.iFld = 31025 % n3;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            this.iFld = this.iFld;
            this.fFld += (float)n;
            instanceCount -= -82L;
            this.iFld -= -36391;
            instanceCount *= (long)this.byFld;
        }
        FuzzerUtils.out.println("i15 s i16 = " + n + "," + n4 + "," + n2);
        FuzzerUtils.out.println("b d1 i17 = " + (bl ? 1 : 0) + "," + Double.doubleToLongBits(d) + "," + n3);
        FuzzerUtils.out.println("lArr2 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount fFld dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("byFld iFld iArrFld = " + this.byFld + "," + this.iFld + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

