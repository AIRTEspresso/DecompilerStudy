/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -172524961L;
    public static double dFld = -49.11037;
    public static double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2() {
        int n = 21596;
        instanceCount -= (long)n;
        vMeth2_check_sum += (long)n;
    }

    public static void vMeth1() {
        int n = -8;
        int n2 = 167;
        int n3 = 69;
        int n4 = 5;
        int[][] nArray = new int[400][400];
        float f = 8.437f;
        int n5 = 32209;
        FuzzerUtils.init(nArray, 3);
        n |= n;
        n2 = 1;
        while (++n2 < 288) {
            Test.vMeth2();
            n *= (int)f;
            instanceCount = n2;
            dFld -= dFld;
            n5 = (short)(n5 + (short)((long)n2 * instanceCount + (long)n5 - (long)n2));
            f *= (float)n2;
        }
        int[] nArray2 = nArray[(n >>> 1) % 400];
        int n6 = (n2 >>> 1) % 400;
        nArray2[n6] = nArray2[n6] | n2;
        for (n3 = 16; n3 < 345; ++n3) {
            instanceCount -= -12L;
            instanceCount = 5L;
        }
        instanceCount >>= n3;
        vMeth1_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n5 + n3 + n4) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth() {
        int n = 126;
        int n2 = 40630;
        int n3 = 3;
        int n4 = -130;
        int n5 = 39783;
        int n6 = -4301;
        int n7 = -5;
        int n8 = 9;
        float f = 0.748f;
        boolean bl = true;
        n %= (int)((long)((float)n2++ - f) | 1L);
        Test.vMeth1();
        for (n3 = 1; 271 > n3; ++n3) {
            dFld += (double)instanceCount;
            block4: for (n5 = 1; n5 < 6; ++n5) {
                switch (n3 % 1 + 59) {
                    case 59: {
                        for (n7 = 2; n7 > n5; n7 -= 3) {
                            f = n8;
                            n6 += n2;
                            f += 6.0f;
                            bl = true;
                        }
                        if (n7 == 0) continue block4;
                        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + (bl ? 1 : 0) + n3 + n4 + n5 + n6 + n7 + n8);
                        return;
                    }
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + (bl ? 1 : 0) + n3 + n4 + n5 + n6 + n7 + n8);
    }

    public void mainTest(String[] stringArray) {
        int n = 7;
        int n2 = -107;
        int n3 = -16652;
        int n4 = 210;
        int n5 = -10;
        int n6 = -28026;
        int n7 = -7;
        int n8 = -134;
        int[] nArray = new int[400];
        float f = -2.213f;
        float f2 = 117.753f;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -52);
        FuzzerUtils.init(lArray, 4273287049834774936L);
        n = 1;
        do {
            int n9 = n;
            int n10 = nArray[n9] + 1;
            nArray[n9] = n10;
            n2 *= (int)((double)n10 - (double)f * dFld * (double)((long)n2 - instanceCount));
            nArray[n] = (int)instanceCount;
            if (Math.max((long)(dFld * (double)instanceCount), (long)(n2++ * nArray[n])) != (long)n2++) continue;
            Test.vMeth();
            try {
                n2 = -13135 % n;
                n2 = 3139 % n2;
                n2 = n % -27682;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        } while (++n < 382);
        n2 = 111;
        n2 <<= n2;
        n2 *= n2;
        f *= (float)n;
        for (n3 = 9; n3 < 178; ++n3) {
            int n11 = n3 + 1;
            nArray[n11] = nArray[n11] << (int)instanceCount;
            n4 = 101;
            n5 = 1;
            while (++n5 < 148) {
                f *= -6.0f;
            }
            lArray[n3] = (long)f;
            for (n6 = 7; n6 < 148; ++n6) {
                n2 += -5 + n6 * n6;
                n2 -= n2;
                instanceCount += (long)(n6 + n7);
                f *= 8.0f;
            }
            n8 = 1;
            while (++n8 < 148) {
                f2 -= f;
            }
            instanceCount = n;
            int n12 = n3 - 1;
            nArray[n12] = nArray[n12] + 11;
        }
        FuzzerUtils.out.println("i i1 f = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i14 i15 i16 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i17 i18 i19 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("f3 iArr lArr = " + Float.floatToIntBits(f2) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.dArrFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, -53.37468);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

