/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2548559245571105894L;
    public volatile float fFld = 0.247f;
    public static float fFld1 = 52.1023f;
    public static volatile long lFld = -13L;
    public long lFld1 = -252L;
    public static int[][] iArrFld = new int[400][400];
    public static volatile long[][] lArrFld = new long[400][400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static int iMeth(int n, boolean bl, int n2) {
        float f = -12.784f;
        int n3 = -221;
        int n4 = 1;
        int n5 = -50464;
        instanceCount |= (long)Math.abs(n2--);
        for (f = 292.0f; 18.0f < f; f -= 1.0f) {
            n4 = 6;
            while (n4 > 1) {
                int[] nArray = iArrFld[(int)(f + 1.0f)];
                int n6 = n4--;
                nArray[n6] = nArray[n6] - (int)instanceCount;
            }
        }
        long l = n + (bl ? 1 : 0) + n2 + Float.floatToIntBits(f) + n3 + n4 + n5;
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth2(float f, long l) {
        int n = -27693;
        int n2 = -8861;
        int n3 = -11554;
        int n4 = -11;
        int n5 = 5;
        int n6 = -8;
        int n7 = -50961;
        double d = 0.114156;
        boolean bl = false;
        boolean bl2 = false;
        for (n = 11; n < 363; ++n) {
            n2 = (int)d;
            d += (double)instanceCount;
            n3 = 1;
            do {
                for (n4 = 1; n < n4; n4 -= 2) {
                    int[] nArray = iArrFld[n3 - 1];
                    int n8 = n4 + 1;
                    nArray[n8] = nArray[n8] + 14;
                    n5 = n2 = n4;
                }
            } while (++n3 < 5);
            d = l;
            bl = bl2;
            n5 = (int)((long)n5 + ((long)n | instanceCount));
            for (n6 = 5; n6 > 1; --n6) {
                l -= (long)n2;
                n2 -= (int)f;
                int[] nArray = iArrFld[n - 1];
                int n9 = n6 - 1;
                nArray[n9] = nArray[n9] * n4;
            }
        }
        vMeth2_check_sum += (long)Float.floatToIntBits(f) + l + (long)n + (long)n2 + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)(bl2 ? 1 : 0) + (long)n6 + (long)n7;
    }

    public static void vMeth1() {
        int n = -43282;
        int n2 = -11;
        int n3 = 33817;
        int n4 = 206;
        int n5 = -21;
        int n6 = -27158;
        boolean[] blArray = new boolean[400];
        float[] fArray = new float[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(fArray, -1.732f);
        FuzzerUtils.init(dArray, 1.4055);
        Test.vMeth2(fFld1, instanceCount);
        block26: for (n = 2; n < 197; ++n) {
            try {
                n2 = -35744 / n;
                n2 = n % iArrFld[n][n - 1];
                n2 = -478950232 % iArrFld[n][n + 1];
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            for (n3 = n; n3 < 8; ++n3) {
                long[] lArray = lArrFld[n3 - 1];
                int n7 = n3 - 1;
                lArray[n7] = lArray[n7] - (long)n6;
            }
            if (n2 != 0) {
                vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n6 + n5) + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
                return;
            }
            n4 = n6;
            switch ((n2 >>> 1) % 10 + 82) {
                case 82: {
                    n4 = n3;
                    switch ((n4 >>> 1) % 10 * 5 + 20) {
                        case 24: {
                            instanceCount *= (long)fFld1;
                            blArray[n] = false;
                            break;
                        }
                        case 65: {
                            n2 += n;
                            instanceCount += (long)(-13856 + n * n);
                            n2 += n3;
                        }
                        case 39: {
                            n2 <<= n2;
                            break;
                        }
                        case 51: {
                            n4 = n2;
                            break;
                        }
                        case 42: {
                            n2 -= 1762287415;
                            break;
                        }
                        case 63: {
                            n6 = (short)(n6 >>> 7);
                        }
                        case 47: {
                            n2 |= n6;
                        }
                        case 45: {
                            fFld1 *= (float)n2;
                            break;
                        }
                        case 28: {
                            fArray[n - 1] = instanceCount;
                            break;
                        }
                        default: {
                            n4 += n ^ n3;
                        }
                    }
                }
                case 83: {
                    dArray[n] = n4;
                }
                case 84: {
                    if (n2 == 0) continue block26;
                    vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n6 + n5) + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
                    return;
                }
                case 85: {
                    n4 = n;
                    continue block26;
                }
                case 86: {
                    n5 = -10;
                    continue block26;
                }
                case 87: 
                case 88: {
                    fFld1 += 2.52465971E9f;
                    continue block26;
                }
                case 89: {
                    try {
                        n4 = iArrFld[n - 1][n + 1] % n3;
                        Test.iArrFld[n + 1][n] = 45858 / n2;
                        n5 = n % -1804673463;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    continue block26;
                }
                case 90: {
                    n2 >>= n4;
                    continue block26;
                }
                case 91: {
                    n2 *= (int)fFld1;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n6 + n5) + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth() {
        int n = 5;
        int n2 = 11;
        int n3 = 234;
        int n4 = 50095;
        int n5 = 27996;
        int[] nArray = new int[400];
        float f = -1.341f;
        double d = -2.60442;
        long[][] lArray = new long[400][400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(lArray, -138L);
        FuzzerUtils.init(nArray, -9);
        FuzzerUtils.init(blArray, false);
        for (n = 19; n < 335; ++n) {
            long[] lArray2 = lArray[n];
            int n6 = n;
            long l = lArray2[n6];
            lArray2[n6] = l - 1L;
            n2 = (int)((float)instanceCount - (f - (float)l));
            try {
                n2 = n % n2;
                nArray[n] = n2 / 1;
                n2 %= n2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n2 = n2 - Test.iMeth((int)((long)n + instanceCount / (long)(n | 1)), blArray[n + 1], -n2--);
            Test.vMeth1();
            instanceCount *= (long)n;
            n2 = 199;
            n2 *= n2;
            d += (double)n;
        }
        n3 = 1;
        while ((n3 += 2) < 350) {
            for (n4 = 1; n4 < 9; ++n4) {
                n2 -= n4;
                n2 <<= (int)(instanceCount += -15974L);
                n2 -= (int)instanceCount;
            }
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(blArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 4;
        int n2 = -5;
        int n3 = 0;
        int n4 = 27922;
        int n5 = -53;
        int n6 = 203;
        int n7 = 5445;
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        double d = -2.9433;
        int n8 = 64;
        int n9 = -13347;
        FuzzerUtils.init(blArray, false);
        n = 1;
        for (n2 = 3; n2 < 381; ++n2) {
            for (n4 = 1; n4 < 2; ++n4) {
                this.fFld += (float)n4 - this.fFld;
                this.fFld += (float)((long)n4 + instanceCount);
                if (bl) break;
                bl = blArray[n2] = bl;
            }
            Test.vMeth();
            for (n6 = n; n6 < 2; ++n6) {
                d = n8;
                this.fFld += (float)n6;
                int[] nArray = iArrFld[n - 1];
                int n10 = n6 + 1;
                nArray[n10] = nArray[n10] % (n5 | 1);
                switch (n2 % 4 * 5 + 73) {
                    case 84: {
                        n7 <<= (int)instanceCount;
                        n3 += n6;
                        break;
                    }
                    case 92: {
                        n7 >>= n8;
                        int[] nArray2 = iArrFld[n2 - 1];
                        int n11 = n;
                        nArray2[n11] = nArray2[n11] * 1910181863;
                        break;
                    }
                    case 77: {
                        lFld = (long)((float)lFld + ((float)n6 * fFld1 + (float)n7 - (float)this.lFld1));
                        break;
                    }
                    case 81: {
                        if (bl) break;
                        n3 += n;
                        int[] nArray3 = iArrFld[n6 + 1];
                        int n12 = n2 + 1;
                        nArray3[n12] = nArray3[n12] ^ n2;
                        break;
                    }
                    default: {
                        n5 = n9;
                    }
                }
                n5 += n2;
                blArray[n6 + 1] = bl;
                n7 -= n4;
                n3 = (int)instanceCount;
            }
            fFld1 *= 32.0f;
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 i4 b = " + n4 + "," + n5 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i27 i28 d2 = " + n6 + "," + n7 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("by s1 bArr = " + n8 + "," + n9 + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount fFld Test.fFld1 = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Float.floatToIntBits(fFld1));
        FuzzerUtils.out.println("Test.lFld lFld1 Test.iArrFld = " + lFld + "," + this.lFld1 + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -166);
        FuzzerUtils.init(lArrFld, -95L);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

