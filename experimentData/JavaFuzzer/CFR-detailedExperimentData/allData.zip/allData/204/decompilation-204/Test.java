/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3981599709L;
    public static int iFld = -11;
    public byte byFld = (byte)-35;
    public static double dFld = -94.5653;
    public short sFld = (short)18050;
    public static int[] iArrFld = new int[400];
    public int[] iArrFld1 = new int[400];
    public float[] fArrFld = new float[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(int n, int n2, int n3) {
        int n4 = -13;
        int n5 = -219;
        int n6 = -31463;
        int n7 = -45;
        float f = 89.338f;
        float[] fArray = new float[400];
        float[] fArray2 = new float[400];
        int n8 = 58;
        double d = 62.6696;
        double[] dArray = new double[400];
        FuzzerUtils.init(fArray, -40.14f);
        FuzzerUtils.init(fArray2, -2.17f);
        FuzzerUtils.init(dArray, 0.54139);
        switch ((n3 >>> 1) % 9 * 5 + 51) {
            case 79: {
                n4 = 1;
                do {
                    fArray[n4 + 1] = f;
                    for (n5 = 1; n5 < 12; ++n5) {
                        n3 >>= n;
                        instanceCount -= (long)n;
                        n7 = 1;
                        while (++n7 < 2) {
                            fArray2[n7 - 1] = n8;
                            if (n4 != 0) {
                                // empty if block
                            }
                            instanceCount >>= (int)instanceCount;
                            instanceCount = iFld;
                            int n9 = n7 + 1;
                            dArray[n9] = dArray[n9] - (double)n7;
                            iFld = -82;
                            instanceCount += instanceCount;
                        }
                    }
                } while (++n4 < 131);
                break;
            }
            case 96: {
                n2 >>= n5;
                break;
            }
            case 89: {
                n2 -= n;
                break;
            }
            case 86: {
                int n10 = (n3 >>> 1) % 400;
                fArray2[n10] = fArray2[n10] + (float)instanceCount;
            }
            case 63: {
                Test.iArrFld[45] = 69954769;
                break;
            }
            case 75: {
                d += (double)n;
                break;
            }
            case 72: {
                Test.iArrFld[(n5 >>> 1) % 400] = n6;
                break;
            }
            case 93: {
                n6 = n8;
                break;
            }
            case 53: {
                n = n4;
            }
            default: {
                Test.iArrFld[(n6 >>> 1) % 400] = -20974;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + n7 + n8) + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray2)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth(float f) {
        Test.iArrFld[(Test.iFld >>> 1) % 400] = (int)Test.lMeth(iFld, iFld, iFld);
        vMeth_check_sum += (long)Float.floatToIntBits(f);
    }

    public static int iMeth(long l, long l2, int n) {
        float f = -2.233f;
        boolean bl = true;
        int n2 = -100;
        n -= (int)((long)(++iFld) * (-15174L + l * (long)n));
        if (bl) {
            int n3 = (iFld >>> 1) % 400;
            int n4 = iArrFld[n3] + 1;
            iArrFld[n3] = n4;
            instanceCount <<= n4;
        } else if (bl) {
            Test.vMeth(f);
            n += iFld;
            dFld = iFld;
        } else {
            iFld = n;
            n2 = (byte)(n2 + (byte)f);
            iFld *= 3478;
            Test.iArrFld[8] = n;
        }
        int n5 = (iFld >>> 1) % 400;
        iArrFld[n5] = iArrFld[n5] << 16986;
        long l3 = l + l2 + (long)n + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + (long)n2;
        iMeth_check_sum += l3;
        return (int)l3;
    }

    public void mainTest(String[] stringArray) {
        float f = -2.135f;
        int n = -5;
        int n2 = -41868;
        int n3 = -9;
        int n4 = 185;
        int n5 = -51621;
        int n6 = 226;
        int n7 = 2081;
        int[][] nArray = new int[400][400];
        boolean bl = true;
        double[] dArray = new double[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 1);
        FuzzerUtils.init(dArray, 113.58021);
        FuzzerUtils.init(lArray, 698108647L);
        byte by = this.byFld;
        this.byFld = (byte)(by - 1);
        iFld -= by;
        iFld = Test.iMeth(4445328316377560012L, instanceCount, -50883);
        instanceCount *= (long)iFld;
        f += (float)iFld;
        int n8 = (iFld >>> 1) % 400;
        this.iArrFld1[n8] = this.iArrFld1[n8] + -906;
        this.fArrFld = this.fArrFld;
        for (n = 6; n < 347; ++n) {
            instanceCount += (long)n2;
            iFld += -248 + n * n;
        }
        this.sFld = (short)(this.sFld + (short)iFld);
        n3 = 1;
        while (++n3 < 226) {
            dArray[n3 + 1] = iFld;
            block0 : switch (n3 % 2 + 33) {
                case 33: {
                    for (n4 = 3; 111 > n4; ++n4) {
                        n5 = 8;
                        int n9 = n3 - 1;
                        iArrFld[n9] = iArrFld[n9] - 1613785836;
                        iFld *= n;
                        if (bl) break block0;
                        for (n6 = 2; n6 > 1; --n6) {
                            nArray[n6] = this.iArrFld1;
                            iFld = (int)((float)iFld + ((float)((long)n6 * instanceCount + (long)iFld) - f));
                            iFld >>= -47;
                            f += (float)(-140 + n6 * n6);
                            n2 += n6 | (n5 += (int)(instanceCount >>= n2));
                        }
                    }
                    break;
                }
                case 34: {
                    lArray[n3 - 1] = n7;
                }
            }
        }
        FuzzerUtils.out.println("f3 i9 i10 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i11 b1 i12 = " + n3 + "," + (bl ? 1 : 0) + "," + n4);
        FuzzerUtils.out.println("i13 i14 i15 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("iArr1 dArr1 lArr = " + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld byFld = " + instanceCount + "," + iFld + "," + this.byFld);
        FuzzerUtils.out.println("Test.dFld sFld Test.iArrFld = " + Double.doubleToLongBits(dFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iArrFld1 fArrFld = " + FuzzerUtils.checkSum(this.iArrFld1) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 34598);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

