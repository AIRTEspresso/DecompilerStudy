/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -3L;
    public static double dFld = -85.81815;
    public static byte byFld = (byte)86;
    public static float fFld = 117.644f;
    public short sFld = (short)-15762;
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n, int n2, int n3) {
        int n4 = 110;
        int n5 = 2;
        int n6 = -141;
        int n7 = 42;
        int n8 = 5;
        int n9 = 35442;
        int n10 = 2;
        int n11 = -10467;
        double d = 28.83515;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 2916952361270809038L);
        n4 = (byte)(n4 * (byte)n2);
        for (n5 = 7; n5 < 179; ++n5) {
            instanceCount = n6;
            for (n7 = 1; n7 < 9; ++n7) {
                for (n9 = 1; n9 < 2; ++n9) {
                    instanceCount += (long)(n9 - n6);
                }
                n6 = n11;
                Test.iArrFld[n7] = (int)instanceCount;
                int n12 = n7 + 1;
                lArray[n12] = lArray[n12] + (long)n8;
                d *= (double)n5;
                n3 += 127;
            }
        }
        n8 += 48331;
        instanceCount = n3;
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + (n8 >>= n) + n9 + n10 + n11) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(int n, short s, int n2) {
        int n3 = 74;
        int n4 = -1;
        int n5 = 184;
        int n6 = -21;
        int n7 = -18597;
        int n8 = -121;
        boolean bl = false;
        float f = -120.945f;
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(fArray, 57.381f);
        FuzzerUtils.init(lArray, -32798L);
        switch (((0xFFFF5BE1 & n) >>> 1) % 6 * 5 + 97) {
            case 112: {
                int n9 = (n2 >>> 1) % 400;
                fArray[n9] = fArray[n9] - (float)Math.abs(n++ * Test.iMeth(n, n2, -54914));
                n3 = 1;
                do {
                    n += n2;
                    instanceCount = n2;
                    n2 += 31466 + n3 * n3;
                    for (n4 = 1; n4 < 7; ++n4) {
                        n8 = (byte)(n8 << n8);
                        block14: for (n6 = n4; n6 < 2; ++n6) {
                            switch (n3 % 2 + 104) {
                                case 104: {
                                    dFld += (double)n3;
                                    dFld -= -202.0;
                                    n = n8;
                                    continue block14;
                                }
                                case 105: {
                                    f += (float)(n6 * n6);
                                }
                            }
                        }
                    }
                } while (++n3 < 243);
            }
            case 100: {
                dFld *= (double)n2;
                break;
            }
            case 101: {
                n2 = (int)instanceCount;
                break;
            }
            case 102: {
                n -= (int)f;
                break;
            }
            case 115: {
                instanceCount *= (long)n2;
            }
            case 123: 
        }
        vMeth1_check_sum += (long)(n + s + n2 + n3 + n4 + n5 + n8 + (bl ? 1 : 0) + n6 + n7 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n) {
        int n2 = 8;
        int n3 = 62033;
        int n4 = -3;
        int n5 = -135;
        int n6 = 117;
        for (n2 = 7; n2 < 227; n2 += 3) {
            Test.vMeth1(n2, (short)-11532, n3);
        }
        for (n4 = 5; n4 < 180; ++n4) {
            if (n4 != 0) {
                vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6);
                return;
            }
            n6 = 1;
            do {
                n = n6;
                iArrFld = FuzzerUtils.int1array(400, -1);
                byFld = (byte)(byFld + (byte)n);
                instanceCount *= (long)n;
                instanceCount = n4;
                n -= n3;
            } while (++n6 < 9);
            instanceCount = n6;
            instanceCount += (long)(n4 * n4);
            n3 <<= n6;
            instanceCount <<= (int)instanceCount;
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6);
    }

    public void mainTest(String[] stringArray) {
        int n = 38695;
        int n2 = 38;
        int n3 = 45019;
        int n4 = 6176;
        float f = -92.67f;
        boolean bl = true;
        int n5 = -16563;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 54201L);
        n = 1;
        while (++n < 323) {
            for (n2 = 4; n2 < 78; ++n2) {
                Test.vMeth(13350);
                n3 += n2;
                f = 1.0f;
                block25: do {
                    if (bl) continue;
                    fFld += f;
                    switch (n % 7 + 14) {
                        case 14: {
                            instanceCount &= (long)n2;
                            switch (n % 2 + 30) {
                                case 30: {
                                    bl = true;
                                    n3 += (int)((long)f ^ (long)f);
                                    n3 = n;
                                    break;
                                }
                                case 31: {
                                    lArray[n2 + 1] = (long)f;
                                }
                                default: {
                                    n3 += (int)(f * (float)this.sFld + (float)n3 - (float)n);
                                }
                            }
                            n3 *= (int)instanceCount;
                            fFld += (float)n;
                            break;
                        }
                        case 15: {
                            n3 += (int)instanceCount;
                            break;
                        }
                        case 16: {
                            int n6 = n;
                            iArrFld[n6] = iArrFld[n6] >>> -1;
                            n3 *= n2;
                            instanceCount += (long)n2;
                            break;
                        }
                        case 17: {
                            int n7 = n2 + 1;
                            lArray[n7] = lArray[n7] | instanceCount;
                            break;
                        }
                        case 18: {
                            instanceCount *= (long)dFld;
                            switch ((n >>> 1) % 6 + 105) {
                                case 105: {
                                    n5 = (short)(n5 * -29227);
                                    break;
                                }
                                case 106: {
                                    n3 = 4;
                                    fFld = (float)dFld;
                                    int n8 = n2 - 1;
                                    lArray[n8] = lArray[n8] * (long)n;
                                }
                                case 107: {
                                    try {
                                        n3 = n2 % n;
                                        n3 = n2 / 2;
                                        n3 = n / -47091;
                                    }
                                    catch (ArithmeticException arithmeticException) {}
                                    break;
                                }
                                case 108: {
                                    n3 += (int)(f * (float)n2 + (float)n3 - (float)n5);
                                    break;
                                }
                                case 109: {
                                    instanceCount *= (long)dFld;
                                }
                                case 110: {
                                    n3 += (int)((long)f ^ (long)n);
                                }
                            }
                            continue block25;
                        }
                        case 19: {
                            n4 = byFld;
                            break;
                        }
                        case 20: {
                            lArray[n2 + 1] = n2;
                        }
                    }
                } while ((f += 1.0f) < 2.0f);
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f1 b1 s2 = " + Float.floatToIntBits(f) + "," + (bl ? 1 : 0) + "," + n5);
        FuzzerUtils.out.println("i25 lArr2 = " + n4 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
        FuzzerUtils.out.println("Test.fFld sFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 26433);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

