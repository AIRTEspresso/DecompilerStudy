/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 9137146112630515312L;
    public static byte byFld = (byte)-126;
    public static boolean bFld = true;
    public static float fFld = 2.582f;
    public short sFld = (short)7484;
    public double dFld = 2.69772;
    public static boolean[] bArrFld = new boolean[400];
    public static long[] lArrFld = new long[400];
    public static int[] iArrFld = new int[400];
    public static long fMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth() {
        int n = 3;
        int n2 = -1;
        int n3 = 85;
        int n4 = -65184;
        int n5 = -46985;
        int n6 = -42940;
        int n7 = -4802;
        int[] nArray = new int[400];
        float f = 32.616f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -250L);
        FuzzerUtils.init(nArray, -2);
        for (n = 8; n < 295; ++n) {
            instanceCount = n2;
            n2 += n * n;
        }
        for (n3 = 8; n3 < 159; ++n3) {
            n5 = 10;
            do {
                lArray[n5] = n5;
                for (n6 = 1; n6 < 1; ++n6) {
                    Test.bArrFld[n5 - 1] = true;
                    try {
                        n2 = n5 % 18441;
                        n4 = -20752 / n6;
                        n4 = nArray[n5] % 143;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n2 *= 57747;
                    n7 = (int)((float)n7 + ((float)(n6 * byFld) + f - (float)n6));
                    int n8 = n6;
                    nArray[n8] = nArray[n8] << -11;
                    f += (float)((long)n6 | (long)n7);
                }
            } while (--n5 > 0);
            instanceCount += (long)n6;
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(int n, float f) {
        int n2 = -38;
        int n3 = -42;
        int n4 = -94;
        int n5 = -251;
        int n6 = 9;
        int[] nArray = new int[400];
        long l = -13L;
        short[] sArray = new short[400];
        FuzzerUtils.init(nArray, 14);
        FuzzerUtils.init(sArray, (short)14662);
        Test.vMeth();
        for (n2 = 1; n2 < 322; ++n2) {
            n = (int)instanceCount;
            try {
                n3 = n2 / n2;
                n %= n;
                nArray[n2 - 1] = n % 162;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            l = 1L;
            if (5L > l) {
                int n7 = n2 + 1;
                sArray[n7] = (short)(sArray[n7] * (short)(n4 <<= -51364));
            }
            n3 += n3;
        }
        long l2 = (long)(n + Float.floatToIntBits(f) + n2 + n3) + l + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(sArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static float fMeth(int n, int n2) {
        int n3 = 55257;
        int n4 = 0;
        int n5 = 7;
        int[][][] nArray = new int[400][400][400];
        int n6 = 16511;
        FuzzerUtils.init((Object[][])nArray, (Object)93);
        block0: for (n3 = 133; n3 > 5; n3 -= 3) {
            byFld = (byte)(byFld + 1);
            int[] nArray2 = nArray[n3 - 1][n3];
            int n7 = n3;
            nArray2[n7] = nArray2[n7] - n4++;
            n2 -= (int)((long)Test.iMeth(-13, fFld) + (instanceCount += (long)byFld * -1111387205437454085L));
            fFld += (float)(n3 * n) + fFld - fFld;
            n5 = 1;
            do {
                n ^= n5;
                n6 = (short)(n6 + (short)n5);
                n <<= n2;
                fFld += (float)n3;
                if (bFld) continue block0;
                instanceCount = (long)((float)instanceCount + ((float)(n5 * n3 + n4) - fFld));
                n4 -= n4;
            } while (++n5 < 36);
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum((Object[][])nArray);
        fMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 14158;
        int n2 = -192;
        int n3 = -77;
        int n4 = -20715;
        int n5 = 46;
        int n6 = -6;
        int n7 = -10;
        int n8 = 153;
        int n9 = 2;
        int[][][] nArray = new int[400][400][400];
        float f = 0.848f;
        float f2 = -1.24f;
        float[] fArray = new float[400];
        long l = -63278L;
        FuzzerUtils.init(fArray, 103.682f);
        FuzzerUtils.init((Object[][])nArray, (Object)27309);
        instanceCount <<= n;
        for (n2 = 8; n2 < 150; ++n2) {
            for (n4 = 8; n4 < 177; ++n4) {
                f += Test.fMeth(n3, n5);
                for (n6 = 1; n6 < 2; ++n6) {
                    this.sFld = (short)(this.sFld - (short)this.dFld);
                    if (bFld) continue;
                    n5 += 23;
                    switch ((n2 >>> 1) % 1 * 5 + 9) {
                        case 14: {
                            instanceCount += (long)(-12 + n6 * n6);
                            int n10 = n2 - 1;
                            fArray[n10] = fArray[n10] + -177.0f;
                            int[] nArray2 = nArray[n4][n6];
                            int n11 = n4 + 1;
                            nArray2[n11] = nArray2[n11] + (int)f;
                        }
                    }
                    n7 = (int)((float)n7 + ((float)(n6 * n7 + n6) - fFld));
                    f = n4;
                }
                l >>= n5;
                l -= (long)this.dFld;
            }
            try {
                nArray[n2 - 1][n2][n2] = 96 % n4;
                n7 /= n4;
                n7 = n5 % n;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            fFld -= (float)n6;
            iArrFld = nArray[n2 + 1][n2 + 1];
        }
        block17: for (f2 = 14.0f; f2 < 324.0f; f2 += 1.0f) {
            l = (long)this.dFld;
            n9 = 81;
            do {
                n8 = (int)instanceCount;
                if (bFld) continue block17;
                switch ((int)(f2 % 5.0f * 5.0f + 107.0f)) {
                    case 108: {
                        try {
                            n5 = nArray[n9][(int)(f2 - 1.0f)][n9] % n3;
                            Test.iArrFld[(int)(f2 - 1.0f)] = n6 / 109338388;
                            n8 = n6 / n2;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                    }
                    case 128: {
                        n8 += n9 * n9;
                        n -= n2;
                        this.dFld -= 10.0;
                        break;
                    }
                    case 120: {
                        fArray[(int)f2] = n9;
                        break;
                    }
                    case 110: {
                        n3 += n9;
                        break;
                    }
                    case 131: {
                        f += (float)n3;
                    }
                }
            } while (--n9 > 0);
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 i4 f = " + n4 + "," + n5 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i23 i24 l1 = " + n6 + "," + n7 + "," + l);
        FuzzerUtils.out.println("f3 i25 i26 = " + Float.floatToIntBits(f2) + "," + n8 + "," + n9);
        FuzzerUtils.out.println("fArr iArr3 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum((Object[][])nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.bFld = " + instanceCount + "," + byFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld sFld dFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.bArrFld Test.lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(bArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(bArrFld, false);
        FuzzerUtils.init(lArrFld, -117L);
        FuzzerUtils.init(iArrFld, 0);
        fMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

