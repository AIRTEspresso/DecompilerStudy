/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -13920L;
    public static byte byFld = (byte)95;
    public float fFld = -38.168f;
    public short sFld = (short)-27092;
    public static int[] iArrFld = new int[400];
    public static float[] fArrFld = new float[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, int n2) {
        float f = -2.89f;
        float[][][] fArray = new float[400][400][400];
        int n3 = -74;
        int n4 = -23109;
        int n5 = -12;
        int n6 = -8333;
        double d = -104.27888;
        int n7 = 30785;
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(0.71f));
        n = n2;
        f = n;
        n3 = 1;
        while (++n3 < 237) {
            f -= (float)n2;
            for (n4 = 1; n4 < 7; ++n4) {
                n6 = 1;
                while (++n6 < 2) {
                    n5 = 799373918;
                    instanceCount = (long)d;
                    iArrFld = FuzzerUtils.int1array(400, 193);
                    fArray[n4][n6][n4 - 1] = n4;
                    switch (n6 % 1 * 5 + 67) {
                        default: 
                    }
                    n5 = n6;
                    n = (int)((long)n + ((long)n6 * instanceCount + (long)n - (long)n7));
                    instanceCount = 12L;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray));
    }

    public static int iMeth1() {
        int n = -6;
        int n2 = 10095;
        int n3 = -25023;
        int n4 = 10;
        int n5 = 253;
        int n6 = -16776;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 6655L);
        Test.vMeth(n, n);
        n2 = 1;
        while (++n2 < 163) {
            int n7 = n2 - 1;
            lArray[n7] = lArray[n7] * instanceCount;
            for (n3 = 1; 10 > n3; ++n3) {
                instanceCount += 32473L + (long)(n3 * n3);
                n4 *= byFld;
                n *= n3;
                instanceCount <<= n3;
                n5 = 1;
                do {
                    double d = -124.48152;
                    instanceCount += (long)(107.914f + (float)(n5 * n5));
                    n4 *= 110;
                    int n8 = n2 + 1;
                    lArray[n8] = lArray[n8] - (long)d;
                    n4 = 52967;
                    n *= n2;
                } while (++n5 < 2);
            }
            int n9 = n2;
            iArrFld[n9] = iArrFld[n9] + n6;
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth(int n, float f, long l) {
        int n2 = 39242;
        int n3 = -7;
        int n4 = 11946;
        int n5 = -58508;
        int n6 = 11590;
        int n7 = 134;
        int n8 = -24646;
        int n9 = -109;
        double d = 0.117562;
        double[] dArray = new double[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(dArray, -50.79292);
        FuzzerUtils.init(fArray, 2.813f);
        for (n2 = 19; n2 < 367; ++n2) {
            Test.iArrFld[n2] = (int)l;
            dArray[n2] = d;
            Test.iMeth1();
            for (n4 = 1; n4 < 5; ++n4) {
                for (n6 = 1; n6 < 2; ++n6) {
                    int n10 = n4;
                    fArray[n10] = fArray[n10] - f;
                    instanceCount -= (long)n5;
                    n5 += n7;
                }
                n += (int)d;
                n *= -26;
                for (n8 = 1; n8 < 2; ++n8) {
                    n5 <<= n6;
                }
                n = n2;
                f -= -68.0f;
            }
        }
        long l2 = (long)(n + Float.floatToIntBits(f)) + l + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -25;
        int n2 = 30594;
        int n3 = -12754;
        int n4 = 153;
        int n5 = -10;
        int n6 = -26818;
        int n7 = 4;
        int n8 = -11;
        long l = 7976563264421262774L;
        long[] lArray = new long[400];
        double d = 126.120803;
        boolean bl = false;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(lArray, -223L);
        FuzzerUtils.init(byArray, (byte)20);
        for (n = 311; n > 2; --n) {
            int n9 = n - 1;
            long l2 = lArray[n9] - 1L;
            lArray[n9] = l2;
            n2 = (int)(-((long)n2 * 1826508092L) * l2);
            for (n3 = n; n3 < 81; ++n3) {
                n2 >>= (int)Math.min((long)(-Test.iMeth(n3, this.fFld, instanceCount) + n2), instanceCount);
                n4 = (int)instanceCount;
                n4 += n3;
            }
            block14: for (l = 2L; l < 81L; ++l) {
                for (n6 = 2; n6 > 1; n6 -= 2) {
                    n5 += n6;
                }
                n5 >>= n7;
                lArray[(int)l] = 13L;
                this.fFld = n3;
                for (d = 1.0; d < 2.0; d += 1.0) {
                    this.sFld = (short)(this.sFld * -28111);
                    instanceCount = -6872L;
                    n7 += (int)d;
                    instanceCount = (long)((double)instanceCount + (221.0 + d * d));
                    this.sFld = (short)(this.sFld * -11);
                    byArray[(int)l] = (byte)n5;
                    Test.fArrFld[(int)l] = n3;
                    n2 += (int)d;
                }
                int n10 = (int)(l - 1L);
                byArray[n10] = (byte)(byArray[n10] << (byte)n2);
                Test.iArrFld[(int)l] = (int)l;
                switch ((int)(l % 10L * 5L + 90L)) {
                    case 112: {
                        n2 = (int)d;
                        n7 *= n3;
                        this.sFld = (short)(this.sFld - (short)n2);
                        instanceCount *= instanceCount;
                    }
                    case 127: {
                        instanceCount -= l;
                        continue block14;
                    }
                    case 114: {
                        n2 |= n7;
                        continue block14;
                    }
                    case 104: {
                        int n11 = n;
                        iArrFld[n11] = iArrFld[n11] * (int)l;
                    }
                    case 131: {
                        if (bl) continue block14;
                    }
                    case 123: {
                        n4 = n;
                        continue block14;
                    }
                    case 133: {
                        this.fFld += (float)(l * (long)n3);
                        continue block14;
                    }
                    case 135: {
                        n2 -= n6;
                        continue block14;
                    }
                    case 126: {
                        this.fFld /= (float)(n8 | 1);
                        continue block14;
                    }
                    case 102: {
                        instanceCount += (long)this.fFld;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 l1 i24 = " + n4 + "," + l + "," + n5);
        FuzzerUtils.out.println("i25 i26 d3 = " + n6 + "," + n7 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i27 b lArr = " + n8 + "," + (bl ? 1 : 0) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("byArr = " + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("sFld Test.iArrFld Test.fArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -250);
        FuzzerUtils.init(fArrFld, -99.458f);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

