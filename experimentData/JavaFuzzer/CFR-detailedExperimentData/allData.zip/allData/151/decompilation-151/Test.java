/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -708077500915325689L;
    public int iFld = 27606;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public double[] dArrFld = new double[400];
    public static long dMeth_check_sum;
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;

    public static long lMeth(long l, int n) {
        int n2 = -794;
        n2 = (short)(n2 >> 8);
        long l2 = l + (long)n + (long)n2;
        lMeth_check_sum += l2;
        return l2;
    }

    public static void vMeth(double d, int n) {
        float f = 0.68f;
        float[] fArray = new float[400];
        int n2 = 61838;
        int n3 = -1;
        int n4 = -21888;
        long l = 38238L;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(fArray, 66.836f);
        blArray[(n >>> 1) % 400] = (float)n == fArray[18];
        for (int n5 : iArrFld) {
            int n6 = (n5 >>> 1) % 400;
            iArrFld[n6] = iArrFld[n6] + n;
        }
        n -= (int)f;
        for (n2 = 134; n2 > 7; n2 -= 3) {
            n = n3;
            for (l = 1L; 36L > l; ++l) {
                n4 |= (int)(1479690261L + (long)iArrFld[(int)(l - 1L)] + -((long)n3 - l) + (Test.lMeth(l, n2) - (long)n));
                int n7 = (int)(l + 1L);
                iArrFld[n7] = iArrFld[n7] * n;
                n += (int)l;
                if (n3 != 0) {
                    vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + l + (long)n4 + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                    return;
                }
                n4 *= n;
                instanceCount += l ^ (long)n;
            }
            if (n != 0) {
                vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + l + (long)n4 + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                return;
            }
            n3 = 21956;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + l + (long)n4 + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static double dMeth(long l, int n) {
        double d = 71.91273;
        int n2 = -10;
        int n3 = 57;
        int n4 = -6;
        int n5 = -69;
        int n6 = 27;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)164L);
        Test.vMeth(d, n);
        n <<= (int)instanceCount;
        for (n2 = 3; n2 < 321; ++n2) {
            for (n4 = 1; n4 < 5; ++n4) {
                n6 = (byte)(n *= (int)l);
                Test.iArrFld[n2] = n5 <<= 205;
                instanceCount += (long)(119 + n4 * n4);
            }
        }
        n3 = -210;
        lArray[(n3 >>> 1) % 400][(n >>> 1) % 400][(n >>> 1) % 400] = n4;
        n = n4;
        n5 = n2;
        instanceCount = 14L;
        n6 = (byte)(n6 - (byte)n5);
        long l2 = l + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum((Object[][])lArray);
        dMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 14;
        int n2 = -9;
        int n3 = 0;
        int n4 = 0;
        int n5 = 5243;
        int n6 = -157;
        int[] nArray = new int[400];
        double d = 0.23301;
        double d2 = -1.45981;
        float f = 2.405f;
        int n7 = -10275;
        boolean bl = false;
        int n8 = -39;
        FuzzerUtils.init(nArray, -7868);
        n = 1;
        while (++n < 250) {
            for (n2 = 101; n2 > n; n2 -= 3) {
                for (d = 1.0; 1.0 < d; d -= 2.0) {
                    nArray[n2] = (int)instanceCount;
                    d2 -= (double)n3;
                    f = (float)Test.dMeth(instanceCount, this.iFld);
                    Test.lArrFld[n2] = n2;
                    d2 -= (double)(n4 += n3);
                    instanceCount = n2;
                    d2 *= (double)instanceCount;
                    nArray = iArrFld;
                    int n9 = n;
                    nArray[n9] = nArray[n9] << n;
                }
                n4 >>= n;
                f += (float)instanceCount;
                d2 += (double)n7;
                n4 += 248 + n2 * n2;
                instanceCount = 2L;
                n7 = (short)(n7 + (short)n2);
            }
            Test.iArrFld[n - 1] = (int)instanceCount;
            if (bl) break;
            int n10 = n + 1;
            nArray[n10] = nArray[n10] / (int)((long)d | 1L);
            n5 = 1;
            do {
                int n11 = n;
                this.dArrFld[n11] = this.dArrFld[n11] - (double)instanceCount;
                n3 -= n8;
                this.iFld &= n4;
                n6 = 1;
                do {
                    n4 >>= (int)instanceCount;
                    this.iFld -= (int)instanceCount;
                    this.iFld -= (int)d2;
                } while (++n6 < 1);
            } while (++n5 < 101);
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("d i3 d1 = " + Double.doubleToLongBits(d) + "," + n4 + "," + Double.doubleToLongBits(d2));
        FuzzerUtils.out.println("f s1 b = " + Float.floatToIntBits(f) + "," + n7 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("i15 by1 i16 = " + n5 + "," + n8 + "," + n6);
        FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.iArrFld = " + instanceCount + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 68);
        FuzzerUtils.init(lArrFld, 39896L);
        dMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

