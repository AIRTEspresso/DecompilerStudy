/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2L;
    public static int iFld = -218;
    public static volatile byte byFld = (byte)-102;
    public short sFld = (short)-25450;
    public static double dFld = 1.8143;
    public static boolean bFld = true;
    public static long vMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(long l, int n) {
        vMeth1_check_sum += l + (long)n;
    }

    public static int iMeth(int n) {
        boolean bl = false;
        float f = 97.812f;
        int n2 = -50639;
        int n3 = 12600;
        int n4 = 11;
        int n5 = 221;
        int[] nArray = new int[400];
        byte[] byArray = new byte[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(byArray, (byte)-87);
        FuzzerUtils.init(nArray, 5);
        FuzzerUtils.init(lArray, -4419682554608553365L);
        Test.vMeth1(instanceCount, iFld);
        if (bl) {
            iFld |= iFld;
            byArray[(n >>> 1) % 400] = byFld;
        }
        f = iFld;
        for (int n6 : nArray) {
            int n7 = (iFld >>> 1) % 400;
            nArray[n7] = nArray[n7] + iFld;
            for (n2 = 1; n2 < 4; ++n2) {
                iFld *= (int)f;
                int n8 = n2 + 1;
                lArray[n8] = lArray[n8] << n3;
                for (n4 = 1; n4 < 2; ++n4) {
                    instanceCount *= (long)n3;
                    f = n2;
                    iFld -= -9;
                    instanceCount *= instanceCount;
                }
            }
        }
        long l = (long)(n + (bl ? 1 : 0) + Float.floatToIntBits(f) + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum(byArray) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth() {
        int n = 10;
        int n2 = -20950;
        int n3 = 7;
        int n4 = -241;
        int n5 = 7;
        int[] nArray = new int[400];
        long l = 134L;
        long[] lArray = new long[400];
        int n6 = 78;
        int n7 = -17714;
        boolean bl = false;
        FuzzerUtils.init(nArray, 36246);
        FuzzerUtils.init(lArray, 215L);
        switch ((9 + --iFld >>> 1) % 1 + 53) {
            case 53: {
                n = 1;
                do {
                    for (n2 = n; n2 < 9; ++n2) {
                        instanceCount -= l + (long)(nArray[(n >>> 1) % 400] + iFld * iFld);
                    }
                    iFld >>= n3;
                    for (n4 = 1; n4 < 9; ++n4) {
                        int n8 = n4;
                        nArray[n8] = nArray[n8] * ((n6 + n2 + (n5 - n6)) * n);
                        int n9 = n - 1;
                        int n10 = nArray[n9];
                        nArray[n9] = n10 - 1;
                        n7 = (short)(n7 | (short)nArray[n - 1]);
                        Test.iMeth(n3);
                        iFld = (int)(instanceCount >>= n10);
                        int n11 = n + 1;
                        lArray[n11] = lArray[n11] - (long)n7;
                        iFld = n3;
                        instanceCount += (long)n4;
                    }
                } while (++n < 169);
                break;
            }
            default: {
                bl = false;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3) + l + (long)n4 + (long)n5 + (long)n6 + (long)n7 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -6;
        int n2 = 117;
        int n3 = -169;
        int n4 = -1852;
        int n5 = -44238;
        int n6 = 9;
        int n7 = -133;
        int n8 = -61689;
        int n9 = -73;
        int[][] nArray = new int[400][400];
        float f = -44.284f;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)-3359696756L);
        FuzzerUtils.init(nArray, 187);
        n = 1;
        while (++n < 203) {
            switch (n % 2 + 44) {
                case 44: {
                    Test.vMeth();
                    instanceCount = n;
                    break;
                }
                case 45: {
                    long[] lArray2 = lArray[n - 1][n + 1];
                    int n10 = n;
                    lArray2[n10] = lArray2[n10] + (long)iFld;
                    for (n2 = 1; n2 < 124; ++n2) {
                        for (n4 = 1; 2 > n4; ++n4) {
                            int[] nArray2 = nArray[n4];
                            int n11 = n - 1;
                            nArray2[n11] = nArray2[n11] << n5;
                            this.sFld = (short)(this.sFld - (short)instanceCount);
                            instanceCount += (long)n4 * instanceCount;
                        }
                        for (n6 = 2; n6 > 1; --n6) {
                            iFld += (int)instanceCount;
                            nArray[n + 1][n2 - 1] = (int)(instanceCount ^= (long)n3);
                            nArray[n - 1] = FuzzerUtils.int1array(400, 65);
                        }
                        n3 -= (int)f;
                        if (bFld) continue;
                        n3 *= n6;
                        try {
                            n3 = 436342200 % nArray[n][n2 - 1];
                            iFld = n % -8174;
                            nArray[n - 1][n] = n7 % -696068463;
                        }
                        catch (ArithmeticException arithmeticException) {
                            // empty catch block
                        }
                        n5 -= (int)dFld;
                        block21: for (n8 = 2; n8 > n2; --n8) {
                            byFld = (byte)(byFld - (byte)n5);
                            n9 = iFld;
                            n5 -= (int)instanceCount;
                            switch (n % 10 + 21) {
                                case 21: {
                                    n5 *= (int)instanceCount;
                                    if (!bFld) continue block21;
                                    continue block21;
                                }
                                case 22: {
                                    iFld = n9;
                                    continue block21;
                                }
                                case 23: {
                                    instanceCount += (long)f;
                                    continue block21;
                                }
                                case 24: {
                                    long[] lArray3 = lArray[n8 + 1][n8 + 1];
                                    int n12 = n;
                                    lArray3[n12] = lArray3[n12] + 13L;
                                }
                                case 25: {
                                    f += f;
                                    continue block21;
                                }
                                case 26: {
                                    if (bFld) continue block21;
                                }
                                case 27: {
                                    int[] nArray3 = nArray[n - 1];
                                    int n13 = n2;
                                    nArray3[n13] = nArray3[n13] * -118;
                                    continue block21;
                                }
                                case 28: {
                                    nArray[n + 1][n2 - 1] = n2;
                                    continue block21;
                                }
                                case 29: 
                                case 30: {
                                    n9 += iFld;
                                    continue block21;
                                }
                                default: {
                                    n3 >>= n8;
                                }
                            }
                        }
                    }
                    break;
                }
            }
        }
        FuzzerUtils.out.println("i i13 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i15 i16 i17 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i18 f1 i19 = " + n7 + "," + Float.floatToIntBits(f) + "," + n8);
        FuzzerUtils.out.println("i20 lArr2 iArr2 = " + n9 + "," + FuzzerUtils.checkSum((Object[][])lArray) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + byFld);
        FuzzerUtils.out.println("sFld Test.dFld Test.bFld = " + this.sFld + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

