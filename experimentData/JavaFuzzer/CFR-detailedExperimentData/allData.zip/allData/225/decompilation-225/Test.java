/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 11L;
    public static int iFld = -47;
    public static short sFld = (short)2948;
    public static byte byFld = (byte)-26;
    public boolean bFld = false;
    public static double dFld = 2.66763;
    public static float fFld = -7.287f;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static short[] sArrFld = new short[400];
    public static byte[] byArrFld = new byte[400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;

    public static int iMeth1(int n, int n2) {
        int n3 = 110;
        int n4 = 35954;
        int n5 = -5;
        int n6 = 8;
        double d = -2.73343;
        float f = 1.286f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 1980381468L);
        instanceCount += (long)n2;
        iFld += -6;
        for (n3 = 15; n3 < 262; ++n3) {
            n += 14;
            d -= (double)sFld;
            for (n5 = 1; n5 < 7; ++n5) {
                instanceCount = (long)f;
                switch ((n4 >>> 1) % 1 * 5 + 127) {
                    case 131: {
                        lArray[n3] = n;
                        instanceCount += (long)(n5 | n6);
                        iFld >>>= sFld;
                        instanceCount *= (long)sFld;
                    }
                }
                n >>= byFld;
                n4 = (int)instanceCount;
            }
        }
        long l = (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth() {
        int n = 117;
        int n2 = 15718;
        int n3 = -36215;
        int n4 = 233;
        float f = 95.287f;
        float f2 = 62.931f;
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(fArray, 0.207f);
        FuzzerUtils.init(lArray, -560020216L);
        int n5 = iFld;
        int n6 = (iFld >>> 1) % 400;
        int n7 = iArrFld[n6] + 1;
        iArrFld[n6] = n7;
        int n8 = n7 * Math.max(iFld, iFld);
        int n9 = iFld - iFld;
        iFld = n;
        iFld = n5 - n8 * (n9 + iFld);
        iFld = sFld;
        n2 = 1;
        do {
            instanceCount *= (long)n2;
            fArray[n2] = (n2 + Test.iMeth1(n2, n2)) * 8;
            for (f = 1.0f; f < 4.0f; f += 1.0f) {
                try {
                    iFld = iArrFld[n2 - 1] / iFld;
                    n3 = iFld % 178;
                    iFld = -11284 % iFld;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n4 = 1;
                while ((n4 += 2) < 2) {
                    int n10 = n2 - 1;
                    lArray[n10] = lArray[n10] - (long)sFld;
                    switch (n4 % 7 * 5 + 15) {
                        case 30: {
                            n3 = (int)((long)n3 + ((long)n4 + instanceCount));
                            n3 = -1;
                            iFld -= n2;
                            break;
                        }
                        case 16: {
                            sFld = (short)(sFld + (short)(-12406 + n4 * n4));
                        }
                        case 39: {
                            instanceCount >>= -1384129393;
                            break;
                        }
                        case 41: {
                            Test.iArrFld[n2] = (int)f;
                            break;
                        }
                        case 42: {
                            Test.iArrFld[n2] = n3;
                            break;
                        }
                        case 47: {
                            f2 += (float)(n4 * n3 + iFld - n2);
                        }
                    }
                }
            }
        } while (++n2 < 396);
        long l = (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + Float.floatToIntBits(f2)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n) {
        int n2 = 57371;
        int n3 = -22209;
        int n4 = 22;
        int n5 = 8;
        int n6 = -32640;
        int n7 = -5;
        int n8 = -222;
        int n9 = 2;
        int n10 = 0;
        double d = -6.49078;
        float f = -1.147f;
        float f2 = -51.353f;
        boolean bl = true;
        Test.iMeth();
        switch ((iFld >>> 1) % 9 + 49) {
            case 49: {
                block11: for (n2 = 5; n2 < 121; n2 += 3) {
                    for (n4 = 2; n4 < 40; ++n4) {
                        for (d = 1.0; d < 2.0; d += 1.0) {
                            n3 -= (int)f;
                        }
                        iFld += n4 + iFld;
                        instanceCount >>>= n4;
                        if (bl) continue block11;
                    }
                }
                break;
            }
            case 50: {
                for (n7 = 324; 12 < n7; n7 -= 3) {
                    for (n9 = 1; 15 > n9; ++n9) {
                        n10 += 21167;
                        f2 += (float)(n9 + sFld);
                        n3 = n5;
                        int n11 = n7 - 1;
                        lArrFld[n11] = lArrFld[n11] * -205L;
                    }
                }
                break;
            }
            case 51: {
                n3 -= n;
                break;
            }
            case 52: {
                int n12 = (n5 >>> 1) % 400;
                sArrFld[n12] = (short)(sArrFld[n12] - (short)n2);
                break;
            }
            case 53: {
                n5 <<= sFld;
                break;
            }
            case 54: {
                n3 -= (int)instanceCount;
            }
            case 55: {
                n6 |= (int)instanceCount;
                break;
            }
            case 56: {
                f = n3;
                break;
            }
            case 57: {
                instanceCount *= (long)iFld;
                break;
            }
            default: {
                n5 <<= (int)instanceCount;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)n6 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + (long)n7 + (long)n8 + (long)n9 + (long)n10 + (long)Float.floatToIntBits(f2);
    }

    /*
     * Unable to fully structure code
     */
    public void mainTest(String[] var1_1) {
        var2_2 = -6;
        var3_3 = -3;
        var4_4 = 8;
        var5_5 = 25895;
        var6_6 = 37204;
        var7_7 = -224;
        var8_8 = 206;
        Test.vMeth(Test.iFld);
        Test.instanceCount ^= (long)Test.iFld;
        var2_2 = 1;
        do {
            v0 = var2_2 - 1;
            Test.iArrFld[v0] = Test.iArrFld[v0] - var2_2;
            Test.byFld = (byte)(Test.byFld * (byte)Test.instanceCount);
            Test.byArrFld[var2_2] = 4;
        } while ((var2_2 += 3) < 330);
        for (var3_3 = 6; var3_3 < 176; ++var3_3) {
            var5_5 = 1;
            do {
                var4_4 = var5_5;
                var4_4 += var3_3;
                var4_4 += var5_5 | var5_5;
                Test.iFld += var5_5;
                var6_6 *= (int)Test.instanceCount;
                block14: for (var7_7 = 1; var7_7 < 2; ++var7_7) {
                    var4_4 = var5_5;
                    Test.iFld += var7_7 * var5_5 + var2_2 - var7_7;
                    Test.iFld += var8_8;
                    Test.sFld = (short)var4_4;
                    Test.instanceCount >>>= (int)Test.instanceCount;
                    this.bFld = false;
                    switch (var5_5 % 10 + 4) {
                        case 4: {
                            Test.iFld += var6_6;
                            if (!this.bFld) ** GOTO lbl39
                            Test.iArrFld[var5_5 - 1] = (int)Test.dFld;
                            Test.iArrFld[var5_5] = (int)Test.instanceCount;
                            ** GOTO lbl43
lbl39:
                            // 1 sources

                            if (this.bFld) {
                                Test.sFld = (short)(Test.sFld >> (short)var2_2);
                            } else {
                                var6_6 >>= var2_2;
                            }
                        }
lbl43:
                        // 4 sources

                        case 5: {
                            Test.fFld += (float)Test.iFld;
                            Test.dFld *= (double)var5_5;
                            continue block14;
                        }
                        case 6: {
                            var4_4 = -35063;
                            continue block14;
                        }
                        case 7: {
                            Test.iArrFld[var7_7] = -244;
                            continue block14;
                        }
                        case 8: {
                            Test.lArrFld[var5_5 + 1] = var5_5;
                        }
                        case 9: {
                            if (!this.bFld) continue block14;
                            continue block14;
                        }
                        case 10: {
                            v1 = var5_5 + 1;
                            Test.iArrFld[v1] = Test.iArrFld[v1] - -40985;
                            continue block14;
                        }
                        case 11: {
                            var8_8 *= (int)Test.fFld;
                            continue block14;
                        }
                        case 12: 
                        case 13: {
                            Test.iArrFld[var7_7 + 1] = (int)Test.fFld;
                        }
                    }
                }
            } while ((var5_5 += 2) < 148);
        }
        FuzzerUtils.out.println("i19 i20 i21 = " + var2_2 + "," + var3_3 + "," + var4_4);
        FuzzerUtils.out.println("i22 i23 i24 = " + var5_5 + "," + var6_6 + "," + var7_7);
        FuzzerUtils.out.println("i25 = " + var8_8);
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + Test.instanceCount + "," + Test.iFld + "," + Test.sFld);
        FuzzerUtils.out.println("Test.byFld bFld Test.dFld = " + Test.byFld + "," + (this.bFld != false ? 1 : 0) + "," + Double.doubleToLongBits(Test.dFld));
        FuzzerUtils.out.println("Test.fFld Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(Test.fFld) + "," + FuzzerUtils.checkSum(Test.iArrFld) + "," + FuzzerUtils.checkSum(Test.lArrFld));
        FuzzerUtils.out.println("Test.sArrFld Test.byArrFld = " + FuzzerUtils.checkSum(Test.sArrFld) + "," + FuzzerUtils.checkSum(Test.byArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + Test.iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + Test.iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + Test.vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 154);
        FuzzerUtils.init(lArrFld, -234L);
        FuzzerUtils.init(sArrFld, (short)7255);
        FuzzerUtils.init(byArrFld, (byte)28);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
    }
}

