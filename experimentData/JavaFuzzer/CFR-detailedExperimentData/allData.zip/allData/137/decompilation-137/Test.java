/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 50760L;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2) {
        int n3 = 31;
        int n4 = -91;
        float f = 0.685f;
        float f2 = 2.16f;
        int n5 = 122;
        boolean bl = false;
        double d = -2.12627;
        n = (int)instanceCount;
        n3 = 1;
        do {
            f = n2;
            n5 = (byte)(n5 + (byte)instanceCount);
            n += n3;
            n += n3;
            n5 = (byte)(n5 >>> (byte)instanceCount);
            n2 += 9;
            n2 >>= 12;
            if (bl) break;
            for (f2 = 6.0f; 1.0f < f2; f2 -= 1.0f) {
                d = n;
                n += (int)(f2 * f2);
                int n6 = (int)(f2 - 1.0f);
                iArrFld[n6] = iArrFld[n6] - 196;
            }
        } while (++n3 < 257);
        vMeth1_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n5 + (bl ? 1 : 0) + Float.floatToIntBits(f2) + n4) + Double.doubleToLongBits(d);
    }

    public static void vMeth() {
        int n = -243;
        int n2 = 233;
        int n3 = 222;
        int n4 = 50204;
        int n5 = -24032;
        short[] sArray = new short[400];
        float f = -75.288f;
        float[] fArray = new float[400];
        long l = 77L;
        long[] lArray = new long[400];
        FuzzerUtils.init(sArray, (short)-16151);
        FuzzerUtils.init(fArray, 4.417f);
        FuzzerUtils.init(lArray, 33896L);
        n = 1;
        do {
            try {
                n2 = iArrFld[n + 1] % -2083200514;
                n2 = -12447 / n2;
                n2 %= -470138837;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            int n6 = n5;
            n5 = (short)(n5 - 1);
            instanceCount = n6;
            sArray = FuzzerUtils.short1array(400, (short)8297);
            int n7 = n - 1;
            float f2 = fArray[n7];
            fArray[n7] = f2 - 1.0f;
            n2 += (int)f2;
            f -= 1.0f;
            f = (float)Math.abs(n) - f + (float)n2--;
            int n8 = n;
            iArrFld[n8] = iArrFld[n8] + (int)lArray[n];
            n3 = 13;
            while (--n3 > 0) {
                float f3 = f;
                f = f3 - 1.0f;
                instanceCount += (long)(f3 + f);
                n2 = n3 * (n - n + (n2 + n));
                Test.vMeth1(n3, -64);
                instanceCount += -12L;
                for (l = 1L; l < 1L; l += 3L) {
                    f += (float)n2;
                    int n9 = n + 1;
                    iArrFld[n9] = iArrFld[n9] >>> n4;
                }
            }
        } while (++n < 123);
        vMeth_check_sum += (long)(n + n2 + n5 + Float.floatToIntBits(f) + n3) + l + (long)n4 + FuzzerUtils.checkSum(sArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray);
    }

    public static int iMeth(int n, long l) {
        double d = 0.111255;
        int n2 = -102;
        float f = -18.954f;
        int n3 = 8280;
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init((Object[][])lArray, (Object)-12L);
        d = 1.0;
        while (true) {
            double d2;
            d += 1.0;
            if (!(d2 < 361.0)) break;
            int n4 = (int)(d + 1.0);
            iArrFld[n4] = iArrFld[n4] + 1;
            Test.vMeth();
        }
        n2 = 4;
        instanceCount <<= 11096;
        lArray[42][61] = lArray[(n >>> 1) % 400][(n >>> 1) % 400];
        for (f = 236.0f; f > 3.0f; f -= 1.0f) {
            n3 = (int)((float)n3 + (-20827.0f + f * f));
            n3 -= (int)f;
            int n5 = (int)f;
            iArrFld[n5] = iArrFld[n5] + (n += (int)f);
            int n6 = (int)(f - 1.0f);
            iArrFld[n6] = iArrFld[n6] * (int)l;
            n3 += (int)(f + (float)instanceCount);
        }
        long l2 = (long)n + l + Double.doubleToLongBits(d) + (long)n2 + (long)Float.floatToIntBits(f) + (long)n3 + FuzzerUtils.checkSum((Object[][])lArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 5;
        long l = (long)n++ - (instanceCount + (long)n);
        n += Test.iMeth(n, instanceCount);
        n = (int)(l + (long)n);
        n ^= n;
        instanceCount = 0L;
        FuzzerUtils.out.println("i = " + n);
        FuzzerUtils.out.println("Test.instanceCount Test.iArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 178);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

