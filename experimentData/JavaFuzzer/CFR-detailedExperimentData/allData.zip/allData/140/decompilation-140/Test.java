/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -8L;
    public static int iFld = 10;
    public static short sFld = (short)-30775;
    public float fFld = -116.725f;
    public boolean bFld = false;
    public static float fFld1 = -80.97f;
    public static boolean bFld1 = true;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        int n2 = 205;
        int n3 = -62929;
        int n4 = -59205;
        int n5 = 157;
        int n6 = 56578;
        int n7 = 118;
        int n8 = 29973;
        for (n2 = 11; 334 > n2; ++n2) {
            int n9 = n2 + 1;
            iArrFld[n9] = iArrFld[n9] - 30561;
            for (n4 = 1; n4 < 5; ++n4) {
                for (n6 = 1; 2 > n6; ++n6) {
                    n = n5;
                    fFld1 -= -74.0f;
                    n7 *= n7;
                    n7 >>= 1369483419;
                    n7 *= -12757;
                    switch (n2 % 2 + 29) {
                        case 29: {
                            sFld = (short)(sFld >> (short)iFld);
                            break;
                        }
                        case 30: {
                            fFld1 += -48.891f + (float)(n6 * n6);
                            n8 = (short)(n8 >> (short)iFld);
                        }
                    }
                    n5 += n6;
                }
                n += iFld;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8);
    }

    public static void vMeth(float f, int n) {
        int n2 = -38934;
        int n3 = -6490;
        int n4 = 19410;
        int n5 = -10;
        int n6 = -9;
        double d = -52.25984;
        int n7 = -68;
        long l = -1630227261L;
        for (n2 = 1; n2 < 279; ++n2) {
            float f2 = f;
            double d2 = d;
            double d3 = d;
            d = d3 - 1.0;
            f -= 1.0f;
            f = f2 - (float)(d2 - d3 + (double)(f * (float)n7));
            n3 = Math.max(iArrFld[n2 + 1], (int)(-((long)n3 * instanceCount)));
            n += n2;
            Test.vMeth1(n2);
            if (bFld1) {
                int n8 = n2;
                iArrFld[n8] = iArrFld[n8] + n2;
                continue;
            }
            if (bFld1) {
                instanceCount += (long)(n2 * n3 + n - n3);
                Test.iArrFld[n2 - 1] = (int)f;
                n3 = n4;
                continue;
            }
            if (!bFld1) continue;
            for (n5 = 6; n5 > 1; --n5) {
                l <<= iFld;
                n7 = (byte)(n7 << 4);
                n >>>= 2637;
            }
        }
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3) + Double.doubleToLongBits(d) + (long)n7 + (long)n4 + (long)n5 + (long)n6 + l;
    }

    public static int iMeth() {
        int n = 38915;
        int n2 = -9;
        int n3 = -12;
        int n4 = -4;
        double d = -2.69176;
        for (n = 9; 213 > n; ++n) {
            try {
                iFld = iArrFld[n - 1] / -53408;
                n2 = 1813546770 % n2;
                Test.iArrFld[n + 1] = iArrFld[n - 1] % -8;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            for (n3 = 1; 8 > n3; ++n3) {
                int n5 = n3 - 1;
                int n6 = iArrFld[n5] - 1;
                iArrFld[n5] = n6;
                n4 -= n6 - (Math.abs(-12) + n3);
                Test.vMeth(fFld1, n3);
                n2 -= 140;
                n2 = iFld = n;
                instanceCount = (long)(fFld1 += (float)n3);
                switch (n % 2 * 5 + 11) {
                    case 12: {
                        if (n3 != 0) {
                            // empty if block
                        }
                        instanceCount -= 16L;
                        int n7 = n3 - 1;
                        iArrFld[n7] = iArrFld[n7] * n4;
                    }
                    case 17: {
                        n4 = (int)d;
                    }
                }
                d += 40311.0;
            }
        }
        long l = (long)(n + n2 + n3 + n4) + Double.doubleToLongBits(d);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -11;
        int n2 = -4;
        int n3 = -6;
        int n4 = 116;
        int n5 = -1;
        int n6 = -11;
        int n7 = 15;
        double[] dArray = new double[400];
        boolean[] blArray = new boolean[400];
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(dArray, 0.56855);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(lArray, -3426413554L);
        iFld -= (int)instanceCount--;
        sFld = (short)(sFld + (short)(this.fFld += 1.0f));
        for (n = 174; 2 < n; --n) {
            n3 = 1;
            do {
                for (n4 = 1; n4 < 1; ++n4) {
                    iFld <<= -52526;
                    this.fFld -= 5.0f;
                    n2 ^= n5;
                    sFld = (short)(sFld >> (short)n);
                    switch (n % 3 + 94) {
                        case 94: {
                            n5 = n;
                            n2 += n4;
                            n2 ^= n4;
                            fFld1 *= (float)n4;
                            break;
                        }
                        case 95: {
                            int n8 = n;
                            dArray[n8] = dArray[n8] * (double)n5;
                            iFld = (int)((float)iFld + ((float)n4 * this.fFld + (float)n4 - (float)iFld));
                            break;
                        }
                        case 96: {
                            iFld = (int)((long)iFld + ((long)n4 * instanceCount + (long)iFld - (long)n));
                        }
                    }
                    sFld = (short)121;
                    int n9 = n4 + 1;
                    dArray[n9] = dArray[n9] - (double)(instanceCount += (long)n4);
                    n2 -= n;
                    instanceCount += (long)(n4 + n6);
                    blArray[n - 1] = this.bFld;
                }
            } while (++n3 < 146);
            lArray[n] = lArray[n];
        }
        n7 = (byte)instanceCount;
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 i4 i22 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("by1 dArr bArr = " + n7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
        FuzzerUtils.out.println("fFld bFld Test.fFld1 = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld1));
        FuzzerUtils.out.println("Test.bFld1 Test.iArrFld = " + (bFld1 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 93);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

