/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 4L;
    public float[] fArrFld = new float[400];
    public static long lMeth_check_sum = 0L;
    public static long dMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;

    public static void vMeth(int n, int n2) {
        int n3 = 3;
        int n4 = -165;
        int n5 = 102;
        int n6 = 227;
        int n7 = 9076;
        int n8 = -109;
        int[] nArray = new int[400];
        float f = -86.678f;
        float[] fArray = new float[400];
        long l = -5L;
        long[] lArray = new long[400];
        boolean bl = false;
        FuzzerUtils.init(lArray, 4319310807116406889L);
        FuzzerUtils.init(fArray, 87.964f);
        FuzzerUtils.init(nArray, -6);
        for (n3 = 17; n3 < 283; ++n3) {
            lArray[n3 - 1] = n4;
            n2 += n3 * n + n2 - n3;
            n4 += (int)instanceCount;
            instanceCount += (long)f;
            for (n5 = 1; n5 < 6; ++n5) {
                for (l = 1L; l < 2L; ++l) {
                    int n9 = (int)l;
                    nArray[n9] = nArray[n9] * n6;
                    n2 += (int)(l + (long)n7);
                    n2 = (int)f;
                    bl = false;
                    n2 += (int)(l * (long)n2 + (long)n4 - (long)n8);
                    instanceCount = -3955237631L;
                    n4 += (int)(l | (long)f);
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6) + l + (long)n7 + (long)(bl ? 1 : 0) + (long)n8 + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public static double dMeth(int n, float f) {
        int n2 = -204;
        int n3 = -185;
        int n4 = -14;
        int n5 = 65202;
        int n6 = -12;
        int[] nArray = new int[400];
        int n7 = 97;
        FuzzerUtils.init(nArray, -60316);
        Test.vMeth(n, n);
        int n8 = (n >>> 1) % 400;
        nArray[n8] = nArray[n8] >>> -14;
        n2 = 1;
        while (++n2 < 275) {
            for (n3 = 1; 6 > n3; ++n3) {
                block11: for (n5 = n3; n5 < 2; ++n5) {
                    boolean bl = false;
                    long l = -1907497295189160996L;
                    n <<= (int)instanceCount;
                    if (bl) {
                        n -= 27902;
                        f *= -24772.0f;
                        f = n3;
                    } else if (bl) {
                        instanceCount += (long)n5;
                    }
                    switch (n5 % 7 * 5 + 60) {
                        case 86: {
                            n += n5 * n5;
                            n -= n;
                            continue block11;
                        }
                        case 66: {
                            nArray[n5 + 1] = n7;
                            continue block11;
                        }
                        case 83: {
                            n6 -= n2;
                        }
                        case 74: {
                            n7 = 39;
                        }
                        case 92: {
                            l += 90L;
                            continue block11;
                        }
                        case 67: {
                            instanceCount >>= n5;
                            continue block11;
                        }
                        case 78: {
                            n7 = (byte)(n7 + (byte)((long)(n5 * n7 + n4) - instanceCount));
                        }
                    }
                }
            }
        }
        long l = (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
        dMeth_check_sum += l;
        return l;
    }

    public long lMeth(int n) {
        float f = 20.951f;
        Test.dMeth(n, f);
        instanceCount = 0L;
        this.fArrFld = this.fArrFld;
        long l = n + Float.floatToIntBits(f);
        lMeth_check_sum += l;
        return l;
    }

    public void mainTest(String[] stringArray) {
        int n = 211;
        int n2 = -26;
        int n3 = 53;
        n = n - (int)(((double)(n - n3) + 5.72502 / (double)(n >> (int)instanceCount | 1)) * (double)((long)n++ + (-3953315401L + this.lMeth(n2))));
        FuzzerUtils.out.println("i by i16 = " + n + "," + n3 + "," + n2);
        FuzzerUtils.out.println("Test.instanceCount fArrFld = " + instanceCount + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

