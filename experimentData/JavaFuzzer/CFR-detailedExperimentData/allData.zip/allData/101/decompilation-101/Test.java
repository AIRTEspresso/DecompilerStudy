/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -73L;
    public static volatile int iFld = -39797;
    public static boolean bFld = true;
    public static double dFld = 3.15632;
    public static float fFld = -2.177f;
    public static byte byFld = (byte)55;
    public int iFld1 = 8;
    public static short sFld = (short)-7885;
    public static boolean bFld1 = true;
    public static long[] lArrFld = new long[400];
    public double[][][] dArrFld = new double[400][400][400];
    public int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(double d) {
        int n = 2;
        int n2 = -10;
        int n3 = 136;
        int n4 = 130;
        int n5 = -8;
        int n6 = -43993;
        int n7 = -6;
        int[] nArray = new int[400];
        double d2 = -41.96886;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(nArray, -198);
        for (n = 13; 268 > n; ++n) {
            for (d2 = 6.0; d2 > 1.0; d2 -= 1.0) {
                n3 *= -29920;
            }
            block2: for (n4 = 1; n4 < 6; ++n4) {
                blArray[n4] = bFld;
                iFld = (int)((long)iFld + ((long)n4 ^ instanceCount));
                instanceCount %= (long)(n | 1);
                for (n6 = 2; 1 < n6; n6 -= 3) {
                    int n8 = n - 1;
                    nArray[n8] = nArray[n8] + n3;
                    n3 = n4;
                    instanceCount *= (long)n2;
                    int n9 = n + 1;
                    lArrFld[n9] = lArrFld[n9] >> n;
                    n5 -= iFld;
                    if (bFld) continue block2;
                    n3 = n;
                }
            }
        }
        vMeth2_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n2 + Double.doubleToLongBits(d2) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(int n) {
        int n2 = -59969;
        int n3 = 51840;
        int n4 = -9;
        int n5 = 21085;
        int n6 = -7;
        int n7 = -12;
        int n8 = 51;
        int n9 = 5;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -2.782f);
        Test.vMeth2(dFld);
        for (n2 = 11; n2 < 282; n2 += 3) {
            block1: for (n4 = 1; n4 < 17; ++n4) {
                int n10 = (n2 >>> 1) % 400;
                fArray[n10] = fArray[n10] + (float)n4;
                if (bFld) continue;
                if (bFld) {
                    fFld = n3;
                    continue;
                }
                for (n6 = 1; n6 < 2; ++n6) {
                    Test.lArrFld[n4 + 1] = (long)fFld;
                    iFld = (int)fFld;
                    Test.lArrFld[n4 + 1] = n3;
                }
                for (n8 = 1; n8 < 2; ++n8) {
                    n3 = (int)((float)n3 + ((float)n8 * fFld + (float)n3 - (float)instanceCount));
                    iFld = 58440;
                    if (bFld) continue block1;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void vMeth(int n, long l, long l2) {
        int n2 = -189;
        int n3 = -12;
        int n4 = 11;
        int n5 = 64;
        int[] nArray = new int[400];
        double d = 101.56145;
        int n6 = 20639;
        FuzzerUtils.init(nArray, 4);
        n *= iFld;
        Test.vMeth1(iFld);
        block10: for (n2 = 10; n2 < 384; ++n2) {
            if (bFld) {
                iFld *= iFld;
            } else {
                n3 *= (int)fFld;
                nArray[n2 - 1] = -89;
            }
            switch (n2 % 7 + 24) {
                case 24: {
                    d = 1.0;
                    do {
                        for (n4 = 1; 1 > n4; ++n4) {
                            n6 = (short)(n6 * byFld);
                            l = iFld;
                        }
                    } while ((d += 1.0) < 5.0);
                }
                case 25: {
                    try {
                        nArray[n2 + 1] = n5 % n5;
                        nArray[n2] = 30 / iFld;
                        nArray[n2 + 1] = -1488794660 % n4;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    continue block10;
                }
                case 26: {
                    fFld -= (float)n4;
                    continue block10;
                }
                case 27: {
                    if (n5 == 0) continue block10;
                    vMeth_check_sum += (long)n + l + l2 + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
                    return;
                }
                case 28: 
                case 29: {
                    iFld = 52293;
                    continue block10;
                }
                case 30: {
                    byFld = (byte)(byFld * (byte)iFld);
                    continue block10;
                }
                default: {
                    n6 = (short)l2;
                }
            }
        }
        vMeth_check_sum += (long)n + l + l2 + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -66;
        int n2 = -5;
        int n3 = 10;
        int n4 = 0;
        int n5 = -13;
        int n6 = 6;
        int n7 = 64474;
        int n8 = 10;
        int n9 = -9;
        float f = 4.56f;
        n = 371;
        while (--n > 0) {
            n2 <<= --iFld + n2;
            this.vMeth(n, -49L, instanceCount);
            double[] dArray = this.dArrFld[n + 1][n];
            int n10 = n + 1;
            dArray[n10] = dArray[n10] + (double)instanceCount;
            this.dArrFld[n + 1][n + 1][n + 1] = n;
            if (bFld) break;
            this.iArrFld[n] = iFld;
            fFld += (float)n;
            iFld = 30403;
        }
        if (bFld1) {
            for (n3 = 223; n3 > 9; n3 -= 3) {
                n6 -= (int)instanceCount;
            }
        } else {
            n9 -= (int)dFld;
        }
        FuzzerUtils.out.println("i i1 i24 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i25 i26 i27 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i28 i29 f = " + n7 + "," + n8 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i30 = " + n9);
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dFld Test.fFld Test.byFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + byFld);
        FuzzerUtils.out.println("iFld1 Test.sFld Test.bFld1 = " + this.iFld1 + "," + sFld + "," + (bFld1 ? 1 : 0));
        FuzzerUtils.out.println("Test.lArrFld dArrFld iArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])this.dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 6L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

