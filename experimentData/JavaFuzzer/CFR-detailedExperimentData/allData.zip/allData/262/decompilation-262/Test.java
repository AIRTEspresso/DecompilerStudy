/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -6L;
    public byte byFld = (byte)-1;
    public double dFld = 58.27429;
    public static short sFld = (short)29103;
    public boolean bFld = false;
    public static volatile long[][] lArrFld = new long[400][400];
    public static long dMeth_check_sum;
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;

    public int iMeth() {
        int n = -3;
        int n2 = 52825;
        int n3 = 41086;
        int n4 = -963;
        int n5 = 58605;
        int n6 = 38547;
        int n7 = -11;
        int[] nArray = new int[400];
        boolean bl = true;
        double d = 119.89531;
        float f = 0.903f;
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(fArray, -2.175f);
        FuzzerUtils.init(lArray, -2830177830L);
        FuzzerUtils.init(nArray, -62700);
        for (n = 8; 318 > n && !bl; ++n) {
            n2 += (int)this.dFld;
            for (d = 1.0; d < 5.0; d += 1.0) {
                this.dFld -= (double)n3;
                this.byFld = (byte)92;
                fArray[(int)(d + 1.0)] = instanceCount;
            }
            n3 = (int)((float)n3 + ((float)n * f + (float)this.byFld - f));
            block7: for (n4 = 1; n4 < 5; ++n4) {
                int n8 = -11086;
                int n9 = n;
                nArray[n9] = nArray[n9] * n4;
                switch ((n3 >>> 1) % 3 + 87) {
                    case 87: {
                        for (n6 = 1; 2 > n6; n6 += 2) {
                            n2 = (int)((float)n2 + ((float)n6 + (f -= (float)n4)));
                            int n10 = n6 - 1;
                            nArray[n10] = nArray[n10] - 235;
                        }
                        continue block7;
                    }
                    case 88: {
                        n7 = (int)f;
                    }
                    case 89: {
                        n8 = (short)(n8 * (short)instanceCount);
                        continue block7;
                    }
                    default: {
                        instanceCount >>= this.byFld;
                    }
                }
            }
        }
        long l = (long)(n + n2 + (bl ? 1 : 0)) + Double.doubleToLongBits(d) + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void vMeth() {
        int n = -934;
        int n2 = -11;
        int n3 = 185;
        float f = -2.479f;
        float f2 = 0.29f;
        this.byFld = (byte)this.iMeth();
        for (n = 8; n < 372; ++n) {
            for (f = (float)n; f < 5.0f; f += 1.0f) {
                n2 += (int)f;
            }
            n3 += n - n;
            instanceCount *= (long)this.dFld;
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + (n3 += n) + Float.floatToIntBits(f2 *= -3.04787712E8f));
    }

    public double dMeth() {
        int n = 36184;
        int n2 = 1;
        int n3 = -42285;
        int n4 = -3;
        int[][] nArray = new int[400][400];
        long l = 447504782L;
        float f = 69.681f;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.746f);
        FuzzerUtils.init(nArray, 9082);
        this.vMeth();
        n -= n;
        n += (int)instanceCount;
        for (n2 = 16; n2 < 354; ++n2) {
            try {
                n3 = n / n3;
                n3 = n / n;
                n = n2 % n2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            l = 1L;
            do {
                n3 ^= sFld;
                n4 = 1;
                while ((n4 -= 3) > 0) {
                    instanceCount += (long)(-40309 + n4 * n4);
                    f -= (float)n4;
                    fArray[(int)l] = n;
                    n <<= -139;
                    int[] nArray2 = nArray[n4 - 1];
                    int n5 = (int)(l + 1L);
                    nArray2[n5] = nArray2[n5] >> 104;
                }
                n <<= n;
            } while (++l < 5L);
        }
        long l2 = (long)(n + n2 + n3) + l + (long)n4 + (long)Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
        dMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -9870;
        int n2 = 4;
        int n3 = -197;
        int n4 = -13;
        int n5 = 88;
        int n6 = -124;
        int n7 = 0;
        int n8 = 7;
        int[][] nArray = new int[400][400];
        double d = -53.102563;
        float f = 118.361f;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(nArray, -6);
        FuzzerUtils.init(byArray, (byte)52);
        n = n-- - (int)((long)n / ((long)((double)n-- * ((double)n + 1.27269)) | 1L));
        block27: for (d = 4.0; d < 125.0; d += 1.0) {
            n2 += (int)(d + (double)instanceCount);
            for (n3 = 7; n3 < 207; ++n3) {
                int[] nArray2 = nArray[n3];
                int n9 = (int)(d + 1.0);
                nArray2[n9] = nArray2[n9] * (int)(-5L - (long)(--n));
                n = (int)this.dMeth();
            }
            switch ((int)(d % 8.0 + 16.0)) {
                case 16: {
                    n <<= n4;
                    block29: for (n5 = 4; n5 < 207; ++n5) {
                        switch (((n4 += n5) >>> 1) % 2 + 99) {
                            case 99: {
                                switch ((int)(d % 10.0 + 17.0)) {
                                    case 17: {
                                        n4 -= 4500;
                                        this.byFld = (byte)(this.byFld * (byte)d);
                                        n2 += n6;
                                        for (n7 = 1; n7 < 2; ++n7) {
                                            f += (float)d;
                                            try {
                                                n = -85 / n7;
                                                n6 = n5 / n4;
                                                n8 = 140 / n4;
                                            }
                                            catch (ArithmeticException arithmeticException) {
                                                // empty catch block
                                            }
                                            n8 += 69 + n7 * n7;
                                            instanceCount += (long)n3;
                                            n8 = -14;
                                            nArray[(n8 >>> 1) % 400] = nArray[317];
                                            f += (float)((long)n7 ^ (long)f);
                                            instanceCount -= instanceCount;
                                            n2 = n4;
                                        }
                                        continue block29;
                                    }
                                    case 18: {
                                        int[] nArray3 = nArray[n5];
                                        int n10 = n5;
                                        nArray3[n10] = nArray3[n10] - (int)f;
                                        n6 += n6;
                                        n8 = (int)this.dFld;
                                        if (!this.bFld) continue block29;
                                        break;
                                    }
                                    case 19: {
                                        f -= -27416.0f;
                                        break;
                                    }
                                    case 20: {
                                        n2 += n5 * n6 + this.byFld - n7;
                                        break;
                                    }
                                    case 21: {
                                        break;
                                    }
                                    case 22: {
                                        f += (float)(n5 + this.byFld);
                                    }
                                    case 23: {
                                        instanceCount += (long)n5 * instanceCount;
                                        break;
                                    }
                                    case 24: {
                                        if (this.bFld) break;
                                    }
                                    case 25: {
                                        this.bFld = this.bFld;
                                        break;
                                    }
                                    case 26: {
                                        int[] nArray4 = nArray[(int)d];
                                        int n11 = (int)(d - 1.0);
                                        nArray4[n11] = nArray4[n11] << n4;
                                        break;
                                    }
                                    default: {
                                        this.dFld -= (double)n6;
                                        break;
                                    }
                                }
                                continue block29;
                            }
                            case 100: {
                                n2 -= n7;
                                continue block29;
                            }
                        }
                    }
                    continue block27;
                }
                case 17: {
                    n6 *= n5;
                }
                case 18: {
                    n6 >>= this.byFld;
                    continue block27;
                }
                case 19: {
                    n *= -219;
                    continue block27;
                }
                case 20: {
                    n = -14;
                    continue block27;
                }
                case 21: {
                    int n12 = (int)(d - 1.0);
                    byArray[n12] = (byte)(byArray[n12] * (byte)n5);
                }
                case 22: 
                case 23: {
                    if (!this.bFld) continue block27;
                    continue block27;
                }
            }
        }
        FuzzerUtils.out.println("i d i1 = " + n + "," + Double.doubleToLongBits(d) + "," + n2);
        FuzzerUtils.out.println("i2 i3 i18 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i19 i20 i21 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("f4 iArr byArr = " + Float.floatToIntBits(f) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount byFld dFld = " + instanceCount + "," + this.byFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.sFld bFld Test.lArrFld = " + sFld + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -3972438219L);
        dMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

