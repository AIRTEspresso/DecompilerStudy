/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 5830344760535448422L;
    public static byte byFld = (byte)-9;
    public static boolean bFld = true;
    public static int[] iArrFld = new int[400];
    public long[] lArrFld = new long[400];
    public float[] fArrFld = new float[400];
    public static long vSmallMeth_check_sum;
    public static long iMeth_check_sum;
    public static long bMeth_check_sum;

    public static void vSmallMeth(int n) {
        n += n;
        vSmallMeth_check_sum += (long)n;
    }

    public static boolean bMeth(long l) {
        int n = -2;
        int n2 = 23;
        int n3 = -3;
        int n4 = 25343;
        int n5 = 9;
        int n6 = 13358;
        int[] nArray = new int[400];
        double d = 0.118501;
        int n7 = 18177;
        FuzzerUtils.init(nArray, -12127);
        Test.vSmallMeth(n);
        for (d = 145.0; 3.0 < d; d -= 1.0) {
            n += (int)d;
            n += (int)d;
            instanceCount = n2;
            int n8 = (int)d;
            nArray[n8] = nArray[n8] | (n -= 47);
        }
        for (n3 = 9; n3 < 190; ++n3) {
            ++instanceCount;
        }
        for (n5 = 8; n5 < 201; ++n5) {
            int n9 = n5;
            nArray[n9] = nArray[n9] + (int)l;
            n6 += (int)l;
            int n10 = n5 + 1;
            nArray[n10] = nArray[n10] + n7;
            n *= n4;
            n6 *= n6;
        }
        long l2 = l + (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
        bMeth_check_sum += l2;
        return l2 % 2L > 0L;
    }

    public static int iMeth(int n, short s) {
        int n2 = 195;
        int n3 = 84;
        int n4 = -29841;
        int n5 = 21852;
        int n6 = -64578;
        int n7 = 220;
        int n8 = 11;
        int n9 = -16757;
        double d = -26.1473;
        Test.bMeth(3489460398L);
        for (n2 = 18; n2 < 297; ++n2) {
            n4 = 1;
            while (++n4 < 6) {
                for (n5 = 1; n5 < 1; n5 += 3) {
                    n3 += (int)instanceCount;
                    int n10 = n2 - 1;
                    iArrFld[n10] = iArrFld[n10] | n6;
                    n3 = -14;
                }
                n6 += (int)(2441361569086449615L + (long)(n4 * n4));
            }
            d += (double)s;
            for (n7 = 1; n7 < 6; ++n7) {
                try {
                    n8 = 43826 / n;
                    n8 = 221 / n3;
                    n3 = n2 % -1167312081;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n9 = 1;
                do {
                    instanceCount = -13269L;
                } while (++n9 < 2);
                int n11 = n7 + 1;
                iArrFld[n11] = iArrFld[n11] >>> n8;
                n -= n7;
            }
        }
        long l = (long)(n + s + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + (long)n8 + (long)n9;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 159;
        int n2 = 6;
        int n3 = 52873;
        int n4 = -154;
        int n5 = 6933;
        int n6 = 1;
        int n7 = -70;
        int n8 = -14;
        int n9 = -3;
        int n10 = 189;
        float f = 0.335f;
        double d = -2.24006;
        byte[] byArray = new byte[400];
        short[] sArray = new short[400];
        FuzzerUtils.init(byArray, (byte)50);
        FuzzerUtils.init(sArray, (short)-17221);
        for (int i = 0; i < 990; ++i) {
            Test.vSmallMeth(--n - Math.min((int)((float)n - 82.367f), Test.iMeth(0, (short)23964)));
        }
        f += -1.737f;
        d *= (double)n;
        for (n2 = 237; n2 > 9; --n2) {
            instanceCount = n2;
            n = (int)((long)n + ((long)n2 * instanceCount + (long)n2 - (long)byFld));
            instanceCount *= instanceCount;
        }
        block12: for (n4 = 10; n4 < 199; ++n4) {
            f *= 126.468f;
            instanceCount += (long)(n4 + n5);
            if (bFld) continue;
            switch ((n2 >>> 1) % 5 + 56) {
                case 56: {
                    n6 = 1;
                    while (++n6 < 133) {
                        switch (n4 % 2 + 49) {
                            case 49: {
                                this.lArrFld[n4 + 1] = n3;
                                d -= (double)f;
                                f += (float)(n6 * n6);
                                break;
                            }
                            case 50: {
                                n5 -= n5;
                                n3 *= -65242;
                                int n11 = n4;
                                this.fArrFld[n11] = this.fArrFld[n11] + (float)d;
                                n3 -= n;
                            }
                        }
                        f -= (float)n2;
                        for (n7 = 1; n7 < 1; ++n7) {
                            n3 = 15119;
                        }
                        n <<= n3;
                    }
                    for (n9 = 133; n9 > 6; --n9) {
                        int n12 = n4;
                        byArray[n12] = (byte)(byArray[n12] + (byte)n9);
                        n3 -= (int)instanceCount;
                    }
                    continue block12;
                }
                case 57: 
                case 58: {
                    d += 9.0;
                    continue block12;
                }
                case 59: {
                    sArray[n4] = (short)n4;
                    continue block12;
                }
                case 60: {
                    n = byFld;
                    continue block12;
                }
                default: {
                    instanceCount += (long)n7;
                }
            }
        }
        FuzzerUtils.out.println("i1 f d2 = " + n + "," + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i17 i18 i19 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i20 i21 i22 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i23 i24 i25 = " + n8 + "," + n9 + "," + n10);
        FuzzerUtils.out.println("byArr sArr = " + FuzzerUtils.checkSum(byArray) + "," + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.bFld = " + instanceCount + "," + byFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iArrFld lArrFld fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -112);
        vSmallMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
    }
}

