/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 34275L;
    public static float fFld = -56.119f;
    public static long lFld = 2012182374L;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long vMeth2_check_sum = 0L;

    public static void vMeth2(int n, int n2, float f) {
        int n3 = 51;
        int n4 = 3923;
        int n5 = -2;
        int n6 = 2;
        int[] nArray = new int[400];
        long l = -1125702414L;
        long[][] lArray = new long[400][400];
        double d = -2.18765;
        boolean bl = true;
        FuzzerUtils.init(lArray, -66L);
        FuzzerUtils.init(nArray, 7);
        for (n3 = 373; n3 > 18; n3 -= 3) {
            instanceCount = n4;
        }
        lArray = FuzzerUtils.long2array(400, 2863929807L);
        long[] lArray2 = lArray[8];
        int n7 = (n3 >>> 1) % 400;
        lArray2[n7] = lArray2[n7] | instanceCount;
        n5 = 1;
        do {
            n4 += (int)fFld;
        } while (++n5 < 360);
        f = instanceCount;
        n2 = n5;
        for (l = 1L; l < 221L; ++l) {
            n2 *= (int)f;
            d *= (double)n6;
            n2 >>= n;
            int n8 = (int)l;
            nArray[n8] = nArray[n8] * 1816082270;
        }
        vMeth2_check_sum += (long)(n + (n2 %= 12210) + Float.floatToIntBits(f) + n3 + n4 + n5) + l + (long)n6 + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1() {
        int n = 6;
        n = (int)((long)n + ((long)(n + n) + ((long)n + instanceCount)));
        Test.vMeth2(-3, -30, fFld);
        vMeth1_check_sum += (long)n;
    }

    public static void vMeth(int n, short s) {
        int n2 = -45;
        int n3 = 3;
        int n4 = -3;
        int n5 = -154;
        int n6 = 69;
        int n7 = 248;
        int[] nArray = new int[400];
        double d = -112.3736;
        int n8 = -18;
        boolean bl = false;
        FuzzerUtils.init(nArray, 5);
        for (n2 = 291; n2 > 10; n2 -= 2) {
            instanceCount += (long)n4;
            n4 += 38147 + n2 * n2;
            int n9 = n2 - 1;
            int n10 = nArray[n9];
            nArray[n9] = n10 + 1;
            n4 = (int)((double)n10 + ((double)(fFld += 1.0f) - -15.49521 % (double)(instanceCount++ | 1L)));
            block13: for (d = 11.0; d > 1.0; d -= 1.0) {
                n5 += (int)(d * d);
                switch (((int)(-77L * -instanceCount) >>> 1) % 10 + 90) {
                    case 90: {
                        ++n5;
                        Test.vMeth1();
                        lFld = n5;
                        continue block13;
                    }
                    case 91: {
                        fFld = n;
                        continue block13;
                    }
                    case 92: {
                        n6 = 1;
                        while (n6 < 2) {
                            n8 = (byte)(n8 + (byte)n6);
                            n5 = n6++;
                        }
                        continue block13;
                    }
                    case 93: {
                        n5 += (int)instanceCount;
                        continue block13;
                    }
                    case 94: {
                        n4 <<= n7;
                        continue block13;
                    }
                    case 95: {
                        lFld += (long)d;
                        continue block13;
                    }
                    case 96: {
                        n5 = -173;
                        continue block13;
                    }
                    case 97: {
                        n5 = 3182;
                    }
                    case 98: {
                        n7 += (int)d;
                        continue block13;
                    }
                    case 99: {
                        continue block13;
                    }
                    default: {
                        n7 = n;
                    }
                }
            }
        }
        vMeth_check_sum += (long)(n + s + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        float f = 0.175f;
        int n = -54588;
        int n2 = 5;
        int n3 = -62054;
        int n4 = -213;
        int n5 = -4;
        int n6 = -7;
        int n7 = -199;
        int n8 = 11;
        int[][] nArray = new int[400][400];
        short s = -9733;
        int n9 = -8487;
        double d = 2.25882;
        double d2 = -68.91371;
        FuzzerUtils.init(nArray, -24385);
        f *= (float)Long.reverseBytes(n - (n + n));
        Test.vMeth(n, s);
        n2 = 1;
        while (++n2 < 316) {
            fFld -= (float)n;
        }
        n9 = (short)(n9 + (short)n);
        instanceCount = n2;
        try {
            n3 = 1;
            do {
                n += n3;
                for (n4 = n3; n4 < 481; ++n4) {
                    switch (n3 % 7 + 53) {
                        case 53: 
                        case 54: {
                            instanceCount %= (long)(n3 | 1);
                            break;
                        }
                        case 55: {
                            n -= (int)d;
                            n = 0;
                            for (n6 = 1; n6 < 1; ++n6) {
                                lFld += (long)fFld;
                                instanceCount += (long)n6;
                            }
                            n >>>= (int)lFld;
                        }
                        case 56: {
                            nArray[n3 - 1][n3] = n += n4 * n4;
                            nArray[n4] = nArray[n4 - 1];
                            break;
                        }
                        case 57: {
                            for (d2 = 1.0; d2 < 401.0; d2 += 1.0) {
                                n8 = n3;
                            }
                            f += -5.0f;
                        }
                        case 58: {
                            f *= -2.0f;
                        }
                        case 59: {
                            n5 = n4;
                            instanceCount += (long)n;
                            n7 -= n8;
                            break;
                        }
                        default: {
                            lFld += -39L;
                        }
                    }
                    instanceCount -= lFld;
                }
            } while (++n3 < 311);
        }
        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            nArray[5] = nArray[366];
        }
        FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(f) + "," + n + "," + s);
        FuzzerUtils.out.println("i15 s2 i16 = " + n2 + "," + n9 + "," + n3);
        FuzzerUtils.out.println("i17 i18 d2 = " + n4 + "," + n5 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i19 i20 d3 = " + n6 + "," + n7 + "," + Double.doubleToLongBits(d2));
        FuzzerUtils.out.println("i21 iArr2 = " + n8 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

