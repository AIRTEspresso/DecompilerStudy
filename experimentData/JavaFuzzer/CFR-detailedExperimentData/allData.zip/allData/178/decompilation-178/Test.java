/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -8876196576951346957L;
    public static int iFld = 2;
    public volatile short sFld = (short)-18905;
    public static int[] iArrFld = new int[400];
    public static double[][] dArrFld = new double[400][400];
    public static long fMeth_check_sum;
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;

    /*
     * Enabled aggressive block sorting
     */
    public static long lMeth(int n) {
        int n2 = 30755;
        int n3 = -60;
        int n4 = 20340;
        int n5 = -4;
        int n6 = -41;
        int n7 = -43396;
        int n8 = 40167;
        int[] nArray = new int[400];
        float f = 1.639f;
        int n9 = 32;
        double d = -64.88658;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -32478);
        FuzzerUtils.init(lArray, 12L);
        n <<= n;
        nArray[43] = nArray[43] | n2;
        n3 = 3;
        while (true) {
            if (n3 < 376) {
            } else {
                long l = (long)(n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f) + n9 + n7 + n8) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
                lMeth_check_sum += l;
                return l;
            }
            block18: for (n5 = 1; n5 < 5; ++n5) {
                f = n;
                switch ((n3 >>> 1) % 7 + 29) {
                    case 29: {
                        n9 = (byte)(n9 + 8);
                        switch (((iFld += n5 * n5 + n4 - n3) >>> 1) % 6 + 111) {
                            case 111: {
                                for (n7 = 1; n7 < 2; n4 += n7 - n5, f += (float)(n7 * n9) + f - (float)instanceCount, ++n7) {
                                    int n10 = n7 + 1;
                                    nArray[n10] = nArray[n10] + n;
                                }
                                n = (int)instanceCount;
                                n4 += n5 * n5;
                                continue block18;
                            }
                            case 112: {
                                n9 = (byte)(n9 * n9);
                            }
                            case 113: {
                                d += (double)n5;
                                continue block18;
                            }
                            case 114: {
                                n -= (int)instanceCount;
                                continue block18;
                            }
                            case 115: {
                                if (!bl) break;
                                continue block18;
                            }
                            case 116: {
                                f = n7;
                            }
                        }
                        continue block18;
                    }
                    case 30: {
                        continue block18;
                    }
                    case 31: {
                        instanceCount = n9;
                        continue block18;
                    }
                    case 32: {
                        int n11 = n3;
                        lArray[n11] = lArray[n11] + 491920893359087281L;
                        continue block18;
                    }
                    case 33: {
                        instanceCount >>= n6;
                    }
                    case 34: {
                        n6 = (int)instanceCount;
                        continue block18;
                    }
                    case 35: {
                        f -= f;
                        continue block18;
                    }
                }
            }
            ++n3;
        }
    }

    public static void vMeth(long l, int n) {
        int n2 = 19848;
        int n3 = 24241;
        l >>= (int)((long)n - Test.lMeth(iFld) << (int)instanceCount);
        n = -28099;
        iFld = -5931;
        instanceCount = l;
        int n4 = (iFld >>> 1) % 400;
        iArrFld[n4] = iArrFld[n4] % (iFld | 1);
        n2 = 1;
        while (++n2 < 287) {
            instanceCount = l;
            n = iFld;
            if (n == 0) continue;
            vMeth_check_sum += l + (long)n + (long)n2 + (long)n3;
            return;
        }
        iFld += n2;
        n3 = 1;
        while (++n3 < 239) {
            n *= n3;
        }
        vMeth_check_sum += l + (long)n + (long)n2 + (long)n3;
    }

    public static float fMeth(int n, float f) {
        int n2 = 24445;
        int n3 = -13;
        int n4 = -9;
        int n5 = 9748;
        int n6 = 11;
        boolean bl = true;
        Test.vMeth(594L, n);
        for (n2 = 15; 316 > n2; ++n2) {
            instanceCount += (long)n2;
            n4 = 5;
            while (--n4 > 0) {
                double[] dArray = dArrFld[n2];
                int n7 = n4 + 1;
                dArray[n7] = dArray[n7] * (double)(instanceCount &= 0xFFFFFFFFFFFFE133L);
                n = (int)((long)n + ((long)n4 ^ (long)(f += (float)(-63590 + n4 * n4))));
            }
            for (n5 = 5; n5 > 1; --n5) {
                iFld <<= n3;
            }
        }
        long l = n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + (bl ? 1 : 0);
        fMeth_check_sum += l;
        return l;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void mainTest(String[] stringArray) {
        int n = 5;
        int n2 = 147;
        int n3 = 179;
        int n4 = 62480;
        int n5 = -54;
        int n6 = -215;
        int n7 = -37874;
        boolean bl = false;
        boolean bl2 = true;
        boolean[] blArray = new boolean[400];
        float f = 53.326f;
        double d = -2.26581;
        int n8 = -60;
        short[] sArray = new short[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(sArray, (short)-12352);
        n = 3;
        while (true) {
            if (n >= 224) {
                FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
                FuzzerUtils.out.println("i3 b f = " + n4 + "," + (bl ? 1 : 0) + "," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("i20 i21 d1 = " + n5 + "," + n6 + "," + Double.doubleToLongBits(d));
                FuzzerUtils.out.println("i22 by1 b3 = " + n7 + "," + n8 + "," + (bl2 ? 1 : 0));
                FuzzerUtils.out.println("bArr sArr = " + FuzzerUtils.checkSum(blArray) + "," + FuzzerUtils.checkSum(sArray));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
                FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
                return;
            }
            n3 = 114;
            do {
                n4 = 1;
                while (++n4 < 1) {
                    blArray[n3 - 1] = bl;
                }
                switch (n % 1 + 19) {
                    case 19: {
                        f += Test.fMeth(n4, 0.999f) + (float)n;
                        break;
                    }
                }
                block29: for (n5 = n3; n5 < 1; ++n5) {
                    switch (n3 % 5 * 5 + 57) {
                        case 68: {
                            iFld = n6;
                            Test.iArrFld[n3] = -88;
                            switch ((n2 >>> 1) % 7 + 46) {
                                case 46: {
                                    switch ((n6 >>> 1) % 1 * 5 + 54) {
                                        case 57: {
                                            int n9 = n5;
                                            iArrFld[n9] = iArrFld[n9] * (int)d;
                                            n6 = n2 >>= n3;
                                            instanceCount += (long)(n5 * n5) + instanceCount - (long)n2;
                                            break;
                                        }
                                    }
                                }
                                case 47: {
                                    switch ((n5 >>> 1) % 2 * 5 + 109) {
                                        case 117: {
                                            n6 >>= n5;
                                            n6 -= iFld;
                                            n2 |= n5;
                                            iFld |= (int)instanceCount;
                                            continue block29;
                                        }
                                        case 111: {
                                            n7 *= n3;
                                            continue block29;
                                        }
                                    }
                                    continue block29;
                                }
                                case 48: {
                                    n8 = (byte)(n8 + (byte)((long)n5 * instanceCount + (long)n - (long)n3));
                                    n2 += n5 + n8;
                                }
                                case 49: {
                                    int n10 = n3 + 1;
                                    iArrFld[n10] = iArrFld[n10] * n4;
                                    iFld *= (int)d;
                                    instanceCount += (long)d;
                                }
                                case 50: {
                                    iFld += n5 * this.sFld + n4 - n;
                                }
                                case 51: {
                                    if (!bl2) break;
                                    continue block29;
                                }
                                case 52: {
                                    iFld = n5;
                                }
                            }
                            continue block29;
                        }
                        case 61: {
                            n7 += -66 + n5 * n5;
                            continue block29;
                        }
                        case 63: {
                            instanceCount += (long)n5;
                        }
                        case 59: {
                            int n11 = n5 - 1;
                            sArray[n11] = (short)(sArray[n11] | (short)n2);
                        }
                        case 64: {
                            continue block29;
                        }
                    }
                }
            } while (--n3 > 0);
            ++n;
        }
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 4);
        FuzzerUtils.init(dArrFld, -92.19358);
        fMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

