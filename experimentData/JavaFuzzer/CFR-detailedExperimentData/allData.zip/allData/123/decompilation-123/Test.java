/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -58487L;
    public static short sFld = (short)-24700;
    public static long[] lArrFld = new long[400];
    public volatile double[][][] dArrFld = new double[400][400][400];
    public int[] iArrFld = new int[400];
    public long[][] lArrFld1 = new long[400][400];
    public int[][] iArrFld1 = new int[400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth() {
        int n = 7;
        int n2 = 10;
        int n3 = -11;
        int n4 = 247;
        int n5 = -15555;
        int n6 = -3;
        int[] nArray = new int[400];
        float f = -33.896f;
        float f2 = -2.34f;
        double d = -96.20907;
        int n7 = 25;
        FuzzerUtils.init(nArray, 57874);
        n = 1;
        do {
            block5: for (f = (float)n; f < 5.0f; f += 1.0f) {
                nArray[(int)(f + 1.0f)] = (int)d;
                switch (((n2 += (int)f) >>> 1) % 2 * 5 + 111) {
                    case 120: {
                        d = 46531.0;
                        f2 += (float)n;
                        for (n3 = 1; n3 < 1; ++n3) {
                            instanceCount -= (long)n2;
                            f2 += (float)n3;
                            instanceCount += (long)n2;
                        }
                        continue block5;
                    }
                    case 113: {
                        for (n5 = (int)f; n5 < 1; ++n5) {
                            instanceCount = n5;
                            n7 = (byte)(n7 + (byte)((float)n5 * f + (float)instanceCount - (float)n));
                        }
                        int n8 = (int)(f - 1.0f);
                        nArray[n8] = nArray[n8] >> n;
                        continue block5;
                    }
                    default: {
                        n2 = n6;
                    }
                }
            }
        } while (++n < 341);
        long l = (long)(n + Float.floatToIntBits(f) + n2) + Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f2) + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1(int n, int n2) {
        int n3 = -6437;
        float f = 66.929f;
        lArrFld[91] = lArrFld[91] >> Math.min(80 + n3, (int)(f - (float)n)) - (Test.iMeth() - n2);
        vMeth1_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f));
    }

    public static void vMeth(int n, int n2, long l) {
        int n3 = 177;
        int n4 = 48;
        int n5 = 1;
        int n6 = -1;
        int n7 = 26099;
        int n8 = 11588;
        int[][] nArray = new int[400][400];
        long l2 = 2074981987686830504L;
        double d = 0.1631;
        int n9 = 104;
        byte[] byArray = new byte[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(nArray, 1);
        FuzzerUtils.init(fArray, -1.738f);
        FuzzerUtils.init(byArray, (byte)0);
        block14: for (n3 = 268; n3 > 4; n3 -= 3) {
            switch (n3 % 9 + 76) {
                case 76: {
                    for (n5 = 1; n5 < 18; ++n5) {
                        for (l2 = 1L; 2L > l2; ++l2) {
                            d += (double)l;
                            int[] nArray2 = nArray[n5 + 1];
                            int n10 = (int)(l2 - 1L);
                            int[] nArray3 = nArray[n5 + 1];
                            int n11 = n3 - 1;
                            int n12 = nArray3[n11];
                            nArray3[n11] = n12 - 1;
                            nArray2[n10] = nArray2[n10] - (int)((long)n12 - lArrFld[n3]);
                            Test.vMeth1(n2, -99);
                        }
                        l = -3L;
                        n8 = 1;
                        do {
                            int n13 = -70;
                            fArray[n5 + 1] = n5;
                            try {
                                n = nArray[n3 + 1][n5] % n2;
                                n6 = -58704 / n3;
                                n4 = n2 % -1235870547;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n13 = (byte)(n13 + (byte)n8);
                            d = n5;
                        } while (++n8 < 2);
                        int[] nArray4 = nArray[n3 + 1];
                        int n14 = n5 - 1;
                        nArray4[n14] = nArray4[n14] >> n6;
                    }
                }
                case 77: {
                    try {
                        n = nArray[n3][n3 + 1] % nArray[n3 - 1][n3 - 1];
                        n7 = -20843 % n7;
                        n4 = -21 % n2;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                case 78: {
                    n7 = n9;
                    continue block14;
                }
                case 79: {
                    nArray[n3][n3] = n2;
                }
                case 80: {
                    l = n8;
                    continue block14;
                }
                case 81: {
                    n4 += n3 * n + n6 - n8;
                    continue block14;
                }
                case 82: {
                    n4 = n5;
                    continue block14;
                }
                case 83: {
                    n2 -= n7;
                    continue block14;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + l + (long)n3 + (long)n4 + (long)n5 + (long)n6 + l2 + (long)n7 + Double.doubleToLongBits(d) + (long)n8 + (long)n9 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(byArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -13;
        int n2 = 18415;
        int n3 = 11;
        int n4 = 4;
        int n5 = -254;
        int n6 = -156;
        int n7 = 4;
        int n8 = 6;
        int n9 = 11;
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        double d = 28.15279;
        double d2 = -1.104601;
        double d3 = 1.65179;
        float f = -65.49f;
        FuzzerUtils.init(blArray, true);
        for (n = 10; 304 > n; ++n) {
            Test.vMeth(n2, n2, instanceCount);
            if (bl) continue;
            for (d = 86.0; d > (double)n; d -= 2.0) {
                for (n4 = 1; n4 < 1; ++n4) {
                    instanceCount *= -1L;
                    n3 *= n2;
                }
                n6 = 1;
                while ((n6 += 3) < 1) {
                    this.dArrFld[n + 1][n][42] = n2;
                    blArray[n] = bl;
                    this.dArrFld[n6 + 1][n + 1] = this.dArrFld[n6][n];
                }
            }
            n7 = 86;
            block23: while ((n7 -= 3) > 0) {
                n5 |= n2;
                sFld = (short)(sFld + (short)(n7 + n3));
                instanceCount ^= (long)n;
                switch (n7 % 9 * 5 + 44) {
                    case 75: {
                        if (bl) continue block23;
                    }
                    case 54: {
                        n5 ^= 0xFFFFFF78;
                        n5 = n3;
                        block24: for (d2 = (double)n; d2 < 3.0; d2 += 1.0) {
                            n9 += (int)(d2 * d2);
                            n9 += (int)d2;
                            switch (n % 7 + 12) {
                                case 12: {
                                    if (bl) continue block24;
                                    n2 = n3 += (int)(d2 * d2);
                                    n9 += (int)(d2 + (double)instanceCount);
                                    continue block24;
                                }
                                case 13: {
                                    n3 *= n3;
                                    int n10 = n7 + 1;
                                    this.iArrFld[n10] = this.iArrFld[n10] >> n5;
                                    instanceCount += (long)d2;
                                    continue block24;
                                }
                                case 14: {
                                    f += (float)n6;
                                    continue block24;
                                }
                                case 15: {
                                    d3 -= -12.0;
                                    continue block24;
                                }
                                case 16: {
                                    int n11 = n;
                                    lArrFld[n11] = lArrFld[n11] << (int)instanceCount;
                                    continue block24;
                                }
                                case 17: {
                                    this.lArrFld1 = FuzzerUtils.long2array(400, -127L);
                                }
                                case 18: {
                                    n2 += (int)(d2 * (double)n + (double)sFld - (double)n9);
                                }
                            }
                        }
                    }
                    case 72: {
                        this.iArrFld1 = this.iArrFld1;
                    }
                    case 83: {
                        n5 = -55;
                    }
                    case 79: {
                        n8 = (int)((float)n8 + ((float)((long)n7 * instanceCount) + f - (float)n9));
                    }
                    case 68: {
                        n2 = (int)f;
                        continue block23;
                    }
                    case 80: {
                        n5 -= 1502486984;
                        continue block23;
                    }
                    case 69: 
                    case 70: {
                        instanceCount *= 3801956899L;
                    }
                }
                instanceCount <<= (int)instanceCount;
            }
        }
        FuzzerUtils.out.println("i i1 b = " + n + "," + n2 + "," + (bl ? 1 : 0));
        FuzzerUtils.out.println("d2 i18 i19 = " + Double.doubleToLongBits(d) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i20 i21 i22 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("d3 i23 i24 = " + Double.doubleToLongBits(d2) + "," + n8 + "," + n9);
        FuzzerUtils.out.println("f3 d4 bArr = " + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d3) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.lArrFld = " + instanceCount + "," + sFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("dArrFld iArrFld lArrFld1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])this.dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld1));
        FuzzerUtils.out.println("iArrFld1 = " + FuzzerUtils.checkSum(this.iArrFld1));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -7L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

