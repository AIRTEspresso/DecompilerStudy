/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -5222L;
    public static volatile int iFld = 88;
    public boolean bFld = true;
    public float fFld = -36.1f;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long fMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, int n3) {
        int n4 = 163;
        int n5 = 135;
        int n6 = 18796;
        double d = 124.113852;
        int n7 = -16932;
        float f = 0.781f;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -1.329f);
        fArray[226] = fArray[226] * (float)iFld;
        for (n4 = 14; 265 > n4; ++n4) {
            n = n4;
            instanceCount = n4;
            n += (int)d;
            Test.iArrFld[n4] = (int)instanceCount;
            n7 = (short)(n7 + (short)f);
        }
        iFld = (int)f;
        iFld = n;
        n6 = 320;
        do {
            instanceCount *= instanceCount;
            d += (double)n;
            iFld += n;
            f += (float)(n6 + n6);
            iFld = n6;
        } while ((n6 -= 2) > 0);
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)n7 + (long)Float.floatToIntBits(f) + (long)n6 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static float fMeth(int n, float f) {
        Test.vMeth1(n, n, n);
        n >>= n;
        long l = n + Float.floatToIntBits(f);
        fMeth_check_sum += l;
        return l;
    }

    public static void vMeth(int n) {
        double d = 0.54918;
        int n2 = -25327;
        int n3 = -10;
        int n4 = 54959;
        int n5 = -31164;
        boolean bl = true;
        float f = 127.843f;
        d -= (double)(instanceCount * (long)(n2 * iArrFld[(n >>> 1) % 400]));
        switch ((-14227 - (n + -240) >>> 1) % 4 * 5 + 110) {
            case 117: {
                Test.fMeth(iFld, 0.97f);
            }
            case 125: {
                block9: for (n3 = 7; n3 < 175; ++n3) {
                    switch (n3 % 1 + 28) {
                        case 28: {
                            instanceCount += (long)n3;
                            if (bl) continue block9;
                            n5 = 1;
                            do {
                                d -= (double)n5;
                                if (bl) continue;
                                int n6 = n3 + 1;
                                lArrFld[n6] = lArrFld[n6] + -31L;
                                iFld >>= 11;
                                n4 = n5;
                                int n7 = n3 - 1;
                                iArrFld[n7] = iArrFld[n7] - (int)(f *= (float)instanceCount);
                            } while (++n5 < 9);
                            continue block9;
                        }
                        default: {
                            n4 >>= n5;
                        }
                    }
                }
                break;
            }
            case 113: {
                iArrFld[97] = iArrFld[97] * n2;
                break;
            }
            case 121: {
                d = instanceCount;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)(bl ? 1 : 0) + (long)n5 + (long)Float.floatToIntBits(f);
    }

    public void mainTest(String[] stringArray) {
        int n = 26;
        int n2 = -47;
        int n3 = -201;
        int n4 = -50780;
        int n5 = -13;
        int n6 = -34538;
        int n7 = -107;
        int n8 = -9896;
        double d = -41.74295;
        iFld = (int)(instanceCount * (long)(iFld % (n | 1) - (iFld + -43)));
        instanceCount >>>= (int)(3325148203513961961L * (long)(iFld + iFld + iFld++));
        for (n2 = 3; n2 < 152; ++n2) {
            Test.vMeth(249);
            iFld -= (int)instanceCount;
            for (n4 = 6; n4 < 168; ++n4) {
                block28: for (n6 = 1; n6 < 2; ++n6) {
                    switch (n6 % 7 * 5 + 108) {
                        case 140: {
                            if (this.bFld) continue block28;
                            n7 >>>= n4;
                            if (this.bFld) continue block28;
                            iFld *= (int)instanceCount;
                            continue block28;
                        }
                        case 109: {
                            n3 = n7;
                            n3 = (int)((long)n3 + ((long)(n6 * n4 + n5) - instanceCount));
                            this.fFld -= (float)n8;
                            continue block28;
                        }
                        case 134: {
                            n3 += n5;
                            continue block28;
                        }
                        case 132: {
                            n5 = (int)instanceCount;
                            int n9 = n4;
                            dArrFld[n9] = dArrFld[n9] - d;
                            continue block28;
                        }
                        case 135: {
                            n7 %= iFld | 1;
                            n7 *= (int)this.fFld;
                            n8 = (short)(n8 + (short)(n6 * iFld));
                            instanceCount += (long)n6;
                            continue block28;
                        }
                        case 125: {
                            block10 : switch (n2 % 4 + 90) {
                                case 90: {
                                    n3 += n6 ^ n8;
                                    try {
                                        Test.iArrFld[n2 + 1] = -35219 / n6;
                                        iFld = -18791 / n7;
                                        iFld = -257669378 % n7;
                                    }
                                    catch (ArithmeticException arithmeticException) {
                                        // empty catch block
                                    }
                                    switch (n6 % 8 + 21) {
                                        case 21: {
                                            instanceCount -= (long)n3;
                                            break block10;
                                        }
                                        case 22: 
                                        case 23: {
                                            instanceCount = n4;
                                            n7 += n2;
                                            int n10 = n2;
                                            iArrFld[n10] = iArrFld[n10] + (int)instanceCount;
                                            break block10;
                                        }
                                        case 24: {
                                            n5 -= iFld;
                                        }
                                        case 25: {
                                            n7 += n6 * n4;
                                            break block10;
                                        }
                                        case 26: {
                                            n3 += 5118 + n6 * n6;
                                        }
                                        case 27: {
                                            break block10;
                                        }
                                        case 28: {
                                            n3 += n6 ^ n4;
                                        }
                                    }
                                    break;
                                }
                                case 91: {
                                    if (this.bFld) break;
                                }
                                case 92: {
                                    n5 = -8;
                                    break;
                                }
                                case 93: {
                                    n7 ^= 0xFFFFFFD4;
                                    break;
                                }
                                default: {
                                    n7 += n6;
                                    break;
                                }
                            }
                            continue block28;
                        }
                        case 119: {
                            n5 += n6 ^ n2;
                            continue block28;
                        }
                        default: {
                            n = (byte)(n << (byte)n5);
                        }
                    }
                }
            }
        }
        FuzzerUtils.out.println("by i i1 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i13 i14 i15 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i16 s2 d2 = " + n7 + "," + n8 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld bFld = " + instanceCount + "," + iFld + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("fFld Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("Test.dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -2);
        FuzzerUtils.init(lArrFld, 51240L);
        FuzzerUtils.init(dArrFld, 0.119512);
        vMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

