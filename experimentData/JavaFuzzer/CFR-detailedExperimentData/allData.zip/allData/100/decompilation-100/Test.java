/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -164L;
    public static int iFld = -191;
    public static short sFld = (short)9040;
    public static float fFld = 6.937f;
    public boolean bFld = true;
    public static int[] iArrFld = new int[400];
    public static short[] sArrFld = new short[400];
    public static long[] lArrFld = new long[400];
    public byte[] byArrFld = new byte[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2) {
        int n3 = 242;
        int n4 = -12;
        int n5 = -100;
        int n6 = 61712;
        int n7 = 2;
        int[][][] nArray = new int[400][400][400];
        float f = -1.207f;
        int n8 = -15259;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)-26343);
        FuzzerUtils.init((Object[][])nArray, (Object)-43);
        sArray[45] = (short)(sArray[45] >> 5587);
        for (n3 = 5; n3 < 232; ++n3) {
            instanceCount += (long)(n3 | n3);
            n5 = 1;
            do {
                n = (int)instanceCount;
                f -= (float)n8;
            } while (++n5 < 7);
            n4 = (int)instanceCount;
            iFld = n5;
            for (n6 = n3; n6 < 7; ++n6) {
                nArray[n3][n3 + 1][n3 + 1] = iFld;
                n = n2;
                n7 = -9;
                try {
                    nArray[n3 - 1][(Test.iFld >>> 1) % 400][n3] = -28 / iFld;
                    n4 = iFld / 120;
                    n4 = iFld % n4;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n4 += 167;
            }
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f) + n8 + n6 + n7) + FuzzerUtils.checkSum(sArray) + FuzzerUtils.checkSum((Object[][])nArray);
    }

    public static void vMeth1(int n) {
        int n2 = 64905;
        int n3 = 14;
        int n4 = -144;
        int n5 = 55921;
        int n6 = 10;
        float f = 93.277f;
        double d = 122.97533;
        long[] lArray = new long[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(lArray, -6530L);
        FuzzerUtils.init(blArray, true);
        Test.vMeth2(n, iFld);
        n2 = 1;
        while (++n2 < 332) {
            block18: for (n3 = 1; 5 > n3; ++n3) {
                n4 = n3;
                int n7 = n2 - 1;
                iArrFld[n7] = iArrFld[n7] + n;
                n4 = sFld;
                switch (n3 % 5 + 124) {
                    case 124: {
                        block19: for (n5 = 2; n5 > 1; n5 -= 3) {
                            n += n5 * iFld;
                            n4 = (int)((float)n4 + ((float)n5 * f + (float)n3 - (float)n6));
                            switch (n3 % 9 + 54) {
                                case 54: {
                                    n += -10 + n5 * n5;
                                    f += (float)n2;
                                    sFld = (short)(sFld - (short)n5);
                                }
                                case 55: {
                                    d += (double)n4;
                                    continue block19;
                                }
                                case 56: {
                                    continue block19;
                                }
                                case 57: {
                                    n6 += n5 * n + sFld - n2;
                                    continue block19;
                                }
                                case 58: {
                                    n6 = n2;
                                    continue block19;
                                }
                                case 59: {
                                    iFld = n;
                                    continue block19;
                                }
                                case 60: {
                                    int n8 = n5 + 1;
                                    lArray[n8] = lArray[n8] & (long)iFld;
                                    continue block19;
                                }
                                case 61: {
                                    blArray[n3 - 1] = true;
                                    continue block19;
                                }
                                case 62: {
                                    instanceCount += (long)(n5 | n);
                                }
                            }
                        }
                        continue block18;
                    }
                    case 125: 
                    case 126: {
                        instanceCount += (long)(n3 * n2) + instanceCount - (long)n;
                        continue block18;
                    }
                    case 127: {
                        iFld = 30724;
                    }
                    case 128: {
                        int n9 = n2;
                        lArray[n9] = lArray[n9] + instanceCount;
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(blArray);
    }

    public static void vMeth(int n, int n2) {
        int n3 = 5;
        int n4 = 4341;
        int n5 = -21348;
        int n6 = 18502;
        int n7 = -12;
        int n8 = -5;
        int n9 = -37552;
        int n10 = -9;
        double d = 10.11893;
        for (n3 = 6; n3 < 344; ++n3) {
            Test.vMeth1(n);
            for (n5 = n3; n5 < 5; ++n5) {
                for (n7 = 1; 1 > n7; ++n7) {
                    n = (int)instanceCount;
                    d = instanceCount;
                    d = n5;
                }
                n6 = 105465785;
                for (n9 = 1; n9 < 1; ++n9) {
                    n4 -= (int)d;
                    instanceCount = (long)fFld;
                    n4 = (int)fFld;
                    n6 += n9 * n9;
                    fFld -= -11.0f;
                    instanceCount -= 104L;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8) + Double.doubleToLongBits(d) + (long)n9 + (long)n10;
    }

    public void mainTest(String[] stringArray) {
        int n = 5;
        int n2 = -56;
        int n3 = -143;
        int n4 = -15659;
        int n5 = -214;
        int n6 = -59920;
        int n7 = 14;
        int n8 = -144;
        int n9 = 40380;
        int[] nArray = new int[400];
        long l = 12L;
        double d = 0.22206;
        FuzzerUtils.init(nArray, 25274);
        Test.vMeth(iFld, iFld);
        for (n = 9; n < 163; ++n) {
            for (n3 = n; n3 < 163; ++n3) {
                int n10 = n + 1;
                iArrFld[n10] = iArrFld[n10] * n2;
                l = 1L;
                while (++l < 1L) {
                    iFld -= n4;
                    instanceCount = n2;
                }
            }
            for (n5 = 9; n5 < 163; ++n5) {
                n2 = (int)fFld;
                d = 37426.0;
                int n11 = n5;
                nArray[n11] = nArray[n11] + (int)l;
                iFld = (int)fFld;
                n4 -= n3;
                n6 += (int)instanceCount;
                for (n7 = n5; n7 < 2; ++n7) {
                    n4 += n8;
                    n4 -= n4;
                    instanceCount += (long)n4;
                }
                n9 = 1;
                do {
                    int n12 = n5;
                    iArrFld[n12] = iArrFld[n12] * iFld;
                    int n13 = n - 1;
                    iArrFld[n13] = iArrFld[n13] << (int)l;
                    instanceCount <<= n8;
                    n2 += n9;
                    if (this.bFld) continue;
                    instanceCount = n2;
                    int n14 = n5;
                    lArrFld[n14] = lArrFld[n14] - (long)n;
                } while (++n9 < 2);
                iFld >>>= n7;
            }
            this.byArrFld = this.byArrFld;
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 l i27 = " + n4 + "," + l + "," + n5);
        FuzzerUtils.out.println("i28 d2 i29 = " + n6 + "," + Double.doubleToLongBits(d) + "," + n7);
        FuzzerUtils.out.println("i30 i31 iArr1 = " + n8 + "," + n9 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
        FuzzerUtils.out.println("Test.fFld bFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.sArrFld Test.lArrFld byArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 41383);
        FuzzerUtils.init(sArrFld, (short)16014);
        FuzzerUtils.init(lArrFld, -2009317289L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

