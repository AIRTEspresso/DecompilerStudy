/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -55718L;
    public int iFld = 99;
    public static float fFld = 0.585f;
    public static boolean bFld = false;
    public static long lFld = -49429L;
    public static long[] lArrFld = new long[400];
    public static volatile float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long byMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n) {
        int n2 = -65;
        int n3 = 21115;
        int n4 = -3;
        int n5 = 1929;
        int n6 = 2;
        int n7 = -7;
        int n8 = 9;
        int n9 = -6;
        boolean bl = true;
        if (bl) {
            instanceCount <<= n;
            for (n2 = 7; n2 < 125; ++n2) {
                for (n4 = 1; n4 < 13; ++n4) {
                    fFld = n3;
                }
                for (n6 = 1; 13 > n6; ++n6) {
                    for (n8 = 1; n8 < 2; n8 += 2) {
                        n -= n8;
                        int n10 = n6 + 1;
                        lArrFld[n10] = lArrFld[n10] - 78L;
                        switch (n2 % 1 + 25) {
                            case 25: {
                                n = 82;
                            }
                        }
                        if (n4 != 0) {
                            vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + (bl ? 1 : 0));
                            return;
                        }
                        instanceCount += (long)n8;
                        instanceCount = n6;
                    }
                }
                n7 = -69;
            }
        } else if (bl) {
            n9 = 39;
        } else {
            instanceCount = n5;
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + (bl ? 1 : 0));
    }

    public static byte byMeth(long l, int n, int n2) {
        int n3 = 9;
        int n4 = 1;
        int n5 = -2;
        int n6 = -51;
        double d = 0.32039;
        for (n3 = 19; n3 < 319; ++n3) {
            Test.vMeth1(-11);
            n6 = (byte)n3;
            if (bFld) break;
            n5 = 1;
            while (++n5 < 6) {
                fFld += fFld;
                Test.lArrFld[n5] = 0L;
                n4 -= 29489;
                d *= (double)n5;
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n6 + (long)n5 + Double.doubleToLongBits(d);
        byMeth_check_sum += l2;
        return (byte)l2;
    }

    public static void vMeth(int n) {
        int n2 = -5;
        int n3 = -4653;
        int n4 = 12;
        int n5 = -49763;
        int n6 = 13;
        double d = -108.37499;
        int n7 = 64;
        Test.byMeth(instanceCount, n, n);
        for (n2 = 12; n2 < 245; ++n2) {
            n3 >>>= -38783;
            n += 0;
            n3 <<= n2;
            n <<= (int)instanceCount;
        }
        try {
            n4 = 1;
            while (++n4 < 194) {
                n5 = 1;
                while (n5 < 8) {
                    lFld >>= n4;
                    fFld += (float)n5;
                    int n8 = n5 + 1;
                    fArrFld[n8] = fArrFld[n8] + (float)n;
                    int n9 = n5++;
                    lArrFld[n9] = lArrFld[n9] - (long)d;
                }
            }
        }
        catch (ArithmeticException arithmeticException) {
            n7 = (byte)(n7 - (byte)n);
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7;
    }

    public void mainTest(String[] stringArray) {
        int[][] nArray = new int[400][400];
        FuzzerUtils.init(nArray, -61212);
        int[] nArray2 = nArray[(this.iFld >>> 1) % 400];
        int n = (this.iFld >>> 1) % 400;
        int n2 = (this.iFld >>> 1) % 400;
        long l = lArrFld[n2];
        lArrFld[n2] = l - 1L;
        nArray2[n] = nArray2[n] << (int)Math.abs(l);
        Test.vMeth(this.iFld);
        int[] nArray3 = nArray[(this.iFld >>> 1) % 400];
        int n3 = (this.iFld >>> 1) % 400;
        nArray3[n3] = nArray3[n3] * -3;
        this.iFld >>= this.iFld;
        FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.lFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + lFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 2000137365L);
        FuzzerUtils.init(fArrFld, -1.951f);
        vMeth_check_sum = 0L;
        byMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

