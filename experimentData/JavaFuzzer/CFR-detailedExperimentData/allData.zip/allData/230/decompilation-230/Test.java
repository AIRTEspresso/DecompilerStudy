/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -27496L;
    public static short sFld = (short)-10814;
    public static long lFld = 15L;
    public static float fFld = -2.144f;
    public int iFld = 2;
    public static int[] iArrFld = new int[400];
    public static double[] dArrFld = new double[400];
    public float[] fArrFld = new float[400];
    public volatile long[] lArrFld = new long[400];
    public static volatile short[] sArrFld = new short[400];
    public static long vMeth_check_sum;
    public static long byMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(int n, int n2) {
        float f = -1.864f;
        int n3 = 7;
        int n4 = -161;
        int n5 = -32;
        short[] sArray = new short[400];
        FuzzerUtils.init(sArray, (short)633);
        n2 += n2;
        f -= -104.0f;
        instanceCount = n;
        n3 = 6;
        while (n3 < 133) {
            instanceCount += (long)(n3 * n4 + n) - instanceCount;
            n5 = (byte)(n5 * (byte)(f -= (float)n3));
            n4 += n3;
            n = -187;
            int n6 = n3++;
            iArrFld[n6] = iArrFld[n6] - n;
            n >>= -1611071117;
            n4 *= (int)instanceCount;
        }
        n2 += n;
        long l = (long)((n -= (int)f) + n2 + Float.floatToIntBits(f) + n3 + n4 + n5) + FuzzerUtils.checkSum(sArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static byte byMeth(double d, double d2) {
        int n = -12800;
        int n2 = 11;
        int n3 = 4;
        int n4 = -17016;
        int n5 = -25;
        int n6 = 38233;
        float f = 1.402f;
        long l = 4385430486641923231L;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -3028360344L);
        n -= -Test.iMeth(n, n);
        n -= n;
        n *= (int)f;
        for (n2 = 8; n2 < 192; ++n2) {
            l = 1L;
            while (++l < 9L) {
                for (n4 = 1; n4 < 1; ++n4) {
                    n6 += n4 ^ n6;
                    n6 = (int)l;
                    --n3;
                    n5 >>= n2;
                    n6 -= n2;
                    int n7 = n4 + 1;
                    lArray[n7] = lArray[n7] & l;
                    instanceCount += (long)(-23950 + n4 * n4);
                    instanceCount += (long)d2;
                }
            }
        }
        long l2 = Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + l + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(lArray);
        byMeth_check_sum += l2;
        return (byte)l2;
    }

    public static void vMeth() {
        int n = -16;
        int n2 = -105;
        int n3 = 95;
        int n4 = 3;
        int n5 = -204;
        double d = 53.30768;
        int n6 = -107;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(byArray, (byte)110);
        for (n = 155; n > 9; n -= 3) {
            n2 += n * n + n2 - n;
            for (n3 = 32; n3 > 2; --n3) {
                n5 = 1;
                while (++n5 < 2) {
                    instanceCount += (long)d;
                    Test.iArrFld[n5 + 1] = n4;
                    sFld = (short)(sFld + 69);
                    n4 >>= n6;
                    byArray[n] = (byte)(instanceCount >>= (n2 <<= Test.byMeth(d, d)));
                }
                lFld *= (long)n6;
                lFld += (long)(n3 + n4);
                n4 -= n6;
                try {
                    n2 = n3 / iArrFld[n - 1];
                    n2 = n5 / 1595;
                    n2 = -523912631 / n;
                    continue;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)n6 + FuzzerUtils.checkSum(byArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -21;
        double d = 34.66381;
        double d2 = 0.22094;
        int n2 = 210;
        int n3 = -35805;
        int n4 = -6;
        int n5 = 45860;
        int n6 = 94;
        int n7 = -5;
        boolean bl = true;
        instanceCount *= instanceCount % (long)(Math.abs((int)((double)n + -97.127346)) | 1);
        Test.vMeth();
        for (d = 8.0; d < 287.0; d += 1.0) {
            if (bl) {
                n2 += (int)instanceCount;
                n2 += (int)d;
                n = 12;
                continue;
            }
            if (bl) {
                instanceCount -= (long)this.iFld;
                continue;
            }
            n2 = n7;
        }
        FuzzerUtils.out.println("s d4 i15 = " + n + "," + Double.doubleToLongBits(d) + "," + n2);
        FuzzerUtils.out.println("i16 i17 i18 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i19 b i20 = " + n6 + "," + (bl ? 1 : 0) + "," + n7);
        FuzzerUtils.out.println("d5 = " + Double.doubleToLongBits(d2));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.lFld = " + instanceCount + "," + sFld + "," + lFld);
        FuzzerUtils.out.println("Test.fFld iFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.dArrFld fArrFld lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 101);
        FuzzerUtils.init(dArrFld, -2.101023);
        FuzzerUtils.init(sArrFld, (short)-6577);
        vMeth_check_sum = 0L;
        byMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

