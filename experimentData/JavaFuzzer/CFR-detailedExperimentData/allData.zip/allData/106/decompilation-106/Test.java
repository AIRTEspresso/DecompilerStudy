/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 5L;
    public static int iFld = 55569;
    public double dFld = 106.59753;
    public float fFld = -1.409f;
    public boolean bFld = false;
    public int[] iArrFld = new int[400];
    public static short[] sArrFld = new short[400];
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(int n, int n2, long l) {
        int n3 = -16;
        float f = 8.263f;
        float[] fArray = new float[400];
        boolean bl = true;
        int n4 = 10972;
        long[] lArray = new long[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(fArray, 0.497f);
        FuzzerUtils.init(lArray, -2444275299L);
        FuzzerUtils.init(dArray, -2.116215);
        n3 = 1;
        while (++n3 < 269) {
            switch (n3 % 7 * 5 + 32) {
                case 40: {
                    l += (long)n3 * (instanceCount *= (long)n) + l - (long)(n2 += (int)f);
                    n |= iFld;
                    break;
                }
                case 42: {
                    n2 += n3 * n + n - n2;
                }
                case 63: {
                    if (bl) break;
                    int n5 = n3;
                    fArray[n5] = fArray[n5] * (float)n4;
                    break;
                }
                case 51: {
                    int n6 = n3 - 1;
                    lArray[n6] = lArray[n6] - 97L;
                    break;
                }
                case 55: {
                    int n7 = n3 + 1;
                    dArray[n7] = dArray[n7] * (double)l;
                    n2 = n += n3 * n3;
                    f = n3;
                }
                case 65: {
                    n2 = n;
                    break;
                }
                case 60: {
                    n = n3;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2) + l + (long)n3 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + (long)n4 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth() {
        int n = -140;
        int n2 = 8;
        int n3 = -10;
        int n4 = 54853;
        int[] nArray = new int[400];
        float f = 0.268f;
        float[][] fArray = new float[400][400];
        double d = -108.109856;
        FuzzerUtils.init(nArray, 9375);
        FuzzerUtils.init(fArray, 2.21f);
        Test.vMeth1(iFld, iFld, instanceCount);
        iFld *= iFld;
        nArray[45] = nArray[45] * iFld;
        for (n = 10; n < 207; ++n) {
            n3 = 1;
            while (++n3 < 8) {
                instanceCount -= (long)n;
                for (f = 1.0f; f < 1.0f; f += 1.0f) {
                    instanceCount = -5L;
                    int n5 = (int)(f + 1.0f);
                    nArray[n5] = nArray[n5] - n3;
                    float[] fArray2 = fArray[(int)f];
                    int n6 = (int)f;
                    fArray2[n6] = fArray2[n6] + 8.0f;
                    instanceCount = (long)d;
                    nArray[354] = nArray[354] + (int)f;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static boolean bMeth(int n, short s, int n2) {
        double d = -115.88184;
        double[] dArray = new double[400];
        int n3 = 51051;
        int[] nArray = new int[400];
        float f = -2.614f;
        int n4 = -61;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(nArray, 78);
        FuzzerUtils.init(dArray, 83.2875);
        FuzzerUtils.init(byArray, (byte)58);
        n2 -= nArray[(n2 >>> 1) % 400];
        Test.vMeth();
        nArray[69] = nArray[69] * (int)(instanceCount += (long)n);
        int n5 = (n2 >>> 1) % 400;
        dArray[n5] = dArray[n5] * (double)(iFld *= -294958096);
        for (byte by : byArray) {
            n -= (n2 -= (int)d);
        }
        n3 = 1;
        do {
            f = instanceCount;
            instanceCount = 1L;
            n4 = (byte)n;
            Test.sArrFld[n3 + 1] = (short)n;
        } while (++n3 < 350);
        long l = (long)(n + s + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + FuzzerUtils.checkSum(byArray);
        bMeth_check_sum += l;
        return l % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        int n = -48;
        int n2 = -161;
        int n3 = 134;
        int n4 = 238;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, -544060613407401985L);
        for (int n5 : this.iArrFld) {
            Test.bMeth(n5, (short)21006, iFld);
            this.iArrFld[(n5 >>> 1) % 400] = (int)this.dFld;
            this.iArrFld = this.iArrFld;
            n5 *= (int)instanceCount;
            for (n = 3; n < 63; ++n) {
                block14: for (n3 = 1; n3 < 2; ++n3) {
                    switch (n % 2 * 5 + 103) {
                        case 105: {
                            continue block14;
                        }
                        case 109: {
                            iFld += 7137;
                            long[] lArray2 = lArray[n];
                            int n6 = n3 + 1;
                            lArray2[n6] = lArray2[n6] & (long)n2;
                            switch (n % 1 + 1) {
                                case 1: {
                                    n4 *= iFld;
                                    iFld = (int)instanceCount;
                                    int n7 = n3 + 1;
                                    this.iArrFld[n7] = this.iArrFld[n7] - -13;
                                    break;
                                }
                                default: {
                                    switch (n % 1 + 71) {
                                        case 71: {
                                            n5 += n3;
                                            n2 = (int)instanceCount;
                                        }
                                    }
                                }
                            }
                            n2 >>= n2;
                        }
                        default: {
                            this.fFld += (float)n3;
                            this.fFld = instanceCount;
                            try {
                                iFld = n4 / n5;
                                iFld = this.iArrFld[n] / -3633;
                                iFld = -30624 / n4;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            iFld = (int)((long)iFld + ((long)n3 * instanceCount + instanceCount - (long)n));
                        }
                    }
                }
                iFld += n * n4 + iFld - n3;
            }
            lArray[(n3 >>> 1) % 400][(Test.iFld >>> 1) % 400] = (long)this.dFld;
            n5 *= n;
            int n8 = (n4 >>> 1) % 400;
            this.iArrFld[n8] = this.iArrFld[n8] << n3;
        }
        this.bFld = this.bFld;
        FuzzerUtils.out.println("i12 i13 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i15 lArr1 = " + n4 + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("fFld bFld iArrFld = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(sArrFld, (short)-25998);
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

