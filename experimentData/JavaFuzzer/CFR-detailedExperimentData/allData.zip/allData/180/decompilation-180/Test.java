/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -22450L;
    public static short sFld = (short)-5318;
    public static boolean bFld = false;
    public static short sFld1 = (short)-9894;
    public static float fFld = 0.378f;
    public float[] fArrFld = new float[400];
    public static int[] iArrFld = new int[400];
    public double[] dArrFld = new double[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth2_check_sum;

    public void vMeth() {
        int n = -10;
        int n2 = 0;
        int n3 = 7;
        int n4 = 156;
        int n5 = 245;
        int[] nArray = new int[400];
        double d = 0.74801;
        long l = 448096626L;
        float f = -117.326f;
        FuzzerUtils.init(nArray, 3608);
        for (int n6 : nArray) {
            for (n = 1; 4 > n; ++n) {
                double d2 = ++n6;
                ++n6;
                n6 = (int)(d2 + ((double)(-9 * n6) - (d - (double)n6)));
                l = 1L;
                do {
                    int n7 = (int)l;
                    nArray[n7] = nArray[n7] >>> (int)l;
                    n6 -= n;
                    n6 = (int)instanceCount;
                    f = instanceCount += (long)(Short.reverseBytes(sFld) - n6);
                    n2 += (int)((float)(l * (long)n2 + (long)sFld) - f);
                    n6 = (int)(-(d * 8.0 * (double)Math.min(-30843, n)));
                } while (++l < 2L);
                d *= (double)n2++;
                for (n3 = 1; n3 < 2; ++n3) {
                    this.fArrFld = this.fArrFld = this.fArrFld;
                    instanceCount = nArray[n3];
                    n2 %= (int)(instanceCount | 1L);
                    int n8 = n3 + 1;
                    int n9 = nArray[n8] + 1;
                    nArray[n8] = n9;
                    n2 = Math.abs(n9) + (n3 + n3 + (n5 + n));
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + l + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth2(boolean bl) {
        int n = -14;
        int n2 = -216;
        int n3 = -13;
        int n4 = 27621;
        int n5 = 0;
        int n6 = 40089;
        int n7 = -1;
        int[] nArray = new int[400];
        float f = 0.804f;
        float[][][] fArray = new float[400][400][400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, -53761);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(90.987f));
        FuzzerUtils.init(dArray, 0.40053);
        for (n = 142; n > 7; n -= 3) {
            fArray[n][n][n] = 38.337f;
            for (n3 = n; n3 < 34; ++n3) {
                dArray[n3 - 1] = f;
                n5 = 1;
                while (++n5 < 1) {
                    nArray[n3 + 1] = n2;
                }
                n2 = (int)((long)n2 + ((long)n3 + instanceCount));
                n2 -= n5;
                for (n6 = 1; n6 < 1; ++n6) {
                    f *= (float)instanceCount;
                    f = n6;
                    n4 = n2 -= 14352;
                    n4 >>= n2;
                }
            }
        }
        vMeth2_check_sum += (long)((bl ? 1 : 0) + n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static int iMeth(int n, byte by, float f) {
        int n2 = 4;
        int n3 = 60588;
        int n4 = -36931;
        int n5 = -202;
        int n6 = -65326;
        double d = 117.70311;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 5L);
        Test.vMeth2(bFld);
        n2 = 1;
        do {
            block13: for (n3 = 1; n3 < 9; ++n3) {
                switch ((n2 >>> 1) % 10 + 1) {
                    case 1: {
                        sFld = (short)(sFld + (short)((long)(n3 * n4) + instanceCount - (long)n));
                        for (n5 = 1; n5 < 2; ++n5) {
                            instanceCount += (long)n3;
                            d += d;
                            d -= 2.534579257E9;
                            f += (float)n5;
                            n6 = sFld1;
                            n = (int)(instanceCount += (long)n5);
                        }
                        n += 455988198;
                        continue block13;
                    }
                    case 2: {
                        Test.iArrFld[n3] = n3;
                        continue block13;
                    }
                    case 3: {
                        sFld1 = (short)(sFld1 + (short)instanceCount);
                        continue block13;
                    }
                    case 4: {
                        lArray[(n3 >>> 1) % 400] = n;
                    }
                    case 5: {
                        n6 = n3;
                        continue block13;
                    }
                    case 6: {
                        n = (int)instanceCount;
                    }
                    case 7: {
                        n4 = (int)d;
                        continue block13;
                    }
                    case 8: {
                        instanceCount = n5;
                        continue block13;
                    }
                    case 9: {
                        n4 = (int)d;
                    }
                    case 10: {
                        if (!bFld) continue block13;
                        continue block13;
                    }
                    default: {
                        int n7 = n3 + 1;
                        iArrFld[n7] = iArrFld[n7] >> -220;
                    }
                }
            }
        } while (++n2 < 171);
        long l = (long)(n + by + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static void vMeth1() {
        int n = 17;
        int n2 = -41456;
        int n3 = 243;
        int n4 = -46258;
        int n5 = 2;
        int n6 = 54670;
        byte by = 119;
        double d = -1.47089;
        double d2 = 1.45159;
        if (bFld) {
            instanceCount = -206L;
            n += Test.iMeth(n, by, fFld);
        } else if (bFld) {
            n *= 192;
            for (d = 1.0; d < 214.0; d += 3.0) {
                for (n3 = (int)d; 22 > n3; ++n3) {
                    instanceCount = -4L;
                    by = (byte)(by - (byte)(n += sFld));
                }
                Test.iArrFld[(int)d] = n3;
            }
            for (n5 = 286; 7 < n5; --n5) {
                n4 = (int)((long)n4 + ((long)n5 * instanceCount + (long)n2 - (long)n4));
                d2 += (double)n4;
                instanceCount *= (long)n5;
            }
        } else if (bFld) {
            n4 *= (int)fFld;
        }
        vMeth1_check_sum += (long)(n + by) + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + Double.doubleToLongBits(d2);
    }

    public void mainTest(String[] stringArray) {
        int n = -10;
        int n2 = 6;
        int n3 = -14;
        int n4 = 64503;
        int n5 = 11;
        int n6 = 248;
        int n7 = 7;
        int n8 = -45417;
        int n9 = -49716;
        int n10 = -42;
        double d = -2.1235;
        int n11 = -97;
        byte[] byArray = new byte[400];
        float f = 76.96f;
        FuzzerUtils.init(byArray, (byte)-43);
        this.vMeth();
        Test.vMeth1();
        n = 1;
        while (n < 339) {
            for (n3 = 1; n3 < 74; ++n3) {
                int n12 = n + 1;
                byArray[n12] = (byte)(byArray[n12] - (byte)n2);
                n4 += (int)fFld;
                n4 *= n;
                d = n3;
                n2 += (n4 += n3 * n3);
                n2 |= n3;
                n4 += (int)(158868936188254660L + (long)(n3 * n3));
            }
            int n13 = n++;
            this.dArrFld[n13] = this.dArrFld[n13] - (double)n3;
        }
        for (n5 = 9; n5 < 209; ++n5) {
            n7 = 1;
            do {
                for (n8 = 1; 1 < n8; n8 -= 3) {
                    n9 -= 12;
                    instanceCount += -4007248630L + (long)(n8 * n8);
                    n11 = (byte)n;
                }
                n4 += n7;
                n10 = 1;
                block21: do {
                    bFld = true;
                    d += 11.0;
                    switch (n5 % 3 + 118) {
                        case 118: {
                            switch (n5 % 7 + 106) {
                                case 106: {
                                    Test.iArrFld[n5 - 1] = (int)d;
                                    break;
                                }
                                case 107: {
                                    n6 = n11;
                                    break;
                                }
                                case 108: {
                                    try {
                                        Test.iArrFld[n5] = -11713 % n5;
                                        n4 = -166 / iArrFld[n5 - 1];
                                        n2 = n4 % iArrFld[n7];
                                    }
                                    catch (ArithmeticException arithmeticException) {}
                                    break;
                                }
                                case 109: {
                                    instanceCount += (long)(n10 | n5);
                                    break;
                                }
                                case 110: {
                                    n2 >>= -206;
                                    break;
                                }
                                case 111: {
                                    instanceCount += -4L + (long)(n10 * n10);
                                }
                                case 112: {
                                    int n14 = n10;
                                    this.fArrFld[n14] = this.fArrFld[n14] + (float)n10;
                                }
                            }
                            continue block21;
                        }
                        case 119: {
                            fFld *= (float)n6;
                        }
                        case 120: {
                            this.fArrFld[(n4 >>> 1) % 400] = fFld;
                            break;
                        }
                        default: {
                            f = (float)d;
                        }
                    }
                } while (++n10 < 1);
            } while (++n7 < 126);
        }
        FuzzerUtils.out.println("i26 i27 i28 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i29 d4 i30 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("i31 i32 i33 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("i34 by2 i35 = " + n9 + "," + n11 + "," + n10);
        FuzzerUtils.out.println("f3 byArr = " + Float.floatToIntBits(f) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + sFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld1 Test.fFld fArrFld = " + sFld1 + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("Test.iArrFld dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -209);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

