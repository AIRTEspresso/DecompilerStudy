/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 107L;
    public static volatile int iFld = -8;
    public long lFld = 13L;
    public static volatile byte byFld = (byte)-21;
    public static boolean bFld = false;
    public static float[] fArrFld = new float[400];
    public static volatile int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long fMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1(long l) {
        int n = 10789;
        l = -14075L;
        vMeth1_check_sum += l + (long)(n *= (int)instanceCount);
    }

    public static float fMeth(double d, byte by, long l) {
        int n = 2;
        int n2 = 63504;
        int n3 = -62949;
        int[] nArray = new int[400];
        float f = 0.913f;
        int n4 = -9867;
        short[] sArray = new short[400];
        FuzzerUtils.init(nArray, 50986);
        FuzzerUtils.init(sArray, (short)-4317);
        n = 1;
        do {
            int n5 = 0;
            f += (float)(n * n);
            Test.vMeth1(instanceCount);
            n5 *= n;
            try {
                n5 = -216 / n;
                n5 = n / n5;
                nArray[n + 1] = -1323004922 / n5;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        } while (++n < 226);
        d -= (double)n;
        n2 = 1;
        block11: while ((n2 += 3) < 234) {
            nArray[n2 - 1] = n;
            switch (n2 % 4 + 63) {
                case 63: 
                case 64: {
                    n3 = 1;
                    do {
                        switch (n3 % 1 + 10) {
                            case 10: {
                                sArray[n2 - 1] = (short)n;
                                n4 = (short)(n4 + (short)(n3 * n3));
                            }
                        }
                        int n6 = n3++;
                        nArray[n6] = nArray[n6] * -91;
                    } while (n3 < 20);
                }
                case 65: {
                    instanceCount = (long)f;
                }
                case 66: {
                    iFld = 17008;
                    continue block11;
                }
            }
            iFld += n2 | n3;
        }
        long l2 = Double.doubleToLongBits(d) + (long)by + l + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n3 + (long)n4 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(sArray);
        fMeth_check_sum += l2;
        return l2;
    }

    public static void vMeth(int n) {
        int n2 = 5351;
        int n3 = 79;
        int n4 = -8;
        int n5 = -14;
        int n6 = 28617;
        int n7 = 36801;
        int[] nArray = new int[400];
        double d = 57.26152;
        float f = 50.231f;
        byte by = -40;
        boolean bl = true;
        FuzzerUtils.init(nArray, 10);
        n2 = 216;
        do {
            int n8 = n2;
            nArray[n8] = nArray[n8] >> -14;
            double d2 = d;
            d = d2 + 1.0;
            instanceCount *= (long)(d2 - (double)Integer.reverseBytes(Integer.reverseBytes(n2)));
            for (n3 = 21; n3 > 1; n3 -= 3) {
                n4 += n3;
                n += (int)d;
            }
            n4 += (int)d;
        } while ((n2 -= 3) > 0);
        float f2 = f;
        f = f2 + 1.0f;
        instanceCount &= (long)(f2 - (float)((long)n4 - ((long)n - instanceCount)));
        for (float f3 : fArrFld) {
            for (n5 = 1; n5 < 4; ++n5) {
                n7 = 2;
                while (--n7 > 0) {
                    instanceCount += (long)(n7 * n3 + n7 - n5);
                    nArray[n7 - 1] = (int)((float)n-- + Test.fMeth(-114.7178, by, instanceCount *= (long)n5));
                    if (!bl) continue;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + (long)by + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 42031;
        int n2 = -1;
        int n3 = -231;
        int n4 = -20701;
        int n5 = 74;
        int n6 = -3;
        int n7 = -190;
        int n8 = -2;
        double d = -1.48991;
        double d2 = 82.119659;
        boolean bl = false;
        float f = -98.489f;
        int n9 = -6115;
        byte[] byArray = new byte[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(byArray, (byte)-66);
        FuzzerUtils.init(lArray, 2711281106836039529L);
        for (n = 4; n < 255; ++n) {
            int n10 = n + 1;
            byArray[n10] = (byte)(byArray[n10] - (byte)instanceCount++);
            Test.vMeth(n);
            for (n3 = n; n3 < 100; n3 += 3) {
                n2 = (int)((long)n2 + ((long)(n3 * iFld) + this.lFld - (long)iFld));
                Test.iArrFld[n - 1] = n3;
                iFld *= (int)d;
                int n11 = n3 - 1;
                iArrFld[n11] = iArrFld[n11] - n4;
            }
        }
        iFld %= (int)(instanceCount | 1L);
        n5 = 1;
        block11: while (++n5 < 198) {
            switch (n5 % 8 + 43) {
                case 43: 
                case 44: {
                    d2 = 1.0;
                    while (true) {
                        double d3;
                        d2 += 1.0;
                        if (!(d3 < 127.0)) break;
                        int n12 = (int)d2;
                        iArrFld[n12] = iArrFld[n12] - 585660258;
                        iFld *= n2;
                        for (n6 = (int)d2; n6 < 1 && !bl; ++n6) {
                            iFld = (int)((float)iFld + ((float)((long)n6 * this.lFld) + f - (float)n4));
                            iFld = n9;
                            iFld = n7;
                            this.lFld >>= byFld;
                            n4 = (int)(instanceCount += (long)n6);
                            n7 = n8 += -3 + n6 * n6;
                        }
                        n8 -= (int)instanceCount;
                        n2 += 63916;
                    }
                    f += (float)((long)(n5 * n8) + instanceCount - (long)n5);
                    f += (float)n5;
                    f = this.lFld;
                }
                case 45: {
                    lArray[n5 - 1] = iFld;
                }
                case 46: {
                    int n13 = n5 + 1;
                    byArray[n13] = (byte)(byArray[n13] & (byte)this.lFld);
                }
                case 47: {
                    if (bl) continue block11;
                }
                case 48: {
                    if (bFld) continue block11;
                }
                case 49: {
                    instanceCount >>= (int)this.lFld;
                    continue block11;
                }
                case 50: 
            }
            n2 = -8;
        }
        FuzzerUtils.out.println("i i1 i14 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i15 d2 i16 = " + n4 + "," + Double.doubleToLongBits(d) + "," + n5);
        FuzzerUtils.out.println("d3 i17 i18 = " + Double.doubleToLongBits(d2) + "," + n6 + "," + n7);
        FuzzerUtils.out.println("b1 f3 s1 = " + (bl ? 1 : 0) + "," + Float.floatToIntBits(f) + "," + n9);
        FuzzerUtils.out.println("i19 byArr lArr = " + n8 + "," + FuzzerUtils.checkSum(byArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld lFld = " + instanceCount + "," + iFld + "," + this.lFld);
        FuzzerUtils.out.println("Test.byFld Test.bFld Test.fArrFld = " + byFld + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 90.263f);
        FuzzerUtils.init(iArrFld, 44029);
        vMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

