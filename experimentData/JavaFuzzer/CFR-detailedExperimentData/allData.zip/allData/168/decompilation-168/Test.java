/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -8L;
    public static short sFld = (short)20299;
    public static volatile float fFld = 42.963f;
    public static double dFld = 0.87786;
    public static float[] fArrFld = new float[400];
    public static int[] iArrFld = new int[400];
    public static int[] iArrFld1 = new int[400];
    public static long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(long l) {
        int n = 64573;
        int n2 = -1;
        int n3 = -8;
        int n4 = 196;
        int n5 = 103;
        float f = -73.448f;
        boolean bl = true;
        double d = 0.36287;
        n >>= n;
        for (n2 = 7; n2 < 126; ++n2) {
            n += n;
            for (n4 = 13; n4 > 1; --n4) {
                int n6 = n2 + 1;
                fArrFld[n6] = fArrFld[n6] - (float)sFld;
                n *= (int)f;
                f = n4;
                n += n4 | n5;
                d += (double)instanceCount;
                if (bl) continue;
                n3 = (int)((long)n3 + ((long)n4 + instanceCount));
            }
            fFld /= (float)(n2 | 1);
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + Double.doubleToLongBits(d);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth1() {
        int n = -157;
        int n2 = 15;
        int n3 = 25151;
        int n4 = -47664;
        int n5 = -92;
        int n6 = 52921;
        int n7 = 3;
        int[] nArray = new int[400];
        double d = 1.102163;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 60L);
        FuzzerUtils.init(nArray, 10);
        lArray[(n >>> 1) % 400] = n - n;
        for (n2 = 6; n2 < 233; ++n2) {
            sFld = (short)(sFld + (short)((double)Test.iMeth(instanceCount) * -99.7755));
            d -= (double)n2;
            n = n2;
            n = -31029;
            fFld += (float)(n2 + n);
            fFld = n;
        }
        for (int n8 : nArray) {
            for (n4 = 1; n4 < 4; ++n4) {
            }
            instanceCount += (long)n3;
            for (n6 = 1; n6 < 4; ++n6) {
                n = (int)((long)n + ((long)n6 - instanceCount));
            }
            n3 += n8;
        }
        vMeth1_check_sum += (long)(n + n2 + n3) + Double.doubleToLongBits(d) + (long)n4 + (long)n5 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
    }

    public void vMeth(int n, int n2, int n3) {
        int n4 = -1;
        int n5 = -13;
        int n6 = 35767;
        int n7 = -14;
        int n8 = -60287;
        int n9 = 203;
        int n10 = 0;
        int[] nArray = new int[400];
        int n11 = 17553;
        long l = 26153L;
        FuzzerUtils.init(nArray, 209);
        n4 = 238;
        while ((n4 -= 3) > 0) {
            n2 += n4 * n3;
            n5 += n4 * n + n5 - n11;
            n5 >>>= -6956 * n3;
        }
        Test.vMeth1();
        for (l = 9L; l < 178L; l += 3L) {
            n7 = (int)l;
            while (n7 < 27) {
                int n12 = n7++;
                nArray[n12] = nArray[n12] + (int)instanceCount;
                n8 += n6;
                n3 ^= n11;
            }
            switch ((n4 >>> 1) % 1 + 67) {
                default: 
            }
            dFld = n;
            for (n9 = 1; n9 < 27; ++n9) {
                instanceCount *= (long)n4;
                n += n9 ^ n6;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n11) + l + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)n10 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 14;
        int n2 = 13;
        int n3 = 20808;
        int n4 = -182;
        int n5 = -248;
        int n6 = 56853;
        int n7 = -19775;
        int n8 = -63336;
        int n9 = -14;
        int n10 = 107;
        int n11 = 4691;
        int n12 = 244;
        boolean bl = false;
        this.vMeth(n, n, n);
        n -= (int)instanceCount;
        for (n2 = 14; n2 < 235; ++n2) {
            n = n3;
            n3 += n;
            for (n4 = 114; n4 > 7; --n4) {
                n5 *= n;
                for (n6 = 2; n6 > 1 && !bl; --n6) {
                }
                n -= (int)fFld;
                try {
                    n5 = iArrFld[n4 + 1] / iArrFld1[n2 - 1];
                    Test.iArrFld1[n4] = iArrFld1[n4] / 2135;
                    n5 = n3 / 1430829216;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                instanceCount = n;
                n8 = 1;
                do {
                    int n13 = n2;
                    lArrFld[n13] = lArrFld[n13] - 1L;
                    n7 += n7;
                    if (!bl) continue;
                } while (++n8 < 2);
                n += n4;
            }
            block11: for (n9 = 4; n9 < 114; ++n9) {
                instanceCount ^= (long)n2;
                switch (n2 % 4 + 19) {
                    case 19: {
                        n5 >>= 9157;
                        if (!bl) continue block11;
                        continue block11;
                    }
                    case 20: 
                    case 21: {
                        n10 -= n4;
                        int n14 = n9;
                        iArrFld[n14] = iArrFld[n14] % (sFld | 1);
                        continue block11;
                    }
                    case 22: {
                        n7 = (int)instanceCount;
                        instanceCount = n8;
                        continue block11;
                    }
                    default: {
                        for (n11 = 1; n11 < 2; ++n11) {
                            n12 *= n5;
                        }
                        instanceCount += (long)n9;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i26 i27 i28 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i29 b1 i30 = " + n7 + "," + (bl ? 1 : 0) + "," + n8);
        FuzzerUtils.out.println("i31 i32 i33 = " + n9 + "," + n10 + "," + n11);
        FuzzerUtils.out.println("i34 = " + n12);
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + sFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.dFld Test.fArrFld Test.iArrFld = " + Double.doubleToLongBits(dFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.iArrFld1 Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld1) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, -60.656f);
        FuzzerUtils.init(iArrFld, -6);
        FuzzerUtils.init(iArrFld1, -10);
        FuzzerUtils.init(lArrFld, -13L);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

