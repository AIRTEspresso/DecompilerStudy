/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -40060L;
    public int iFld = -8;
    public static double dFld = 1.40678;
    public boolean bFld = false;
    public static short sFld = (short)-23880;
    public volatile byte[] byArrFld = new byte[400];
    public static int[] iArrFld = new int[400];
    public static long[][] lArrFld = new long[400][400];
    public static long vMeth_check_sum;
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long iMeth2_check_sum;

    public static void vMeth(byte by) {
        float f;
        int n = 5;
        float f2 = f = 0.554f;
        f = f2 - 1.0f;
        n = (int)f2;
        vMeth_check_sum += (long)(by + n + Float.floatToIntBits(f));
    }

    public static int iMeth2(long l) {
        int n = 2603;
        int n2 = 5;
        int n3 = -167;
        int n4 = 216;
        int n5 = 10;
        int n6 = -20085;
        float f = -123.957f;
        int n7 = -7702;
        boolean bl = false;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, -76.122301);
        l = n;
        for (n2 = 136; n2 > 6; --n2) {
            n3 += n2 * n2;
            dArray[n2 - 1] = 0.604f;
            n = -216;
            for (n4 = 1; 12 > n4; ++n4) {
                n5 -= n4;
                f += (float)instanceCount;
                n7 = (short)(n7 + (short)(n4 ^ n4));
                n6 = 1;
                while (++n6 < 2) {
                    n3 = (int)((long)n3 + ((long)(n6 * n7 + n7) - l));
                    if (bl) continue;
                    f += (float)(172 + n6 * n6);
                }
                l -= instanceCount;
            }
            n5 += (int)(-7796281L + (long)(n2 * n2));
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + (long)n7 + (long)n6 + (long)(bl ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth2_check_sum += l2;
        return (int)l2;
    }

    public static int iMeth1(int n, double d, int n2) {
        int n3 = 2934;
        double d2 = 2.14113;
        double d3 = -2.13547;
        int n4 = -117;
        int n5 = -108;
        int[][] nArray = new int[400][400];
        float f = -1.276f;
        int n6 = -77;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -27);
        FuzzerUtils.init(lArray, -20091L);
        n3 = (short)(n3 - (short)(++n));
        n += Test.iMeth2(instanceCount);
        instanceCount += (long)(n - n2);
        n3 = (short)(n3 * (short)n);
        n2 -= n;
        switch ((n >>> 1) % 7 + 43) {
            case 43: {
                for (d2 = 6.0; d2 < 126.0; d2 += 1.0) {
                    int[] nArray2 = nArray[(int)d2];
                    int n7 = (n2 >>> 1) % 400;
                    nArray2[n7] = nArray2[n7] | n4;
                    int[] nArray3 = nArray[(int)d2];
                    int n8 = (int)(d2 - 1.0);
                    nArray3[n8] = nArray3[n8] + n4;
                    for (d3 = 1.0; d3 < 13.0; d3 += 1.0) {
                        n3 = (short)n5;
                        f += (float)((long)d3 ^ (long)n6);
                        n = (int)instanceCount;
                        instanceCount /= (long)(n5 | 1);
                        lArray[(int)d2] = n5;
                    }
                    n3 = (short)(n3 + (short)d2);
                }
                break;
            }
            case 44: {
                instanceCount += (long)f;
                break;
            }
            case 45: {
                int[] nArray4 = nArray[359];
                int n9 = (n5 >>> 1) % 400;
                nArray4[n9] = nArray4[n9] << -16986;
            }
            case 46: {
                n = (int)f;
                break;
            }
            case 47: {
                d -= 4.0;
                break;
            }
            case 48: {
                d += (double)f;
                break;
            }
            case 49: {
                int[] nArray5 = nArray[(n >>> 1) % 400];
                nArray5[46] = nArray5[46] - n2;
            }
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + Double.doubleToLongBits(d2) + (long)n4 + Double.doubleToLongBits(d3) + (long)n5 + (long)Float.floatToIntBits(f) + (long)n6 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public int iMeth(long l, int n) {
        int n2 = -20196;
        int n3 = -35817;
        int n4 = -174;
        int n5 = -21135;
        int n6 = -49780;
        double d = -118.123465;
        float f = -103.787f;
        n += (int)((long)(this.iFld-- - (n2 - 47335)) - ((long)(this.iFld * n) - 56818L));
        int n7 = (n >>> 1) % 400;
        byte by = (byte)(this.byArrFld[n7] - 1);
        this.byArrFld[n7] = by;
        Test.vMeth(by);
        for (n3 = 5; n3 < 221; ++n3) {
            Test.iMeth1(n4, d, n4);
            l -= l;
            for (n5 = 1; n5 < 7; ++n5) {
                Test.iArrFld[n5 - 1] = (int)l;
                Test.lArrFld[n5 + 1][n3 - 1] = instanceCount;
                n4 += n5 + n5;
                l <<= -21209;
                n *= -1104629931;
                n6 = (int)d;
            }
            f -= -24.0f;
            n6 >>>= n6;
            f -= (float)n3;
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -14;
        int n2 = 128;
        int n3 = 1;
        int n4 = -6;
        int n5 = -160;
        int n6 = -48;
        int n7 = 69;
        int n8 = 49;
        float f = 14.78f;
        float f2 = 1.196f;
        float[][][] fArray = new float[400][400][400];
        int n9 = -127;
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(66.983f));
        float[] fArray2 = fArray[(this.iFld >>> 1) % 400][(this.iFld >>> 1) % 400];
        int n10 = (this.iFld >>> 1) % 400;
        float f3 = fArray2[n10];
        fArray2[n10] = f3 - 1.0f;
        Test.vMeth((byte)((float)((long)this.iFld - instanceCount) + f3 - (float)((long)this.iFld - instanceCount - (long)(1 + this.iMeth(instanceCount, -4)))));
        float[] fArray3 = fArray[(this.iFld >>> 1) % 400][(this.iFld >>> 1) % 400];
        int n11 = (this.iFld >>> 1) % 400;
        fArray3[n11] = fArray3[n11] + 67.0f;
        this.iFld *= 13;
        this.iFld |= this.iFld;
        int n12 = (this.iFld >>> 1) % 400;
        iArrFld[n12] = iArrFld[n12] - this.iFld;
        this.iFld = this.iFld;
        block14: for (n = 6; 205 > n; ++n) {
            switch (n % 10 + 67) {
                case 67: {
                    f *= (float)this.iFld;
                    this.iFld += n * n;
                    for (f2 = 2.0f; 126.0f > f2; f2 += 1.0f) {
                        for (n4 = 1; n4 < 2; ++n4) {
                            int n13 = n + 1;
                            iArrFld[n13] = iArrFld[n13] + n;
                            this.bFld = this.bFld;
                            dFld = n5;
                            f -= (float)n;
                            this.iFld = (int)(instanceCount += (long)(n4 * n2 + (n3 += (int)dFld) - n5));
                            n3 = (int)instanceCount;
                            int n14 = n4;
                            iArrFld[n14] = iArrFld[n14] >> n;
                            instanceCount += (long)(n4 * n4);
                        }
                        n2 += (int)(f2 * (float)n5 + (float)instanceCount - (float)n);
                        for (n6 = 2; n6 > 1; --n6) {
                            Test.lArrFld[n6][n + 1] = n3;
                            f -= (float)(instanceCount -= (long)n9);
                            n2 -= this.iFld;
                            n7 = -11;
                        }
                    }
                    continue block14;
                }
                case 68: {
                    n7 <<= (int)instanceCount;
                    continue block14;
                }
                case 69: {
                    sFld = (short)(sFld + (short)n5);
                }
                case 70: {
                    this.iFld += n;
                    continue block14;
                }
                case 71: {
                    n9 = (byte)(n9 + (byte)(n - n));
                    continue block14;
                }
                case 72: {
                    n8 += n;
                    continue block14;
                }
                case 73: {
                    if (!this.bFld) continue block14;
                    continue block14;
                }
                case 74: {
                    long[] lArray = lArrFld[n + 1];
                    int n15 = n + 1;
                    lArray[n15] = lArray[n15] ^ 0x8126L;
                    continue block14;
                }
                case 75: {
                    int n16 = (n3 >>> 1) % 400;
                    iArrFld[n16] = iArrFld[n16] * (int)f2;
                    continue block14;
                }
                case 76: {
                    try {
                        n5 = n4 % iArrFld[n + 1];
                        Test.iArrFld[n] = n6 % -224;
                        n8 = iArrFld[n] / 2005531373;
                        continue block14;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
            }
        }
        FuzzerUtils.out.println("i16 i17 f4 = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("f5 i18 i19 = " + Float.floatToIntBits(f2) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i20 i21 i22 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("by2 i23 fArr = " + n9 + "," + n8 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("bFld Test.sFld byArrFld = " + (this.bFld ? 1 : 0) + "," + sFld + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 7);
        FuzzerUtils.init(lArrFld, -735264085L);
        vMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        iMeth2_check_sum = 0L;
    }
}

