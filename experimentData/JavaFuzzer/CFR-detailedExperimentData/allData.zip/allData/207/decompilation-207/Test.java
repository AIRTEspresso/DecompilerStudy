/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3L;
    public volatile byte byFld = (byte)68;
    public float fFld = -2.386f;
    public static float[] fArrFld = new float[400];
    public volatile short[] sArrFld = new short[400];
    public static long vMeth_check_sum;
    public static long dMeth_check_sum;
    public static long byMeth_check_sum;

    public static byte byMeth(long l, long l2, int n) {
        int n2 = 10;
        int n3 = -10608;
        int n4 = 97;
        int n5 = -252;
        int n6 = 245;
        float f = -78.772f;
        boolean bl = false;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 96.95171);
        n2 = 235;
        do {
            dArray[n2 + 1] = 24951.0;
            for (n3 = 1; 7 > n3; ++n3) {
            }
        } while (--n2 > 0);
        long l3 = l + l2 + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + (long)(bl ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        byMeth_check_sum += l3;
        return (byte)l3;
    }

    public static double dMeth(int n, long l) {
        int n2 = 220;
        int n3 = 25163;
        int n4 = 39624;
        int n5 = 62400;
        int[][][] nArray = new int[400][400][400];
        double d = -100.67351;
        double[][] dArray = new double[400][400];
        float f = -1.842f;
        FuzzerUtils.init((Object[][])nArray, (Object)-14);
        FuzzerUtils.init(dArray, 35.20581);
        for (n2 = 8; n2 < 189; ++n2) {
            if (n == 0) continue;
        }
        for (d = 156.0; d > 5.0; d -= 2.0) {
            int[] nArray2 = nArray[(int)(d + 1.0)][(int)d];
            int n6 = (int)(d - 1.0);
            int n7 = nArray2[n6];
            nArray2[n6] = n7 + 1;
            Test.byMeth(instanceCount, l, n4 -= (int)((double)(-n7) * dArray[(int)d][(int)(d + 1.0)]));
            l = -2L;
            f += (float)l;
            n3 = n2;
            int n8 = (int)(d - 1.0);
            fArrFld[n8] = fArrFld[n8] - 3.54143616E9f;
            n3 = n;
            n4 -= 115;
            f = 50.0f;
        }
        int[] nArray3 = nArray[41][(n2 >>> 1) % 400];
        int n9 = (n5 >>> 1) % 400;
        nArray3[n9] = nArray3[n9] - -32168;
        long l2 = (long)n + l + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + FuzzerUtils.checkSum((Object[][])nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        dMeth_check_sum += l2;
        return l2;
    }

    public static void vMeth(float f, short s, byte by) {
        int n = 15;
        int n2 = 49946;
        int n3 = 13;
        int n4 = -241;
        int[] nArray = new int[400];
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -11981);
        FuzzerUtils.init(fArray, 94.829f);
        FuzzerUtils.init(lArray, -2086867153L);
        block8: for (int n5 : nArray) {
            int n6 = (n5 >>> 1) % 400;
            s = (short)(s - 1);
            fArray[n6] = fArray[n6] * (float)s;
            switch ((Integer.reverseBytes(n5) >>> 1) % 4 * 5 + 120) {
                case 135: {
                    n5 |= nArray[57];
                    continue block8;
                }
                case 138: {
                    Test.dMeth(n5, instanceCount);
                    int n7 = (n5 >>> 1) % 400;
                    fArray[n7] = fArray[n7] * -47907.0f;
                    for (n = 1; n < 4; ++n) {
                        n2 = 125;
                        instanceCount += (long)n;
                        n3 = 1;
                        do {
                            f = n2;
                            n2 = n;
                            try {
                                n5 = nArray[n3 - 1] / n2;
                                n5 = -10449 % n3;
                                nArray[n] = n4 / n4;
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n5 *= n;
                            n5 += n;
                        } while (++n3 < 2);
                    }
                    continue block8;
                }
                case 127: {
                    n2 <<= n3;
                }
                case 139: {
                    instanceCount = n4;
                }
            }
        }
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + s + by + n + n2 + n3 + n4) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -23636;
        int n2 = 62;
        int n3 = -4;
        int n4 = -217;
        int n5 = 33819;
        int n6 = -23645;
        int n7 = -175;
        int n8 = 2688;
        int n9 = 10;
        int n10 = 7;
        int n11 = -2;
        int[][][] nArray = new int[400][400][400];
        float f = 0.215f;
        int n12 = -21836;
        boolean bl = true;
        long[] lArray = new long[400];
        FuzzerUtils.init((Object[][])nArray, (Object)-13);
        FuzzerUtils.init(lArray, -8L);
        int n13 = n++;
        long l = n;
        long l2 = (long)n + instanceCount;
        ++n;
        n = n13 - (int)(l + (l2 - (long)n));
        Test.vMeth(f, (short)n12, (byte)83);
        nArray[(n >>> 1) % 400][(n >>> 1) % 400][(n >>> 1) % 400] = n12;
        n -= n;
        n2 = 1;
        do {
            n = 51656;
            n3 &= (int)instanceCount;
        } while ((n2 += 3) < 132);
        block12: for (n4 = 22; n4 < 389; ++n4) {
            if (bl || bl) continue;
            for (n6 = 69; n6 > 1; --n6) {
                try {
                    n5 = nArray[n4 + 1][n6][n4] / 229;
                    n7 = n3 % n2;
                    nArray[n4][n6 + 1][n4] = 232 / n;
                    continue;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
            }
            nArray[n4 - 1][n4][n4] = n2;
            nArray[n4 + 1][n4][n4 - 1] = n5;
            n7 *= n2;
            n5 -= n3;
            switch (n4 % 8 * 5 + 60) {
                case 85: {
                    n5 = 109;
                    n3 &= (int)instanceCount;
                    f += (float)n;
                }
                case 66: {
                    n = (int)instanceCount;
                    int[] nArray2 = nArray[n4 + 1][n4 - 1];
                    int n14 = n4 - 1;
                    nArray2[n14] = nArray2[n14] << -6;
                    continue block12;
                }
                case 95: {
                    for (n8 = 2; 69 > n8; ++n8) {
                        this.byFld = (byte)(this.byFld - (byte)n9);
                        n3 += n8 * n9 + n5 - n2;
                    }
                    n9 = -19;
                    continue block12;
                }
                case 86: {
                    for (n10 = 1; n10 < 69; ++n10) {
                        n3 = n2;
                    }
                    this.sArrFld[n4 + 1] = (short)this.fFld;
                    instanceCount *= (long)n;
                    continue block12;
                }
                case 93: 
                case 97: {
                    instanceCount -= instanceCount;
                    continue block12;
                }
                case 96: {
                    nArray[n4 - 1][n4 - 1][n4 + 1] = n10;
                    continue block12;
                }
                case 94: {
                    n3 += n4 * n4;
                    continue block12;
                }
            }
        }
        FuzzerUtils.out.println("i f3 s1 = " + n + "," + Float.floatToIntBits(f) + "," + n12);
        FuzzerUtils.out.println("i17 i18 i19 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i20 b1 i21 = " + n5 + "," + (bl ? 1 : 0) + "," + n6);
        FuzzerUtils.out.println("i22 i23 i24 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i25 i26 iArr2 = " + n10 + "," + n11 + "," + FuzzerUtils.checkSum((Object[][])nArray));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount byFld fFld = " + instanceCount + "," + this.byFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.fArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 55.666f);
        vMeth_check_sum = 0L;
        dMeth_check_sum = 0L;
        byMeth_check_sum = 0L;
    }
}

