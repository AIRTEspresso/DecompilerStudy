/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 54321L;
    public static int iFld = 57895;
    public static volatile boolean bFld = true;
    public int[] iArrFld = new int[400];
    public static float[][] fArrFld = new float[400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth(long l, float f) {
        int n = -59333;
        int n2 = 13342;
        int n3 = -14;
        int n4 = 231;
        int n5 = 93;
        boolean bl = false;
        int n6 = 22632;
        short[] sArray = new short[400];
        double d = -2.128752;
        double[] dArray = new double[400];
        FuzzerUtils.init(sArray, (short)31140);
        FuzzerUtils.init(dArray, -74.19942);
        n -= n;
        n2 = 1;
        do {
            l |= 0xFFFFFFFFB644004FL;
            int n7 = n2 - 1;
            sArray[n7] = (short)(sArray[n7] >> (short)n2);
            n3 = 1;
            block1: while (++n3 < 6) {
                for (n4 = 1; n4 < 1; ++n4) {
                    int n8 = n3 - 1;
                    sArray[n8] = (short)(sArray[n8] ^ (short)n5);
                    if (bl) continue block1;
                    n += n4 * n2 + n6 - n;
                    n5 *= (int)d;
                    n5 -= (int)l;
                    n += 26770 + n4 * n4;
                    int n9 = n3 + 1;
                    dArray[n9] = dArray[n9] + (double)n3;
                    d -= (double)n4;
                }
            }
        } while (++n2 < 254);
        long l2 = l + (long)Float.floatToIntBits(f) + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)(bl ? 1 : 0) + (long)n6 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(sArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth1() {
        float f = -3.913f;
        float[] fArray = new float[400];
        int n = -13;
        int n2 = 225;
        int n3 = -19169;
        int n4 = 30659;
        int n5 = -13;
        int n6 = 9;
        int[][] nArray = new int[400][400];
        double d = 90.21355;
        FuzzerUtils.init(fArray, 1.596f);
        FuzzerUtils.init(nArray, -46583);
        Test.iMeth(-2932141964L, f);
        for (n = 4; n < 318; n += 3) {
            n2 = 13038;
            n2 >>= iFld;
            for (n3 = 1; n3 < 15; n3 += 3) {
                iFld += (int)d;
                n4 *= n2;
                n4 = n;
                int n7 = n3 - 1;
                fArray[n7] = fArray[n7] - -132.0f;
                nArray[n3][n3 - 1] = n2;
            }
            iFld += n * n;
            for (n5 = n; n5 < 15; ++n5) {
                f += (float)n5;
                instanceCount = iFld;
            }
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(int n) {
        int n2 = -12741;
        int n3 = 4;
        int n4 = -139;
        int n5 = -55;
        int[] nArray = new int[400];
        float f = -9.42f;
        int n6 = 3880;
        int n7 = 2;
        FuzzerUtils.init(nArray, 1);
        Test.vMeth1();
        iFld = 190;
        n |= (int)instanceCount;
        for (n2 = 14; n2 < 273; ++n2) {
            boolean bl = true;
            instanceCount -= (long)f;
            instanceCount += 41127L;
            if (bl) {
                n4 = 1;
                while (++n4 < 6) {
                    iFld = -35;
                    n5 = 1;
                    do {
                        n += 185 + n5 * n5;
                        instanceCount += (long)n6;
                        instanceCount += (long)n5;
                        n3 = n7;
                        f *= (float)n7;
                    } while (++n5 < 1);
                }
                continue;
            }
            n = (int)((long)n + ((long)n2 * instanceCount + instanceCount - (long)n6));
        }
        vMeth_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 45102;
        int n2 = -140;
        int n3 = -43;
        int n4 = -9641;
        int n5 = -7927;
        int n6 = 16846;
        int n7 = 0;
        int n8 = -63869;
        int n9 = 110;
        double d = 125.45846;
        long l = -15078L;
        long[] lArray = new long[400];
        float f = 83.183f;
        int n10 = 9910;
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(lArray, -9L);
        FuzzerUtils.init(blArray, true);
        lArray[(n >>> 1) % 400] = this.iArrFld[(n >>> 1) % 400];
        Test.vMeth(n);
        n9 = (byte)(n9 >>> 6);
        d -= (double)instanceCount;
        int n11 = (n >>> 1) % 400;
        lArray[n11] = lArray[n11] + (long)n;
        for (n2 = 1; 145 > n2; ++n2) {
            n3 += n2 * n2;
            try {
                n = iFld / n2;
                n = 23869 % n2;
                this.iArrFld[n2 + 1] = this.iArrFld[n2 - 1] / n4;
                continue;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        }
        l = 1L;
        do {
            for (n5 = 232; n5 > 4; --n5) {
                n += (int)instanceCount;
                instanceCount *= -19L;
                iFld *= (int)f;
                block10: for (n7 = 1; n7 < 2; ++n7) {
                    n8 *= (int)l;
                    --n8;
                    iFld ^= n6;
                    int n12 = n7 - 1;
                    this.iArrFld[n12] = this.iArrFld[n12] - n7;
                    blArray[n5 + 1] = bFld;
                    switch (n5 % 4 * 5 + 78) {
                        case 82: 
                        case 91: {
                            n6 = iFld = 188;
                            n10 = (short)n7;
                            instanceCount += (long)n7;
                        }
                        case 98: {
                            lArray[181] = lArray[181] ^ (long)n8;
                            instanceCount >>= -736314550;
                            n3 = (int)l;
                            continue block10;
                        }
                        case 97: {
                            float[] fArray = fArrFld[(int)(l + 1L)];
                            int n13 = n5;
                            fArray[n13] = fArray[n13] + -10.0f;
                            n += (int)f;
                        }
                    }
                }
            }
        } while ((l += 3L) < 325L);
        FuzzerUtils.out.println("i by1 d2 = " + n + "," + n9 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i18 i19 i20 = " + n2 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("l1 i21 i22 = " + l + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f3 i23 i24 = " + Float.floatToIntBits(f) + "," + n7 + "," + n8);
        FuzzerUtils.out.println("s2 lArr bArr = " + n10 + "," + FuzzerUtils.checkSum(lArray) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 0.356f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

