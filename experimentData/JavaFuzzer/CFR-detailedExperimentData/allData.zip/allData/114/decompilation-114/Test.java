/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 6410838818528573617L;
    public static int iFld = 13;
    public static int iFld1 = 231;
    public static boolean bFld = true;
    public static float[] fArrFld = new float[400];
    public static long bMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = 5;
        int n2 = -32166;
        int n3 = 24633;
        int n4 = 28969;
        int n5 = -6;
        int[] nArray = new int[400];
        double d = 1.74993;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 3);
        FuzzerUtils.init(lArray, 2603973738L);
        iFld = (int)instanceCount;
        block6: for (n = 4; 285 > n; ++n) {
            float f = 2.737f;
            try {
                n2 = nArray[n - 1] % -145;
                n2 /= n;
                n2 = -1738862258 % iFld;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            switch ((n >>> 1) % 2 * 5 + 109) {
                case 118: {
                    n2 /= 18222;
                    continue block6;
                }
                case 110: {
                    if (bl) {
                        n3 = 1;
                        while (n3 < 6) {
                            n5 = 1;
                            do {
                                iFld *= -1;
                                d = n3;
                                d -= -5770.0;
                                int n6 = n3++;
                                lArray[n6] = lArray[n6] | instanceCount;
                            } while (++n5 < 2);
                            n2 += 14;
                        }
                        continue block6;
                    }
                    n2 = 0;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
    }

    public static void vMeth(int n, int n2, float f) {
        int n3 = 11;
        int n4 = -33757;
        int n5 = 58530;
        int n6 = 4;
        int n7 = 180;
        boolean bl = false;
        double d = 1.41276;
        double[] dArray = new double[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -6080L);
        FuzzerUtils.init(dArray, -23.37426);
        Test.vMeth1();
        lArray[255] = iFld;
        block4: for (n3 = 11; 327 > n3; ++n3) {
            n4 -= 823354691;
            n2 |= 8;
            for (n5 = 1; n5 < 5; ++n5) {
                dArray[n5 + 1] = iFld;
                if (bl) continue block4;
                n7 = 1;
                do {
                    switch (n3 % 2 * 5 + 50) {
                        case 56: {
                            instanceCount -= 0L;
                            int n8 = (n >>> 1) % 400;
                            lArray[n8] = lArray[n8] >> 168;
                            n4 = n7;
                            n2 += (int)d;
                        }
                        case 58: {
                            instanceCount += (long)n3;
                        }
                    }
                } while (++n7 < 2);
            }
        }
        vMeth_check_sum += (long)(n + n2 + Float.floatToIntBits(f) + n3 + n4 + n5 + n6 + (bl ? 1 : 0) + n7) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static boolean bMeth(int n) {
        int n2 = -63371;
        int n3 = -248;
        int n4 = 10;
        int n5 = -203;
        int n6 = 32545;
        float f = 6.663f;
        int n7 = 116;
        byte[][] byArray = new byte[400][400];
        long l = 130L;
        boolean bl = true;
        FuzzerUtils.init(byArray, (byte)-49);
        for (n2 = 7; n2 < 323; ++n2) {
            n = (int)(++instanceCount);
        }
        f = 1.0f;
        while (true) {
            float f2;
            f += 1.0f;
            if (!(f2 < 391.0f)) break;
            n3 ^= Math.abs(14);
            Test.vMeth(98, n, f);
        }
        iFld += n;
        instanceCount += instanceCount;
        for (n4 = 4; n4 < 154; ++n4) {
            n5 += n4 * iFld + n5 - n4;
            n7 = (byte)(n7 - (byte)iFld);
            for (l = 1L; l < 11L; ++l) {
                n3 = (int)l;
            }
            if (bl) continue;
            byArray[n4] = byArray[n4 + 1];
        }
        instanceCount = -4982L;
        long l2 = (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n7) + l + (long)n6 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(byArray);
        bMeth_check_sum += l2;
        return l2 % 2L > 0L;
    }

    public void mainTest(String[] stringArray) {
        float f = 0.236f;
        int n = 224;
        int n2 = -64;
        int n3 = -1;
        int n4 = 15918;
        int n5 = 13;
        int n6 = 200;
        int[] nArray = new int[400];
        int[] nArray2 = new int[400];
        int n7 = 96;
        double d = -2.9206;
        boolean[] blArray = new boolean[400];
        short[] sArray = new short[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(nArray, -40735);
        FuzzerUtils.init(nArray2, 41);
        FuzzerUtils.init(sArray, (short)-18776);
        f = 311.0f;
        while (true) {
            float f2;
            f -= 3.0f;
            if (!(f2 > 0.0f)) break;
            blArray[(int)f] = Test.bMeth(iFld);
        }
        for (n = 21; n < 363; ++n) {
            instanceCount += -27196L;
            int n8 = n + 1;
            fArrFld[n8] = fArrFld[n8] - (float)iFld;
            instanceCount &= 0x7EF3L;
            for (n3 = 2; n3 < 74; ++n3) {
                n5 = 1;
                do {
                    if (bFld) {
                        instanceCount += (long)(n5 - n7);
                        iFld >>>= n;
                        switch (n3 % 2 * 5 + 122) {
                            case 125: {
                                instanceCount += (long)n5;
                                instanceCount *= (long)d;
                                iFld1 += 57;
                                n2 -= n2;
                            }
                        }
                        nArray2[n] = (int)instanceCount;
                        iFld1 *= (int)instanceCount;
                        instanceCount -= (long)iFld;
                    }
                    int n9 = n;
                    nArray2[n9] = nArray2[n9] - 9;
                    iFld |= (int)instanceCount;
                    n4 = iFld1;
                } while (++n5 < 2);
                iFld1 *= 9;
                n6 = 1;
                while (++n6 < 2) {
                    int n10 = n6 - 1;
                    sArray[n10] = (short)(sArray[n10] * (short)n4);
                }
            }
            int n11 = n - 1;
            sArray[n11] = (short)(sArray[n11] - (short)instanceCount);
        }
        iFld = (int)instanceCount;
        nArray2[27] = nArray2[27] + iFld1;
        FuzzerUtils.out.println("f i19 i20 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i21 i22 i23 = " + n3 + "," + (n4 ^= n2) + "," + n5);
        FuzzerUtils.out.println("by1 d2 i24 = " + n7 + "," + Double.doubleToLongBits(d) + "," + n6);
        FuzzerUtils.out.println("bArr iArr1 iArr2 = " + FuzzerUtils.checkSum(blArray) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(nArray2));
        FuzzerUtils.out.println("sArr = " + FuzzerUtils.checkSum(sArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.bFld Test.fArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 42.196f);
        bMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

