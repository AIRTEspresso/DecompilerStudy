/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -10L;
    public short sFld = (short)-3104;
    public static double dFld = -1.93154;
    public static short sFld1 = (short)-7536;
    public static boolean bFld = false;
    public float fFld = 2.334f;
    public byte[] byArrFld = new byte[400];
    public static long[] lArrFld = new long[400];
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n, boolean bl) {
        int n2 = -13424;
        int n3 = -5;
        int n4 = 55176;
        int n5 = -65024;
        int n6 = -48;
        int n7 = -16599;
        int[] nArray = new int[400];
        int n8 = 106;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.753f);
        FuzzerUtils.init(nArray, -83);
        for (n2 = 3; 331 > n2; ++n2) {
            block4: for (n4 = 1; n4 < 5; ++n4) {
                n5 -= n2;
                switch (n4 % 1 + 126) {
                    case 126: {
                        int n9 = n2 - 1;
                        lArrFld[n9] = lArrFld[n9] >> -139;
                        n8 = (byte)(n8 << (byte)n2);
                        continue block4;
                    }
                    default: {
                        n -= 142;
                        n8 = (byte)n2;
                        if (bl) continue block4;
                        n3 = (int)instanceCount;
                    }
                }
            }
            for (n6 = 1; n6 < 5; ++n6) {
                int n10 = n6 - 1;
                fArray[n10] = fArray[n10] + (float)n2;
                int n11 = n6 - 1;
                nArray[n11] = nArray[n11] - 44041;
                if (bl) continue;
                n += (int)instanceCount;
            }
        }
        vMeth_check_sum += (long)(n + (bl ? 1 : 0) + n2 + n3 + n4 + n5 + n8 + n6 + n7) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(nArray);
    }

    public static long lMeth(byte by) {
        int n = 9;
        int n2 = 1981;
        int n3 = 7259;
        int n4 = 28851;
        int n5 = 222;
        boolean bl = false;
        boolean[] blArray = new boolean[400];
        long l = -5234185637074291691L;
        float f = 38.225f;
        FuzzerUtils.init(blArray, true);
        Test.vMeth(n, bl);
        for (l = 10L; 302L > l; ++l) {
            n3 = 6;
            while (--n3 > 0) {
                n2 = n;
                for (n4 = 1; n4 < 1; ++n4) {
                    dFld = l;
                    instanceCount = (long)((float)instanceCount + ((float)n4 * f + (float)instanceCount - (float)n5));
                    blArray[n4 + 1] = true;
                    f += f;
                    instanceCount = n4;
                    n5 += n4;
                    n5 |= n2;
                    n5 -= sFld1;
                }
                n = n2;
            }
        }
        long l2 = (long)(by + n + (bl ? 1 : 0)) + l + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(blArray);
        lMeth_check_sum += l2;
        return l2;
    }

    public static int iMeth() {
        int n = -1;
        int n2 = 8;
        int n3 = -86;
        int n4 = 6725;
        int n5 = -21856;
        float f = -56.748f;
        double d = -1.9204;
        int n6 = 93;
        n += n + (n + (n - n));
        int n7 = n++;
        Test.iArrFld[(n >>> 1) % 400] = n = (int)((float)n7 - ((float)Test.lMeth((byte)-95) + f));
        n2 = 1;
        do {
            for (n3 = 1; n3 < 11; ++n3) {
                if (bFld) {
                    n4 *= n3;
                    int n8 = n3 + 1;
                    iArrFld[n8] = iArrFld[n8] / 57;
                    continue;
                }
                n <<= n2;
                for (d = 1.0; 2.0 > d; d += 1.0) {
                    if (bFld) {
                        n4 += n3;
                        continue;
                    }
                    if (!bFld) continue;
                    int n9 = (int)d;
                    iArrFld[n9] = iArrFld[n9] + n6;
                    n4 += (int)instanceCount;
                }
            }
        } while (++n2 < 146);
        long l = (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4) + Double.doubleToLongBits(d) + (long)n5 + (long)n6;
        iMeth_check_sum += l;
        return (int)l;
    }

    /*
     * Unable to fully structure code
     */
    public void mainTest(String[] var1_1) {
        var2_2 = -85;
        var3_3 = -201;
        var4_4 = 66;
        var5_5 = 3;
        var6_6 = -3;
        var7_7 = -5;
        var8_8 = 16;
        v0 = (var2_2 >>> 1) % 400;
        v1 = this.byArrFld[v0];
        this.byArrFld[v0] = (byte)(v1 - 1);
        var2_2 <<= (int)(-(131L ^ (long)v1) << (this.sFld << var2_2) + Test.iMeth());
        Test.instanceCount = var2_2;
        Test.instanceCount -= -7596570181699054355L;
        for (var3_3 = 8; var3_3 < 195; ++var3_3) {
            Test.lArrFld[var3_3] = 7L;
            Test.instanceCount += (long)var3_3;
            Test.iArrFld[var3_3 - 1] = var2_2;
            switch (var3_3 % 2 + 7) {
                case 7: {
                    if (!Test.bFld) ** GOTO lbl53
                    if (Test.bFld) {
                        var5_5 = 1;
                        while (++var5_5 < 134) {
                            v2 = var3_3;
                            Test.iArrFld[v2] = Test.iArrFld[v2] >> -34151;
                            var2_2 -= (int)Test.instanceCount;
                            var4_4 = (int)Test.instanceCount;
                            var4_4 = this.sFld;
                            for (var6_6 = 1; var6_6 < 1; ++var6_6) {
                                var4_4 += var6_6 * var2_2 + var2_2 - var8_8;
                                var2_2 = (int)((long)var2_2 + (long)var6_6 * Test.instanceCount);
                                switch (var6_6 % 1 * 5 + 63) {
                                    case 68: {
                                        v3 = var6_6 + 1;
                                        Test.lArrFld[v3] = Test.lArrFld[v3] - (long)var7_7;
                                        if (!Test.bFld) break;
                                        var8_8 = (byte)(var8_8 << -115);
                                        this.sFld = (short)var4_4;
                                        Test.instanceCount += (long)var6_6;
                                    }
                                }
                                Test.instanceCount += (long)var7_7;
                                Test.instanceCount = var5_5;
                                var2_2 = var3_3;
                                var4_4 |= 9;
                            }
                        }
                    } else if (Test.bFld) {
                        var2_2 += -123 + var3_3 * var3_3;
                    } else if (Test.bFld) {
                        Test.sFld1 = (short)(Test.sFld1 << (short)var7_7);
                    }
                    ** GOTO lbl57
lbl53:
                    // 1 sources

                    if (Test.bFld) {
                        this.fFld += -106.0f;
                    } else {
                        var4_4 >>>= var6_6;
                    }
                }
lbl57:
                // 6 sources

                case 8: {
                    var7_7 = this.sFld;
                }
            }
        }
        FuzzerUtils.out.println("i i18 i19 = " + var2_2 + "," + var3_3 + "," + var4_4);
        FuzzerUtils.out.println("i20 i21 i22 = " + var5_5 + "," + var6_6 + "," + var7_7);
        FuzzerUtils.out.println("by3 = " + var8_8);
        FuzzerUtils.out.println("Test.instanceCount sFld Test.dFld = " + Test.instanceCount + "," + this.sFld + "," + Double.doubleToLongBits(Test.dFld));
        FuzzerUtils.out.println("Test.sFld1 Test.bFld fFld = " + Test.sFld1 + "," + (Test.bFld != false ? 1 : 0) + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("byArrFld Test.lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(this.byArrFld) + "," + FuzzerUtils.checkSum(Test.lArrFld) + "," + FuzzerUtils.checkSum(Test.iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + Test.vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + Test.lMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + Test.iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -32L);
        FuzzerUtils.init(iArrFld, 24);
        iMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

