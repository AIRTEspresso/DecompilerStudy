/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3139461427362276786L;
    public int iFld = 191;
    public static double dFld = 1.385;
    public static float fFld = -22.27f;
    public static boolean bFld = true;
    public static byte byFld = (byte)7;
    public static int iFld1 = -39535;
    public static int[] iArrFld = new int[400];
    public long[] lArrFld = new long[400];
    public static short[][] sArrFld = new short[400][400];
    public static long iMeth_check_sum;
    public static long lMeth_check_sum;
    public static long fMeth_check_sum;

    public static float fMeth() {
        int n = 37;
        int n2 = 128;
        int n3 = 45101;
        int n4 = 229;
        int n5 = -111;
        int n6 = 23381;
        boolean bl = true;
        int n7 = 18441;
        for (n = 5; 385 > n; ++n) {
            if (bl) continue;
            n2 = (int)instanceCount;
            dFld = n3;
            if (bl) {
                switch (n % 2 * 5 + 78) {
                    case 81: {
                        for (n4 = 1; 4 > n4; ++n4) {
                            n6 = 1;
                            while (++n6 < 2) {
                                Test.iArrFld[n4] = n7;
                            }
                            instanceCount = (long)((float)instanceCount + ((float)(n4 * (n2 -= n7)) + fFld - (float)n2));
                            n3 = (int)((float)n3 + ((float)n4 - fFld));
                        }
                        n5 = (int)((long)n5 + ((long)n | (long)fFld));
                        n2 += n;
                        break;
                    }
                    case 80: {
                        n5 *= n6;
                        break;
                    }
                    default: {
                        n3 *= (int)fFld;
                        break;
                    }
                }
                continue;
            }
            if (bl) {
                n2 += (int)instanceCount;
                continue;
            }
            n2 += n;
        }
        long l = n + n2 + (bl ? 1 : 0) + n3 + n4 + n5 + n6 + n7;
        fMeth_check_sum += l;
        return l;
    }

    public static long lMeth() {
        int n = -11547;
        int n2 = -13;
        int n3 = -12;
        int n4 = -14;
        int n5 = 13755;
        long l = -3919467807L;
        for (int n6 : iArrFld) {
            for (n = 1; n < 4; ++n) {
                short[] sArray = sArrFld[n];
                int n7 = n + 1;
                short s = (short)(sArray[n7] - 1);
                sArray[n7] = s;
                n5 = s;
                n6 += (int)(-((dFld -= 1.0) * (double)Test.fMeth()));
                l = 1L;
                do {
                    int n8 = (int)(l + 1L);
                    iArrFld[n8] = iArrFld[n8] * n6;
                    Test.iArrFld[n + 1] = (int)(instanceCount -= (long)fFld);
                    n2 -= n6;
                } while (++l < 2L);
            }
            fFld = n;
            iArrFld[193] = iArrFld[193] << n6;
            for (n3 = 1; n3 < 4; ++n3) {
                fFld *= (float)n6;
                n2 = (int)((long)n2 + ((long)n3 * l + (long)n3 - (long)n6));
            }
        }
        long l2 = (long)(n + n2 + n5) + l + (long)n3 + (long)n4;
        lMeth_check_sum += l2;
        return l2;
    }

    public static int iMeth() {
        int n = 8567;
        int n2 = 180;
        int n3 = 0;
        int n4 = -199;
        int n5 = 21521;
        int n6 = -5;
        int n7 = -28;
        int n8 = -166;
        n = 172;
        do {
            n2 += n * n;
            Test.lMeth();
            n2 += 8740;
        } while (--n > 0);
        n2 *= n;
        n3 = 1;
        do {
            int n9 = n3;
            iArrFld[n9] = iArrFld[n9] | n3;
            for (n4 = 1; n4 < 4; ++n4) {
                byFld = (byte)instanceCount;
                for (n6 = n3; n6 < 2; ++n6) {
                    n7 = (int)((float)n7 + ((float)(n6 * (n2 &= n7) + byFld) - fFld));
                }
                if (iFld1 != 0) {
                    // empty if block
                }
                int n10 = n4 - 1;
                iArrFld[n10] = iArrFld[n10] - -2;
                n8 = n5;
            }
        } while (++n3 < 391);
        long l = n + n2 + n3 + n4 + n5 + n6 + n7 + n8;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        float f = -103.274f;
        float[] fArray = new float[400];
        int n = -14;
        int n2 = -6;
        int n3 = -65;
        int n4 = 13;
        int n5 = -34669;
        boolean bl = false;
        double[] dArray = new double[400];
        FuzzerUtils.init(fArray, -91.144f);
        FuzzerUtils.init(dArray, -1.58);
        f *= (float)(this.iFld |= Math.abs((int)(dFld + (double)this.iFld)));
        n = 1;
        block14: while (++n < 132) {
            long l = this.lArrFld[n];
            this.lArrFld[n + 1] = l;
            Test.iArrFld[n] = (int)l;
            block15: for (n2 = 11; n2 < 190; ++n2) {
                float f2 = 0.547f;
                int n6 = n + 1;
                int n7 = iArrFld[n6];
                iArrFld[n6] = n7 + 1;
                n3 = -(-(n - n2)) + n3 + Math.abs(n7);
                if (bl) continue block14;
                int n8 = n - 1;
                fArray[n8] = fArray[n8] * (float)(-this.iFld);
                instanceCount = --n3;
                this.iFld <<= (int)((long)Math.abs(Integer.reverseBytes(23015)) * (instanceCount-- + (long)Integer.reverseBytes(-240)));
                switch (n2 % 6 + 35) {
                    case 35: {
                        int n9 = n2;
                        iArrFld[n9] = iArrFld[n9] % (Test.iMeth() | 1);
                        this.iFld -= n3;
                        Test.iArrFld[n] = (int)instanceCount;
                        block16: for (n4 = 2; n4 > 1; n4 -= 2) {
                            switch (n4 % 5 + 120) {
                                case 120: {
                                    n3 *= (int)f;
                                    if (bFld) {
                                        this.iFld -= n3;
                                        instanceCount ^= instanceCount;
                                        continue block16;
                                    }
                                    n5 = n;
                                    iFld1 += n4;
                                    f += (float)n4;
                                    this.iFld = this.iFld;
                                    continue block16;
                                }
                                case 121: {
                                    iFld1 = (int)((float)iFld1 + ((float)n4 - fFld));
                                    continue block16;
                                }
                                case 122: {
                                    iFld1 *= -4321;
                                    int n10 = n2 - 1;
                                    iArrFld[n10] = iArrFld[n10] + (int)instanceCount;
                                    f += (float)(n4 * n);
                                    instanceCount *= -55L;
                                    continue block16;
                                }
                                case 123: {
                                    instanceCount += (long)(3 + n4 * n4);
                                    instanceCount += (long)f;
                                    continue block16;
                                }
                                case 124: {
                                    n3 += n4;
                                }
                            }
                        }
                        continue block15;
                    }
                    case 36: {
                        this.iFld += n2 + n5;
                        continue block15;
                    }
                    case 37: {
                        f2 += (float)(n2 * this.iFld + n - n);
                    }
                    case 38: {
                        if (!bFld) continue block15;
                        continue block15;
                    }
                    case 39: {
                        this.iFld = n4;
                    }
                    default: {
                        dArray[n2 - 1] = n;
                    }
                }
            }
        }
        FuzzerUtils.out.println("f i i1 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("i2 b i22 = " + n3 + "," + (bl ? 1 : 0) + "," + n4);
        FuzzerUtils.out.println("i23 fArr dArr = " + n5 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fFld Test.bFld Test.byFld = " + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0) + "," + byFld);
        FuzzerUtils.out.println("Test.iFld1 Test.iArrFld lArrFld = " + iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -10);
        FuzzerUtils.init(sArrFld, (short)27125);
        iMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
    }
}

