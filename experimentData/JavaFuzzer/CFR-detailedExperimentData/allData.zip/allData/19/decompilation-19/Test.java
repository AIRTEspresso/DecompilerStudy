/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 2635474643414078350L;
    public double dFld = 126.123539;
    public static float fFld = 1.194f;
    public volatile short sFld = (short)-19991;
    public static int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2, boolean bl) {
        int n3 = 75;
        int n4 = 219;
        int n5 = -235;
        int n6 = 8;
        int[] nArray = new int[400];
        float f = -110.209f;
        int n7 = -29305;
        FuzzerUtils.init(nArray, -52078);
        n3 = 1;
        while ((n3 += 2) < 229) {
            for (n4 = 1; n4 < 14; ++n4) {
                int n8 = n3;
                nArray[n8] = nArray[n8] + (int)f;
                n >>= n7;
                n6 = 1;
                do {
                    f += (float)(n6 * n6);
                    n2 -= n3;
                    f -= f;
                    n2 = n3;
                    instanceCount = n7;
                    instanceCount += (long)(n6 * n + n) - instanceCount;
                    n -= n;
                    n5 = n3;
                    n5 += n6 ^ n;
                    n = -20531;
                } while (++n6 < 2);
            }
        }
        vMeth2_check_sum += (long)(n + n2 + (bl ? 1 : 0) + n3 + n4 + n5 + Float.floatToIntBits(f) + n7 + n6) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1(long l, short s, int n) {
        boolean bl = false;
        int n2 = -5;
        int n3 = 32747;
        int n4 = -129;
        int n5 = 18080;
        int n6 = 34680;
        int n7 = 4;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 105.79999);
        Test.vMeth2(n, -14, bl);
        instanceCount -= (long)n;
        int n8 = (n >>> 1) % 400;
        iArrFld[n8] = iArrFld[n8] >> -62707;
        fFld -= -43.12985f;
        for (n2 = 2; n2 < 362; ++n2) {
            for (n4 = 1; n4 < 5; ++n4) {
                fFld = n;
                n6 = 1;
                while (++n6 < 2) {
                    int n9 = n6 + 1;
                    iArrFld[n9] = iArrFld[n9] & (int)l;
                    n3 = n5;
                    n = (int)l;
                    dArray[n6 + 1] = n4;
                    s = (short)(s + n7);
                    if (!bl) continue;
                }
            }
        }
        vMeth1_check_sum += l + (long)s + (long)n + (long)(bl ? 1 : 0) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)n7 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth(double d, float f, long l) {
        short s = 24636;
        int n = 13;
        int n2 = 138;
        int n3 = -13;
        int n4 = 36;
        boolean bl = true;
        int n5 = 29;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, -2.416f);
        Test.vMeth1(instanceCount, s, 64611);
        n = 1;
        do {
            if (bl) continue;
            n2 ^= n;
            for (n3 = 1; n3 < 4; ++n3) {
                n2 = (int)instanceCount;
                n4 -= (int)fFld;
                n2 <<= n3;
                n2 = (int)l;
                fArray[n + 1] = n;
                n2 >>= n5;
                d -= d;
                if (bl) {
                    n4 = n3;
                    fFld *= (float)n3;
                    continue;
                }
                if (bl) {
                    n2 |= n2;
                    continue;
                }
                l <<= n4;
            }
        } while (++n < 398);
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)Float.floatToIntBits(f) + l + (long)s + (long)n + (long)(bl ? 1 : 0) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public void mainTest(String[] stringArray) {
        int n = -10;
        int n2 = 54911;
        int n3 = 107;
        int n4 = -3;
        double d = 88.95346;
        boolean bl = true;
        int n5 = -67;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 1.372f);
        for (n = 7; 123 > n; ++n) {
            try {
                n2 = n / 7299;
                n2 = 64470 % n;
                n2 = -339529081 % n2;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            for (d = 216.0; d > (double)n; d -= 1.0) {
                n2 = n3 - n3 + -(n3 - n) - n;
                double d2 = this.dFld;
                this.dFld = d2 - 1.0;
                n3 *= (int)d2;
                Test.vMeth(this.dFld, fFld, 59682L);
                n3 = n2;
                if (bl) break;
                Test.iArrFld[n] = -5647;
                n4 = 1;
                do {
                    n2 = -8;
                    n2 = n3;
                    this.dFld -= 4.0;
                    n3 -= n;
                    switch (n % 1 * 5 + 110) {
                        case 114: {
                            fFld = n2;
                            Test.iArrFld[n4 - 1] = n4;
                            fArray[(int)(d + 1.0)] = fFld;
                            this.sFld = 1;
                            n3 ^= n;
                        }
                    }
                    n2 += n2;
                    n2 = n4++;
                } while (!bl && n4 < 1);
                n3 ^= this.sFld;
                n3 -= n;
            }
            n2 = -34816;
            n5 = (byte)fFld;
        }
        FuzzerUtils.out.println("i i1 d = " + n + "," + (n2 *= n) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i2 b3 i19 = " + n3 + "," + (bl ? 1 : 0) + "," + n4);
        FuzzerUtils.out.println("by2 fArr1 = " + n5 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("sFld Test.iArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 6);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

