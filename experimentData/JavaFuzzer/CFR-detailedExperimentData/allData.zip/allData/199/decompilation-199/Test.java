/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 1756888618L;
    public short sFld = (short)2230;
    public boolean bFld = false;
    public static double dFld = 1.38551;
    public volatile int iFld = 167;
    public static long[][] lArrFld = new long[400][400];
    public static float[] fArrFld = new float[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long iMeth2_check_sum;

    public static int iMeth2(int n, int n2, int n3) {
        int n4 = -9;
        int n5 = -57746;
        int n6 = 64400;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 55659);
        n = n3;
        n = n2;
        instanceCount >>= 62952;
        n3 >>= n3;
        for (n4 = 7; 138 > n4; ++n4) {
            n3 -= n3;
            n3 = n4;
            try {
                n3 = nArray[n4 + 1] / -224;
                n2 = n4 / -1009995685;
                nArray[n4 - 1] = -462777520 / n4;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n2 += n4;
            n3 &= (int)instanceCount;
            switch (n4 % 1 + 122) {
                case 122: {
                    instanceCount += (long)(n4 | n5);
                    n6 = 1;
                    do {
                        n3 <<= n2;
                        long[] lArray = lArrFld[n6 - 1];
                        int n7 = n6++;
                        lArray[n7] = lArray[n7] + instanceCount;
                    } while (n6 < 12);
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray);
        iMeth2_check_sum += l;
        return (int)l;
    }

    public static int iMeth1() {
        int n = -58630;
        int n2 = -10;
        int n3 = -33704;
        int n4 = 11;
        int n5 = -9327;
        int n6 = 31460;
        int n7 = -37;
        int[] nArray = new int[400];
        double d = -1.16138;
        boolean bl = true;
        FuzzerUtils.init(nArray, -35851);
        for (n = 12; n < 352; ++n) {
            for (n3 = n; n3 < 5; ++n3) {
                for (n5 = n3; n5 < 1; ++n5) {
                    try {
                        n2 /= nArray[n3];
                        n2 = n6 / -37666;
                        n2 = n4 / nArray[n3 - 1];
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    n4 = (int)((long)n4 + ((long)n5 + instanceCount));
                    instanceCount += (long)(n5 - n5);
                    instanceCount |= (long)(n2 += (int)((double)Test.iMeth2(n3, n4, n4) * d));
                    n6 *= (int)d;
                    try {
                        n4 = nArray[n3 - 1] / n6;
                        n6 = n / 108;
                        n4 = n6 % n;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    long[] lArray = lArrFld[n5 + 1];
                    int n8 = n3;
                    lArray[n8] = lArray[n8] + (long)n3;
                }
                instanceCount = n3;
                n7 = 1;
                while (++n7 < 1) {
                    n2 *= n6;
                    if (!bl) continue;
                }
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public int iMeth(int n, byte by, int n2) {
        double d = 88.64745;
        int n3 = 171;
        int n4 = 1;
        int[] nArray = new int[400];
        float f = -21.907f;
        FuzzerUtils.init(nArray, 33223);
        block17: for (d = 2.0; d < 288.0; d += 1.0) {
            switch ((Math.min(-100, -178) >>> 1) % 7 + 22) {
                case 22: {
                    switch ((int)(d % 4.0 * 5.0)) {
                        case 19: {
                            f -= (float)Test.iMeth1();
                            break;
                        }
                        case 18: {
                            instanceCount += (long)(d * d);
                            n2 -= this.sFld;
                            instanceCount += (long)by;
                            break;
                        }
                        case 14: {
                            f += (float)(d * (double)instanceCount + (double)n2 - (double)n2);
                            if (this.bFld) break;
                            this.bFld = false;
                            n = (int)((double)n + (-217.0 + d * d));
                            break;
                        }
                        case 9: {
                            if (this.bFld) {
                                dFld += (double)n2;
                                instanceCount *= instanceCount;
                                break;
                            }
                            if (this.bFld) {
                                this.iFld += (int)(d - (double)n4);
                            } else {
                                break;
                            }
                        }
                    }
                    continue block17;
                }
                case 23: {
                    dFld += (double)n3;
                }
                case 24: {
                    Test.fArrFld[(int)d] = (float)dFld;
                }
                case 25: {
                    n4 = (int)instanceCount;
                }
                case 26: {
                    instanceCount = -88L;
                }
                case 27: {
                    nArray[(int)(d + 1.0)] = n3;
                }
                case 28: {
                    try {
                        this.iFld = n2 % 822935784;
                        this.iFld = -342026397 / nArray[(int)(d - 1.0)];
                        n3 = this.iFld % 17809;
                        continue block17;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
            }
        }
        long l = (long)(n + by + n2) + Double.doubleToLongBits(d) + (long)n3 + (long)Float.floatToIntBits(f) + (long)n4 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = -8723;
        int n2 = 105;
        int n3 = -62;
        int n4 = -129;
        int n5 = -233;
        int n6 = 71;
        int n7 = 8;
        int n8 = -34135;
        int[] nArray = new int[400];
        float f = 37.157f;
        int n9 = 83;
        byte[] byArray = new byte[400];
        short[][] sArray = new short[400][400];
        boolean[] blArray = new boolean[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, 58);
        FuzzerUtils.init(byArray, (byte)-13);
        FuzzerUtils.init(sArray, (short)-28163);
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(dArray, 56.48633);
        block14: for (n = 5; n < 171; n += 2) {
            this.iMeth(n, (byte)45, n);
            switch (n % 6 + 79) {
                case 79: {
                    for (n3 = 15; n3 < 302; ++n3) {
                        switch ((n >>> 1) % 1 + 37) {
                            case 37: {
                                n5 = 2;
                                while (--n5 > 0) {
                                    instanceCount += (long)this.iFld;
                                    if (this.bFld) {
                                        n4 += (int)dFld;
                                    }
                                    instanceCount = n4;
                                }
                                break;
                            }
                            default: {
                                nArray[n] = n2;
                                int n10 = n;
                                byArray[n10] = (byte)(byArray[n10] * (byte)this.sFld);
                            }
                        }
                        sArray[n - 1][n3] = (short)n4;
                        n4 = (int)((long)n4 + ((long)(n3 * n) + (instanceCount *= (long)n) - (long)n4));
                        n4 += n;
                        this.iFld *= (int)instanceCount;
                    }
                    n6 = 302;
                    do {
                        dFld += (double)instanceCount;
                        nArray[n6] = (int)instanceCount;
                        dFld += (double)instanceCount;
                        n2 = (int)((long)n2 + ((long)n6 * instanceCount + (long)n - (long)n5));
                        f += (float)n3;
                        Test.fArrFld[n6 + 1] = n5;
                    } while ((n6 -= 3) > 0);
                    block18: for (n7 = 3; n7 < 302; ++n7) {
                        switch ((n3 >>> 1) % 2 + 125) {
                            case 125: {
                                blArray[3] = this.bFld;
                                instanceCount = 43402L;
                                instanceCount += (long)(n7 * n6 + n5) - instanceCount;
                            }
                            case 126: {
                                dArray[n] = f;
                                continue block18;
                            }
                            default: {
                                int n11 = n + 1;
                                nArray[n11] = nArray[n11] - 1;
                            }
                        }
                    }
                }
                case 80: 
                case 81: {
                    dFld *= (double)n;
                    continue block14;
                }
                case 82: {
                    n8 += (int)f;
                    continue block14;
                }
                case 83: {
                    n9 = (byte)(n9 - (byte)this.sFld);
                    continue block14;
                }
                case 84: {
                    instanceCount = n;
                }
                default: {
                    n4 += n ^ n5;
                }
            }
        }
        FuzzerUtils.out.println("i i1 i20 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 i22 i23 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f1 i24 i25 = " + Float.floatToIntBits(f) + "," + n7 + "," + n8);
        FuzzerUtils.out.println("by1 iArr3 byArr = " + n9 + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("sArr bArr dArr = " + FuzzerUtils.checkSum(sArray) + "," + FuzzerUtils.checkSum(blArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount sFld bFld = " + instanceCount + "," + this.sFld + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dFld iFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -14L);
        FuzzerUtils.init(fArrFld, -2.591f);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        iMeth2_check_sum = 0L;
    }
}

