/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 5588716753445120000L;
    public short sFld = (short)-23480;
    public short sFld1 = (short)-16171;
    public static long iMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long iMeth1_check_sum = 0L;

    public static int iMeth1(int n) {
        int n2 = 12;
        int n3 = 20702;
        int n4 = -10;
        int n5 = -8;
        int[][] nArray = new int[400][400];
        FuzzerUtils.init(nArray, -48);
        for (n2 = 235; n2 > 9; --n2) {
            try {
                n4 = 14 / n;
                n = nArray[n2 + 1][n2] % n2;
                n5 = n4 / 653800839;
                continue;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5) + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static void vMeth(int n, double d, boolean bl) {
        int n2 = 4;
        int n3 = -46256;
        int n4 = 42621;
        int n5 = -3;
        int n6 = -3;
        int[] nArray = new int[400];
        float f = -67.183f;
        FuzzerUtils.init(nArray, -1);
        n = (int)((double)(-Test.iMeth1(n)) * d);
        block3: for (n2 = 2; 347 > n2; ++n2) {
            n4 = 1;
            while (++n4 < 5) {
                instanceCount = n4;
                n = n4;
                n += 13 + n4 * n4;
            }
            switch (n2 % 1 * 5 + 58) {
                case 61: {
                    instanceCount -= -191L;
                    if (bl) continue block3;
                }
                default: {
                    n >>= n2;
                    if (bl) {
                        for (n5 = 1; n5 < 5; ++n5) {
                            int n7 = (n4 >>> 1) % 400;
                            nArray[n7] = nArray[n7] ^ (int)instanceCount;
                            f += (float)n3;
                            n3 *= -32;
                        }
                        continue block3;
                    }
                    if (bl) continue block3;
                }
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n6 + (long)Float.floatToIntBits(f) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(double d) {
        int n = 223;
        int n2 = 7;
        int n3 = -38228;
        int[] nArray = new int[400];
        boolean bl = false;
        float f = 85.897f;
        FuzzerUtils.init(nArray, 101);
        for (n = 7; n < 379; ++n) {
            nArray[n] = n;
            Test.vMeth(38805, d, bl);
            f = -8.7536821E18f;
            if (bl) continue;
            instanceCount -= (long)n2;
            n2 += n;
            n2 += n ^ n2;
            n3 /= n | 1;
        }
        long l = Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)n3 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        boolean bl = true;
        double d = 0.89714;
        double d2 = 0.22961;
        int n = -199;
        int n2 = -55832;
        int n3 = 4;
        int n4 = 10;
        int n5 = 2;
        int n6 = -29;
        int n7 = -231;
        int n8 = 99;
        int n9 = 32;
        int n10 = -480;
        int[] nArray = new int[400];
        int n11 = -69;
        float f = -1.445f;
        float[][][] fArray = new float[400][400][400];
        long l = 23773L;
        FuzzerUtils.init(nArray, 7439);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(108.203f));
        bl = Test.iMeth(d) > this.sFld;
        n = n11;
        for (n2 = 4; n2 < 396; ++n2) {
            this.sFld1 = (short)(this.sFld1 + (short)(n2 + n3));
            n3 -= (int)instanceCount;
            if (bl) break;
        }
        instanceCount *= -10L;
        f = n3;
        for (l = 1L; l < 272L; ++l) {
            n3 *= 36541;
        }
        for (n5 = 1; n5 < 163; ++n5) {
            for (n7 = 4; n7 < 155; ++n7) {
                this.sFld = (short)(this.sFld + (short)((long)(n7 * n3) + instanceCount - (long)n));
                d = n8;
                for (d2 = 1.0; d2 < 2.0; d2 += 2.0) {
                    n9 <<= (int)instanceCount;
                    n8 += n5;
                    try {
                        nArray[n5] = n8 / nArray[n7];
                        n8 = -35716 % nArray[n5 + 1];
                        n = 243 / n6;
                        continue;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                }
                n8 = 92;
                n10 = 1;
                do {
                    if (bl) {
                        n = (int)f;
                    }
                    n9 += (int)d;
                    instanceCount -= (long)n4;
                    int n12 = n10 + 1;
                    nArray[n12] = nArray[n12] + n8;
                    float[] fArray2 = fArray[n5][n10 + 1];
                    int n13 = n5;
                    fArray2[n13] = fArray2[n13] + (float)n8;
                    int n14 = n5;
                    nArray[n14] = nArray[n14] << n3;
                } while (++n10 < 2);
            }
        }
        FuzzerUtils.out.println("b d2 i14 = " + (bl ? 1 : 0) + "," + Double.doubleToLongBits(d) + "," + n);
        FuzzerUtils.out.println("by i15 i16 = " + n11 + "," + n2 + "," + n3);
        FuzzerUtils.out.println("f2 l i17 = " + Float.floatToIntBits(f) + "," + l + "," + n4);
        FuzzerUtils.out.println("i18 i19 i20 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i21 d3 i22 = " + n8 + "," + Double.doubleToLongBits(d2) + "," + n9);
        FuzzerUtils.out.println("i23 iArr3 fArr = " + n10 + "," + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)));
        FuzzerUtils.out.println("Test.instanceCount sFld sFld1 = " + instanceCount + "," + this.sFld + "," + this.sFld1);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

