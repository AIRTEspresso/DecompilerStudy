/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 91422406L;
    public static volatile int iFld = 48503;
    public static double dFld = -57.101559;
    public static short sFld = (short)14556;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;
    public static long vMeth2_check_sum = 0L;

    public static void vMeth2() {
        int n = -12859;
        int n2 = -2;
        int n3 = 4224;
        int n4 = 187;
        int[] nArray = new int[400];
        float f = -2.326f;
        FuzzerUtils.init(nArray, 1);
        n = 1;
        do {
            for (n2 = 1; n2 < 13; ++n2) {
                iFld = (int)((long)iFld + ((long)(n2 * n3) + instanceCount - instanceCount));
                iFld >>>= (int)instanceCount;
                n3 *= n3;
                instanceCount -= instanceCount;
                n4 = 1;
                while (++n4 < 2) {
                    switch (n % 4 + 58) {
                        case 58: {
                            instanceCount = 1529322783506501478L;
                            iFld = (int)dFld;
                            iFld += (int)(0L + (long)(n4 * n4));
                            break;
                        }
                        case 59: {
                            --iFld;
                            n3 += (int)(-394978877L + (long)(n4 * n4));
                            try {
                                nArray[98] = n % nArray[n2 - 1];
                                n3 = 214 / nArray[n4 + 1];
                                n3 = -107 % nArray[n2 + 1];
                            }
                            catch (ArithmeticException arithmeticException) {}
                            break;
                        }
                        case 60: {
                            sFld = (short)(sFld + (short)f);
                            break;
                        }
                        case 61: {
                            iFld += -9;
                        }
                    }
                }
            }
        } while (++n < 121);
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth1() {
        int n = -1;
        int n2 = 252;
        int n3 = -241;
        int n4 = -9972;
        int n5 = 6;
        int[] nArray = new int[400];
        float f = 0.294f;
        long l = -3391514436L;
        FuzzerUtils.init(nArray, 93);
        n = 1;
        while (++n < 179) {
            instanceCount += (long)iFld--;
            n2 = 1;
            do {
                f += (float)(n2 * n2);
            } while (++n2 < 9);
            instanceCount -= (long)nArray[n - 1];
            Test.vMeth2();
            for (l = 9L; l > 1L; --l) {
                for (n4 = 1; n4 < 2; ++n4) {
                    dFld += (double)n;
                    n3 += (int)(101L + (long)(n4 * n4));
                    n5 = (int)((float)n5 + ((float)((long)n4 * l) + f - (float)instanceCount));
                    n3 *= 234;
                    f *= (float)sFld;
                    int n6 = (int)(l - 1L);
                    nArray[n6] = nArray[n6] << iFld;
                    n5 = (int)l;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + Float.floatToIntBits(f)) + l + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public static void vMeth(byte by, boolean bl) {
        int n = 108;
        int n2 = 30256;
        int n3 = 35;
        float f = -62.619f;
        Test.vMeth1();
        n = 320;
        while (--n > 0) {
            f *= (float)iFld;
        }
        instanceCount = iFld;
        iFld = 0;
        for (n2 = 5; n2 < 240; ++n2) {
            n3 += n2;
        }
        iFld <<= n;
        instanceCount *= (long)sFld;
        iFld += by;
        instanceCount >>= -1409;
        vMeth_check_sum += (long)(by + (bl ? (byte)1 : 0) + n + Float.floatToIntBits(f) + n2 + (n3 += (int)dFld));
    }

    public void mainTest(String[] stringArray) {
        byte by = -10;
        boolean bl = false;
        int n = 14;
        int n2 = 137;
        int n3 = -12;
        int[] nArray = new int[400];
        long l = -6333598361640171668L;
        long l2 = 3717823922L;
        long[] lArray = new long[400];
        float f = 79.696f;
        FuzzerUtils.init(nArray, -2);
        FuzzerUtils.init(lArray, 119L);
        Test.vMeth(by, bl);
        n = 1;
        while (++n < 313) {
            iFld += iFld;
            for (l = 2L; 80L > l; ++l) {
                l2 = 1L;
                while (++l2 < 2L) {
                    int n4 = (int)(l2 + 1L);
                    nArray[n4] = nArray[n4] - (n2 += (int)(l2 * l2));
                    f += (float)l2;
                    n2 >>= (int)instanceCount;
                    instanceCount += l2;
                    switch ((int)(l2 % 1L + 60L)) {
                        case 60: {
                            n2 += (int)l2;
                            break;
                        }
                        default: {
                            instanceCount &= l;
                            iFld += iFld;
                            by = (byte)(by - (byte)l2);
                        }
                    }
                    nArray[n + 1] = (int)f;
                }
                dFld -= (double)n;
                n3 = 1;
                while (++n3 < 2) {
                    iFld = 0;
                    n2 >>= n2;
                    n2 = iFld <<= n;
                    int n5 = (int)l;
                    nArray[n5] = nArray[n5] + n3;
                    int n6 = n - 1;
                    lArray[n6] = lArray[n6] >> -73;
                    by = (byte)dFld;
                }
                iFld -= (int)dFld;
            }
            lArray[n] = 30L;
            iFld += 987379418;
        }
        FuzzerUtils.out.println("by1 b1 i12 = " + by + "," + (bl ? 1 : 0) + "," + n);
        FuzzerUtils.out.println("l1 i13 l2 = " + l + "," + n2 + "," + l2);
        FuzzerUtils.out.println("f3 i14 iArr2 = " + Float.floatToIntBits(f) + "," + n3 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.sFld = " + sFld);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

