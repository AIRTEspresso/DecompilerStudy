/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 31L;
    public volatile byte byFld = (byte)-90;
    public static short sFld = (short)24809;
    public boolean bFld = true;
    public static int[] iArrFld = new int[400];
    public static volatile byte[] byArrFld = new byte[400];
    public static long[][] lArrFld = new long[400][400];
    public float[] fArrFld = new float[400];
    public static long fMeth_check_sum;
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;

    public static void vMeth1() {
        int n = -7;
        int n2 = 1;
        int n3 = -1;
        float f = 39.809f;
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 0.116437);
        n = 1;
        while (++n < 248) {
            for (n2 = 1; n2 < 7; ++n2) {
                int n4 = n + 1;
                dArray[n4] = dArray[n4] * (double)instanceCount;
                Test.iArrFld[n] = (int)instanceCount;
                Test.byArrFld[n] = (byte)n;
                n3 *= (int)f;
                f -= (float)n2;
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
    }

    public static void vMeth(int n) {
        int n2 = 135;
        int n3 = 89;
        int n4 = -53907;
        int n5 = 0;
        int n6 = -2102;
        float f = 14.461f;
        float[] fArray = new float[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(fArray, 0.426f);
        FuzzerUtils.init(lArray, 5058943701552193298L);
        n <<= (int)Math.min((long)(fArray[(n >>> 1) % 400] * (float)(n - n2)), (long)(25240 - (n + n)));
        Test.vMeth1();
        for (int n7 : iArrFld) {
            boolean bl = false;
            if (bl) break;
            for (n3 = 1; 4 > n3; ++n3) {
                f += (float)n2;
                for (n5 = 1; n5 < 2; ++n5) {
                    instanceCount = -20L;
                    f *= (float)n6;
                    lArray[n3] = n3;
                    n += (int)(instanceCount <<= n5);
                    iArrFld = FuzzerUtils.int1array(400, 30646);
                    n4 += n2;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + Float.floatToIntBits(f) + n5 + n6) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + FuzzerUtils.checkSum(lArray);
    }

    public static float fMeth(long l) {
        int n = -30273;
        int n2 = 104;
        int n3 = 10;
        int n4 = -7;
        int n5 = -214;
        int n6 = -28916;
        int n7 = -79;
        int n8 = 1;
        int n9 = -127;
        boolean bl = false;
        double d = 94.20718;
        for (n = 6; n < 317; ++n) {
            Test.vMeth(n);
            for (n3 = n; n3 < 5; n3 += 3) {
                try {
                    n4 = n2 % 1297331538;
                    Test.iArrFld[n + 1] = n5 % 704792885;
                    n5 = -64980 / iArrFld[n - 1];
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                n5 |= sFld;
                n5 -= n9;
                block14: for (n6 = n; n6 < 1; ++n6) {
                    switch (128) {
                        case 115: {
                            n5 = n6;
                            n7 >>>= (int)l;
                            l &= 0x55F5L;
                        }
                        case 152: {
                            Test.lArrFld[n + 1][n3 - 1] = n8;
                            n8 <<= n;
                            l = n6;
                            continue block14;
                        }
                        case 136: {
                            n2 -= (int)instanceCount;
                            continue block14;
                        }
                        case 126: {
                            n4 = 1359880625;
                        }
                        case 150: {
                            bl = false;
                            continue block14;
                        }
                        case 117: {
                            Test.iArrFld[n] = n7;
                            continue block14;
                        }
                        case 137: {
                            instanceCount += (long)(142 + n6 * n6);
                            continue block14;
                        }
                        case 148: {
                            d -= d;
                            continue block14;
                        }
                        default: {
                            l = (long)d;
                        }
                    }
                }
            }
        }
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n9 + (long)n6 + (long)n7 + (long)n8 + (long)(bl ? 1 : 0) + Double.doubleToLongBits(d);
        fMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 65203;
        int n2 = -133;
        int n3 = -161;
        int n4 = -9;
        int n5 = -3;
        int n6 = 192;
        float f = 12.179f;
        int n7 = n;
        n *= n;
        n = n7 + (int)((long)(-n) + ((long)n + (long)n * instanceCount));
        n = (int)instanceCount--;
        for (n2 = 123; n2 > 6; --n2) {
            this.byFld = (byte)(this.byFld << (byte)(++instanceCount));
            n3 *= (int)Test.fMeth(instanceCount);
            instanceCount = n3;
            instanceCount *= (long)n;
            for (n4 = 5; 214 > n4; ++n4) {
                sFld = (short)(sFld >> sFld);
                n6 = 1;
                block5: do {
                    instanceCount += (long)(n6 * this.byFld + n2 - n);
                    this.bFld = this.bFld;
                    instanceCount |= 0xA9E6L;
                    n3 += n6 | n;
                    this.fArrFld[n6 - 1] = n4;
                    this.byFld = (byte)(this.byFld + (byte)((float)n6 * (f += (float)n6)));
                    switch ((n4 >>> 1) % 1 + 12) {
                        case 12: {
                            if (this.bFld) continue block5;
                            instanceCount = 69L;
                            n3 -= n2;
                            n += n6;
                        }
                        default: {
                            if (this.bFld) {
                                Test.lArrFld[n6 - 1][n4] = ++instanceCount;
                                n <<= n6;
                            } else {
                                n <<= 212;
                            }
                            n -= 1112228430;
                        }
                    }
                } while ((n6 += 2) < 2);
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 i22 i23 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f2 = " + Float.floatToIntBits(f));
        FuzzerUtils.out.println("Test.instanceCount byFld Test.sFld = " + instanceCount + "," + this.byFld + "," + sFld);
        FuzzerUtils.out.println("bFld Test.iArrFld Test.byArrFld = " + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("Test.lArrFld fArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -33534);
        FuzzerUtils.init(byArrFld, (byte)-3);
        FuzzerUtils.init(lArrFld, -54089L);
        fMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
    }
}

