/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -27L;
    public int iFld = -244;
    public static float fFld = 88.972f;
    public static boolean bFld = false;
    public short sFld = (short)32045;
    public static byte[] byArrFld = new byte[400];
    public static long fMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth() {
        int n = 161;
        int n2 = -36882;
        int n3 = -32838;
        int n4 = -168;
        int n5 = 6;
        int n6 = 27239;
        int[] nArray = new int[400];
        int n7 = -24569;
        int n8 = 27002;
        double d = 2.99229;
        boolean bl = false;
        long l = 0L;
        FuzzerUtils.init(nArray, -55);
        nArray[(n >>> 1) % 400] = n;
        for (n2 = 4; n2 < 129; n2 += 3) {
            fFld *= 10.0f;
            for (n4 = 37; n4 > 2; --n4) {
                n6 = 1;
                do {
                    n7 = (short)(n7 + 24015);
                    if (!bl) continue;
                    d += (double)instanceCount;
                } while (++n6 < 2);
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + l + (long)n8 + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth(long l, int n) {
        int n2 = -9966;
        int n3 = 21628;
        int[] nArray = new int[400];
        double d = -2.4667;
        double[][] dArray = new double[400][400];
        FuzzerUtils.init(nArray, 196);
        FuzzerUtils.init(dArray, -8.9381);
        Test.vMeth();
        for (n2 = 1; 327 > n2; n2 += 3) {
            nArray[n2 + 1] = (int)fFld;
            double[] dArray2 = dArray[n2 - 1];
            int n4 = n2;
            dArray2[n4] = dArray2[n4] + 27891.0;
            n3 = n;
            n %= (int)((long)fFld | 1L);
            n += (int)d;
            d = 17596.0;
            fFld += (float)n2;
            instanceCount += l;
        }
        int n5 = (n3 >>> 1) % 400;
        nArray[n5] = nArray[n5] ^ 0x876C;
        n = -61;
        long l2 = l + (long)n + (long)n2 + (long)n3 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray));
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static float fMeth(long l) {
        int n = 174;
        int n2 = -178;
        int n3 = -14;
        int[] nArray = new int[400];
        float f = -1.278f;
        float f2 = -5.484f;
        int n4 = 3940;
        FuzzerUtils.init(nArray, 40504);
        int n5 = (n >>> 1) % 400;
        nArray[n5] = nArray[n5] >> (int)((float)(n - Math.min(n, 13)) - ((float)((long)n + instanceCount) + ((float)n - f)));
        f += (float)(--l);
        n2 = 1;
        while (++n2 < 227) {
            l <<= (int)(instanceCount-- + (long)(n - n2 - n2 * n2));
            n = (int)(--instanceCount);
            Test.iMeth(instanceCount, n);
            n %= n4 | 1;
            n += n2 * n2;
        }
        instanceCount = 1L;
        for (f2 = 3.0f; f2 < 208.0f; f2 += 1.0f) {
            n3 += (int)l;
            n3 *= n3;
            n3 = (int)instanceCount;
        }
        n = n2;
        long l2 = l + (long)n + (long)Float.floatToIntBits(f) + (long)n2 + (long)n4 + (long)Float.floatToIntBits(f2) + (long)(n3 -= n2) + FuzzerUtils.checkSum(nArray);
        fMeth_check_sum += l2;
        return l2;
    }

    public void mainTest(String[] stringArray) {
        int n = 10035;
        int n2 = 64808;
        int n3 = 12;
        int n4 = -221;
        int n5 = 11;
        int n6 = -11;
        int[] nArray = new int[400];
        double d = 0.51427;
        long[] lArray = new long[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(lArray, -1L);
        FuzzerUtils.init(fArray, -90.698f);
        FuzzerUtils.init(nArray, -10);
        lArray[74] = lArray[74] * (long)((float)((long)Math.abs(this.iFld) + Math.min(instanceCount, -1279146865349914639L)) - (float)(this.iFld + 140) * Test.fMeth(instanceCount));
        for (n = 13; 304 > n; ++n) {
            for (d = 86.0; d > 3.0; d -= 1.0) {
                n4 = 2;
                while ((double)n4 > d) {
                    n2 = n5;
                    block0 : switch ((int)(d % 10.0 + 42.0)) {
                        case 42: {
                            int n7 = n4 - 1;
                            fArray[n7] = fArray[n7] - -1.12304f;
                            Test.byArrFld[(int)(d + 1.0)] = (byte)n;
                            break;
                        }
                        case 43: {
                            instanceCount -= instanceCount;
                            if (!bFld) break;
                            break;
                        }
                        case 44: {
                            instanceCount <<= n4;
                        }
                        case 45: {
                            n2 = n;
                            break;
                        }
                        case 46: {
                            switch (n % 2 * 5 + 89) {
                                case 99: {
                                    n6 -= 16890;
                                    n3 = n2;
                                    n2 = -14;
                                    n5 -= (int)fFld;
                                    break block0;
                                }
                                case 92: {
                                    lArray[n4 + 1] = n;
                                    n5 -= n3;
                                    nArray[n + 1] = 13;
                                    this.iFld = this.iFld;
                                    break block0;
                                }
                            }
                            int n8 = n + 1;
                            nArray[n8] = nArray[n8] + n3;
                            n3 = (int)instanceCount;
                            instanceCount = -10L;
                            if (!bFld) break;
                            instanceCount -= instanceCount;
                            int n9 = n;
                            nArray[n9] = nArray[n9] * (int)fFld;
                            n5 = (int)(instanceCount %= (long)(n | 1));
                            break;
                        }
                        case 47: {
                            instanceCount += (long)n4 * instanceCount + (long)n3 - (long)n4;
                            break;
                        }
                        case 48: {
                            fFld += (float)n5;
                            break;
                        }
                        case 49: 
                        case 50: {
                            n2 -= (int)fFld;
                            break;
                        }
                        case 51: {
                            this.iFld = this.sFld;
                            break;
                        }
                        default: {
                            n2 *= this.sFld;
                        }
                    }
                    --n4;
                }
            }
        }
        FuzzerUtils.out.println("i14 i15 d2 = " + n + "," + n2 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i16 i17 i18 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i19 lArr fArr = " + n6 + "," + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld sFld Test.byArrFld = " + (bFld ? 1 : 0) + "," + this.sFld + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(byArrFld, (byte)20);
        fMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

