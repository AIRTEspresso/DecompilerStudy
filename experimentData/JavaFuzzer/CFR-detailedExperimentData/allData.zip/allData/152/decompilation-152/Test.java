/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 9L;
    public volatile float fFld = 0.82f;
    public static double dFld = 30.32936;
    public static float fFld1 = -9.21f;
    public static int[] iArrFld = new int[400];
    public static long[] lArrFld = new long[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(boolean bl, int n, float f) {
        int n2 = 2;
        int n3 = -94;
        int n4 = 5;
        int n5 = 22656;
        int n6 = 60951;
        int n7 = 3;
        int[] nArray = new int[400];
        int n8 = 7257;
        float f2 = 1.108f;
        FuzzerUtils.init(nArray, 4);
        if (bl) {
            if (bl) {
                for (n2 = 6; n2 < 204; ++n2) {
                    n += n2;
                    n4 = 1;
                    while ((n4 += 2) < 8) {
                        n = (int)((long)n + ((long)n4 ^ instanceCount));
                        n += n4 * n4;
                        dFld = n8;
                    }
                    for (n5 = 1; 8 > n5; ++n5) {
                        for (f2 = 1.0f; f2 < 2.0f; f2 += 1.0f) {
                            dFld += -40264.0;
                            f += f2 * (float)n + (float)n - (float)instanceCount;
                            int n9 = (n6 >>> 1) % 400;
                            nArray[n9] = nArray[n9] - n4;
                            f = n4;
                        }
                    }
                }
                vMeth_check_sum += (long)((bl ? 1 : 0) + n + Float.floatToIntBits(f) + n2 + n3 + n4 + n8 + n5 + n6 + Float.floatToIntBits(f2) + n7) + FuzzerUtils.checkSum(nArray);
                return;
            }
            if (bl) {
                n7 = n6;
            } else if (bl) {
                f = n;
            } else {
                instanceCount = n3;
            }
        } else {
            n *= (int)f;
        }
        vMeth_check_sum += (long)((bl ? 1 : 0) + n + Float.floatToIntBits(f) + n2 + n3 + n4 + n8 + n5 + n6 + Float.floatToIntBits(f2) + n7) + FuzzerUtils.checkSum(nArray);
    }

    public static int iMeth1(int n, int n2, int n3) {
        boolean bl = false;
        int n4 = 55277;
        int n5 = -4;
        int n6 = -3;
        int n7 = -9;
        int n8 = 7;
        int n9 = -149;
        int n10 = -14409;
        long l = 1598912768L;
        Test.vMeth(bl, n, fFld1);
        instanceCount = 153L;
        for (n4 = 8; 143 > n4; ++n4) {
            n5 -= n4;
            for (n6 = 1; n6 < 12; ++n6) {
                n3 += (int)instanceCount;
            }
            n8 = 1;
            while (++n8 < 12) {
                instanceCount = n6;
                for (n9 = 1; n9 < 1; ++n9) {
                    int n11 = 9313;
                    n10 <<= (int)instanceCount;
                    n2 += n11;
                    n2 <<= n6;
                    Test.iArrFld[n8 + 1] = (int)instanceCount;
                    n3 = (int)((long)n3 + ((long)n9 * instanceCount + instanceCount - l));
                }
                Test.iArrFld[n8] = n7;
            }
        }
        long l2 = (long)(n + n2 + n3 + (bl ? 1 : 0) + n4 + n5 + n6 + n7 + n8 + n9 + n10) + l;
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    /*
     * Unable to fully structure code
     */
    public int iMeth(long var1_1, int var3_2) {
        var4_3 = 223;
        var5_4 = new int[400];
        var6_5 = -23804;
        FuzzerUtils.init(var5_4, -8);
        var4_3 = 1;
        do {
            var3_2 = var3_2-- - Integer.reverseBytes(var3_2);
            switch (var4_3 % 6 + 115) {
                case 115: {
                    if (var3_2 != 0) {
                        // empty if block
                    }
                    v0 = var5_4;
                    var5_4 = v0;
                    var5_4 = v0;
                    var5_4 = v0;
                    var3_2 *= Test.iMeth1(-195, var4_3, var4_3) - -208;
                }
                ** case 116:
lbl18:
                // 2 sources

                case 117: {
                    Test.fFld1 = -3.0f;
                    switch ((var4_3 >>> 1) % 1 + 111) {
                        case 111: {
                            Test.dFld -= -22231.0;
                            Test.iArrFld[var4_3 + 1] = (int)Test.instanceCount;
                            var1_1 += (long)(6 + var4_3 * var4_3);
                        }
                    }
                    this.fFld = 99.0f;
                    var3_2 <<= var6_5;
                    break;
                }
                case 118: {
                    this.fFld += (float)(var4_3 * var4_3 + var4_3 - var3_2);
                    break;
                }
                case 119: {
                    this.fFld = Test.instanceCount;
                    break;
                }
                default: {
                    Test.instanceCount = var3_2;
                }
            }
        } while (++var4_3 < 303);
        var7_6 = var1_1 + (long)var3_2 + (long)var4_3 + (long)var6_5 + FuzzerUtils.checkSum(var5_4);
        Test.iMeth_check_sum += var7_6;
        return (int)var7_6;
    }

    public void mainTest(String[] stringArray) {
        int n = -5;
        int n2 = -40545;
        int n3 = -7;
        int n4 = 0;
        int n5 = -7430;
        int n6 = 19375;
        int n7 = 83;
        int n8 = 58164;
        int n9 = -22017;
        int n10 = -15580;
        short[] sArray = new short[400];
        double d = 97.15975;
        boolean bl = false;
        float[] fArray = new float[400];
        FuzzerUtils.init(sArray, (short)-28031);
        FuzzerUtils.init(fArray, -2.988f);
        for (n = 12; n < 194; ++n) {
            n2 = (int)((float)n - this.fFld);
            for (n3 = 5; 138 > n3; ++n3) {
                this.fFld *= (float)this.iMeth(instanceCount, n4);
                n2 = (int)((float)n2 + ((float)n3 * fFld1 + (float)n3 - (float)n3));
                n10 = (short)(n10 % -10);
                n2 >>= n4;
            }
            n2 += n;
            n2 = n3;
        }
        Test.iArrFld[(n4 >>> 1) % 400] = (int)instanceCount;
        int n11 = (n2 >>> 1) % 400;
        lArrFld[n11] = lArrFld[n11] - (long)n3;
        Test.iArrFld[(n3 >>> 1) % 400] = n2 = -61103;
        n2 |= (int)instanceCount;
        for (n5 = 17; n5 < 293; ++n5) {
            n7 = 1;
            do {
                n2 += (int)(4529079815672162736L + (long)(n7 * n7));
            } while (++n7 < 91);
            block11: for (d = 1.0; d < 91.0; d += 1.0) {
                this.fFld += (float)n2;
                sArray[n5 + 1] = (short)n7;
                n6 += 2;
                n4 += (int)d;
                switch (n5 % 6 * 5 + 126) {
                    case 145: {
                        n9 <<= n5;
                        int n12 = (int)d;
                        fArray[n12] = fArray[n12] + fFld1;
                        instanceCount += (long)d;
                        continue block11;
                    }
                    case 134: {
                        int n13 = n5;
                        iArrFld[n13] = iArrFld[n13] + -52042;
                        continue block11;
                    }
                    case 137: {
                        n6 <<= n;
                        n8 = (int)dFld;
                    }
                    case 154: {
                        int n14 = n5 + 1;
                        iArrFld[n14] = iArrFld[n14] * n2;
                        continue block11;
                    }
                    case 144: {
                        fFld1 -= (float)n8;
                        continue block11;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 s3 i23 = " + n4 + "," + n10 + "," + n5);
        FuzzerUtils.out.println("i24 i25 d = " + n6 + "," + n7 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i26 b2 i27 = " + n8 + "," + (bl ? 1 : 0) + "," + n9);
        FuzzerUtils.out.println("sArr fArr = " + FuzzerUtils.checkSum(sArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)));
        FuzzerUtils.out.println("Test.instanceCount fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fFld1 Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(fFld1) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 156);
        FuzzerUtils.init(lArrFld, -10L);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

