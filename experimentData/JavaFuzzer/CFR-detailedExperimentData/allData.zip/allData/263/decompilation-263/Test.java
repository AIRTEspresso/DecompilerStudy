/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 10L;
    public static short sFld = (short)27623;
    public static int iFld = -6;
    public static float fFld = 0.206f;
    public static boolean bFld = false;
    public volatile double dFld = -88.12107;
    public static long sMeth_check_sum = 0L;
    public static long vMeth_check_sum = 0L;
    public static long vMeth1_check_sum = 0L;

    public static void vMeth1(byte by) {
        float f = 0.63f;
        int n = -208;
        int n2 = -11425;
        double d = -1.83869;
        int n3 = 29561;
        f = instanceCount;
        instanceCount >>= n;
        n *= n;
        n *= n;
        n += (int)instanceCount;
        n2 = 1;
        do {
            instanceCount &= (long)n;
            try {
                n %= 123;
                n %= n;
                n = n2 / n;
            }
            catch (ArithmeticException arithmeticException) {
                // empty catch block
            }
            n = (int)((long)n + (long)n2 * instanceCount);
            f /= (float)((long)d | 1L);
            n += n2;
            f -= (float)n2;
            n *= (int)instanceCount;
        } while (++n2 < 312);
        d *= (double)n;
        vMeth1_check_sum += (long)(by + Float.floatToIntBits(f) + (n *= n3) + n2) + Double.doubleToLongBits(d) + (long)n3;
    }

    public static void vMeth(int n) {
        byte by = 84;
        int n2 = 64823;
        int n3 = -3;
        int n4 = 22;
        int n5 = 2549;
        int n6 = -12498;
        int n7 = -240;
        int[] nArray = new int[400];
        float f = 0.33f;
        FuzzerUtils.init(nArray, 30);
        Test.vMeth1(by);
        n -= 1122984600;
        n >>= n;
        for (n2 = 6; n2 < 238; ++n2) {
            for (n4 = 1; n4 < 7; ++n4) {
                block11: for (n6 = 1; n6 < 2; ++n6) {
                    nArray[n2 - 1] = (int)instanceCount;
                    switch (n6 % 7 + 52) {
                        case 52: {
                            n = n4;
                            n3 += 44629;
                            n3 -= 218;
                            instanceCount -= (long)sFld;
                        }
                        case 53: {
                            by = (byte)(by >> (byte)n6);
                        }
                        case 54: {
                            n7 -= 17;
                            continue block11;
                        }
                        case 55: {
                            instanceCount -= (long)n4;
                        }
                        case 56: {
                            n7 -= 40;
                            continue block11;
                        }
                        case 57: {
                            int n8 = n4 - 1;
                            nArray[n8] = nArray[n8] - n;
                            continue block11;
                        }
                        case 58: {
                            n7 -= iFld;
                            continue block11;
                        }
                        default: {
                            n = (int)f;
                        }
                    }
                }
            }
        }
        vMeth_check_sum += (long)(n + by + n2 + n3 + n4 + n5 + n6 + n7 + Float.floatToIntBits(f)) + FuzzerUtils.checkSum(nArray);
    }

    public static short sMeth(int n, float f) {
        int n2 = 13;
        int n3 = -99;
        int n4 = 26352;
        int n5 = 75;
        int n6 = 12;
        int n7 = 38331;
        int[] nArray = new int[400];
        byte[] byArray = new byte[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(byArray, (byte)81);
        FuzzerUtils.init(lArray, -24573L);
        FuzzerUtils.init(nArray, 45118);
        n2 = 1;
        while (++n2 < 363) {
            Test.vMeth(58519);
            for (n3 = n2; n3 < 5; n3 += 2) {
                int n8 = n2 - 1;
                byArray[n8] = (byte)(byArray[n8] * (byte)instanceCount);
                iFld += n3;
                f += -7.0f;
            }
            n5 = 5;
            do {
                int n9 = (n5 >>> 1) % 400;
                lArray[n9] = lArray[n9] * (long)n3;
                n = n4;
                fFld = instanceCount;
                for (n6 = n2; n6 < 1; ++n6) {
                    int n10 = n2;
                    nArray[n10] = nArray[n10] + n;
                }
                instanceCount += (long)(n5 * n5 + sFld - n2);
                bFld = false;
                n7 <<= -34271;
            } while (--n5 > 0);
        }
        long l = (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(byArray) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(nArray);
        sMeth_check_sum += l;
        return (short)l;
    }

    /*
     * Unable to fully structure code
     */
    public void mainTest(String[] var1_1) {
        var2_2 = -10;
        var3_3 = 53245;
        var4_4 = -47405;
        var5_5 = -17813;
        var6_6 = -23;
        var7_7 = 19137;
        var8_8 = new int[400];
        var9_9 = 2.6389;
        var11_10 = 9315;
        var12_11 = 2064041513L;
        var14_12 = new long[400];
        var15_13 = 118;
        var16_14 = new byte[400];
        FuzzerUtils.init(var8_8, -6);
        FuzzerUtils.init(var14_12, -205393022L);
        FuzzerUtils.init(var16_14, (byte)24);
        Test.sMeth(Test.iFld, Test.fFld);
        var2_2 = 1;
        block29: do {
            switch (var2_2 % 7 * 5 + 70) {
                case 76: {
                    v0 = var2_2 + 1;
                    var8_8[v0] = var8_8[v0] * (int)Test.instanceCount;
                }
                case 75: {
                    for (var9_9 = 187.0; var9_9 > (double)var2_2; var9_9 -= 1.0) {
                        var3_3 = -363545526;
                    }
                    block31: for (var4_4 = 187; var4_4 > 1; var4_4 -= 3) {
                        switch ((var2_2 >>> 1) % 9 + 57) {
                            case 57: {
                                var5_5 |= var2_2;
                                var5_5 -= var3_3;
                                continue block31;
                            }
                            case 58: {
                                var3_3 = (int)((long)var3_3 + ((long)(var4_4 * Test.iFld + var2_2) - Test.instanceCount));
                                Test.fFld *= 23787.0f;
                                var3_3 = var2_2;
                                continue block31;
                            }
                            case 59: {
                                switch ((var2_2 >>> 1) % 5 + 68) {
                                    case 68: {
                                        var3_3 += var4_4 * var11_10 + var2_2 - var4_4;
                                        for (var12_11 = 1L; var12_11 < 4L; ++var12_11) {
                                            v1 = (int)var12_11;
                                            var14_12[v1] = var14_12[v1] + (long)var2_2;
                                        }
                                        break;
                                    }
                                    case 69: {
                                        var3_3 += 134;
                                        try {
                                            var6_6 = var3_3 / -39367;
                                            var5_5 = var8_8[var4_4 - 1] % 208;
                                            var8_8[var4_4] = 62027 % var5_5;
                                        }
                                        catch (ArithmeticException var17_15) {}
                                        break;
                                    }
                                    case 70: {
                                        var7_7 = 1;
                                        while (++var7_7 < 4 && !Test.bFld) {
                                            Test.instanceCount = (long)((float)Test.instanceCount + (float)var7_7 * Test.fFld);
                                            if (Test.bFld) continue;
                                            var3_3 += var7_7 * Test.sFld + var3_3 - var3_3;
                                            var8_8[var7_7 - 1] = var6_6;
                                            var6_6 += var7_7 * var15_13 + Test.iFld - var7_7;
                                            var16_14[var7_7 + 1] = (byte)var5_5;
                                            var8_8[var2_2 + 1] = Test.iFld;
                                            this.dFld += (double)(Test.instanceCount += 4972554890482288877L);
                                        }
                                    }
                                    case 71: {
                                        Test.instanceCount *= (long)var3_3;
                                        break;
                                    }
                                    case 72: {
                                        var6_6 += var4_4 - Test.iFld;
                                    }
                                }
                                continue block31;
                            }
                            case 60: {
                                Test.instanceCount &= Test.instanceCount;
                                continue block31;
                            }
                            case 61: {
                                v2 = var2_2 - 1;
                                var14_12[v2] = var14_12[v2] << var6_6;
                                continue block31;
                            }
                            ** case 62:
lbl85:
                            // 2 sources

                            case 63: {
                                v3 = var4_4 - 1;
                                var8_8[v3] = var8_8[v3] + Test.iFld;
                                continue block31;
                            }
                            case 64: {
                                var3_3 -= (int)var9_9;
                                continue block31;
                            }
                            case 65: {
                                v4 = var4_4;
                                var8_8[v4] = var8_8[v4] * (int)Test.fFld;
                                continue block31;
                            }
                            default: {
                                Test.instanceCount += (long)var6_6;
                            }
                        }
                    }
                    continue block29;
                }
                case 94: {
                    Test.instanceCount *= -49563L;
                }
                case 96: {
                    var3_3 += var2_2;
                    break;
                }
                case 71: {
                    break;
                }
                case 103: {
                    this.dFld = var12_11;
                    break;
                }
                case 99: {
                    this.dFld = Test.fFld;
                }
            }
        } while (++var2_2 < 134);
        FuzzerUtils.out.println("i16 d1 i17 = " + var2_2 + "," + Double.doubleToLongBits(var9_9) + "," + var3_3);
        FuzzerUtils.out.println("i18 i19 s1 = " + var4_4 + "," + var5_5 + "," + var11_10);
        FuzzerUtils.out.println("l i20 i21 = " + var12_11 + "," + var6_6 + "," + var7_7);
        FuzzerUtils.out.println("by2 iArr2 lArr1 = " + var15_13 + "," + FuzzerUtils.checkSum(var8_8) + "," + FuzzerUtils.checkSum(var14_12));
        FuzzerUtils.out.println("byArr1 = " + FuzzerUtils.checkSum(var16_14));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.iFld = " + Test.instanceCount + "," + Test.sFld + "," + Test.iFld);
        FuzzerUtils.out.println("Test.fFld Test.bFld dFld = " + Float.floatToIntBits(Test.fFld) + "," + (Test.bFld != false ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + Test.vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + Test.vMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + Test.sMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

