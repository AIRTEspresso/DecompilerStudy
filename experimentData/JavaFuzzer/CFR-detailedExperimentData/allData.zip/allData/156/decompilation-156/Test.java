/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 58788L;
    public static int iFld = 23969;
    public double dFld = -1.11906;
    public static long[] lArrFld = new long[400];
    public static long lMeth_check_sum;
    public static long fMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(double d, int n) {
        int n2 = 11;
        int n3 = -149;
        int n4 = -247;
        int n5 = 11;
        int n6 = 38;
        int[][] nArray = new int[400][400];
        double d2 = 120.41676;
        FuzzerUtils.init(nArray, 40743);
        for (n2 = 203; n2 > 1; --n2) {
            int n7 = n2 - 1;
            lArrFld[n7] = lArrFld[n7] / 2379255939094521235L;
            nArray[n2][n2 + 1] = (int)instanceCount;
        }
        for (d2 = 3.0; 229.0 > d2; d2 += 1.0) {
            nArray[(int)(d2 - 1.0)] = nArray[(int)d2];
            n3 += (int)instanceCount;
            for (n5 = 1; n5 < 7; ++n5) {
                n4 <<= 14;
                n6 += n6;
            }
            instanceCount -= -13L;
            n3 -= 112;
            n3 -= (int)d;
            instanceCount <<= (n6 *= n4);
            n3 = n6;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3 + Double.doubleToLongBits(d2) + (long)n4 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public static float fMeth(float f, int n, int n2) {
        int n3 = 75;
        int n4 = 48908;
        int n5 = -122;
        int[] nArray = new int[400];
        long l = 0L;
        FuzzerUtils.init(nArray, -14);
        f = --n2;
        f += (float)(++n2);
        n3 = 292;
        do {
            Test.vMeth(-1.128013, 52466);
            n >>= n2;
            instanceCount |= instanceCount;
        } while ((n3 -= 2) > 0);
        for (int n6 : nArray) {
            for (n4 = 4; n4 > 1; n4 -= 3) {
                n2 += n4;
                l = 1L;
                while (++l < 4L) {
                    n2 -= (int)l;
                }
                n2 += 12;
                instanceCount = l;
                n6 = n5;
                int n7 = n4;
                lArrFld[n7] = lArrFld[n7] + l;
            }
        }
        long l2 = (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5) + l + FuzzerUtils.checkSum(nArray);
        fMeth_check_sum += l2;
        return l2;
    }

    public long lMeth(boolean bl, long l, byte by) {
        int n = -13;
        int n2 = 44914;
        int n3 = -5;
        int n4 = -2;
        int[] nArray = new int[400];
        double d = -11.55899;
        double d2 = -48.1605;
        long l2 = 164L;
        float f = -42.821f;
        FuzzerUtils.init(nArray, -133);
        n = 305;
        while ((n -= 3) > 0) {
            if (bl == bl) continue;
            for (d = 1.0; d < 15.0; d += 1.0) {
                d2 -= (double)Integer.reverseBytes((int)((l2 *= (long)n2) * 42406L));
                n2 = (int)(-((float)(n2 - n2) * ((float)n2 - f)));
                instanceCount += (long)(d * (double)l + (double)n2 - (double)f);
                n2 = (int)(-((long)(n2 - 21103) | instanceCount));
                int n5 = (int)d;
                nArray[n5] = nArray[n5] + (int)(f + (float)(n2 + (n2 - n)));
                for (n3 = 2; 1 < n3; n3 -= 2) {
                    int n6 = n;
                    long l3 = lArrFld[n6] - 1L;
                    lArrFld[n6] = l3;
                    n4 *= (int)l3;
                    try {
                        n4 /= n2;
                        n4 = n / 211;
                        n2 = n3 % n2;
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    switch (n % 1 * 5 + 98) {
                        case 101: {
                            d2 = lArrFld[(int)(d - 1.0)];
                            boolean bl2 = bl || bl;
                            bl = bl2;
                            bl = bl2;
                            bl = bl2;
                        }
                    }
                }
                n4 = (int)Test.fMeth(-25.313f, n2, n);
            }
        }
        long l4 = (long)(bl ? 1 : 0) + l + (long)by + (long)n + Double.doubleToLongBits(d) + (long)n2 + Double.doubleToLongBits(d2) + l2 + (long)Float.floatToIntBits(f) + (long)n3 + (long)n4 + FuzzerUtils.checkSum(nArray);
        lMeth_check_sum += l4;
        return l4;
    }

    public void mainTest(String[] stringArray) {
        int n = -14;
        int n2 = -34935;
        int n3 = -3304;
        int n4 = -1;
        int n5 = -122;
        int n6 = -58655;
        int n7 = 178;
        int n8 = 6;
        int n9 = 6;
        int n10 = 3;
        int[] nArray = new int[400];
        int n11 = -29242;
        int n12 = 87;
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, -209);
        FuzzerUtils.init(dArray, 1.48625);
        nArray[(n >>> 1) % 400] = (int)((float)this.lMeth(false, -96L, (byte)38) + 1.584f);
        int n13 = (n >>> 1) % 400;
        nArray[n13] = nArray[n13] + 9880;
        for (n2 = 17; n2 < 318; ++n2) {
            for (n4 = 1; n4 < 84; ++n4) {
                for (n6 = 2; n6 > 1; --n6) {
                    int n14 = n2 - 1;
                    dArray[n14] = dArray[n14] - (double)n7;
                }
                n8 = 1;
                do {
                    n = n7;
                    n11 = (short)instanceCount;
                    n7 -= 60002;
                    n7 -= n4;
                    n = n3;
                    n7 = n3;
                    instanceCount = n4;
                    n = (int)instanceCount;
                    n7 += n8;
                    n5 += n8;
                } while (++n8 < 2);
                nArray[n2] = n5;
                n >>>= iFld;
                n3 += n4 * n4;
                iFld *= (int)this.dFld;
                instanceCount = n5;
                for (n9 = n4; n9 < 2; ++n9) {
                    this.dFld = 53.0;
                    n5 = n10;
                    iFld *= n;
                    iFld += n9 * n9;
                    instanceCount = n12;
                }
            }
        }
        FuzzerUtils.out.println("i i17 i18 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i19 i20 i21 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i22 i23 s = " + n7 + "," + n8 + "," + n11);
        FuzzerUtils.out.println("i24 i25 by1 = " + n9 + "," + n10 + "," + n12);
        FuzzerUtils.out.println("iArr dArr = " + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, -173L);
        lMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

