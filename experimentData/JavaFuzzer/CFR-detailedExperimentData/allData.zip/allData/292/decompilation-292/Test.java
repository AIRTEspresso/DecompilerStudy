/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -216L;
    public static byte byFld = (byte)-69;
    public static float fFld = -25.276f;
    public volatile int iFld = -64572;
    public short sFld = (short)-5698;
    public double dFld = -1.119064;
    public static volatile byte byFld1 = (byte)-86;
    public static long[] lArrFld = new long[400];
    public static byte[] byArrFld = new byte[400];
    public static int[] iArrFld = new int[400];
    public short[] sArrFld = new short[400];
    public static long vSmallMeth_check_sum;
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(long l) {
        double d = 0.5759;
        int n = 187;
        int n2 = -10803;
        int n3 = 2;
        d += (double)n;
        for (n2 = 4; n2 < 268; ++n2) {
            byFld = (byte)(byFld << -64);
        }
        l = -14L;
        vMeth_check_sum += l + Double.doubleToLongBits(d) + (long)n + (long)n2 + (long)n3;
    }

    public static int iMeth(long l, int n) {
        boolean bl = true;
        int n2 = 177;
        int n3 = -16427;
        int n4 = 23124;
        int n5 = -10;
        int n6 = -14;
        int n7 = 13;
        int[] nArray = new int[400];
        int n8 = 8136;
        FuzzerUtils.init(nArray, 6161);
        Test.vMeth(instanceCount);
        bl = false;
        for (n2 = 3; n2 < 374; ++n2) {
            n -= n3;
            for (n4 = 1; n4 < 5; ++n4) {
                n8 = (short)n;
            }
            if (bl) {
                n6 = 5;
                while (--n6 > 0) {
                    l = n5;
                    l += (long)(n6 * n2 + n7 - n);
                    l = n6;
                    n3 = n5;
                    int n9 = n2 - 1;
                    nArray[n9] = nArray[n9] * n2;
                }
                continue;
            }
            instanceCount = -13L;
            n3 = (int)((long)n3 + (long)n2 * instanceCount);
        }
        long l2 = l + (long)n + (long)(bl ? 1 : 0) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + (long)n8 + (long)n6 + (long)n7 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vSmallMeth(long l, int n) {
        n = n-- + Test.iMeth(l, n);
        fFld -= -50.58f;
        vSmallMeth_check_sum += l + (long)n;
    }

    /*
     * Unable to fully structure code
     */
    public void mainTest(String[] var1_1) {
        var2_2 = -44780;
        var3_3 = -175;
        var4_4 = -116;
        var5_5 = -3485;
        var6_6 = -3;
        var7_7 = 196;
        var8_8 = 12;
        var9_9 = false;
        for (var10_10 = 0; var10_10 < 790; ++var10_10) {
            Test.vSmallMeth(Test.instanceCount, this.iFld);
        }
        var2_2 = 216;
        while ((var2_2 -= 2) > 0) {
            this.sFld = (short)(this.sFld + (short)var2_2);
        }
        Test.instanceCount *= Test.instanceCount;
        this.iFld <<= (int)Test.instanceCount;
        for (var3_3 = 16; 391 > var3_3; ++var3_3) {
            Test.fFld = this.iFld;
            if (var9_9) {
                var4_4 = (int)((float)var4_4 + ((float)(var3_3 * var2_2 + var4_4) - Test.fFld));
                block19: for (var5_5 = 67; 3 < var5_5; --var5_5) {
                    Test.byFld = (byte)(Test.byFld + (byte)var5_5);
                    v0 = var5_5 + 1;
                    Test.lArrFld[v0] = Test.lArrFld[v0] | (long)var2_2;
                    var4_4 += var5_5 * var2_2 + var6_6 - var3_3;
                    switch (var3_3 % 8 + 80) {
                        case 80: {
                            Test.fFld += (float)var5_5;
                            v1 = var3_3 - 1;
                            Test.byArrFld[v1] = (byte)(Test.byArrFld[v1] & (byte)var6_6);
                            continue block19;
                        }
                        case 81: {
                            var6_6 = (int)this.dFld;
                            block20: for (var7_7 = 1; var7_7 < 2; ++var7_7) {
                                this.sFld = (short)(this.sFld - 0);
                                switch (var5_5 % 1 * 5 + 73) {
                                    case 76: {
                                        Test.iArrFld[var3_3 - 1] = (int)Test.instanceCount;
                                        var6_6 += 229;
                                        var4_4 -= (int)this.dFld;
                                        if (var9_9) {
                                            switch (var7_7 % 2 * 5 + 36) {
                                                case 38: 
                                                case 42: {
                                                    var8_8 = var6_6;
                                                }
                                            }
                                            continue block20;
                                        }
                                        if (var9_9 || !var9_9) continue block20;
                                        this.sFld = (short)(this.sFld + (short)(var7_7 * var3_3 + var2_2 - var3_3));
                                    }
                                }
                            }
                        }
                        case 82: {
                            var8_8 += var5_5;
                            continue block19;
                        }
                        case 83: {
                            var4_4 -= (int)Test.instanceCount;
                            continue block19;
                        }
                        ** case 84:
lbl57:
                        // 2 sources

                        case 85: {
                            this.sFld = (short)(this.sFld - (short)Test.instanceCount);
                            continue block19;
                        }
                        case 86: {
                            var6_6 += var5_5 - var5_5;
                            continue block19;
                        }
                        case 87: {
                            var8_8 = Test.byFld;
                        }
                    }
                }
                continue;
            }
            if (var9_9) {
                var8_8 *= (int)Test.instanceCount;
                continue;
            }
            v2 = var3_3 + 1;
            this.sArrFld[v2] = (short)(this.sArrFld[v2] + 13);
        }
        FuzzerUtils.out.println("i11 i12 i13 = " + var2_2 + "," + var3_3 + "," + var4_4);
        FuzzerUtils.out.println("i14 i15 i16 = " + var5_5 + "," + var6_6 + "," + var7_7);
        FuzzerUtils.out.println("i17 b1 = " + var8_8 + "," + (var9_9 != false ? 1 : 0));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + Test.instanceCount + "," + Test.byFld + "," + Float.floatToIntBits(Test.fFld));
        FuzzerUtils.out.println("iFld sFld dFld = " + this.iFld + "," + this.sFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.byFld1 Test.lArrFld Test.byArrFld = " + Test.byFld1 + "," + FuzzerUtils.checkSum(Test.lArrFld) + "," + FuzzerUtils.checkSum(Test.byArrFld));
        FuzzerUtils.out.println("Test.iArrFld sArrFld = " + FuzzerUtils.checkSum(Test.iArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + Test.vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + Test.iMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + Test.vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(lArrFld, 2439062821416184846L);
        FuzzerUtils.init(byArrFld, (byte)0);
        FuzzerUtils.init(iArrFld, 33527);
        vSmallMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

