/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -11L;
    public static int iFld = -58827;
    public static double dFld = -69.54201;
    public static short sFld = (short)-21332;
    public boolean bFld = false;
    public static int iFld1 = 194;
    public volatile short[] sArrFld = new short[400];
    public static volatile double[] dArrFld = new double[400];
    public static float[] fArrFld = new float[400];
    public static volatile int[] iArrFld = new int[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth() {
        int n = 210;
        float f = -92.635f;
        boolean bl = false;
        boolean[][][] blArray = new boolean[400][400][400];
        int n2 = 123;
        long l = 5L;
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        n = 1;
        while (++n < 201) {
            f = n;
            iFld = n;
            blArray[n - 1][n + 1][n] = bl;
            iFld >>= iFld;
            iFld = n2;
            int n3 = n;
            fArrFld[n3] = fArrFld[n3] + (float)iFld;
            iFld *= (int)dFld;
            dFld = instanceCount;
            int n4 = n + 1;
            fArrFld[n4] = fArrFld[n4] - (float)n;
        }
        l = 1L;
        while (++l < 284L) {
            iFld += (int)(l * instanceCount);
        }
        bl = true;
        long l2 = (long)(n + Float.floatToIntBits(f += 18262.0f) + (bl ? 1 : 0) + n2) + l + FuzzerUtils.checkSum((Object[][])blArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public static void vMeth1(int n) {
        int n2 = 6;
        int n3 = -138;
        float f = 72.392f;
        for (n2 = 328; n2 > 6; --n2) {
            float f2 = 0.974f;
            n <<= (int)((float)(++instanceCount) * f2);
        }
        f -= (float)(n - Test.iMeth() + iFld);
        n = n2;
        dArrFld[388] = dArrFld[388] - -168.0;
        f = -102.0f;
        vMeth1_check_sum += (long)(n + n2 + n3 + Float.floatToIntBits(f));
    }

    public static void vMeth(double d, long l) {
        int n = 93;
        int n2 = -45;
        int n3 = 13;
        float f = -2.29f;
        for (double d2 : dArrFld) {
            Test.vMeth1(62893);
            for (n = 1; 4 > n; ++n) {
                n3 = 2;
                n2 = iFld;
                iFld = 49802;
            }
        }
        int n4 = (n3 >>> 1) % 400;
        iArrFld[n4] = iArrFld[n4] + (int)l;
        iFld -= 48873;
        dFld -= (double)sFld;
        vMeth_check_sum += Double.doubleToLongBits(d) + l + (long)n + (long)n2 + (long)n3 + (long)Float.floatToIntBits(f *= (float)n3);
    }

    public void mainTest(String[] stringArray) {
        float f = 1.517f;
        int n = 8;
        int n2 = 13647;
        int n3 = 150;
        int n4 = -23986;
        int n5 = 198;
        int n6 = 44;
        int n7 = -169;
        int[] nArray = new int[400];
        int n8 = -112;
        long l = -12170L;
        long[] lArray = new long[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(dArray, 73.18599);
        FuzzerUtils.init(nArray, -6);
        FuzzerUtils.init(lArray, -2273727902L);
        f += f - (float)(iFld * iFld + --iFld);
        n = 16;
        while (n < 287) {
            dArray[n] = this.sArrFld[n];
            n2 &= nArray[n];
            int n9 = n++;
            nArray[n9] = nArray[n9] << --n2 - Math.min(iFld, iFld) * ++n2;
        }
        Test.vMeth(-2.70447, instanceCount);
        if (this.bFld) {
            iFld += n8;
        }
        for (n3 = 6; n3 < 205; ++n3) {
            for (n5 = 2; n5 < 126; ++n5) {
                instanceCount = n6;
                Test.iArrFld[n3] = -7;
                iFld = (int)((float)iFld + ((float)n5 * (f += (float)n6) + (float)n3 - (float)n));
                n6 /= 39805;
                f += (float)dFld;
                try {
                    iFld1 = n3 / n2;
                    n4 = 12 / n4;
                    Test.iArrFld[n5] = iArrFld[n5 + 1] % n6;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                sFld = (short)n4;
                for (l = (long)n3; l < 2L; ++l) {
                    int n10 = (int)(l - 1L);
                    nArray[n10] = nArray[n10] | n5;
                    n7 = n;
                    int n11 = n3;
                    iArrFld[n11] = iArrFld[n11] ^ n2;
                    n6 >>>= n8;
                    sFld = (short)(sFld + (short)l);
                    n2 += (int)(instanceCount |= (long)n3);
                }
                n2 *= n3;
            }
            n4 /= n2 | 1;
        }
        FuzzerUtils.out.println("f i i1 = " + Float.floatToIntBits(f) + "," + n + "," + n2);
        FuzzerUtils.out.println("by1 i10 i11 = " + n8 + "," + n3 + "," + n4);
        FuzzerUtils.out.println("i12 i13 l2 = " + n5 + "," + n6 + "," + l);
        FuzzerUtils.out.println("i14 dArr iArr = " + n7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)) + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.sFld bFld Test.iFld1 = " + sFld + "," + (this.bFld ? 1 : 0) + "," + iFld1);
        FuzzerUtils.out.println("sArrFld Test.dArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.sArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 0.65447);
        FuzzerUtils.init(fArrFld, -1.139f);
        FuzzerUtils.init(iArrFld, 200);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

