/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2079407246L;
    public static float fFld = 26.1022f;
    public static volatile boolean bFld = true;
    public static byte byFld = (byte)-56;
    public static short sFld = (short)14238;
    public static boolean bFld1 = false;
    public static int[] iArrFld = new int[400];
    public volatile long[] lArrFld = new long[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(int n, int n2, int n3) {
        int n4 = 23889;
        int n5 = 1;
        int[] nArray = new int[400];
        int n6 = 30715;
        double d = -100.50226;
        boolean bl = false;
        byte[] byArray = new byte[400];
        long[][][] lArray = new long[400][400][400];
        FuzzerUtils.init(nArray, 8);
        FuzzerUtils.init(byArray, (byte)93);
        FuzzerUtils.init((Object[][])lArray, (Object)-4L);
        instanceCount -= (long)n2;
        n4 = 1;
        block10: while (++n4 < 185) {
            double d2 = 14.34097;
            d2 = n3;
            n5 = 1;
            while (++n5 < 9) {
                nArray = FuzzerUtils.int1array(400, 4550);
            }
            n -= (int)instanceCount;
            n2 -= n6;
            int n7 = n4 - 1;
            byArray[n7] = (byte)(byArray[n7] - (byte)d);
            n2 += n4;
            switch (n4 % 6 + 51) {
                case 51: {
                    instanceCount = n;
                    lArray[n4 - 1][n4][n4] = n;
                    continue block10;
                }
                case 52: {
                    n3 += n4;
                    n3 = n4;
                    n3 <<= n2;
                }
                case 53: {
                    fFld -= (float)n;
                    continue block10;
                }
                case 54: {
                    instanceCount += (long)(-4 + n4 * n4);
                }
                case 55: {
                    try {
                        n3 = 1746384800 / nArray[n4 - 1];
                        n = n2 / n;
                        nArray[n4] = n2 / n5;
                    }
                    catch (ArithmeticException arithmeticException) {}
                    continue block10;
                }
                case 56: {
                    if (!bl) continue block10;
                    continue block10;
                }
            }
            instanceCount -= (long)n;
        }
        vMeth2_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(byArray) + FuzzerUtils.checkSum((Object[][])lArray);
    }

    public static void vMeth1(int n, int n2) {
        int n3 = -178;
        int n4 = -12;
        int n5 = 11;
        int n6 = 4;
        int n7 = -14829;
        int n8 = -26780;
        double d = 14.112286;
        Test.vMeth2(29139, n, n);
        n >>= 12;
        for (n3 = 3; n3 < 156; ++n3) {
            n2 |= n;
            instanceCount += (long)n3;
            for (n5 = 1; 10 > n5; ++n5) {
                instanceCount += (long)d;
            }
            switch (66) {
                case 67: {
                    n7 = 10;
                    while (n7 > 1) {
                        int n9 = n7 + 1;
                        iArrFld[n9] = iArrFld[n9] + n4;
                        instanceCount -= (long)n;
                        n2 = n7--;
                    }
                    n2 <<= n4;
                    int n10 = n3 - 1;
                    iArrFld[n10] = iArrFld[n10] + n3;
                }
            }
        }
        vMeth1_check_sum += (long)(n + n2 + n3 + n4 + n5 + n6) + Double.doubleToLongBits(d) + (long)n7 + (long)n8;
    }

    public static void vMeth() {
        int n = -231;
        int n2 = -31945;
        int n3 = -37748;
        int n4 = 10;
        double d = 2.877;
        double d2 = -126.701;
        int n5 = 6411;
        float f = -1.789f;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -3703891573993596982L);
        Test.vMeth1(n, n);
        n |= n;
        d *= (double)fFld;
        n2 = 1;
        while (++n2 < 273) {
            for (d2 = (double)n2; d2 < 6.0; d2 += 1.0) {
                n <<= n5;
                n3 += (int)(d2 * (double)(n *= (int)f));
                int n6 = n2 + 1;
                iArrFld[n6] = iArrFld[n6] * (int)instanceCount;
                byFld = (byte)(byFld * byFld);
                instanceCount >>= n;
                n = (int)instanceCount;
            }
            n4 = 1;
            do {
                int n7 = n4++;
                lArray[n7] = lArray[n7] >>> -34834;
            } while (n4 < 6);
            int n8 = n2 + 1;
            iArrFld[n8] = iArrFld[n8] >>> n4;
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + Double.doubleToLongBits(d2) + (long)n3 + (long)n5 + (long)Float.floatToIntBits(f) + (long)n4 + FuzzerUtils.checkSum(lArray);
    }

    public void mainTest(String[] stringArray) {
        int n = -63357;
        int n2 = -200;
        int n3 = -8;
        int n4 = -61;
        int n5 = 0;
        int n6 = -534;
        int n7 = -4;
        int n8 = -11;
        int n9 = 24708;
        int n10 = 14;
        float[] fArray = new float[400];
        boolean[][][] blArray = new boolean[400][400][400];
        FuzzerUtils.init(fArray, -2.458f);
        FuzzerUtils.init((Object[][])blArray, (Object)true);
        Test.vMeth();
        n += n;
        for (n2 = 13; n2 < 263; ++n2) {
            instanceCount = (long)fFld;
            instanceCount -= (long)n;
            n4 = 101;
            while ((n4 -= 3) > 0) {
                for (n5 = 1; n5 < 3; ++n5) {
                    n6 >>>= n3;
                }
                int n11 = n2 - 1;
                iArrFld[n11] = iArrFld[n11] - 12;
                for (n7 = 1; 3 > n7; ++n7) {
                    bFld = false;
                    instanceCount *= (long)n7;
                    n6 += n3;
                    Test.iArrFld[n7 - 1] = n5;
                    switch (n4 % 2 + 87) {
                        case 87: {
                            n8 = n5;
                            blArray[n4 - 1][n7 + 1][n7 + 1] = bFld;
                            int n12 = n2;
                            iArrFld[n12] = iArrFld[n12] - sFld;
                            break;
                        }
                        case 88: {
                            n += n7;
                            try {
                                n6 = 7808 / n;
                                n8 = n7 / (n %= 89);
                            }
                            catch (ArithmeticException arithmeticException) {
                                // empty catch block
                            }
                            n3 &= 0xE;
                        }
                    }
                    this.lArrFld[n2] = n4;
                }
                for (n9 = 1; 3 > n9; ++n9) {
                    bFld1 = bFld;
                    n8 %= n8 | 1;
                    instanceCount = (long)((float)instanceCount + ((float)(n9 * n10 + n9) - (fFld += -7899.0f)));
                    n8 -= n;
                }
            }
        }
        FuzzerUtils.out.println("i17 i18 i19 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i20 i21 i22 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i23 i24 i25 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("i26 fArr bArr = " + n10 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray)) + "," + FuzzerUtils.checkSum((Object[][])blArray));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld Test.sFld Test.bFld1 = " + byFld + "," + sFld + "," + (bFld1 ? 1 : 0));
        FuzzerUtils.out.println("Test.iArrFld lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 2);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

