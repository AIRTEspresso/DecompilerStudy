/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -60L;
    public static volatile boolean bFld = true;
    public static double dFld = 53.97498;
    public static byte byFld = (byte)127;
    public int iFld = -60701;
    public int iFld1 = 43182;
    public static boolean bFld1 = false;
    public static long lFld = -212L;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long vMeth_check_sum;
    public static long bMeth_check_sum;

    public static boolean bMeth(int n, long l) {
        int n2 = 5;
        int n3 = -8;
        int n4 = -125;
        int n5 = 5;
        int n6 = -20817;
        int n7 = 239;
        int n8 = -10;
        int n9 = 56896;
        float f = -2.104f;
        int n10 = -54;
        long l2 = -3139798362L;
        int n11 = -27326;
        try {
            if (bFld) {
                n -= 37361;
            } else if (bFld) {
                for (n2 = 13; 355 > n2; ++n2) {
                    n4 = 1;
                    while (++n4 < 5) {
                        instanceCount *= (long)f;
                    }
                    n3 >>>= n4;
                }
                n5 = 1;
                do {
                    for (n6 = 1; n6 < 6; n6 += 2) {
                        for (n8 = 1; n8 < 3; ++n8) {
                            n += n8 + n5;
                        }
                        Test.iArrFld[n6 + 1] = n;
                    }
                } while (++n5 < 276);
                n10 = (byte)(n10 - (byte)l);
                l2 += -1L;
            } else {
                n7 = n3;
            }
        }
        catch (ArithmeticException arithmeticException) {
            n3 += (int)f;
        }
        catch (UserDefinedExceptionTest userDefinedExceptionTest) {
            n = n11;
        }
        long l3 = (long)n + l + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n5 + (long)n6 + (long)n7 + (long)n8 + (long)n9 + (long)n10 + l2 + (long)n11;
        bMeth_check_sum += l3;
        return l3 % 2L > 0L;
    }

    public static void vMeth(float f, int n, double d) {
        int n2 = 194;
        int n3 = 14;
        int n4 = 56779;
        int n5 = -251;
        double d2 = 2.68192;
        boolean bl = false;
        float[] fArray = new float[400];
        FuzzerUtils.init(fArray, 0.4f);
        n2 = 1;
        block0: do {
            d2 = 1.0;
            do {
                if (Test.bMeth(n2, instanceCount)) {
                    n = (int)((double)n + (9.0 + d2 * d2));
                    int n6 = n2 + 1;
                    iArrFld[n6] = iArrFld[n6] - iArrFld[n2 - 1];
                } else if (bl) {
                    if (!(instanceCount > instanceCount-- | bl)) continue block0;
                    int n7 = n2;
                    float f2 = fArray[n7] - 1.0f;
                    fArray[n7] = f2;
                    instanceCount += (long)(f2 - (float)(n + -13535) * (f + -1833.0f));
                } else {
                    for (n3 = 1; n3 < 1; ++n3) {
                        instanceCount = n ^= 0xFFFFFFFF;
                        instanceCount += (long)n;
                        n4 -= (int)f;
                        n5 *= 1;
                    }
                }
                n4 *= (int)instanceCount;
                d += d;
            } while ((d2 += 1.0) < 6.0);
        } while (++n2 < 263);
        vMeth_check_sum += (long)(Float.floatToIntBits(f) + n) + Double.doubleToLongBits(d) + (long)n2 + Double.doubleToLongBits(d2) + (long)(bl ? 1 : 0) + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static int iMeth(long l, int n, int n2) {
        int n3 = 11;
        int n4 = 2;
        int n5 = -10944;
        boolean[] blArray = new boolean[400];
        long[] lArray = new long[400];
        FuzzerUtils.init(blArray, false);
        FuzzerUtils.init(lArray, 6L);
        blArray[(n >>> 1) % 400] = blArray[(n2 >>> 1) % 400];
        n2 *= (int)lArray[(n2 >>> 1) % 400];
        Test.vMeth(-101.447f, n, dFld);
        if (bFld) {
            for (n3 = 11; n3 < 180; ++n3) {
                switch (n3 % 1 + 23) {
                    default: 
                }
                int n6 = n3;
                iArrFld[n6] = iArrFld[n6] << n3;
                n5 = (short)(n5 - (short)n4);
            }
            int n7 = (n4 >>> 1) % 400;
            iArrFld[n7] = iArrFld[n7] * -2;
            n2 -= n3;
            lArray[195] = lArray[195] - instanceCount;
        } else if (bFld) {
            n4 -= (int)dFld;
        } else {
            byFld = (byte)(byFld * (byte)dFld);
        }
        byFld = (byte)n4;
        long l2 = l + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(blArray) + FuzzerUtils.checkSum(lArray);
        iMeth_check_sum += l2;
        return (int)l2;
    }

    public void mainTest(String[] stringArray) {
        int n = -17633;
        int n2 = -8;
        int n3 = -26279;
        int n4 = -30;
        int n5 = -2;
        int n6 = 30;
        int n7 = 222;
        int n8 = -121;
        float f = 1.1f;
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(lArray, 241L);
        block13: for (n = 13; n < 271; ++n) {
            iArrFld = FuzzerUtils.int1array(400, -246);
            Test.iMeth(instanceCount, n, n);
            switch (n % 2 * 5 + 82) {
                case 84: {
                    if (bFld) continue block13;
                    switch (n % 7 * 5 + 12) {
                        case 35: {
                            n2 <<= -19576;
                            dFld = instanceCount &= 0xEL;
                            for (n3 = 1; 97 > n3; n3 += 2) {
                                int n9 = -5632;
                                instanceCount = n5;
                                n4 = (int)((long)n4 + ((long)(n3 * n4) + instanceCount - (long)n9));
                                for (n6 = 3; n6 > 1; --n6) {
                                    n7 >>= n5;
                                    n2 -= n6;
                                    instanceCount <<= n5;
                                    instanceCount += (long)n4;
                                    if (bFld) continue;
                                    if (bFld) break;
                                    this.iFld += 152;
                                    lArray[n3][n] = instanceCount -= (long)n6;
                                }
                                this.iFld = n3;
                                n8 = 1;
                                while (++n8 < 3) {
                                    this.iFld1 >>= -21569;
                                    this.iFld = this.iFld1;
                                    if (bFld1) {
                                        int n10 = n3 + 1;
                                        iArrFld[n10] = iArrFld[n10] - (int)instanceCount;
                                        n7 += n8 * n3 + n4 - n2;
                                        instanceCount >>= n2;
                                        continue;
                                    }
                                    if (bFld1) {
                                        this.iFld = 139;
                                        continue;
                                    }
                                    n4 += (int)dFld;
                                }
                            }
                        }
                        case 38: {
                            f = n3;
                            continue block13;
                        }
                        case 45: {
                            n5 *= 135;
                            continue block13;
                        }
                        case 18: {
                            dFld /= (double)(byFld | 1);
                        }
                        case 34: {
                            this.iFld -= n2;
                            continue block13;
                        }
                        case 44: {
                            n2 = n8;
                            continue block13;
                        }
                        case 28: {
                            Test.iArrFld[n + 1] = (int)instanceCount;
                            continue block13;
                        }
                    }
                    continue block13;
                }
                case 87: {
                    f *= (float)lFld;
                }
                default: {
                    Test.iArrFld[n] = n;
                }
            }
        }
        FuzzerUtils.out.println("i i1 i20 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i21 i22 i23 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i24 i25 f3 = " + n7 + "," + n8 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.byFld iFld iFld1 = " + byFld + "," + this.iFld + "," + this.iFld1);
        FuzzerUtils.out.println("Test.bFld1 Test.lFld Test.iArrFld = " + (bFld1 ? 1 : 0) + "," + lFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 8673);
        iMeth_check_sum = 0L;
        vMeth_check_sum = 0L;
        bMeth_check_sum = 0L;
    }
}

