/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 14L;
    public static byte byFld = (byte)-82;
    public static float[] fArrFld = new float[400];
    public static long vSmallMeth_check_sum;
    public static long iMeth_check_sum;
    public static long fMeth_check_sum;

    public static float fMeth(int n, int n2) {
        int n3 = 41075;
        int n4 = -2;
        int n5 = 4322;
        int n6 = -10;
        int n7 = 9;
        double d = 57.111964;
        boolean bl = false;
        float f = -29.314f;
        switch ((n >>> 1) % 2 + 70) {
            case 70: {
                instanceCount = n;
                for (n3 = 13; n3 < 289; ++n3) {
                    block5: for (n5 = 1; n5 < 6; ++n5) {
                        n7 >>= (int)instanceCount;
                        n -= n4;
                        n6 += n3;
                        n2 >>= n4;
                        if (bl) {
                            n6 += n5;
                            d = 1.0;
                            while (true) {
                                double d2;
                                d += 1.0;
                                if (!(d2 < 2.0)) continue block5;
                                if (!bl) continue;
                                n4 += (int)instanceCount;
                                instanceCount += (long)(d * d);
                            }
                        }
                        if (bl) {
                            n6 += (int)instanceCount;
                            continue;
                        }
                        if (!bl) continue;
                        n2 += (int)f;
                    }
                }
                break;
            }
            case 71: {
                n2 += (int)f;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + n7) + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f);
        fMeth_check_sum += l;
        return l;
    }

    public static int iMeth(long l, long l2, int n) {
        int n2 = 10;
        int n3 = 11;
        int n4 = -5;
        int n5 = -10430;
        int[] nArray = new int[400];
        double d = 0.115804;
        boolean bl = false;
        boolean bl2 = false;
        float f = -102.937f;
        int n6 = 26;
        FuzzerUtils.init(nArray, -52830);
        block0: for (n2 = 9; n2 < 336; ++n2) {
            for (n4 = 1; n4 < 5; ++n4) {
                n5 *= (int)((double)fArrFld[n4] * (d + (d - -2.0)));
                if (bl) {
                    boolean bl3;
                    bl = true;
                    n += n4 ^ n5;
                    bl2 = bl2;
                    bl2 = bl2;
                    if (bl3) {
                        n5 += 12456 + n4 * n4;
                        n5 += 11 + n4 * n4;
                    }
                    if (Test.fMeth(n2, n5) == -68.256f) continue;
                    continue block0;
                }
                n = n3;
            }
        }
        long l3 = l + l2 + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)n5 + Double.doubleToLongBits(d) + (long)(bl ? 1 : 0) + (long)Float.floatToIntBits(f) + (long)(bl2 ? 1 : 0) + (long)n6 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l3;
        return (int)l3;
    }

    public static void vSmallMeth() {
        int n = 130;
        Test.iMeth(instanceCount, instanceCount, n);
        vSmallMeth_check_sum += (long)n;
    }

    public void mainTest(String[] stringArray) {
        int n = 250;
        int n2 = 3388;
        int n3 = -79;
        int n4 = 5241;
        int n5 = 10467;
        int n6 = 171;
        int[] nArray = new int[400];
        float f = -125.56f;
        int n7 = 11487;
        FuzzerUtils.init(nArray, -81);
        for (int i = 0; i < 368; ++i) {
            Test.vSmallMeth();
        }
        instanceCount -= 36L;
        for (n = 152; n > 9; --n) {
            for (n3 = 175; n3 > n; n3 -= 3) {
                Test.fArrFld[n3] = instanceCount;
                for (n5 = 1; n5 < 1; ++n5) {
                    n4 += n2;
                    f = n7;
                    switch (n % 5 + 106) {
                        case 106: {
                            n6 <<= -9;
                            byFld = (byte)n;
                            int n8 = n + 1;
                            nArray[n8] = nArray[n8] >>> 64654;
                            int n9 = n;
                            nArray[n9] = nArray[n9] * n2;
                        }
                        case 107: {
                            n2 >>= (int)instanceCount;
                            break;
                        }
                        case 108: {
                            int n10 = n5;
                            nArray[n10] = nArray[n10] >> (int)instanceCount;
                            f -= (float)n5;
                            n4 *= -2;
                            instanceCount -= (long)n5;
                            break;
                        }
                        case 109: {
                            n4 = n6;
                            n4 = n3;
                            break;
                        }
                        case 110: {
                            n4 = n3;
                            instanceCount &= 0xFFFFFFFFFFFFE7C8L;
                        }
                    }
                    n4 *= n3;
                    int n11 = n5;
                    nArray[n11] = nArray[n11] >> n2;
                    n4 += n5 - n6;
                }
                n2 = (int)((long)n2 + ((long)n3 + instanceCount));
                n6 -= 2;
                instanceCount = n4;
            }
            instanceCount += (long)n;
            n4 += n;
        }
        FuzzerUtils.out.println("i13 i14 i15 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i16 i17 i18 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("f2 s iArr1 = " + Float.floatToIntBits(f) + "," + n7 + "," + FuzzerUtils.checkSum(nArray));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fArrFld = " + instanceCount + "," + byFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(fArrFld, 1.518f);
        vSmallMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
        fMeth_check_sum = 0L;
    }
}

