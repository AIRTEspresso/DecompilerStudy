/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 65317L;
    public static double dFld = 1.31994;
    public static boolean bFld = true;
    public static float fFld = 0.377f;
    public static int iFld = -33496;
    public byte byFld = (byte)-122;
    public static int iFld1 = 250;
    public boolean bFld1 = true;
    public static int[] iArrFld = new int[400];
    public static byte[][] byArrFld = new byte[400][400];
    public static long vMeth_check_sum;
    public static long lMeth_check_sum;
    public static long iMeth_check_sum;

    public static int iMeth() {
        int n = 2;
        int n2 = -84;
        int n3 = -122;
        int n4 = -61610;
        int n5 = -8246;
        int n6 = -52;
        long[] lArray = new long[400];
        boolean[] blArray = new boolean[400];
        float[] fArray = new float[400];
        FuzzerUtils.init(lArray, 8407702357601404726L);
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(fArray, 1.184f);
        fFld = iFld;
        iFld <<= -128;
        for (n = 391; n > 11; --n) {
            n3 = 1;
            do {
                iFld = n3;
                for (n4 = 1; n4 < 4; ++n4) {
                    n2 += n5;
                    lArray = FuzzerUtils.long1array(400, -7L);
                    blArray[n] = bFld;
                }
                switch (n3 % 5 + 103) {
                    case 103: {
                        n5 = n;
                        n6 = (byte)(n6 >> (byte)instanceCount);
                        iFld = 42462;
                        int n7 = n;
                        iArrFld[n7] = iArrFld[n7] + -2;
                        break;
                    }
                    case 104: {
                        n2 = n5;
                        break;
                    }
                    case 105: {
                        iFld %= n | 1;
                        break;
                    }
                    case 106: {
                        int n8 = n;
                        fArray[n8] = fArray[n8] + fFld;
                        break;
                    }
                    case 107: {
                        n5 += n3 * n3;
                    }
                }
            } while ((n3 += 3) < 4);
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum(blArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
        iMeth_check_sum += l;
        return (int)l;
    }

    public static long lMeth(int n) {
        int n2 = 142;
        int n3 = -5;
        int n4 = 5896;
        int n5 = -21814;
        int n6 = 213;
        int[] nArray = new int[400];
        float f = -10.491f;
        int n7 = 69;
        byte[] byArray = new byte[400];
        FuzzerUtils.init(nArray, -227);
        FuzzerUtils.init(byArray, (byte)-1);
        n = n & n--;
        for (n2 = 4; 356 > n2; ++n2) {
            n3 += n2 * n2;
            for (f = 5.0f; f > 1.0f; f -= 1.0f) {
                instanceCount = Math.min(n2, n2) / (nArray[n2 + 1] | 1) * byArray[(int)f];
                if (!bFld) continue;
                n -= n4;
                for (n5 = (int)f; n5 < 2; ++n5) {
                    if (bFld == (n3 == Test.iMeth())) {
                        n4 |= (int)(-((double)instanceCount++ - (double)instanceCount * dFld));
                    } else {
                        nArray[(int)(f - 1.0f)] = iFld;
                    }
                    n7 = (byte)(n7 + (byte)instanceCount);
                    instanceCount *= (long)iFld;
                    n4 += n5 * n5;
                }
            }
        }
        long l = (long)(n + n2 + n3 + Float.floatToIntBits(f) + n4 + n5 + n6 + n7) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(byArray);
        lMeth_check_sum += l;
        return l;
    }

    public static void vMeth(byte by, byte by2) {
        int n = -48;
        int n2 = 40641;
        int n3 = 97;
        int[][] nArray = new int[400][400];
        double d = -16.17851;
        FuzzerUtils.init(nArray, -11101);
        Test.lMeth(iFld);
        iFld = (int)instanceCount;
        dFld *= -30.0;
        for (n = 1; n < 173; ++n) {
            n3 = 1;
            while (++n3 < 9) {
                iFld >>= -3;
                d = 1.0;
                do {
                    int n4 = (int)(d - 1.0);
                    iArrFld[n4] = iArrFld[n4] >> iFld;
                    iFld = n2;
                } while ((d += 1.0) < 1.0);
                nArray[n + 1] = FuzzerUtils.int1array(400, 4);
                instanceCount *= (long)dFld;
                fFld *= (float)n2;
                n2 += n3 * iFld + by - n3;
            }
        }
        vMeth_check_sum += (long)(by + by2 + n + n2 + n3) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 0;
        int n2 = 61;
        int n3 = 61;
        int n4 = 6;
        int n5 = 18687;
        int n6 = 12;
        int n7 = -14;
        int n8 = -228;
        int n9 = 0;
        boolean[][] blArray = new boolean[400][400];
        long[][] lArray = new long[400][400];
        FuzzerUtils.init(blArray, true);
        FuzzerUtils.init(lArray, -60058L);
        Test.vMeth(this.byFld, this.byFld);
        fFld -= (float)iFld;
        for (n = 3; n < 275; ++n) {
            if (bFld) {
                blArray[n][n - 1] = bFld;
                long[] lArray2 = lArray[n];
                int n10 = n;
                lArray2[n10] = lArray2[n10] + (long)fFld;
            } else if (bFld) {
                n2 &= iFld1;
                lArray[n][n] = iFld1;
                n3 = 92;
                do {
                    iFld = n3;
                    iFld1 += (int)fFld;
                    byte[] byArray = byArrFld[n];
                    int n11 = n + 1;
                    byArray[n11] = (byte)(byArray[n11] << (byte)n);
                    int n12 = n3;
                    iArrFld[n12] = iArrFld[n12] << (int)instanceCount;
                    int n13 = n3 - 1;
                    iArrFld[n13] = iArrFld[n13] * 7;
                } while (--n3 > 0);
            } else if (bFld) {
                // empty if block
            }
            iFld += (int)dFld;
            if (bFld) break;
            n2 -= (int)instanceCount;
            instanceCount -= 191L;
            for (n4 = 5; n4 < 92; ++n4) {
                if (!bFld) continue;
            }
            n9 = n2;
        }
        FuzzerUtils.out.println("i14 i15 i16 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i17 i18 i19 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("i20 i21 i22 = " + n7 + "," + n8 + "," + n9);
        FuzzerUtils.out.println("bArr1 lArr1 = " + FuzzerUtils.checkSum(blArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld Test.iFld byFld = " + Float.floatToIntBits(fFld) + "," + iFld + "," + this.byFld);
        FuzzerUtils.out.println("Test.iFld1 bFld1 Test.iArrFld = " + iFld1 + "," + (this.bFld1 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.byArrFld = " + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 194);
        FuzzerUtils.init(byArrFld, (byte)6);
        vMeth_check_sum = 0L;
        lMeth_check_sum = 0L;
        iMeth_check_sum = 0L;
    }
}

