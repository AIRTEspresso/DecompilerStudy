/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -12L;
    public static volatile double dFld = 34.38497;
    public static byte byFld = (byte)19;
    public float fFld = -2.886f;
    public boolean bFld = false;
    public static int[] iArrFld = new int[400];
    public static long iMeth_check_sum;
    public static long iMeth1_check_sum;
    public static long vMeth_check_sum;

    public static void vMeth(int n) {
        int n2 = 42787;
        int n3 = -37618;
        int n4 = 19059;
        int n5 = -104;
        int n6 = -13;
        int n7 = 14;
        float f = -1.951f;
        int n8 = -30645;
        boolean bl = false;
        block7: for (n2 = 272; 16 < n2; --n2) {
            instanceCount = -5L;
            for (n4 = 6; n4 > 1; --n4) {
                int n9 = -48;
                n5 = (int)f;
                n5 += n4;
                if (bl) {
                    switch (n2 % 5 + 17) {
                        case 17: {
                            n6 = 1;
                            do {
                                int n10 = n6++;
                                iArrFld[n10] = iArrFld[n10] >> n;
                                n *= n;
                                n5 *= -86;
                                n8 = (short)(n8 * (short)instanceCount);
                            } while (n6 < 2);
                        }
                        case 18: {
                            n7 = (int)((float)n7 + ((float)(n4 * n) + f - f));
                            n3 += n4;
                            dFld -= dFld;
                            break;
                        }
                        case 19: {
                            Test.iArrFld[n2 - 1] = n2;
                            break;
                        }
                        case 20: {
                            if (!bl) break;
                            break;
                        }
                        case 21: {
                            n5 = n4;
                        }
                    }
                    continue;
                }
                if (bl) continue block7;
                n9 = (byte)instanceCount;
            }
        }
        vMeth_check_sum += (long)(n + n2 + n3 + n4 + n5 + Float.floatToIntBits(f) + n6 + n8 + n7 + (bl ? 1 : 0));
    }

    public static int iMeth1(long l, int n) {
        int n2 = -6;
        int n3 = 1;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 10);
        for (n2 = 3; n2 < 271; ++n2) {
            nArray[n2 + 1] = (int)l;
        }
        Test.vMeth(-12);
        long l2 = l + (long)n + (long)n2 + (long)n3 + FuzzerUtils.checkSum(nArray);
        iMeth1_check_sum += l2;
        return (int)l2;
    }

    public int iMeth(int n) {
        int n2 = 19368;
        int n3 = 8;
        int n4 = -14;
        int n5 = 9025;
        int n6 = -17586;
        int n7 = 16351;
        for (n2 = 15; n2 < 281; ++n2) {
            n4 = 1;
            while (++n4 < 6) {
                n3 += n4;
                n3 = Test.iMeth1(instanceCount, n2);
                n3 += (int)instanceCount;
                block8: for (n5 = n2; 1 > n5; ++n5) {
                    n -= n;
                    try {
                        n3 = n2 % -704943244;
                        n = iArrFld[n2 + 1] % n2;
                        n3 = -1887 / iArrFld[n5 - 1];
                    }
                    catch (ArithmeticException arithmeticException) {
                        // empty catch block
                    }
                    switch ((n >>> 1) % 2 + 111) {
                        case 111: {
                            n6 = (int)instanceCount;
                            instanceCount = 78L;
                            n6 >>= 2089;
                            continue block8;
                        }
                        case 112: {
                            n7 = (short)(n7 - (short)n4);
                            n3 += n3;
                            n -= (int)instanceCount;
                            continue block8;
                        }
                        default: {
                            int n8 = n4 - 1;
                            iArrFld[n8] = iArrFld[n8] - n6;
                        }
                    }
                }
            }
        }
        long l = n + n2 + n3 + n4 + n5 + n6 + n7;
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 0;
        int n2 = 54052;
        int n3 = -107;
        int n4 = -3953;
        int n5 = -250;
        int n6 = 120;
        int n7 = -3;
        int n8 = 64501;
        int n9 = -4;
        int n10 = -27259;
        int[][] nArray = new int[400][400];
        long l = -2336875686245425543L;
        int n11 = -25689;
        double[] dArray = new double[400];
        FuzzerUtils.init(nArray, -10765);
        FuzzerUtils.init(dArray, -91.75991);
        nArray[7][(n >>> 1) % 400] = (int)(((long)n + instanceCount + (long)this.iMeth(n)) * (long)byFld);
        this.fFld -= (float)n;
        for (n2 = 3; n2 < 156; ++n2) {
            for (l = 8L; 164L > l; ++l) {
                n -= n11;
                n4 = n3;
                dFld *= -1.81981760497132646E18;
                int[] nArray2 = nArray[(int)(l + 1L)];
                int n12 = (int)l;
                nArray2[n12] = nArray2[n12] * (int)this.fFld;
                int[] nArray3 = nArray[n2 + 1];
                int n13 = n2 - 1;
                nArray3[n13] = nArray3[n13] * -140;
            }
            for (n5 = 7; 164 > n5; ++n5) {
                this.fFld += (float)n;
                n += 11 + n5 * n5;
            }
            dFld *= (double)n;
            for (n7 = 164; 10 < n7; --n7) {
                for (n9 = n7; n9 < 2; ++n9) {
                    int n14 = n2 - 1;
                    iArrFld[n14] = iArrFld[n14] + (int)l;
                    n += n9 * n9;
                    n10 += -1 + n9 * n9;
                    n8 -= (int)l;
                    int n15 = n2;
                    iArrFld[n15] = iArrFld[n15] + n4;
                    n8 += 5;
                }
                this.bFld = this.bFld;
                switch (n7 % 2 + 111) {
                    case 111: {
                        dArray[n7] = 0.0;
                        break;
                    }
                    case 112: {
                        n6 = (int)l;
                        n8 += (int)(8149340305286956525L + (long)(n7 * n7));
                        n10 += n11;
                    }
                }
                n3 = (int)instanceCount;
                n6 = n4;
            }
        }
        FuzzerUtils.out.println("i i17 i18 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("l1 i19 s2 = " + l + "," + n4 + "," + n11);
        FuzzerUtils.out.println("i20 i21 i22 = " + n5 + "," + n6 + "," + n7);
        FuzzerUtils.out.println("i23 i24 i25 = " + n8 + "," + n9 + "," + n10);
        FuzzerUtils.out.println("iArr dArr = " + FuzzerUtils.checkSum(nArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
        FuzzerUtils.out.println("fFld bFld Test.iArrFld = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, 92);
        iMeth_check_sum = 0L;
        iMeth1_check_sum = 0L;
        vMeth_check_sum = 0L;
    }
}

