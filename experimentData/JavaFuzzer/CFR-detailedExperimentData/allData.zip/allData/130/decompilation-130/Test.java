/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 31092L;
    public boolean bFld = false;
    public static float fFld = 2.355f;
    public static int iFld = -14;
    public static double dFld = 0.9752;
    public static short sFld = (short)3781;
    public int iFld1 = 391;
    public static double[] dArrFld = new double[400];
    public static volatile float[] fArrFld = new float[400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long vMeth2_check_sum;

    public static void vMeth2(long l, byte by) {
        int n = 129;
        int n2 = 37992;
        int n3 = -7;
        int n4 = 254;
        int n5 = 3;
        int n6 = 4;
        int[][] nArray = new int[400][400];
        float f = -2.32f;
        int n7 = 11932;
        FuzzerUtils.init(nArray, 99);
        for (n = 8; 197 > n; ++n) {
            for (n3 = 8; n3 > 1; --n3) {
                n2 >>= (int)instanceCount;
                n4 = (int)instanceCount;
            }
            n4 = 19178;
            n4 -= (int)(f += (float)n);
            l += (long)n ^ (long)f;
            n2 = n7;
            l *= (long)n3;
        }
        for (n5 = 2; n5 < 304; ++n5) {
            int[] nArray2 = nArray[n5];
            int n8 = n5;
            nArray2[n8] = nArray2[n8] + n6;
            instanceCount += (long)(n5 ^ n3);
            n2 -= n2;
        }
        vMeth2_check_sum += l + (long)by + (long)n + (long)n2 + (long)n3 + (long)n4 + (long)Float.floatToIntBits(f) + (long)n7 + (long)n5 + (long)n6 + FuzzerUtils.checkSum(nArray);
    }

    public void vMeth1(float f) {
        int n = -1;
        int n2 = 53410;
        int n3 = -118;
        int n4 = -5944;
        int[][][] nArray = new int[400][400][400];
        int n5 = 60;
        double d = -1.10406;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, 0L);
        FuzzerUtils.init((Object[][])nArray, (Object)-13);
        Test.vMeth2(instanceCount, (byte)113);
        instanceCount += -9L;
        for (n = 12; n < 244; ++n) {
            n2 += n - n2;
            if (this.bFld) continue;
            instanceCount = n2;
            for (n3 = n; n3 < 7; ++n3) {
                try {
                    n4 = n3 % n4;
                    n4 = 139 / n4;
                    nArray[n3][n - 1][n + 1] = n4 / -21;
                }
                catch (ArithmeticException arithmeticException) {
                    // empty catch block
                }
                nArray[n][n] = FuzzerUtils.int1array(400, 9);
                int n6 = n;
                lArray[n6] = lArray[n6] + (long)n;
                if (this.bFld) {
                    n4 = n5;
                    n4 = 1;
                    continue;
                }
                n2 += (int)d;
            }
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + n + n2 + n3 + n4 + n5) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray) + FuzzerUtils.checkSum((Object[][])nArray);
    }

    public void vMeth(int n) {
        int n2 = -2;
        int n3 = 54;
        int n4 = 37188;
        int n5 = -3;
        int n6 = -1;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, -4);
        this.vMeth1(fFld);
        instanceCount += (long)n;
        n /= n | 1;
        iFld = (int)instanceCount;
        for (n2 = 2; 149 > n2; ++n2) {
            int n7 = n2;
            fArrFld[n7] = fArrFld[n7] - (float)iFld;
            for (n4 = 11; n4 > 1; --n4) {
                int n8 = n2 - 1;
                nArray[n8] = nArray[n8] - -34288;
                nArray = FuzzerUtils.int1array(400, -12);
            }
            n6 = 1;
            do {
                dFld += (double)n5;
            } while (++n6 < 11);
            n3 += n3;
            fFld -= (float)n4;
        }
        vMeth_check_sum += (long)(n + n2 + (n3 += sFld) + n4 + n5 + n6) + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 33;
        int n2 = -7;
        int n3 = -45;
        int n4 = -9;
        int n5 = 6;
        int n6 = 4;
        int n7 = 11;
        int n8 = -2;
        int[] nArray = new int[400];
        int n9 = 70;
        byte[] byArray = new byte[400];
        boolean[] blArray = new boolean[400];
        FuzzerUtils.init(byArray, (byte)14);
        FuzzerUtils.init(nArray, -55);
        FuzzerUtils.init(blArray, true);
        n = -(n * -Math.max(n, n));
        n2 = 1;
        while ((n2 += 2) < 237) {
            this.vMeth(0);
            n9 = (byte)(n9 + (byte)n);
            block13: for (n3 = 212; 1 < n3; --n3) {
                n4 -= (int)fFld;
                switch (((n4 += n3) >>> 1) % 2 * 5 + 110) {
                    case 116: {
                        instanceCount ^= (long)n5;
                        n = n5;
                        instanceCount <<= iFld;
                        iFld = 52943;
                        continue block13;
                    }
                    case 119: {
                        switch (n3 % 2 + 124) {
                            case 124: {
                                n5 += n3 * n3;
                                for (n7 = n3; n7 < 2; ++n7) {
                                    switch (n7 % 2 + 109) {
                                        case 109: {
                                            int n10 = n7 - 1;
                                            byArray[n10] = (byte)(byArray[n10] * 13);
                                            n9 = (byte)(n9 + (byte)n7);
                                            instanceCount += instanceCount;
                                            break;
                                        }
                                        case 110: {
                                            n9 = (byte)(n9 - (byte)n6);
                                            n8 -= 3;
                                            n8 *= n5;
                                            break;
                                        }
                                        default: {
                                            n5 -= n4;
                                            instanceCount += -8L;
                                        }
                                    }
                                    n = (int)((float)n + ((float)(n7 * n3 + n6) - fFld));
                                    nArray = FuzzerUtils.int1array(400, 4639);
                                    instanceCount -= instanceCount;
                                    fFld -= (float)n4;
                                    n4 = n8;
                                    this.iFld1 -= 114;
                                }
                            }
                            case 125: {
                                blArray[n2] = true;
                            }
                        }
                        continue block13;
                    }
                    default: {
                        instanceCount += instanceCount;
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 by2 = " + n + "," + n2 + "," + n9);
        FuzzerUtils.out.println("i18 i19 i20 = " + n3 + "," + n4 + "," + n5);
        FuzzerUtils.out.println("i21 i22 i23 = " + n6 + "," + n7 + "," + n8);
        FuzzerUtils.out.println("byArr iArr3 bArr = " + FuzzerUtils.checkSum(byArray) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(blArray));
        FuzzerUtils.out.println("Test.instanceCount bFld Test.fFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iFld Test.dFld Test.sFld = " + iFld + "," + Double.doubleToLongBits(dFld) + "," + sFld);
        FuzzerUtils.out.println("iFld1 Test.dArrFld Test.fArrFld = " + this.iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(dArrFld, 1.37436);
        FuzzerUtils.init(fArrFld, -87.315f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        vMeth2_check_sum = 0L;
    }
}

