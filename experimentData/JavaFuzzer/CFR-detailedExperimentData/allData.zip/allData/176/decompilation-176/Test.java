/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 216L;
    public static float fFld = 0.587f;
    public static int[] iArrFld = new int[400];
    public static double[] dArrFld = new double[400];
    public static float[][] fArrFld = new float[400][400];
    public static long vMeth_check_sum;
    public static long vMeth1_check_sum;
    public static long lMeth_check_sum;

    /*
     * Unable to fully structure code
     */
    public static long lMeth(int var0) {
        var1_1 = 113;
        var2_2 = -52;
        var3_3 = 43697;
        var4_4 = -20;
        var5_5 = 31518;
        var6_6 = 5;
        var7_7 = -107;
        var8_8 = -1.4457;
        var10_9 = false;
        var11_10 = -29349;
        Test.iArrFld[(var0 >>> 1) % 400] = (int)Test.instanceCount;
        v0 = (var0 >>> 1) % 400;
        Test.iArrFld[v0] = Test.iArrFld[v0] & var1_1;
        block11: for (var2_2 = 3; var2_2 < 125; ++var2_2) {
            var0 |= var0;
            switch (var2_2 % 9 + 29) {
                case 29: {
                    var0 >>= var0;
                    for (var4_4 = 13; var4_4 > 1; var4_4 -= 2) {
                        for (var6_6 = 1; var6_6 < 3; ++var6_6) {
                            Test.iArrFld[var6_6] = var0 += var6_6;
                            if (var3_3 != 0) {
                                // empty if block
                            }
                            var5_5 *= var7_7;
                            Test.instanceCount -= (long)Test.fFld;
                            Test.iArrFld[var6_6 + 1] = 134;
                        }
                    }
                    continue block11;
                }
                case 30: {
                    var8_8 *= (double)Test.fFld;
                }
                case 31: {
                    Test.iArrFld[var2_2] = var4_4;
                }
                case 32: {
                    Test.instanceCount -= (long)var2_2;
                    continue block11;
                }
                case 33: {
                    var3_3 = -7870;
                    continue block11;
                }
                case 34: {
                    var1_1 = (byte)(var1_1 + (byte)var2_2);
                }
                ** case 35:
lbl43:
                // 2 sources

                case 36: {
                    var3_3 += -81 + var2_2 * var2_2;
                }
                case 37: {
                    if (!var10_9) continue block11;
                    continue block11;
                }
                default: {
                    var7_7 *= var11_10;
                }
            }
        }
        var12_11 = (long)(var0 + var1_1 + var2_2 + var3_3 + var4_4 + var5_5 + var6_6 + var7_7) + Double.doubleToLongBits(var8_8) + (long)(var10_9 != false ? 1 : 0) + (long)var11_10;
        Test.lMeth_check_sum += var12_11;
        return var12_11;
    }

    public static void vMeth1(float f, boolean bl, byte by) {
        int n = 76;
        int n2 = -121;
        int n3 = 53510;
        int n4 = 136;
        double d = 0.37123;
        long[] lArray = new long[400];
        FuzzerUtils.init(lArray, -3677485691447833902L);
        for (n = 16; n < 313; ++n) {
            f -= (float)(n2 * 55978);
            block12: for (n3 = 1; 6 > n3; ++n3) {
                int n5 = n3;
                int n6 = n3;
                int n7 = iArrFld[n6] - 1;
                iArrFld[n6] = n7;
                iArrFld[n5] = iArrFld[n5] + (int)(f - (float)n7);
                int n8 = n;
                iArrFld[n8] = iArrFld[n8] >>> (int)lArray[n + 1];
                switch ((n >>> 1) % 10 * 5 + 7) {
                    case 47: {
                        n4 >>>= (int)((instanceCount -= (long)(d + (double)by)) * Test.lMeth(n3));
                        fFld -= (float)d;
                    }
                    case 16: {
                        n2 += n3 * n2 + n3 - by;
                        n2 += n3 * n2;
                        continue block12;
                    }
                    case 39: {
                        f = n2;
                        n4 += n3;
                        continue block12;
                    }
                    case 31: {
                        fFld = n4;
                        n2 += n3 * n3;
                        continue block12;
                    }
                    case 29: {
                        n4 <<= -19;
                        continue block12;
                    }
                    case 36: 
                    case 44: {
                        int n9 = (n3 >>> 1) % 400;
                        dArrFld[n9] = dArrFld[n9] - 11.0;
                        continue block12;
                    }
                    case 45: {
                        instanceCount += (long)n;
                        continue block12;
                    }
                    case 11: {
                        n2 *= n4;
                        continue block12;
                    }
                    case 24: {
                        n4 += 23;
                    }
                }
            }
        }
        vMeth1_check_sum += (long)(Float.floatToIntBits(f) + (bl ? 1 : 0) + by + n + n2 + n3 + n4) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(lArray);
    }

    /*
     * Unable to fully structure code
     */
    public static void vMeth() {
        var0 = 67;
        var1_1 = 37531;
        var2_2 = -2;
        var3_3 = 9;
        var4_4 = -12743;
        var5_5 = -52049;
        var6_6 = -14.59992;
        var8_7 = new long[400];
        var9_8 = new short[400];
        FuzzerUtils.init(var8_7, 24885L);
        FuzzerUtils.init(var9_8, (short)15054);
        Test.vMeth1(-1.957f, true, var0);
        for (var1_1 = 11; var1_1 < 397; ++var1_1) {
            var2_2 *= (int)var6_6;
            block7: for (var3_3 = 4; var3_3 > 1; var3_3 -= 2) {
                Test.fFld += (float)var1_1;
                var5_5 = 1;
                do {
                    v0 = var5_5++;
                    var8_7[v0] = var8_7[v0] << var1_1;
                } while (var5_5 < 4);
                switch (var1_1 % 4 * 5 + 69) {
                    case 78: {
                        var2_2 = (int)((long)var2_2 + ((long)(var3_3 * var2_2) + Test.instanceCount - (long)var4_4));
                        var2_2 *= var2_2;
                        var4_4 = (int)((long)var4_4 + ((long)var3_3 - Test.instanceCount));
                        var2_2 = var1_1;
                        continue block7;
                    }
                    case 74: {
                        var4_4 = -1;
                        continue block7;
                    }
                    ** case 87:
lbl33:
                    // 2 sources

                    case 89: {
                        var9_8[var3_3 - 1] = (short)var5_5;
                    }
                }
            }
        }
        Test.vMeth_check_sum += (long)(var0 + var1_1 + var2_2) + Double.doubleToLongBits(var6_6) + (long)var3_3 + (long)var4_4 + (long)var5_5 + FuzzerUtils.checkSum(var8_7) + FuzzerUtils.checkSum(var9_8);
    }

    public void mainTest(String[] stringArray) {
        int n = 52929;
        int n2 = -5;
        int n3 = 6;
        int n4 = 61;
        float f = -92.28f;
        double d = 0.127586;
        instanceCount = -19053L;
        for (n = 2; n < 273; ++n) {
            n2 *= n << (int)((float)(n >>> n2) + f);
            n2 = iArrFld[n - 1];
            Test.vMeth();
            fFld = (float)d;
        }
        instanceCount -= (long)f;
        for (n3 = 12; 213 > n3; ++n3) {
            n4 += 191 + n3 * n3;
        }
        float[] fArray = fArrFld[(n >>> 1) % 400];
        fArray[183] = fArray[183] + 4.0f;
        FuzzerUtils.out.println("i i1 f = " + n + "," + n2 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("d3 i19 i20 = " + Double.doubleToLongBits(d) + "," + n3 + "," + n4);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.dArrFld Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }

    static {
        FuzzerUtils.init(iArrFld, -46777);
        FuzzerUtils.init(dArrFld, 60.85987);
        FuzzerUtils.init(fArrFld, 65.453f);
        vMeth_check_sum = 0L;
        vMeth1_check_sum = 0L;
        lMeth_check_sum = 0L;
    }
}

