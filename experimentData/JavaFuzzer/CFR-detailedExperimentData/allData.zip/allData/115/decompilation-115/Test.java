/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 8059626202638698049L;
    public static int iFld = -8;
    public static long iMeth_check_sum = 0L;
    public static long iMeth1_check_sum = 0L;
    public static long vMeth_check_sum = 0L;

    public static void vMeth() {
        int n = 10366;
        int n2 = 187;
        int n3 = 30724;
        int n4 = -132;
        int n5 = -84;
        int[] nArray = new int[400];
        double d = 1.3044;
        long l = 143L;
        long[][][] lArray = new long[400][400][400];
        boolean bl = false;
        int n6 = 31;
        float[][] fArray = new float[400][400];
        FuzzerUtils.init(nArray, 52023);
        FuzzerUtils.init((Object[][])lArray, (Object)-13L);
        FuzzerUtils.init(fArray, 80.593f);
        for (n = 16; n < 396; ++n) {
            d /= (double)(n | 1);
            for (l = 1L; l < 4L; ++l) {
                n2 += n2;
                n2 += (int)(l + (long)n);
                if (bl) continue;
                n2 += n2;
                d *= (double)l;
                n6 = (byte)(n6 + (byte)(l * l));
                n3 = n2;
                for (n4 = n; n4 < 2; ++n4) {
                    long[] lArray2 = lArray[(iFld >>> 1) % 400][(int)(l - 1L)];
                    int n7 = n - 1;
                    lArray2[n7] = lArray2[n7] >>> n;
                    float[] fArray2 = fArray[n4 + 1];
                    int n8 = n - 1;
                    fArray2[n8] = fArray2[n8] - (float)n5;
                    if (n3 == 0) continue;
                    vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + l + (long)n3 + (long)(bl ? 1 : 0) + (long)n6 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
                    return;
                }
            }
        }
        vMeth_check_sum += (long)(n + n2) + Double.doubleToLongBits(d) + l + (long)n3 + (long)(bl ? 1 : 0) + (long)n6 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum((Object[][])lArray) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArray));
    }

    public static int iMeth1(int n, float f, int n2) {
        int n3 = 64194;
        int n4 = -4;
        int n5 = 135;
        int n6 = -4340;
        int n7 = 34616;
        int n8 = 3;
        int[] nArray = new int[400];
        boolean bl = true;
        int n9 = 123;
        double d = -40.90322;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, 185);
        FuzzerUtils.init(lArray, -13937L);
        for (n3 = 10; n3 < 385; ++n3) {
            instanceCount += (long)(n3 * n3);
            Test.vMeth();
            block9: for (n5 = n3; n5 < 5; ++n5) {
                switch ((n >>> 1) % 6 * 5 + 39) {
                    case 52: {
                        for (n7 = 1; n7 < 1; ++n7) {
                            nArray[n5] = n4;
                            lArray[n3] = instanceCount;
                            n2 = (int)(instanceCount += (long)iFld);
                            n6 += (int)f;
                            f *= (float)instanceCount;
                        }
                        if (bl) {
                            n8 >>= (int)instanceCount;
                            n8 = (int)((long)n8 + ((long)n5 ^ instanceCount));
                            continue block9;
                        }
                        n = (int)((long)n + ((long)n5 * instanceCount + (long)n7 - (long)n3));
                        continue block9;
                    }
                    case 69: {
                        n8 += n5 * n5;
                        continue block9;
                    }
                    case 62: {
                        instanceCount = n3;
                        continue block9;
                    }
                    case 56: {
                        d = n8;
                        continue block9;
                    }
                    case 65: {
                        n4 <<= n5;
                        continue block9;
                    }
                    case 68: {
                        iFld = (int)((long)iFld + ((long)(n5 * iFld) + instanceCount - (long)n4));
                        continue block9;
                    }
                    default: {
                        nArray[n3 - 1] = (int)d;
                    }
                }
            }
        }
        long l = (long)(n + Float.floatToIntBits(f) + n2 + n3 + n4 + n5 + n6 + n7 + n8 + (bl ? 1 : 0) + n9) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(nArray) + FuzzerUtils.checkSum(lArray);
        iMeth1_check_sum += l;
        return (int)l;
    }

    public static int iMeth() {
        int n = -9;
        int n2 = 8;
        int n3 = -63556;
        int n4 = -63465;
        int n5 = 0;
        int n6 = -141;
        int n7 = -5;
        int[][] nArray = new int[400][400];
        float f = 110.576f;
        double d = 1.107505;
        FuzzerUtils.init(nArray, -215);
        iFld = (int)(++instanceCount);
        for (n = 141; n > 4; --n) {
            iFld >>= Integer.reverseBytes(Test.iMeth1(n, -93.958f, iFld)) / 1;
        }
        for (n3 = 7; n3 < 267; ++n3) {
            n2 = 56678;
            n2 >>= 11;
        }
        for (n5 = 17; n5 < 320; ++n5) {
            iFld = n2;
            instanceCount -= (long)f;
            for (d = (double)n5; d < 5.0; d += 1.0) {
                instanceCount = 15723L;
                int[] nArray2 = nArray[n5];
                int n8 = n5 - 1;
                nArray2[n8] = nArray2[n8] * n5;
                instanceCount = iFld += (int)(d * d);
                n4 += iFld;
            }
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n6 + Float.floatToIntBits(f)) + Double.doubleToLongBits(d) + (long)n7 + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public void mainTest(String[] stringArray) {
        int n = 20032;
        int n2 = 60363;
        int n3 = 228;
        int n4 = 18823;
        int n5 = -231;
        int n6 = 24658;
        int[] nArray = new int[400];
        int n7 = -31;
        float f = 1.475f;
        double d = -102.797;
        boolean bl = false;
        long[] lArray = new long[400];
        FuzzerUtils.init(nArray, -7);
        FuzzerUtils.init(lArray, -955183947397554756L);
        for (n = 9; 201 > n; ++n) {
            n3 = 1;
            block20: while (++n3 < 131) {
                nArray[n] = (int)f;
                n2 = (int)((double)n7 + ((double)nArray[n] - (d + -11.16715)));
                for (n4 = 1; n4 > 1; n4 -= 3) {
                    f += (float)(-140 + n4 * n4);
                    n5 |= (int)instanceCount;
                    nArray[n3 - 1] = (int)(--instanceCount);
                    instanceCount = (long)(d - 76.0);
                    n5 = (int)((long)n5 + ((long)(n4 * n3) + instanceCount - (long)n));
                    n2 = Test.iMeth();
                }
                iFld += iFld;
                n2 = (int)((long)n2 + ((long)(n3 * iFld) + instanceCount - (long)n4));
                switch ((n5 >>> 1) % 2 + 45) {
                    case 45: {
                        int n8 = n;
                        nArray[n8] = nArray[n8] * (int)instanceCount;
                        continue block20;
                    }
                    case 46: {
                        int n9 = n - 1;
                        nArray[n9] = nArray[n9] + n5;
                        switch ((n5 >>> 1) % 6 * 5 + 60) {
                            case 63: {
                                break;
                            }
                            case 73: {
                                f += (float)d;
                                if (bl) {
                                    n6 = 1;
                                    while (++n6 < 1) {
                                        n5 -= 2;
                                        switch (n % 5 + 111) {
                                            case 111: {
                                                instanceCount = n2 += n6;
                                            }
                                            case 112: {
                                                lArray[n3] = n4;
                                                int n10 = n6;
                                                nArray[n10] = nArray[n10] - n5;
                                                break;
                                            }
                                            case 113: {
                                                instanceCount -= instanceCount;
                                                break;
                                            }
                                            case 114: {
                                                instanceCount = n5;
                                            }
                                            case 115: {
                                                d = n4;
                                            }
                                        }
                                    }
                                    continue block20;
                                }
                                n2 <<= n4;
                                break;
                            }
                            case 66: {
                                n2 = (int)((long)n2 + ((long)n3 ^ instanceCount));
                                break;
                            }
                            case 87: {
                                n5 = n4;
                                break;
                            }
                            case 69: {
                                iFld = n5;
                                break;
                            }
                            case 88: {
                                nArray[n + 1] = 66;
                            }
                        }
                        continue block20;
                    }
                }
                int n11 = n;
                nArray[n11] = nArray[n11] - -37483;
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("by f d = " + n7 + "," + Float.floatToIntBits(f) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i3 i4 i25 = " + n4 + "," + n5 + "," + n6);
        FuzzerUtils.out.println("b2 iArr lArr2 = " + (bl ? 1 : 0) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(lArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld = " + instanceCount + "," + iFld);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

