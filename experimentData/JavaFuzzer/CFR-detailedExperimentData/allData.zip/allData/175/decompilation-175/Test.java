/*
 * Decompiled with CFR 0.152.
 */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -162L;
    public static volatile int iFld = 27866;
    public static float fFld = 42.615f;
    public static volatile double dFld = -2.7781;
    public static short sFld = (short)29534;
    public static boolean bFld = false;
    public static long vMeth_check_sum = 0L;
    public static long sMeth_check_sum = 0L;
    public static long iMeth_check_sum = 0L;

    public static int iMeth(int n) {
        int n2 = 44222;
        int n3 = -63977;
        int n4 = -14;
        int n5 = 8;
        int n6 = -25;
        int n7 = 5;
        int n8 = 0;
        int[] nArray = new int[400];
        int n9 = 14446;
        FuzzerUtils.init(nArray, -64739);
        for (n2 = 1; 244 > n2; ++n2) {
            instanceCount += (long)(n2 * n2);
            for (n4 = 1; 7 > n4; ++n4) {
                n3 = (int)((long)n3 + ((long)(n4 * n5) + instanceCount - (long)n9));
                instanceCount = n;
            }
            n6 = 1;
            do {
                float f = -2.763f;
                long l = 4L;
                f = instanceCount;
                n3 += n6 * n6 + iFld - n6;
                instanceCount += (long)n6 * l + l - (long)iFld;
            } while (++n6 < 7);
            n5 = (int)(instanceCount += (long)n);
            nArray[n2 - 1] = (int)fFld;
        }
        for (n7 = 13; n7 < 380; ++n7) {
            instanceCount = (long)((float)instanceCount + ((float)n7 + fFld));
            n = (int)dFld;
        }
        long l = (long)(n + n2 + n3 + n4 + n5 + n9 + n6 + n7 + n8) + FuzzerUtils.checkSum(nArray);
        iMeth_check_sum += l;
        return (int)l;
    }

    public static short sMeth(int n) {
        double d = -2.56164;
        int n2 = 64078;
        int n3 = -92;
        int n4 = 42308;
        byte[][][] byArray = new byte[400][400][400];
        long[] lArray = new long[400];
        FuzzerUtils.init((Object[][])byArray, (Object)-94);
        FuzzerUtils.init(lArray, 11671L);
        byte[] byArray2 = byArray[(n >>> 1) % 400][(n >>> 1) % 400];
        int n5 = (n >>> 1) % 400;
        instanceCount = Test.iMeth(iFld);
        byArray2[n5] = (byte)(byArray2[n5] - (byte)(instanceCount * (long)iFld));
        for (d = 1.0; d < 134.0; d += 1.0) {
            n += sFld;
            n *= n2;
        }
        instanceCount -= (long)n;
        for (n3 = 8; n3 < 171; ++n3) {
            n4 += n3 | (iFld -= (int)fFld);
            instanceCount += (long)(n3 * sFld + n3 - (iFld |= (int)instanceCount));
            iFld += (int)instanceCount;
        }
        switch (78) {
            case 75: {
                int n6 = (n3 >>> 1) % 400;
                lArray[n6] = lArray[n6] - (long)fFld;
                instanceCount <<= 35171436;
                instanceCount *= (long)n2;
                break;
            }
            case 71: {
                iFld += n;
                break;
            }
            case 77: {
                instanceCount = n4;
            }
        }
        long l = (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + FuzzerUtils.checkSum((Object[][])byArray) + FuzzerUtils.checkSum(lArray);
        sMeth_check_sum += l;
        return (short)l;
    }

    public static void vMeth(int n, double d) {
        int n2 = 62329;
        int n3 = -2;
        int n4 = 22414;
        int n5 = 72;
        int[] nArray = new int[400];
        FuzzerUtils.init(nArray, 58);
        n = Test.sMeth(n) + n;
        nArray[(n >>> 1) % 400] = iFld;
        n = 18151;
        n2 = 1;
        while (++n2 < 215) {
            for (n3 = 1; n3 < 7; ++n3) {
                switch (n3 % 1 * 5 + 116) {
                    case 119: {
                        fFld = 13.0f;
                        n5 = n4;
                        instanceCount += (long)(n3 - n4);
                        iFld = n3;
                        break;
                    }
                }
                n4 = n5;
                n5 *= (int)(instanceCount += (long)fFld);
                n += 198;
            }
        }
        vMeth_check_sum += (long)n + Double.doubleToLongBits(d) + (long)n2 + (long)n3 + (long)n4 + (long)n5 + FuzzerUtils.checkSum(nArray);
    }

    public void mainTest(String[] stringArray) {
        int n = 48942;
        int n2 = -9;
        int n3 = 24196;
        int n4 = 0;
        int n5 = -62266;
        int n6 = 30268;
        int n7 = 241;
        int[] nArray = new int[400];
        float f = 0.235f;
        float[][][] fArray = new float[400][400][400];
        int n8 = -31888;
        int n9 = -30;
        byte[] byArray = new byte[400];
        long[] lArray = new long[400];
        double[] dArray = new double[400];
        FuzzerUtils.init(lArray, -177L);
        FuzzerUtils.init(dArray, -88.6756);
        FuzzerUtils.init((Object[][])fArray, (Object)Float.valueOf(-21.24f));
        FuzzerUtils.init(nArray, 213);
        FuzzerUtils.init(byArray, (byte)-93);
        n = 1;
        while (++n < 166) {
            block18: for (n2 = 3; n2 < 151; ++n2) {
                for (n4 = 1; n4 < 2; ++n4) {
                    int n10 = n - 1;
                    long l = lArray[n10] - ++instanceCount;
                    lArray[n10] = l;
                    n5 = (int)(l + (long)n5);
                    int n11 = n4;
                    lArray[n11] = lArray[n11] | (long)n5;
                    int n12 = (n4 >>> 1) % 400;
                    lArray[n12] = lArray[n12] ^ Long.reverseBytes((long)((f - (float)n4) * (float)(instanceCount - (long)n5)));
                    n5 = n5-- * (int)(((long)(2.65315 + ((double)n2 + -31.31911)) << (int)(0xFFFFFFFFFC40F82DL ^ instanceCount + (long)n8)) / ((long)n5 - (instanceCount - -80L) | 1L));
                    Test.vMeth(n, dFld);
                    lArray = FuzzerUtils.long1array(400, -1768316691L);
                    n5 = (int)(f *= 267.0f);
                    iFld = n5 *= (int)instanceCount;
                }
                switch (n % 9 + 116) {
                    case 116: {
                        iFld += n2;
                        n6 = (int)((long)n6 + ((long)(n2 * n9) + instanceCount - instanceCount));
                        n3 += n2;
                        continue block18;
                    }
                    case 117: {
                        n5 += -110 + n2 * n2;
                        f *= (float)n4;
                        switch (n2 % 2 + 36) {
                            case 36: {
                                n7 = 1;
                                do {
                                    n3 = (int)dFld;
                                    n3 -= n;
                                    float[] fArray2 = fArray[n2][n - 1];
                                    int n13 = n + 1;
                                    fArray2[n13] = fArray2[n13] * (float)instanceCount;
                                    fFld += (float)((long)(n7 * n7) + instanceCount - (long)iFld);
                                    int n14 = n2 + 1;
                                    nArray[n14] = nArray[n14] * (int)instanceCount;
                                } while (++n7 < 2);
                                if (bFld) continue block18;
                            }
                            case 37: {
                                if (bFld) break;
                                int n15 = n + 1;
                                lArray[n15] = lArray[n15] - (long)n4;
                                break;
                            }
                            default: {
                                n5 += (int)f;
                            }
                        }
                    }
                    case 118: {
                        n3 += (int)dFld;
                        continue block18;
                    }
                    case 119: {
                        n6 += 12 + n2 * n2;
                        continue block18;
                    }
                    case 120: {
                        n6 = (int)instanceCount;
                    }
                    case 121: {
                        int n16 = n + 1;
                        byArray[n16] = (byte)(byArray[n16] * (byte)n4);
                        continue block18;
                    }
                    case 122: {
                        n3 = (int)((long)n3 + ((long)n2 * instanceCount + (long)n6 - (long)n3));
                    }
                    case 123: {
                        try {
                            iFld = n6 % n5;
                            n5 = nArray[n] / 168;
                            iFld = -490270453 / nArray[n - 1];
                        }
                        catch (ArithmeticException arithmeticException) {}
                        continue block18;
                    }
                    case 124: {
                        fArray[n + 1][n2][n2] = n3;
                    }
                    default: {
                        sFld = (short)(sFld + (short)(n2 * n4 + n - n3));
                    }
                }
            }
        }
        FuzzerUtils.out.println("i i1 i2 = " + n + "," + n2 + "," + n3);
        FuzzerUtils.out.println("i3 i4 f = " + n4 + "," + n5 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("s i22 by = " + n8 + "," + n6 + "," + n9);
        FuzzerUtils.out.println("i23 lArr dArr = " + n7 + "," + FuzzerUtils.checkSum(lArray) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArray)));
        FuzzerUtils.out.println("fArr iArr2 byArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][])fArray)) + "," + FuzzerUtils.checkSum(nArray) + "," + FuzzerUtils.checkSum(byArray));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.dFld Test.sFld Test.bFld = " + Double.doubleToLongBits(dFld) + "," + sFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] stringArray) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; ++i) {
                test.mainTest(stringArray);
            }
        }
        catch (Exception exception) {
            FuzzerUtils.out.println(exception.getClass().getCanonicalName());
        }
    }
}

