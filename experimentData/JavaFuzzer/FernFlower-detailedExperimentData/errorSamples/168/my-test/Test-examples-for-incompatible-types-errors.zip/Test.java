class Test {
	long lArrFld[];
	{
		int i24 = 13;
		lArrFld[i24] -=(long) 1.149F;
	}
}
