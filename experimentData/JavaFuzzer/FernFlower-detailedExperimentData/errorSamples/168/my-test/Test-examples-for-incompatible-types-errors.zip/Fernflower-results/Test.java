class Test {
   long[] lArrFld;

   Test() {
      byte var1 = 13;
      int var10002 = this.lArrFld[var1]--;
   }
}
