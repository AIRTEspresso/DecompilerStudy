class Test {
   int N = 400;
   float fFld = 0.731F;

   long lMeth(long var1) {
      short var4 = 214;
      int[] var5 = new int[this.N];
      var5[1] = 0;
      float var10000 = (float)var4;
      int var10003 = this.fFld--;
      int var10005 = var5[1];
      int var10002 = var5[1];
      var5[1] = var10005 - 1;
      int var8 = (int)(var10000 - var10003 * (float)var10002);
      return var1;
   }
}
