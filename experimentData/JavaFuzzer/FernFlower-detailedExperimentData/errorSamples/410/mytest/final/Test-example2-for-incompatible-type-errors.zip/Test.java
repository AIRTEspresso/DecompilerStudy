 class Test {
 	int N = 400;
 	float fFld=0.731F;
 	long lMeth(long l) {
 		int i2, i3 = 214 , iArr[] = new int[N];
 		iArr[1] = 0;
 		i3 -= fFld-- * iArr[1]--;
 		long meth_res = l;
 		return meth_res;
 	}
 }
