public class Test {
   public static final int N = 400;
   public static long instanceCount = 14L;
   public int iFld = -11;
   public byte byFld = 66;
   public static long lFld = 3769337865L;
   public short sFld = -7028;
   public static int iFld1 = 205;
   public volatile double dFld = 63.66422;
   public int[] iArrFld = new int[400];
   public static int[] iArrFld1 = new int[400];
   public volatile short[] sArrFld = new short[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 45190;
      int var5 = 173;
      int var6 = -12999;
      int var7 = 156;
      short var8 = 29112;
      boolean var9 = false;
      var2 >>= var0;
      int var12 = 1;

      do {
         lFld -= -7L;

         for(var4 = 5; var4 > 1; --var4) {
            var0 += var4;

            for(var6 = 1; var6 < 2; ++var6) {
               var5 = (int)((long)var5 + ((long)var6 - lFld));
               var5 = var1;

               try {
                  var0 = iArrFld1[var12 + 1] / -1066630903;
                  var7 = 355998573 % var4;
                  var7 = var12 / 6628;
               } catch (ArithmeticException var11) {
               }

               int[] var10000 = iArrFld1;
               var10000[var4 + 1] -= 1353235880;
               instanceCount <<= -1;
               if (var9) {
                  instanceCount += (long)var7;
                  instanceCount -= (long)var7;
               } else if (var9) {
                  var8 <<= (short)var1;
               } else {
                  var8 >>= (short)var2;
               }
            }
         }

         ++var12;
      } while(var12 < 320);

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var12 + var4 + var5 + var6 + var7 + var8 + (var9 ? 1 : 0));
   }

   public int iMeth(long var1) {
      boolean var3 = true;
      byte var4 = 10;
      int var5 = -14416;
      int var6 = -5;
      int var7 = 216;
      short var8 = 211;
      double var9 = -81.62522;
      float var11 = 107.349F;
      int[] var10000 = this.iArrFld;
      int var10001 = (this.iFld >>> 1) % 400;
      var10000[var10001] |= this.byFld - this.iArrFld[(this.iFld >>> 1) % 400];
      vMeth1(this.iFld, this.iFld, this.iFld);

      int var14;
      for(var14 = 10; var14 < 227; ++var14) {
         instanceCount = 3L;
         this.iArrFld[var14 + 1] = var4;

         for(var5 = var14; var5 < 7; ++var5) {
            var7 = 1;

            while(true) {
               ++var7;
               if (var7 >= 1) {
                  break;
               }

               switch (var7 % 9 * 5 + 14) {
                  case 24:
                     var6 += this.iFld;
                     this.byFld += (byte)(var7 + var4);
                     var11 = (float)var6;
                  case 25:
                  case 26:
                  case 27:
                  case 28:
                  case 29:
                  case 30:
                  case 31:
                  case 32:
                  case 33:
                  case 34:
                  case 36:
                  case 38:
                  case 41:
                  case 42:
                  case 43:
                  case 44:
                  case 46:
                  default:
                     break;
                  case 39:
                     var11 = (float)var5;
                     break;
                  case 40:
                     if (var14 != 0) {
                     }
                     break;
                  case 45:
                     var11 += (float)((long)(var7 * this.sFld + var8) - var1);
                     break;
                  case 47:
                     var9 = (double)var6;
                     break;
                  case 48:
                     var1 = (long)var14;
                     var6 = -112;
                     var9 = 2.0;
                     break;
                  case 49:
                     this.iFld >>= var8;
                  case 35:
                     var1 -= -2L;
                  case 37:
                     instanceCount += (long)(var7 * iFld1 + var7 - var14);
               }
            }
         }
      }

      long var12 = var1 + (long)var14 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + Double.doubleToLongBits(var9) + (long)Float.floatToIntBits(var11) + (long)var8;
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void vMeth(long var1, long var3) {
      int var5 = -33822;
      int var6 = -6;
      int var7 = 58993;
      int var8 = 8;
      int var9 = 215;
      int var10 = 108;
      int[] var11 = new int[400];
      double var12 = 66.828;
      float var14 = 0.37F;
      boolean var15 = true;
      long[] var16 = new long[400];
      FuzzerUtils.init((int[])var11, (int)-9);
      FuzzerUtils.init(var16, -9170342097933258973L);
      var5 = 1;

      do {
         if (!var15) {
            if (var15) {
               var3 = (long)this.iFld;
            } else {
               var8 += var5;
            }
         } else {
            var6 = 1;

            do {
               for(var7 = 1; var7 < 1; ++var7) {
                  var8 += var8;
               }

               var9 = 1;

               while(var9 < 1) {
                  switch (var5 % 1 + 27) {
                     case 27:
                     default:
                        try {
                           var10 = var5 / 6714;
                           var11[var5 + 1] = -1128238398 / var5;
                           var10 = var5 % 792512917;
                        } catch (ArithmeticException var18) {
                        }

                        var11[var5] = (int)((double)(var16[var6 + 1] - (long)var6) - (double)(179 * this.iMeth(var1)) * var12);
                        var10 = 6;
                        iFld1 = -197;
                        switch ((this.iFld >>> 1) % 1 + 113) {
                           case 113:
                           default:
                              var8 = (int)((long)var8 + ((long)var9 | (long)var14));
                              ++var9;
                        }
                  }
               }

               var8 = 63;
               var14 = (float)var8;
               ++var6;
            } while(var6 < 5);
         }

         ++var5;
      } while(var5 < 313);

      vMeth_check_sum += var1 + var3 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + Double.doubleToLongBits(var12) + (long)Float.floatToIntBits(var14) + (long)(var15 ? 1 : 0) + FuzzerUtils.checkSum(var11) + FuzzerUtils.checkSum(var16);
   }

   public void mainTest(String[] var1) {
      float var2 = 3.172F;
      boolean var3 = true;
      boolean var4 = true;
      byte var5 = 4;
      short var6 = -217;
      int var7 = -14;
      short var8 = 236;
      boolean var9 = true;
      boolean var10 = true;
      long var11 = 25631L;
      double[] var13 = new double[400];
      FuzzerUtils.init(var13, -121.117498);
      this.vMeth(instanceCount, -231L);
      var2 += (float)this.iFld;
      int var14 = 1;

      int var15;
      int var16;
      do {
         iFld1 += this.sFld;
         this.iFld *= (int)this.dFld;

         int[] var10000;
         for(var15 = 107; 6 < var15; --var15) {
            this.iFld = (int)((long)this.iFld + ((long)var15 * instanceCount + (long)var5 - (long)var15));
            this.iFld -= var15;
            var6 = 1;
            if (2 > var6) {
               instanceCount = (long)var14;
            }

            var10000 = iArrFld1;
            var10000[var15 + 1] <<= var5;
            var10 = var10;
            var10000 = iArrFld1;
            var10000[var15] *= (int)var2;
         }

         for(var11 = 107L; var11 > (long)var14; var11 -= 2L) {
            iFld1 += (int)(var11 * (long)var8 + (long)var6 - (long)var7);
            lFld += var11;
            var7 = var14;
            var10000 = this.iArrFld;
            var10000[var14 + 1] -= var14;
            short[] var17 = this.sArrFld;
            var17[(int)var11] *= (short)((int)var11);
            instanceCount += 57L + var11 * var11;
            iFld1 += (int)(var11 * (long)var14 + (long)var14 - (long)iFld1);
         }

         var7 *= this.sFld;
         var16 = 107;

         while(true) {
            --var16;
            if (var16 <= 0) {
               ++var14;
               break;
            }

            this.iFld += var14;
            iArrFld1[var14 - 1] = this.sFld;
            this.dFld += -2.047484256E9;
            iFld1 += var16;
            var13[var14] += (double)var14;
         }
      } while(var14 < 235);

      FuzzerUtils.out.println("f2 i20 i21 = " + Float.floatToIntBits(var2) + "," + var14 + "," + var15);
      FuzzerUtils.out.println("i22 i23 i24 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("b2 l3 i25 = " + (var10 ? 1 : 0) + "," + var11 + "," + var8);
      FuzzerUtils.out.println("i26 dArr = " + var16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)));
      FuzzerUtils.out.println("Test.instanceCount iFld byFld = " + instanceCount + "," + this.iFld + "," + this.byFld);
      FuzzerUtils.out.println("Test.lFld sFld Test.iFld1 = " + lFld + "," + this.sFld + "," + iFld1);
      FuzzerUtils.out.println("dFld iArrFld Test.iArrFld1 = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
      FuzzerUtils.out.println("sArrFld = " + FuzzerUtils.checkSum(this.sArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld1, (int)185);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
