public class Test {
   public static final int N = 400;
   public static long instanceCount = 3594617949L;
   public int iFld = -3;
   public float fFld = 0.124F;
   public static volatile short sFld = 9772;
   public boolean bFld = false;
   public static volatile byte byFld = -22;
   public static double[] dArrFld = new double[400];
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public int iMeth(int var1) {
      boolean var2 = true;
      int var3 = -193;
      int var4 = -119;
      byte var5 = -12;
      int var6 = -9715;
      boolean var7 = true;
      float var8 = -111.65F;
      byte var9 = 108;
      long var10 = -14L;
      ++var1;

      int var14;
      for(var14 = 19; var14 < 398; ++var14) {
         for(var4 = 1; var4 < 4; var4 += 2) {
            this.iFld = (int)instanceCount;

            for(var6 = 1; var6 < 4; ++var6) {
               dArrFld[var6] = (double)var8;
               instanceCount *= instanceCount;
            }

            instanceCount -= instanceCount;
            var9 = (byte)((int)instanceCount);
            var10 -= (long)var6;
            var3 = var4 * 21168;
            var10 += (long)(-26549 + var4 * var4);
         }
      }

      int var15 = (int)var8;
      long var12 = (long)(var1 + var14 + var3 + var4 + var5 + var6 + var15 + Float.floatToIntBits(var8) + var9) + var10;
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void vMeth1(float var1, int var2) {
      double var3 = -2.65346;
      boolean var5 = true;
      int var6 = -174;
      boolean var7 = true;
      int var8 = 4;
      int var9 = 5;
      int var10 = 9;
      long var11 = 112483535L;
      long[] var13 = new long[400];
      float[] var14 = new float[400];
      FuzzerUtils.init(var14, -68.326F);
      FuzzerUtils.init(var13, 1591523943L);
      var14[(this.iFld >>> 1) % 400] = (float)var3;

      int var15;
      for(var15 = 9; var15 < 148; ++var15) {
         var13 = var13;
      }

      int var16;
      for(var16 = 15; var16 < 257; ++var16) {
         var9 = 1;

         do {
            for(var11 = 1L; var11 < 1L; ++var11) {
               var2 += (int)(var11 - (long)this.iFld);
               this.iFld += this.iMeth(var15);
               dArrFld[var16 + 1] = (double)var11;
               var2 += (int)(var11 - (long)var10);
               var13[(int)var11] += (long)var16;
               var8 = (int)var1;
               var10 += (int)instanceCount;
               var6 >>>= var10;
               var10 = (int)((long)var10 + 2162L + var11 * var11);
            }

            ++var9;
         } while(var9 < 7);
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var1) + var2) + Double.doubleToLongBits(var3) + (long)var15 + (long)var6 + (long)var16 + (long)var8 + (long)var9 + var11 + (long)var10 + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)) + FuzzerUtils.checkSum(var13);
   }

   public void vMeth(double var1, long var3, double var5) {
      boolean var7 = true;
      boolean var8 = true;
      int var9 = 58;
      int var10 = -226;
      int var11 = 94;
      int var12 = 5457;
      int[] var13 = new int[400];
      byte var14 = 98;
      long[] var15 = new long[400];
      FuzzerUtils.init(var15, 2918919998L);
      FuzzerUtils.init((int[])var13, (int)7);
      int var18 = 139;

      while(true) {
         --var18;
         if (var18 <= 0) {
            int var19;
            for(var19 = 2; var19 < 348; ++var19) {
               for(var10 = 1; var10 < 5; ++var10) {
                  this.iFld += (int)instanceCount;
                  var11 >>= this.iFld;
                  var12 = 1;

                  while(true) {
                     ++var12;
                     if (var12 >= 2) {
                        break;
                     }

                     this.bFld = true;

                     try {
                        var9 = var13[var12 - 1] % 254;
                        this.iFld = var19 % var13[var12 - 1];
                        var13[var19] = var12 % var11;
                     } catch (ArithmeticException var17) {
                     }

                     var1 *= (double)sFld;
                     var11 = (int)var3;
                  }
               }
            }

            vMeth_check_sum += Double.doubleToLongBits(var1) + var3 + Double.doubleToLongBits(var5) + (long)var18 + (long)var14 + (long)var19 + (long)var9 + (long)var10 + (long)var11 + (long)var12 + FuzzerUtils.checkSum(var15) + FuzzerUtils.checkSum(var13);
            return;
         }

         this.iFld += this.iFld = (int)((long)var18 + var15[var18]);
         this.vMeth1(this.fFld, var18);
         this.iFld += var18 ^ var14;
         this.iFld >>>= var18;
         this.iFld <<= sFld;
      }
   }

   public void mainTest(String[] var1) {
      double var2 = -1.115433;
      int var4 = -231;
      int var5 = -239;
      byte var6 = 74;
      int var7 = 79;
      int var8 = -72;
      int var9 = -41365;
      int var10 = 11;
      int[][] var11 = new int[400][400];
      int[] var12 = new int[400];
      long[] var13 = new long[400];
      FuzzerUtils.init((int[][])var11, (int)-193);
      FuzzerUtils.init(var13, 2527083260L);
      FuzzerUtils.init((int[])var12, (int)5);
      this.vMeth(var2, instanceCount, var2);
      var2 = (double)this.iFld;
      this.iFld *= 142;
      int[] var10000 = var11[(this.iFld >>> 1) % 400];
      int var10001 = (this.iFld >>> 1) % 400;
      var10000[var10001] -= -2;
      var10001 = (this.iFld >>> 1) % 400;
      var13[var10001] >>>= (int)instanceCount;
      int[] var14 = var12;
      int var15 = var12.length;

      for(int var16 = 0; var16 < var15; ++var16) {
         int var18 = var14[var16];
         sFld = (short)this.iFld;
         int var17 = (int)instanceCount;
         this.iFld = (int)instanceCount;
         var12[(this.iFld >>> 1) % 400] = this.iFld;
         var10000 = iArrFld;
         var10000[(var17 >>> 1) % 400] *= (int)instanceCount;
         var4 = 1;

         do {
            var17 <<= var17;
            var17 -= this.iFld;
            var11[var4 - 1][var4 - 1] = var4;
            this.fFld -= (float)instanceCount;
            this.bFld = this.bFld;
            this.iFld -= (int)var2;
            ++var4;
         } while(var4 < 63);

         for(var5 = 63; var5 > 1; var5 -= 2) {
            for(var7 = var5; var7 < 3; ++var7) {
               var17 += var7;
            }

            instanceCount += (long)sFld;
            if (this.bFld) {
               break;
            }
         }

         var11[(var6 >>> 1) % 400][0] = var4;
         if (this.bFld) {
            for(var9 = 3; var9 < 63; ++var9) {
               var8 >>= var8;
               this.fFld = (float)byFld;
               instanceCount += (long)var4;
            }
         } else if (this.bFld) {
            var8 /= 88;
         } else {
            var10 >>= (int)instanceCount;
         }
      }

      FuzzerUtils.out.println("d3 i21 i22 = " + Double.doubleToLongBits(var2) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i23 i24 i25 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i26 i27 iArr1 = " + var9 + "," + var10 + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("lArr2 iArr2 = " + FuzzerUtils.checkSum(var13) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount iFld fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.sFld bFld Test.byFld = " + sFld + "," + (this.bFld ? 1 : 0) + "," + byFld);
      FuzzerUtils.out.println("Test.dArrFld Test.iArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 0.98955);
      FuzzerUtils.init((int[])iArrFld, (int)13);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
