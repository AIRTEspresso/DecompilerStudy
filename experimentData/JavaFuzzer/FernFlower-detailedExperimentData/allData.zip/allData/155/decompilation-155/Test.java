public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -4896260308601194030L;
   public static volatile float fFld = -97.216F;
   public static short sFld = -10287;
   public static byte byFld = -22;
   public static int[] iArrFld = new int[400];
   public static long lMeth_check_sum;
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1() {
      double var0 = 100.75751;
      double var2 = -1.91412;
      boolean var4 = true;
      int var5 = 170;
      int var6 = 14;
      int var7 = 196;
      int var8 = 0;
      float var9 = -71.42F;
      var0 *= (double)instanceCount;
      var2 -= (double)instanceCount;

      int var12;
      for(var12 = 9; var12 < 320; ++var12) {
         for(var6 = 5; var6 > 1; var6 -= 3) {
            boolean var10 = false;
            fFld *= (float)var0;
            var7 >>= var7;
            if (var10) {
               for(var9 = 1.0F; var9 < 5.0F; ++var9) {
                  var7 += (int)(var9 * var9);
                  instanceCount += (long)var2;
                  var5 += var5;
                  sFld += sFld;
                  var8 += var8;
                  var8 = byFld;
               }
            }

            iArrFld[var12] = var5;
         }
      }

      long var13 = Double.doubleToLongBits(var0) + Double.doubleToLongBits(var2) + (long)var12 + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var9) + (long)var8;
      iMeth1_check_sum += var13;
      return (int)var13;
   }

   public static int iMeth(int var0, int var1) {
      boolean var2 = true;
      int var3 = 120;
      int var4 = -72;
      int var5 = -14;
      int var6 = 15849;
      int var7 = 7573;
      byte var8 = 2;
      boolean var9 = true;
      double var10 = 0.70164;
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, 142960554L);

      int var16;
      for(var16 = 19; var16 < 384; ++var16) {
         var12[var16 + 1] = (long)(iArrFld[var16] * iMeth1() + var0);
         if (var9) {
            break;
         }

         for(var4 = 1; var4 < 5; ++var4) {
            if (var9) {
               try {
                  iArrFld[var16 + 1] = var5 % -1322244732;
                  var5 = var4 % -54194;
                  var1 = var4 / iArrFld[var16 + 1];
               } catch (ArithmeticException var15) {
               }

               var3 = (int)((long)var3 + ((long)var4 * instanceCount + (long)var1 - (long)var0));
               var6 = (int)instanceCount;
               var7 = 2;

               do {
                  var3 >>= var3;
                  var9 = var9;
                  var0 = (int)instanceCount;
                  var10 = (double)var8;
                  var5 = (int)instanceCount;
                  var7 -= 3;
               } while(var7 > 0);
            } else {
               instanceCount = (long)fFld;
            }
         }
      }

      long var13 = (long)(var0 + var1 + var16 + var3 + (var9 ? 1 : 0) + var4 + var5 + var6 + var7) + Double.doubleToLongBits(var10) + (long)var8 + FuzzerUtils.checkSum(var12);
      iMeth_check_sum += var13;
      return (int)var13;
   }

   public long lMeth(int var1, int var2) {
      boolean var3 = true;
      int var4 = -202;
      int var5 = 234;
      int var6 = 33;
      int var7 = -54699;
      byte var8 = 9;
      var1 -= iMeth(var1, var1);
      var2 <<= sFld;

      int var11;
      for(var11 = 169; var11 > 7; var11 -= 3) {
         iArrFld = iArrFld;
         instanceCount |= (long)var2;
         instanceCount ^= (long)var4;

         for(var5 = 1; var5 < 28; ++var5) {
            for(var7 = 1; var7 < 2; ++var7) {
               var4 &= var5;
               instanceCount += (long)var7;
               instanceCount += (long)var7;
            }

            var6 /= -47;
            instanceCount = (long)var4;
            var1 = (int)((long)var1 + ((long)var5 ^ instanceCount));
         }
      }

      int[] var10000 = iArrFld;
      var10000[388] *= var1;
      long var9 = (long)(var1 + var2 + var11 + var4 + var5 + var6 + var7 + var8);
      lMeth_check_sum += var9;
      return var9;
   }

   public void mainTest(String[] var1) {
      int var2 = -29049;
      boolean var3 = true;
      int var4 = -9940;
      int var5 = -13;
      var2 <<= (int)((float)(this.lMeth(var2, var2) * (long)var2) - fFld);
      instanceCount += 10L;

      int var6;
      for(var6 = 2; var6 < 164; ++var6) {
         var4 ^= var5;
         byFld = (byte)sFld;
         var5 += 25200;
      }

      int[] var10000 = iArrFld;
      var10000[(var4 >>> 1) % 400] ^= (int)instanceCount;
      instanceCount = (long)var2;
      FuzzerUtils.out.println("i i23 i24 = " + var2 + "," + var6 + "," + var4);
      FuzzerUtils.out.println("i25 = " + var5);
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
      FuzzerUtils.out.println("Test.byFld Test.iArrFld = " + byFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)43661);
      lMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
