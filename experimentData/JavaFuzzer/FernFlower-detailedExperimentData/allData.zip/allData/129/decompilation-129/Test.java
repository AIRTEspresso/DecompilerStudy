public class Test {
   public static final int N = 400;
   public static long instanceCount = -9197421431258648103L;
   public static float fFld = -2.584F;
   public static int iFld = 5;
   public static boolean bFld = true;
   public static volatile int iFld1 = 38602;
   public double dFld = -15.3741;
   public static long iMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long lMeth_check_sum = 0L;

   public static long lMeth(boolean var0, byte var1, long var2) {
      long var4 = -8255520576848102185L;
      int var6 = -46813;
      int var7 = -9;
      int var8 = -13;
      byte var9 = -6;
      int var10 = -35261;
      int[] var11 = new int[400];
      short var12 = -17359;
      boolean var13 = true;
      FuzzerUtils.init((int[])var11, (int)-29303);

      for(var4 = 1L; 134L > var4; ++var4) {
         for(var7 = 1; var7 < 12; ++var7) {
            var8 |= var8;
            var12 = (short)var1;
            var6 += var7;
            var6 += -14 + var7 * var7;
            var6 += var8;
         }

         switch ((int)(var4 % 3L * 5L + 66L)) {
            case 71:
               fFld += -10301.0F;
               var11[(int)(var4 + 1L)] += (int)instanceCount;
               var6 += var8;
            case 73:
            default:
               break;
            case 74:
               if (var13) {
                  break;
               }
            case 72:
               var8 /= var8 | 1;
         }
      }

      long var14 = (long)((var0 ? 1 : 0) + var1) + var2 + var4 + (long)var6 + (long)var7 + (long)var8 + (long)var12 + (long)var9 + (long)var10 + (long)(var13 ? 1 : 0) + FuzzerUtils.checkSum(var11);
      lMeth_check_sum += var14;
      return var14;
   }

   public static void vMeth(long var0) {
      double var2 = 0.118181;
      byte var4 = 111;
      boolean var5 = true;
      int var6 = -20569;
      int var7 = -4;
      short var8 = -177;
      int var9 = 33738;
      byte var10 = 6;
      byte var11 = 77;
      int[] var12 = new int[400];
      long var13 = 227L;
      FuzzerUtils.init((int[])var12, (int)4);
      var2 = 1.0;

      int var16;
      do {
         int var15 = 203;
         var15 = Math.abs(var15) - var12[(int)(var2 + 1.0)] - (var15 + var4 - var15);

         for(var16 = 1; var16 < 5; ++var16) {
            for(var7 = 1; var7 < 2; ++var7) {
               var6 = (int)((long)var6 + ((long)var7 ^ instanceCount));
            }

            for(var9 = 1; var9 < 2; ++var9) {
               var6 += var9;
               var4 |= (byte)((int)(58.0F - (fFld + -2.864F + (float)var6)));
               var12[var9] *= (int)(((double)(var16 * var10) + (var2 - (double)var10)) * (double)(++instanceCount - (long)(-(30233 - (var9 + var9)))));
               var15 %= (int)(lMeth(bFld, var4, 12L) | 1L);
               if (bFld) {
                  break;
               }

               iFld += 142;
            }

            for(var13 = 1L; var13 < 2L; ++var13) {
               var6 += var11;
               fFld += (float)(var13 * (long)iFld + instanceCount - (long)var8);
            }
         }
      } while(++var2 < 323.0);

      vMeth_check_sum += var0 + Double.doubleToLongBits(var2) + (long)var4 + (long)var16 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + var13 + (long)var11 + FuzzerUtils.checkSum(var12);
   }

   public static int iMeth(long var0, int var2) {
      short var3 = -5847;
      boolean var4 = true;
      short var5 = 2781;
      boolean var6 = true;
      char var7 = '늌';
      int[] var8 = new int[400];
      byte var9 = 117;
      long[] var10 = new long[400];
      FuzzerUtils.init(var10, -6L);
      FuzzerUtils.init((int[])var8, (int)-29624);
      vMeth(instanceCount);
      var10[0] = instanceCount;
      var8[356] -= var2;
      var3 -= (short)var2;

      int var14;
      for(var14 = 12; var14 < 283; ++var14) {
         instanceCount = -177L;
         var9 = (byte)(var9 * 108);
         char var13 = 'ꒊ';
         var10[var14] = (long)fFld;
         var2 = -10;
      }

      iFld = -123;

      int var15;
      for(var15 = 13; var15 < 389; ++var15) {
         var0 <<= var5;
         iFld = var2;
         fFld *= -8.0F;
      }

      long var11 = var0 + (long)var2 + (long)var3 + (long)var14 + (long)var5 + (long)var9 + (long)var15 + (long)var7 + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -130;
      boolean var4 = true;
      int var5 = 51760;
      boolean var6 = true;
      boolean var7 = true;
      int var8 = -14;
      boolean var9 = true;
      int var10 = -15920;
      int[] var11 = new int[400];
      float var12 = 0.48F;
      byte var13 = 74;
      short var14 = -2402;
      FuzzerUtils.init((int[])var11, (int)-141);
      int var15 = 1;

      int var17;
      int var18;
      int var19;
      int var20;
      do {
         var12 *= (float)(var3++ - var11[var15]);
         var11[var15] *= Math.max(var3, (int)(instanceCount * (long)var3)) + Math.min(var15, -34466 * iMeth(instanceCount, var3));
         var13 = (byte)(var13 + 118);
         var11[var15 + 1] = iFld;
         iFld = var15;

         for(var17 = 5; var17 < 186; ++var17) {
            var3 += var17 | var5;
            iFld = iFld1;
            iFld += iFld1;
            var11[var17] -= var3;
            var14 <<= -30424;
         }

         iFld += var17;
         var18 = 1;

         do {
            for(var19 = 1; var19 < 1; ++var19) {
               var8 -= (int)instanceCount;
               int var10000 = var5 + var19 * var19;
               var12 -= (float)iFld;
               short var16 = 132;
               var3 = var16 + '\ud9cc';
               var5 = var18 | var14;
               var11[var19] += (int)instanceCount;
               var11[var15 - 1] <<= var3;
            }

            var12 += var12;

            for(var20 = 1; var20 < 1; ++var20) {
               var10 = -42598;
               this.dFld += 50540.0;
               this.dFld -= (double)iFld;
               var10 = (int)((long)var10 + ((long)var20 ^ (long)fFld));
            }

            ++var18;
         } while(var18 < 186);

         ++var15;
      } while(var15 < 135);

      FuzzerUtils.out.println("i f i1 = " + var15 + "," + Float.floatToIntBits(var12) + "," + var3);
      FuzzerUtils.out.println("by3 i20 i21 = " + var13 + "," + var17 + "," + var5);
      FuzzerUtils.out.println("s2 i22 i23 = " + var14 + "," + var18 + "," + var19);
      FuzzerUtils.out.println("i24 i25 i26 = " + var8 + "," + var20 + "," + var10);
      FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
      FuzzerUtils.out.println("Test.bFld Test.iFld1 dFld = " + (bFld ? 1 : 0) + "," + iFld1 + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
