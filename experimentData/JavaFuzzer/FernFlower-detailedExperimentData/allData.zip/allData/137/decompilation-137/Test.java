public class Test {
   public static final int N = 400;
   public static long instanceCount = 50760L;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1) {
      boolean var2 = true;
      byte var3 = -91;
      float var4 = 0.685F;
      float var5 = 2.16F;
      byte var6 = 122;
      boolean var7 = false;
      double var8 = -2.12627;
      instanceCount = instanceCount;
      var0 = (int)instanceCount;
      int var10 = 1;

      do {
         var4 = (float)var1;
         var6 += (byte)((int)instanceCount);
         var0 += var10;
         var0 += var10;
         var6 >>>= (byte)((int)instanceCount);
         var1 += 9;
         var1 >>= 12;
         if (var7) {
            break;
         }

         for(var5 = 6.0F; 1.0F < var5; --var5) {
            var8 = (double)var0;
            var0 += (int)(var5 * var5);
            int[] var10000 = iArrFld;
            var10000[(int)(var5 - 1.0F)] -= 196;
         }

         ++var10;
      } while(var10 < 257);

      vMeth1_check_sum += (long)(var0 + var1 + var10 + Float.floatToIntBits(var4) + var6 + (var7 ? 1 : 0) + Float.floatToIntBits(var5) + var3) + Double.doubleToLongBits(var8);
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = 233;
      boolean var2 = true;
      char var3 = '쐜';
      short var4 = -24032;
      short[] var5 = new short[400];
      float var6 = -75.288F;
      float[] var7 = new float[400];
      long var8 = 77L;
      long[] var10 = new long[400];
      FuzzerUtils.init(var5, (short)-16151);
      FuzzerUtils.init(var7, 4.417F);
      FuzzerUtils.init(var10, 33896L);
      int var13 = 1;

      int var14;
      do {
         try {
            var1 = iArrFld[var13 + 1] % -2083200514;
            var1 = -12447 / var1;
            var1 %= -470138837;
         } catch (ArithmeticException var12) {
         }

         instanceCount = (long)(var4--);
         var5 = FuzzerUtils.short1array(400, (short)8297);
         int var10002 = var13 - 1;
         float var10004 = var7[var13 - 1];
         var7[var10002] = var7[var13 - 1] - 1.0F;
         var1 += (int)var10004;
         var6 = (float)Math.abs(var13) - --var6 + (float)(var1--);
         int[] var16 = iArrFld;
         var16[var13] += (int)var10[var13];
         var14 = 13;

         while(true) {
            --var14;
            if (var14 <= 0) {
               ++var13;
               break;
            }

            instanceCount += (long)(var6-- + var6);
            var1 = var14 * (var13 - var13 + var1 + var13);
            vMeth1(var14, -64);
            instanceCount += -12L;

            for(var8 = 1L; var8 < 1L; var8 += 3L) {
               var6 += (float)var1;
               var16 = iArrFld;
               var16[var13 + 1] >>>= var3;
            }
         }
      } while(var13 < 123);

      vMeth_check_sum += (long)(var13 + var1 + var4 + Float.floatToIntBits(var6) + var14) + var8 + (long)var3 + FuzzerUtils.checkSum(var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + FuzzerUtils.checkSum(var10);
   }

   public static int iMeth(int var0, long var1) {
      double var3 = 0.111255;
      boolean var5 = true;
      float var6 = -18.954F;
      int var7 = 8280;
      long[][][] var8 = new long[400][400][400];
      FuzzerUtils.init((Object[][])var8, -12L);
      var3 = 1.0;

      while(++var3 < 361.0) {
         var0 = var0;
         int var10002 = iArrFld[(int)(var3 + 1.0)]++;
         vMeth();
      }

      byte var11 = 4;
      instanceCount <<= 11096;
      var8[42][61] = var8[(var0 >>> 1) % 400][(var0 >>> 1) % 400];
      var0 = var0;

      for(var6 = 236.0F; var6 > 3.0F; --var6) {
         var7 = (int)((float)var7 + -20827.0F + var6 * var6);
         var7 -= (int)var6;
         var0 += (int)var6;
         int[] var10000 = iArrFld;
         var10000[(int)var6] += var0;
         var10000 = iArrFld;
         var10000[(int)(var6 - 1.0F)] *= (int)var1;
         var7 += (int)(var6 + (float)instanceCount);
      }

      long var9 = (long)var0 + var1 + Double.doubleToLongBits(var3) + (long)var11 + (long)Float.floatToIntBits(var6) + (long)var7 + FuzzerUtils.checkSum((Object[][])var8);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void mainTest(String[] var1) {
      int var2 = 5;
      var2 = (int)((long)(var2++) - (instanceCount + (long)var2) + (long)(var2 + iMeth(var2, instanceCount)));
      var2 ^= var2;
      instanceCount = 0L;
      FuzzerUtils.out.println("i = " + var2);
      FuzzerUtils.out.println("Test.instanceCount Test.iArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)178);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
