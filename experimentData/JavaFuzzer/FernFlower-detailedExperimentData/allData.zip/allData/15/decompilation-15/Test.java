public class Test {
   public static final int N = 400;
   public static long instanceCount = 34275L;
   public static float fFld = -56.119F;
   public static long lFld = 2012182374L;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long vMeth2_check_sum = 0L;

   public static void vMeth2(int var0, int var1, float var2) {
      boolean var3 = true;
      int var4 = 3923;
      boolean var5 = true;
      byte var6 = 2;
      int[] var7 = new int[400];
      long var8 = -1125702414L;
      long[][] var10 = new long[400][400];
      double var11 = -2.18765;
      boolean var13 = true;
      FuzzerUtils.init(var10, -66L);
      FuzzerUtils.init((int[])var7, (int)7);

      int var14;
      for(var14 = 373; var14 > 18; var14 -= 3) {
         instanceCount = (long)var4;
      }

      var10 = FuzzerUtils.long2array(400, 2863929807L);
      var10[8][(var14 >>> 1) % 400] |= instanceCount;
      int var15 = 1;

      do {
         var4 += (int)fFld;
         ++var15;
      } while(var15 < 360);

      var2 = (float)instanceCount;
      var1 = var15;

      for(var8 = 1L; var8 < 221L; ++var8) {
         var1 *= (int)var2;
         var11 *= (double)var6;
         var1 >>= var0;
         var13 = var13;
         var7[(int)var8] *= 1816082270;
      }

      var1 %= 12210;
      vMeth2_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + var14 + var4 + var15) + var8 + (long)var6 + Double.doubleToLongBits(var11) + (long)(var13 ? 1 : 0) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var7);
   }

   public static void vMeth1() {
      int var0 = 6;
      var0 = (int)((long)var0 + (long)(var0 + var0) + (long)var0 + instanceCount);
      vMeth2(-3, -30, fFld);
      vMeth1_check_sum += (long)var0;
   }

   public static void vMeth(int var0, short var1) {
      boolean var2 = true;
      byte var3 = 3;
      int var4 = -3;
      int var5 = -154;
      int var6 = 69;
      int var7 = 248;
      int[] var8 = new int[400];
      double var9 = -112.3736;
      byte var11 = -18;
      boolean var12 = false;
      FuzzerUtils.init((int[])var8, (int)5);

      int var13;
      for(var13 = 291; var13 > 10; var13 -= 2) {
         instanceCount += (long)var4;
         int var10000 = var4 + '锃' + var13 * var13;
         int var10001 = var13 - 1;
         int var10003 = var8[var13 - 1];
         var8[var10001] = var8[var13 - 1] + 1;
         var4 = (int)((double)var10003 + ((double)(++fFld) - -15.49521 % (double)(instanceCount++ | 1L)));

         label42:
         for(var9 = 11.0; var9 > 1.0; --var9) {
            var5 += (int)(var9 * var9);
            switch (((int)(-77L * -instanceCount) >>> 1) % 10 + 90) {
               case 90:
                  ++var5;
                  var5 = var5;
                  vMeth1();
                  lFld = (long)var5;
                  break;
               case 91:
                  fFld = (float)var0;
                  break;
               case 92:
                  var6 = 1;

                  while(true) {
                     if (var6 >= 2) {
                        continue label42;
                     }

                     var11 += (byte)var6;
                     var12 = var12;
                     var5 = var6++;
                  }
               case 93:
                  var5 += (int)instanceCount;
                  break;
               case 94:
                  var4 <<= var7;
                  break;
               case 95:
                  lFld += (long)var9;
                  break;
               case 96:
                  var5 = -173;
                  break;
               case 97:
                  var5 = 3182;
               case 98:
                  var7 += (int)var9;
                  break;
               case 99:
                  var8 = var8;
                  break;
               default:
                  var7 = var0;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var13 + var3 + var4) + Double.doubleToLongBits(var9) + (long)var5 + (long)var6 + (long)var7 + (long)var11 + (long)(var12 ? 1 : 0) + FuzzerUtils.checkSum(var8);
   }

   public void mainTest(String[] var1) {
      float var2 = 0.175F;
      int var3 = -54588;
      boolean var4 = true;
      int var5 = -62054;
      int var6 = -213;
      int var7 = -4;
      int var8 = -7;
      int var9 = -199;
      int var10 = 11;
      int[][] var11 = new int[400][400];
      short var12 = -9733;
      short var13 = -8487;
      double var14 = 2.25882;
      double var16 = -68.91371;
      FuzzerUtils.init((int[][])var11, (int)-24385);
      var2 *= (float)Long.reverseBytes((long)(var3 - (var3 + var3)));
      vMeth(var3, var12);
      int var21 = 1;

      while(true) {
         ++var21;
         if (var21 >= 316) {
            var13 += (short)var3;
            instanceCount = (long)var21;

            try {
               var5 = 1;

               do {
                  var3 += var5;

                  for(var6 = var5; var6 < 481; ++var6) {
                     label93: {
                        label63: {
                           switch (var5 % 7 + 53) {
                              case 53:
                              case 54:
                                 instanceCount %= (long)(var5 | 1);
                                 break label93;
                              case 55:
                                 int var10000 = var3 - (int)var14;
                                 byte var20 = 0;

                                 for(var8 = 1; var8 < 1; ++var8) {
                                    lFld += (long)fFld;
                                    instanceCount += (long)var8;
                                 }

                                 var3 = var20 >>> (int)lFld;
                              case 56:
                                 break;
                              case 57:
                                 for(var16 = 1.0; var16 < 401.0; ++var16) {
                                    var10 = var5;
                                 }

                                 var2 += -5.0F;
                              case 58:
                                 var2 *= -2.0F;
                              case 59:
                                 break label63;
                              default:
                                 lFld += -39L;
                                 break label93;
                           }

                           var3 += var6 * var6;
                           var11[var5 - 1][var5] = var3;
                           var11[var6] = var11[var6 - 1];
                           break label93;
                        }

                        var7 = var6;
                        instanceCount += (long)var3;
                        var9 -= var10;
                     }

                     instanceCount -= lFld;
                  }

                  ++var5;
               } while(var5 < 311);
            } catch (ArrayIndexOutOfBoundsException var19) {
               var11[5] = var11[366];
            }

            FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(var2) + "," + var3 + "," + var12);
            FuzzerUtils.out.println("i15 s2 i16 = " + var21 + "," + var13 + "," + var5);
            FuzzerUtils.out.println("i17 i18 d2 = " + var6 + "," + var7 + "," + Double.doubleToLongBits(var14));
            FuzzerUtils.out.println("i19 i20 d3 = " + var8 + "," + var9 + "," + Double.doubleToLongBits(var16));
            FuzzerUtils.out.println("i21 iArr2 = " + var10 + "," + FuzzerUtils.checkSum(var11));
            FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         fFld -= (float)var3;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
