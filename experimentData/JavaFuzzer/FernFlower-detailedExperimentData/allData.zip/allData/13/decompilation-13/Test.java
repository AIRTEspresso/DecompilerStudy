public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -216L;
   public static float fFld = -61.376F;
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(int var0) {
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -7;
      int var4 = 32523;
      boolean var5 = true;
      short var6 = 237;
      int[] var7 = new int[400];
      float var8 = 0.224F;
      short var9 = 24645;
      double var10 = -100.122643;
      byte[] var12 = new byte[400];
      FuzzerUtils.init(var12, (byte)-111);
      FuzzerUtils.init((int[])var7, (int)-5993);
      int var15 = 1;

      int var16;
      int var17;
      do {
         for(var16 = var15; 8 > var16; ++var16) {
            var12[var16 + 1] = (byte)((int)fFld);

            for(var8 = 1.0F; 1.0F > var8; ++var8) {
               var3 += (int)((long)var8 ^ (long)var9);
               var0 -= var4;
               var0 *= var3;
               var12[(int)(var8 + 1.0F)] *= (byte)var0;
               var0 = var4;
               lArrFld = lArrFld;
            }
         }

         for(var17 = 1; 8 > var17; ++var17) {
            var7[var17 + 1] = var0;
            var4 *= (int)var10;
            var3 = -2;
            var4 -= (int)fFld;
         }

         ++var15;
      } while(var15 < 212);

      long var13 = (long)(var0 + var15 + var16 + var3 + Float.floatToIntBits(var8) + var4 + var9 + var17 + var6) + Double.doubleToLongBits(var10) + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var7);
      iMeth_check_sum += var13;
      return (int)var13;
   }

   public static void vMeth1(double var0) {
      int var2 = -51287;
      int var3 = 24534;
      int var4 = -36668;
      byte var5 = -8;
      int[] var6 = new int[400];
      byte var7 = 99;
      float[] var8 = new float[400];
      FuzzerUtils.init((int[])var6, (int)-30115);
      FuzzerUtils.init(var8, -93.2F);
      int[] var9 = var6;
      int var10 = var6.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var12 = var9[var11];
         double var10000 = (double)((199.0F + fFld) * (float)(instanceCount + (long)var12));
         ++var12;
         var12 = (int)(var10000 - ((double)var12 + var0 * (double)var12));

         for(var2 = 1; var2 < 4; ++var2) {
            var12 += (int)((var0 = (double)var3) - (double)(var3--) + (double)(--lArrFld[var2]));
            var6[var2] >>= iMeth(var12);

            for(var4 = 1; var4 < 2; ++var4) {
               var0 = (double)instanceCount;
               var7 += (byte)((int)((long)var4 * instanceCount + (long)var7 - (long)var4));
               var12 -= var4;
            }
         }

         fFld = (float)var5;
         var12 <<= var5;
         var3 >>= 0;
         var6[(var12 >>> 1) % 400] = (int)instanceCount;
         instanceCount *= (long)var3;
         var8[(var4 >>> 1) % 400] -= (float)var4;
      }

      vMeth1_check_sum += Double.doubleToLongBits(var0) + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var7 + FuzzerUtils.checkSum(var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
   }

   public static void vMeth(int var0, int var1, int var2) {
      double var3 = 1.23456;
      int var5 = -63777;
      byte var6 = 9;
      int var7 = -10;
      int[] var8 = new int[400];
      FuzzerUtils.init((int[])var8, (int)60);
      vMeth1(var3);

      for(var5 = 157; var5 > 8; var5 -= 2) {
         if (var5 != 0) {
            vMeth_check_sum += (long)(var0 + var1 + var2) + Double.doubleToLongBits(var3) + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
            return;
         }

         try {
            var0 = var7 / -56624;
            var7 = var0 % var1;
            var0 = var8[var5] / var8[var5];
         } catch (ArithmeticException var10) {
         }

         var2 += '놑' + var5 * var5;
         instanceCount = (long)((float)instanceCount + ((float)(var5 * var7 + var6) - fFld));
         var2 += var5;
      }

      vMeth_check_sum += (long)(var0 + var1 + var2) + Double.doubleToLongBits(var3) + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
   }

   public void mainTest(String[] var1) {
      int var2 = -4;
      int var3 = -64252;
      int var4 = 40601;
      int var5 = 119;
      byte var6 = 31;
      int[][] var7 = new int[400][400];
      short var8 = 22418;
      long var9 = -14L;
      boolean var11 = false;
      boolean[] var12 = new boolean[400];
      float var13 = 61.641F;
      byte var14 = -67;
      double var15 = -2.117728;
      FuzzerUtils.init((int[][])var7, (int)85);
      FuzzerUtils.init(var12, false);
      var2 = var7[(var2 >>> 1) % 400][(var2 >>> 1) % 400] + var2 * var8;
      vMeth(var2, var2, var2);
      instanceCount += (long)fFld;
      var7[(var2 >>> 1) % 400][1] -= var2;
      var2 = var2;
      var9 -= (long)var2;

      for(var3 = 9; var3 < 268; ++var3) {
         var12[var3] = var11;
         if (var11) {
            fFld *= fFld;
            var13 = 1.0F;

            do {
               var5 = 1;

               while(true) {
                  ++var5;
                  if (var5 >= 1) {
                     break;
                  }

                  instanceCount = (long)var2;
                  switch ((var5 >>> 1) % 6 + 100) {
                     case 100:
                        var4 += var5 * var2 + var5 - var8;
                        var11 = var11;
                     case 101:
                        var7[var3 + 1][var3 + 1] = (int)var9;
                        var9 ^= (long)var3;
                        var4 -= var4;
                        break;
                     case 102:
                        var9 = (long)var4;
                        instanceCount *= (long)var3;
                        long[] var10000 = lArrFld;
                        var10000[(int)(var13 - 1.0F)] -= 13864L;
                        break;
                     case 103:
                        var9 <<= var14;
                        break;
                     case 104:
                     case 105:
                        var4 = (int)((long)var4 + (long)var5 + var9);
                        var4 = (int)((long)var4 + (long)var5 * var9);
                        var4 = (int)fFld;
                        var6 = 1;
                  }

                  var4 = (int)var15;
                  var14 += (byte)(var5 * var5);
               }
            } while(++var13 < 97.0F);
         }
      }

      FuzzerUtils.out.println("i s l = " + var2 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i20 i21 b = " + var3 + "," + var4 + "," + (var11 ? 1 : 0));
      FuzzerUtils.out.println("f1 i22 by1 = " + Float.floatToIntBits(var13) + "," + var5 + "," + var14);
      FuzzerUtils.out.println("i23 d3 iArr = " + var6 + "," + Double.doubleToLongBits(var15) + "," + FuzzerUtils.checkSum(var7));
      FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 210L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
