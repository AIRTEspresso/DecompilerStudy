public class Test {
   public static final int N = 400;
   public static long instanceCount = -8876196576951346957L;
   public static int iFld = 2;
   public volatile short sFld = -18905;
   public static int[] iArrFld = new int[400];
   public static double[][] dArrFld = new double[400][400];
   public static long fMeth_check_sum;
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0) {
      short var1 = 30755;
      boolean var2 = true;
      int var3 = 20340;
      int var4 = -4;
      int var5 = -41;
      int var6 = -43396;
      char var7 = '鳧';
      int[] var8 = new int[400];
      float var9 = 1.639F;
      byte var10 = 32;
      double var11 = -64.88658;
      boolean var13 = false;
      long[] var14 = new long[400];
      FuzzerUtils.init((int[])var8, (int)-32478);
      FuzzerUtils.init(var14, 12L);
      var0 <<= var0;
      var8[43] |= var1;

      int var17;
      for(var17 = 3; var17 < 376; ++var17) {
         for(var4 = 1; var4 < 5; ++var4) {
            var9 = (float)var0;
            switch ((var17 >>> 1) % 7 + 29) {
               case 29:
                  iFld += var4 * var4 + var3 - var17;
                  var10 = (byte)(var10 + 8);
                  switch ((iFld >>> 1) % 6 + 111) {
                     case 111:
                        for(var6 = 1; var6 < 2; ++var6) {
                           var3 += var6 - var4;
                           var8[var6 + 1] += var0;
                           var9 += (float)(var6 * var10) + var9 - (float)instanceCount;
                        }

                        var0 = (int)instanceCount;
                        var3 += var4 * var4;
                        continue;
                     case 112:
                        var10 *= var10;
                     case 113:
                        var11 += (double)var4;
                        continue;
                     case 114:
                        var0 -= (int)instanceCount;
                        continue;
                     case 115:
                        if (var13) {
                        }
                        continue;
                     case 116:
                        var9 = (float)var6;
                     default:
                        continue;
                  }
               case 30:
                  var13 = var13;
                  break;
               case 31:
                  instanceCount = (long)var10;
                  break;
               case 32:
                  var14[var17] += 491920893359087281L;
                  break;
               case 33:
                  instanceCount >>= var5;
               case 34:
                  var5 = (int)instanceCount;
                  break;
               case 35:
                  var9 -= var9;
            }
         }
      }

      long var15 = (long)(var0 + var1 + var17 + var3 + var4 + var5 + Float.floatToIntBits(var9) + var10 + var6 + var7) + Double.doubleToLongBits(var11) + (long)(var13 ? 1 : 0) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var14);
      lMeth_check_sum += var15;
      return var15;
   }

   public static void vMeth(long var0, int var2) {
      boolean var3 = true;
      int var4 = 24241;
      var0 >>= (int)((long)var2 - lMeth(iFld) << (int)instanceCount);
      var2 = -28099;
      iFld = -5931;
      instanceCount = var0;
      int[] var10000 = iArrFld;
      int var10001 = (iFld >>> 1) % 400;
      var10000[var10001] %= iFld | 1;
      iArrFld = iArrFld;
      int var5 = 1;

      do {
         ++var5;
         if (var5 >= 287) {
            iArrFld = iArrFld;
            iFld += var5;
            var4 = 1;

            while(true) {
               ++var4;
               if (var4 >= 239) {
                  vMeth_check_sum += var0 + (long)var2 + (long)var5 + (long)var4;
                  return;
               }

               var2 *= var4;
            }
         }

         instanceCount = var0;
         var2 = iFld;
      } while(var2 == 0);

      vMeth_check_sum += var0 + (long)var2 + (long)var5 + (long)var4;
   }

   public static float fMeth(int var0, float var1) {
      boolean var2 = true;
      byte var3 = -13;
      int var4 = -9;
      int var5 = 9748;
      byte var6 = 11;
      boolean var7 = true;
      vMeth(594L, var0);

      int var10;
      for(var10 = 15; 316 > var10; ++var10) {
         instanceCount += (long)var10;
         var4 = 5;

         while(true) {
            --var4;
            if (var4 <= 0) {
               for(var5 = 5; var5 > 1; --var5) {
                  iFld <<= var3;
               }
               break;
            }

            iArrFld = iArrFld;
            instanceCount &= -7885L;
            double[] var10000 = dArrFld[var10];
            var10000[var4 + 1] *= (double)instanceCount;
            var1 += (float)(-63590 + var4 * var4);
            var0 = (int)((long)var0 + ((long)var4 ^ (long)var1));
         }
      }

      long var8 = (long)(var0 + Float.floatToIntBits(var1) + var10 + var3 + var4 + var5 + var6 + (var7 ? 1 : 0));
      fMeth_check_sum += var8;
      return (float)var8;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 147;
      int var4 = 179;
      int var5 = 62480;
      int var6 = -54;
      int var7 = -215;
      int var8 = -37874;
      boolean var9 = false;
      boolean var10 = true;
      boolean[] var11 = new boolean[400];
      float var12 = 53.326F;
      double var13 = -2.26581;
      byte var15 = -60;
      short[] var16 = new short[400];
      FuzzerUtils.init(var11, false);
      FuzzerUtils.init(var16, (short)-12352);

      int var17;
      for(var17 = 3; var17 < 224; ++var17) {
         var4 = 114;

         do {
            var5 = 1;

            while(true) {
               ++var5;
               if (var5 >= 1) {
                  switch (var17 % 1 + 19) {
                     case 19:
                        var12 += fMeth(var5, 0.999F) + (float)var17;
                     default:
                        var6 = var4;
                  }

                  for(; var6 < 1; ++var6) {
                     switch (var4 % 5 * 5 + 57) {
                        case 60:
                        case 62:
                        case 65:
                        case 66:
                        case 67:
                        default:
                           break;
                        case 61:
                           var8 += -66 + var6 * var6;
                           break;
                        case 63:
                           instanceCount += (long)var6;
                        case 59:
                           var16[var6 - 1] |= (short)var3;
                        case 64:
                           var9 = var9;
                           break;
                        case 68:
                           iFld = var7;
                           iArrFld[var4] = -88;
                           int[] var10000;
                           switch ((var3 >>> 1) % 7 + 46) {
                              case 46:
                                 switch ((var7 >>> 1) % 1 * 5 + 54) {
                                    case 57:
                                       var3 >>= var4;
                                       var10000 = iArrFld;
                                       var10000[var6] *= (int)var13;
                                       var7 = var3;
                                       instanceCount += (long)(var6 * var6) + instanceCount - (long)var3;
                                    default:
                                       var9 = var9;
                                 }
                              case 47:
                                 switch ((var6 >>> 1) % 2 * 5 + 109) {
                                    case 111:
                                       var8 *= var4;
                                       continue;
                                    case 117:
                                       var7 >>= var6;
                                       var7 -= iFld;
                                       var3 |= var6;
                                       iFld |= (int)instanceCount;
                                    default:
                                       continue;
                                 }
                              case 48:
                                 var15 += (byte)((int)((long)var6 * instanceCount + (long)var17 - (long)var4));
                                 var3 += var6 + var15;
                              case 49:
                                 var10000 = iArrFld;
                                 var10000[var4 + 1] *= var5;
                                 iFld *= (int)var13;
                                 instanceCount += (long)var13;
                              case 50:
                                 iFld += var6 * this.sFld + var5 - var17;
                              case 51:
                                 if (var10) {
                                 }
                                 break;
                              case 52:
                                 iFld = var6;
                           }
                     }
                  }

                  --var4;
                  break;
               }

               var11[var4 - 1] = var9;
            }
         } while(var4 > 0);
      }

      FuzzerUtils.out.println("i i1 i2 = " + var17 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 b f = " + var5 + "," + (var9 ? 1 : 0) + "," + Float.floatToIntBits(var12));
      FuzzerUtils.out.println("i20 i21 d1 = " + var6 + "," + var7 + "," + Double.doubleToLongBits(var13));
      FuzzerUtils.out.println("i22 by1 b3 = " + var8 + "," + var15 + "," + (var10 ? 1 : 0));
      FuzzerUtils.out.println("bArr sArr = " + FuzzerUtils.checkSum(var11) + "," + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
      FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)4);
      FuzzerUtils.init(dArrFld, -92.19358);
      fMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
