public class Test {
   public static final int N = 400;
   public static long instanceCount = -5L;
   public static byte byFld = -99;
   public static double dFld = -2.54905;
   public short sFld = -11226;
   public static int[] iArrFld = new int[400];
   public volatile long[][][] lArrFld = new long[400][400][400];
   public static long vMeth_check_sum;
   public static long dMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(long var0, int var2) {
      boolean var3 = true;
      int var4 = 6438;
      int var5 = -51747;
      int var6 = 4;
      int var7 = 112;
      int var8 = -1;
      int var9 = 12;
      int var10 = 208;
      byte var11 = 88;
      byte[] var12 = new byte[400];
      FuzzerUtils.init(var12, (byte)-72);

      int var13;
      for(var13 = 356; var13 > 20; --var13) {
         for(var5 = 1; var5 < 5; ++var5) {
            var6 &= var6;
            var6 = var5;
            var2 += var5;

            for(var7 = var5; var7 < 2; ++var7) {
               var8 = -1401111136;
            }

            var4 += var5 * var5;
            var0 >>>= var4;
            var9 += var5 * var13 + var7 - var5;
            byFld = -27;
         }

         for(var10 = 1; var10 < 5; ++var10) {
            int[] var10000 = iArrFld;
            var10000[(var13 >>> 1) % 400] |= var9;
            var12[var13 - 1] += (byte)var5;
         }
      }

      vMeth1_check_sum += var0 + (long)var2 + (long)var13 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + (long)var11 + FuzzerUtils.checkSum(var12);
   }

   public static double dMeth(int var0, int var1) {
      int var2 = 36754;
      int var3 = -3;
      int var4 = -6;
      int var5 = 53;
      double var6 = -67.17575;
      float var8 = -1.27F;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, -708057116794659751L);
      vMeth1(instanceCount, var0);
      var0 <<= var1;
      var0 += (int)instanceCount;
      var2 = 1;

      while(true) {
         ++var2;
         if (var2 >= 205) {
            boolean var12 = true;
            byte var13 = byFld;
            long var10 = (long)(var0 + var13 + var2 + var3 + var4 + var5) + Double.doubleToLongBits(var6) + (long)Float.floatToIntBits(var8) + FuzzerUtils.checkSum(var9);
            dMeth_check_sum += var10;
            return (double)var10;
         }

         var1 *= (int)instanceCount;
         var3 = 1;

         do {
            iArrFld[var2 - 1] = -144;
            instanceCount += (long)(var3 - var2);

            for(var4 = 1; var4 < 1; ++var4) {
               var9[var2 - 1] *= (long)var4;
            }

            iArrFld[var2] = var2;
            var5 = (int)var6;
            ++var3;
         } while(var3 < 8);

         var0 = (int)((float)var0 + ((float)(var2 * byFld + var2) - var8));
      }
   }

   public static void vMeth(byte var0, long var1, long var3) {
      int var5 = 6;
      boolean var6 = true;
      int var7 = -61078;
      int var8 = 82;
      int var9 = -22522;
      float var10 = 115.269F;
      boolean var11 = false;
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, -1248685713359125201L);
      var12[(var5 >>> 1) % 400] *= (long)dMeth(var5, var5);

      int var13;
      for(var13 = 3; var13 < 206; ++var13) {
         for(var8 = var13; var8 < 8; ++var8) {
            var9 = -7;
            if (var11) {
               var5 |= var8;
               dFld -= (double)var9;
               var9 += 27919 + var8 * var8;
            } else if (var11) {
               iArrFld[var8 + 1] = var9;
               var7 -= var13;
               switch (var13 % 1 * 5 + 78) {
                  case 80:
                     var5 += var8 * var8;
                     var7 *= var9;
                     iArrFld[var13] = 5;
                     var10 = 4.0F;
               }
            } else if (var11) {
               var10 += (float)(-27767 + var8 * var8);
            }
         }
      }

      vMeth_check_sum += (long)var0 + var1 + var3 + (long)var5 + (long)var13 + (long)var7 + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var10) + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var12);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 4;
      int var4 = -26800;
      int var5 = -64239;
      int var6 = 4;
      int var7 = 8;
      boolean var8 = false;
      float var9 = 1.895F;
      long var10 = -11L;
      short[] var12 = new short[400];
      FuzzerUtils.init((short[])var12, (short)14060);

      int var13;
      for(var13 = 4; 333 > var13; ++var13) {
         vMeth((byte)-9, instanceCount, instanceCount);
         int[] var10000;
         if (!var8) {
            if (var8) {
               iArrFld[var13] = (int)instanceCount;
            } else {
               var10000 = iArrFld;
               var10000[var13 - 1] *= var3;
            }
         } else {
            var4 = 1;

            while(true) {
               ++var4;
               if (var4 >= 76) {
                  break;
               }

               byte var14 = 12;
               this.lArrFld[var4 + 1][var13 + 1][var4] = (long)dFld;
               var3 = var14 + var13;

               for(var5 = 1; var5 < 1; ++var5) {
                  var3 += 8;
                  instanceCount += (long)var5;
                  instanceCount = (long)dFld;
                  this.sFld += (short)(var5 | var3);
                  var6 += 6;
                  var3 *= (int)instanceCount;
                  var6 += var6;
                  var8 = var8;
                  var9 -= (float)var3;
               }

               instanceCount = instanceCount;

               for(var10 = 1L; var10 < 1L; ++var10) {
                  instanceCount *= (long)var3;
                  var6 += (int)(var10 * var10);
                  if (var8) {
                     switch ((int)(var10 % 9L + 126L)) {
                        case 126:
                        case 127:
                           var9 += (float)var4;
                           var6 += (int)((float)var10 + var9);
                           var10000 = iArrFld;
                           var10000[(int)(var10 - 1L)] += (int)var10;
                           break;
                        case 128:
                           var8 = true;
                           instanceCount += var10 + (long)var13;
                           break;
                        case 129:
                           instanceCount = instanceCount;
                           break;
                        case 130:
                           var7 = var5;
                        case 131:
                           var3 <<= var3;
                           break;
                        case 132:
                           instanceCount = (long)byFld;
                        case 133:
                           var7 += (int)((float)(var10 * var10 + (long)var6) - var9);
                           break;
                        case 134:
                           if (var8) {
                           }
                           break;
                        default:
                           byFld >>= (byte)var5;
                     }
                  } else {
                     byFld <<= (byte)var13;
                  }
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 i23 = " + var13 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i24 i25 b1 = " + var5 + "," + var6 + "," + (var8 ? 1 : 0));
      FuzzerUtils.out.println("f2 l3 i26 = " + Float.floatToIntBits(var9) + "," + var10 + "," + var7);
      FuzzerUtils.out.println("sArr = " + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.dFld = " + instanceCount + "," + byFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("sFld Test.iArrFld lArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-2747);
      vMeth_check_sum = 0L;
      dMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
