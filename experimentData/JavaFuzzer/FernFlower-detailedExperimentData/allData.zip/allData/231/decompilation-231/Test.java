public class Test {
   public static final int N = 400;
   public static long instanceCount = -1092153931L;
   public static int iFld = -14;
   public volatile int iFld1 = -89;
   public float fFld = 0.767F;
   public static boolean bFld = false;
   public static int iFld2 = 63846;
   public short sFld = 12618;
   public static long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(short var0) {
      int var1 = -203;
      int var2 = 3;
      int var3 = -167;
      int var4 = 2;
      int[] var5 = new int[400];
      float var6 = -1.716F;
      double[] var7 = new double[400];
      FuzzerUtils.init((int[])var5, (int)136);
      FuzzerUtils.init(var7, 2.9201);
      if (!bFld) {
         bFld = bFld;
         vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var6) + var2 + var3 + var4) + FuzzerUtils.checkSum(var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
      } else {
         var1 = 1;

         while(true) {
            var1 += 3;
            if (var1 >= 346) {
               int var10001 = (iFld >>> 1) % 400;
               var7[var10001] -= (double)var1;

               for(var2 = 4; var2 < 329; ++var2) {
                  var4 = 1;

                  while(true) {
                     ++var4;
                     if (var4 >= 5) {
                        break;
                     }

                     instanceCount -= instanceCount;
                     var3 *= var1;
                     instanceCount >>= var4;
                     bFld = bFld;
                  }
               }

               vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var6) + var2 + var3 + var4) + FuzzerUtils.checkSum(var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
               return;
            }

            var5[var1] -= var1;
            var7[var1 + 1] = (double)var1;
            instanceCount += (long)(var1 * var1 + iFld - var1);
            var6 = (float)var1;
            if (var1 != 0) {
               vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var6) + var2 + var3 + var4) + FuzzerUtils.checkSum(var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
               return;
            }

            var5[var1 - 1] = -6;
         }
      }
   }

   public static int iMeth1(int var0) {
      boolean var1 = true;
      int var2 = 1;
      int var3 = -21373;
      char var4 = '芞';
      int var5 = 226;
      long var6 = 30266L;
      short var8 = -21802;
      float[][] var9 = new float[400][400];
      FuzzerUtils.init(var9, -18.822F);
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 287) {
            long var13 = (long)(var0 + var12) + var6 + (long)var2 + (long)var8 + (long)var3 + (long)var4 + (long)var5 + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
            iMeth1_check_sum += var13;
            return (int)var13;
         }

         for(var6 = 1L; var6 < 6L; ++var6) {
            vMeth(var8);
            iFld -= iFld;

            for(var3 = 1; var3 < 2; ++var3) {
               float var10 = -43.654F;
               var9[var12][(int)(var6 + 1L)] = (float)var5;
               var5 *= -8;
               var2 *= (int)var6;
               switch ((var3 >>> 1) % 4 * 5 + 16) {
                  case 20:
                  default:
                     lArrFld = lArrFld;
                     break;
                  case 26:
                     var10 = (float)instanceCount;
                  case 31:
                     var4 = '蔈';
                     instanceCount += (long)var3;
                     var0 >>= (int)var6;
                     break;
                  case 33:
                     float var10000 = var10 + (float)var5;
                     iFld *= (int)var6;
               }
            }
         }
      }
   }

   public static int iMeth(int var0, int var1) {
      boolean var2 = true;
      short var3 = 5565;
      boolean var4 = true;
      byte var5 = 42;
      int var6 = -5;
      short var7 = 29426;
      int var8 = 127;
      int var9 = -13;
      int var10 = 3421;
      int[] var11 = new int[400];
      float var12 = 0.2F;
      double var13 = 59.97539;
      FuzzerUtils.init((int[])var11, (int)3);
      var2 = iMeth1(iFld) <= var3;

      int var17;
      for(var17 = 4; var17 < 238; var17 += 2) {
         var11[var17 - 1] -= iFld;

         for(var6 = 1; var6 < 13; ++var6) {
            iFld = (int)((long)iFld + ((long)var6 | (long)var12));
         }

         for(var8 = 1; var8 < 13; ++var8) {
            var9 >>= -12;
            iFld2 -= var9;
            var3 += (short)((int)(-29013L + (long)(var8 * var8)));
            var10 = 1;

            while(true) {
               ++var10;
               if (var10 >= 2) {
                  var13 -= 166.0;
                  break;
               }

               instanceCount = (long)var8;
               var11[var10] += var7;
               instanceCount += (long)(var10 ^ var1);
               if (iFld != 0) {
               }
            }
         }
      }

      long var15 = (long)(var0 + var1 + (var2 ? 1 : 0) + var3 + var17 + var5 + var6 + var7 + Float.floatToIntBits(var12) + var8 + var9 + var10) + Double.doubleToLongBits(var13) + FuzzerUtils.checkSum(var11);
      iMeth_check_sum += var15;
      return (int)var15;
   }

   public void mainTest(String[] var1) {
      double var2;
      int var4;
      int var5;
      int var6;
      int var7;
      int var8;
      int[] var9;
      boolean var10;
      boolean[] var11;
      byte var12;
      long[] var13;
      label99: {
         label98: {
            label113: {
               var2 = -1.111049;
               var4 = -35552;
               var5 = -8;
               var6 = 11115;
               var7 = 6;
               var8 = 23886;
               var9 = new int[400];
               var10 = false;
               var11 = new boolean[400];
               var12 = -93;
               var13 = new long[400];
               FuzzerUtils.init(var13, -1651258823L);
               FuzzerUtils.init(var11, false);
               FuzzerUtils.init((int[])var9, (int)0);
               switch ((iFld-- >>> 1) % 9 * 5) {
                  case 1:
                     instanceCount = (long)var4;
                  case 3:
                     break;
                  case 6:
                     instanceCount -= (long)var7;
                     break label113;
                  case 11:
                     break label98;
                  case 15:
                     instanceCount += (long)((var2 = (double)iFld) - (double)((long)iFld - instanceCount) + var2);
                  case 5:
                     var4 = 1;

                     do {
                        for(var5 = 2; var5 < 168; ++var5) {
                           var7 = 1;

                           do {
                              iFld += var7 * var7;
                              label75:
                              switch (var7 % 10 * 5 + 126) {
                                 case 144:
                                    var6 = var8;
                                    var8 = (int)this.fFld;
                                    iFld2 *= -992432826;
                                    switch ((var6 >>> 1) % 10 + 85) {
                                       case 85:
                                          var8 = 80333139;
                                          break label75;
                                       case 86:
                                          var13[var7] = instanceCount;
                                          this.iFld1 %= iFld | 1;
                                       case 87:
                                          this.iFld1 = iFld2;
                                       case 88:
                                          if (!var10) {
                                             instanceCount += (long)var7;
                                          }
                                          break label75;
                                       case 89:
                                          var6 ^= (int)instanceCount;
                                          break label75;
                                       case 90:
                                          instanceCount = (long)var12;
                                          break label75;
                                       case 91:
                                          if (bFld) {
                                             break label75;
                                          }
                                       case 92:
                                          var8 += var7 * var7;
                                          break label75;
                                       case 93:
                                          instanceCount = (long)this.iFld1;
                                          break label75;
                                       case 94:
                                          this.iFld1 += var7 * iFld2 + var7 - var8;
                                          break label75;
                                       default:
                                          this.fFld *= (float)var8;
                                          break label75;
                                    }
                                 case 145:
                                 case 146:
                                 case 147:
                                 case 148:
                                 case 149:
                                 case 150:
                                 case 151:
                                 case 153:
                                 case 155:
                                 case 156:
                                 case 158:
                                 case 159:
                                 case 161:
                                 case 163:
                                 case 164:
                                 case 165:
                                 case 166:
                                 case 167:
                                 case 168:
                                 case 169:
                                 case 172:
                                 case 174:
                                 case 175:
                                 default:
                                    instanceCount >>= var6;
                                    break;
                                 case 152:
                                    this.iFld1 *= (int)instanceCount;
                                    break;
                                 case 154:
                                    instanceCount = (long)(-15032.0F - (-2.27F - (float)Math.max(var8, -14)) - (float)iFld - --this.fFld);
                                    var8 -= iMeth(64579, 12);
                                    var6 = var4;
                                    var2 = (double)iFld2;
                                    break;
                                 case 157:
                                    this.iFld1 -= iFld;
                                    break;
                                 case 160:
                                    this.iFld1 = (int)this.fFld;
                                    break;
                                 case 162:
                                    this.iFld1 -= this.iFld1;
                                    break;
                                 case 170:
                                    instanceCount += (long)(-116.246F + (float)(var7 * var7));
                                    this.iFld1 += var7;
                                    if (var10) {
                                    }
                                    break;
                                 case 171:
                                    var13[var7 + 1] = instanceCount;
                                    break;
                                 case 173:
                                    var9[var5 + 1] *= var4;
                                    break;
                                 case 176:
                                    var2 = var2;
                              }

                              ++var7;
                           } while(var7 < 2);
                        }

                        var4 += 2;
                     } while(var4 < 299);
                  case 44:
                     var9[(var6 >>> 1) % 400] *= (int)this.fFld;
                     break label98;
                  case 18:
                     break label113;
                  case 29:
                     this.sFld = (short)(this.sFld << 1);
                  default:
                     break label99;
               }

               this.iFld1 = -12;
               break label99;
            }

            instanceCount -= (long)var7;
            break label99;
         }

         iFld2 += -1208575172;
      }

      FuzzerUtils.out.println("d i i1 = " + Double.doubleToLongBits(var2) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i2 i3 b = " + var6 + "," + var7 + "," + (var10 ? 1 : 0));
      FuzzerUtils.out.println("i4 by lArr = " + var8 + "," + var12 + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("bArr iArr2 = " + FuzzerUtils.checkSum(var11) + "," + FuzzerUtils.checkSum(var9));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld iFld1 = " + instanceCount + "," + iFld + "," + this.iFld1);
      FuzzerUtils.out.println("fFld Test.bFld Test.iFld2 = " + Float.floatToIntBits(this.fFld) + "," + (bFld ? 1 : 0) + "," + iFld2);
      FuzzerUtils.out.println("sFld Test.lArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -1585976315551056196L);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
