public class Test {
   public static final int N = 400;
   public static long instanceCount = -252L;
   public static int iFld = 205;
   public static short sFld = 32195;
   public static float fFld = -65.822F;
   public byte byFld = 97;
   public volatile int iFld1 = 95;
   public static double[] dArrFld = new double[400];
   public static float[][] fArrFld = new float[400][400];
   public static boolean[] bArrFld = new boolean[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long iMeth2_check_sum;

   public static int iMeth2() {
      double var0 = 0.80496;
      boolean var2 = true;
      int var3 = 87;
      int[] var4 = new int[400];
      long var5 = -3484110969561352279L;
      float var7 = 119.386F;
      boolean var8 = true;
      FuzzerUtils.init((int[])var4, (int)-26657);
      var0 = (double)iFld;

      int var11;
      for(var11 = 10; var11 < 252; ++var11) {
         var4[var11 - 1] += sFld;
         var3 = 1;
         iFld -= iFld;
         var5 = 1L;

         do {
            var7 += (float)var5;
            iFld = (int)var5;
            int var10000 = var3 + (int)(var5 * var5);
            dArrFld[(int)var5] = (double)var11;
            var3 = -22725;
            if (!var8) {
               var3 += sFld;
            }
         } while(++var5 < 7L);

         var3 -= 4955;
         var7 /= (float)((long)var7 | 1L);
      }

      long var9 = Double.doubleToLongBits(var0) + (long)var11 + (long)var3 + var5 + (long)Float.floatToIntBits(var7) + (long)(var8 ? 1 : 0) + FuzzerUtils.checkSum(var4);
      iMeth2_check_sum += var9;
      return (int)var9;
   }

   public static int iMeth1(float var0) {
      boolean var1 = true;
      int var2 = -67;
      int var3 = -2;
      int var4 = 64287;
      int var5 = -59583;
      byte var6 = 7;
      int[] var7 = new int[400];
      boolean var8 = true;
      byte var9 = 115;
      FuzzerUtils.init((int[])var7, (int)-10);
      iFld = iMeth2();

      int var12;
      for(var12 = 4; var12 < 375; ++var12) {
         double var10 = 0.64899;

         for(var3 = 1; var3 < 5; ++var3) {
            var8 = var8;
            var2 -= var3;
            var4 += var3;
            instanceCount *= (long)var4;
            var4 = (int)((float)var4 + ((float)var3 - var0));
         }

         iFld += var9;

         for(var5 = 1; var5 < 5; ++var5) {
            if (var12 != 0) {
            }

            var6 = var9;
            instanceCount = (long)var2;
         }

         var7[var12 - 1] = (int)var10;
      }

      var8 = true;
      long var13 = (long)(Float.floatToIntBits(var0) + var12 + var2 + var3 + var4 + (var8 ? 1 : 0) + var9 + var5 + var6) + FuzzerUtils.checkSum(var7);
      iMeth1_check_sum += var13;
      return (int)var13;
   }

   public static int iMeth(long var0) {
      boolean var2 = true;
      boolean var3 = true;
      short var4 = -8726;
      int var5 = 14;
      int var6 = 44889;
      int[] var7 = new int[400];
      double var8 = -1.7973;
      long[] var10 = new long[400];
      FuzzerUtils.init(var10, -50L);
      FuzzerUtils.init((int[])var7, (int)-3);
      int var13 = 1;

      while(true) {
         ++var13;
         if (var13 >= 221) {
            iMeth1(124.606F);
            iFld += (int)instanceCount;

            int var14;
            for(var14 = 18; var14 < 302; ++var14) {
               for(var5 = 1; var5 < 6; ++var5) {
                  var8 += (double)var4;
                  instanceCount <<= var4;
               }

               var7[var14] -= 12;
            }

            var7[(var13 >>> 1) % 400] = var14;
            var6 -= var13;
            fFld -= (float)var0;
            long var11 = var0 + (long)var13 + (long)var14 + (long)var4 + (long)var5 + (long)var6 + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var7);
            iMeth_check_sum += var11;
            return (int)var11;
         }

         var10[var13] >>= iFld--;
         sFld += (short)(var13 * var13);
      }
   }

   public void mainTest(String[] var1) {
      double var2 = 1.97296;
      boolean var4 = true;
      int var5 = 41;
      int var6 = 20;
      int var7 = -4;
      int var8 = -56;
      int var9 = -620;
      int var10 = -45478;
      int var11 = 4;
      int[] var12 = new int[400];
      long var13 = -8632283117275854122L;
      boolean var15 = true;
      FuzzerUtils.init((int[])var12, (int)-11);
      int var10001 = (iFld >>> 1) % 400;
      var12[var10001] >>= (int)((double)Math.max(iFld, iFld) + var2++ + (double)iMeth(instanceCount));

      int var18;
      for(var18 = 2; var18 < 179; ++var18) {
         instanceCount = instanceCount;
         iFld = (int)instanceCount;

         for(var6 = 2; var6 < 142; ++var6) {
            sFld += (short)var6;
            fArrFld[var6][var6] = (float)var7;

            for(var13 = (long)var6; var13 < 2L; ++var13) {
               this.byFld <<= (byte)this.iFld1;
               if (!var15 && !var15) {
                  instanceCount = (long)fFld;
                  var5 = (int)fFld;
                  var5 = 3;
                  bArrFld = FuzzerUtils.boolean1array(400, true);
               }
            }

            instanceCount -= (long)fFld;
            var12[var6 - 1] -= (int)var13;
            var5 -= (int)var13;
            instanceCount -= -7L;
         }

         var12 = var12;
         var7 <<= 159;
         instanceCount = instanceCount;

         for(var9 = 2; var9 < 142; ++var9) {
            var8 = 803;
            var11 = 1;

            while(true) {
               ++var11;
               if (var11 >= 2) {
                  break;
               }

               var10 = this.iFld1;

               try {
                  var7 = 87 % var6;
                  var7 = var8 % var10;
                  var10 = -201373032 % this.iFld1;
               } catch (ArithmeticException var17) {
               }

               fFld -= (float)var18;
               var8 = (int)fFld;
               var15 = false;
            }
         }
      }

      FuzzerUtils.out.println("d i13 i14 = " + Double.doubleToLongBits(var2) + "," + var18 + "," + var5);
      FuzzerUtils.out.println("i15 i16 l2 = " + var6 + "," + var7 + "," + var13);
      FuzzerUtils.out.println("i17 b2 i18 = " + var8 + "," + (var15 ? 1 : 0) + "," + var9);
      FuzzerUtils.out.println("i19 i20 iArr = " + var10 + "," + var11 + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
      FuzzerUtils.out.println("Test.fFld byFld iFld1 = " + Float.floatToIntBits(fFld) + "," + this.byFld + "," + this.iFld1);
      FuzzerUtils.out.println("Test.dArrFld Test.fArrFld Test.bArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
      FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 0.93006);
      FuzzerUtils.init(fArrFld, 2.57F);
      FuzzerUtils.init(bArrFld, true);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      iMeth2_check_sum = 0L;
   }
}
