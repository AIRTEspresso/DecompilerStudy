public class Test {
   public static final int N = 400;
   public static long instanceCount = -3446703931L;
   public static byte byFld = -2;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long fMeth_check_sum = 0L;

   public static float fMeth(double var0, int var2) {
      boolean var3 = true;
      int var4 = -99;
      int var5 = -1;
      short var6 = -11861;
      int var7 = -153;
      int var8 = -191;
      boolean var9 = true;
      byte var10 = 12;
      float var11 = 0.884F;
      short var12 = 28365;

      int var15;
      for(var15 = 4; var15 < 124; ++var15) {
         for(var5 = 1; var5 < 13; ++var5) {
            instanceCount -= (long)var5;

            for(var7 = var15; var7 < 2; ++var7) {
               instanceCount *= -4424L;
               var8 &= (int)instanceCount;
               var4 -= (int)var11;
               var2 = var6;
               var8 = var12;
            }

            var11 += (float)var15;
         }

         var0 += (double)var11;
         var12 -= (short)var4;
      }

      int var16;
      for(var16 = 1; var16 < 294; ++var16) {
         var0 = (double)var2;
         var11 *= (float)instanceCount;
      }

      long var13 = Double.doubleToLongBits(var0) + (long)var2 + (long)var15 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var11) + (long)var12 + (long)var16 + (long)var10;
      fMeth_check_sum += var13;
      return (float)var13;
   }

   public static void vMeth1(int var0, long var1) {
      short var3 = 23800;
      double var4 = 0.122986;
      double[] var6 = new double[400];
      boolean var7 = true;
      boolean var8 = true;
      int var9 = 181;
      int[] var10 = new int[400];
      float[] var11 = new float[400];
      long[][][] var12 = new long[400][400][400];
      FuzzerUtils.init(var6, -111.25194);
      FuzzerUtils.init(var11, 1.344F);
      FuzzerUtils.init((int[])var10, (int)13);
      FuzzerUtils.init((Object[][])var12, 7L);
      var3 -= (short)((int)(fMeth(var4, -14) * (float)var0));
      var7 = var7;
      var6[(var0 >>> 1) % 400] = -13.0;

      int var13;
      for(var13 = 2; var13 < 239; ++var13) {
         switch (93) {
            case 89:
               var0 *= var9;
               instanceCount >>>= 123;
               var0 -= var9;
               var9 = var9;
               break;
            case 90:
               switch ((var13 >>> 1) % 6 * 5 + 4) {
                  case 7:
                     var9 += var0;
                     break;
                  case 34:
                     if (var7) {
                        var11[var13] -= (float)var4;
                        var3 += (short)(var13 * var13);
                     } else if (var7) {
                        instanceCount = instanceCount;
                        var9 = var9;
                     } else {
                        var0 += var13;
                     }
                  case 10:
                     var9 += (int)var1;
                  case 31:
                     byFld *= (byte)var0;
                  case 20:
                     var10[var13 - 1] = -249;
                  case 8:
                     var12[var13][var13 + 1][var13 - 1] = (long)var13;
                     break;
                  default:
                     var0 = var9;
               }
            case 91:
               var10[var13 + 1] *= (int)var4;
               break;
            case 92:
               var10 = var10;
               break;
            case 93:
               var11[var13 + 1] = -1.0F;
               break;
            case 94:
               var10[var13 - 1] <<= var0;
               break;
            default:
               instanceCount = (long)var13;
         }
      }

      vMeth1_check_sum += (long)var0 + var1 + (long)var3 + Double.doubleToLongBits(var4) + (long)(var7 ? 1 : 0) + (long)var13 + (long)var9 + Double.doubleToLongBits(FuzzerUtils.checkSum(var6)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum((Object[][])var12);
   }

   public static void vMeth(int var0, int var1) {
      boolean var2 = true;
      int var3 = -12;
      int var4 = 39;
      int[][][] var5 = new int[400][400][400];
      boolean var6 = false;
      FuzzerUtils.init((Object[][])var5, 13);
      var0 ^= var0;
      var1 ^= (var1 - (var1 - var1)) * var0;
      vMeth1(-64855, instanceCount);
      int var8 = 1;

      while(true) {
         ++var8;
         if (var8 >= 155) {
            vMeth_check_sum += (long)(var0 + var1 + var8 + var3 + var4 + (var6 ? 1 : 0)) + FuzzerUtils.checkSum((Object[][])var5);
            return;
         }

         if (var8 != 0) {
            vMeth_check_sum += (long)(var0 + var1 + var8 + var3 + var4 + (var6 ? 1 : 0)) + FuzzerUtils.checkSum((Object[][])var5);
            return;
         }

         var1 = (int)instanceCount;

         for(var3 = 1; var3 < 10; ++var3) {
            float var7 = 2.1011F;
            instanceCount *= -117L;
            var1 -= (int)instanceCount;
            byte var9 = byFld;
            var1 = (int)((long)var9 + ((long)var3 * instanceCount + (long)var4 - (long)var3));
            var5 = var5;
            if (var6) {
               var4 += (int)(-2.18F + (float)(var3 * var3));
               var7 -= (float)instanceCount;
            } else {
               var1 >>= -168;
            }
         }
      }
   }

   public void mainTest(String[] var1) {
      int var2 = -19130;
      var2 *= -var2;
      vMeth(5, var2);
      byte var3 = 55;
      FuzzerUtils.out.println("i = " + var3);
      FuzzerUtils.out.println("Test.instanceCount Test.byFld = " + instanceCount + "," + byFld);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
