public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -989642660582499141L;
   public boolean bFld = false;
   public static byte byFld = -4;
   public float fFld = 118.63F;
   public static volatile float[] fArrFld = new float[400];
   public static double[] dArrFld = new double[400];
   public static int[][] iArrFld = new int[400][400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0, int var1) {
      boolean var2 = true;
      double var3 = 2.119435;
      float var5 = 0.994F;
      int var8 = 1;

      while(true) {
         ++var8;
         if (var8 >= 388) {
            long var6 = (long)(var0 + var1 + var8) + Double.doubleToLongBits(var3) + (long)Float.floatToIntBits(var5);
            lMeth_check_sum += var6;
            return var6;
         }

         var0 += var8 * var8;
         var3 = (double)var8;
         var1 *= (int)var5;
         var0 = (int)((long)var0 + (long)var8 + instanceCount);
         var0 >>= 170;
      }
   }

   public static void vMeth() {
      int var0 = -28;
      int var1 = -46995;
      int var2 = 72;
      int var3 = -3;
      int var4 = -2;
      int var5 = 2;
      byte var6 = 0;
      int[] var7 = new int[400];
      double var8 = 2.55003;
      float var10 = -2.149F;
      boolean var11 = true;
      FuzzerUtils.init((int[])var7, (int)-69);
      var0 <<= var0--;
      lMeth(-14, var0);
      if (!var11) {
         if (var11) {
            var2 = var1;
         }

         vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var8) + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var10) + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var7);
      } else {
         for(var1 = 14; var1 < 303; ++var1) {
            for(var3 = 6; var3 > 1; var3 -= 3) {
               var2 = (int)instanceCount;
               var7[var3] -= 1755221272;
               instanceCount -= instanceCount;
               var8 *= 13.0;
               var4 = (int)instanceCount;
               var8 = (double)var4;

               for(var5 = 1; var5 < 6; ++var5) {
                  instanceCount += (long)var5;
                  var10 += 22732.0F;
                  var11 = var11;
               }
            }
         }

         vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var8) + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var10) + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var7);
      }
   }

   public static int iMeth(float var0) {
      boolean var1 = true;
      int var2 = 186;
      int var3 = 0;
      int var4 = 179;
      int var5 = 2;
      byte var6 = 10;
      int var7 = 0;
      short var8 = -7826;
      double var9 = -35.37211;
      vMeth();

      int var13;
      for(var13 = 4; var13 < 165; ++var13) {
         var2 *= var2;
         instanceCount += (long)var8;
         var2 *= var13;
         var0 = (float)var2;
         char var14 = '앋';
         var2 = (int)((long)var14 + ((long)var13 - instanceCount));

         label36:
         for(var3 = var13; var3 < 10; ++var3) {
            switch (var13 % 8 + 26) {
               case 26:
                  var9 = 5.0;
                  var5 = 1;

                  while(true) {
                     if (var5 >= 1) {
                        continue label36;
                     }

                     instanceCount += (long)(var5 * var7);
                     byFld <<= (byte)var4;
                     var5 += 3;
                  }
               case 27:
                  var4 += var3;
                  break;
               case 28:
                  var4 *= (int)var0;
                  break;
               case 29:
                  var2 *= var6;
               case 30:
                  instanceCount >>>= var5;
               case 31:
                  var7 += var3;
                  break;
               case 32:
                  var0 += (float)var9;
                  break;
               case 33:
                  instanceCount += (long)(var3 * var5 + var7 - var2);
            }
         }
      }

      long var11 = (long)(Float.floatToIntBits(var0) + var13 + var2 + var8 + var3 + var4) + Double.doubleToLongBits(var9) + (long)var5 + (long)var6 + (long)var7;
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public void mainTest(String[] var1) {
      int var2 = 37890;
      int var3 = 54462;
      int var4 = -9;
      int var5 = 10;
      int var6 = 11;
      int[] var7 = new int[400];
      short var8 = -12741;
      FuzzerUtils.init((int[])var7, (int)-174);
      this.bFld = 3579882441071966691L * (long)(byFld * var2) <= (long)iMeth(this.fFld);
      int[] var9 = var7;
      int var10 = var7.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var12 = var9[var11];
         var3 = 1;

         do {
            double var13 = 1.128552;
            var7[var3 + 1] = var3;
            var13 = -105.0;

            for(var4 = 1; 1 > var4; ++var4) {
               var2 = (int)((float)var2 + (float)var4 + this.fFld);
               var12 = -32488;
               if (this.bFld) {
                  var5 = var4;
                  this.fFld += (float)(var4 * var4 + var4 - var4);
               } else {
                  var7[var4 + 1] = var2;
               }
            }

            instanceCount = (long)this.fFld;
            var6 = 1;

            do {
               var5 += var5;
               var12 = (int)((long)var12 + ((long)(var6 * var2 + var4) - instanceCount));
               var2 -= (int)var13;
               var12 *= var2;
               var12 += var6;
               switch (var3 % 2 + 85) {
                  case 85:
                     break;
                  case 86:
                     var13 *= (double)instanceCount;
                     var12 = var12;
                     break;
                  default:
                     var2 = (int)this.fFld;
               }

               instanceCount += (long)var6 * instanceCount + (long)var4 - (long)var5;
               this.fFld = this.fFld;
               this.fFld += (float)(var6 - var8);
               var7[var6 - 1] -= 97;
               ++var6;
            } while(var6 < 1);

            double[] var10000 = dArrFld;
            var10000[var3 - 1] += -28675.0;
            iArrFld = iArrFld;
            ++var3;
         } while(var3 < 63);
      }

      FuzzerUtils.out.println("i i19 i20 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i21 i22 s1 = " + var5 + "," + var6 + "," + var8);
      FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(var7));
      FuzzerUtils.out.println("Test.instanceCount bFld Test.byFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + byFld);
      FuzzerUtils.out.println("fFld Test.fArrFld Test.dArrFld = " + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 85.12F);
      FuzzerUtils.init(dArrFld, -2.71362);
      FuzzerUtils.init((int[][])iArrFld, (int)1);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
