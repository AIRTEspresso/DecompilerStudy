public class Test {
   public static final int N = 400;
   public static long instanceCount = -20946L;
   public static int iFld = 3;
   public boolean bFld = false;
   public static long lFld = 125L;
   public static int[] iArrFld = new int[400];
   public static long lMeth_check_sum;
   public static long bMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static long lMeth(int var0) {
      int[] var1 = new int[400];
      FuzzerUtils.init((int[])var1, (int)182);
      var1[67] >>= (int)instanceCount;
      long var2 = (long)var0 + FuzzerUtils.checkSum(var1);
      lMeth_check_sum += var2;
      return var2;
   }

   public static void vMeth1(int var0, int var1) {
      int var2 = -44967;
      byte var3 = 2;
      byte var4 = -4;
      int var5 = 1;
      short var6 = -150;
      int var7 = -3;
      int var8 = -40438;
      int[] var9 = new int[400];
      long var10 = 0L;
      float var12 = -127.634F;
      double var13 = 0.2123;
      short var15 = 2548;
      short[] var16 = new short[400];
      FuzzerUtils.init((int[])var9, (int)-12);
      FuzzerUtils.init((short[])var16, (short)15552);

      for(var2 = 10; var2 < 179; ++var2) {
         var9 = var9;

         for(var10 = (long)var2; 9L > var10; ++var10) {
            var12 = (float)var2;
         }

         label43:
         for(var5 = 1; var5 < 9; ++var5) {
            var7 = 1;

            while(true) {
               ++var7;
               if (var7 >= 2) {
                  var16[var2 - 1] *= (short)((int)var10);
                  var8 = 1;

                  while(true) {
                     ++var8;
                     if (var8 >= 2) {
                        var1 *= var15;
                        var0 = -216;
                        var9[var2 - 1] *= (int)var10;
                        continue label43;
                     }

                     instanceCount -= instanceCount;
                     var0 += (int)var12;
                  }
               }

               var9[var5] = (int)var10;
               var13 -= (double)var10;
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3) + var10 + (long)var4 + (long)Float.floatToIntBits(var12) + (long)var5 + (long)var6 + (long)var7 + Double.doubleToLongBits(var13) + (long)var8 + (long)var15 + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var16);
   }

   public static void vMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 214;
      int var5 = -54274;
      int var6 = 0;
      int var7 = -7;
      int[] var8 = new int[400];
      FuzzerUtils.init((int[])var8, (int)-190);
      vMeth1(iFld, var1);
      var0 = var2;
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 352) {
            vMeth_check_sum += (long)(var0 + var1 + var2 + var12 + var4 + var5 + var6 + var7) + FuzzerUtils.checkSum(var8);
            return;
         }

         for(var4 = 1; var4 < 5; ++var4) {
            var6 = 1;

            do {
               boolean var9 = false;
               var8[var6] -= (int)instanceCount;
               if (var9) {
                  instanceCount = (long)iFld;
                  instanceCount = (long)iFld;
                  if (var5 != 0) {
                     vMeth_check_sum += (long)(var0 + var1 + var2 + var12 + var4 + var5 + var6 + var7) + FuzzerUtils.checkSum(var8);
                     return;
                  }

                  iFld = (int)instanceCount;
               } else if (var9) {
                  try {
                     int var10000 = var0 / var4;
                     var7 = var6 % -52543;
                     var1 = 20406 % var6;
                  } catch (ArithmeticException var11) {
                  }

                  if (var0 != 0) {
                     vMeth_check_sum += (long)(var0 + var1 + var2 + var12 + var4 + var5 + var6 + var7) + FuzzerUtils.checkSum(var8);
                     return;
                  }

                  iFld = var7;
               } else {
                  var7 += var6 * var12 + var6 - var7;
               }

               ++var6;
            } while(var6 < 2);
         }
      }
   }

   public static boolean bMeth(int var0, long var1, long var3) {
      int var5 = 36264;
      boolean var6 = true;
      int var7 = -38507;
      int var8 = -14;
      float var9 = 0.373F;
      short var10 = -23543;
      long[] var11 = new long[400];
      FuzzerUtils.init(var11, 83L);
      var5 = 1;

      byte var15;
      do {
         vMeth(iFld, 179, 125);

         try {
            var0 = -45456 / var0;
            var0 = var5 / 11925;
            iFld = 195 % iFld;
         } catch (ArithmeticException var14) {
         }

         var0 /= (int)((long)var9 | 1L);
         var15 = 1;
         if (var15 < 11) {
            double var12 = -1.71475;
            var9 += (float)var8;
            iFld %= var10 | 1;
            var8 *= var7;
         }

         ++var5;
      } while(var5 < 137);

      long var16 = (long)var0 + var1 + var3 + (long)var5 + (long)Float.floatToIntBits(var9) + (long)var15 + (long)var7 + (long)var8 + (long)var10 + FuzzerUtils.checkSum(var11);
      bMeth_check_sum += var16;
      return var16 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      float var2 = 2.274F;
      float var3 = -51.605F;
      float var4 = -124.129F;
      int var5 = 4863;
      int var6 = 0;
      int var7 = -70;
      int var8 = -6;
      boolean var9 = true;
      int var10 = -59152;
      int var11 = -230;
      double var12 = 0.6727;
      boolean[] var14 = new boolean[400];
      FuzzerUtils.init(var14, true);
      var2 = 1.0F;

      do {
         iFld = (int)lMeth(iFld);
         if (bMeth(iFld, -4L, instanceCount)) {
            break;
         }

         iFld -= (int)var2;
         var5 = 1;

         while(true) {
            ++var5;
            if (var5 >= 194 || this.bFld) {
               try {
                  var7 = iFld / '\ud852';
                  iFld = 240 / var5;
                  var7 = -1105412431 / var7;
               } catch (ArithmeticException var16) {
               }

               instanceCount = (long)var6;
               instanceCount = (long)var5;
               instanceCount -= 30933L;
               var14[(int)(var2 + 1.0F)] = this.bFld;
               lFld = (long)var7;
               break;
            }

            var3 += (float)(var5 * var5 + iFld - iFld);

            for(var6 = 1; 1 > var6; ++var6) {
               var3 *= (float)var7;
               var7 += var6;
               var7 = (int)((long)var7 + ((long)var6 | instanceCount));
            }

            var8 = 1;

            while(true) {
               var7 += var8 * var6 + var7 - iFld;
               if (!this.bFld) {
                  var12 = (double)var6;
                  instanceCount += (long)var7;
                  iArrFld[var5 + 1] = var7;
               }

               ++var8;
               if (var8 >= 1) {
                  break;
               }
            }
         }
      } while(++var2 < 129.0F);

      iFld += 99;

      int var17;
      for(var17 = 167; 5 < var17; --var17) {
         var10 = var7;
         int[] var10000 = iArrFld;
         var10000[var17 + 1] >>= var8;
         var11 = 155;

         do {
            instanceCount += (long)var8;
            --var11;
         } while(var11 > 0);

         var3 += (float)(var17 * var6) + var4 - (float)var11;
      }

      FuzzerUtils.out.println("f i23 f3 = " + Float.floatToIntBits(var2) + "," + var5 + "," + Float.floatToIntBits(var3));
      FuzzerUtils.out.println("i24 i25 i26 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("d2 i27 i28 = " + Double.doubleToLongBits(var12) + "," + var17 + "," + var10);
      FuzzerUtils.out.println("i29 f4 bArr = " + var11 + "," + Float.floatToIntBits(var4) + "," + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld bFld = " + instanceCount + "," + iFld + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.lFld Test.iArrFld = " + lFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(iArrFld, -36523);
      lMeth_check_sum = 0L;
      bMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
