public class Test {
   public static final int N = 400;
   public static long instanceCount = -27988L;
   public static double dFld = 122.101356;
   public static short sFld = 15807;
   public int iFld = -4428;
   public float fFld = -6.434F;
   public byte byFld = -53;
   public static volatile short[][] sArrFld = new short[400][400];
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      boolean var1 = true;
      int var2 = -56780;
      short var3 = -141;
      int var4 = -11;
      int var5 = 13;
      byte var6 = -50;
      int[] var7 = new int[400];
      float var8 = -102.76F;
      boolean var9 = true;
      double[] var10 = new double[400];
      FuzzerUtils.init((int[])var7, (int)13751);
      FuzzerUtils.init(var10, -66.129352);
      var0 = 11;
      short[] var10000 = sArrFld[62];
      var10000[(var0 >>> 1) % 400] *= (short)var0;
      int var11 = 162;

      while(true) {
         var11 -= 2;
         if (var11 <= 0) {
            vMeth1_check_sum += (long)(var0 + var11 + var2 + var3 + Float.floatToIntBits(var8) + var4 + var5 + (var9 ? 1 : 0) + var6) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
            return;
         }

         for(var2 = 1; var2 < 19; ++var2) {
            var8 += (float)instanceCount;

            for(var4 = var2; var4 < 2; ++var4) {
               instanceCount = (long)dFld;
               var7[var2 - 1] *= var4;
               switch ((var5 >>> 1) % 9 + 108) {
                  case 108:
                     var10[var11] += (double)var11;
                     var8 *= (float)dFld;
                     break;
                  case 109:
                  case 110:
                     switch (var2 % 2 * 5 + 75) {
                        case 77:
                           var7[var2 - 1] = (int)dFld;
                           var5 = (int)dFld;
                           var0 += var4 * var4;
                        case 76:
                           var0 /= (int)(instanceCount | 1L);
                        default:
                           continue;
                     }
                  case 111:
                     var8 -= -4.0F;
                     break;
                  case 112:
                     var5 >>= sFld;
                     break;
                  case 113:
                     var5 += var5;
                     break;
                  case 114:
                     var5 += var3;
                     break;
                  case 115:
                     if (var9) {
                     }
                     break;
                  case 116:
                     var10[var2 + 1] = (double)var6;
                     break;
                  default:
                     dFld -= (double)var6;
               }
            }
         }
      }
   }

   public static int iMeth() {
      boolean var0 = true;
      int var1 = -117;
      int var2 = -42899;
      int var3 = -56960;
      boolean var4 = true;
      int var5 = 64112;
      int var6 = 37604;
      float var7 = 2.0F;
      byte var8 = -16;

      int var11;
      for(var11 = 13; var11 < 227; var11 += 3) {
         for(var2 = 1; 22 > var2; ++var2) {
            var7 -= (float)(Math.max(Integer.reverseBytes(var3), (int)((long)var3 - instanceCount)) * var3++);
         }

         var3 = var3-- * var3;
         vMeth1(var2);
      }

      int var12;
      for(var12 = 8; 345 > var12; ++var12) {
         var6 = 1;

         do {
            var1 *= var3;
            int[] var13 = iArrFld;
            var13[var12] *= var8;
            iArrFld[var12 - 1] = (int)instanceCount;
            ++var6;
         } while(var6 < 5);

         var5 = -44279;
      }

      instanceCount -= (long)var5;
      long var9 = (long)(var11 + var1 + var2 + var3 + Float.floatToIntBits(var7) + var12 + var5 + var6 + var8);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void vMeth(int var1, int var2) {
      double var3 = -48.1075;
      int var5 = 42211;
      int var6 = 6;
      int var7 = -36103;
      int var8 = 58152;
      int var9 = -254;
      float var10 = 119.832F;
      var3 = (double)(-(var2++ - iMeth()));
      ++var2;

      label33:
      for(var5 = 9; var5 < 146; var5 += 3) {
         switch (112) {
            case 112:
               instanceCount <<= var6;
               var6 += 4 + var5 * var5;
               var3 = (double)var5;
               var7 = 1;

               while(true) {
                  ++var7;
                  if (var7 >= 34) {
                     continue label33;
                  }

                  var10 += (float)var6;

                  for(var8 = 1; var8 < 1; ++var8) {
                     var10 -= (float)instanceCount;
                     if (var9 != 0) {
                        vMeth_check_sum += (long)(var1 + var2) + Double.doubleToLongBits(var3) + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var10) + (long)var8 + (long)var9;
                        return;
                     }

                     int[] var11 = iArrFld;
                     var11[var7] -= (int)instanceCount;
                     var1 *= var1;
                     var9 += var6;
                  }
               }
            default:
               instanceCount += (long)(var5 - sFld);
         }
      }

      vMeth_check_sum += (long)(var1 + var2) + Double.doubleToLongBits(var3) + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var10) + (long)var8 + (long)var9;
   }

   public void mainTest(String[] var1) {
      int var2 = -41499;
      int var3 = 1;
      int var4 = -64418;
      int var5 = 14535;
      boolean var6 = false;
      this.vMeth(this.iFld, this.iFld);

      for(var2 = 1; var2 < 307; ++var2) {
         this.iFld >>= this.iFld;
         var3 = this.iFld;
         this.fFld += (float)var2;
         this.iFld &= var2;
         var3 <<= -438499239;
         iArrFld[var2] = -12979;
         this.iFld += var2 * var2;
         switch (var2 % 2 * 5 + 77) {
            case 83:
               dFld -= (double)var3;
               this.iFld += var2;
               break;
            case 84:
               var6 = var6;

               for(var4 = 82; var4 > 5; var4 -= 3) {
                  int[] var10000 = iArrFld;
                  var10000[var2 + 1] -= var2;
                  var3 |= this.byFld;
                  dFld %= (double)(var4 | 1);
                  sFld += (short)(var4 ^ var3);
                  this.iFld += var4 * var4;
                  this.iFld = this.iFld;
                  this.fFld -= -31249.0F;
                  instanceCount += (long)var4;
               }

               this.iFld = (int)((long)this.iFld + ((long)(var2 * this.iFld + this.iFld) - instanceCount));
         }

         var5 |= (int)instanceCount;
      }

      instanceCount -= (long)var2;
      instanceCount <<= var2;
      var3 >>= sFld;
      var5 = var2 & var2;
      FuzzerUtils.out.println("i21 i22 b1 = " + var2 + "," + var3 + "," + (var6 ? 1 : 0));
      FuzzerUtils.out.println("i23 i24 = " + var4 + "," + var5);
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.sFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + sFld);
      FuzzerUtils.out.println("iFld fFld byFld = " + this.iFld + "," + Float.floatToIntBits(this.fFld) + "," + this.byFld);
      FuzzerUtils.out.println("Test.sArrFld Test.iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((short[][])sArrFld, (short)24112);
      FuzzerUtils.init((int[])iArrFld, (int)12);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
