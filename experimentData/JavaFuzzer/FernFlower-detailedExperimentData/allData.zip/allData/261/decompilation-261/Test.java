public class Test {
   public static final int N = 400;
   public static long instanceCount = 118L;
   public int iFld = 58665;
   public volatile float fFld = 105.646F;
   public static double dFld = 21.125562;
   public static byte byFld = -96;
   public static short sFld = 11635;
   public double dFld1 = 15.18372;
   public static long[] lArrFld = new long[400];
   public short[][][] sArrFld = new short[400][400][400];
   public int[] iArrFld = new int[400];
   public static double[] dArrFld = new double[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, int var1) {
      vMeth2_check_sum += (long)(var1 + var1);
   }

   public static void vMeth1(int var0, long var1) {
      boolean var3 = true;
      int var4 = 4;
      int var5 = 9;
      int var6 = -14;
      int var7 = 25864;
      int var8 = -3869;
      short var9 = 1612;
      int[] var10 = new int[400];
      short var11 = -8858;
      boolean var12 = false;
      FuzzerUtils.init((int[])var10, (int)-1);
      var0 += (int)(var1--);
      vMeth2(var0, var0);
      long[] var10000 = lArrFld;
      var10000[(var0 >>> 1) % 400] += var1;

      int var14;
      for(var14 = 10; var14 < 312; ++var14) {
         byte var13 = -38;
         var13 += (byte)(var14 + var4);
         switch (var14 % 9 * 5 + 121) {
            case 139:
               for(var5 = var14; 5 > var5; ++var5) {
                  for(var7 = var5; var7 < 1; ++var7) {
                     var11 &= (short)var7;
                     --var4;
                     var0 <<= -14;
                     var1 = -22472L;
                     if (var12) {
                     }
                  }

                  var8 *= var4;
                  var10[var14 - 1] += (int)dFld;
               }
               break;
            case 141:
               instanceCount -= (long)var14;
            case 122:
               instanceCount = (long)var8;
            case 125:
               instanceCount = var1;
               break;
            case 147:
               instanceCount -= (long)var7;
               break;
            case 152:
               var6 = var7;
               break;
            case 157:
               var0 = -115;
               break;
            case 159:
               var8 *= var9;
               break;
            case 166:
               var4 += (int)var1;
         }
      }

      vMeth1_check_sum += (long)var0 + var1 + (long)var14 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var11 + (long)(var12 ? 1 : 0) + (long)var9 + FuzzerUtils.checkSum(var10);
   }

   public static void vMeth(int var0, long var1) {
      boolean var3 = true;
      int var4 = -243;
      int var5 = -5;
      int var6 = -12;
      int[] var7 = new int[400];
      float var8 = 0.733F;
      FuzzerUtils.init((int[])var7, (int)-15513);

      int var9;
      for(var9 = 12; var9 < 343; ++var9) {
         vMeth1(107, -3L);
         byFld >>>= (byte)var0;
         var7[var9 + 1] += (int)dFld;
         long[] var10000 = lArrFld;
         var10000[var9 - 1] *= (long)var0;
         var8 = 1.0F;

         do {
            sFld = -19;

            for(var5 = (int)var8; var5 < 1; ++var5) {
               var7[(int)var8] = var4;
               if (var0 != 0) {
                  vMeth_check_sum += (long)var0 + var1 + (long)var9 + (long)var4 + (long)Float.floatToIntBits(var8) + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7);
                  return;
               }
            }

            switch ((var6 >>> 1) % 9 + 119) {
               case 119:
                  var6 = (int)instanceCount;
                  var6 >>= var4;
                  break;
               case 120:
                  var4 += (int)(var8 * (float)var1 + (float)var1 - (float)instanceCount);
                  var0 += var6;
                  break;
               case 121:
                  var6 = (int)dFld;
                  break;
               case 122:
                  var4 = var4;
                  break;
               case 123:
                  var6 += (int)(var8 * (float)var5 + var8 - (float)var0);
                  break;
               case 124:
                  var6 &= 44158;
               case 125:
                  var1 -= (long)byFld;
                  break;
               case 126:
                  var0 = var0;
                  break;
               case 127:
                  var7[(int)(var8 + 1.0F)] -= var4;
            }
         } while(++var8 < 5.0F);
      }

      vMeth_check_sum += (long)var0 + var1 + (long)var9 + (long)var4 + (long)Float.floatToIntBits(var8) + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -56;
      int var4 = -61707;
      int var5 = -193;
      boolean var6 = true;
      int var7 = 4;
      int var8 = 27519;
      byte var9 = 8;
      byte var10 = -4;
      short var11 = -18154;
      boolean var12 = false;
      float[] var13 = new float[400];
      FuzzerUtils.init(var13, 0.108F);
      var13[(this.iFld >>> 1) % 400] = this.fFld;

      int var14;
      for(var14 = 5; var14 < 172; ++var14) {
         vMeth(var14, -7389263707675291169L);
         this.iFld = (int)instanceCount;
         if (var12) {
            break;
         }

         short[] var10000 = this.sArrFld[var14 + 1][var14 - 1];
         var10000[var14 - 1] %= (short)((int)((long)this.fFld | 1L));
         this.iFld += var14 * var14;
         int[] var16 = this.iArrFld;
         int var10001 = (this.iFld >>> 1) % 400;
         var16[var10001] -= var14;

         for(var4 = 4; var4 < 150; ++var4) {
            var3 = var14;
            this.fFld += (float)var5;
         }

         var5 -= var4;
         var16 = this.iArrFld;
         var16[var14] -= (int)instanceCount;
         var5 += var14;
      }

      int var15;
      for(var15 = 7; var15 < 221; ++var15) {
         sFld = (short)var15;
         double[] var17 = dArrFld;
         var17[var15 - 1] += dFld;
         var7 += var15;

         for(var8 = var15; var8 < 117; ++var8) {
            instanceCount += (long)var8 - instanceCount;
            var12 = var12;
            sFld = (short)(sFld * 14);
         }

         var3 += var15 + var3;
      }

      FuzzerUtils.out.println("i i1 b1 = " + var14 + "," + var3 + "," + (var12 ? 1 : 0));
      FuzzerUtils.out.println("i18 i19 i20 = " + var4 + "," + var5 + "," + var15);
      FuzzerUtils.out.println("i21 i22 i23 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i24 i25 fArr = " + var10 + "," + var11 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)));
      FuzzerUtils.out.println("Test.instanceCount iFld fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.dFld Test.byFld Test.sFld = " + Double.doubleToLongBits(dFld) + "," + byFld + "," + sFld);
      FuzzerUtils.out.println("dFld1 Test.lArrFld sArrFld = " + Double.doubleToLongBits(this.dFld1) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.sArrFld));
      FuzzerUtils.out.println("iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 26450288L);
      FuzzerUtils.init(dArrFld, 1.94222);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
