public class Test {
   public static final int N = 400;
   public static long instanceCount = 1351516201L;
   public static int iFld = 218;
   public static double dFld = -43.97286;
   public float fFld = -96.26F;
   public int[] iArrFld = new int[400];
   public boolean[] bArrFld = new boolean[400];
   public static long vMeth_check_sum = 0L;
   public static long byMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(byte var0, int var1, int var2) {
      int var3 = 57909;
      int var4 = 3520;
      int var5 = 52;
      int var6 = -55162;
      int[] var7 = new int[400];
      float var8 = 1.63F;
      boolean var9 = false;
      FuzzerUtils.init((int[])var7, (int)-8);

      for(var3 = 3; var3 < 328; ++var3) {
         double var10 = 0.12976;
         var7 = var7;
         instanceCount = (long)var4;
         var8 = (float)var10;

         for(var5 = 1; 5 > var5; ++var5) {
            var4 += 10;
            switch ((var2 >>> 1) % 6 * 5 + 27) {
               case 28:
                  var6 = (int)instanceCount;
                  break;
               case 41:
                  iFld = 20;
                  break;
               case 45:
                  iFld *= 6;
                  var6 *= var4;
               case 40:
                  iFld *= var5;
                  if (var9) {
                     break;
                  }

                  var10 = (double)instanceCount;
                  iFld /= var4 | 1;
               case 34:
                  var4 += (int)(35004L + (long)(var5 * var5));
               case 57:
                  instanceCount += (long)var2;
                  break;
               default:
                  var2 *= var6;
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var8) + var5 + var6 + (var9 ? 1 : 0)) + FuzzerUtils.checkSum(var7);
   }

   public static byte byMeth(int var0, int var1, int var2) {
      byte var3 = -100;
      int var4 = -64987;
      byte var5 = 13;
      int var6 = -36836;
      int var7 = 84;
      byte var8 = -11;
      float var9 = 12.16F;
      short var10 = 23476;
      long var11 = 186L;
      long[] var13 = new long[400];
      boolean var14 = false;
      FuzzerUtils.init(var13, 234L);
      vMeth1(var3, var0, iFld);
      var4 = -48831;
      var13[(var0 >>> 1) % 400] += 30L;

      label59:
      for(var9 = 7.0F; var9 < 149.0F; ++var9) {
         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 11) {
               var7 = 1;

               while(true) {
                  ++var7;
                  if (var7 >= 11) {
                     continue label59;
                  }

                  var1 = -4;
                  var10 = (short)((int)dFld);

                  for(var11 = (long)var9; var11 < 1L; ++var11) {
                     if (var14) {
                        var4 += (int)var11;
                     }

                     if (var14) {
                        instanceCount *= (long)var0;
                        var4 <<= 13;
                     } else if (var14) {
                        if (var14) {
                        }
                     } else if (var14) {
                        if (var14) {
                           break;
                        }
                     } else {
                        iFld &= 19951;
                     }
                  }
               }
            }

            var0 >>= var6;
         }
      }

      long var15 = (long)(var0 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var9) + var5 + var6 + var7 + var10) + var11 + (long)var8 + (long)(var14 ? 1 : 0) + FuzzerUtils.checkSum(var13);
      byMeth_check_sum += var15;
      return (byte)((int)var15);
   }

   public static void vMeth(int var0, double var1) {
      short var3 = 1979;
      boolean var4 = true;
      int var5 = -8734;
      int var6 = 55147;
      int var7 = 7;
      byte var8 = -10;
      int[] var9 = new int[400];
      boolean var10 = true;
      FuzzerUtils.init((int[])var9, (int)8);
      int var10001 = (iFld >>> 1) % 400;
      --var3;
      var9[var10001] = var3;
      var0 = -(var0-- + var9[241]);

      int var12;
      for(var12 = 10; 183 > var12; ++var12) {
         iFld += var12 * iFld + var5 - var0;
         instanceCount += (long)(-53498 + var12 * var12);
         iFld *= (int)instanceCount;
         var5 = (int)((long)var5 + ((long)(var12 * var6) + instanceCount - (long)var12));
         if (!(var10 = byMeth(9621, iFld, var5) != -118) && !var10) {
            for(var7 = 1; var7 < 9; ++var7) {
               byte var11 = -37;
               var5 = var12;
               var11 *= (byte)((int)instanceCount);
               var3 *= (short)var12;
               iFld &= var12;
            }
         } else {
            var6 = iFld;
         }
      }

      vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var12 + (long)var5 + (long)var6 + (long)(var10 ? 1 : 0) + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
   }

   public void mainTest(String[] var1) {
      int var2 = -56983;
      int var3 = 0;
      int var4 = -8298;
      int var5 = -13;
      int var6 = -7;
      int var7 = 31206;
      short var8 = 21623;
      byte var9 = 94;
      double[] var10 = new double[400];
      FuzzerUtils.init(var10, 42.116294);
      iFld -= --iFld;
      var2 = 1;

      while(true) {
         while(true) {
            ++var2;
            if (var2 >= 311) {
               FuzzerUtils.out.println("i i21 i22 = " + var2 + "," + var3 + "," + var4);
               FuzzerUtils.out.println("i23 i24 s2 = " + var5 + "," + var6 + "," + var8);
               FuzzerUtils.out.println("by3 i25 dArr = " + var9 + "," + var7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)));
               FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
               FuzzerUtils.out.println("fFld iArrFld bArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.bArrFld));
               FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
               FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               return;
            }

            switch (var2 % 6 + 5) {
               case 5:
                  vMeth(var2, dFld);
               case 6:
                  instanceCount >>= iFld;
                  this.iArrFld = this.iArrFld;
                  iFld += var2;
                  break;
               case 7:
                  for(var3 = 2; var3 < 81; ++var3) {
                     for(var5 = 1; 2 > var5; ++var5) {
                        boolean var11 = false;
                        switch (var2 % 5 * 5 + 6) {
                           case 11:
                              var4 <<= -46723;
                              var6 += var6;
                              break;
                           case 17:
                              var6 = (int)((long)var6 + ((long)(var5 * var3) + instanceCount - instanceCount));
                              break;
                           case 19:
                              instanceCount = instanceCount;
                              var8 = (short)var9;
                              if (!var11) {
                                 if (var11) {
                                    this.iArrFld = this.iArrFld;
                                 } else if (var11) {
                                    this.iArrFld[var3] = var4;
                                    this.fFld += (float)var7;
                                    var7 %= var2 | 1;
                                    var4 += -2 + var5 * var5;
                                 } else {
                                    var8 = (short)((int)instanceCount);
                                    instanceCount = (long)this.fFld;
                                    var10 = var10;
                                    this.iArrFld[var2 + 1] = var2;
                                 }
                              }
                              break;
                           case 28:
                              this.fFld += this.fFld;
                              break;
                           case 29:
                              this.bArrFld[var2 - 1] = var11;
                              var4 >>= var8;
                              instanceCount <<= var8;
                        }
                     }
                  }
                  break;
               case 8:
                  instanceCount = (long)var7;
                  break;
               case 9:
                  iFld += var3;
                  break;
               case 10:
                  var6 <<= var6;
               default:
                  var8 -= (short)((int)instanceCount);
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
