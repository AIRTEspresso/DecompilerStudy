public class Test {
   public static final int N = 400;
   public static long instanceCount = 2852157046L;
   public static int iFld = 11;
   public float fFld = 0.99F;
   public static short[] sArrFld = new short[400];
   public static long vSmallMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, int var2) {
      int var3 = -63634;
      int var4 = 26;
      int var5 = -46396;
      int var6 = 2;
      int[] var7 = new int[400];
      float var8 = -44.323F;
      short var9 = -267;
      byte var10 = -51;
      long[] var11 = new long[400];
      FuzzerUtils.init((int[])var7, (int)-24056);
      FuzzerUtils.init(var11, 2513115404534364896L);
      iFld &= (int)instanceCount;
      var7[(iFld >>> 1) % 400] = (int)instanceCount;
      long[] var12 = var11;
      int var13 = var11.length;

      for(int var14 = 0; var14 < var13; ++var14) {
         long var15 = var12[var14];

         for(var3 = 1; var3 < 4; ++var3) {
            for(var5 = 1; 2 > var5; ++var5) {
               var4 -= var4;
               var7[var3] &= var1;
               var0 = (int)var8;
               var7[var5 + 1] += iFld;
               var9 = var9;
               var8 -= (float)var0;
               var10 += (byte)var4;
               var1 *= -4;
               var15 = (long)((float)var15 + ((float)(var5 * var5) + var8 - (float)var5));
            }

            var6 += var9;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + Float.floatToIntBits(var8) + var9 + var10) + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var11);
   }

   public static void vMeth(int var0) {
      long var1 = 26575L;
      long[] var3 = new long[400];
      double var4 = -2.6092;
      double var6 = 98.79058;
      byte var8 = 12;
      short var9 = 5623;
      float var10 = 1.64F;
      FuzzerUtils.init(var3, -8L);
      var1 = 349L;

      do {
         vMeth1(var0, -153, iFld);
         iFld += (int)(var1 * var1);
      } while(--var1 > 0L);

      var4 = 1.0;

      while(++var4 < 187.0) {
         instanceCount += (long)(var4 * (double)var0 + (double)var1 - (double)var0);
         var0 = -182;
         instanceCount = -5L;
         instanceCount = (long)var0;

         for(var6 = 1.0; 9.0 > var6; var6 += 2.0) {
            iFld += (int)(var6 * (double)var8 + (double)iFld - (double)var9);
            instanceCount += -86L;
            var0 = (int)var1;
            iFld *= (int)var10;
            var3[(int)var4] += (long)var0;
            instanceCount += (long)var6;
         }
      }

      vMeth_check_sum += (long)var0 + var1 + Double.doubleToLongBits(var4) + Double.doubleToLongBits(var6) + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var3);
   }

   public static void vSmallMeth(long var0, int var2) {
      vMeth(5835);
      iFld /= var2 | 1;
      vSmallMeth_check_sum += var0 + (long)var2;
   }

   public void mainTest(String[] var1) {
      int var2 = 16414;
      int var3 = -45584;
      int var4 = -59418;
      boolean var5 = true;
      byte var6 = 15;
      short var7 = -5406;
      float[] var8 = new float[400];
      FuzzerUtils.init(var8, 1.382F);
      sArrFld[(iFld >>> 1) % 400] = (short)(iFld &= (int)(~(instanceCount * 180L)));
      float var10000 = --this.fFld;
      ++var2;
      var2 = (int)(var10000 + (float)var2 - (float)(-var2 * (var7 - var2)));

      for(var3 = 290; var3 > 2; --var3) {
         var4 = (int)((float)(instanceCount++) + this.fFld);
      }

      for(int var9 = 0; var9 < 282; ++var9) {
         vSmallMeth(instanceCount, var4);
      }

      var4 += var2;

      int var10;
      for(var10 = 7; var10 < 137; ++var10) {
         var2 >>= var10;
      }

      FuzzerUtils.out.println("i s i1 = " + var2 + "," + var7 + "," + var3);
      FuzzerUtils.out.println("i2 i14 i15 = " + var4 + "," + var10 + "," + var6);
      FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var8)));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((short[])sArrFld, (short)19782);
      vSmallMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
