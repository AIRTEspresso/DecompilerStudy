public class Test {
   public static final int N = 400;
   public static long instanceCount = -22450L;
   public static short sFld = -5318;
   public static boolean bFld = false;
   public static short sFld1 = -9894;
   public static float fFld = 0.378F;
   public float[] fArrFld = new float[400];
   public static int[] iArrFld = new int[400];
   public double[] dArrFld = new double[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth2_check_sum;

   public void vMeth() {
      int var1 = -10;
      int var2 = 0;
      int var3 = 7;
      short var4 = 156;
      short var5 = 245;
      int[] var6 = new int[400];
      double var7 = 0.74801;
      long var9 = 448096626L;
      float var11 = -117.326F;
      FuzzerUtils.init((int[])var6, (int)3608);
      int[] var12 = var6;
      int var13 = var6.length;

      for(int var14 = 0; var14 < var13; ++var14) {
         int var15 = var12[var14];

         for(var1 = 1; 4 > var1; ++var1) {
            ++var15;
            double var10000 = (double)var15;
            ++var15;
            var15 = (int)(var10000 + ((double)(-9 * var15) - (var7 - (double)var15)));
            var9 = 1L;

            do {
               var6[(int)var9] >>>= (int)var9;
               int var16 = var15 - var1;
               var11 = (float)(instanceCount += (long)(Short.reverseBytes(sFld) - (int)instanceCount));
               var2 += (int)((float)(var9 * (long)var2 + (long)sFld) - var11);
               var15 = (int)(-(var7 * 8.0 * (double)Math.min(-30843, var1)));
            } while(++var9 < 2L);

            var7 *= (double)(var2++);

            for(var3 = 1; var3 < 2; ++var3) {
               this.fArrFld = this.fArrFld = this.fArrFld;
               instanceCount = (long)var6[var3];
               var2 %= (int)(instanceCount | 1L);
               var2 = Math.abs(++var6[var3 + 1]) + var3 + var3 + var5 + var1;
            }
         }
      }

      vMeth_check_sum += (long)(var1 + var2) + Double.doubleToLongBits(var7) + var9 + (long)Float.floatToIntBits(var11) + (long)var3 + (long)var4 + (long)var5 + FuzzerUtils.checkSum(var6);
   }

   public static void vMeth2(boolean var0) {
      boolean var1 = true;
      int var2 = -216;
      int var3 = -13;
      int var4 = 27621;
      int var5 = 0;
      int var6 = 40089;
      byte var7 = -1;
      int[] var8 = new int[400];
      float var9 = 0.804F;
      float[][][] var10 = new float[400][400][400];
      double[] var11 = new double[400];
      FuzzerUtils.init(var8, -53761);
      FuzzerUtils.init((Object[][])var10, 90.987F);
      FuzzerUtils.init(var11, 0.40053);

      int var12;
      for(var12 = 142; var12 > 7; var12 -= 3) {
         var2 = var2;
         var10[var12][var12][var12] = 38.337F;

         for(var3 = var12; var3 < 34; ++var3) {
            var11[var3 - 1] = (double)var9;
            var5 = 1;

            while(true) {
               ++var5;
               if (var5 >= 1) {
                  var2 = (int)((long)var2 + (long)var3 + instanceCount);
                  var2 -= var5;

                  for(var6 = 1; var6 < 1; ++var6) {
                     var2 -= 14352;
                     var9 *= (float)instanceCount;
                     var9 = (float)var6;
                     var4 = var2 >> var2;
                  }
                  break;
               }

               var8[var3 + 1] = var2;
            }
         }
      }

      vMeth2_check_sum += (long)((var0 ? 1 : 0) + var12 + var2 + var3 + var4 + Float.floatToIntBits(var9) + var5 + var6 + var7) + FuzzerUtils.checkSum(var8) + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var10)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11));
   }

   public static int iMeth(int var0, byte var1, float var2) {
      boolean var3 = true;
      int var4 = 60588;
      int var5 = -36931;
      int var6 = -202;
      int var7 = -65326;
      double var8 = 117.70311;
      long[] var10 = new long[400];
      FuzzerUtils.init(var10, 5L);
      vMeth2(bFld);
      var0 = var0;
      int var13 = 1;

      do {
         for(var4 = 1; var4 < 9; ++var4) {
            switch ((var13 >>> 1) % 10 + 1) {
               case 1:
                  sFld += (short)((int)((long)(var4 * var5) + instanceCount - (long)var0));

                  for(var6 = 1; var6 < 2; ++var6) {
                     instanceCount += (long)var4;
                     instanceCount += (long)var6;
                     var8 += var8;
                     var8 -= 2.534579257E9;
                     var2 += (float)var6;
                     var7 = sFld1;
                     var0 = (int)instanceCount;
                  }

                  var0 += 455988198;
                  break;
               case 2:
                  iArrFld[var4] = var4;
                  break;
               case 3:
                  sFld1 += (short)((int)instanceCount);
                  break;
               case 4:
                  var10[(var4 >>> 1) % 400] = (long)var0;
               case 5:
                  var7 = var4;
                  break;
               case 6:
                  var0 = (int)instanceCount;
               case 7:
                  var5 = (int)var8;
                  break;
               case 8:
                  instanceCount = (long)var6;
                  break;
               case 9:
                  var5 = (int)var8;
               case 10:
                  if (bFld) {
                  }
                  break;
               default:
                  int[] var10000 = iArrFld;
                  var10000[var4 + 1] >>= -220;
            }
         }

         ++var13;
      } while(var13 < 171);

      long var11 = (long)(var0 + var1 + Float.floatToIntBits(var2) + var13 + var4 + var5 + var6 + var7) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static void vMeth1() {
      int var0 = 17;
      int var1 = -41456;
      int var2 = 243;
      int var3 = -46258;
      int var4 = 2;
      char var5 = '햎';
      byte var6 = 119;
      double var7 = -1.47089;
      double var9 = 1.45159;
      if (bFld) {
         instanceCount = -206L;
         var0 += iMeth(var0, var6, fFld);
      } else if (bFld) {
         var0 *= 192;

         for(var7 = 1.0; var7 < 214.0; var7 += 3.0) {
            for(var2 = (int)var7; 22 > var2; ++var2) {
               instanceCount = -4L;
               var0 += sFld;
               var6 -= (byte)var0;
               iArrFld = iArrFld;
            }

            iArrFld[(int)var7] = var2;
         }

         for(var4 = 286; 7 < var4; --var4) {
            var3 = (int)((long)var3 + ((long)var4 * instanceCount + (long)var1 - (long)var3));
            var9 += (double)var3;
            instanceCount *= (long)var4;
         }
      } else if (bFld) {
         var3 *= (int)fFld;
      }

      vMeth1_check_sum += (long)(var0 + var6) + Double.doubleToLongBits(var7) + (long)var1 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + Double.doubleToLongBits(var9);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 6;
      int var4 = -14;
      int var5 = 64503;
      boolean var6 = true;
      short var7 = 248;
      int var8 = 7;
      int var9 = -45417;
      int var10 = -49716;
      int var11 = -42;
      double var12 = -2.1235;
      byte var14 = -97;
      byte[] var15 = new byte[400];
      float var16 = 76.96F;
      FuzzerUtils.init(var15, (byte)-43);
      this.vMeth();
      vMeth1();

      int var19;
      for(var19 = 1; var19 < 339; ++var19) {
         for(var4 = 1; var4 < 74; ++var4) {
            var15[var19 + 1] -= (byte)var3;
            var5 += (int)fFld;
            var5 *= var19;
            var12 = (double)var4;
            var5 += var4 * var4;
            var3 += var5;
            var3 |= var4;
            var5 += (int)(158868936188254660L + (long)(var4 * var4));
         }

         double[] var10000 = this.dArrFld;
         var10000[var19] -= (double)var4;
      }

      int var20;
      for(var20 = 9; var20 < 209; ++var20) {
         var8 = 1;

         do {
            for(var9 = 1; 1 < var9; var9 -= 3) {
               var10 -= 12;
               instanceCount += -4007248630L + (long)(var9 * var9);
               bFld = bFld;
               var14 = (byte)var19;
            }

            var5 += var8;
            var11 = 1;

            do {
               bFld = true;
               var12 += 11.0;
               label49:
               switch (var20 % 3 + 118) {
                  case 118:
                     switch (var20 % 7 + 106) {
                        case 106:
                           iArrFld[var20 - 1] = (int)var12;
                           break label49;
                        case 107:
                           var7 = var14;
                           break label49;
                        case 108:
                           try {
                              iArrFld[var20] = -11713 % var20;
                              var5 = -166 / iArrFld[var20 - 1];
                              var3 = var5 % iArrFld[var8];
                           } catch (ArithmeticException var18) {
                           }
                           break label49;
                        case 109:
                           instanceCount += (long)(var11 | var20);
                           break label49;
                        case 110:
                           var3 >>= -206;
                           break label49;
                        case 111:
                           instanceCount += -4L + (long)(var11 * var11);
                        case 112:
                           float[] var21 = this.fArrFld;
                           var21[var11] += (float)var11;
                        default:
                           break label49;
                     }
                  case 119:
                     fFld *= (float)var7;
                  case 120:
                     this.fArrFld[(var5 >>> 1) % 400] = fFld;
                     break;
                  default:
                     var16 = (float)var12;
               }

               ++var11;
            } while(var11 < 1);

            ++var8;
         } while(var8 < 126);
      }

      FuzzerUtils.out.println("i26 i27 i28 = " + var19 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i29 d4 i30 = " + var5 + "," + Double.doubleToLongBits(var12) + "," + var20);
      FuzzerUtils.out.println("i31 i32 i33 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i34 by2 i35 = " + var10 + "," + var14 + "," + var11);
      FuzzerUtils.out.println("f3 byArr = " + Float.floatToIntBits(var16) + "," + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + sFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.sFld1 Test.fFld fArrFld = " + sFld1 + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("Test.iArrFld dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-209);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
