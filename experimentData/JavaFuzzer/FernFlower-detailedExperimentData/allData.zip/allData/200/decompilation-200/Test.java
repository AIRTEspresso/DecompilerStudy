public class Test {
   public static final int N = 400;
   public static long instanceCount = 3677L;
   public static volatile boolean bFld = false;
   public static int iFld = 37466;
   public int iFld1 = 39050;
   public static volatile int[] iArrFld = new int[400];
   public float[] fArrFld = new float[400];
   public volatile long[] lArrFld = new long[400];
   public static long vSmallMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      double var1 = 2.6701;
      byte var3 = -28;
      int var4 = -121;
      byte var5 = 124;
      int var6 = -67;
      int var7 = 7;
      float var8 = 0.524F;
      float[] var9 = new float[400];
      short var10 = -31039;
      short[] var11 = new short[400];
      FuzzerUtils.init(var11, (short)-7701);
      FuzzerUtils.init(var9, 0.4F);
      if (!bFld) {
         if (bFld) {
            int var10002 = iArrFld[257]++;
         } else {
            var7 += var5;
         }

         vMeth1_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var8) + (long)var10 + FuzzerUtils.checkSum(var11) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
      } else {
         var0 -= 2;
         int[] var12 = iArrFld;
         int var13 = var12.length;

         for(int var14 = 0; var14 < var13; ++var14) {
            int var15 = var12[var14];
            var1 -= (double)var3;

            try {
               var0 %= var15;
               var15 /= var0;
               var15 = 89 / var15;
            } catch (ArithmeticException var17) {
            }

            label52:
            for(var4 = 1; var4 < 4; ++var4) {
               if (!bFld) {
                  switch ((var0 >>> 1) % 3 + 79) {
                     case 79:
                        var0 = (int)instanceCount;
                     case 80:
                        var6 = var4;

                        while(true) {
                           if (var6 >= 2) {
                              continue label52;
                           }

                           instanceCount = (long)((float)instanceCount + ((float)var6 * var8 + (float)var10 - (float)var0));
                           instanceCount *= (long)var8;
                           iArrFld[var4 + 1] = (int)instanceCount;
                           var11[var4 + 1] -= (short)var7;
                           int[] var10000 = iArrFld;
                           var10000[var4 - 1] += (int)var8;
                           ++var6;
                        }
                     case 81:
                        var15 += var4 ^ var6;
                        break;
                     default:
                        instanceCount = 450198295L;
                  }
               }
            }
         }

         vMeth1_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var8) + (long)var10 + FuzzerUtils.checkSum(var11) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
      }
   }

   public static void vMeth(int var0, int var1) {
      long[] var2 = new long[400];
      FuzzerUtils.init(var2, 244L);
      vMeth1(var1);
      instanceCount -= instanceCount;
      var2[(var0 >>> 1) % 400] += (long)var1;
      var2[(var1 >>> 1) % 400] = instanceCount;
      vMeth_check_sum += (long)(var0 + var1) + FuzzerUtils.checkSum(var2);
   }

   public static void vSmallMeth(int var0, int var1, short var2) {
      var0 >>>= var1;
      vMeth(var1, -52028);
      vSmallMeth_check_sum += (long)(var0 + var1 + var2);
   }

   public void mainTest(String[] var1) {
      int var2 = -35318;
      boolean var3 = true;
      int var4 = 46;
      int var5 = -9;
      int var6 = 159;
      int var7 = 4;
      int var8 = -8;
      short var9 = -30473;
      double var10 = -2.117285;
      float var12 = -82.563F;
      long var13 = 10L;

      for(int var15 = 0; var15 < 158; ++var15) {
         vSmallMeth(var2, var2, var9);
      }

      instanceCount = (long)var2;

      int var17;
      for(var17 = 13; var17 < 248; ++var17) {
         var2 = var4;
         var4 /= var4 | 1;

         for(var5 = 3; var5 < 107; ++var5) {
            switch ((var2 >>> 1) % 1 + 41) {
               case 41:
                  int var10000 = var2 + (int)var10;
                  var4 += var5;
                  break;
               default:
                  this.fArrFld[var5] = (float)var5;
                  var12 += (float)(var5 * var6 + var2 - var6);
            }

            var4 <<= -59098;
            var2 = var17;

            for(var7 = 1; var7 < 2; ++var7) {
               var13 += instanceCount;
               var10 = (double)var2;
               bFld = true;
               var12 = (float)var2;
               var8 -= var4;
               instanceCount &= (long)var8;

               try {
                  var6 = iArrFld[var17 - 1] % -36362;
                  iFld = -8115 / var17;
                  var6 = -1 % var2;
               } catch (ArithmeticException var16) {
               }
            }

            var4 = 57453;
            long[] var18 = this.lArrFld;
            var18[var5] *= (long)var2;
            var6 += (int)var13;
         }

         int[] var19 = iArrFld;
         var19[var17 + 1] &= var6;
         instanceCount >>= 14;
         var13 += (long)(var17 | var4);
         var2 = var6;
         var4 *= 63470;
      }

      var13 ^= (long)var4;
      FuzzerUtils.out.println("i10 s2 i11 = " + var2 + "," + var9 + "," + var17);
      FuzzerUtils.out.println("i12 i13 i14 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("d1 f2 i15 = " + Double.doubleToLongBits(var10) + "," + Float.floatToIntBits(var12) + "," + var7);
      FuzzerUtils.out.println("i16 l = " + var8 + "," + var13);
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + iFld);
      FuzzerUtils.out.println("iFld1 Test.iArrFld fArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-6);
      vSmallMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
