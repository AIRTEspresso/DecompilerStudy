public class Test {
   public static final int N = 400;
   public static long instanceCount = -60085L;
   public static byte byFld = -3;
   public static float fFld = 125.127F;
   public static double dFld = -2.2675;
   public static int iFld = 12;
   public boolean bFld = true;
   public static short sFld = 22065;
   public static float[] fArrFld = new float[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1) {
      double var2 = -1.69204;
      boolean var4 = true;
      byte var5 = -1;
      int var6 = -184;
      int var7 = -17594;
      int var8 = -61718;
      int[] var9 = new int[400];
      FuzzerUtils.init((int[])var9, (int)21259);

      for(var2 = 1.0; ++var2 < 137.0; instanceCount += (long)var0) {
         var1 >>= var0;
      }

      int var10;
      for(var10 = 219; 2 < var10; --var10) {
         switch (var10 % 6 * 5 + 99) {
            case 100:
               var9[var10] = var8;
               break;
            case 111:
               instanceCount -= 0L;
               break;
            case 117:
               var0 += 232;
               break;
            case 118:
               dFld += -14589.0;
            case 105:
               fFld = (float)var8;
               break;
            case 120:
               instanceCount += (long)('ꔈ' + var10 * var10);
               instanceCount ^= instanceCount;
               var6 = 1;

               do {
                  for(var7 = 1; var7 < 3; ++var7) {
                     fFld -= (float)var0;
                     dFld *= 9.0;
                     var1 += var7 * var0;
                     var0 += 182;
                     var1 -= (int)fFld;
                  }

                  var6 += 2;
               } while(var6 < 7);

               instanceCount &= -35L;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var10 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      int var2 = -133;
      int var3 = 4;
      int var4 = 158;
      int var5 = -47214;
      int var6 = 0;
      int var7 = -6;
      int[] var8 = new int[400];
      boolean var9 = false;
      float var10 = 1.405F;
      float[][][] var11 = new float[400][400][400];
      short var12 = 14175;
      long[] var13 = new long[400];
      long[][][] var14 = new long[400][400][400];
      FuzzerUtils.init((int[])var8, (int)135);
      FuzzerUtils.init(var13, -1392964188L);
      FuzzerUtils.init((Object[][])var14, -1046417596L);
      FuzzerUtils.init((Object[][])var11, -96.943F);
      long var10000 = instanceCount;
      byte var10002 = byFld;
      byFld = (byte)(var10002 + 1);
      instanceCount = var10000 + (long)(var0 - var10002);
      int var18 = 1;

      while(true) {
         while(true) {
            ++var18;
            if (var18 >= 232) {
               vMeth_check_sum += (long)(var0 + var18 + var2 + var3 + var4 + var5 + (var9 ? 1 : 0) + Float.floatToIntBits(var10) + var6 + var7 + var12) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var13) + FuzzerUtils.checkSum((Object[][])var14) + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var11));
               return;
            }

            switch (var18 + 117) {
               case 117:
                  var0 = (int)(--instanceCount);

                  for(var2 = 1; var2 < 7; ++var2) {
                     var3 += var2;
                     instanceCount *= (long)((float)(instanceCount + (long)var3 + (long)(var2 + var18)) - ((float)instanceCount - 2.689F - fFld));
                     vMeth1(var3, -8536);
                     dFld += (double)var18;

                     for(var4 = var2; var4 < 2 && !var9; ++var4) {
                        byFld = -22;
                     }

                     for(var10 = (float)var18; var10 < 2.0F; ++var10) {
                        fFld += var10 * (float)instanceCount;
                        var3 += (int)(var10 - (float)var3);
                     }
                  }
                  break;
               case 118:
                  instanceCount %= (long)(var3 | 1);
                  break;
               case 119:
                  instanceCount = (long)var2;
                  break;
               case 120:
                  instanceCount >>= var2;
                  break;
               case 121:
               case 122:
                  var8 = var8;
                  break;
               case 123:
                  var3 = var4;
                  break;
               case 124:
                  var0 = (int)((long)var0 + ((long)(var18 * var0) + instanceCount - (long)var5));
                  break;
               case 125:
                  fFld += var10;
                  break;
               case 126:
                  instanceCount = instanceCount;
                  break;
               case 127:
                  var5 = var2;
               case 128:
                  instanceCount = (long)var18;
               case 129:
                  try {
                     var5 = -45037 / var8[(var2 >>> 1) % 400];
                     var6 = var3 % '뼫';
                     var6 = -25073 % var5;
                  } catch (ArithmeticException var17) {
                  }
                  break;
               case 130:
                  fFld += (float)var18;
                  break;
               case 131:
                  var8[var18 - 1] += var3;
               case 132:
                  var8[var18 + 1] <<= var4;
                  break;
               case 133:
                  var13[var18 - 1] *= (long)var4;
                  break;
               case 134:
                  dFld = (double)instanceCount;
                  break;
               case 135:
                  var0 += var18;
                  break;
               case 136:
                  if (var9) {
                  }
                  break;
               case 137:
                  if (var9) {
                     break;
                  }
               case 138:
                  var0 = var5;
               case 139:
                  var3 >>= var3;
                  break;
               case 140:
                  var0 = var0;
                  break;
               case 141:
                  var0 *= 1;
                  break;
               case 142:
                  var7 *= var18;
               case 143:
                  var5 ^= var5;
                  break;
               case 144:
                  try {
                     var5 = 54 / var4;
                     var8[var18] = var5 % -34365;
                     var7 = var8[var18 - 1] % 170;
                  } catch (ArithmeticException var16) {
                  }
                  break;
               case 145:
                  var5 >>>= var3;
                  break;
               case 146:
                  fFld += (float)(1L + (long)(var18 * var18));
                  break;
               case 147:
                  var6 -= var6;
               case 148:
               case 149:
                  var3 = var18;
                  break;
               case 150:
                  byFld = 4;
                  break;
               case 151:
                  var8 = var8;
                  break;
               case 152:
                  var3 *= 94;
                  break;
               case 153:
                  var5 = (int)instanceCount;
                  break;
               case 154:
                  var0 -= var6;
                  break;
               case 155:
                  dFld += (double)instanceCount;
                  break;
               case 156:
                  var8[var18 - 1] = (int)instanceCount;
               case 157:
                  var5 += var18 * var18;
                  break;
               case 158:
                  var14 = var14;
                  break;
               case 159:
                  var3 += var6;
                  break;
               case 160:
                  var6 = (int)((long)var6 + ((long)var18 - instanceCount));
                  break;
               case 161:
                  instanceCount += (long)(var18 * var2 + var18 - var2);
               case 162:
                  dFld -= (double)var0;
                  break;
               case 163:
                  instanceCount -= (long)dFld;
               case 164:
                  var7 -= var7;
               case 165:
                  var6 %= (int)(instanceCount | 1L);
                  break;
               case 166:
                  var12 += (short)((int)instanceCount);
                  break;
               case 167:
                  var8[var18 + 1] = -7;
                  break;
               case 168:
                  instanceCount = (long)iFld;
                  break;
               case 169:
               case 170:
                  var14[var18 - 1][var18] = FuzzerUtils.long1array(400, -212L);
                  break;
               case 171:
                  iFld -= var0;
               case 172:
                  var0 = var6;
                  break;
               case 173:
                  instanceCount += instanceCount;
                  break;
               case 174:
                  instanceCount *= (long)var6;
                  break;
               case 175:
                  var3 = (int)((long)var3 + (long)var18 * instanceCount);
                  break;
               case 176:
                  var7 = -34;
                  break;
               case 177:
                  var7 = (int)instanceCount;
                  break;
               case 178:
                  var11 = var11;
                  break;
               case 179:
                  var6 *= (int)var10;
                  break;
               case 180:
               case 181:
                  iFld += var4;
               case 182:
                  var0 += var18 ^ var7;
                  break;
               case 183:
               case 184:
                  iFld >>= var18;
                  break;
               case 185:
                  instanceCount += (long)var0;
                  break;
               case 186:
                  instanceCount += (long)(var18 + var7);
            }
         }
      }
   }

   public int iMeth(long var1, int var3, short var4) {
      boolean var5 = true;
      int var6 = -4;
      byte var7 = 14;
      int var8 = 24;
      int var9 = -34437;
      int[] var10 = new int[400];
      double var11 = -1.19643;
      FuzzerUtils.init((int[])var10, (int)7);

      int var15;
      for(var15 = 189; var15 > 10; var15 -= 3) {
         float var13 = 1.885F;
         --var6;
         var13 -= (float)(var6 + (var3 - var15)) - ++var13;

         for(var11 = (double)var15; var11 < 26.0; ++var11) {
            vMeth(var7);
            byFld -= (byte)var15;
            var3 += (int)var11;

            for(var8 = 1; var8 < 1; ++var8) {
               var10[var15] += (int)var11;
               this.bFld = false;
               var3 += var8 * var9 + var7 - byFld;
               instanceCount = (long)iFld;
               var6 = var7;
               dFld = (double)iFld;
               byFld += (byte)(207 + var8 * var8);
            }
         }
      }

      long var16 = var1 + (long)var3 + (long)var4 + (long)var15 + (long)var6 + Double.doubleToLongBits(var11) + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var16;
      return (int)var16;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 101;
      int var4 = 4;
      int var5 = -93;
      int var6 = -20696;
      int var7 = 6;
      int var8 = -118;
      int var9 = 25946;
      int var10 = 12196;
      short var11 = -7197;
      int[] var12 = new int[400];
      long var13 = -61015L;
      FuzzerUtils.init(var12, -64688);

      int var15;
      for(var15 = 3; var15 < 239; ++var15) {
         for(var4 = 1; var4 < 106; ++var4) {
            var5 = this.iMeth(-6L, var4, sFld) * var5;
            var3 = (int)instanceCount;

            for(var13 = 2L; --var13 > 0L; instanceCount -= (long)var6) {
               iFld ^= -937115070;
               instanceCount -= (long)var15;
               var5 = (int)dFld;
               var6 *= var4;
               fFld = (float)var6;
               iFld = var5;
               instanceCount -= (long)var3;
               instanceCount -= (long)var6;
            }

            for(var7 = 1; var7 < 2; var7 += 3) {
               var5 %= byFld | 1;
               var6 += var7 ^ iFld;
            }

            var5 = var7;
            instanceCount *= (long)fFld;
         }

         var8 = (int)((float)var8 + ((float)((long)(var15 * var8) + var13) - fFld));
         var3 += var5;
         float[] var10000 = fArrFld;
         var10000[var15] += -9.0F;
         var9 = 1;

         do {
            var3 += var9;
            switch (93) {
               case 91:
                  iFld = var3;

                  for(var10 = var15; var10 < 1; ++var10) {
                     var8 += var10 * var4;
                     var8 += var7;
                     var12[var10 - 1] = var15;
                  }
               case 93:
                  var3 *= sFld;
            }

            ++var9;
         } while(var9 < 106);
      }

      FuzzerUtils.out.println("i i1 i2 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 l1 i26 = " + var5 + "," + var13 + "," + var6);
      FuzzerUtils.out.println("i27 i28 i29 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i30 i31 iArr3 = " + var10 + "," + var11 + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.dFld Test.iFld bFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.sFld Test.fArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 42.749F);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
