public class Test {
   public static final int N = 400;
   public static long instanceCount = -8L;
   public static int iFld = 10;
   public static short sFld = -30775;
   public float fFld = -116.725F;
   public boolean bFld = false;
   public static float fFld1 = -80.97F;
   public static boolean bFld1 = true;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      boolean var1 = true;
      int var2 = -62929;
      int var3 = -59205;
      int var4 = 157;
      int var5 = 56578;
      int var6 = 118;
      short var7 = 29973;

      int var8;
      for(var8 = 11; 334 > var8; ++var8) {
         int[] var10000 = iArrFld;
         var10000[var8 + 1] -= 30561;

         for(var3 = 1; var3 < 5; ++var3) {
            for(var5 = 1; 2 > var5; ++var5) {
               var0 = var4;
               fFld1 -= -74.0F;
               var6 *= var6;
               var6 >>= 1369483419;
               var6 *= -12757;
               switch (var8 % 2 + 29) {
                  case 29:
                     sFld >>= (short)iFld;
                     break;
                  case 30:
                     fFld1 += -48.891F + (float)(var5 * var5);
                     var7 >>= (short)iFld;
               }

               var4 += var5;
            }

            var0 += iFld;
         }
      }

      vMeth1_check_sum += (long)(var0 + var8 + var2 + var3 + var4 + var5 + var6 + var7);
   }

   public static void vMeth(float var0, int var1) {
      int var2 = -38934;
      int var3 = -6490;
      short var4 = 19410;
      int var5 = -10;
      byte var6 = -9;
      double var7 = -52.25984;
      byte var9 = -68;
      long var10 = -1630227261L;

      for(var2 = 1; var2 < 279; ++var2) {
         var0 -= (float)(var7 - var7-- + (double)(--var0 * (float)var9));
         var3 = Math.max(iArrFld[var2 + 1], (int)(-((long)var3 * instanceCount)));
         var1 += var2;
         vMeth1(var2);
         if (bFld1) {
            int[] var10000 = iArrFld;
            var10000[var2] += var2;
         } else if (bFld1) {
            instanceCount += (long)(var2 * var3 + var1 - var3);
            iArrFld[var2 - 1] = (int)var0;
            instanceCount = instanceCount;
            var3 = var4;
         } else if (bFld1) {
            for(var5 = 6; var5 > 1; --var5) {
               var10 <<= iFld;
               var9 = (byte)(var9 << 4);
               var1 >>>= 2637;
            }
         }
      }

      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1 + var2 + var3) + Double.doubleToLongBits(var7) + (long)var9 + (long)var4 + (long)var5 + (long)var6 + var10;
   }

   public static int iMeth() {
      int var0 = 38915;
      int var1 = -9;
      int var2 = -12;
      int var3 = -4;
      double var4 = -2.69176;

      for(var0 = 9; 213 > var0; ++var0) {
         try {
            iFld = iArrFld[var0 - 1] / -53408;
            var1 = 1813546770 % var1;
            iArrFld[var0 + 1] = iArrFld[var0 - 1] % -8;
         } catch (ArithmeticException var8) {
         }

         var2 = 1;

         while(8 > var2) {
            var3 -= --iArrFld[var2 - 1] - (Math.abs(-12) + var2);
            vMeth(fFld1, var2);
            fFld1 += (float)var2;
            var1 -= 140;
            iFld = var0;
            var1 = iFld;
            instanceCount = (long)fFld1;
            switch (var0 % 2 * 5 + 11) {
               case 12:
                  if (var2 != 0) {
                  }

                  instanceCount -= 16L;
                  int[] var10000 = iArrFld;
                  var10000[var2 - 1] *= var3;
               case 17:
                  var3 = (int)var4;
               default:
                  var4 += 40311.0;
                  ++var2;
            }
         }
      }

      long var6 = (long)(var0 + var1 + var2 + var3) + Double.doubleToLongBits(var4);
      iMeth_check_sum += var6;
      return (int)var6;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -4;
      int var4 = -6;
      int var5 = 116;
      int var6 = -1;
      byte var7 = -11;
      boolean var8 = true;
      double[] var9 = new double[400];
      boolean[] var10 = new boolean[400];
      long[][] var11 = new long[400][400];
      FuzzerUtils.init(var9, 0.56855);
      FuzzerUtils.init(var10, true);
      FuzzerUtils.init(var11, -3426413554L);
      iFld -= (int)(instanceCount--);
      sFld += (short)((int)(++this.fFld));

      int var12;
      for(var12 = 174; 2 < var12; --var12) {
         var4 = 1;

         do {
            for(var5 = 1; var5 < 1; ++var5) {
               iFld <<= -52526;
               this.fFld -= 5.0F;
               var3 ^= var6;
               sFld >>= (short)var12;
               switch (var12 % 3 + 94) {
                  case 94:
                     var6 = var12;
                     var3 += var5;
                     var3 ^= var5;
                     fFld1 *= (float)var5;
                     break;
                  case 95:
                     var9[var12] *= (double)var6;
                     iFld = (int)((float)iFld + ((float)var5 * this.fFld + (float)var5 - (float)iFld));
                     break;
                  case 96:
                     iFld = (int)((long)iFld + ((long)var5 * instanceCount + (long)iFld - (long)var12));
               }

               sFld = 121;
               instanceCount += (long)var5;
               var9[var5 + 1] -= (double)instanceCount;
               var3 -= var12;
               instanceCount += (long)(var5 + var7);
               var10[var12 - 1] = this.bFld;
            }

            ++var4;
         } while(var4 < 146);

         var11[var12] = var11[var12];
      }

      byte var13 = (byte)((int)instanceCount);
      FuzzerUtils.out.println("i i1 i2 = " + var12 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 i4 i22 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("by1 dArr bArr = " + var13 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)) + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
      FuzzerUtils.out.println("fFld bFld Test.fFld1 = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld1));
      FuzzerUtils.out.println("Test.bFld1 Test.iArrFld = " + (bFld1 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)93);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
