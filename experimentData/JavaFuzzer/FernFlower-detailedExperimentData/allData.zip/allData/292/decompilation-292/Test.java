public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -216L;
   public static byte byFld = -69;
   public static float fFld = -25.276F;
   public volatile int iFld = -64572;
   public short sFld = -5698;
   public double dFld = -1.119064;
   public static volatile byte byFld1 = -86;
   public static long[] lArrFld = new long[400];
   public static byte[] byArrFld = new byte[400];
   public static int[] iArrFld = new int[400];
   public short[] sArrFld = new short[400];
   public static long vSmallMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(long var0) {
      double var2 = 0.5759;
      short var4 = 187;
      boolean var5 = true;
      byte var6 = 2;
      var2 += (double)var4;

      int var7;
      for(var7 = 4; var7 < 268; ++var7) {
         byFld <<= -64;
      }

      var0 = -14L;
      vMeth_check_sum += var0 + Double.doubleToLongBits(var2) + (long)var4 + (long)var7 + (long)var6;
   }

   public static int iMeth(long var0, int var2) {
      boolean var3 = true;
      boolean var4 = true;
      int var5 = -16427;
      int var6 = 23124;
      byte var7 = -10;
      int var8 = -14;
      byte var9 = 13;
      int[] var10 = new int[400];
      short var11 = 8136;
      FuzzerUtils.init((int[])var10, (int)6161);
      vMeth(instanceCount);
      var3 = false;

      int var14;
      for(var14 = 3; var14 < 374; ++var14) {
         var2 -= var5;

         for(var6 = 1; var6 < 5; ++var6) {
            var11 = (short)var2;
         }

         if (var3) {
            var8 = 5;

            while(true) {
               --var8;
               if (var8 <= 0) {
                  break;
               }

               var0 = (long)var7;
               long var10000 = var0 + (long)(var8 * var14 + var9 - var2);
               var0 = (long)var8;
               var5 = var7;
               var10[var14 - 1] *= var14;
            }
         } else {
            instanceCount = -13L;
            var5 = (int)((long)var5 + (long)var14 * instanceCount);
         }
      }

      long var12 = var0 + (long)var2 + (long)(var3 ? 1 : 0) + (long)var14 + (long)var5 + (long)var6 + (long)var7 + (long)var11 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public static void vSmallMeth(long var0, int var2) {
      var2 = var2-- + iMeth(var0, var2);
      fFld -= -50.58F;
      vSmallMeth_check_sum += var0 + (long)var2;
   }

   public void mainTest(String[] var1) {
      int var2 = -44780;
      boolean var3 = true;
      int var4 = -116;
      int var5 = -3485;
      int var6 = -3;
      int var7 = 196;
      int var8 = 12;
      boolean var9 = false;

      for(int var10 = 0; var10 < 790; ++var10) {
         vSmallMeth(instanceCount, this.iFld);
      }

      var2 = 216;

      while(true) {
         var2 -= 2;
         if (var2 <= 0) {
            instanceCount *= instanceCount;
            this.iFld <<= (int)instanceCount;

            int var11;
            for(var11 = 16; 391 > var11; ++var11) {
               fFld = (float)this.iFld;
               if (!var9) {
                  if (var9) {
                     var8 *= (int)instanceCount;
                  } else {
                     short[] var13 = this.sArrFld;
                     var13[var11 + 1] = (short)(var13[var11 + 1] + 13);
                  }
               } else {
                  var4 = (int)((float)var4 + ((float)(var11 * var2 + var4) - fFld));

                  for(var5 = 67; 3 < var5; --var5) {
                     byFld += (byte)var5;
                     long[] var10000 = lArrFld;
                     var10000[var5 + 1] |= (long)var2;
                     var4 += var5 * var2 + var6 - var11;
                     switch (var11 % 8 + 80) {
                        case 80:
                           fFld += (float)var5;
                           byte[] var12 = byArrFld;
                           var12[var11 - 1] &= (byte)var6;
                           break;
                        case 81:
                           var6 = (int)this.dFld;
                           var7 = 1;

                           while(var7 < 2) {
                              this.sFld = (short)(this.sFld - 0);
                              switch (var5 % 1 * 5 + 73) {
                                 case 76:
                                    iArrFld[var11 - 1] = (int)instanceCount;
                                    var6 += 229;
                                    var4 -= (int)this.dFld;
                                    if (var9) {
                                       switch (var7 % 2 * 5 + 36) {
                                          case 38:
                                          case 42:
                                             var8 = var6;
                                       }
                                    } else if (var9) {
                                       var6 = var6;
                                    } else if (var9) {
                                       this.sFld += (short)(var7 * var11 + var2 - var11);
                                    }
                                 default:
                                    ++var7;
                              }
                           }
                        case 82:
                           var8 += var5;
                           break;
                        case 83:
                           var4 -= (int)instanceCount;
                           break;
                        case 84:
                           iArrFld = iArrFld;
                        case 85:
                           this.sFld -= (short)((int)instanceCount);
                           break;
                        case 86:
                           var6 += var5 - var5;
                           break;
                        case 87:
                           var8 = byFld;
                     }
                  }
               }
            }

            FuzzerUtils.out.println("i11 i12 i13 = " + var2 + "," + var11 + "," + var4);
            FuzzerUtils.out.println("i14 i15 i16 = " + var5 + "," + var6 + "," + var7);
            FuzzerUtils.out.println("i17 b1 = " + var8 + "," + (var9 ? 1 : 0));
            FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(fFld));
            FuzzerUtils.out.println("iFld sFld dFld = " + this.iFld + "," + this.sFld + "," + Double.doubleToLongBits(this.dFld));
            FuzzerUtils.out.println("Test.byFld1 Test.lArrFld Test.byArrFld = " + byFld1 + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
            FuzzerUtils.out.println("Test.iArrFld sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
            return;
         }

         this.sFld += (short)var2;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 2439062821416184846L);
      FuzzerUtils.init((byte[])byArrFld, (byte)0);
      FuzzerUtils.init((int[])iArrFld, (int)33527);
      vSmallMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
