public class Test {
   public static final int N = 400;
   public static long instanceCount = 3260064452L;
   public volatile int iFld = -42144;
   public static volatile boolean bFld = true;
   public static float fFld = 0.42F;
   public double dFld = -1.40777;
   public static byte byFld = -85;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = 18148;
      int var2 = 199;
      byte var3 = -4;
      int var4 = 22154;
      float var5 = 33.128F;
      boolean var6 = false;
      long var7 = 7590L;
      double[] var9 = new double[400];
      FuzzerUtils.init(var9, 0.2025);
      int var11 = 4850;
      if (var6) {
         var5 -= (float)var11;
         var11 *= (int)var5;
         vMeth1_check_sum += (long)(var11 + Float.floatToIntBits(var5) + (var6 ? 1 : 0) + var1 + var2 + var3) + var7 + (long)var4 + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
      } else {
         var1 = 1;

         while(true) {
            ++var1;
            if (var1 >= 127) {
               vMeth1_check_sum += (long)(var11 + Float.floatToIntBits(var5) + (var6 ? 1 : 0) + var1 + var2 + var3) + var7 + (long)var4 + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
               return;
            }

            for(var2 = 1; var2 < 12; ++var2) {
               var9[var1 + 1] *= (double)var1;
               var11 = (int)var7;
               if (var11 != 0) {
                  vMeth1_check_sum += (long)(var11 + Float.floatToIntBits(var5) + (var6 ? 1 : 0) + var1 + var2 + var3) + var7 + (long)var4 + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
                  return;
               }

               if (!var6) {
                  var0 = true;
                  var4 = 1;

                  do {
                     boolean var10 = true;
                     var11 = -52591;
                     var5 += (float)var4;
                     ++var4;
                  } while(var4 < 2);
               }
            }
         }
      }
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      int var2 = -42547;
      int var3 = -10421;
      int var4 = -63;
      int var5 = -168;
      double var6 = -71.113772;
      float var8 = -32.553F;
      vMeth1();

      int var11;
      for(var11 = 4; 241 > var11; ++var11) {
         for(var6 = 1.0; var6 < 7.0; ++var6) {
            var0 <<= var3;
            if (var11 != 0) {
               vMeth_check_sum += (long)(var0 + var11 + var2) + Double.doubleToLongBits(var6) + (long)var3 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var8);
               return;
            }

            instanceCount += (long)var6;
            iArrFld[(int)(var6 - 1.0)] = var11;
            lArrFld[var11 + 1] = (long)var11;
            var3 >>>= var3;

            try {
               iArrFld[(int)var6] = -803490057 % var2;
               var3 = 'Ｑ' % var3;
               var2 = var11 % iArrFld[var11 - 1];
            } catch (ArithmeticException var10) {
            }

            var3 += (int)(var6 * (double)var11 + (double)var2 - (double)var11);
         }

         for(var4 = 1; var4 < 7; ++var4) {
            iArrFld[var11] = (int)instanceCount;
            var5 <<= var0;
            var3 += (int)var8;
         }
      }

      vMeth_check_sum += (long)(var0 + var11 + var2) + Double.doubleToLongBits(var6) + (long)var3 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var8);
   }

   public static int iMeth() {
      int var0 = -30984;
      boolean var1 = true;
      boolean var2 = true;
      short var3 = 32361;
      short var4 = -22207;
      double[] var5 = new double[400];
      FuzzerUtils.init(var5, -1.23681);
      vMeth(var0);
      int var8 = 1;

      while(true) {
         ++var8;
         if (var8 >= 294) {
            var0 = -29776;
            bFld = bFld;
            var0 = var0;

            int var9;
            for(var9 = 10; 175 > var9; var9 += 3) {
               var0 >>>= -9;
               iArrFld[var9 + 1] = var9;
               fFld *= (float)var0;
               int[] var10000 = iArrFld;
               var10000[var9 + 1] -= var0;
            }

            fFld -= 0.177F;
            var5[(var9 >>> 1) % 400] = (double)var0;
            var0 += 60544;
            long var6 = (long)(var0 + var8 + var4 + var9 + var3) + Double.doubleToLongBits(FuzzerUtils.checkSum(var5));
            iMeth_check_sum += var6;
            return (int)var6;
         }

         instanceCount = instanceCount;
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      float var3 = 78.393F;
      short var4 = -4189;
      boolean var5 = true;
      boolean var6 = true;
      int var7 = 15;
      int var8 = -14;
      byte var9 = -80;
      int var10 = -5;
      byte var11 = 12;
      var2 = this.iFld > this.iFld & var2 | (float)iMeth() != var3;
      this.dFld = 3.0;
      this.iFld = (int)var3;
      var4 = (short)(var4 - 6811);
      this.iFld -= this.iFld;
      instanceCount = (long)this.iFld;
      int var12 = 1;

      do {
         instanceCount += (long)this.iFld;
         var12 += 2;
      } while(var12 < 255);

      this.iFld = -84;
      iArrFld[(var12 >>> 1) % 400] = var12;
      var4 <<= (short)this.iFld;
      this.iFld *= var12;
      int var13 = 380;

      while(true) {
         label69:
         while(true) {
            var13 -= 3;
            if (var13 <= 0) {
               FuzzerUtils.out.println("b f2 s1 = " + (var2 ? 1 : 0) + "," + Float.floatToIntBits(var3) + "," + var4);
               FuzzerUtils.out.println("i16 i17 i18 = " + var12 + "," + var13 + "," + var7);
               FuzzerUtils.out.println("i19 i20 i21 = " + var8 + "," + var9 + "," + var10);
               FuzzerUtils.out.println("i22 = " + var11);
               FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
               FuzzerUtils.out.println("Test.fFld dFld Test.byFld = " + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld) + "," + byFld);
               FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
               FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
               return;
            }

            var7 = 1;

            while(true) {
               ++var7;
               if (var7 >= 197) {
                  switch (var13 % 2 + 9) {
                     case 9:
                        lArrFld[var13 + 1] = (long)var3;
                        var8 = var13;

                        for(; var8 < 197; ++var8) {
                           for(var10 = 1; var10 < 1; ++var10) {
                              var3 %= 5.0F;
                              this.dFld += this.dFld;
                              this.dFld += (double)this.iFld;
                              if (bFld) {
                                 break;
                              }

                              this.dFld = (double)var7;
                              lArrFld = lArrFld;
                              iArrFld = iArrFld;
                              var2 = false;
                              iArrFld[var13] = var9;
                           }
                        }
                        continue label69;
                     case 10:
                        iArrFld[var13 - 1] = var13;
                     default:
                        continue label69;
                  }
               }

               instanceCount += (long)(var7 - var7);
               this.iFld += var7 * var7;
               fFld += (float)byFld;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-129);
      FuzzerUtils.init(lArrFld, 1461668461105384269L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
