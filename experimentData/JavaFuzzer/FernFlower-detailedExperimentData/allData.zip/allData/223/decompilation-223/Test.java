public class Test {
   public static final int N = 400;
   public static long instanceCount = 6L;
   public static volatile float fFld = 66.652F;
   public static short sFld = 11214;
   public static int iFld = 2;
   public static double dFld = -1.89755;
   public static boolean bFld = false;
   public static long[] lArrFld = new long[400];
   public int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long byMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(long var0, long var2) {
      boolean var4 = true;
      boolean var5 = true;
      int var6 = 12;
      int var7 = -55901;
      int var8 = -11;
      double var9 = -1.74436;
      long var11 = -2715737770L;
      float var13 = -25.21F;
      short var14 = 18593;
      --var0;
      int var15 = 1;

      int var16;
      do {
         var9 = (double)var15;
         var9 *= var9;

         for(var16 = var15; var16 < 7; var16 += 2) {
            var6 += -187 + var16 * var16;
         }

         var2 >>>= var16;

         for(var11 = 7L; var11 > 1L; var11 -= 2L) {
            if (var15 != 0) {
               vMeth1_check_sum += var0 + var2 + (long)var15 + Double.doubleToLongBits(var9) + (long)var16 + (long)var6 + var11 + (long)var7 + (long)Float.floatToIntBits(var13) + (long)var8 + (long)var14;
               return;
            }

            var6 -= var15;
            var7 = (int)var0;

            for(var13 = 1.0F; 3.0F > var13; ++var13) {
               int var10000 = var6 - var16;
               var6 = var14;
            }

            var8 += var6;
         }

         ++var15;
      } while(var15 < 242);

      vMeth1_check_sum += var0 + var2 + (long)var15 + Double.doubleToLongBits(var9) + (long)var16 + (long)var6 + var11 + (long)var7 + (long)Float.floatToIntBits(var13) + (long)var8 + (long)var14;
   }

   public static byte byMeth(double var0) {
      boolean var2 = true;
      int var3 = 84;
      boolean var4 = true;
      byte var5 = 3;
      int var6 = 10;
      int var7 = -40160;
      int[] var8 = new int[400];
      boolean var9 = false;
      FuzzerUtils.init((int[])var8, (int)-26);
      fFld = (float)(instanceCount++);

      int var12;
      for(var12 = 5; var12 < 154; ++var12) {
         vMeth1(-156L, 3411951848L);
         var8[(var3 >>> 1) % 400] = var12;
         var3 *= var3;
      }

      int var13;
      for(var13 = 11; var13 < 223; ++var13) {
         if (var9) {
            var5 = var5;
            var3 *= var12;

            for(var6 = 1; var6 < 8; ++var6) {
               fFld += (float)var6;
               var7 += 6203;
               instanceCount = instanceCount;
               if (var9) {
                  break;
               }

               var9 = var9;
            }
         } else if (var9) {
            var8[var13] -= -31951;
         }
      }

      long var10 = Double.doubleToLongBits(var0) + (long)var12 + (long)var3 + (long)var13 + (long)var5 + (long)var6 + (long)var7 + (long)(var9 ? 1 : 0) + FuzzerUtils.checkSum(var8);
      byMeth_check_sum += var10;
      return (byte)((int)var10);
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = -6;
      int var2 = -214;
      int var3 = 12;
      int var4 = -2;
      int var5 = -12;
      double var6 = 2.42552;
      boolean var8 = false;

      int var9;
      for(var9 = 14; var9 < 373; ++var9) {
         instanceCount = (long)byMeth(var6);

         for(var2 = 1; 5 > var2; var2 += 3) {
            var1 -= var2;
            var1 += (int)(-9920L + (long)(var2 * var2));

            for(var4 = 5; var4 > var9; var4 -= 3) {
               fFld += (float)(var4 * var9 + sFld - var5);
               var3 += var4 * var4;
               var3 += 174;
               var3 = 20;
               if (var8) {
                  fFld += (float)sFld;
                  var5 -= var1;
                  var1 += var1;
               } else {
                  if (var8) {
                     instanceCount += (long)(var4 * var4 + sFld - var9);
                     vMeth_check_sum += (long)(var9 + var1) + Double.doubleToLongBits(var6) + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)(var8 ? 1 : 0);
                     return;
                  }

                  var5 += -147 + var4 * var4;
               }
            }
         }
      }

      vMeth_check_sum += (long)(var9 + var1) + Double.doubleToLongBits(var6) + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)(var8 ? 1 : 0);
   }

   public void mainTest(String[] var1) {
      int var2 = -11;
      byte var3 = 0;
      short var4 = 6595;
      byte var5 = -57;
      short var6 = 177;
      byte var7 = -121;
      byte var8 = -11;
      long var9 = -741191400L;
      byte var11 = 111;
      float var12 = -13.977F;
      var2 -= 141;
      if (bFld) {
         vMeth();
      } else {
         instanceCount = (long)var8;
      }

      FuzzerUtils.out.println("i l3 i18 = " + var2 + "," + var9 + "," + var3);
      FuzzerUtils.out.println("i19 i20 by = " + var4 + "," + var5 + "," + var11);
      FuzzerUtils.out.println("i21 i22 f1 = " + var6 + "," + var7 + "," + Float.floatToIntBits(var12));
      FuzzerUtils.out.println("i23 = " + var8);
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
      FuzzerUtils.out.println("Test.iFld Test.dFld Test.bFld = " + iFld + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.lArrFld iArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 2625323702L);
      vMeth_check_sum = 0L;
      byMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
