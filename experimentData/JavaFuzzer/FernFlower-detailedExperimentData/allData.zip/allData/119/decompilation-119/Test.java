public class Test {
   public static final int N = 400;
   public static long instanceCount = -5L;
   public static double dFld = 0.1188;
   public float fFld = -2.494F;
   public static short sFld = -20974;
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(int var0, int var1, int var2) {
      boolean var3 = true;
      short var4 = 185;
      int var5 = -12;
      int var6 = -17978;
      int[] var7 = new int[400];
      float var8 = 2.226F;
      short var9 = 11360;
      long[] var10 = new long[400];
      FuzzerUtils.init(var10, 28981L);
      FuzzerUtils.init((int[])var7, (int)3);

      int var13;
      for(var13 = 4; var13 < 388; ++var13) {
         var10[var13 - 1] = -316845889L;
         var8 -= (float)instanceCount;
         var5 = 4;

         do {
            var2 += var5 * var5;
            var1 *= (int)dFld;
            var8 = (float)var9;
            dFld += (double)var5;
            var7[var13 + 1] = var5;
            var8 = (float)instanceCount;
            --var5;
         } while(var5 > 0);

         instanceCount += (long)(var13 + var2);
         var6 = 1;

         do {
            var2 += var5;
            ++var6;
         } while(var6 < 4);
      }

      instanceCount = (long)var2;
      var1 *= (int)instanceCount;
      long var11 = (long)(var0 + var1 + var2 + var13 + var4 + Float.floatToIntBits(var8) + var5 + var9 + var6) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var7);
      iMeth1_check_sum += var11;
      return (int)var11;
   }

   public static int iMeth() {
      boolean var0 = true;
      int var1 = 1;
      int var2 = 8207;
      int var3 = 192;
      byte var4 = 1;
      int[] var5 = new int[400];
      float var6 = 20.329F;
      float var7 = 116.944F;
      float[] var8 = new float[400];
      byte var9 = 13;
      long[][] var10 = new long[400][400];
      FuzzerUtils.init(var5, -56399);
      FuzzerUtils.init(var10, -13L);
      FuzzerUtils.init(var8, 1.1F);

      int var14;
      for(var14 = 5; var14 < 175; ++var14) {
         for(var2 = 1; var2 < 9; ++var2) {
            var5 = var5;
            instanceCount = (long)(-((float)((long)var1 - instanceCount) + -220.0F * ((float)instanceCount + var6)));
            long[] var10001 = var10[var2];
            int var10002 = var2 - 1;
            long var10004 = var10001[var2 - 1];
            var10001[var10002] = var10001[var2 - 1] + 1L;
            instanceCount /= var10004 | 1L;
            switch (var14 % 3 + 12) {
               case 12:
                  var1 = var3++;
                  var5[var14] = (var1 + var2 + iMeth1(var14, var14, var1)) * var1;
                  var7 = 1.0F;

                  for(; var7 < 2.0F; ++var7) {
                     var9 += (byte)((int)(var7 * var7));
                     var3 += (int)((long)var7 | (long)var6);
                     var3 += (int)(var7 * (float)var1 + (float)var14 - (float)var1);

                     try {
                        var1 = var3 % 27714;
                        var5[var2] = -63375 % var2;
                        var1 = var3 / var2;
                     } catch (ArithmeticException var13) {
                     }
                  }

                  var1 = (int)((float)var1 + ((float)(var2 * var3 + var1) - var6));
                  break;
               case 13:
                  var10[var2 + 1][var14 - 1] -= (long)var1;
                  break;
               case 14:
                  var8[var14] = (float)instanceCount;
                  break;
               default:
                  var4 = 86;
            }
         }
      }

      long var11 = (long)(var14 + var1 + var2 + var3 + Float.floatToIntBits(var6) + Float.floatToIntBits(var7) + var4 + var9) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static void vMeth(int var0, int var1) {
      short var2 = -18385;
      iMeth();
      instanceCount = (long)var0;
      var2 = (short)(var2 / 1);
      vMeth_check_sum += (long)(var0 + var1 + var2);
   }

   public void mainTest(String[] var1) {
      int var2 = 19;
      boolean var3 = true;
      int var4 = 14;
      int var5 = -2241;
      int var6 = 8654;
      int var7 = -8;
      short var8 = -28321;
      boolean var9 = true;
      char var10 = '퉢';
      int var11 = 8;
      int var12 = 2;
      int var13 = -37154;
      int[] var14 = new int[400];
      long[] var15 = new long[400];
      boolean[][][] var16 = new boolean[400][400][400];
      FuzzerUtils.init(var15, 3L);
      FuzzerUtils.init(var14, -52838);
      FuzzerUtils.init((Object[][])var16, false);
      vMeth(var2, var2);
      dFld += (double)var2;

      int var19;
      for(var19 = 8; 197 > var19; ++var19) {
         var15[var19] = 1L;

         try {
            var2 %= 1405380339;
            var14[var19 + 1] = var19 % 155;
            var4 = var2 % var2;
         } catch (ArithmeticException var18) {
         }

         for(var5 = var19; 133 > var5; ++var5) {
            var6 -= var4;

            for(var7 = var19; var7 < 1; ++var7) {
               float[] var10000 = fArrFld;
               var10000[var7] += (float)var2;
               var16[var7][var5 + 1] = var16[var19 - 1][var5];
               this.fFld *= (float)var8;
               this.fFld = (float)var7;
               var2 = var5;
               dFld = (double)var19;
               sFld += (short)((int)((long)(var7 * var8) + instanceCount - (long)var5));
               instanceCount >>= var5;
               this.fFld -= (float)var6;
               var15[var5] = -26L;
            }

            var14[var19 + 1] >>= (int)instanceCount;
            instanceCount = instanceCount;
         }
      }

      var4 >>= sFld;
      var4 -= var2;
      instanceCount = (long)var2;
      var16[(var6 >>> 1) % 400][(var19 >>> 1) % 400][(var4 >>> 1) % 400] = false;

      int var20;
      for(var20 = 9; var20 < 385; ++var20) {
         var11 = 1;

         do {
            for(var12 = 1; var12 < 4; var12 += 2) {
               instanceCount = (long)((float)instanceCount + ((float)(var12 * sFld + var5) - this.fFld));
               var15[var11 + 1] += (long)var12;
               var6 = 5;
            }

            var11 += 3;
         } while(var11 < 67);
      }

      FuzzerUtils.out.println("i14 i15 i16 = " + var2 + "," + var19 + "," + var4);
      FuzzerUtils.out.println("i17 i18 i19 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i20 i21 i22 = " + var8 + "," + var20 + "," + var10);
      FuzzerUtils.out.println("i23 i24 i25 = " + var11 + "," + var12 + "," + var13);
      FuzzerUtils.out.println("lArr2 iArr2 bArr = " + FuzzerUtils.checkSum(var15) + "," + FuzzerUtils.checkSum(var14) + "," + FuzzerUtils.checkSum((Object[][])var16));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.sFld Test.fArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 1.94F);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
