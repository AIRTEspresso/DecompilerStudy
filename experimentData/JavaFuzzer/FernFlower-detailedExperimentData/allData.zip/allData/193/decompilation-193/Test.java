public class Test {
   public static final int N = 400;
   public static long instanceCount = 3L;
   public static boolean bFld = false;
   public static double dFld = -30.90614;
   public static short sFld = 7699;
   public static byte byFld = 41;
   public static int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0) {
      int var1 = 1;
      int var2 = 1313;
      byte var3 = -9;
      int var4 = 5;
      int var5 = -44109;
      float var6 = -91.337F;
      if (bFld) {
         var1 = 1;

         while(true) {
            ++var1;
            if (var1 >= 308) {
               var0 >>= (int)instanceCount;
               break;
            }

            instanceCount += 89L;
         }
      } else if (bFld) {
         var0 -= 12;

         for(var2 = 5; var2 < 291; ++var2) {
            iArrFld[var2] = var0;
            var0 = var1;
            var6 = (float)var1;
         }

         var0 <<= (int)instanceCount;
         float[] var10000 = fArrFld;
         var10000[(var0 >>> 1) % 400] += -238.0F;
      } else {
         for(var4 = 11; var4 < 239; ++var4) {
            instanceCount += -404788774760728131L + (long)(var4 * var4);
            instanceCount += (long)var5;
            if (bFld) {
               break;
            }
         }
      }

      long var7 = (long)(var0 + var1 + var2 + var3 + Float.floatToIntBits(var6) + var4 + var5);
      lMeth_check_sum += var7;
      return var7;
   }

   public static void vMeth1(float var0) {
      boolean var1 = true;
      int var2 = 1;
      boolean var3 = true;
      int var4 = 11810;
      int var5 = 63351;
      int var6 = -7;
      byte var7 = -6;
      long[] var8 = new long[400];
      FuzzerUtils.init(var8, 2L);

      int var9;
      for(var9 = 2; var9 < 254; ++var9) {
         var2 += var9;
         var2 *= (int)(--instanceCount);
         lMeth(var2);
         var2 += var9;
      }

      var2 *= 14;

      int var10;
      label45:
      for(var10 = 20; var10 < 386; ++var10) {
         var5 = 1;

         while(true) {
            label36:
            while(true) {
               ++var5;
               if (var5 >= 5) {
                  continue label45;
               }

               iArrFld[var5] = var9;
               float[] var10000 = fArrFld;
               var10000[var10 + 1] -= (float)var5;
               switch (var5 % 10 * 5 + 100) {
                  case 104:
                     iArrFld[var5] = var7;
                     break;
                  case 107:
                     var4 = var4;
                     break;
                  case 119:
                     int[] var11 = iArrFld;
                     var11[var10 + 1] += -104;
                     break;
                  case 120:
                     var4 += 96 + var5 * var5;
                     break;
                  case 121:
                     var8[var5 + 1] = (long)var9;
                     break;
                  case 128:
                     var2 = sFld;
                     break;
                  case 130:
                     var2 -= var6;
                  case 113:
                     var2 -= var7;
                  case 138:
                     var2 >>= (int)instanceCount;
                     break;
                  case 150:
                     var6 = 1;

                     while(true) {
                        var2 += var6 + var6;
                        var4 = var4;
                        dFld = (double)var0;
                        ++var6;
                        if (var6 >= 1) {
                           continue label36;
                        }
                     }
                  default:
                     var4 = -2;
               }
            }
         }
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var9 + var2 + var10 + var4 + var5 + var6 + var7) + FuzzerUtils.checkSum(var8);
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      short var2 = 12314;
      int var3 = -42;
      int var4 = -29446;
      int var5 = -10;
      byte var6 = 8;
      int var7 = 220;
      byte var8 = -7;
      byte var9 = -77;
      boolean[] var10 = new boolean[400];
      FuzzerUtils.init(var10, true);

      int var12;
      for(var12 = 8; var12 < 227; ++var12) {
         for(var3 = 1; var3 < 7; ++var3) {
            float var11 = -126.363F;
            vMeth1(var11);
            var4 -= (int)instanceCount;
         }

         int[] var10000 = iArrFld;
         var10000[var12 + 1] *= var0;

         for(var5 = var12; var5 < 7; ++var5) {
            iArrFld[var12 + 1] = var4;
            iArrFld[var5 + 1] = var6;
            var4 = -11;
            var10000 = iArrFld;
            var10000[var5 + 1] += (int)instanceCount;

            for(var7 = 1; var7 < 1; ++var7) {
               var10[378] = bFld;
               bFld = bFld;
               int var13 = var6 >> var12;
               var6 = var9;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var12 + var2 + var3 + var4 + var5 + var6 + var7 + var8 + var9) + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      int var2 = 10761;
      boolean var3 = true;
      int var4 = 8168;
      int var5 = -3;
      byte var6 = 10;
      int var7 = 203;
      int var8 = 7;
      int var9 = 112;
      int var10 = 59433;
      int var11 = -60872;
      float var12 = -1.493F;
      vMeth(var2);

      int var13;
      for(var13 = 8; var13 < 346; ++var13) {
         var2 *= 14;
         if (bFld) {
            break;
         }

         iArrFld[var13 - 1] = (int)instanceCount;

         for(var5 = 74; var5 > 4; --var5) {
            instanceCount *= 65280L;
            var4 -= var13;

            for(var7 = var5; var7 < 2; ++var7) {
               instanceCount >>= var7;
            }

            for(var9 = 2; var9 > 1; --var9) {
               bFld = false;
               dFld = (double)var13;
               dFld -= (double)var13;
               int[] var10000;
               switch (var9 % 8 + 37) {
                  case 37:
                     var8 *= (int)instanceCount;
                     if (!bFld) {
                        instanceCount = (long)var9;
                        instanceCount &= 1036L;
                     }
                     break;
                  case 38:
                     var8 = 74;
                     break;
                  case 39:
                     int var14 = var4 + 74 + var9 * var9;
                     var4 = var13;
                     switch ((var9 >>> 1) % 7 + 104) {
                        case 104:
                           iArrFld[var9] = byFld;
                           var12 = (float)dFld;
                           continue;
                        case 105:
                           instanceCount += (long)var9;
                           continue;
                        case 106:
                           iArrFld = iArrFld;
                           instanceCount += (long)byFld;
                           var11 += var9 * var9;
                           continue;
                        case 107:
                           var10 = -8372;
                        case 108:
                           instanceCount &= (long)var11;
                           continue;
                        case 109:
                           iArrFld[var9] = 52327;
                           continue;
                        case 110:
                           instanceCount += (long)dFld;
                           continue;
                        default:
                           var8 -= var5;
                           continue;
                     }
                  case 40:
                     var12 = (float)dFld;
                     break;
                  case 41:
                     var2 -= (int)dFld;
                     break;
                  case 42:
                     var10000 = iArrFld;
                     var10000[var13] -= var13;
                     break;
                  case 43:
                     var10000 = iArrFld;
                     var10000[var5 + 1] /= var13 | 1;
                  case 44:
                     fArrFld = FuzzerUtils.float1array(400, -113.619F);
               }
            }
         }
      }

      FuzzerUtils.out.println("i23 i24 i25 = " + var2 + "," + var13 + "," + var4);
      FuzzerUtils.out.println("i26 i27 i28 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i29 i30 i31 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("f3 i32 = " + Float.floatToIntBits(var12) + "," + var11);
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.sFld Test.byFld Test.iArrFld = " + sFld + "," + byFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)47);
      FuzzerUtils.init(fArrFld, 0.836F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
