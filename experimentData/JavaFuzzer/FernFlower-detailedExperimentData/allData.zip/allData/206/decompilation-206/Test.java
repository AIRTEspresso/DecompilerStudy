public class Test {
   public static final int N = 400;
   public static long instanceCount = -46520L;
   public static volatile byte byFld = 121;
   public static short sFld = 22404;
   public static float fFld = -24.197F;
   public static long vMeth_check_sum = 0L;
   public static long byMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(int var0, float var1, int var2) {
      boolean var3 = true;
      int var4 = 63555;
      boolean var5 = true;
      int var6 = -5614;
      byte var7 = -3;
      int var8 = -9;
      byte var9 = 7;
      byte var10 = 14;
      int[] var11 = new int[400];
      double var12 = -74.81373;
      double var14 = 55.117826;
      long[][][] var16 = new long[400][400][400];
      FuzzerUtils.init((int[])var11, (int)11);
      FuzzerUtils.init((Object[][])var16, 798186012L);
      var0 = -994581114;

      int var17;
      for(var17 = 1; 182 > var17; var17 += 2) {
         var11 = var11;
         var0 &= var17;
         var4 = var17;
         var2 >>= var17;
      }

      int var18;
      for(var18 = 12; var18 < 392; ++var18) {
         for(var12 = 1.0; var12 < 4.0; ++var12) {
            var16[var18 - 1][var18 + 1][var18] += (long)var6;
         }

         var2 += var18 * var18;
         byFld += (byte)((int)((float)var18 - var1));

         for(var8 = 1; var8 < 4; ++var8) {
            for(var14 = 1.0; var14 < 2.0; ++var14) {
               var4 = var0;
               var6 = (int)instanceCount;
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var2 + var17 + var4 + var18 + var6) + Double.doubleToLongBits(var12) + (long)var7 + (long)var8 + (long)var9 + Double.doubleToLongBits(var14) + (long)var10 + FuzzerUtils.checkSum(var11) + FuzzerUtils.checkSum((Object[][])var16);
   }

   public static byte byMeth(long var0, int var2, long var3) {
      boolean var5 = true;
      int var6 = 6;
      byte var7 = -2;
      int var8 = -16491;
      int[] var9 = new int[400];
      float var10 = 2.422F;
      long[][] var11 = new long[400][400];
      FuzzerUtils.init(var11, -23852L);
      FuzzerUtils.init((int[])var9, (int)5);
      int var14 = 1;

      while(true) {
         ++var14;
         if (var14 >= 166) {
            long var12 = var0 + (long)var2 + var3 + (long)var14 + (long)Float.floatToIntBits(var10) + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var11) + FuzzerUtils.checkSum(var9);
            byMeth_check_sum += var12;
            return (byte)((int)var12);
         }

         vMeth1(var14, var10, var2);

         for(var6 = 1; var6 < 10; ++var6) {
            var8 = 1;

            while(true) {
               ++var8;
               if (var8 >= 2) {
                  break;
               }

               var3 = (long)var2;
               var11[var14][var6 - 1] = (long)var14;
               var9[var6 + 1] -= var2;
               switch (var8 % 1 * 5 + 12) {
                  case 17:
                     var2 += var8;
                     var9[var6] += var7;
                     var7 = byFld;
                     break;
                  default:
                     sFld *= (short)var8;
                     var2 += 10;
                     var0 >>= var2;
               }
            }
         }
      }
   }

   public static void vMeth(long var0, boolean var2) {
      double var3 = 1.312;
      short var5 = -149;
      int[][][] var6 = new int[400][400][400];
      float var7 = -2.668F;
      FuzzerUtils.init((Object[][])var6, -55);

      for(var3 = 273.0; var3 > 16.0; --var3) {
         byMeth(-28650L, var5, instanceCount);
         sFld += (short)((int)(var3 * (double)var5 + (double)var7 - (double)var7));
         var6[(int)var3][(int)(var3 - 1.0)] = var6[(int)(var3 - 1.0)][(int)(var3 - 1.0)];
         var2 = var2;
      }

      vMeth_check_sum += var0 + (long)(var2 ? 1 : 0) + Double.doubleToLongBits(var3) + (long)var5 + (long)Float.floatToIntBits(var7) + FuzzerUtils.checkSum((Object[][])var6);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 163;
      int var4 = 20472;
      int var5 = -12500;
      char var6 = '讃';
      short var7 = 243;
      int[] var8 = new int[400];
      long var9 = 4L;
      long var11 = 1618798475L;
      long[] var13 = new long[400];
      double var14 = 99.117018;
      double[] var16 = new double[400];
      boolean var17 = true;
      boolean[] var18 = new boolean[400];
      FuzzerUtils.init((int[])var8, (int)60213);
      FuzzerUtils.init(var18, true);
      FuzzerUtils.init(var13, -9L);
      FuzzerUtils.init(var16, 0.812);

      int var19;
      for(var19 = 3; var19 < 134; ++var19) {
         int var10000 = var3 >>> var8[var19 + 1];
         var18[var19] = true;
         var3 = (int)(--var13[var19 + 1]);
         vMeth(instanceCount, true);

         short var20;
         for(var9 = 3L; 191L > var9; ++var9) {
            var14 -= (double)var19;
            var3 -= 105;
            var20 = 250;
            var4 = var20 >> 'ꯊ';
            instanceCount -= (long)var3;
            var13[(int)(var9 + 1L)] <<= -13;
         }

         for(var5 = 11; var5 < 191; ++var5) {
            var4 += var5;
            var13[var19] &= (long)var19;
            var4 >>= var4;

            for(var11 = 2L; var11 > 1L; --var11) {
               var20 = 6202;
               var16[var5] -= var14;
               fFld *= (float)var19;
               var3 = (int)var11;
               var3 = 4;
               var8[var19 + 1] = var5;
               var17 = true;
               var4 = var20 + (int)(var11 + instanceCount);
               byFld += (byte)((int)(var11 * var11));
               byFld = -88;
            }
         }
      }

      FuzzerUtils.out.println("i i1 l3 = " + var19 + "," + var3 + "," + var9);
      FuzzerUtils.out.println("i18 d3 i19 = " + var4 + "," + Double.doubleToLongBits(var14) + "," + var5);
      FuzzerUtils.out.println("i20 l4 i21 = " + var6 + "," + var11 + "," + var7);
      FuzzerUtils.out.println("b1 iArr bArr = " + (var17 ? 1 : 0) + "," + FuzzerUtils.checkSum(var8) + "," + FuzzerUtils.checkSum(var18));
      FuzzerUtils.out.println("lArr dArr = " + FuzzerUtils.checkSum(var13) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var16)));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + byFld + "," + sFld);
      FuzzerUtils.out.println("Test.fFld = " + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
