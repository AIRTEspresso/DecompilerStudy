public class Test {
   public static final int N = 400;
   public static long instanceCount = 1756888618L;
   public short sFld = 2230;
   public boolean bFld = false;
   public static double dFld = 1.38551;
   public volatile int iFld = 167;
   public static long[][] lArrFld = new long[400][400];
   public static float[] fArrFld = new float[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long iMeth2_check_sum;

   public static int iMeth2(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = -57746;
      int var5 = 64400;
      int[] var6 = new int[400];
      FuzzerUtils.init((int[])var6, (int)55659);
      instanceCount >>= '\uf5e8';
      var2 >>= var2;
      int var10 = 7;

      while(138 > var10) {
         var2 -= var2;
         var2 = var10;

         try {
            var2 = var6[var10 + 1] / -224;
            var1 = var10 / -1009995685;
            var6[var10 - 1] = -462777520 / var10;
         } catch (ArithmeticException var9) {
         }

         var1 += var10;
         var2 &= (int)instanceCount;
         switch (var10 % 1 + 122) {
            case 122:
               instanceCount += (long)(var10 | var4);
               var5 = 1;

               do {
                  var2 <<= var1;
                  long[] var10000 = lArrFld[var5 - 1];
                  var10000[var5] += instanceCount;
                  ++var5;
               } while(var5 < 12);
            default:
               ++var10;
         }
      }

      long var7 = (long)(var1 + var1 + var2 + var10 + var4 + var5) + FuzzerUtils.checkSum(var6);
      iMeth2_check_sum += var7;
      return (int)var7;
   }

   public static int iMeth1() {
      int var0 = -58630;
      int var1 = -10;
      int var2 = -33704;
      int var3 = 11;
      int var4 = -9327;
      int var5 = 31460;
      int var6 = -37;
      int[] var7 = new int[400];
      double var8 = -1.16138;
      boolean var10 = true;
      FuzzerUtils.init(var7, -35851);

      for(var0 = 12; var0 < 352; ++var0) {
         for(var2 = var0; var2 < 5; ++var2) {
            for(var4 = var2; var4 < 1; ++var4) {
               try {
                  int var10000 = var1 / var7[var2];
                  var1 = var5 / -37666;
                  var1 = var3 / var7[var2 - 1];
               } catch (ArithmeticException var14) {
               }

               var3 = (int)((long)var3 + (long)var4 + instanceCount);
               instanceCount += (long)(var4 - var4);
               var1 += (int)((double)iMeth2(var2, var3, var3) * var8);
               instanceCount |= (long)var1;
               var5 *= (int)var8;

               try {
                  var3 = var7[var2 - 1] / var5;
                  var5 = var0 / 108;
                  var3 = var5 % var0;
               } catch (ArithmeticException var13) {
               }

               long[] var15 = lArrFld[var4 + 1];
               var15[var2] += (long)var2;
            }

            instanceCount = (long)var2;
            var6 = 1;

            do {
               ++var6;
               if (var6 >= 1) {
                  break;
               }

               var1 *= var5;
            } while(!var10);
         }
      }

      long var11 = (long)(var0 + var1 + var2 + var3 + var4 + var5) + Double.doubleToLongBits(var8) + (long)var6 + (long)(var10 ? 1 : 0) + FuzzerUtils.checkSum(var7);
      iMeth1_check_sum += var11;
      return (int)var11;
   }

   public int iMeth(int var1, byte var2, int var3) {
      double var4 = 88.64745;
      int var6 = 171;
      int var7 = 1;
      int[] var8 = new int[400];
      float var9 = -21.907F;
      FuzzerUtils.init((int[])var8, (int)33223);

      for(var4 = 2.0; var4 < 288.0; ++var4) {
         switch ((Math.min(-100, -178) >>> 1) % 7 + 22) {
            case 22:
               switch ((int)(var4 % 4.0 * 5.0)) {
                  case 9:
                     if (this.bFld) {
                        dFld += (double)var3;
                        instanceCount = instanceCount;
                        instanceCount *= instanceCount;
                     } else if (this.bFld) {
                        this.iFld += (int)(var4 - (double)var7);
                     }
                     continue;
                  case 14:
                     var9 += (float)(var4 * (double)instanceCount + (double)var3 - (double)var3);
                     if (!this.bFld) {
                        this.bFld = false;
                        var1 = (int)((double)var1 + -217.0 + var4 * var4);
                     }
                     continue;
                  case 18:
                     instanceCount += (long)(var4 * var4);
                     var3 -= this.sFld;
                     instanceCount += (long)var2;
                     continue;
                  case 19:
                     var9 -= (float)iMeth1();
                  default:
                     continue;
               }
            case 23:
               dFld += (double)var6;
            case 24:
               fArrFld[(int)var4] = (float)dFld;
            case 25:
               var7 = (int)instanceCount;
            case 26:
               instanceCount = -88L;
            case 27:
               var8[(int)(var4 + 1.0)] = var6;
            case 28:
               try {
                  this.iFld = var3 % 822935784;
                  this.iFld = -342026397 / var8[(int)(var4 - 1.0)];
                  var6 = this.iFld % 17809;
               } catch (ArithmeticException var12) {
               }
         }
      }

      long var10 = (long)(var1 + var2 + var3) + Double.doubleToLongBits(var4) + (long)var6 + (long)Float.floatToIntBits(var9) + (long)var7 + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var10;
      return (int)var10;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 105;
      int var4 = -62;
      int var5 = -129;
      int var6 = -233;
      int var7 = 71;
      int var8 = 8;
      int var9 = -34135;
      int[] var10 = new int[400];
      float var11 = 37.157F;
      byte var12 = 83;
      byte[] var13 = new byte[400];
      short[][] var14 = new short[400][400];
      boolean[] var15 = new boolean[400];
      double[] var16 = new double[400];
      FuzzerUtils.init((int[])var10, (int)58);
      FuzzerUtils.init(var13, (byte)-13);
      FuzzerUtils.init(var14, (short)-28163);
      FuzzerUtils.init(var15, false);
      FuzzerUtils.init(var16, 56.48633);

      int var17;
      for(var17 = 5; var17 < 171; var17 += 2) {
         this.iMeth(var17, (byte)45, var17);
         switch (var17 % 6 + 79) {
            case 79:
               for(var4 = 15; var4 < 302; ++var4) {
                  label61:
                  switch ((var17 >>> 1) % 1 + 37) {
                     case 37:
                        var6 = 2;

                        while(true) {
                           --var6;
                           if (var6 <= 0) {
                              break label61;
                           }

                           instanceCount += (long)this.iFld;
                           if (this.bFld) {
                              var5 += (int)dFld;
                           }

                           instanceCount = (long)var5;
                        }
                     default:
                        var10[var17] = var3;
                        var13[var17] *= (byte)this.sFld;
                  }

                  instanceCount *= (long)var17;
                  var14[var17 - 1][var4] = (short)var5;
                  var5 = (int)((long)var5 + ((long)(var4 * var17) + instanceCount - (long)var5));
                  var5 += var17;
                  this.iFld *= (int)instanceCount;
               }

               var7 = 302;

               do {
                  dFld += (double)instanceCount;
                  var10[var7] = (int)instanceCount;
                  dFld += (double)instanceCount;
                  var3 = (int)((long)var3 + ((long)var7 * instanceCount + (long)var17 - (long)var6));
                  var11 += (float)var4;
                  fArrFld[var7 + 1] = (float)var6;
                  var7 -= 3;
               } while(var7 > 0);

               for(var8 = 3; var8 < 302; ++var8) {
                  switch ((var4 >>> 1) % 2 + 125) {
                     case 125:
                        var15[3] = this.bFld;
                        instanceCount = 43402L;
                        instanceCount += (long)(var8 * var7 + var6) - instanceCount;
                     case 126:
                        var16[var17] = (double)var11;
                        break;
                     default:
                        --var10[var17 + 1];
                  }
               }
            case 80:
            case 81:
               dFld *= (double)var17;
               break;
            case 82:
               var9 += (int)var11;
               break;
            case 83:
               var12 -= (byte)this.sFld;
               break;
            case 84:
               instanceCount = (long)var17;
            default:
               var5 += var17 ^ var6;
         }
      }

      FuzzerUtils.out.println("i i1 i20 = " + var17 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i21 i22 i23 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("f1 i24 i25 = " + Float.floatToIntBits(var11) + "," + var8 + "," + var9);
      FuzzerUtils.out.println("by1 iArr3 byArr = " + var12 + "," + FuzzerUtils.checkSum(var10) + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("sArr bArr dArr = " + FuzzerUtils.checkSum(var14) + "," + FuzzerUtils.checkSum(var15) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var16)));
      FuzzerUtils.out.println("Test.instanceCount sFld bFld = " + instanceCount + "," + this.sFld + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.dFld iFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -14L);
      FuzzerUtils.init(fArrFld, -2.591F);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      iMeth2_check_sum = 0L;
   }
}
