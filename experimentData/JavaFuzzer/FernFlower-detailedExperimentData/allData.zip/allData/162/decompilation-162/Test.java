public class Test {
   public static final int N = 400;
   public static long instanceCount = 11L;
   public static float fFld = 1.846F;
   public volatile int iFld = 9;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long fMeth_check_sum = 0L;

   public static float fMeth() {
      boolean var0 = true;
      int var1 = 228;
      int var2 = 13;
      int var3 = -48284;
      int var4 = 14;
      int[] var5 = new int[400];
      short var6 = 62;
      float var7 = 27.65F;
      boolean var8 = false;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, -2223656525721366550L);
      FuzzerUtils.init((int[])var5, (int)88);

      int var12;
      for(var12 = 5; var12 < 181; ++var12) {
         var6 >>>= (short)((int)instanceCount);
         instanceCount = (long)var1;
         var1 += (int)(-42L + (long)(var12 * var12));

         for(var2 = 9; var2 > 1; var2 -= 3) {
            int var10000 = var1 << var12;
            var1 = (int)var7;
            if (var8) {
               switch (var2 % 10 + 28) {
                  case 28:
                     var9[var2 + 1] = (long)var7;
                     break;
                  case 29:
                     var3 >>= var1;
                     break;
                  case 30:
                     var1 >>= -234;
                     break;
                  case 31:
                     var4 = 1;

                     do {
                        var5[var2 + 1] *= (int)var7;
                        var3 &= var4;
                        ++var4;
                     } while(var4 < 5);
                  case 32:
                  default:
                     break;
                  case 33:
                     var9[var12 + 1] <<= var2;
                  case 34:
                     var1 += var2 * var2;
                     break;
                  case 35:
                     var5[(var1 >>> 1) % 400] |= (int)instanceCount;
                     break;
                  case 36:
                     var1 = (int)((long)var1 + ((long)var2 * instanceCount + instanceCount - (long)var4));
                     break;
                  case 37:
                     var1 = var4;
               }
            } else {
               var3 = var3;
            }
         }
      }

      long var10 = (long)(var12 + var1 + var6 + var2 + var3 + Float.floatToIntBits(var7) + var4 + (var8 ? 1 : 0)) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var5);
      fMeth_check_sum += var10;
      return (float)var10;
   }

   public static void vMeth1(int var0, int var1) {
      float var2 = -39.956F;
      boolean var3 = true;
      int var4 = 46;
      int var5 = 9;
      int var6 = 239;
      int var7 = -172;
      int[] var8 = new int[400];
      byte var9 = -47;
      FuzzerUtils.init((int[])var8, (int)8558);
      var1 = 62;
      var2 -= fMeth();
      int var10 = 1;

      while(true) {
         ++var10;
         if (var10 >= 331) {
            vMeth1_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + var10 + var4 + var9 + var5 + var6 + var7) + FuzzerUtils.checkSum(var8);
            return;
         }

         var4 = 1;

         while(true) {
            var4 += 3;
            if (var4 >= 5) {
               break;
            }

            var1 += var4 + var1;
            var2 -= (float)var9;
            var8[var10 + 1] = var10;

            for(var5 = var10; var5 < 5; ++var5) {
               var6 = (int)((long)var6 + ((long)(var5 * var1 + var10) - instanceCount));
               var0 += var5;
               var8[var10 - 1] += var7;
            }

            var6 = -58;
            var8[var4] = (int)fFld;
            instanceCount = 58632L;
            var7 = var4;
         }
      }
   }

   public void vMeth(long var1, int var3) {
      boolean var4 = true;
      int var5 = 121;
      boolean var6 = true;
      short var7 = 1515;
      int var8 = 14841;
      byte var9 = 51;
      int[] var10 = new int[400];
      FuzzerUtils.init((int[])var10, (int)-3);
      vMeth1(44170, var3);

      int var11;
      for(var11 = 11; 202 > var11; ++var11) {
         var1 >>= 2135098574;
         short var12 = -10416;
         var5 = var12 * var12;
         var10[var11] <<= var11;
      }

      var5 <<= var11;
      var5 -= 40421;
      var10 = var10;

      int var13;
      for(var13 = 20; 397 > var13; ++var13) {
         var5 = var13;
         var10[var13 - 1] *= var3;

         for(var8 = 1; 4 > var8; ++var8) {
            var3 = var8;
            if (var9 != 0) {
               vMeth_check_sum += var1 + (long)var8 + (long)var11 + (long)var13 + (long)var13 + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
               return;
            }
         }
      }

      vMeth_check_sum += var1 + (long)var3 + (long)var11 + (long)var5 + (long)var13 + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      int[] var2 = new int[400];
      FuzzerUtils.init((int[])var2, (int)-11272);
      this.vMeth(instanceCount, this.iFld);
      FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(var2));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + this.iFld);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
