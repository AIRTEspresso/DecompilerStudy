public class Test {
   public static final int N = 400;
   public static long instanceCount = 42L;
   public int iFld = -12;
   public static double dFld = -2.22376;
   public static byte byFld = 102;
   public static volatile short sFld = -18140;
   public static volatile boolean bFld = false;
   public static int[] iArrFld = new int[400];
   public static volatile int[] iArrFld1 = new int[400];
   public static long byMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(long var0) {
      boolean var2 = true;
      int var3 = -47598;
      byte var4 = -2;
      int var5 = 49440;
      int var6 = -63281;
      float var7 = 2.93F;
      byte var8 = 40;
      short var9 = 22809;
      int var10 = 1;

      while(true) {
         ++var10;
         if (var10 >= 286) {
            vMeth1_check_sum += var0 + (long)var10 + (long)var3 + (long)var4 + (long)Float.floatToIntBits(var7) + (long)var8 + (long)var9 + (long)var5 + (long)var6;
            return;
         }

         for(var3 = 1; var3 < 6; var3 += 2) {
            var7 += (float)(var3 * var3);
            int[] var10000 = iArrFld;
            var10000[var10] <<= var8;
            var9 -= (short)var10;

            for(var5 = 1; var5 < 3; var5 += 2) {
               var8 &= -33;
               dFld += (double)var5;
               var6 += 97;
               var6 += (int)var7;
               var7 = (float)var10;
               var7 -= (float)var3;
               var9 += (short)var5;
               var0 += (long)var3;
               var10000 = iArrFld;
               var10000[var5 - 1] *= var5;
            }
         }
      }
   }

   public static void vMeth(boolean var0) {
      boolean var1 = true;
      int var2 = 21261;
      int var3 = 148;
      int var4 = -13;
      int var5 = -710;
      float var6 = 119.36F;
      double[] var7 = new double[400];
      FuzzerUtils.init(var7, 1.76494);
      vMeth1(30317L);
      int var8 = 138;

      do {
         switch (var8 % 2 * 5 + 62) {
            case 68:
               var2 = 22;

               label68:
               for(; 1 < var2; var2 -= 2) {
                  int[] var10000 = iArrFld;
                  var10000[var2 + 1] += var8;
                  if (var8 != 0) {
                     vMeth_check_sum += (long)((var0 ? 1 : 0) + var8 + var2 + var3 + var4 + var5 + Float.floatToIntBits(var6)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
                     return;
                  }

                  instanceCount -= instanceCount;
                  dFld *= (double)var2;
                  var3 >>= (int)instanceCount;
                  switch (var8 % 8 + 47) {
                     case 47:
                        switch (var2 % 5 + 127) {
                           case 127:
                              var4 = 1;

                              while(true) {
                                 if (var4 >= 3) {
                                    continue label68;
                                 }

                                 var7[var8] %= 1.64917504195884314E18;
                                 var5 = var2;
                                 dFld = (double)var6;
                                 ++var4;
                              }
                           case 128:
                              dFld *= 3.0;
                              continue;
                           case 129:
                              instanceCount >>= (int)instanceCount;
                              continue;
                           case 130:
                           case 131:
                              var6 += var6;
                           default:
                              continue;
                        }
                     case 48:
                        var5 = (int)((long)var5 + ((long)var2 ^ (long)var6));
                        break;
                     case 49:
                        byFld = 85;
                        break;
                     case 50:
                        var3 = -9;
                        break;
                     case 51:
                        var6 = (float)var2;
                        break;
                     case 52:
                        var5 |= var8;
                        break;
                     case 53:
                        if (var2 != 0) {
                           vMeth_check_sum += (long)((var0 ? 1 : 0) + var8 + var2 + var3 + var4 + var5 + Float.floatToIntBits(var6)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
                           return;
                        }
                        break;
                     case 54:
                        var6 += (float)(var2 - sFld);
                  }
               }
               break;
            case 70:
               iArrFld = iArrFld;
         }

         var8 -= 2;
      } while(var8 > 0);

      vMeth_check_sum += (long)((var0 ? 1 : 0) + var8 + var2 + var3 + var4 + var5 + Float.floatToIntBits(var6)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
   }

   public static byte byMeth() {
      boolean var0 = true;
      int var1 = -29;
      boolean var2 = true;
      int var3 = 3;
      int var4 = -121;
      int var5 = -5;
      float var6 = 1.154F;
      long var7 = 169L;

      int var11;
      for(var11 = 3; 286 > var11; ++var11) {
         var1 = (int)instanceCount;
         vMeth(bFld);
         iArrFld[var11] = var1;
         var6 = (float)dFld;
         var1 += var11 * var11;
      }

      int[] var10000 = iArrFld;
      var10000[375] += var11;

      int var12;
      for(var12 = 16; var12 < 380; ++var12) {
         for(var4 = 1; var4 < 5; ++var4) {
            for(var7 = 1L; ++var7 < 2L; var1 = sFld) {
               int var13 = var3 * var5;
               if (var5 != 0) {
               }

               var3 = (int)var7;
               var5 += var5;
            }
         }
      }

      long var9 = (long)(var11 + var1 + Float.floatToIntBits(var6) + var12 + var3 + var4 + var5) + var7;
      byMeth_check_sum += var9;
      return (byte)((int)var9);
   }

   public void mainTest(String[] var1) {
      float var2 = 0.551F;
      float[] var3 = new float[400];
      int var4 = -7;
      boolean var5 = true;
      int var6 = 1;
      int var7 = -1;
      int var8 = 0;
      int var9 = 217;
      short var10 = 173;
      int var11 = -22745;
      byte var12 = 113;
      double[] var13 = new double[400];
      FuzzerUtils.init(var13, -124.42827);
      FuzzerUtils.init(var3, -2.114F);
      instanceCount -= (long)(this.iFld++);
      var2 = (float)((this.iFld + this.iFld) * (var4 | 26));
      this.iFld = byMeth();

      int var18;
      for(var18 = 6; var18 < 244; ++var18) {
         var13[var18 - 1] = -20481.0;
         var4 *= (int)var2;
      }

      int[] var14 = iArrFld;
      int var15 = var14.length;

      for(int var16 = 0; var16 < var15; ++var16) {
         int var17 = var14[var16];
         int[] var10000;
         if (bFld) {
            var10000 = iArrFld;
            var10000[(var4 >>> 1) % 400] += var18;
         } else if (bFld) {
            for(var7 = 3; 63 > var7; ++var7) {
               var17 *= byFld;
            }

            iArrFld = iArrFld;
            iArrFld[(var18 >>> 1) % 400] = var18;
            var8 >>>= var6;
         } else if (bFld) {
            var10000 = iArrFld;
            var10000[(var17 >>> 1) % 400] -= var18;
            instanceCount *= (long)var8;
            var8 -= (int)instanceCount;
         } else {
            iArrFld = iArrFld;

            label66:
            for(var9 = 63; var9 > 2; --var9) {
               var3[var9] += (float)var17;
               var17 = var4;
               switch ((this.iFld >>> 1) % 3 * 5 + 80) {
                  case 83:
                     var17 = var4 | var7;
                     break;
                  case 84:
                     var17 = var4 - (int)instanceCount;
                     var6 |= var18;
                     iArrFld1[var9 + 1] = 2;
                     var11 = 1;

                     while(true) {
                        if (var11 >= 2) {
                           continue label66;
                        }

                        var8 = (int)((long)var8 + ((long)(var11 * var8) + instanceCount - instanceCount));
                        if (bFld) {
                           dFld = (double)var7;
                           var17 += (int)var2;
                        } else if (bFld) {
                           var2 += (float)var11;
                        }

                        var11 += 3;
                     }
                  case 90:
                     var10000 = iArrFld1;
                     var10000[var9] ^= -173;
                     break;
                  default:
                     var8 -= var12;
               }
            }
         }
      }

      FuzzerUtils.out.println("f i i17 = " + Float.floatToIntBits(var2) + "," + var4 + "," + var18);
      FuzzerUtils.out.println("i18 i20 i21 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i22 i23 i24 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("i25 dArr1 fArr = " + var12 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var3)));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.byFld Test.sFld Test.bFld = " + byFld + "," + sFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.iArrFld Test.iArrFld1 = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)14);
      FuzzerUtils.init((int[])iArrFld1, (int)-82);
      byMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
