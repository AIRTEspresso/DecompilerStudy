public class Test {
   public static final int N = 400;
   public static long instanceCount = -7198668973938529287L;
   public static volatile int iFld = -229;
   public short sFld = -31446;
   public static int iFld1 = 10;
   public static volatile float[] fArrFld = new float[400];
   public static long vSmallMeth_check_sum;
   public static long lMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vSmallMeth(long var0, int var2) {
      float var3 = -59.425F;
      iFld = (int)((long)iFld % (var0 | 1L));
      var3 = (float)(++iFld);
      vSmallMeth_check_sum += var0 + (long)var2 + (long)Float.floatToIntBits(var3);
   }

   public static void vMeth(int var0, int var1) {
      float var2 = 2.806F;
      double[] var3 = new double[400];
      FuzzerUtils.init(var3, 1.41799);
      vSmallMeth(instanceCount, -1);
      var3[(var1 >>> 1) % 400] += (double)var2;
      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var3));
   }

   public static long lMeth(int var0) {
      boolean var1 = true;
      int var2 = -214;
      int var3 = -26449;
      int var4 = -238;
      int var5 = -1257;
      char var6 = '\uf1ce';
      int[] var7 = new int[400];
      float var8 = 0.785F;
      byte var9 = -4;
      long var10 = 1243554974L;
      FuzzerUtils.init((int[])var7, (int)-8);
      vMeth(iFld, var0);
      instanceCount += instanceCount;

      int var14;
      label32:
      for(var14 = 21; var14 < 349; ++var14) {
         iFld = var2;
         iFld |= (int)instanceCount;
         var8 -= var8;

         for(var3 = var14; 5 > var3; ++var3) {
            instanceCount += (long)(var3 ^ var2);
            iFld = 123;
         }

         var7[var14] -= var9;
         switch (var14 % 2 * 5 + 100) {
            case 104:
               iFld = (int)var10;
               break;
            case 108:
               var5 = var14;

               while(true) {
                  if (var5 >= 5) {
                     continue label32;
                  }

                  fArrFld[var14 - 1] = (float)var5;
                  var2 = var6;
                  var4 += var5 * var5;
                  ++var5;
               }
            default:
               var8 += (float)var2;
         }
      }

      long var12 = (long)(var0 + var14 + var2 + Float.floatToIntBits(var8) + var3 + var4 + var9 + var5 + var6) + var10 + FuzzerUtils.checkSum(var7);
      lMeth_check_sum += var12;
      return var12;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -195;
      int var4 = -2;
      int var5 = 0;
      int var6 = 54892;
      int var7 = 2;
      short var8 = 225;
      byte var9 = 14;
      int var10 = -48978;
      short var11 = 25990;
      int var12 = -189;
      byte var13 = 1;
      float var14 = -1.923F;
      boolean var15 = true;
      byte[] var16 = new byte[400];
      FuzzerUtils.init((byte[])var16, (byte)108);
      iFld <<= -11 + iFld;

      int var18;
      for(var18 = 340; var18 > 19; --var18) {
         for(int var17 = 0; var17 < 62; ++var17) {
            long var10000 = (long)((float)(--this.sFld) + -1.0F + ((float)var18 - var14) - (float)instanceCount);
            double var10001 = Math.sqrt(-37.78289) + (double)(var3 ^ var18);
            long var10002 = (long)Math.min(var3, iFld);
            --var3;
            vSmallMeth(var10000, (int)(var10001 * (double)(var10002 * 8L * (long)var3)));
         }

         var3 = (int)(lMeth(iFld) + instanceCount);
         if (var15) {
            break;
         }

         var16[var18] = (byte)((int)var14);
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 78) {
               var5 = 78;

               do {
                  iFld = var4;
                  var3 = var5;
                  var14 = (float)iFld;
                  --var5;
               } while(var5 > 0);

               var3 += iFld;
               break;
            }

            var3 = (int)((long)var3 + ((long)var4 ^ instanceCount));
            iFld += var4 * var4;
         }
      }

      if (var15) {
         var6 = 1;

         while(true) {
            var6 += 3;
            if (var6 >= 186) {
               iFld1 >>= 10;
               break;
            }

            for(var7 = 1; var7 < var6; ++var7) {
               iFld >>>= var5;
               var3 = 47891;
               instanceCount *= (long)var14;
               iFld = var9;
               instanceCount = 27202L;

               for(var10 = 1; var10 < 2; ++var10) {
                  var3 -= var9;
                  instanceCount += (long)var11;
                  iFld1 += var10 + var11;
               }
            }
         }
      } else if (var15) {
         for(var12 = 8; var12 < 160; ++var12) {
            instanceCount = (long)var14;
         }

         iFld1 *= var5;
      } else {
         var15 = false;
      }

      FuzzerUtils.out.println("i i1 f1 = " + var18 + "," + var3 + "," + Float.floatToIntBits(var14));
      FuzzerUtils.out.println("b i12 i13 = " + (var15 ? 1 : 0) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i14 i15 i16 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i17 i18 i19 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("i20 i21 byArr = " + var12 + "," + var13 + "," + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
      FuzzerUtils.out.println("Test.iFld1 Test.fArrFld = " + iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 0.479F);
      vSmallMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
