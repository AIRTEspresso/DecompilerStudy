public class Test {
   public static final int N = 400;
   public static long instanceCount = 31948L;
   public static volatile boolean bFld = true;
   public static int iFld = 59888;
   public static short sFld = 3058;
   public static double dFld = -90.111661;
   public static short[] sArrFld = new short[400];
   public static byte[] byArrFld = new byte[400];
   public static long lMeth_check_sum;
   public static long iMeth_check_sum;
   public static long dMeth_check_sum;

   public static double dMeth() {
      boolean var0 = true;
      int var1 = -6;
      byte var2 = 8;
      float var3 = 41.916F;
      double var4 = 126.78193;
      double var6 = 0.108195;
      double[] var8 = new double[400];
      FuzzerUtils.init(var8, -77.101621);

      int var11;
      for(var11 = 11; var11 < 355; ++var11) {
         var3 -= var3;
         var4 = 1.0;

         do {
            boolean var9 = true;
            instanceCount += instanceCount;
            short var12 = (short)((int)var3);
            var1 = var1;
            var6 = 1.0;

            do {
               var1 += (int)((long)var6 ^ (long)var11);
               instanceCount += (long)var11;
               var3 += (float)var4;
               instanceCount = instanceCount;
               var3 -= -8989.0F;
               instanceCount -= (long)var1;
            } while(++var6 < 1.0);

            var1 -= (int)instanceCount;
            var8[var11 + 1] = (double)var2;
         } while(++var4 < 5.0);
      }

      long var13 = (long)(var11 + var1 + Float.floatToIntBits(var3)) + Double.doubleToLongBits(var4) + Double.doubleToLongBits(var6) + (long)var2 + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
      dMeth_check_sum += var13;
      return (double)var13;
   }

   public static int iMeth(long var0, int var2, int var3) {
      float var4 = 2.321F;
      float var5 = -123.208F;
      boolean var6 = true;
      int var7 = 12;
      int var8 = 8537;
      int var9 = -17190;
      int[] var10 = new int[400];
      long var11 = -3793330418L;
      long[] var13 = new long[400];
      byte[] var14 = new byte[400];
      FuzzerUtils.init(var13, 3903266759103189862L);
      FuzzerUtils.init((int[])var10, (int)14);
      FuzzerUtils.init(var14, (byte)-103);
      var4 = 1.0F;

      int var17;
      do {
         label36:
         for(var17 = (int)var4; var17 < 7; var17 += 3) {
            int var10001 = (int)(var4 + 1.0F);
            long var10002 = var13[(int)(var4 + 1.0F)];
            --var3;
            var13[var10001] = var10002 << (int)((long)((double)(var2 * 11 * var3) + Math.abs(dMeth())));
            bFld = true;
            switch ((var17 >>> 1) % 5 + 2) {
               case 2:
                  var8 = 1;

                  while(true) {
                     if (1 <= var8) {
                        continue label36;
                     }

                     if (!bFld) {
                        var11 = -363309613L;
                        var7 = (int)((long)var7 + ((long)(var8 * var7 + var17) - var11));
                        var5 += (float)(var8 * var8);
                        var10[var17 - 1] = 1870944173;
                        var14[var8 + 1] ^= (byte)var3;
                        var2 *= -159;
                     }

                     ++var8;
                  }
               case 3:
                  var7 = (int)instanceCount;
                  break;
               case 4:
                  var7 += 111;
                  break;
               case 5:
                  var7 += var17 - var17;
                  break;
               case 6:
                  var9 = (int)var4;
            }
         }
      } while(++var4 < 235.0F);

      long var15 = var0 + (long)var2 + (long)var3 + (long)Float.floatToIntBits(var4) + (long)var17 + (long)var7 + (long)var8 + (long)var9 + var11 + (long)Float.floatToIntBits(var5) + FuzzerUtils.checkSum(var13) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var14);
      iMeth_check_sum += var15;
      return (int)var15;
   }

   public static long lMeth() {
      int var0;
      int var1;
      short var2;
      int var3;
      int var4;
      int var5;
      int var6;
      int var7;
      byte var8;
      float var9;
      var0 = 156;
      var1 = -100;
      var2 = 16;
      var3 = -30874;
      var4 = 41;
      var5 = -47;
      var6 = -25;
      var7 = -89;
      var8 = 5;
      var9 = 21.808F;
      label43:
      switch ((iMeth(instanceCount, iFld, var0) >>> 1) % 4 * 5 + 60) {
         case 68:
         case 69:
         case 71:
         case 73:
         default:
            var5 = var1;
            break;
         case 70:
            for(var1 = 306; var1 > 2; --var1) {
               iFld <<= var1;
               instanceCount += (long)(var1 + var0);
               sArrFld = FuzzerUtils.short1array(400, (short)-7719);
            }

            var3 = 1;

            while(true) {
               for(var4 = 1; 5 > var4; ++var4) {
                  iFld += var4 * var2 + var2 - iFld;
                  var0 -= var8;
                  iFld >>= var2;

                  for(var6 = 1; var6 < 2; ++var6) {
                     var2 = 174;
                     sFld -= (short)((int)dFld);
                     var7 -= iFld;
                     var8 += (byte)var1;
                  }
               }

               ++var3;
               if (var3 >= 329) {
                  break label43;
               }
            }
         case 74:
            var9 = (float)instanceCount;
         case 67:
         case 72:
            var9 -= (float)var4;
      }

      long var10 = (long)(var0 + var1 + var2 + var3 + var4 + var5 + var8 + var6 + var7 + Float.floatToIntBits(var9));
      lMeth_check_sum += var10;
      return var10;
   }

   public void mainTest(String[] var1) {
      int var2 = 21031;
      boolean var3 = true;
      int var4 = -204;
      int var5 = -949;
      int var6 = -4751;
      int var7 = 69;
      int var8 = 21208;
      byte var9 = 0;
      int[][][] var10 = new int[400][400][400];
      float var11 = -119.498F;
      float var12 = 46.82F;
      byte var13 = -29;
      long[] var14 = new long[400];
      FuzzerUtils.init((Object[][])var10, -50323);
      FuzzerUtils.init(var14, 8757L);
      var2 = Integer.reverseBytes((int)((long)(var2 - var2) + --instanceCount));
      var2 -= (int)(lMeth() * (long)var2);
      int[] var10000 = var10[(iFld >>> 1) % 400][(iFld >>> 1) % 400];
      int var10001 = (iFld >>> 1) % 400;
      var10000[var10001] &= (int)instanceCount;

      int var17;
      label60:
      for(var17 = 5; var17 < 180; ++var17) {
         var10[var17 + 1][var17 + 1][var17] = var2;
         iFld -= var17;
         iFld >>>= var17;
         sFld += (short)((int)dFld);

         for(var11 = 8.0F; var11 < 143.0F; var11 += 3.0F) {
            dFld += (double)var17;
            var6 = 1;

            while(true) {
               ++var6;
               if (var6 >= 4) {
                  if (bFld) {
                     if (bFld) {
                        continue label60;
                     }

                     for(var8 = 1; var8 < 4; ++var8) {
                        var12 -= (float)instanceCount;
                        instanceCount = (long)sFld;
                        var10[var17][(int)var11][var8 + 1] += (int)var11;
                        var14 = var14;
                        var2 = var5;
                        iFld += var8 * var8;
                     }
                  } else if (bFld) {
                     var12 += var11 * var11;
                  } else {
                     byte[] var18 = byArrFld;
                     var18[(int)(var11 + 1.0F)] /= (byte)(iFld | 1);
                  }
                  break;
               }

               var5 -= var2;
               var7 = var17 * var17;
               var10[var6 + 1][var17][var6 - 1] |= sFld;
               var2 += var6 | var5;
               var12 -= (float)var13;
               var7 = 970;
               instanceCount += (long)(var6 * var5 + var7 - var4);
               bFld = bFld;

               try {
                  iFld = 25 / var6;
                  var4 = -28 / var7;
                  var2 = iFld / 47;
               } catch (ArithmeticException var16) {
               }
            }
         }
      }

      FuzzerUtils.out.println("i i18 i19 = " + var2 + "," + var17 + "," + var4);
      FuzzerUtils.out.println("f4 i20 i21 = " + Float.floatToIntBits(var11) + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i22 f5 by1 = " + var7 + "," + Float.floatToIntBits(var12) + "," + var13);
      FuzzerUtils.out.println("i23 i24 iArr1 = " + var8 + "," + var9 + "," + FuzzerUtils.checkSum((Object[][])var10));
      FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + iFld);
      FuzzerUtils.out.println("Test.sFld Test.dFld Test.sArrFld = " + sFld + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("Test.byArrFld = " + FuzzerUtils.checkSum(byArrFld));
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(sArrFld, (short)-24248);
      FuzzerUtils.init((byte[])byArrFld, (byte)90);
      lMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      dMeth_check_sum = 0L;
   }
}
