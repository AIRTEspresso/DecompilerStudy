public class Test {
   public static final int N = 400;
   public static long instanceCount = -11L;
   public static int iFld = -58827;
   public static double dFld = -69.54201;
   public static short sFld = -21332;
   public boolean bFld = false;
   public static int iFld1 = 194;
   public volatile short[] sArrFld = new short[400];
   public static volatile double[] dArrFld = new double[400];
   public static float[] fArrFld = new float[400];
   public static volatile int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth() {
      boolean var0 = true;
      float var1 = -92.635F;
      boolean var2 = false;
      boolean[][][] var3 = new boolean[400][400][400];
      byte var4 = 123;
      long var5 = 5L;
      FuzzerUtils.init((Object[][])var3, true);
      int var9 = 1;

      while(true) {
         ++var9;
         if (var9 >= 201) {
            for(var5 = 1L; ++var5 < 284L; iFld = iFld) {
               iFld += (int)(var5 * instanceCount);
            }

            var2 = true;
            var1 += 18262.0F;
            long var7 = (long)(var9 + Float.floatToIntBits(var1) + (var2 ? 1 : 0) + var4) + var5 + FuzzerUtils.checkSum((Object[][])var3);
            iMeth_check_sum += var7;
            return (int)var7;
         }

         var1 = (float)var9;
         iFld = var9;
         var3[var9 - 1][var9 + 1][var9] = var2;
         iFld >>= iFld;
         iFld = var4;
         float[] var10000 = fArrFld;
         var10000[var9] += (float)iFld;
         iFld *= (int)dFld;
         dFld = (double)instanceCount;
         var10000 = fArrFld;
         var10000[var9 + 1] -= (float)var9;
      }
   }

   public static void vMeth1(int var0) {
      boolean var1 = true;
      short var2 = -138;
      float var3 = 72.392F;

      int var5;
      for(var5 = 328; var5 > 6; --var5) {
         float var4 = 0.974F;
         var0 <<= (int)((float)(++instanceCount) * var4);
      }

      float var10000 = var3 - (float)(var0 - iMeth() + iFld);
      double[] var6 = dArrFld;
      var6[388] -= -168.0;
      var3 = -102.0F;
      vMeth1_check_sum += (long)(var5 + var5 + var2 + Float.floatToIntBits(var3));
   }

   public static void vMeth(double var0, long var2) {
      int var4 = 93;
      int var5 = -45;
      byte var6 = 13;
      float var7 = -2.29F;
      double[] var8 = dArrFld;
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         double var10000 = var8[var10];
         vMeth1(62893);

         for(var4 = 1; 4 > var4; ++var4) {
            var6 = 2;
            var5 = iFld;
            iFld = 49802;
         }
      }

      int[] var13 = iArrFld;
      var13[(var6 >>> 1) % 400] += (int)var2;
      var7 *= (float)var6;
      iFld -= 48873;
      dFld -= (double)sFld;
      vMeth_check_sum += Double.doubleToLongBits(var0) + var2 + (long)var4 + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var7);
   }

   public void mainTest(String[] var1) {
      float var2 = 1.517F;
      boolean var3 = true;
      int var4 = 13647;
      boolean var5 = true;
      int var6 = -23986;
      int var7 = 198;
      int var8 = 44;
      int var9 = -169;
      int[] var10 = new int[400];
      byte var11 = -112;
      long var12 = -12170L;
      long[] var14 = new long[400];
      double[] var15 = new double[400];
      FuzzerUtils.init(var15, 73.18599);
      FuzzerUtils.init((int[])var10, (int)-6);
      FuzzerUtils.init(var14, -2273727902L);
      var2 += var2 - (float)(iFld * iFld + --iFld);

      int var18;
      for(var18 = 16; var18 < 287; ++var18) {
         var15[var18] = (double)this.sArrFld[var18];
         var4 &= var10[var18];
         int var10002 = var10[var18];
         --var4;
         int var10003 = var4;
         int var10004 = Math.min(iFld, iFld);
         ++var4;
         var10[var18] = var10002 << var10003 - var10004 * var4;
      }

      vMeth(-2.70447, instanceCount);
      instanceCount = instanceCount;
      if (this.bFld) {
         iFld += var11;
      }

      int var19;
      for(var19 = 6; var19 < 205; ++var19) {
         for(var7 = 2; var7 < 126; ++var7) {
            instanceCount = (long)var8;
            iArrFld[var19] = -7;
            var2 += (float)var8;
            iFld = (int)((float)iFld + ((float)var7 * var2 + (float)var19 - (float)var18));
            var8 /= 39805;
            var2 += (float)dFld;

            try {
               iFld1 = var19 / var4;
               var6 = 12 / var6;
               iArrFld[var7] = iArrFld[var7 + 1] % var8;
            } catch (ArithmeticException var17) {
            }

            sFld = (short)var6;

            for(var12 = (long)var19; var12 < 2L; ++var12) {
               var10[(int)(var12 - 1L)] |= var7;
               var9 = var18;
               int[] var10000 = iArrFld;
               var10000[var19] ^= var4;
               var8 >>>= var11;
               instanceCount |= (long)var19;
               sFld += (short)((int)var12);
               var4 += (int)instanceCount;
            }

            var4 *= var19;
         }

         dArrFld = dArrFld;
         var6 /= var4 | 1;
      }

      FuzzerUtils.out.println("f i i1 = " + Float.floatToIntBits(var2) + "," + var18 + "," + var4);
      FuzzerUtils.out.println("by1 i10 i11 = " + var11 + "," + var19 + "," + var6);
      FuzzerUtils.out.println("i12 i13 l2 = " + var7 + "," + var8 + "," + var12);
      FuzzerUtils.out.println("i14 dArr iArr = " + var9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var15)) + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.sFld bFld Test.iFld1 = " + sFld + "," + (this.bFld ? 1 : 0) + "," + iFld1);
      FuzzerUtils.out.println("sArrFld Test.dArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.sArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 0.65447);
      FuzzerUtils.init(fArrFld, -1.139F);
      FuzzerUtils.init((int[])iArrFld, (int)200);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
