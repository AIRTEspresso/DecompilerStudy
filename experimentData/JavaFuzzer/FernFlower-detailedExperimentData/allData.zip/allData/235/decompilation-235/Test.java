public class Test {
   public static final int N = 400;
   public static long instanceCount = -13L;
   public byte byFld = 2;
   public static double dFld = 1.15879;
   public static volatile byte byFld1 = -37;
   public static float fFld = 0.395F;
   public static volatile double[] dArrFld = new double[400];
   public static float[] fArrFld = new float[400];
   public volatile int[] iArrFld = new int[400];
   public static long lMeth_check_sum;
   public static long lMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(long var0, int var2, int var3) {
      boolean var4 = true;
      short var5 = -30539;
      int var6 = 251;
      int var7 = 8;
      int var8 = -12;
      int[] var9 = new int[400];
      int[][][] var10 = new int[400][400][400];
      byte var11 = 111;
      boolean var12 = false;
      float var13 = -2.966F;
      short var14 = 13171;
      FuzzerUtils.init(var9, -33890);
      FuzzerUtils.init((Object[][])var10, -12);
      var2 = (int)instanceCount;
      int[] var15 = var9;
      int var16 = var9.length;

      for(int var17 = 0; var17 < var16; ++var17) {
         int var10000 = var15[var17];
         var2 = var3;
         var0 += (long)var3;
      }

      dArrFld[(var3 >>> 1) % 400] = 59648.0;
      var3 *= 228;

      int var19;
      for(var19 = 3; var19 < 195; ++var19) {
         var11 &= (byte)var3;
         if (var12) {
            break;
         }

         for(var6 = var19; var6 < 8; ++var6) {
            var8 = 1;

            while(true) {
               ++var8;
               if (var8 >= 1) {
                  break;
               }

               var10 = var10;
               var3 = (int)var13;
               var13 += (float)var8 * var13 + (float)var14 - (float)var3;
               var7 += var8;
            }
         }
      }

      vMeth_check_sum += var0 + (long)var2 + (long)var3 + (long)var19 + (long)var5 + (long)var11 + (long)(var12 ? 1 : 0) + (long)var6 + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var13) + (long)var14 + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum((Object[][])var10);
   }

   public static long lMeth1(long var0) {
      int var2 = 6;
      boolean var3 = true;
      byte var4 = -4;
      int var5 = 172;
      byte var6 = -7;
      int var7 = -10;
      int var8 = -41008;
      int[][] var9 = new int[400][400];
      float var10 = -86.297F;
      boolean var11 = true;
      FuzzerUtils.init((int[][])var9, (int)-6);
      vMeth(var0, 30684, var2);

      int var14;
      for(var14 = 3; var14 < 179; ++var14) {
         var10 = 1.0F;

         do {
            fArrFld = fArrFld;
            var9[(int)(var10 + 1.0F)][var14 - 1] |= var14;
            var9[(int)(var10 - 1.0F)][var14 + 1] += 1690;
            var2 *= (int)dFld;
            byFld1 += (byte)((int)(6.0F + var10 * var10));
            var0 += (long)(var10 * var10);

            for(var5 = 1; var5 < 3; ++var5) {
               instanceCount += (long)var14;
            }
         } while((var10 += 3.0F) < 9.0F);

         var0 *= 128L;

         for(var7 = 1; 9 > var7; ++var7) {
            float[] var10000 = fArrFld;
            var10000[var14 + 1] *= (float)var14;
            if (var11) {
            }
         }
      }

      long var12 = var0 + (long)var2 + (long)var14 + (long)var4 + (long)Float.floatToIntBits(var10) + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var9);
      lMeth1_check_sum += var12;
      return var12;
   }

   public static long lMeth() {
      double var0 = -2.69354;
      int var2 = -10;
      boolean var3 = false;
      int var4 = -177;
      int var5 = -33746;
      int var6 = 137;
      int var7 = 13;
      short var8 = 130;
      int[] var9 = new int[400];
      FuzzerUtils.init((int[])var9, (int)181);
      var0 = (double)((long)(-var2) * ((long)var2 % (instanceCount | 1L) >> var2 % (var2 | 1)));
      var2 -= (int)(++var0);
      lMeth1(instanceCount);

      int var12;
      for(var12 = 7; var12 < 232; ++var12) {
         for(var5 = var12; var5 < 7; ++var5) {
            var2 += var5 * var5;

            for(var7 = 1; var7 < 1; ++var7) {
               boolean var10 = false;
               var9[var12] = (int)fFld;
               switch (var7 % 3 + 126) {
                  case 126:
                     var4 -= var8;
                     break;
                  case 127:
                     fFld %= (float)(instanceCount | 1L);
                     var6 *= var8;
                  case 128:
                     instanceCount += (long)var5;
                     var9[var5] >>= 48994;
                     if (var10) {
                        break;
                     }
                  default:
                     var9[var12 - 1] += 475700792;
               }
            }
         }
      }

      long var13 = Double.doubleToLongBits(var0) + (long)var2 + (long)var12 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
      lMeth_check_sum += var13;
      return var13;
   }

   public void mainTest(String[] var1) {
      float var2 = 1.187F;
      int var3 = -6360;
      boolean var4 = true;
      int var5 = -101;
      int var6 = 49669;
      int var7 = 10;
      byte var8 = -14;
      double var9 = 1.65927;
      short var11 = -26214;
      short[] var12 = new short[400];
      long[] var13 = new long[400];
      byte[][][] var14 = new byte[400][400][400];
      FuzzerUtils.init(var13, -56288L);
      FuzzerUtils.init((Object[][])var14, (byte)53);
      FuzzerUtils.init(var12, (short)-4381);
      this.byFld = (byte)((int)(Math.abs(var2) * (float)lMeth() - (float)var3));
      var13[235] /= (long)(var3 | 1);
      int[] var10000 = this.iArrFld;
      var10000[6] *= var3;
      var3 *= var3;
      int var15 = 1;

      do {
         label46: {
            var3 += var15 * var3;
            var2 *= 7.0F;
            dFld += (double)instanceCount;
            var14 = var14;

            for(var9 = 4.0; 100.0 > var9; ++var9) {
               var11 += (short)((int)(var9 - (double)var5));
               var5 += (int)(var9 * var9);
            }

            switch (var15 % 2 + 16) {
               case 16:
                  dFld = (double)var15;
                  instanceCount += (long)var5;
                  byFld1 >>= (byte)var5;
                  break label46;
               case 17:
               default:
                  var6 = 1;
            }

            do {
               var5 += (int)instanceCount;
               dFld = 5.0;

               for(var7 = var15; var7 < 1; ++var7) {
                  var12[var7] -= (short)((int)instanceCount);
                  this.iArrFld = this.iArrFld;
                  instanceCount <<= '얏';
                  switch ((var5 >>> 1) % 4 + 64) {
                     case 64:
                        this.iArrFld[var6] = (int)instanceCount;
                        break;
                     case 65:
                     case 66:
                        var3 = (int)instanceCount;
                        var13[var6] = (long)var3;
                        instanceCount *= instanceCount;
                        break;
                     case 67:
                        this.iArrFld[var15 - 1] = var3;
                  }
               }

               ++var6;
            } while(var6 < 100);
         }

         ++var15;
      } while(var15 < 252);

      FuzzerUtils.out.println("f i22 i23 = " + Float.floatToIntBits(var2) + "," + var3 + "," + var15);
      FuzzerUtils.out.println("d1 i26 s1 = " + Double.doubleToLongBits(var9) + "," + var5 + "," + var11);
      FuzzerUtils.out.println("i27 i28 i29 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("lArr byArr sArr = " + FuzzerUtils.checkSum(var13) + "," + FuzzerUtils.checkSum((Object[][])var14) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount byFld Test.dFld = " + instanceCount + "," + this.byFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.byFld1 Test.fFld Test.dArrFld = " + byFld1 + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("Test.fArrFld iArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, -2.69701);
      FuzzerUtils.init(fArrFld, -118.926F);
      lMeth_check_sum = 0L;
      lMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
