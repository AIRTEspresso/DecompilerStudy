public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 6951135113443121899L;
   public static float fFld = -1.63F;
   public static double dFld = 26.112492;
   public static boolean bFld = true;
   public static volatile long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = -52;
      int var5 = 15;
      int[] var6 = new int[400];
      float var7 = -55.706F;
      double var8 = 1.26081;
      long var10 = -29882L;
      long var12 = 0L;
      FuzzerUtils.init((int[])var6, (int)39179);
      var1 *= var1;
      var0 = 178;
      var2 = var2;
      int var16 = 1;

      do {
         var6[var16] -= (int)var7;

         for(var8 = 1.0; var8 < 8.0; ++var8) {
            var6[var16 + 1] = (int)var8;
            var6[var16 - 1] += (int)instanceCount;

            for(var10 = (long)var8; var10 < 2L; ++var10) {
               var1 = var0;
               instanceCount -= (long)var8;
               var7 -= (float)var8;
               if (var2) {
                  try {
                     var4 = 198 % var6[var16 + 1];
                     var0 /= var0;
                     var4 = 80 / var5;
                  } catch (ArithmeticException var15) {
                  }

                  var5 = (int)var12;
               }
            }
         }

         ++var16;
      } while(var16 < 208);

      vMeth1_check_sum += (long)(var0 + var1 + (var2 ? 1 : 0) + var16 + Float.floatToIntBits(var7)) + Double.doubleToLongBits(var8) + (long)var4 + var10 + (long)var5 + var12 + FuzzerUtils.checkSum(var6);
   }

   public static void vMeth(double var0, byte var2) {
      int var3 = -13;
      boolean var4 = true;
      int var5 = -4;
      int var6 = -10;
      boolean var7 = true;
      boolean var8 = false;
      short var9 = 27020;
      vMeth1(var3, var3);

      int var10;
      for(var10 = 9; var10 < 184; ++var10) {
         fFld -= (float)var10;
         var6 = 9;

         do {
            var5 += (int)instanceCount;
            --var6;
         } while(var6 > 0);

         if (var8) {
            break;
         }

         var3 = (int)((long)var3 + ((long)(var10 * var6) + instanceCount - instanceCount));
         var3 |= var3;
         instanceCount = instanceCount;
         var5 += var10 * var10 + var6 - var3;
      }

      int var11 = (int)var0;
      instanceCount -= (long)var6;
      var11 += var9;
      vMeth_check_sum += Double.doubleToLongBits(var0) + (long)var2 + (long)var3 + (long)var10 + (long)var5 + (long)var6 + (long)(var8 ? 1 : 0) + (long)var11 + (long)var9;
   }

   public int iMeth(int var1, float var2, int var3) {
      boolean var4 = true;
      byte var5 = 4;
      int var6 = -8;
      byte var7 = -5;
      int var8 = -31319;
      int var9 = 4;
      byte var10 = 39;
      boolean var11 = false;

      int var14;
      for(var14 = 10; var14 < 174; ++var14) {
         vMeth(dFld, var10);
         if (!var11) {
            dFld -= (double)var9;
         } else {
            var1 = (int)instanceCount;
            switch ((var5 >>> 1) % 1 + 91) {
               case 91:
                  var6 = 1;

                  do {
                     var2 *= (float)var5;
                     var7 = var10;

                     for(var8 = 1; var8 > var6; --var8) {
                        if (!var11) {
                           lArrFld = FuzzerUtils.long1array(400, 91L);
                           var9 ^= var8;
                           instanceCount = (long)var6;
                           var3 += var8 + var5;
                           if (var11) {
                              break;
                           }
                        }
                     }

                     ++var6;
                  } while(var6 < 10);
                  break;
               default:
                  var1 += 130;
            }
         }
      }

      long var12 = (long)(var1 + Float.floatToIntBits(var2) + var3 + var14 + var5 + var10 + var6 + var7 + var8 + var9 + (var11 ? 1 : 0));
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 34913;
      int var4 = 129;
      int var5 = 9;
      int var6 = -3;
      byte var7 = 14;
      int var8 = -5;
      short var9 = 17884;
      int[] var10 = new int[400];
      short var11 = 19104;
      short[] var12 = new short[400];
      byte var13 = -82;
      long[] var14 = new long[400];
      FuzzerUtils.init((int[])var10, (int)20056);
      FuzzerUtils.init((short[])var12, (short)13116);
      FuzzerUtils.init(var14, 61L);

      int var17;
      for(var17 = 15; var17 < 392; ++var17) {
         var11 -= (short)((int)((double)(++var10[var17]) + (double)this.iMeth(var3, 2.6F, var3) * dFld));
         if (!bFld) {
            var3 -= 147;

            label66:
            for(var4 = var17; var4 < 67; ++var4) {
               switch (var4 % 2 * 5 + 17) {
                  case 18:
                     var10[var17] = (int)instanceCount;
                     var13 += (byte)var4;
                     var6 = 1;

                     for(; var6 > 1; var6 -= 3) {
                        if (!bFld) {
                           dFld = (double)var3;
                           var3 -= var7;
                           instanceCount += (long)(var6 * var11 + var13 - var3);
                           var12[var4] += (short)var5;
                           var10[var4 - 1] += var3;
                           instanceCount += (long)var6 * instanceCount + instanceCount - (long)var6;
                           var5 /= var3 | 1;
                        }
                     }

                     instanceCount -= (long)var7;
                     break;
                  case 26:
                     lArrFld = var14;

                     try {
                        int var10000 = var4 % var3;
                        var3 = var17 % var7;
                        var5 = var17 / var10[var4 - 1];
                     } catch (ArithmeticException var16) {
                     }

                     var8 = 1;

                     while(true) {
                        if (1 <= var8 || bFld) {
                           continue label66;
                        }

                        var11 += (short)var4;
                        var3 -= var17;
                        fFld *= (float)dFld;
                        long[] var18 = lArrFld;
                        var18[var17 + 1] += instanceCount;
                        ++var8;
                     }
                  default:
                     var3 ^= var7;
                     instanceCount += -230L + (long)(var4 * var4);
               }
            }

            var3 -= 26551;
            var3 >>= var7;
         }
      }

      FuzzerUtils.out.println("i i1 s = " + var17 + "," + var3 + "," + var11);
      FuzzerUtils.out.println("i20 i21 by2 = " + var4 + "," + var5 + "," + var13);
      FuzzerUtils.out.println("i22 i23 i24 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i25 iArr sArr = " + var9 + "," + FuzzerUtils.checkSum(var10) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.bFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -29681L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
