public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -3L;
   public static double dFld = -85.81815;
   public static byte byFld = 86;
   public static float fFld = 117.644F;
   public short sFld = -15762;
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(int var0, int var1, int var2) {
      byte var3 = 110;
      boolean var4 = true;
      short var5 = -141;
      int var6 = 42;
      int var7 = 5;
      int var8 = 35442;
      byte var9 = 2;
      short var10 = -10467;
      double var11 = 28.83515;
      long[] var13 = new long[400];
      FuzzerUtils.init(var13, 2916952361270809038L);
      byte var16 = (byte)(var3 * (byte)var1);

      int var17;
      for(var17 = 7; var17 < 179; ++var17) {
         instanceCount = (long)var5;

         for(var6 = 1; var6 < 9; ++var6) {
            for(var8 = 1; var8 < 2; ++var8) {
               instanceCount += (long)(var8 - var5);
            }

            var5 = var10;
            iArrFld[var6] = (int)instanceCount;
            var13[var6 + 1] += (long)var7;
            var11 *= (double)var17;
            var2 += 127;
         }
      }

      var7 += 48331;
      instanceCount = instanceCount;
      instanceCount = (long)var2;
      var7 >>= var0;
      long var14 = (long)(var0 + var1 + var2 + var16 + var17 + var5 + var6 + var7 + var8 + var9 + var10) + Double.doubleToLongBits(var11) + FuzzerUtils.checkSum(var13);
      iMeth_check_sum += var14;
      return (int)var14;
   }

   public static void vMeth1(int var0, short var1, int var2) {
      int var3 = 74;
      int var4 = -1;
      short var5 = 184;
      int var6 = -21;
      short var7 = -18597;
      byte var8 = -121;
      boolean var9 = false;
      float var10 = -120.945F;
      float[] var11 = new float[400];
      long[] var12 = new long[400];
      FuzzerUtils.init(var11, 57.381F);
      FuzzerUtils.init(var12, -32798L);
      switch (((-42015 & var0) >>> 1) % 6 * 5 + 97) {
         case 101:
            var2 = (int)instanceCount;
            break;
         case 102:
            var0 -= (int)var10;
            break;
         case 112:
            var11[(var2 >>> 1) % 400] -= (float)Math.abs(var0++ * iMeth(var0, var2, -54914));
            var3 = 1;

            do {
               var0 += var2;
               instanceCount = (long)var2;
               var2 += 31466 + var3 * var3;

               for(var4 = 1; var4 < 7; ++var4) {
                  var8 <<= var8;
                  var9 = var9;

                  for(var6 = var4; var6 < 2; ++var6) {
                     dFld = dFld;
                     switch (var3 % 2 + 104) {
                        case 104:
                           dFld += (double)var3;
                           dFld -= -202.0;
                           var0 = var8;
                           break;
                        case 105:
                           var10 += (float)(var6 * var6);
                     }
                  }
               }

               ++var3;
            } while(var3 < 243);
         case 100:
            dFld *= (double)var2;
            break;
         case 115:
            instanceCount *= (long)var2;
         case 123:
            var12 = var12;
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var8 + (var9 ? 1 : 0) + var6 + var7 + Float.floatToIntBits(var10)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)) + FuzzerUtils.checkSum(var12);
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      int var2 = 62033;
      boolean var3 = true;
      short var4 = -135;
      int var5 = 117;

      int var6;
      for(var6 = 7; var6 < 227; var6 += 3) {
         vMeth1(var6, (short)-11532, var2);
      }

      int var7;
      for(var7 = 5; var7 < 180; ++var7) {
         if (var7 != 0) {
            vMeth_check_sum += (long)(var0 + var6 + var2 + var7 + var4 + var5);
            return;
         }

         var5 = 1;

         do {
            iArrFld = FuzzerUtils.int1array(400, -1);
            byFld += (byte)var5;
            instanceCount *= (long)var5;
            instanceCount = (long)var7;
            var0 = var5 - var2;
            ++var5;
         } while(var5 < 9);

         instanceCount = (long)var5;
         instanceCount += (long)(var7 * var7);
         var2 <<= var5;
         instanceCount <<= (int)instanceCount;
      }

      vMeth_check_sum += (long)(var0 + var6 + var2 + var7 + var4 + var5);
   }

   public void mainTest(String[] var1) {
      int var2 = 38695;
      int var3 = 38;
      int var4 = 45019;
      short var5 = 6176;
      float var6 = -92.67F;
      boolean var7 = true;
      short var8 = -16563;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, 54201L);
      var2 = 1;

      while(true) {
         ++var2;
         if (var2 >= 323) {
            FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var3 + "," + var4);
            FuzzerUtils.out.println("f1 b1 s2 = " + Float.floatToIntBits(var6) + "," + (var7 ? 1 : 0) + "," + var8);
            FuzzerUtils.out.println("i25 lArr2 = " + var5 + "," + FuzzerUtils.checkSum(var9));
            FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
            FuzzerUtils.out.println("Test.fFld sFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(iArrFld));
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         for(var3 = 4; var3 < 78; ++var3) {
            vMeth(13350);
            var4 += var3;
            var6 = 1.0F;

            do {
               if (!var7) {
                  fFld += var6;
                  int var10000;
                  switch (var2 % 7 + 14) {
                     case 14:
                        instanceCount &= (long)var3;
                        switch (var2 % 2 + 30) {
                           case 30:
                              var7 = true;
                              var10000 = var4 + (int)((long)var6 ^ (long)var6);
                              var4 = var2;
                              break;
                           case 31:
                              var9[var3 + 1] = (long)var6;
                           default:
                              var4 += (int)(var6 * (float)this.sFld + (float)var4 - (float)var2);
                        }

                        var4 *= (int)instanceCount;
                        fFld += (float)var2;
                        break;
                     case 15:
                        var4 += (int)instanceCount;
                        break;
                     case 16:
                        int[] var12 = iArrFld;
                        var12[var2] >>>= -1;
                        var4 *= var3;
                        instanceCount += (long)var3;
                        break;
                     case 17:
                        var9[var3 + 1] |= instanceCount;
                        break;
                     case 18:
                        instanceCount *= (long)dFld;
                        var4 = var4;
                        switch ((var2 >>> 1) % 6 + 105) {
                           case 105:
                              var8 *= -29227;
                              continue;
                           case 106:
                              var4 = 4;
                              fFld = (float)dFld;
                              var9[var3 - 1] *= (long)var2;
                           case 107:
                              try {
                                 var10000 = var3 % var2;
                                 var4 = var3 / 2;
                                 var4 = var2 / -47091;
                              } catch (ArithmeticException var11) {
                              }
                              continue;
                           case 108:
                              var4 += (int)(var6 * (float)var3 + (float)var4 - (float)var8);
                              continue;
                           case 109:
                              instanceCount *= (long)dFld;
                           case 110:
                              var4 += (int)((long)var6 ^ (long)var2);
                           default:
                              continue;
                        }
                     case 19:
                        var5 = byFld;
                        break;
                     case 20:
                        var9[var3 + 1] = (long)var3;
                  }
               }
            } while(++var6 < 2.0F);
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)26433);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
