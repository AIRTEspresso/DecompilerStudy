public class Test {
   public static final int N = 400;
   public static long instanceCount = -60L;
   public static volatile boolean bFld = true;
   public static double dFld = 53.97498;
   public static byte byFld = 127;
   public int iFld = -60701;
   public int iFld1 = 43182;
   public static boolean bFld1 = false;
   public static long lFld = -212L;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long bMeth_check_sum;

   public static boolean bMeth(int var0, long var1) {
      int var3 = 5;
      int var4 = -8;
      int var5 = -125;
      int var6 = 5;
      int var7 = -20817;
      int var8 = 239;
      int var9 = -10;
      char var10 = '\ude40';
      float var11 = -2.104F;
      byte var12 = -54;
      long var13 = -3139798362L;
      short var15 = -27326;

      try {
         if (bFld) {
            var0 -= 37361;
         } else if (bFld) {
            for(var3 = 13; 355 > var3; ++var3) {
               var5 = 1;

               while(true) {
                  ++var5;
                  if (var5 >= 5) {
                     var4 >>>= var5;
                     break;
                  }

                  instanceCount *= (long)var11;
               }
            }

            var6 = 1;

            do {
               for(var7 = 1; var7 < 6; var7 += 2) {
                  for(var9 = 1; var9 < 3; ++var9) {
                     var0 += var9 + var6;
                  }

                  iArrFld[var7 + 1] = var0;
               }

               ++var6;
            } while(var6 < 276);

            var12 -= (byte)((int)var1);
            var13 += -1L;
         } else {
            var8 = var4;
         }
      } catch (ArithmeticException var18) {
         var4 += (int)var11;
      } catch (UserDefinedExceptionTest var19) {
         var0 = var15;
      }

      long var16 = (long)var0 + var1 + (long)var3 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var11) + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + (long)var12 + var13 + (long)var15;
      bMeth_check_sum += var16;
      return var16 % 2L > 0L;
   }

   public static void vMeth(float var0, int var1, double var2) {
      boolean var4 = true;
      int var5 = 14;
      int var6 = 56779;
      int var7 = -251;
      double var8 = 2.68192;
      boolean var10 = false;
      float[] var11 = new float[400];
      FuzzerUtils.init(var11, 0.4F);
      int var12 = 1;

      do {
         var8 = 1.0;

         do {
            if (bMeth(var12, instanceCount)) {
               var1 = (int)((double)var1 + 9.0 + var8 * var8);
               int[] var10000 = iArrFld;
               var10000[var12 + 1] -= iArrFld[var12 - 1];
            } else if (var10) {
               if (!(instanceCount > instanceCount-- | var10)) {
                  break;
               }

               instanceCount += (long)(--var11[var12] - (float)(var1 + -13535) * (var0 + -1833.0F));
            } else {
               for(var5 = 1; var5 < 1; ++var5) {
                  var1 = ~var1;
                  instanceCount = (long)var1;
                  instanceCount += (long)var1;
                  var6 -= (int)var0;
                  var7 *= 1;
               }
            }

            var6 *= (int)instanceCount;
            var2 += var2;
         } while(++var8 < 6.0);

         ++var12;
      } while(var12 < 263);

      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1) + Double.doubleToLongBits(var2) + (long)var12 + Double.doubleToLongBits(var8) + (long)(var10 ? 1 : 0) + (long)var5 + (long)var6 + (long)var7 + Double.doubleToLongBits(FuzzerUtils.checkSum(var11));
   }

   public static int iMeth(long var0, int var2, int var3) {
      int var4 = 11;
      int var5 = 2;
      short var6 = -10944;
      boolean[] var7 = new boolean[400];
      long[] var8 = new long[400];
      FuzzerUtils.init(var7, false);
      FuzzerUtils.init(var8, 6L);
      var7[(var2 >>> 1) % 400] = var7[(var3 >>> 1) % 400];
      var3 *= (int)var8[(var3 >>> 1) % 400];
      vMeth(-101.447F, var2, dFld);
      if (bFld) {
         var4 = 11;

         int[] var10000;
         while(var4 < 180) {
            switch (var4 % 1 + 23) {
               case 23:
               default:
                  var10000 = iArrFld;
                  var10000[var4] <<= var4;
                  var6 -= (short)var5;
                  ++var4;
            }
         }

         var10000 = iArrFld;
         var10000[(var5 >>> 1) % 400] *= -2;
         var3 -= var4;
         var8[195] -= instanceCount;
      } else if (bFld) {
         var5 -= (int)dFld;
      } else {
         byFld *= (byte)((int)dFld);
      }

      byFld = (byte)var5;
      long var9 = var0 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -8;
      int var4 = -26279;
      int var5 = -30;
      int var6 = -2;
      int var7 = 30;
      int var8 = 222;
      int var9 = -121;
      float var10 = 1.1F;
      long[][] var11 = new long[400][400];
      FuzzerUtils.init(var11, 241L);

      int var13;
      for(var13 = 13; var13 < 271; ++var13) {
         iArrFld = FuzzerUtils.int1array(400, -246);
         iMeth(instanceCount, var13, var13);
         switch (var13 % 2 * 5 + 82) {
            case 84:
               if (bFld) {
                  break;
               }

               switch (var13 % 7 * 5 + 12) {
                  case 18:
                     dFld /= (double)(byFld | 1);
                  case 34:
                     this.iFld -= var3;
                     continue;
                  case 28:
                     iArrFld[var13 + 1] = (int)instanceCount;
                     continue;
                  case 35:
                     instanceCount &= 14L;
                     var3 <<= -19576;
                     dFld = (double)instanceCount;

                     for(var4 = 1; 97 > var4; var4 += 2) {
                        short var12 = -5632;
                        instanceCount = (long)var6;
                        var5 = (int)((long)var5 + ((long)(var4 * var5) + instanceCount - (long)var12));

                        for(var7 = 3; var7 > 1; --var7) {
                           var8 >>= var6;
                           var3 -= var7;
                           instanceCount <<= var6;
                           instanceCount += (long)var5;
                           if (!bFld) {
                              if (bFld) {
                                 break;
                              }

                              this.iFld += 152;
                              instanceCount -= (long)var7;
                              var11[var4][var13] = instanceCount;
                           }
                        }

                        this.iFld = var4;
                        var9 = 1;

                        while(true) {
                           ++var9;
                           if (var9 >= 3) {
                              break;
                           }

                           this.iFld1 >>= -21569;
                           this.iFld = this.iFld1;
                           if (bFld1) {
                              int[] var10000 = iArrFld;
                              var10000[var4 + 1] -= (int)instanceCount;
                              var8 += var9 * var4 + var5 - var3;
                              instanceCount >>= var3;
                           } else if (bFld1) {
                              this.iFld = 139;
                           } else {
                              var5 += (int)dFld;
                           }
                        }
                     }
                  case 38:
                     var10 = (float)var4;
                     continue;
                  case 44:
                     var3 = var9;
                     continue;
                  case 45:
                     var6 *= 135;
                  default:
                     continue;
               }
            case 87:
               var10 *= (float)lFld;
            default:
               iArrFld[var13] = var13;
         }
      }

      FuzzerUtils.out.println("i i1 i20 = " + var13 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i21 i22 i23 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i24 i25 f3 = " + var8 + "," + var9 + "," + Float.floatToIntBits(var10));
      FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.byFld iFld iFld1 = " + byFld + "," + this.iFld + "," + this.iFld1);
      FuzzerUtils.out.println("Test.bFld1 Test.lFld Test.iArrFld = " + (bFld1 ? 1 : 0) + "," + lFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)8673);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      bMeth_check_sum = 0L;
   }
}
