public class Test {
   public static final int N = 400;
   public static long instanceCount = -27L;
   public int iFld = -244;
   public static float fFld = 88.972F;
   public static boolean bFld = false;
   public short sFld = 32045;
   public static byte[] byArrFld = new byte[400];
   public static long fMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth() {
      short var0 = 161;
      int var1 = -36882;
      int var2 = -32838;
      int var3 = -168;
      byte var4 = 6;
      int var5 = 27239;
      int[] var6 = new int[400];
      short var7 = -24569;
      short var8 = 27002;
      double var9 = 2.99229;
      boolean var11 = false;
      long var12 = 0L;
      FuzzerUtils.init((int[])var6, (int)-55);
      var6[(var0 >>> 1) % 400] = var0;

      for(var1 = 4; var1 < 129; var1 += 3) {
         fFld *= 10.0F;

         for(var3 = 37; var3 > 2; --var3) {
            var5 = 1;

            do {
               var7 = (short)(var7 + 24015);
               if (var11) {
                  var9 += (double)instanceCount;
               }

               ++var5;
            } while(var5 < 2);
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var7) + Double.doubleToLongBits(var9) + (long)(var11 ? 1 : 0) + var12 + (long)var8 + FuzzerUtils.checkSum(var6);
   }

   public static int iMeth(long var0, int var2) {
      boolean var3 = true;
      int var4 = 21628;
      int[] var5 = new int[400];
      double var6 = -2.4667;
      double[][] var8 = new double[400][400];
      FuzzerUtils.init((int[])var5, (int)196);
      FuzzerUtils.init(var8, -8.9381);
      vMeth();
      byArrFld = byArrFld;

      int var12;
      for(var12 = 1; 327 > var12; var12 += 3) {
         var5[var12 + 1] = (int)fFld;
         var8[var12 - 1][var12] += 27891.0;
         var4 = var2;
         var2 %= (int)((long)fFld | 1L);
         var2 += (int)var6;
         var6 = 17596.0;
         fFld += (float)var12;
         instanceCount += var0;
      }

      var5[(var4 >>> 1) % 400] ^= 34668;
      byte var11 = -61;
      long var9 = var0 + (long)var11 + (long)var12 + (long)var4 + Double.doubleToLongBits(var6) + FuzzerUtils.checkSum(var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public static float fMeth(long var0) {
      int var2 = 174;
      boolean var3 = true;
      int var4 = -14;
      int[] var5 = new int[400];
      float var6 = -1.278F;
      float var7 = -5.484F;
      short var8 = 3940;
      FuzzerUtils.init((int[])var5, (int)40504);
      var5[(var2 >>> 1) % 400] >>= (int)((float)(var2 - Math.min(var2, 13)) - ((float)((long)var2 + instanceCount) + ((float)var2 - var6)));
      var6 += (float)(--var0);
      int var11 = 1;

      while(true) {
         ++var11;
         if (var11 >= 227) {
            instanceCount = 1L;

            for(var7 = 3.0F; var7 < 208.0F; ++var7) {
               var4 += (int)var0;
               var4 *= var4;
               var4 = (int)instanceCount;
            }

            var4 -= var11;
            long var9 = var0 + (long)var11 + (long)Float.floatToIntBits(var6) + (long)var11 + (long)var8 + (long)Float.floatToIntBits(var7) + (long)var4 + FuzzerUtils.checkSum(var5);
            fMeth_check_sum += var9;
            return (float)var9;
         }

         var0 <<= (int)(instanceCount-- + (long)(var2 - var11 - var11 * var11));
         var2 = (int)(--instanceCount);
         iMeth(instanceCount, var2);
         var2 %= var8 | 1;
         var2 += var11 * var11;
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 64808;
      int var4 = 12;
      int var5 = -221;
      int var6 = 11;
      int var7 = -11;
      int[] var8 = new int[400];
      double var9 = 0.51427;
      long[] var11 = new long[400];
      float[] var12 = new float[400];
      FuzzerUtils.init(var11, -1L);
      FuzzerUtils.init(var12, -90.698F);
      FuzzerUtils.init((int[])var8, (int)-10);
      var11[74] *= (long)((float)((long)Math.abs(this.iFld) + Math.min(instanceCount, -1279146865349914639L)) - (float)(this.iFld + 140) * fMeth(instanceCount));

      int var13;
      for(var13 = 13; 304 > var13; ++var13) {
         for(var9 = 86.0; var9 > 3.0; --var9) {
            for(var5 = 2; (double)var5 > var9; --var5) {
               var3 = var6;
               switch ((int)(var9 % 10.0 + 42.0)) {
                  case 42:
                     var12[var5 - 1] -= -1.12304F;
                     byArrFld[(int)(var9 + 1.0)] = (byte)var13;
                     break;
                  case 43:
                     instanceCount -= instanceCount;
                     if (bFld) {
                     }
                     break;
                  case 44:
                     instanceCount <<= var5;
                  case 45:
                     var3 = var13;
                     instanceCount = instanceCount;
                     break;
                  case 46:
                     switch (var13 % 2 * 5 + 89) {
                        case 92:
                           var11[var5 + 1] = (long)var13;
                           var6 -= var4;
                           var8[var13 + 1] = 13;
                           this.iFld = this.iFld;
                           continue;
                        case 99:
                           var7 -= 16890;
                           var4 = var6;
                           var3 = -14;
                           var6 -= (int)fFld;
                           continue;
                        default:
                           var8[var13 + 1] += var4;
                           var4 = (int)instanceCount;
                           instanceCount = -10L;
                           if (bFld) {
                              instanceCount -= instanceCount;
                              var8[var13] *= (int)fFld;
                              instanceCount %= (long)(var13 | 1);
                              var6 = (int)instanceCount;
                           }
                           continue;
                     }
                  case 47:
                     instanceCount += (long)var5 * instanceCount + (long)var4 - (long)var5;
                     break;
                  case 48:
                     fFld += (float)var6;
                     break;
                  case 49:
                  case 50:
                     var3 = var6 - (int)fFld;
                     break;
                  case 51:
                     this.iFld = this.sFld;
                     break;
                  default:
                     var3 = var6 * this.sFld;
               }
            }
         }
      }

      FuzzerUtils.out.println("i14 i15 d2 = " + var13 + "," + var3 + "," + Double.doubleToLongBits(var9));
      FuzzerUtils.out.println("i16 i17 i18 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i19 lArr fArr = " + var7 + "," + FuzzerUtils.checkSum(var11) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)));
      FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(var8));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld sFld Test.byArrFld = " + (bFld ? 1 : 0) + "," + this.sFld + "," + FuzzerUtils.checkSum(byArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((byte[])byArrFld, (byte)20);
      fMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
