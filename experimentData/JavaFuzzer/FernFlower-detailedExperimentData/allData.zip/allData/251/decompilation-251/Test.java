public class Test {
   public static final int N = 400;
   public static long instanceCount = -23926L;
   public static volatile double dFld = 0.8183;
   public static boolean bFld = false;
   public static short sFld = 17403;
   public static int[] iArrFld = new int[400];
   public static int[][] iArrFld1 = new int[400][400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, byte var1) {
      boolean var2 = true;
      int var3 = -46686;
      byte var4 = 5;
      int[] var5 = new int[400];
      float var6 = -90.327F;
      boolean var7 = false;
      double var8 = -2.36019;
      FuzzerUtils.init((int[])var5, (int)197);
      byte var10 = 1;
      var0 *= var0;
      var5[var10] <<= -121;
      var6 += (float)var10;
      var3 = 1;

      while(!var7) {
         var0 += 21 + var3 * var3;
         instanceCount += (long)(var3 * var3);
         var6 -= (float)var0;
         ++var3;
         if (var3 >= 10) {
            break;
         }
      }

      var0 <<= var0;
      vMeth2_check_sum += (long)(var3 + var1 + var10 + Float.floatToIntBits(var6) + var3 + (var7 ? 1 : 0) + var4) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var5);
   }

   public static void vMeth1(float var0, int var1, long var2) {
      boolean var4 = true;
      int var5 = 48179;
      short var6 = -2634;
      byte var7 = 11;
      int[] var8 = new int[400];
      byte var9 = 67;
      FuzzerUtils.init(var8, -44532);
      int var10 = 1;

      while(true) {
         ++var10;
         if (var10 >= 294) {
            vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var1) + var2 + (long)var10 + (long)var9 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
            return;
         }

         if (var10 != 0) {
            vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var1) + var2 + (long)var10 + (long)var9 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
            return;
         }

         if (var10 != 0) {
            vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var1) + var2 + (long)var10 + (long)var9 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
            return;
         }

         vMeth2(var1, var9);
         var1 -= (int)dFld;
         var5 = 1;

         while(true) {
            var6 = 1;
            if (var6 < 1) {
               var1 = var10;
               dFld = (double)var10;
               var2 = (long)((float)var2 + ((float)(var6 * var5 + var5) - var0));
            }

            ++var5;
            if (var5 >= 6) {
               break;
            }
         }
      }
   }

   public static void vMeth(int var0) {
      float var1 = -1.482F;
      int var2 = -3;
      int var3 = 2;
      long[] var4 = new long[400];
      FuzzerUtils.init(var4, -21294L);
      vMeth1(var1, var0, instanceCount);
      instanceCount -= instanceCount;
      var0 = 1889396016;
      int[] var5 = iArrFld;
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         int var8 = var5[var7];
         var8 >>= 14;
         dFld = (double)instanceCount;
         dFld += (double)var8;

         for(var2 = 1; var2 < 4; ++var2) {
            if (bFld) {
               var8 -= (int)dFld;
               var0 = (int)((long)var0 + ((long)var2 | (long)var1));
               var4[var2 + 1] *= (long)var2;
               int[] var10000 = iArrFld;
               var10000[var2] += (int)dFld;
            } else {
               var3 = var0;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var2 + var3) + FuzzerUtils.checkSum(var4);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -14;
      int var4 = -39188;
      int var5 = -11;
      int var6 = 63507;
      int var7 = -239;
      double var8 = -110.39228;
      long[] var10 = new long[400];
      float[] var11 = new float[400];
      FuzzerUtils.init(var10, -63188L);
      FuzzerUtils.init(var11, -1.97F);

      int[] var10000;
      int var15;
      for(var15 = 9; var15 < 292; ++var15) {
         vMeth(22804);
         if (bFld) {
            break;
         }

         var3 >>= -16641;
         if (bFld) {
            var3 <<= var3;
            var10000 = iArrFld1[var15];
            var10000[var15 + 1] &= var15;
            instanceCount *= (long)var3;
         } else {
            try {
               var3 = 'ꐛ' / var15;
               var3 = var15 / iArrFld[var15];
               var3 = '깁' % iArrFld1[var15][var15];
            } catch (ArithmeticException var14) {
            }

            var3 += 29333 + var15 * var15;
            instanceCount = 3466816774L;
            sFld += (short)(var15 * var15);
         }
      }

      for(var8 = 1.0; var8 < 216.0; ++var8) {
         var10[(int)(var8 - 1.0)] = -6215L;
         var5 = 1;

         do {
            byte var16 = 14;
            var3 = var16 * (int)dFld;
            var4 *= var5;

            for(var6 = 1; var6 < 1; ++var6) {
               var3 = (int)var8;
               var11[(int)var8] = (float)var8;
               switch (var5 % 7 * 5 + 16) {
                  case 22:
                     instanceCount = (long)var5;
                     break;
                  case 23:
                     var7 = var15 + var4;
                     bFld = bFld;
                     break;
                  case 27:
                     var7 += -2 + var6 * var6;
                     break;
                  case 37:
                     try {
                        var4 = iArrFld1[var5 + 1][(int)(var8 + 1.0)] % 116;
                        var3 /= var7;
                        var4 = 255 / var6;
                     } catch (ArithmeticException var13) {
                     }

                     var7 += var6 * var6;
                     break;
                  case 42:
                     var10000 = iArrFld1[var5 - 1];
                     var10000[var6 - 1] *= var5;
                     break;
                  case 50:
                     var7 = var15;
                     break;
                  case 51:
                     var3 <<= 27719;
                     var4 = var3;
                     break;
                  default:
                     instanceCount -= (long)var5;
               }
            }

            ++var5;
         } while(var5 < 117);
      }

      FuzzerUtils.out.println("i i1 d1 = " + var15 + "," + var3 + "," + Double.doubleToLongBits(var8));
      FuzzerUtils.out.println("i15 i16 i17 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i18 lArr1 fArr = " + var7 + "," + FuzzerUtils.checkSum(var10) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.sFld Test.iArrFld Test.iArrFld1 = " + sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-717);
      FuzzerUtils.init((int[][])iArrFld1, (int)39606);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
