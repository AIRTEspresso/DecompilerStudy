public class Test {
   public static final int N = 400;
   public static long instanceCount = -2548559245571105894L;
   public volatile float fFld = 0.247F;
   public static float fFld1 = 52.1023F;
   public static volatile long lFld = -13L;
   public long lFld1 = -252L;
   public static int[][] iArrFld = new int[400][400];
   public static volatile long[][] lArrFld = new long[400][400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static int iMeth(int var0, boolean var1, int var2) {
      float var3 = -12.784F;
      short var4 = -221;
      int var5 = 1;
      int var6 = -50464;
      instanceCount |= (long)Math.abs(var2--);

      for(var3 = 292.0F; 18.0F < var3; --var3) {
         for(var5 = 6; var5 > 1; --var5) {
            int[] var10000 = iArrFld[(int)(var3 + 1.0F)];
            var10000[var5] -= (int)instanceCount;
         }
      }

      long var7 = (long)(var0 + (var1 ? 1 : 0) + var2 + Float.floatToIntBits(var3) + var4 + var5 + var6);
      iMeth_check_sum += var7;
      return (int)var7;
   }

   public static void vMeth2(float var0, long var1) {
      boolean var3 = true;
      int var4 = -8861;
      int var5 = -11554;
      int var6 = -11;
      int var7 = 5;
      int var8 = -8;
      int var9 = -50961;
      double var10 = 0.114156;
      boolean var12 = false;
      boolean var13 = false;

      int var14;
      for(var14 = 11; var14 < 363; ++var14) {
         var4 = (int)var10;
         var10 += (double)instanceCount;
         var5 = 1;

         int[] var10000;
         do {
            for(var6 = 1; var14 < var6; var6 -= 2) {
               var10000 = iArrFld[var5 - 1];
               var10000[var6 + 1] += 14;
               var4 = var6;
               var7 = var6;
            }

            ++var5;
         } while(var5 < 5);

         var10 = (double)var1;
         var12 = var13;
         var7 = (int)((long)var7 + ((long)var14 | instanceCount));

         for(var8 = 5; var8 > 1; --var8) {
            var1 -= (long)var4;
            var4 -= (int)var0;
            var10000 = iArrFld[var14 - 1];
            var10000[var8 - 1] *= var6;
         }
      }

      vMeth2_check_sum += (long)Float.floatToIntBits(var0) + var1 + (long)var14 + (long)var4 + Double.doubleToLongBits(var10) + (long)var5 + (long)var6 + (long)var7 + (long)(var12 ? 1 : 0) + (long)(var13 ? 1 : 0) + (long)var8 + (long)var9;
   }

   public static void vMeth1() {
      int var0 = -43282;
      int var1 = -11;
      int var2 = 33817;
      int var3 = 206;
      int var4 = -21;
      short var5 = -27158;
      boolean[] var6 = new boolean[400];
      float[] var7 = new float[400];
      double[] var8 = new double[400];
      FuzzerUtils.init(var6, true);
      FuzzerUtils.init(var7, -1.732F);
      FuzzerUtils.init(var8, 1.4055);
      vMeth2(fFld1, instanceCount);

      for(var0 = 2; var0 < 197; ++var0) {
         try {
            var1 = -35744 / var0;
            int var10000 = var0 % iArrFld[var0][var0 - 1];
            var1 = -478950232 % iArrFld[var0][var0 + 1];
         } catch (ArithmeticException var11) {
         }

         for(var2 = var0; var2 < 8; ++var2) {
            long[] var12 = lArrFld[var2 - 1];
            var12[var2 - 1] -= (long)var5;
         }

         if (var1 != 0) {
            vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var5 + var4) + FuzzerUtils.checkSum(var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
            return;
         }

         var3 = var5;
         switch ((var1 >>> 1) % 10 + 82) {
            case 82:
               var3 = var2;
               switch ((var2 >>> 1) % 10 * 5 + 20) {
                  case 24:
                     instanceCount *= (long)fFld1;
                     var6[var0] = false;
                     break;
                  case 28:
                     var7[var0 - 1] = (float)instanceCount;
                     break;
                  case 42:
                     var1 -= 1762287415;
                     break;
                  case 51:
                     var3 = var1;
                     break;
                  case 61:
                  default:
                     var3 = var2 + (var0 ^ var2);
                     break;
                  case 63:
                     var5 = (short)(var5 >>> 7);
                  case 47:
                     var1 |= var5;
                  case 45:
                     fFld1 *= (float)var1;
                     break;
                  case 65:
                     var1 += var0;
                     instanceCount += (long)(-13856 + var0 * var0);
                     var1 += var2;
                  case 39:
                     var1 <<= var1;
               }
            case 83:
               var8[var0] = (double)var3;
            case 84:
               if (var1 != 0) {
                  vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var5 + var4) + FuzzerUtils.checkSum(var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
                  return;
               }
               break;
            case 85:
               var3 = var0;
               break;
            case 86:
               var4 = -10;
               break;
            case 87:
            case 88:
               fFld1 += 2.52465971E9F;
               break;
            case 89:
               try {
                  var3 = iArrFld[var0 - 1][var0 + 1] % var2;
                  iArrFld[var0 + 1][var0] = '댢' / var1;
                  var4 = var0 % -1804673463;
               } catch (ArithmeticException var10) {
               }
               break;
            case 90:
               var1 >>= var5;
               break;
            case 91:
               var1 *= (int)fFld1;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var5 + var4) + FuzzerUtils.checkSum(var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = 11;
      boolean var2 = true;
      int var3 = 50095;
      short var4 = 27996;
      int[] var5 = new int[400];
      float var6 = -1.341F;
      double var7 = -2.60442;
      long[][] var9 = new long[400][400];
      boolean[] var10 = new boolean[400];
      FuzzerUtils.init(var9, -138L);
      FuzzerUtils.init((int[])var5, (int)-9);
      FuzzerUtils.init(var10, false);

      int var13;
      for(var13 = 19; var13 < 335; ++var13) {
         float var10000 = (float)instanceCount;
         long[] var10002 = var9[var13];
         long var10005 = var9[var13][var13];
         var10002[var13] = var9[var13][var13] - 1L;
         var1 = (int)(var10000 - (var6 - (float)var10005));

         try {
            var1 = var13 % var1;
            var5[var13] = var1 / 1;
            var1 %= var1;
         } catch (ArithmeticException var12) {
         }

         var1 -= iMeth((int)((long)var13 + instanceCount / (long)(var13 | 1)), var10[var13 + 1], -(var1--));
         vMeth1();
         instanceCount *= (long)var13;
         short var15 = 199;
         var1 = var15 * var15;
         var7 += (double)var13;
      }

      int var14 = 1;

      while(true) {
         var14 += 2;
         if (var14 >= 350) {
            vMeth_check_sum += (long)(var13 + var1 + Float.floatToIntBits(var6)) + Double.doubleToLongBits(var7) + (long)var14 + (long)var3 + (long)var4 + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var10);
            return;
         }

         for(var3 = 1; var3 < 9; ++var3) {
            var1 -= var3;
            instanceCount += -15974L;
            var1 <<= (int)instanceCount;
            var1 -= (int)instanceCount;
         }
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = 0;
      int var5 = 27922;
      int var6 = -53;
      int var7 = 203;
      int var8 = 5445;
      boolean var9 = false;
      boolean[] var10 = new boolean[400];
      double var11 = -2.9433;
      byte var13 = 64;
      short var14 = -13347;
      FuzzerUtils.init(var10, false);
      byte var15 = 1;

      int var16;
      for(var16 = 3; var16 < 381; ++var16) {
         for(var5 = 1; var5 < 2; ++var5) {
            this.fFld += (float)var5 - this.fFld;
            this.fFld += (float)((long)var5 + instanceCount);
            if (var9) {
               break;
            }

            var9 = var10[var16] = var9;
         }

         vMeth();

         for(var7 = var15; var7 < 2; ++var7) {
            var11 = (double)var13;
            this.fFld += (float)var7;
            int[] var10000 = iArrFld[var15 - 1];
            var10000[var7 + 1] %= var6 | 1;
            int var17;
            switch (var16 % 4 * 5 + 73) {
               case 77:
                  lFld = (long)((float)lFld + ((float)var7 * fFld1 + (float)var8 - (float)this.lFld1));
                  break;
               case 81:
                  if (!var9) {
                     var17 = var4 + var15;
                     var10000 = iArrFld[var7 + 1];
                     var10000[var16 + 1] ^= var16;
                  }
                  break;
               case 84:
                  var8 <<= (int)instanceCount;
                  var17 = var4 + var7;
                  break;
               case 92:
                  var8 >>= var13;
                  var10000 = iArrFld[var16 - 1];
                  var10000[var15] *= 1910181863;
                  break;
               default:
                  var9 = var9;
                  var6 = var14;
            }

            var6 += var16;
            var10[var7 + 1] = var9;
            var8 -= var5;
            var4 = (int)instanceCount;
         }

         fFld1 *= 32.0F;
      }

      FuzzerUtils.out.println("i i1 i2 = " + var15 + "," + var16 + "," + var4);
      FuzzerUtils.out.println("i3 i4 b = " + var5 + "," + var6 + "," + (var9 ? 1 : 0));
      FuzzerUtils.out.println("i27 i28 d2 = " + var7 + "," + var8 + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("by s1 bArr = " + var13 + "," + var14 + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("Test.instanceCount fFld Test.fFld1 = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Float.floatToIntBits(fFld1));
      FuzzerUtils.out.println("Test.lFld lFld1 Test.iArrFld = " + lFld + "," + this.lFld1 + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[][])iArrFld, (int)-166);
      FuzzerUtils.init(lArrFld, -95L);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
