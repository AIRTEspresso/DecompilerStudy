public class Test {
   public static final int N = 400;
   public static long instanceCount = 46856L;
   public boolean bFld = false;
   public static int iFld = 126;
   public float fFld = 0.737F;
   public static boolean[] bArrFld = new boolean[400];
   public static long[] lArrFld = new long[400];
   public static long bMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(float var0, int var1) {
      boolean var2 = true;
      int var3 = 157;
      int var4 = 4;
      int var5 = 10926;
      int var6 = -3;
      int[] var7 = new int[400];
      byte var8 = -111;
      boolean var9 = true;
      long var10 = -9132390761175264722L;
      long[] var12 = new long[400];
      FuzzerUtils.init((int[])var7, (int)-10);
      FuzzerUtils.init(var12, 30797L);
      bArrFld = bArrFld;

      int var16;
      for(var16 = 13; var16 < 211; ++var16) {
         try {
            var1 = -49647 % var16;
            var3 = var16 % -110;
            var1 = -116 % var16;
         } catch (ArithmeticException var15) {
         }

         for(var4 = 1; var4 < 8; ++var4) {
            var6 = 1;

            do {
               var7[var6] *= var8;
               instanceCount *= (long)var0;
               var12[var16] = (long)var6;
               var5 >>>= var8;
               var7[var4 - 1] = var5;
               if (var9) {
                  break;
               }

               var1 &= -148;
               var5 -= var6;
               instanceCount += (long)var6 | var10;
               var5 >>>= 100275026;
               ++var6;
            } while(var6 < 2);
         }
      }

      long var13 = (long)(Float.floatToIntBits(var0) + var1 + var16 + var3 + var4 + var5 + var6 + var8 + (var9 ? 1 : 0)) + var10 + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var12);
      iMeth_check_sum += var13;
      return (int)var13;
   }

   public static void vMeth(int var0, short var1) {
      float var2 = 1.823F;
      long var3 = 4L;
      int var5 = 7;
      int var6 = 62;
      int var7 = 25090;
      int var8 = 34;
      byte var9 = -13;
      int[] var10 = new int[400];
      boolean var11 = true;
      byte var12 = -51;
      FuzzerUtils.init((int[])var10, (int)-3);
      var0 += Integer.reverseBytes((int)((long)var0 * instanceCount - instanceCount));
      var1 = (short)iMeth(var2, var0);
      var0 = 8;

      for(var3 = 7L; var3 < 253L && !var11; ++var3) {
         var5 >>= var5;
         var1 += (short)((int)(var3 * var3));
         var0 >>= (int)var3;

         for(var6 = (int)var3; 7 > var6; ++var6) {
            var10[(int)var3] *= var12;
            if (!var11) {
               var2 += (float)var6;

               for(var8 = 1; var8 > 1 && !var11; --var8) {
                  var7 ^= 9674;
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2)) + var3 + (long)var5 + (long)(var11 ? 1 : 0) + (long)var6 + (long)var7 + (long)var12 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
   }

   public boolean bMeth(float var1, int var2, int var3) {
      short var4 = 21130;
      int var5 = -4;
      boolean var6 = true;
      short var7 = -217;
      int var8 = 46094;
      int var9 = 10;
      int[] var10 = new int[400];
      byte var11 = 6;
      long[] var12 = new long[400];
      FuzzerUtils.init((int[])var10, (int)-119);
      FuzzerUtils.init(var12, 369598138L);
      vMeth(33, var4);
      var10[(var5 >>> 1) % 400] = 208;
      var5 += (int)instanceCount;

      int var16;
      for(var16 = 130; var16 > 6; var16 -= 3) {
         var12[var16] -= (long)var4;

         for(var8 = var16; var8 < 37; ++var8) {
            byte var15 = -2;
            var10[var16] += iFld;
            var9 <<= var16;
            var12[var16 - 1] = (long)var16;
            var2 = (int)((long)var15 + ((long)var8 * instanceCount + (long)var3 - (long)var15));
            var2 += var8 ^ var9;
         }

         var12[var16] = (long)var11;
      }

      long var13 = (long)(Float.floatToIntBits(var1) + var2 + var3 + var4 + var5 + var16 + var7 + var8 + var9 + var11) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var12);
      bMeth_check_sum += var13;
      return var13 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -208;
      int var4 = -11;
      int var5 = -10;
      int var6 = 2;
      short var7 = -221;
      int var8 = 18005;
      int var9 = -11;
      int[] var10 = new int[400];
      float var11 = -119.337F;
      double var12 = -2.93573;
      double[] var14 = new double[400];
      short var15 = -369;
      FuzzerUtils.init(var14, -121.49904);
      FuzzerUtils.init((int[])var10, (int)4);
      this.bFld = this.bMeth(this.fFld, iFld, iFld);
      this.fFld %= (float)(iFld | 1);

      int var16;
      label75:
      for(var16 = 13; var16 < 220; ++var16) {
         var3 -= 4564;
         if (this.bFld) {
            switch (var16 % 8 + 80) {
               case 80:
                  for(var11 = (float)var16; var11 < 121.0F; ++var11) {
                     var3 &= 15193;
                     var4 += (int)var11;
                     var4 -= var3;
                     this.bFld = this.bFld;
                  }

                  var14[var16 + 1] = (double)iFld;
                  var4 += (int)instanceCount;
                  var10[var16 + 1] >>= var3;
                  break;
               case 81:
                  for(var12 = 6.0; var12 < 121.0; ++var12) {
                     iFld -= 248;
                  }

                  var10[var16] = iFld;
                  var6 = var16;

                  while(true) {
                     if (var6 >= 121) {
                        continue label75;
                     }

                     this.fFld = (float)instanceCount;

                     for(var8 = 1; var8 < 1; ++var8) {
                        switch (var8 % 1 + 65) {
                           case 65:
                              instanceCount = (long)this.fFld;
                              var10[var8] -= (int)instanceCount;
                        }

                        if (this.bFld) {
                           break;
                        }

                        instanceCount *= -1L;
                        var3 -= (int)instanceCount;
                        var3 = var9;
                        var5 = (int)((float)var5 + ((float)var8 * var11 + (float)var6 - (float)var15));
                        var9 = -59481;
                        var10[var8] += var6;
                     }

                     ++var6;
                  }
               case 82:
                  long[] var10000 = lArrFld;
                  var10000[var16 + 1] += (long)var11;
                  break;
               case 83:
                  this.fFld += (float)var16;
                  break;
               case 84:
                  var3 = iFld;
               case 85:
                  var10[var16 + 1] += 6763;
                  break;
               case 86:
                  var10[var16 - 1] = (int)this.fFld;
                  break;
               case 87:
                  this.fFld = (float)instanceCount;
            }
         }
      }

      FuzzerUtils.out.println("i19 i20 f3 = " + var16 + "," + var3 + "," + Float.floatToIntBits(var11));
      FuzzerUtils.out.println("i21 d i22 = " + var4 + "," + Double.doubleToLongBits(var12) + "," + var5);
      FuzzerUtils.out.println("i23 i24 i25 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i26 s2 dArr = " + var9 + "," + var15 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)));
      FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("Test.instanceCount bFld Test.iFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + iFld);
      FuzzerUtils.out.println("fFld Test.bArrFld Test.lArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(bArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(bArrFld, false);
      FuzzerUtils.init(lArrFld, 6620249178618566476L);
      bMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
