public class Test {
   public static final int N = 400;
   public static long instanceCount = 12L;
   public static float fFld = 0.935F;
   public static int iFld = -55522;
   public byte byFld = 55;
   public static volatile boolean bFld = true;
   public static double dFld = 0.80005;
   public int iFld1 = -48997;
   public long[] lArrFld = new long[400];
   public double[] dArrFld = new double[400];
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth2_check_sum;

   public void vMeth1() {
      float var1 = -75.997F;
      int var2 = -236;
      int[] var3 = new int[400];
      double[] var4 = new double[400];
      FuzzerUtils.init((int[])var3, (int)2127);
      FuzzerUtils.init(var4, 26.43003);
      iFld ^= (int)((float)this.byFld - (--fFld + (float)(instanceCount * instanceCount)));

      for(var1 = 291.0F; var1 > 13.0F; --var1) {
         var2 = 54663;
         this.lArrFld[(int)(var1 + 1.0F)] = (long)var3[(int)var1] * -40101L;
         double var10000 = (double)(--instanceCount);
         int var10002 = (int)var1;
         double var10004 = var4[(int)var1];
         var4[var10002] = var4[(int)var1] - 1.0;
         if (var10000 != var10004) {
         }
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var1) + var2) + FuzzerUtils.checkSum(var3) + Double.doubleToLongBits(FuzzerUtils.checkSum(var4));
   }

   public static void vMeth2(int var0, int var1) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = -52445;
      int var5 = -89;
      int var6 = -47524;
      short var7 = 23965;
      boolean[] var8 = new boolean[400];
      FuzzerUtils.init(var8, true);
      int[] var10000 = iArrFld;
      var10000[(var1 >>> 1) % 400] -= iFld;
      int var9 = 1;

      int var10;
      do {
         instanceCount += (long)(-115 + var9 * var9);
         var8[var9 - 1] = true;

         for(var10 = 5; var10 > 1; var10 -= 2) {
            bFld = bFld;
            var4 *= var9;

            for(var5 = 3; var5 > 1; --var5) {
               var4 *= (int)fFld;
               iFld -= var0;
               var0 -= var4;
               var1 += 23144;
            }

            var6 += var10 * var4 + var1 - var7;
            var1 += var10;
         }

         ++var9;
      } while(var9 < 370);

      vMeth2_check_sum += (long)(var0 + var1 + var9 + var10 + var4 + var5 + var6 + var7) + FuzzerUtils.checkSum(var8);
   }

   public static int iMeth(float var0, int var1, double var2) {
      int var4 = 11;
      int var5 = -38628;
      int var6 = -36;
      int var7 = 19;
      int var8 = 21786;
      short var9 = -14824;
      short var10 = 24200;
      vMeth2(var1, var1);
      iFld += var1;
      var1 = iFld;
      instanceCount = -3821629553L;

      try {
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 308) {
               break;
            }

            iFld += (int)instanceCount;
            instanceCount += (long)(var4 * var4);
            iArrFld = iArrFld;

            for(var5 = 1; var5 < 5; var5 += 3) {
               var10 += (short)(var5 * var6 + var1 - var4);

               for(var7 = 1; var7 < 5; ++var7) {
                  iFld += -1523203516;

                  try {
                     var8 = iArrFld[var5 - 1] % -17280;
                     iFld = var8 % var4;
                     var1 = var7 / var9;
                  } catch (ArithmeticException var13) {
                  }

                  var6 += (int)(19.23F + (float)(var7 * var7));
               }
            }
         }
      } catch (NullPointerException var14) {
         var6 = var6;
      }

      long var11 = (long)(Float.floatToIntBits(var0) + var1) + Double.doubleToLongBits(var2) + (long)var4 + (long)var5 + (long)var6 + (long)var10 + (long)var7 + (long)var8 + (long)var9;
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public void vMeth(int var1, long var2) {
      boolean var4 = true;
      int var5 = -70;
      boolean var6 = true;
      short var7 = 2508;
      int var8 = -229;
      int var9 = -53809;
      int[] var10 = new int[400];
      double var11 = -108.45439;
      float[] var13 = new float[400];
      FuzzerUtils.init(var13, 0.855F);
      FuzzerUtils.init((int[])var10, (int)0);

      int var14;
      for(var14 = 20; var14 < 372; ++var14) {
         float var10000 = fFld;
         long var10001 = ++instanceCount;
         --var1;
         fFld = var10000 + (float)Math.max(var10001, (long)(223 * var1));
         fFld += (float)Math.min(var1, -57273) + ++var13[var14 - 1] + (float)((long)(var5--) / ((long)((float)var2 + fFld) | 1L));
         this.vMeth1();
         var2 &= (long)var10[(iFld >>> 1) % 400];
         var5 += (int)((float)Math.abs(Long.reverseBytes(instanceCount)) - Math.abs((float)(-7.0 - this.dArrFld[var14])));
      }

      ++var5;
      var1 >>= (int)((long)var5 - instanceCount-- * (long)iMeth(fFld, var14, dFld));
      var5 -= (int)fFld;
      var1 -= var14;

      int var15;
      for(var15 = 187; 11 < var15; --var15) {
         var11 = 1.0;

         while(++var11 < 9.0) {
            var2 = 0L;

            for(var8 = 1; 1 > var8; ++var8) {
               iFld += var8 * var8 + this.iFld1 - var7;
               var13 = FuzzerUtils.float1array(400, 42.755F);
            }
         }
      }

      vMeth_check_sum += (long)var1 + var2 + (long)var14 + (long)var5 + (long)var15 + (long)var7 + Double.doubleToLongBits(var11) + (long)var8 + (long)var9 + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)) + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -5;
      int var4 = 183;
      int var5 = -20111;
      int var6 = 4;
      short var7 = -15424;
      float var8 = 39.995F;
      this.vMeth(iFld, instanceCount);
      this.iFld1 += iFld;
      int var16 = 1;

      while(true) {
         ++var16;
         long[] var10000;
         if (var16 >= 287) {
            int[] var9 = iArrFld;
            int var10 = var9.length;

            for(int var11 = 0; var11 < var10; ++var11) {
               int var12 = var9[var11];

               for(var3 = 1; var3 < 63; var3 += 3) {
                  var4 += var3 ^ var12;

                  for(var8 = 1.0F; var8 < 4.0F; ++var8) {
                     iArrFld[(int)var8] = 1167285468;
                     iArrFld[(int)var8] = (int)instanceCount;
                     instanceCount += (long)var5;
                     instanceCount += (long)(var8 * (float)var12 + (float)iFld - (float)this.iFld1);
                     this.iFld1 += -6;
                     this.iFld1 <<= var3;
                  }

                  dFld = (double)var4;

                  try {
                     var12 = var5 % -50283;
                     iArrFld[var3] = -104 / var12;
                     var4 /= var3;
                  } catch (ArithmeticException var15) {
                  }

                  var6 = 1;

                  while(true) {
                     ++var6;
                     if (var6 >= 4) {
                        var4 -= (int)fFld;
                        var4 += var3 + var5;
                        var10000 = this.lArrFld;
                        var10000[var3 + 1] -= (long)var4;
                        var5 += var6;
                        var5 *= var12;
                        break;
                     }

                     var5 = -133;
                     instanceCount = (long)var3;
                     var7 = (short)var4;

                     try {
                        iFld = -120 / iArrFld[var6];
                        iArrFld[var6] = 842860189 / iArrFld[var3];
                        this.iFld1 = iArrFld[var6 - 1] % var16;
                     } catch (ArithmeticException var14) {
                     }

                     var4 = var16;
                  }
               }
            }

            FuzzerUtils.out.println("i22 s2 i24 = " + var16 + "," + var7 + "," + var3);
            FuzzerUtils.out.println("i25 f2 i26 = " + var4 + "," + Float.floatToIntBits(var8) + "," + var5);
            FuzzerUtils.out.println("i27 = " + var6);
            FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
            FuzzerUtils.out.println("byFld Test.bFld Test.dFld = " + this.byFld + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
            FuzzerUtils.out.println("iFld1 lArrFld dArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(this.lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
            FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         iArrFld[var16 - 1] = iFld;
         this.iFld1 = var7;
         var10000 = this.lArrFld;
         var10000[var16] &= -3L;
         iArrFld[var16] = var16;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-166);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
