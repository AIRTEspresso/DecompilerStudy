public class Test {
   public static final int N = 400;
   public static long instanceCount = 5830344760535448422L;
   public static byte byFld = -9;
   public static boolean bFld = true;
   public static int[] iArrFld = new int[400];
   public long[] lArrFld = new long[400];
   public float[] fArrFld = new float[400];
   public static long vSmallMeth_check_sum;
   public static long iMeth_check_sum;
   public static long bMeth_check_sum;

   public static void vSmallMeth(int var0) {
      var0 += var0;
      vSmallMeth_check_sum += (long)var0;
   }

   public static boolean bMeth(long var0) {
      int var2 = -2;
      byte var3 = 23;
      boolean var4 = true;
      short var5 = 25343;
      boolean var6 = true;
      int var7 = 13358;
      int[] var8 = new int[400];
      double var9 = 0.118501;
      short var11 = 18177;
      FuzzerUtils.init((int[])var8, (int)-12127);
      vSmallMeth(var2);

      for(var9 = 145.0; 3.0 < var9; --var9) {
         var2 += (int)var9;
         var2 += (int)var9;
         var2 -= 47;
         instanceCount = (long)var3;
         var8[(int)var9] |= var2;
      }

      int var14;
      for(var14 = 9; var14 < 190; ++var14) {
         ++instanceCount;
      }

      int var15;
      for(var15 = 8; var15 < 201; ++var15) {
         var8[var15] += (int)var0;
         var7 += (int)var0;
         var8[var15 + 1] += var11;
         var2 *= var5;
         var7 *= var7;
      }

      long var12 = var0 + (long)var2 + Double.doubleToLongBits(var9) + (long)var3 + (long)var14 + (long)var5 + (long)var15 + (long)var7 + (long)var11 + FuzzerUtils.checkSum(var8);
      bMeth_check_sum += var12;
      return var12 % 2L > 0L;
   }

   public static int iMeth(int var0, short var1) {
      boolean var2 = true;
      int var3 = 84;
      int var4 = -29841;
      int var5 = 21852;
      int var6 = -64578;
      int var7 = 220;
      int var8 = 11;
      int var9 = -16757;
      double var10 = -26.1473;
      bMeth(3489460398L);

      int var15;
      for(var15 = 18; var15 < 297; ++var15) {
         var4 = 1;

         while(true) {
            ++var4;
            int[] var10000;
            if (var4 >= 6) {
               var10 += (double)var1;

               for(var7 = 1; var7 < 6; ++var7) {
                  try {
                     var8 = 'ꬲ' / var0;
                     var8 = 221 / var3;
                     var3 = var15 % -1167312081;
                  } catch (ArithmeticException var14) {
                  }

                  var9 = 1;

                  do {
                     instanceCount = -13269L;
                     ++var9;
                  } while(var9 < 2);

                  var10000 = iArrFld;
                  var10000[var7 + 1] >>>= var8;
                  var0 -= var7;
               }
               break;
            }

            for(var5 = 1; var5 < 1; var5 += 3) {
               var3 += (int)instanceCount;
               var10000 = iArrFld;
               var10000[var15 - 1] |= var6;
               var3 = -14;
            }

            var6 += (int)(2441361569086449615L + (long)(var4 * var4));
         }
      }

      long var12 = (long)(var0 + var1 + var15 + var3 + var4 + var5 + var6) + Double.doubleToLongBits(var10) + (long)var7 + (long)var8 + (long)var9;
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void mainTest(String[] var1) {
      int var2 = 159;
      boolean var3 = true;
      int var4 = 52873;
      boolean var5 = true;
      int var6 = 6933;
      int var7 = 1;
      int var8 = -70;
      byte var9 = -14;
      int var10 = -3;
      short var11 = 189;
      float var12 = 0.335F;
      double var13 = -2.24006;
      byte[] var15 = new byte[400];
      short[] var16 = new short[400];
      FuzzerUtils.init((byte[])var15, (byte)50);
      FuzzerUtils.init(var16, (short)-17221);

      for(int var17 = 0; var17 < 990; ++var17) {
         --var2;
         vSmallMeth(var2 - Math.min((int)((float)var2 - 82.367F), iMeth(0, (short)23964)));
      }

      var12 += -1.737F;
      var13 *= (double)var2;
      instanceCount = instanceCount;

      int var18;
      for(var18 = 237; var18 > 9; --var18) {
         instanceCount = (long)var18;
         var2 = (int)((long)var2 + ((long)var18 * instanceCount + (long)var18 - (long)byFld));
         instanceCount *= instanceCount;
      }

      int var19;
      label63:
      for(var19 = 10; var19 < 199; ++var19) {
         var12 *= 126.468F;
         instanceCount += (long)(var19 + var6);
         if (!bFld) {
            switch ((var18 >>> 1) % 5 + 56) {
               case 56:
                  var7 = 1;

                  while(true) {
                     ++var7;
                     if (var7 >= 133) {
                        var10 = 133;

                        while(true) {
                           if (var10 <= 6) {
                              continue label63;
                           }

                           var15[var19] += (byte)var10;
                           var4 -= (int)instanceCount;
                           --var10;
                        }
                     }

                     switch (var19 % 2 + 49) {
                        case 49:
                           this.lArrFld[var19 + 1] = (long)var4;
                           bFld = bFld;
                           var13 -= (double)var12;
                           var12 += (float)(var7 * var7);
                           break;
                        case 50:
                           var6 -= var6;
                           var4 *= -65242;
                           float[] var10000 = this.fArrFld;
                           var10000[var19] += (float)var13;
                           var4 -= var2;
                     }

                     var12 -= (float)var18;

                     for(var8 = 1; var8 < 1; ++var8) {
                        var4 = 15119;
                     }

                     var2 <<= var4;
                  }
               case 57:
               case 58:
                  var13 += 9.0;
                  break;
               case 59:
                  var16[var19] = (short)var19;
                  break;
               case 60:
                  var2 = byFld;
                  break;
               default:
                  instanceCount += (long)var8;
            }
         }
      }

      FuzzerUtils.out.println("i1 f d2 = " + var2 + "," + Float.floatToIntBits(var12) + "," + Double.doubleToLongBits(var13));
      FuzzerUtils.out.println("i17 i18 i19 = " + var18 + "," + var4 + "," + var19);
      FuzzerUtils.out.println("i20 i21 i22 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i23 i24 i25 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("byArr sArr = " + FuzzerUtils.checkSum(var15) + "," + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.bFld = " + instanceCount + "," + byFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.iArrFld lArrFld fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-112);
      vSmallMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      bMeth_check_sum = 0L;
   }
}
