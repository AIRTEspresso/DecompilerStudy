public class Test {
   public static final int N = 400;
   public static long instanceCount = -3864190133524760347L;
   public int iFld = -15;
   public static float fFld = -39.414F;
   public static boolean bFld = true;
   public static short sFld = 19145;
   public long lFld = 111L;
   public double dFld = -98.128087;
   public double dFld1 = 47.86497;
   public byte byFld = -63;
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long dMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, int var2) {
      int var3;
      byte var4;
      short var5;
      int var6;
      short var7;
      double var8;
      double[] var10;
      float var11;
      byte var12;
      long[] var13;
      var3 = -16036;
      var4 = 14;
      var5 = 150;
      var6 = -184;
      var7 = -23629;
      var8 = -1.56213;
      var10 = new double[400];
      var11 = 70.671F;
      var12 = 22;
      var13 = new long[400];
      FuzzerUtils.init(var10, 0.20585);
      FuzzerUtils.init(var13, -3063671024401328456L);
      label40:
      switch ((var1 >>> 1) % 4 + 47) {
         case 47:
            var3 = 6;

            while(true) {
               if (138 <= var3) {
                  break label40;
               }

               char var14 = '놌';
               fFld -= (float)var0;
               var8 += (double)var1;
               if (var3 != 0) {
                  vMeth1_check_sum += (long)(var0 + var1 + var14 + var3 + var4) + Double.doubleToLongBits(var8) + (long)Float.floatToIntBits(var11) + (long)var5 + (long)var6 + (long)var7 + (long)var12 + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var13);
                  return;
               }

               int var10000 = var14 * var3;
               var8 += (double)instanceCount;
               byte var15 = 12;
               var2 = var15 + var3 * var3;

               for(var11 = 1.0F; var11 < 12.0F; ++var11) {
                  bFld = bFld;

                  for(var6 = 1; var6 < 2; ++var6) {
                     var12 = var12;
                     instanceCount += (long)(var6 * var1 + var1 - var6);
                  }
               }

               ++var3;
            }
         case 48:
            var0 >>= 203;
            break;
         case 49:
            instanceCount = (long)var3;
         case 50:
            var10[(var1 >>> 1) % 400] = (double)instanceCount;
         default:
            var13[0] = (long)var1;
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var8) + (long)Float.floatToIntBits(var11) + (long)var5 + (long)var6 + (long)var7 + (long)var12 + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var13);
   }

   public double dMeth(float var1, long var2, long var4) {
      boolean var6 = false;
      long var7 = -1047996405L;
      byte var9 = -101;
      int[] var10 = new int[400];
      FuzzerUtils.init((int[])var10, (int)-134);
      this.iFld >>= (int)(++var4);
      vMeth1(-14, this.iFld, this.iFld);
      var7 = 1L;

      while(++var7 < 157L) {
         double var11 = -39.67477;
         lArrFld[(int)var7] = (long)this.iFld;
         switch (65) {
            case 61:
               var10[(int)(var7 + 1L)] += var9;
               sFld += (short)((int)(var7 + (long)sFld));
               var4 *= (long)this.iFld;
               break;
            case 62:
               this.iFld *= (int)var11;
               this.iFld *= this.iFld;
            case 63:
               lArrFld[(int)(var7 - 1L)] = (long)this.iFld;
               this.iFld = this.iFld;
               this.iFld += (int)(var7 ^ (long)this.iFld);
               break;
            case 64:
               this.iFld <<= this.iFld;
            case 65:
               instanceCount |= (long)this.iFld;
               break;
            case 66:
               this.iFld = 5;
         }
      }

      long var13 = (long)Float.floatToIntBits(var1) + var2 + var4 + (long)(var6 ? 1 : 0) + var7 + (long)var9 + FuzzerUtils.checkSum(var10);
      dMeth_check_sum += var13;
      return (double)var13;
   }

   public void vMeth() {
      boolean var1 = true;
      byte var2 = -3;
      int var3 = -49;
      short var4 = 16630;
      int var5 = -118;
      int var6 = 149;
      int[] var7 = new int[400];
      double[] var8 = new double[400];
      FuzzerUtils.init((int[])var7, (int)12);
      FuzzerUtils.init(var8, -2.27171);
      this.iFld = (int)(-this.dMeth(fFld, -5515384168490525178L, 1144697354L) - (double)this.iFld);
      this.lFld -= (long)fFld;
      this.dFld = (double)this.iFld;

      int var9;
      for(var9 = 7; 327 > var9; ++var9) {
         var2 = 80;
         var7[var9] -= (int)this.lFld;
         this.iFld >>= this.iFld;
         fFld = (float)this.iFld;
         switch (var9 % 2 * 5 + 119) {
            case 125:
               var6 |= -7;
               break;
            case 129:
               for(var3 = 1; var3 < 5; ++var3) {
                  for(var5 = 2; var5 > var3; --var5) {
                     var6 >>>= (int)instanceCount;
                     this.lFld &= (long)var2;
                  }
               }

               lArrFld[var9] = instanceCount;
               lArrFld = lArrFld;
               break;
            default:
               var8[var9 - 1] -= 71.0;
         }
      }

      vMeth_check_sum += (long)(var9 + var2 + var3 + var4 + var5 + var6) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 6;
      int var4 = 164;
      int var5 = -11;
      int var6 = 4361;
      int var7 = -37518;
      int var8 = 1;
      byte var9 = 8;
      int[] var10 = new int[400];
      long var11 = 3207255790L;
      float[] var13 = new float[400];
      FuzzerUtils.init((int[])var10, (int)-29101);
      FuzzerUtils.init(var13, 0.187F);
      this.vMeth();
      sFld = 180;
      var10 = var10;
      int var10001 = (this.iFld >>> 1) % 400;
      var13[var10001] -= (float)this.iFld;

      int var14;
      for(var14 = 4; var14 < 196; ++var14) {
         this.dFld1 += this.dFld;

         for(var4 = 8; var4 < 131; ++var4) {
            this.iFld += -12089 + var4 * var4;
            this.byFld ^= (byte)var5;
            this.iFld += var4;
            this.iFld = this.iFld;
            var5 *= this.iFld;

            for(var6 = 1; var6 < 2; ++var6) {
               var7 = var3;
               this.dFld1 = (double)this.lFld;
               var10[var4] = (int)instanceCount;
               var5 += var14;
               this.lFld >>= -31433;
               instanceCount = 96L;
               sFld += (short)var6;
               this.lFld += var11;
               var5 += var3;
               fFld += (float)var6 * fFld + (float)var5 - (float)var14;
            }

            var7 += var7;
            var3 += '륮' + var4 * var4;
            if (!bFld) {
               for(var8 = 1; 2 > var8; ++var8) {
                  instanceCount -= (long)var3;
                  var10[var14 + 1] += var7;
               }
            }
         }
      }

      FuzzerUtils.out.println("i14 i15 i16 = " + var14 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i17 i18 i19 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("l3 i20 i21 = " + var11 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("iArr2 fArr = " + FuzzerUtils.checkSum(var10) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld Test.sFld lFld = " + (bFld ? 1 : 0) + "," + sFld + "," + this.lFld);
      FuzzerUtils.out.println("dFld dFld1 byFld = " + Double.doubleToLongBits(this.dFld) + "," + Double.doubleToLongBits(this.dFld1) + "," + this.byFld);
      FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 5185700968123384073L);
      vMeth_check_sum = 0L;
      dMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
