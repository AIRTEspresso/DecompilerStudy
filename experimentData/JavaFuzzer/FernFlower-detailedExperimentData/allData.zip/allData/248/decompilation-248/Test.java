public class Test {
   public static final int N = 400;
   public static long instanceCount = 1L;
   public static float fFld = -2.495F;
   public static boolean bFld = false;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static short[] sArrFld = new short[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(short var0) {
      int var1;
      byte var2;
      int var3;
      int var4;
      int var5;
      int var6;
      int var7;
      double var8;
      double var10;
      long var12;
      float[] var14;
      var1 = 26171;
      var2 = -11;
      var3 = -34839;
      var4 = 238;
      var5 = -164;
      var6 = -132;
      var7 = -60640;
      var8 = 0.13735;
      var10 = 1.75463;
      var12 = -10L;
      var14 = new float[400];
      FuzzerUtils.init(var14, 0.1003F);
      label58:
      switch ((var1 >>> 1) % 7 + 34) {
         case 34:
            for(var8 = 4.0; var8 < 163.0; ++var8) {
               var1 += (int)(var8 * (double)var1 + (double)var1 - (double)instanceCount);
               var12 = 1L;

               do {
                  var14 = var14;
                  instanceCount = var12;
               } while(++var12 < 10L);

               int[] var10000 = iArrFld;
               var10000[(int)(var8 - 1.0)] += var2;
               var1 *= var2;
            }

            var10 = 7.0;

            while(true) {
               if (!(var10 < 286.0)) {
                  break label58;
               }

               var4 = 1;

               do {
                  for(var5 = 1; 1 > var5; var5 += 3) {
                     var6 *= var2;
                     if (var4 != 0) {
                     }

                     instanceCount <<= var6;
                     if (var1 != 0) {
                     }
                  }

                  ++var4;
               } while(var4 < 6);

               ++var10;
            }
         case 35:
            fFld += (float)var12;
            break;
         case 36:
            var1 = (int)var12;
            break;
         case 37:
            var3 = 1151735093;
         case 38:
            var1 *= var3;
            break;
         case 39:
            var7 += var3;
            break;
         case 40:
            fFld += (float)var1;
      }

      long var15 = (long)(var0 + var1) + Double.doubleToLongBits(var8) + (long)var2 + var12 + Double.doubleToLongBits(var10) + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + Double.doubleToLongBits(FuzzerUtils.checkSum(var14));
      iMeth1_check_sum += var15;
      return (int)var15;
   }

   public static void vMeth() {
      int var0 = -40514;
      int var1 = 52449;
      int var2 = -250;
      int var3 = -73;
      int var4 = -1747;
      int var5 = -239;
      short var6 = 27274;
      double var7 = -1.1404;
      boolean var9 = false;

      for(var0 = 3; var0 < 183; ++var0) {
         fFld = (float)(iMeth1((short)8120) * var0);
         var1 &= var6;
         var1 += var0 * var1;
         int[] var10000 = iArrFld;
         var10000[var0] ^= (int)instanceCount;

         for(var2 = 1; var2 < 9; ++var2) {
            var10000 = iArrFld;
            var10000[var2 - 1] >>>= var0;

            for(var4 = 1; var4 < 2; ++var4) {
               var7 = var7;
               if (var9) {
                  break;
               }

               var7 += -4319.0;
               var3 = (int)((float)var3 + (float)var4 * fFld);
            }
         }

         try {
            var1 = -26247 / var1;
            iArrFld[var0 + 1] = -177 / var0;
            var1 = var3 / iArrFld[var0 + 1];
         } catch (ArithmeticException var11) {
         }

         var1 += var0;
         var5 += var0 * var4 + var5 - var1;
      }

      vMeth_check_sum += (long)(var0 + var1 + var6 + var2 + var3 + var4 + var5) + Double.doubleToLongBits(var7) + (long)(var9 ? 1 : 0);
   }

   public static int iMeth(int var0, long var1, int var3) {
      boolean var4 = true;
      int var5 = 21705;
      int var6 = 82;
      byte var7 = -66;
      byte var8 = -11;
      long var9 = -16066L;
      double var11 = -2.98944;
      double[] var13 = new double[400];
      FuzzerUtils.init(var13, 66.57911);
      vMeth();

      int var16;
      for(var16 = 8; 259 > var16; var16 += 3) {
         instanceCount += (long)(var16 * var3 + var3 - var3);
         var1 += (long)(var16 * var16);
         fFld += (float)var16;

         for(var6 = 1; 19 > var6; ++var6) {
            var5 *= var0;
            instanceCount += (long)(var6 * var6);
            long[] var10000 = lArrFld;
            var10000[var6] += (long)var3;
            var1 = (long)var7;

            for(var9 = 1L; 2L > var9; ++var9) {
               short var14 = 17592;
               var3 = var14;
               var11 = (double)var8;
               fFld = (float)var7;
               var13[var6 + 1] = (double)var6;
            }
         }
      }

      long var17 = (long)var0 + var1 + (long)var3 + (long)var16 + (long)var5 + (long)var6 + (long)var7 + var9 + (long)var8 + Double.doubleToLongBits(var11) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
      iMeth_check_sum += var17;
      return (int)var17;
   }

   public void mainTest(String[] var1) {
      int var2 = -41463;
      boolean var3 = true;
      boolean var4 = true;
      short var5 = 135;
      int var6 = -116;
      int var7 = -13;
      byte var8 = 58;
      int var9 = -2;
      double var10 = -2.14807;
      byte var12 = 54;
      short var13 = -10059;
      var2 *= iMeth(var2, instanceCount, var2) - var2;
      var2 = var2;
      int var14 = 282;

      while(true) {
         --var14;
         if (var14 <= 0) {
            int var15;
            label59:
            for(var15 = 6; var15 < 178; ++var15) {
               instanceCount *= instanceCount;
               var6 = 1;

               while(true) {
                  label54:
                  while(true) {
                     ++var6;
                     if (var6 >= 146) {
                        continue label59;
                     }

                     for(var7 = 1; var7 < 1; ++var7) {
                        fFld += (float)((long)var7 * instanceCount);
                        if (!bFld) {
                           int var10000 = var8 * (int)var10;
                           var5 = var12;
                           instanceCount += (long)(var7 * var7);
                        }
                     }

                     var13 = (short)(var13 - 48);
                     instanceCount = (long)var2;
                     instanceCount = (long)var15;
                     switch ((var8 >>> 1) % 5 * 5 + 20) {
                        case 21:
                           instanceCount += (long)(var6 * var12);
                           break;
                        case 26:
                           fFld += 66.0F;
                           fFld = fFld;
                           var13 += (short)var6;
                           var9 = 1;

                           while(true) {
                              short[] var16 = sArrFld;
                              var16[var15] |= (short)((int)instanceCount);
                              int[] var17 = iArrFld;
                              var17[var15 + 1] += var2;
                              var17 = iArrFld;
                              var17[var15] *= 150;
                              instanceCount -= (long)var12;
                              ++var9;
                              if (var9 >= 1) {
                                 continue label54;
                              }
                           }
                        case 31:
                           instanceCount += (long)(var6 * var6);
                           break;
                        case 37:
                        case 38:
                           var12 -= var12;
                           fFld -= (float)var8;
                           var2 = var7;
                     }
                  }
               }
            }

            FuzzerUtils.out.println("i i22 i23 = " + var2 + "," + var14 + "," + var15);
            FuzzerUtils.out.println("i24 i25 i26 = " + var5 + "," + var6 + "," + var7);
            FuzzerUtils.out.println("i27 d4 by = " + var8 + "," + Double.doubleToLongBits(var10) + "," + var12);
            FuzzerUtils.out.println("s3 i28 = " + var13 + "," + var9);
            FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
            FuzzerUtils.out.println("Test.iArrFld Test.lArrFld Test.sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
            FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            return;
         }

         var2 -= (int)instanceCount;
         fFld += (float)((long)var14 * instanceCount + (long)var2 - instanceCount);
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-8275);
      FuzzerUtils.init(lArrFld, -4028306867L);
      FuzzerUtils.init(sArrFld, (short)-15163);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
