public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 2877520852L;
   public float fFld = 1.642F;
   public static int iFld = 26114;
   public byte byFld = -62;
   public static volatile long[] lArrFld = new long[400];
   public static short[] sArrFld = new short[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1) {
      short var2 = -13243;
      int var3 = 52806;
      short var4 = -142;
      int[] var5 = new int[400];
      int[] var6 = new int[400];
      boolean var7 = true;
      double var8 = 0.121;
      long[] var10 = new long[400];
      FuzzerUtils.init((int[])var5, (int)-77);
      FuzzerUtils.init((int[])var6, (int)-20489);
      FuzzerUtils.init(var10, 6561997257802867438L);
      var2 = (short)(var2 - 2);
      var1 >>= var0;

      for(var3 = 200; var3 > 6; --var3) {
         instanceCount = -9L;
         if (var7) {
            break;
         }

         var8 = 1.0;

         do {
            var5[var3 - 1] = 6;
            instanceCount += (long)var8;
            instanceCount *= instanceCount;
            var1 -= 174;
            var6[var3 + 1] >>= 4;
            instanceCount >>= var3;
            --var5[(int)(var8 + 1.0)];
            var10[(int)var8] += -23891L;
            var0 -= var3;
         } while(++var8 < 8.0);
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + (var7 ? 1 : 0)) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var10);
   }

   public static void vMeth(int var0, int var1) {
      double var2 = 116.22305;
      double var4 = 26.94027;
      double[] var6 = new double[400];
      byte var7 = 10;
      int var8 = -53309;
      int var9 = -20;
      int var10 = 10;
      int[][] var11 = new int[400][400];
      float var12 = 10.96F;
      float[][][] var13 = new float[400][400][400];
      FuzzerUtils.init((int[][])var11, (int)81);
      FuzzerUtils.init((Object[][])var13, -1.349F);
      FuzzerUtils.init(var6, 5.110394);

      for(var2 = 5.0; var2 < 149.0; ++var2) {
         vMeth1(var1, var0);

         for(var8 = 1; 11 > var8; ++var8) {
            var10 = 1;

            do {
               instanceCount |= (long)var10;
               ++var10;
            } while(var10 < 2);

            var4 -= (double)var8;
            var12 = (float)var1;
            var9 = 54417;
            var11[var8][(int)(var2 - 1.0)] >>= var1;
         }
      }

      var12 = 111.0F;
      instanceCount = (long)var8;
      var13[(var7 >>> 1) % 400][(var9 >>> 1) % 400][(var0 >>> 1) % 400] = -42614.0F;
      var1 = iFld;
      var9 = (int)instanceCount;
      iFld = var9;
      vMeth_check_sum += (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var7 + (long)var8 + (long)var9 + (long)var10 + Double.doubleToLongBits(var4) + (long)Float.floatToIntBits(var12) + FuzzerUtils.checkSum(var11) + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var13)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var6));
   }

   public static int iMeth(float var0, int var1, int var2) {
      boolean var3 = true;
      short var4 = 644;
      int var5 = -65049;
      int var6 = 172;
      int var7 = 9;
      int[] var8 = new int[400];
      double var9 = 2.117393;
      FuzzerUtils.init((int[])var8, (int)57977);

      int var13;
      for(var13 = 5; 333 > var13; ++var13) {
         var2 -= var2 - Math.max((int)(instanceCount - 7343052530477782916L), (int)((float)instanceCount - var0));
         var1 *= (int)((double)((long)var2 + (long)var4 + instanceCount) * (var9 *= (double)((long)var4 + instanceCount)));
         vMeth(iFld, var2);
         var9 -= -8510.0;
         var5 = 5;

         do {
            for(var6 = var5; var6 < 1; ++var6) {
               instanceCount &= instanceCount;
               var8[var6 + 1] -= iFld;
               long[] var10000 = lArrFld;
               var10000[var6 - 1] -= (long)var4;
               instanceCount = -14484L;
               var0 = (float)var2;
               var7 >>= var5;
               var0 += (float)('퀦' + var6 * var6);
            }

            --var5;
         } while(var5 > 0);

         var2 -= var5;
      }

      long var11 = (long)(Float.floatToIntBits(var0) + var1 + var2 + var13 + var4) + Double.doubleToLongBits(var9) + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public void mainTest(String[] var1) {
      int var2 = 64914;
      int var3 = 62731;
      int var4 = 6;
      int var5 = -179;
      int var6 = 1;
      int[] var7 = new int[400];
      double var8 = -90.12598;
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, -1.525F);
      FuzzerUtils.init((int[])var7, (int)4124);

      for(var2 = 12; var2 < 374; ++var2) {
         var10[var2 + 1] -= -4.11633954E18F;
         var3 = (int)((float)(var3++) - (float)var2 * this.fFld + (float)Long.reverseBytes(instanceCount));
         switch (var2 % 2 * 5 + 28) {
            case 34:
               var3 >>>= (int)(Math.abs(++this.fFld) % (float)(iMeth(-79.489F, var3, -12623) + var2 | 1));
               switch (var2 % 8 + 103) {
                  case 103:
                     var3 <<= iFld;
                     break;
                  case 104:
                  case 105:
                     for(var4 = 2; var4 < 70; ++var4) {
                        var7[var2 + 1] += var3;
                        var5 <<= var5;
                     }

                     this.byFld -= (byte)var5;
                     this.byFld >>= (byte)var3;
                     var7[var2 - 1] *= (int)this.fFld;
                     break;
                  case 106:
                     var5 = 13;
                     this.fFld = (float)var3;
                     var7[var2] += var5;
                     break;
                  case 107:
                     long[] var12 = lArrFld;
                     var12[var2] += (long)var5;
                     var8 = (double)var5;
                     var5 += var2 * var2;
                     var5 %= var5 | 1;
                     break;
                  case 108:
                     iFld >>= 155;
                  case 109:
                     var5 = (int)instanceCount;
                     var3 &= iFld;
                     break;
                  case 110:
                     this.fFld += (float)var5;
                     short[] var11 = sArrFld;
                     var11[var2] -= (short)var2;
               }

               var7 = var7;
               var6 = 1;

               do {
                  var10[var6 + 1] = (float)instanceCount;
                  iFld += var3;
                  ++var6;
               } while(var6 < 70);
               break;
            case 37:
               instanceCount += (long)var2;
         }
      }

      FuzzerUtils.out.println("i i1 i19 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i20 d5 i21 = " + var5 + "," + Double.doubleToLongBits(var8) + "," + var6);
      FuzzerUtils.out.println("fArr iArr4 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + "," + FuzzerUtils.checkSum(var7));
      FuzzerUtils.out.println("Test.instanceCount fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + iFld);
      FuzzerUtils.out.println("byFld Test.lArrFld Test.sArrFld = " + this.byFld + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 9L);
      FuzzerUtils.init((short[])sArrFld, (short)22098);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
