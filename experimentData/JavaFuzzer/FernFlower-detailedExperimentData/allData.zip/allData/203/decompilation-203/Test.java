public class Test {
   public static final int N = 400;
   public static long instanceCount = -6729139300331859853L;
   public static volatile boolean bFld = false;
   public volatile long[] lArrFld = new long[400];
   public static long fMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(int var0, long var1, int var3) {
      boolean var4 = true;
      byte var5 = -1;
      boolean var6 = false;
      boolean[][][] var7 = new boolean[400][400][400];
      float var8 = -85.332F;
      FuzzerUtils.init((Object[][])var7, true);

      int var9;
      for(var9 = 369; 16 < var9; var9 -= 3) {
         var0 <<= var5;
         var7[var9 + 1][var9][var9 - 1] = var6;
      }

      var8 += -2.66792F;
      var1 >>= var5;
      vMeth1_check_sum += (long)var0 + var1 + (long)var3 + (long)var9 + (long)var5 + (long)(var6 ? 1 : 0) + (long)Float.floatToIntBits(var8) + FuzzerUtils.checkSum((Object[][])var7);
   }

   public static void vMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      boolean var4 = true;
      int var5 = 12;
      int var6 = 8;
      int var7 = 0;
      byte var8 = 12;
      int[] var9 = new int[400];
      byte var10 = 57;
      float var11 = -46.459F;
      float[] var12 = new float[400];
      double var13 = 1.126533;
      FuzzerUtils.init(var9, -51677);
      FuzzerUtils.init(var12, -1.356F);
      int var15 = 1;

      int var16;
      do {
         label57:
         for(var16 = 1; var16 < 6; ++var16) {
            switch (var15 % 9 + 44) {
               case 44:
                  vMeth1(var2, instanceCount, -52);
                  var6 = 1;

                  while(true) {
                     if (var6 >= 2) {
                        continue label57;
                     }

                     instanceCount = (long)var5;
                     var1 += var6 | var6;
                     var9 = var9;
                     if (bFld) {
                        continue label57;
                     }

                     var7 = -1;
                     if (bFld) {
                        continue label57;
                     }

                     switch (var15 % 7 + 28) {
                        case 28:
                        case 29:
                           var5 >>>= (int)instanceCount;
                           var10 += (byte)((int)((long)var6 * instanceCount + instanceCount - (long)var16));
                           break;
                        case 30:
                           if (var15 != 0) {
                              vMeth_check_sum += (long)(var0 + var1 + var2 + var15 + var16 + var5 + var6 + var7 + var10 + Float.floatToIntBits(var11) + var8) + Double.doubleToLongBits(var13) + FuzzerUtils.checkSum(var9) + Double.doubleToLongBits(FuzzerUtils.checkSum(var12));
                              return;
                           }
                           break;
                        case 31:
                           instanceCount = (long)var1;
                        case 32:
                           var1 += 6;
                           break;
                        case 33:
                           var7 += (int)var11;
                           break;
                        case 34:
                           if (bFld) {
                           }
                     }

                     ++var6;
                  }
               case 45:
                  instanceCount += (long)(-20130 + var16 * var16);
                  break;
               case 46:
                  var2 -= var8;
               case 47:
                  var10 += (byte)((int)(-4L + (long)(var16 * var16)));
               case 48:
                  var12[var16] *= (float)var15;
                  break;
               case 49:
                  var0 += var16;
               case 50:
               case 51:
                  var5 *= (int)var13;
               case 52:
                  var5 -= (int)var11;
            }
         }

         ++var15;
      } while(var15 < 262);

      vMeth_check_sum += (long)(var0 + var1 + var2 + var15 + var16 + var5 + var6 + var7 + var10 + Float.floatToIntBits(var11) + var8) + Double.doubleToLongBits(var13) + FuzzerUtils.checkSum(var9) + Double.doubleToLongBits(FuzzerUtils.checkSum(var12));
   }

   public static float fMeth() {
      int var0 = 160;
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -7;
      float var4 = -35.358F;
      double var5 = 0.54138;
      long[] var7 = new long[400];
      FuzzerUtils.init(var7, -2522260819L);
      vMeth(-21017, var0, var0);
      int var10 = 1;

      int var11;
      do {
         for(var11 = 1; var11 < 5; ++var11) {
            if (bFld) {
               if (bFld) {
                  continue;
               }

               var3 += var11 ^ var0;
               var7[var11 + 1] -= (long)var11;
            } else if (bFld) {
               var3 = (int)instanceCount;
               if (bFld) {
                  break;
               }
            } else {
               var0 &= 5;
            }

            var7 = var7;
            var3 <<= var3;
            var0 = (int)instanceCount;
            var4 = (float)var3;
            var5 -= (double)instanceCount;
         }

         ++var10;
      } while(var10 < 354);

      long var8 = (long)(var0 + var10 + var11 + var3 + Float.floatToIntBits(var4)) + Double.doubleToLongBits(var5) + FuzzerUtils.checkSum(var7);
      fMeth_check_sum += var8;
      return (float)var8;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -231;
      boolean var4 = true;
      boolean var5 = true;
      int var6 = -142;
      int var7 = -7;
      byte var8 = 1;
      boolean var9 = true;
      byte var10 = 0;
      int var11 = 46508;
      short var12 = -176;
      int[] var13 = new int[400];
      double var14 = 125.61015;
      float var16 = 1.144F;
      float[] var17 = new float[400];
      boolean var18 = true;
      byte var19 = 11;
      FuzzerUtils.init((int[])var13, (int)-186);
      FuzzerUtils.init(var17, 1.519F);
      int var20 = 1;

      int var21;
      int var22;
      int var23;
      short var25;
      do {
         instanceCount ^= -80L;
         var13[var20 + 1] += (int)((double)((float)var20 - -127.0F * fMeth()) - var14);
         var16 += (float)(var20 * var20);
         var3 += var20;
         var21 = 1;

         do {
            this.lArrFld[var20 + 1] = (long)var3;
            var25 = (short)var21;
            var16 += -165.0F;
            var13[var21 - 1] = 40967;
            var3 = (int)((float)var3 + ((float)var21 * var16 + (float)var20 - (float)instanceCount));
            ++var21;
         } while(var21 < 174);

         instanceCount -= (long)var3;
         var3 = (int)var14;
         var16 = -4.3577936E8F;

         for(var22 = var20; 174 > var22; ++var22) {
            int var10000 = var6 + var22;
            var17[var22 + 1] = (float)var14;
            var6 = -62464;
            var16 += (float)var19;
            bFld = bFld;
            var13[var22 + 1] %= var21 | 1;

            for(var7 = 1; 1 > var7; ++var7) {
               var25 += (short)var7;
            }
         }

         for(var23 = 5; var23 < 174; ++var23) {
            var16 -= (float)var22;
         }

         ++var20;
      } while(var20 < 144);

      long[] var24 = this.lArrFld;
      var24[(var3 >>> 1) % 400] += (long)var23;

      for(var11 = 4; var11 < 247; ++var11) {
         var3 >>= (int)instanceCount;
         instanceCount *= (long)var14;
      }

      FuzzerUtils.out.println("i d2 f3 = " + var20 + "," + Double.doubleToLongBits(var14) + "," + Float.floatToIntBits(var16));
      FuzzerUtils.out.println("i18 i19 s = " + var3 + "," + var21 + "," + var25);
      FuzzerUtils.out.println("i21 i22 by1 = " + var22 + "," + var10 + "," + var19);
      FuzzerUtils.out.println("i23 i24 i25 = " + var7 + "," + var8 + "," + var23);
      FuzzerUtils.out.println("i26 i27 i28 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("iArr fArr1 = " + FuzzerUtils.checkSum(var13) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var17)));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld lArrFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
