public class Test {
   public static final int N = 400;
   public static long instanceCount = -7508667705143825334L;
   public static boolean bFld = false;
   public static float fFld = 0.493F;
   public static byte byFld = 122;
   public static volatile double dFld = -111.16741;
   public int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long[] lArrFld = new long[400];
   public volatile short[][] sArrFld = new short[400][400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long fMeth_check_sum;

   public static float fMeth(long var0, int var2) {
      double var3 = -1.8347;
      boolean var5 = true;
      int var6 = 1;
      int var7 = 5;
      byte var8 = 11;
      short var9 = 24803;
      var3 -= 2265.0;
      var2 = (int)var0;

      int var12;
      for(var12 = 10; var12 < 331; ++var12) {
         var2 *= var2;
         var9 = (short)((int)var0);
         lArrFld[var12] = (long)var12;
         var6 *= var6;
         if (!bFld) {
            for(var7 = 1; var7 < 5; ++var7) {
            }

            fFld -= (float)byFld;
            var6 = (int)fFld;
            var3 = (double)var8;
         }
      }

      bFld = bFld;
      long var10 = var0 + (long)var2 + Double.doubleToLongBits(var3) + (long)var12 + (long)var6 + (long)var9 + (long)var7 + (long)var8;
      fMeth_check_sum += var10;
      return (float)var10;
   }

   public static void vMeth(int var0) {
      int var1 = 35427;
      int var2 = 53006;
      int var3 = -19049;
      int var4 = 38056;
      int var5 = 3;
      int var6 = -60282;
      int var7 = -11;
      short var8 = 17629;
      boolean[] var9 = new boolean[400];
      FuzzerUtils.init(var9, false);
      var0 = (int)(fArrFld[(var0 >>> 1) % 400] + (float)(instanceCount * instanceCount) + fMeth(114L, var0));

      for(var1 = 7; var1 < 321; ++var1) {
         float[] var10000;
         for(var3 = var1; var3 < 5; ++var3) {
            var4 *= var3;
            var10000 = fArrFld;
            var10000[var1 - 1] -= -3.26008576E9F;
         }

         var10000 = fArrFld;
         var10000[var1 - 1] *= (float)var3;
         byFld += (byte)((int)((long)(var1 * var0) + instanceCount - (long)var3));

         for(var5 = 1; var5 < 5; ++var5) {
            var7 = 1;

            while(true) {
               ++var7;
               if (var7 >= 2) {
                  break;
               }

               var4 += var7 + var7;
               switch (var5 % 7 * 5 + 60) {
                  case 66:
                     dFld -= (double)var1;
                  case 67:
                  case 70:
                  case 71:
                  case 72:
                  case 73:
                  case 74:
                  case 76:
                  case 77:
                  case 78:
                  case 79:
                  case 81:
                  case 82:
                  case 83:
                  case 84:
                  case 85:
                  case 86:
                  default:
                     dFld -= -14.0;
                     break;
                  case 68:
                     fFld += -187.0F;
                     break;
                  case 69:
                     var2 = -1618743523;
                     break;
                  case 75:
                     var9[var7] = bFld;
                     break;
                  case 80:
                     var0 += (int)instanceCount;
                     break;
                  case 87:
                     if (!bFld) {
                        vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8) + FuzzerUtils.checkSum(var9);
                        return;
                     }
                     break;
                  case 88:
                     instanceCount <<= var7;
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8) + FuzzerUtils.checkSum(var9);
   }

   public static int iMeth(boolean var0, int var1, int var2) {
      boolean var3 = true;
      byte var4 = 4;
      int var5 = -132;
      int var6 = -1407;
      int[][][] var7 = new int[400][400][400];
      FuzzerUtils.init((Object[][])var7, -51563);
      vMeth(var1);
      float[] var8 = fArrFld;
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         float var10000 = var8[var10];
         dFld = (double)instanceCount;
         fFld -= (float)var2;
         instanceCount -= instanceCount;
         var2 = 0;
      }

      int var12;
      label44:
      for(var12 = 4; var12 < 392; ++var12) {
         var5 = 4;

         while(true) {
            while(true) {
               --var5;
               if (var5 <= 0) {
                  continue label44;
               }

               switch (6) {
                  case 4:
                  case 5:
                     fFld += (float)dFld;
                     break;
                  case 6:
                     var7[var12 - 1][var12 - 1][var5] = (int)instanceCount;
                     break;
                  case 7:
                     var6 = 1;

                     do {
                        var2 = var6;
                        var6 -= 3;
                     } while(var6 > 0);

                     var2 >>= 19737;
                     break;
                  default:
                     var7[var5][var12][var5 - 1] = 40945;
               }
            }
         }
      }

      long var13 = (long)((var0 ? 1 : 0) + var1 + var2 + var12 + var4 + var5 + var6) + FuzzerUtils.checkSum((Object[][])var7);
      iMeth_check_sum += var13;
      return (int)var13;
   }

   public void mainTest(String[] var1) {
      int var2 = -6;
      int var3 = 9;
      int var4 = 251;
      int var5 = -2;
      short var6 = -4;
      float var7 = 0.16F;
      long var8 = -3L;
      byte[] var10 = new byte[400];
      FuzzerUtils.init(var10, (byte)-101);
      int[] var10000 = this.iArrFld;
      var10000[43] >>= iMeth(bFld, var2, var2);
      long[] var15 = lArrFld;
      var15[5] += (long)var2;
      var2 += var2;
      int[] var11 = this.iArrFld;
      int var12 = var11.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         int var14 = var11[var13];

         for(var3 = 63; var3 > 1; var3 -= 2) {
            var14 %= var14 | 1;
            var14 -= 82;
            var10[var3 + 1] -= byFld;
            instanceCount *= (long)var4;

            for(var7 = 1.0F; var7 < 3.0F; ++var7) {
               var14 *= var5;
               var5 -= var3;
            }

            var8 = 1L;

            do {
               switch ((int)(var8 % 4L * 5L + 71L)) {
                  case 82:
                     var14 *= var6;
                     instanceCount = (long)var5;
                     fFld = -37624.0F;
                     break;
                  case 83:
                  case 86:
                  case 87:
                  case 88:
                  default:
                     instanceCount *= (long)var3;
                     break;
                  case 84:
                     if (bFld) {
                        var2 += (int)var8;
                        short[] var16 = this.sArrFld[(int)(var8 + 1L)];
                        var16[var3] *= (short)var3;
                        var2 += (int)var8;
                     }

                     var4 -= var3;
                     var15 = lArrFld;
                     var15[(int)var8] += (long)var3;
                     var6 = -191;
                     break;
                  case 85:
                     fFld += (float)var8;
                     break;
                  case 89:
                     var2 += (int)(var8 * var8);
                     var10000 = this.iArrFld;
                     var10000[(int)(var8 - 1L)] >>>= (int)var8;
                     var10000 = this.iArrFld;
                     var10000[var3 - 1] += var5;
               }
            } while(++var8 < 3L);
         }
      }

      FuzzerUtils.out.println("i20 i22 i23 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("f1 i24 l1 = " + Float.floatToIntBits(var7) + "," + var5 + "," + var8);
      FuzzerUtils.out.println("i25 byArr = " + var6 + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.byFld Test.dFld iArrFld = " + byFld + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("Test.fArrFld Test.lArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 111.209F);
      FuzzerUtils.init(lArrFld, -293861417053480438L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
   }
}
