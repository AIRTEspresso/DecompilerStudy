public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -12L;
   public static volatile double dFld = 34.38497;
   public static byte byFld = 19;
   public float fFld = -2.886F;
   public boolean bFld = false;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0) {
      int var1 = 42787;
      int var2 = -37618;
      int var3 = 19059;
      int var4 = -104;
      int var5 = -13;
      int var6 = 14;
      float var7 = -1.951F;
      short var8 = -30645;
      boolean var9 = false;

      for(var1 = 272; 16 < var1; --var1) {
         instanceCount = -5L;

         for(var3 = 6; var3 > 1; --var3) {
            boolean var10 = true;
            var4 = (int)var7;
            var4 += var3;
            if (!var9) {
               if (var9) {
                  break;
               }

               byte var11 = (byte)((int)instanceCount);
            } else {
               switch (var1 % 5 + 17) {
                  case 17:
                     var5 = 1;

                     do {
                        int[] var10000 = iArrFld;
                        var10000[var5] >>= var0;
                        var0 *= var0;
                        var4 *= -86;
                        var8 *= (short)((int)instanceCount);
                        ++var5;
                     } while(var5 < 2);
                  case 18:
                     var6 = (int)((float)var6 + ((float)(var3 * var0) + var7 - var7));
                     var2 += var3;
                     dFld -= dFld;
                     break;
                  case 19:
                     iArrFld[var1 - 1] = var1;
                     break;
                  case 20:
                     if (var9) {
                     }
                     break;
                  case 21:
                     var4 = var3;
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var7) + var5 + var8 + var6 + (var9 ? 1 : 0));
   }

   public static int iMeth1(long var0, int var2) {
      boolean var3 = true;
      byte var4 = 1;
      int[] var5 = new int[400];
      FuzzerUtils.init((int[])var5, (int)10);

      int var8;
      for(var8 = 3; var8 < 271; ++var8) {
         var5[var8 + 1] = (int)var0;
      }

      vMeth(-12);
      long var6 = var0 + (long)var2 + (long)var8 + (long)var4 + FuzzerUtils.checkSum(var5);
      iMeth1_check_sum += var6;
      return (int)var6;
   }

   public int iMeth(int var1) {
      boolean var2 = true;
      int var3 = 8;
      int var4 = -14;
      int var5 = 9025;
      int var6 = -17586;
      short var7 = 16351;

      int var11;
      for(var11 = 15; var11 < 281; ++var11) {
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 6) {
               break;
            }

            int var10000 = var3 + var4;
            var3 = iMeth1(instanceCount, var11);
            var3 += (int)instanceCount;

            for(var5 = var11; 1 > var5; ++var5) {
               var1 -= var1;

               try {
                  var3 = var11 % -704943244;
                  var1 = iArrFld[var11 + 1] % var11;
                  var3 = -1887 / iArrFld[var5 - 1];
               } catch (ArithmeticException var10) {
               }

               switch ((var1 >>> 1) % 2 + 111) {
                  case 111:
                     var6 = (int)instanceCount;
                     instanceCount = 78L;
                     var6 >>= 2089;
                     break;
                  case 112:
                     var7 -= (short)var4;
                     var3 += var3;
                     var1 -= (int)instanceCount;
                     break;
                  default:
                     int[] var12 = iArrFld;
                     var12[var4 - 1] -= var6;
               }
            }
         }
      }

      long var8 = (long)(var1 + var11 + var3 + var4 + var5 + var6 + var7);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      int var2 = 0;
      int var3 = 54052;
      int var4 = -107;
      int var5 = -3953;
      int var6 = -250;
      int var7 = 120;
      int var8 = -3;
      int var9 = 64501;
      int var10 = -4;
      int var11 = -27259;
      int[][] var12 = new int[400][400];
      long var13 = -2336875686245425543L;
      short var15 = -25689;
      double[] var16 = new double[400];
      FuzzerUtils.init((int[][])var12, (int)-10765);
      FuzzerUtils.init(var16, -91.75991);
      var12[7][(var2 >>> 1) % 400] = (int)(((long)var2 + instanceCount + (long)this.iMeth(var2)) * (long)byFld);
      this.fFld -= (float)var2;

      for(var3 = 3; var3 < 156; ++var3) {
         for(var13 = 8L; 164L > var13; ++var13) {
            var2 -= var15;
            var5 = var4;
            dFld *= -1.81981760497132646E18;
            var12[(int)(var13 + 1L)][(int)var13] *= (int)this.fFld;
            var12[var3 + 1][var3 - 1] *= -140;
         }

         for(var6 = 7; 164 > var6; ++var6) {
            this.fFld += (float)var2;
            var2 += 11 + var6 * var6;
         }

         dFld *= (double)var2;
         var4 = var4;

         for(var8 = 164; 10 < var8; --var8) {
            for(var10 = var8; var10 < 2; ++var10) {
               int[] var10000 = iArrFld;
               var10000[var3 - 1] += (int)var13;
               var2 += var10 * var10;
               var11 += -1 + var10 * var10;
               var9 -= (int)var13;
               var10000 = iArrFld;
               var10000[var3] += var5;
               var9 += 5;
            }

            this.bFld = this.bFld;
            switch (var8 % 2 + 111) {
               case 111:
                  var16[var8] = 0.0;
                  break;
               case 112:
                  var7 = (int)var13;
                  var9 += (int)(8149340305286956525L + (long)(var8 * var8));
                  var11 += var15;
            }

            var4 = (int)instanceCount;
            var7 = var5;
         }
      }

      FuzzerUtils.out.println("i i17 i18 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("l1 i19 s2 = " + var13 + "," + var5 + "," + var15);
      FuzzerUtils.out.println("i20 i21 i22 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i23 i24 i25 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("iArr dArr = " + FuzzerUtils.checkSum(var12) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var16)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
      FuzzerUtils.out.println("fFld bFld Test.iArrFld = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)92);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
