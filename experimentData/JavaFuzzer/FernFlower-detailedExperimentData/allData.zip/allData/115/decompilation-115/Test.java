public class Test {
   public static final int N = 400;
   public static long instanceCount = 8059626202638698049L;
   public static int iFld = -8;
   public static long iMeth_check_sum = 0L;
   public static long iMeth1_check_sum = 0L;
   public static long vMeth_check_sum = 0L;

   public static void vMeth() {
      boolean var0 = true;
      int var1 = 187;
      int var2 = 30724;
      int var3 = -132;
      byte var4 = -84;
      int[] var5 = new int[400];
      double var6 = 1.3044;
      long var8 = 143L;
      long[][][] var10 = new long[400][400][400];
      boolean var11 = false;
      byte var12 = 31;
      float[][] var13 = new float[400][400];
      FuzzerUtils.init((int[])var5, (int)52023);
      FuzzerUtils.init((Object[][])var10, -13L);
      FuzzerUtils.init(var13, 80.593F);

      int var14;
      for(var14 = 16; var14 < 396; ++var14) {
         var6 /= (double)(var14 | 1);

         for(var8 = 1L; var8 < 4L; ++var8) {
            var5 = var5;
            var1 += var1;
            var1 += (int)(var8 + (long)var14);
            if (!var11) {
               var1 += var1;
               var6 *= (double)var8;
               var12 += (byte)((int)(var8 * var8));
               var2 = var1;

               for(var3 = var14; var3 < 2; ++var3) {
                  long[] var10000 = var10[(iFld >>> 1) % 400][(int)(var8 - 1L)];
                  var10000[var14 - 1] >>>= var14;
                  var13[var3 + 1][var14 - 1] -= (float)var4;
                  if (var2 != 0) {
                     vMeth_check_sum += (long)(var14 + var1) + Double.doubleToLongBits(var6) + var8 + (long)var2 + (long)(var11 ? 1 : 0) + (long)var12 + (long)var3 + (long)var4 + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum((Object[][])var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
                     return;
                  }
               }
            }
         }
      }

      vMeth_check_sum += (long)(var14 + var1) + Double.doubleToLongBits(var6) + var8 + (long)var2 + (long)(var11 ? 1 : 0) + (long)var12 + (long)var3 + (long)var4 + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum((Object[][])var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
   }

   public static int iMeth1(int var0, float var1, int var2) {
      int var3 = 64194;
      int var4 = -4;
      int var5 = 135;
      int var6 = -4340;
      int var7 = 34616;
      int var8 = 3;
      int[] var9 = new int[400];
      boolean var10 = true;
      byte var11 = 123;
      double var12 = -40.90322;
      long[] var14 = new long[400];
      FuzzerUtils.init((int[])var9, (int)185);
      FuzzerUtils.init(var14, -13937L);

      for(var3 = 10; var3 < 385; ++var3) {
         instanceCount += (long)(var3 * var3);
         vMeth();

         for(var5 = var3; var5 < 5; ++var5) {
            switch ((var0 >>> 1) % 6 * 5 + 39) {
               case 52:
                  for(var7 = 1; var7 < 1; ++var7) {
                     var9[var5] = var4;
                     var14[var3] = instanceCount;
                     instanceCount += (long)iFld;
                     var2 = (int)instanceCount;
                     var6 += (int)var1;
                     var1 *= (float)instanceCount;
                  }

                  if (var10) {
                     var8 >>= (int)instanceCount;
                     var8 = (int)((long)var8 + ((long)var5 ^ instanceCount));
                  } else {
                     var0 = (int)((long)var0 + ((long)var5 * instanceCount + (long)var7 - (long)var3));
                  }
                  break;
               case 53:
               case 54:
               case 55:
               case 57:
               case 58:
               case 59:
               case 60:
               case 61:
               case 63:
               case 64:
               case 66:
               case 67:
               default:
                  var9[var3 - 1] = (int)var12;
                  break;
               case 56:
                  var12 = (double)var8;
                  break;
               case 62:
                  instanceCount = (long)var3;
                  break;
               case 65:
                  var4 <<= var5;
                  break;
               case 68:
                  iFld = (int)((long)iFld + ((long)(var5 * iFld) + instanceCount - (long)var4));
                  break;
               case 69:
                  var8 += var5 * var5;
            }
         }
      }

      long var15 = (long)(var0 + Float.floatToIntBits(var1) + var2 + var3 + var4 + var5 + var6 + var7 + var8 + (var10 ? 1 : 0) + var11) + Double.doubleToLongBits(var12) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var14);
      iMeth1_check_sum += var15;
      return (int)var15;
   }

   public static int iMeth() {
      boolean var0 = true;
      int var1 = 8;
      int var2 = -63556;
      int var3 = -63465;
      boolean var4 = false;
      short var5 = -141;
      byte var6 = -5;
      int[][] var7 = new int[400][400];
      float var8 = 110.576F;
      double var9 = 1.107505;
      FuzzerUtils.init((int[][])var7, (int)-215);
      iFld = (int)(++instanceCount);

      int var13;
      for(var13 = 141; var13 > 4; --var13) {
         iFld >>= Integer.reverseBytes(iMeth1(var13, -93.958F, iFld)) / 1;
      }

      for(var2 = 7; var2 < 267; ++var2) {
         char var14 = '\udd66';
         var1 = var14 >> 11;
      }

      int var15;
      for(var15 = 17; var15 < 320; ++var15) {
         iFld = var1;
         instanceCount -= (long)var8;

         for(var9 = (double)var15; var9 < 5.0; ++var9) {
            instanceCount = 15723L;
            iFld += (int)(var9 * var9);
            var7[var15][var15 - 1] *= var15;
            instanceCount = (long)iFld;
            var3 += iFld;
         }
      }

      long var11 = (long)(var13 + var1 + var2 + var3 + var15 + var5 + Float.floatToIntBits(var8)) + Double.doubleToLongBits(var9) + (long)var6 + FuzzerUtils.checkSum(var7);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 60363;
      int var4 = 228;
      int var5 = 18823;
      int var6 = -231;
      int var7 = 24658;
      int[] var8 = new int[400];
      byte var9 = -31;
      float var10 = 1.475F;
      double var11 = -102.797;
      boolean var13 = false;
      long[] var14 = new long[400];
      FuzzerUtils.init((int[])var8, (int)-7);
      FuzzerUtils.init(var14, -955183947397554756L);

      int var15;
      label76:
      for(var15 = 9; 201 > var15; ++var15) {
         var4 = 1;

         while(true) {
            while(true) {
               label57:
               while(true) {
                  ++var4;
                  if (var4 >= 131) {
                     continue label76;
                  }

                  var3 = (int)((double)var9 + ((double)(var8[var15] = (int)var10) - (var11 + -11.16715)));

                  for(var5 = 1; var5 > 1; var5 -= 3) {
                     var10 += (float)(-140 + var5 * var5);
                     var6 |= (int)instanceCount;
                     var8[var4 - 1] = (int)(--instanceCount);
                     instanceCount = (long)(var11 - 76.0);
                     var6 = (int)((long)var6 + ((long)(var5 * var4) + instanceCount - (long)var15));
                     var3 = iMeth();
                  }

                  iFld += iFld;
                  var3 = (int)((long)var3 + ((long)(var4 * iFld) + instanceCount - (long)var5));
                  switch ((var6 >>> 1) % 2 + 45) {
                     case 45:
                        var8[var15] *= (int)instanceCount;
                        break;
                     case 46:
                        var8[var15 - 1] += var6;
                        switch ((var6 >>> 1) % 6 * 5 + 60) {
                           case 63:
                           default:
                              continue;
                           case 66:
                              var3 = (int)((long)var3 + ((long)var4 ^ instanceCount));
                              continue;
                           case 69:
                              iFld = var6;
                              continue;
                           case 73:
                              var10 += (float)var11;
                              if (var13) {
                                 var7 = 1;

                                 while(true) {
                                    ++var7;
                                    if (var7 >= 1) {
                                       continue label57;
                                    }

                                    var6 -= 2;
                                    switch (var15 % 5 + 111) {
                                       case 111:
                                          var3 += var7;
                                          instanceCount = (long)var3;
                                       case 112:
                                          var14[var4] = (long)var5;
                                          var8[var7] -= var6;
                                          break;
                                       case 113:
                                          instanceCount -= instanceCount;
                                          break;
                                       case 114:
                                          instanceCount = (long)var6;
                                       case 115:
                                          var11 = (double)var5;
                                    }
                                 }
                              }

                              var3 <<= var5;
                              continue;
                           case 87:
                              var6 = var5;
                              continue;
                           case 88:
                              var8[var15 + 1] = 66;
                              continue;
                        }
                     default:
                        var8[var15] -= -37483;
                  }
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("by f d = " + var9 + "," + Float.floatToIntBits(var10) + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("i3 i4 i25 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("b2 iArr lArr2 = " + (var13 ? 1 : 0) + "," + FuzzerUtils.checkSum(var8) + "," + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld = " + instanceCount + "," + iFld);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
