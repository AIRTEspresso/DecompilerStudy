public class Test {
   public static final int N = 400;
   public static long instanceCount = 42421L;
   public static boolean bFld = false;
   public static byte byFld = -86;
   public static double dFld = 48.119739;
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(long var0, int var2, long var3) {
      boolean var5 = true;
      byte var6 = 6;
      int var7 = -64675;
      int var8 = -51026;
      byte var9 = 7;
      int var10 = -104;
      int var11 = -13;
      int[] var12 = new int[400];
      double var13 = -1.9785;
      boolean var15 = true;
      FuzzerUtils.init((int[])var12, (int)57286);

      int var16;
      for(var16 = 10; var16 < 293; ++var16) {
         var2 = var16;
         if (var16 != 0) {
            vMeth2_check_sum += var0 + (long)var16 + var3 + (long)var16 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(var13) + (long)var9 + (long)var10 + (long)var11 + (long)(var15 ? 1 : 0) + FuzzerUtils.checkSum(var12);
            return;
         }

         long[] var10000 = lArrFld;
         var10000[var16] |= instanceCount;

         for(var7 = var16; var7 < 6; ++var7) {
            var0 = (long)var7;
            var12[var7 - 1] -= -20;
            var12[var16] -= -11370;
            if (var6 != 0) {
               vMeth2_check_sum += var0 + (long)var2 + var3 + (long)var16 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(var13) + (long)var9 + (long)var10 + (long)var11 + (long)(var15 ? 1 : 0) + FuzzerUtils.checkSum(var12);
               return;
            }

            instanceCount += (long)(var7 * var6 + var2) - var3;
            var2 = (int)var3;
         }

         for(var13 = 1.0; var13 < 6.0; ++var13) {
            for(var10 = 1; var10 < 2; ++var10) {
               var11 -= 29455;
               var15 = false;
            }
         }
      }

      vMeth2_check_sum += var0 + (long)var2 + var3 + (long)var16 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(var13) + (long)var9 + (long)var10 + (long)var11 + (long)(var15 ? 1 : 0) + FuzzerUtils.checkSum(var12);
   }

   public static void vMeth1(double var0, int var2, double var3) {
      double var5 = -104.51921;
      int var7 = -3;
      int var8 = -23382;
      int var9 = -11;
      int var10 = 20;
      byte var11 = -6;
      int[][] var12 = new int[400][400];
      FuzzerUtils.init((int[][])var12, (int)-5);
      vMeth2(instanceCount, var2, instanceCount);

      label51:
      for(var5 = 8.0; var5 < 195.0; ++var5) {
         var8 = 1;

         while(true) {
            label46:
            while(true) {
               ++var8;
               if (var8 >= 9) {
                  continue label51;
               }

               var7 += var8;
               switch ((var2 >>> 1) % 8 * 5 + 76) {
                  case 83:
                     try {
                        var2 = var12[(var7 >>> 1) % 400][(int)(var5 - 1.0)] % var7;
                        var7 = var2 % 495600166;
                        var2 = var9 % 203;
                     } catch (ArithmeticException var15) {
                     }
                  case 111:
                     var12[(int)(var5 - 1.0)][(int)(var5 + 1.0)] += (int)var5;
                  case 84:
                  case 85:
                  case 86:
                  case 87:
                  case 88:
                  case 91:
                  case 92:
                  case 93:
                  case 94:
                  case 96:
                  case 97:
                  case 98:
                  case 99:
                  case 100:
                  case 101:
                  case 102:
                  case 103:
                  case 106:
                  case 107:
                  case 108:
                  case 109:
                  case 110:
                  default:
                     break;
                  case 89:
                     byFld <<= (byte)var2;
                     break;
                  case 95:
                     try {
                        var10 = 1833900443 % var10;
                        var10 = -21927 / var9;
                        var2 = var9 / var11;
                     } catch (ArithmeticException var14) {
                     }
                     break;
                  case 104:
                     var7 = 45380;
                  case 90:
                     var10 = var10;
                     break;
                  case 105:
                     instanceCount = instanceCount;
                     var9 = 1;

                     while(true) {
                        if (var9 <= 1) {
                           continue label46;
                        }

                        instanceCount += (long)(var9 + var2);
                        var2 += var9;
                        bFld = false;
                        var10 = var8;
                        var7 = var8 + var8;
                        --var9;
                     }
                  case 112:
                     instanceCount *= (long)var2;
                     var12[var8][var8 - 1] |= (int)instanceCount;
               }
            }
         }
      }

      vMeth1_check_sum += Double.doubleToLongBits(var0) + (long)var2 + Double.doubleToLongBits(var3) + Double.doubleToLongBits(var5) + (long)var7 + (long)var8 + (long)var9 + (long)var10 + (long)var11 + FuzzerUtils.checkSum(var12);
   }

   public static void vMeth(int var0, int var1) {
      double var2 = -1.21148;
      int var4 = 13;
      boolean var5 = true;
      byte var6 = 14;
      int var7 = 9447;
      int var8 = -63;
      int var9 = -3125;
      int[] var10 = new int[400];
      float var11 = -32.939F;
      FuzzerUtils.init((int[])var10, (int)13);
      vMeth1(var2, var1, var2);
      instanceCount <<= var1;
      var10[(var4 >>> 1) % 400] = var1;
      var4 = (int)var2;

      int var12;
      for(var12 = 3; var12 < 169; ++var12) {
         var10[var12 + 1] += (int)var2;

         for(var7 = 1; var7 < 10; ++var7) {
            var11 *= -2.0F;
            var0 += 37072;
            var8 += var7;
            var9 = 1;

            while(true) {
               var9 += 2;
               if (var9 >= 2) {
                  break;
               }

               instanceCount = (long)var0;
               instanceCount += (long)(var9 - var7);
               var10[var9] = var0;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var1 + (long)var12 + (long)var6 + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var11) + (long)var9 + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 48174;
      int var4 = -16433;
      int var5 = -240;
      int var6 = -2;
      int var7 = 53507;
      int var8 = -13;
      int var9 = 62;
      int var10 = 74;
      int var11 = 127;
      int var12 = 19866;
      short var13 = -17917;
      int var14 = -203;
      int[] var15 = new int[400];
      float var16 = -87.472F;
      FuzzerUtils.init((int[])var15, (int)24590);
      int var17 = 1;

      while(true) {
         ++var17;
         if (var17 >= 226) {
            for(var7 = 7; var7 < 158; ++var7) {
               dFld -= dFld;
               byFld -= (byte)var4;

               for(var9 = var7; var9 < 166; var9 += 3) {
                  var10 += var9 - var8;
                  var11 = 1;

                  do {
                     instanceCount = -59826L;
                     ++var11;
                  } while(var11 < 1);

                  lArrFld = lArrFld;
                  switch (var9 % 7 * 5 + 42) {
                     case 45:
                        var6 *= (int)var16;
                     case 76:
                        if (bFld) {
                        }
                        break;
                     case 52:
                        instanceCount += (long)(var9 + var17);
                        break;
                     case 64:
                        switch (var7 % 5 + 107) {
                           case 107:
                              var12 = var9;
                              if (var9 < 1) {
                                 var15[var9] = var3;
                                 var8 = (int)((long)var8 + ((long)(var9 * var7) + instanceCount - instanceCount));
                              }
                              break;
                           case 108:
                              var13 = -4;
                              break;
                           case 109:
                              var14 *= (int)var16;
                              break;
                           case 110:
                              var15[var7] = 19;
                              break;
                           case 111:
                              var4 += var9 | var6;
                        }
                     case 54:
                        var4 += var9 * var9;
                        break;
                     case 68:
                        var16 += (float)var5;
                        break;
                     case 70:
                        var15[var9 - 1] = (int)var16;
                  }
               }
            }

            FuzzerUtils.out.println("i i1 i2 = " + var17 + "," + var3 + "," + var4);
            FuzzerUtils.out.println("f1 i25 i26 = " + Float.floatToIntBits(var16) + "," + var5 + "," + var6);
            FuzzerUtils.out.println("i27 i28 i29 = " + var7 + "," + var8 + "," + var9);
            FuzzerUtils.out.println("i30 i31 i32 = " + var10 + "," + var11 + "," + var12);
            FuzzerUtils.out.println("i33 i34 iArr3 = " + var13 + "," + var14 + "," + FuzzerUtils.checkSum(var15));
            FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.byFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + byFld);
            FuzzerUtils.out.println("Test.dFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(lArrFld));
            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         for(var3 = var17; var3 < 111; var3 += 2) {
            vMeth(var3, var17);
            var16 = (float)var4;

            for(var5 = 1; var5 < 1 && !bFld; ++var5) {
               var4 = var4;
               var15[var3 - 1] >>= (int)instanceCount;
               var6 >>= var3;
               var16 += (float)var5;
               var16 += (float)var5;
               var15[var3 + 1] -= (int)dFld;
               instanceCount += (long)(var5 ^ var4);
            }

            var15[var17 + 1] -= var4;
            var15[var3] = 6;
            if (bFld) {
               break;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 39886L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
