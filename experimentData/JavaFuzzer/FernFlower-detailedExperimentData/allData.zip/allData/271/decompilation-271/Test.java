public class Test {
   public static final int N = 400;
   public static long instanceCount = 7L;
   public static float fFld = 2.406F;
   public static byte byFld = -39;
   public static int iFld = -1;
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, short var1) {
      double var2 = -2.32033;
      double[] var4 = new double[400];
      boolean var5 = true;
      int var6 = -6;
      short var7 = 22904;
      int var8 = 4694;
      int[][] var9 = new int[400][400];
      long var10 = -11L;
      byte var12 = -78;
      boolean var13 = false;
      float[] var14 = new float[400];
      FuzzerUtils.init((int[][])var9, (int)33696);
      FuzzerUtils.init(var4, -29.5127);
      FuzzerUtils.init(var14, -1.43F);
      var2 += (double)var0;

      int var15;
      for(var15 = 7; var15 < 280; ++var15) {
         label37:
         for(var10 = (long)var15; var10 < 6L; ++var10) {
            var0 = var0;
            switch (var15 % 5 * 5 + 63) {
               case 67:
                  var6 <<= (int)instanceCount;
                  break;
               case 71:
                  instanceCount <<= (int)instanceCount;
                  var8 = 1;

                  while(true) {
                     var9[var8][var8] = var6;
                     var9[var15 - 1][(int)(var10 - 1L)] = 147;
                     var4[var8 - 1] *= -41679.0;
                     instanceCount = (long)var7;
                     var12 -= (byte)var0;
                     var13 = var13;
                     instanceCount *= (long)var2;
                     var0 += var15;
                     ++var8;
                     if (var8 >= 1) {
                        continue label37;
                     }
                  }
               case 80:
                  var14[var15 - 1] = (float)var8;
               case 78:
                  var6 += 2;
                  break;
               case 86:
                  var2 *= -2.36221;
            }
         }
      }

      vMeth2_check_sum += (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var15 + (long)var6 + var10 + (long)var7 + (long)var8 + (long)var12 + (long)(var13 ? 1 : 0) + FuzzerUtils.checkSum(var9) + Double.doubleToLongBits(FuzzerUtils.checkSum(var4)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var14));
   }

   public static void vMeth1(int var0) {
      boolean var1 = true;
      int var2 = 3;
      int var3 = -172;
      int var4 = 0;
      int var5 = 1;
      short var6 = 12660;
      short var7 = 18974;
      boolean var8 = false;
      byte[] var9 = new byte[400];
      FuzzerUtils.init(var9, (byte)-71);
      var0 = var0-- + (int)((long)var0 * ((long)var0 - instanceCount - (long)var0 * instanceCount));

      int var11;
      label42:
      for(var11 = 4; 303 > var11; ++var11) {
         short var10 = -4934;
         var9[var11] = (byte)(var9[var11] + 5);
         if (var8) {
            var7 = (short)Math.max(22, var2);
         } else if (var8) {
            vMeth2(var0, var10);
            var3 = (int)((float)var3 + ((float)var11 * fFld + (float)var3 - (float)var11));
            byFld >>= (byte)var3;
            switch (var11 % 3 + 84) {
               case 84:
                  var4 = 6;

                  while(true) {
                     var4 -= 3;
                     if (var4 <= 0) {
                        continue label42;
                     }

                     var2 += var4;
                     iArrFld = FuzzerUtils.int1array(400, 40173);
                     instanceCount += (long)(var4 * var4);
                     int[] var12 = iArrFld;
                     var12[var11] *= 192;
                     byFld += (byte)(var4 * iFld + iFld - var3);
                  }
               case 85:
                  iFld += var11;
                  break;
               case 86:
                  var5 *= var6;
            }
         } else if (var8) {
            var0 = var11;
         } else {
            var0 = (int)instanceCount;
         }
      }

      vMeth1_check_sum += (long)(var0 + var11 + var2 + var7 + var3 + var4 + var5 + var6 + (var8 ? 1 : 0)) + FuzzerUtils.checkSum(var9);
   }

   public void vMeth(long var1, int var3) {
      float var4 = 2.403F;
      int var5 = -34406;
      int var6 = -45717;
      int var7 = 92;
      char var8 = '裧';
      int var9 = 5;
      int var10 = 43199;
      short var11 = -25568;
      double var12 = 2.6251;
      long[] var14 = new long[400];
      FuzzerUtils.init(var14, 7L);
      instanceCount -= (long)(var4++);

      for(var5 = 9; 236 > var5; ++var5) {
         vMeth1(var5);

         for(var7 = 1; 7 > var7; ++var7) {
            iFld -= var5;
            var4 = (float)byFld;
         }

         fFld += (float)(var5 * iFld + var6 - var5);
         var14[var5 + 1] -= instanceCount;
         var6 = 20766;
         var14 = var14;
         int[] var10000 = iArrFld;
         var10000[var5] &= var11;

         for(var9 = 1; var9 < 7; ++var9) {
            var6 = (int)var1;
         }

         var10 += (int)(3355258990889740001L + (long)(var5 * var5));
         var3 += (int)var12;
      }

      vMeth_check_sum += var1 + (long)var3 + (long)Float.floatToIntBits(var4) + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var11 + (long)var9 + (long)var10 + Double.doubleToLongBits(var12) + FuzzerUtils.checkSum(var14);
   }

   public void mainTest(String[] var1) {
      float var2 = 0.317F;
      boolean var3 = true;
      int var4 = 140;
      int var5 = 199;
      int var6 = 44388;
      short var7 = 238;
      double var8 = 71.121114;
      double[][][] var10 = new double[400][400][400];
      boolean var11 = true;
      short var12 = -8714;
      long[] var13 = new long[400];
      FuzzerUtils.init((Object[][])var10, -7.98574);
      FuzzerUtils.init(var13, -48250L);
      var2 = 1.0F;

      do {
         this.vMeth(instanceCount, iFld);
      } while(++var2 < 215.0F);

      byFld = (byte)((int)instanceCount);
      iFld *= (int)instanceCount;
      iFld += iFld;

      int var14;
      for(var14 = 7; 389 > var14; ++var14) {
         for(var5 = 1; var5 < 66; ++var5) {
            iFld = var7;
            var8 = 1.0;

            do {
               int[] var10000;
               switch ((var4 >>> 1) % 2 + 107) {
                  case 107:
                     iFld <<= var5;
                     iFld += var4;
                     break;
                  case 108:
                     iArrFld[var14 - 1] = var5;
                     var6 += (int)var8;
                     iFld += (int)instanceCount;
                     iFld += (int)instanceCount;
                  default:
                     var10[(int)var8][var5 + 1][var5 + 1] *= (double)instanceCount;
                     var10000 = iArrFld;
                     var10000[(int)var8] *= var7;
                     if (var11) {
                        var13[var5] = (long)var4;
                        var13[(int)(var8 - 1.0)] <<= var14;
                        iFld = var6;
                        var4 = (int)((double)var4 + 308.0 + var8 * var8);
                     }

                     var11 = var11;
               }

               var10000 = iArrFld;
               var10000[var5] -= var4;
               var12 -= (short)var6;
               var6 += (int)instanceCount;
               var10000 = iArrFld;
               var10000[var5 - 1] -= var6;
            } while(++var8 < 2.0);

            var6 -= (int)fFld;
            instanceCount = instanceCount;
         }
      }

      FuzzerUtils.out.println("f i19 i20 = " + Float.floatToIntBits(var2) + "," + var14 + "," + var4);
      FuzzerUtils.out.println("i21 i22 i23 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("d2 b2 s4 = " + Double.doubleToLongBits(var8) + "," + (var11 ? 1 : 0) + "," + var12);
      FuzzerUtils.out.println("dArr1 lArr1 = " + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var10)) + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
      FuzzerUtils.out.println("Test.iFld Test.iArrFld = " + iFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-4029);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
