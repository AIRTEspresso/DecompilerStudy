public class Test {
   public static final int N = 400;
   public static long instanceCount = -2L;
   public static int iFld = -12;
   public static byte byFld = -70;
   public static boolean bFld = true;
   public static short sFld = 14539;
   public static double dFld = 90.59275;
   public static volatile int[] iArrFld = new int[400];
   public static long[][] lArrFld = new long[400][400];
   public float[][] fArrFld = new float[400][400];
   public static long dMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1) {
      boolean var2 = true;
      byte var3 = 0;
      int var4 = 48;
      short var5 = 29321;
      int var6 = 8;
      int var7 = -10226;
      int var8 = 54068;
      float var9 = 0.6F;
      short var10 = 13480;

      int var14;
      for(var14 = 213; var14 > 13; --var14) {
         var1 ^= var3;
         var1 -= byFld;
         instanceCount = instanceCount;
         var9 += (float)instanceCount;
         iFld *= var1;

         for(var4 = 1; var4 < 8; ++var4) {
            iFld -= var3;
            var10 += (short)((int)((long)var4 | (long)var9));
         }

         for(var6 = 1; 8 > var6; ++var6) {
            iFld += var6 ^ iFld;
            iFld += (int)var9;
            var8 = 1;

            do {
               byte var11 = -13;

               try {
                  iArrFld[var6] = var7 / -24101;
                  var7 = iArrFld[var6] % 32037;
                  var1 = iArrFld[var14] / var11;
               } catch (ArithmeticException var13) {
               }

               var7 *= (int)var9;
               ++var8;
            } while(var8 < 2);
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var14 + var3 + Float.floatToIntBits(var9) + var4 + var5 + var10 + var6 + var7 + var8);
   }

   public static void vMeth(long var0, long var2, long var4) {
      int var6 = 62705;
      int var7 = -215;
      boolean var8 = true;
      int var9 = -114;
      int var10 = 7;
      int var11 = -76;
      char var12 = '蟵';
      float var13 = 1.596F;
      float var14 = -2.906F;
      double[] var15 = new double[400];
      FuzzerUtils.init(var15, 1.45109);

      for(var6 = 3; 206 > var6; ++var6) {
         iFld = (int)((long)iFld + ((long)(var6 * iFld) + var4 - (long)var6));
         vMeth1(-38359, var7);
         var7 += var7;
      }

      int var18;
      for(var18 = 4; var18 < 310; ++var18) {
         for(var10 = 1; var10 < 5; var10 += 3) {
            byFld += (byte)((int)var0);
            var9 /= (int)((long)var13 | 1L);

            try {
               var9 = var11 % iFld;
               var11 = 13911 % var6;
               iFld = iArrFld[var10 - 1] / var7;
            } catch (ArithmeticException var17) {
            }

            var15 = var15;

            for(var14 = 5.0F; var14 > (float)var18 && !bFld; --var14) {
               long[] var10000 = lArrFld[var18 + 1];
               var10000[var10] |= (long)var9;
               sFld *= (short)var9;
               var2 >>>= var18;
            }
         }
      }

      vMeth_check_sum += var0 + var2 + var4 + (long)var6 + (long)var7 + (long)var18 + (long)var9 + (long)var10 + (long)var11 + (long)Float.floatToIntBits(var13) + (long)Float.floatToIntBits(var14) + (long)var12 + Double.doubleToLongBits(FuzzerUtils.checkSum(var15));
   }

   public static double dMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 181;
      int var5 = -59;
      int var6 = -8;
      boolean var7 = true;
      short var8 = -134;
      int var9 = 8;
      int[] var10 = new int[400];
      double var11 = 0.117402;
      float[] var13 = new float[400];
      FuzzerUtils.init((int[])var10, (int)-13);
      FuzzerUtils.init(var13, 0.15F);
      int var10001 = (var2 >>> 1) % 400;
      --var0;
      var10[var10001] = (int)((long)var0 * (instanceCount | 233L));

      int var16;
      for(var16 = 1; var16 < 328; ++var16) {
         var4 = var10[var16];

         for(var5 = 1; 5 > var5; ++var5) {
            boolean var14 = true;
            --var6;
            instanceCount %= (long)(var5 << var6 | 1);
            if (var14) {
               break;
            }

            vMeth(instanceCount, instanceCount, instanceCount);
         }
      }

      iFld = var16;
      sFld = (short)var1;

      int var17;
      for(var17 = 18; var17 < 320; ++var17) {
         var10[var17 + 1] -= 41;
         var9 = 1;

         do {
            var11 -= (double)iFld;
            var13[var9 + 1] *= (float)var6;
            iFld |= sFld;
            ++var9;
         } while(var9 < 5);
      }

      long var18 = (long)(var0 + var1 + var2 + var16 + var4 + var5 + var6 + var17 + var8 + var9) + Double.doubleToLongBits(var11) + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
      dMeth_check_sum += var18;
      return (double)var18;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -11;
      int var4 = 0;
      int var5 = 166;
      int var6 = 31;
      int var7 = 8;
      int var8 = -37812;
      int var9 = -22309;
      float var10 = -1.192F;
      double[] var11 = new double[400];
      FuzzerUtils.init(var11, -30.86004);
      iFld <<= -(iFld -= (int)dMeth(130, iFld, iFld));

      int var15;
      for(var15 = 13; var15 < 323; ++var15) {
         try {
            iFld = -759257638 % iFld;
            var3 = -17885 / iArrFld[var15];
            var3 = iFld / iFld;
         } catch (ArithmeticException var14) {
         }

         instanceCount += (long)var15;

         for(var4 = 1; var4 < 81; ++var4) {
            instanceCount *= (long)var5;
            var5 *= -48;
            dFld -= -8.0;
            var3 = (int)var10;
         }

         var5 &= var4;
         this.fArrFld[var15 + 1] = this.fArrFld[var15 - 1];
         switch (var15 % 8 * 5 + 37) {
            case 39:
               var3 = (int)instanceCount;
               break;
            case 50:
            case 53:
            case 74:
               try {
                  iArrFld[var15] = var15 % iArrFld[var15];
                  var9 = iArrFld[var15 - 1] / -34681;
                  iArrFld[var15 + 1] = var3 % -124;
               } catch (ArithmeticException var13) {
               }
               break;
            case 56:
               var3 += 8;
               break;
            case 72:
               instanceCount -= (long)var15;
               break;
            case 76:
               for(var6 = 3; var6 < 81; ++var6) {
                  bFld = bFld;
                  dFld += (double)var3;
                  sFld += (short)(var6 * var6);
                  var3 += var6;
                  var3 = var3;
                  instanceCount += (long)var6;

                  for(var8 = 1; var8 < 2; ++var8) {
                     long[] var10000 = lArrFld[var8 + 1];
                     var10000[var6 - 1] -= instanceCount;
                     instanceCount += (long)byFld;
                     dFld = (double)instanceCount;
                     var11[var8 - 1] += 53644.0;
                  }

                  var7 += var9;
                  instanceCount += (long)dFld;
                  var10 -= (float)iFld;
               }

               var3 = var15;
            case 70:
               instanceCount = (long)((float)instanceCount + ((float)var15 * var10 + (float)var5 - (float)byFld));
               break;
            default:
               iArrFld = iArrFld;
         }
      }

      FuzzerUtils.out.println("i27 i28 i29 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i30 f3 i31 = " + var5 + "," + Float.floatToIntBits(var10) + "," + var6);
      FuzzerUtils.out.println("i32 i33 i34 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("dArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + byFld);
      FuzzerUtils.out.println("Test.bFld Test.sFld Test.dFld = " + (bFld ? 1 : 0) + "," + sFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.iArrFld Test.lArrFld fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)212);
      FuzzerUtils.init(lArrFld, 13L);
      dMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
