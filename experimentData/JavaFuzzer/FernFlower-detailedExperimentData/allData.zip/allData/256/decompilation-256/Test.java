public class Test {
   public static final int N = 400;
   public static long instanceCount = -65247L;
   public static float fFld = 2.786F;
   public static int iFld = -5903;
   public static boolean bFld = true;
   public static long[][] lArrFld = new long[400][400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2() {
      boolean var0 = true;
      int var1 = -90;
      int var2 = 194;
      int var3 = -1;
      int var4 = 95;
      int var5 = -48907;
      int[] var6 = new int[400];
      short var7 = -1192;
      double var8 = 28.6854;
      FuzzerUtils.init(var6, -65265);

      int var10;
      for(var10 = 3; var10 < 203; ++var10) {
         instanceCount += (long)(0.904F + (float)(var10 * var10));
         switch (var10 % 3 * 5 + 110) {
            case 113:
               var1 = var1;
               break;
            case 116:
               for(var2 = 1; var2 < 8; ++var2) {
                  var1 = var3;
                  long[] var10000 = lArrFld[var10];
                  var10000[var2] += (long)var3;

                  for(var4 = var2; var4 < 2; ++var4) {
                     var7 += (short)var4;
                     var1 = var1;
                     var6 = FuzzerUtils.int1array(400, 98);
                     var8 += var8;
                     instanceCount = (long)var1;
                     var3 = (int)instanceCount;
                  }

                  fFld = (float)var10;
               }
               break;
            case 124:
               instanceCount += (long)var7;
         }
      }

      vMeth2_check_sum += (long)(var10 + var1 + var2 + var3 + var4 + var5 + var7) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var6);
   }

   public static void vMeth1(int var0) {
      boolean var1 = true;
      int var2 = -20667;
      byte var3 = 11;
      int var4 = 0;
      int var5 = -40355;
      int[] var6 = new int[400];
      float var7 = 99.47F;
      float var8 = 2.74F;
      byte var9 = -81;
      FuzzerUtils.init((int[])var6, (int)30014);
      vMeth2();
      var0 |= var0;

      int var10;
      for(var10 = 12; var10 < 248; ++var10) {
         for(var7 = 1.0F; var7 < 7.0F; ++var7) {
            for(var8 = var7; var8 < 2.0F; ++var8) {
               fFld = 10.0F;
               var5 >>= var2;
               var4 ^= 237;
               var2 += (int)((long)var8 ^ (long)var9);
               var4 = iFld;
            }

            if (bFld) {
               var6[var10 + 1] += (int)var7;
               var5 += var2;
               instanceCount += (long)var7;
            } else {
               var5 += (int)instanceCount;
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var10 + var2 + Float.floatToIntBits(var7) + var3 + Float.floatToIntBits(var8) + var4 + var5 + var9) + FuzzerUtils.checkSum(var6);
   }

   public static void vMeth() {
      vMeth1(iFld);
      vMeth_check_sum += 0L;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -52938;
      boolean var4 = true;
      int var5 = -5;
      int var6 = 195;
      int var7 = -199;
      int[] var8 = new int[400];
      boolean var9 = true;
      short var10 = 18581;
      double var11 = -2.32484;
      FuzzerUtils.init(var8, -53132);

      int var13;
      for(var13 = 13; 387 > var13; ++var13) {
         vMeth();
      }

      byte var15 = (byte)var10;
      var15 *= (byte)((int)fFld);
      var10 = 4726;
      iFld += var13;
      int var14 = 127;

      while(true) {
         --var14;
         if (var14 <= 0) {
            break;
         }

         iFld >>= (int)instanceCount;
         if (bFld) {
            break;
         }

         var3 = (int)((long)var3 + ((long)var14 * instanceCount + instanceCount - (long)var14));

         for(var5 = 197; 11 < var5; --var5) {
            var3 = (int)instanceCount;
            instanceCount = (long)var5;
            var6 += var14;

            for(var11 = 2.0; var11 > 1.0; var11 -= 3.0) {
               var8[var14] = 12;
               var3 += (int)(var11 * var11);
               var7 = -9;
               var3 = var3;
               if (bFld) {
                  instanceCount += (long)var15;
                  var6 += (int)instanceCount;
                  var3 >>= var13;
                  var7 = (int)((double)var7 + 14.0 + var11 * var11);
               } else if (bFld) {
                  var7 = 91;
                  var8[var5 + 1] = var3;
                  var6 <<= var5;
               }

               var6 = (int)((double)var6 + 202.0 + var11 * var11);
               iFld += (int)(204.0 + var11 * var11);
               var15 %= (byte)(var10 | 1);
            }
         }
      }

      FuzzerUtils.out.println("i i1 by1 = " + var13 + "," + var3 + "," + var15);
      FuzzerUtils.out.println("s1 i14 i15 = " + var10 + "," + var14 + "," + var5);
      FuzzerUtils.out.println("i16 d1 i17 = " + var6 + "," + Double.doubleToLongBits(var11) + "," + var7);
      FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(var8));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
      FuzzerUtils.out.println("Test.bFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 7796706057543378775L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
