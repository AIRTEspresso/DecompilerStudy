public class Test {
   public static final int N = 400;
   public static long instanceCount = 1L;
   public static long lFld = -5L;
   public static int iFld = 36272;
   public static byte byFld = -38;
   public static short sFld = 28385;
   public int iFld1 = 57097;
   public static double dFld = -1.80568;
   public static volatile float fFld = 0.693F;
   public int[][] iArrFld = new int[400][400];
   public static long[] lArrFld = new long[400];
   public volatile byte[] byArrFld = new byte[400];
   public int[] iArrFld1 = new int[400];
   public static long vMeth_check_sum;
   public static long dMeth_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(long var0) {
      int var2 = -33606;
      int var3 = 216;
      int var4 = 54593;
      int var5 = -8;
      int var6 = 53979;
      int var7 = 2;
      short var8 = 174;
      int[] var9 = new int[400];
      byte var10 = -53;
      boolean var11 = true;
      float var12 = -17.598F;
      FuzzerUtils.init((int[])var9, (int)124);
      var0 = (long)iFld;
      var2 = 1;

      while(true) {
         ++var2;
         if (var2 >= 218) {
            long var13 = var0 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var10 + (long)(var11 ? 1 : 0) + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var12) + FuzzerUtils.checkSum(var9);
            iMeth_check_sum += var13;
            return (int)var13;
         }

         for(var3 = 1; var3 < 7; ++var3) {
            for(var5 = 1; var5 < 2; ++var5) {
               var10 += (byte)(var5 * iFld + var5 - var3);
            }

            if (!var11) {
               for(var7 = 1; var7 < 2; ++var7) {
                  var4 -= (int)lFld;
                  var6 += (int)var0;
                  var4 >>= -49;
                  lArrFld[var2 + 1] = (long)var6;
                  var9[var7 - 1] *= (int)lFld;
                  var4 = (int)var0;
                  var10 *= (byte)((int)var12);
               }
            }
         }

         var6 >>= var7;
      }
   }

   public double dMeth(int var1, long var2, int var4) {
      float var5 = 0.237F;
      int var6 = -29204;
      int var7 = -2;
      int var8 = -6;
      byte var9 = 65;
      double var10 = 125.50555;
      short var12 = 3970;
      var4 += (int)(instanceCount / (long)(this.iArrFld[(var4 >>> 1) % 400][(var1 >>> 1) % 400] | 1));
      byte[] var13 = this.byArrFld;
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         byte var16 = var13[var15];
         switch (((int)(var5 + (float)var1) >>> 1) % 2 * 5 + 118) {
            case 119:
               var4 <<= var1;
               break;
            case 120:
               for(var6 = 1; 4 > var6; ++var6) {
                  var1 += var7 += var1 + var16 + var7;

                  for(var8 = 1; var8 < 2; var8 += 2) {
                     var10 = (double)(lFld++);
                     iMeth(var2);
                     instanceCount += (long)(var8 * var8);
                     switch ((var8 >>> 1) % 2 + 47) {
                        case 47:
                           lFld += (long)var8;
                           var7 = var4;
                           break;
                        case 48:
                           lFld >>= (int)instanceCount;
                           var1 += var12;
                        default:
                           var9 = var16;
                     }
                  }
               }
         }
      }

      long var17 = (long)var1 + var2 + (long)var4 + (long)Float.floatToIntBits(var5) + (long)var6 + (long)var7 + (long)var8 + (long)var9 + Double.doubleToLongBits(var10) + (long)var12;
      dMeth_check_sum += var17;
      return (double)var17;
   }

   public void vMeth(int var1, byte var2) {
      int var3;
      int var4;
      int var5;
      int var6;
      int var7;
      int var8;
      int[] var9;
      boolean var10;
      float var11;
      short[] var12;
      var3 = 35108;
      var4 = 4681;
      var5 = -184;
      var6 = 109;
      var7 = 90;
      var8 = -4;
      var9 = new int[400];
      var10 = false;
      var11 = -45.98F;
      var12 = new short[400];
      FuzzerUtils.init((int[])var9, (int)-21917);
      FuzzerUtils.init((short[])var12, (short)7118);
      var1 = -this.iArrFld[10][(var1 >>> 1) % 400];
      long[] var10000;
      label48:
      switch (((int)(instanceCount - -122L) >>> 1) % 7 + 101) {
         case 101:
            var3 = 1;

            while(true) {
               var1 *= var1;

               for(var4 = 1; var4 < 12; ++var4) {
                  int[] var10001 = this.iArrFld[var3 + 1];
                  int var10002 = var3 + 1;
                  int var10004 = var10001[var3 + 1];
                  var10001[var10002] = var10001[var3 + 1] + 1;
                  var1 >>>= var10004;

                  for(var6 = 1; 2 > var6; ++var6) {
                     var1 = --this.iArrFld[var6][var6];
                     var10000 = lArrFld;
                     var10000[var6 - 1] += lFld++;
                     var1 -= (int)this.dMeth(var4, instanceCount, iFld);
                     iFld -= (int)instanceCount;
                     if (!var10) {
                        lFld += (long)(var6 | var8);
                        var7 = -42613;
                        this.iArrFld[var6][var4 + 1] = 1923122714;
                     }
                  }
               }

               ++var3;
               if (var3 >= 129) {
                  break label48;
               }
            }
         case 102:
            var10000 = lArrFld;
            var10000[(var8 >>> 1) % 400] -= (long)var4;
            break;
         case 103:
            var8 &= iFld;
         case 104:
            var12[(iFld >>> 1) % 400] = (short)var5;
         case 105:
            var5 += var1;
         case 106:
            var8 = var1;
            break;
         case 107:
            var8 -= var2;
         default:
            var11 -= (float)var8;
      }

      vMeth_check_sum += (long)(var1 + var2 + var3 + var4 + var5 + var6 + var7 + (var10 ? 1 : 0) + var8 + Float.floatToIntBits(var11)) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var12);
   }

   public void mainTest(String[] var1) {
      float var2 = 104.706F;
      float var3 = 0.712F;
      int var4 = -116;
      boolean var5 = true;
      int var6 = -30510;
      int var7 = -41;
      int var8 = -311;
      int var9 = 45774;
      int var10 = 149;
      int var11 = 7;
      int var12 = 177;
      int var13 = 66;
      byte var14 = -13;
      boolean var15 = false;
      this.vMeth(0, byFld);
      int[] var16 = this.iArrFld1;
      int var17 = var16.length;

      for(int var18 = 0; var18 < var17; ++var18) {
         int var19 = var16[var18];
         iFld = (int)lFld;
         iFld = var19;
         int[] var10000 = this.iArrFld1;
         int var10001 = (iFld >>> 1) % 400;
         var10000[var10001] >>= -11301;
         var2 = (float)lFld;
         sFld -= (short)((int)instanceCount);
         iFld *= iFld;
         this.iArrFld[(iFld >>> 1) % 400][45] = iFld;
         iFld = this.iFld1;
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 63 || var15) {
               break;
            }

            this.iFld1 = var4;
            var2 = (float)dFld;
         }
      }

      this.iArrFld[(this.iFld1 >>> 1) % 400][(iFld >>> 1) % 400] = iFld;
      iFld += iFld;
      iFld <<= byFld;

      int var21;
      for(var21 = 5; 257 > var21; ++var21) {
         for(var7 = 4; var7 < 100; ++var7) {
            for(var9 = 1; var9 < 2; ++var9) {
               var3 += (float)((long)var9 | (long)var2);
               instanceCount = (long)((float)instanceCount + ((float)var9 * fFld + (float)var9 - (float)var6));
            }

            var6 += 33846;

            for(var11 = 2; var11 > 1; --var11) {
               var10 += (int)(23.539F + (float)(var11 * var11));
            }

            var12 <<= var4;
         }

         byFld += (byte)(var21 | var8);

         for(var13 = 6; var13 < 100; ++var13) {
            try {
               var12 = this.iFld1 % 204;
               var12 = var14 / '걪';
               var8 = iFld / var12;
            } catch (ArithmeticException var20) {
            }

            var15 = var15;
         }
      }

      FuzzerUtils.out.println("f3 i22 b2 = " + Float.floatToIntBits(var2) + "," + var4 + "," + (var15 ? 1 : 0));
      FuzzerUtils.out.println("i23 i24 i25 = " + var21 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i26 i27 i28 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("f4 i29 i30 = " + Float.floatToIntBits(var3) + "," + var11 + "," + var12);
      FuzzerUtils.out.println("i31 i32 = " + var13 + "," + var14);
      FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.iFld = " + instanceCount + "," + lFld + "," + iFld);
      FuzzerUtils.out.println("Test.byFld Test.sFld iFld1 = " + byFld + "," + sFld + "," + this.iFld1);
      FuzzerUtils.out.println("Test.dFld Test.fFld iArrFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("Test.lArrFld byArrFld iArrFld1 = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld1));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 12L);
      vMeth_check_sum = 0L;
      dMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
