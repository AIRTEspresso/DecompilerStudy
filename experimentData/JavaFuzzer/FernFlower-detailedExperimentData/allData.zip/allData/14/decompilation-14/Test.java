public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 156L;
   public static float fFld = 19.722F;
   public double dFld = 1.58438;
   public static int[] iArrFld = new int[400];
   public static volatile long[] lArrFld = new long[400];
   public static float[] fArrFld = new float[400];
   public static long bMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(short var0, int var1) {
      boolean var2 = false;
      boolean[][] var3 = new boolean[400][400];
      int var4 = -2;
      int var5 = -51889;
      int[] var6 = new int[400];
      float var7 = 124.502F;
      double var8 = 1.117647;
      byte var10 = -90;
      FuzzerUtils.init((int[])var6, (int)128);
      FuzzerUtils.init(var3, true);
      int[] var11 = var6;
      int var12 = var6.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         int var14 = var11[var13];
         var3[(var1 >>> 1) % 400][(var14 >>> 1) % 400] = var2;
         var14 ^= -51468;
         if (var2) {
            if (var2) {
               for(var4 = 1; 4 > var4 && !var2; ++var4) {
                  var7 += (float)(var4 * var4);
                  switch (var4 % 2 + 116) {
                     case 116:
                        instanceCount += (long)var5;
                        var7 -= (float)var5;
                        break;
                     case 117:
                        var8 *= (double)var1;
                        var1 = -32266;
                        var7 *= 83.0F;
                        var8 *= (double)var1;
                  }
               }
            } else {
               int var10000 = var14 - var10;
            }
         } else if (var2) {
            var5 = var4;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + (var2 ? 1 : 0) + var4 + var5 + Float.floatToIntBits(var7)) + Double.doubleToLongBits(var8) + (long)var10 + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var3);
   }

   public static void vMeth() {
      short var0 = -145;
      boolean var1 = true;
      int var2 = 188;
      int var3 = 8;
      int var4 = -9114;
      int var5 = -6;
      int var6 = -37628;
      short var7 = -19244;
      short[] var8 = new short[400];
      boolean var9 = false;
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, 89.208F);
      FuzzerUtils.init((short[])var8, (short)656);
      var0 = var0;
      vMeth1(var7, 61579);

      int var11;
      for(var11 = 7; var11 < 138 && !var9; ++var11) {
         if (var9) {
            var2 *= var0;

            for(var3 = 1; 12 > var3; ++var3) {
               var10[var3 + 1] -= (float)var0;
               iArrFld[var3] = var11;
               var4 += var3 | var3;
               instanceCount = (long)var3;
               var2 >>= var2;
            }
         } else {
            if (var9) {
               for(var5 = 1; 12 > var5; ++var5) {
                  var8[var11 - 1] *= (short)var3;
                  var2 = (int)((long)var2 + ((long)var5 | instanceCount));
               }

               vMeth_check_sum += (long)(var0 + var7 + var11 + var2 + (var9 ? 1 : 0) + var3 + var4 + var5 + var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var8);
               return;
            }

            if (var9) {
               break;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var7 + var11 + var2 + (var9 ? 1 : 0) + var3 + var4 + var5 + var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var8);
   }

   public static boolean bMeth(int var0, float var1, short var2) {
      boolean var3 = true;
      int var4 = 103;
      boolean var5 = true;
      char var6 = '蹟';
      int var7 = -40149;
      short var8 = -140;
      boolean var9 = false;
      vMeth();
      int[] var10000 = iArrFld;
      var10000[(var0 >>> 1) % 400] >>= (int)instanceCount;
      instanceCount = (long)var0;
      iArrFld[(var0 >>> 1) % 400] = var0;

      int var12;
      for(var12 = 12; var12 < 292; ++var12) {
         byte var13 = -5;
         lArrFld[var12] = (long)var13;
         var4 = var13 - (int)instanceCount;
      }

      float[] var15 = fArrFld;
      var15[(var0 >>> 1) % 400] += 0.994F;

      int var14;
      for(var14 = 14; var14 < 312; ++var14) {
         instanceCount <<= var14;
      }

      var10000 = iArrFld;
      var10000[(var0 >>> 1) % 400] += var12;

      for(var7 = 6; 380 > var7; var7 += 2) {
         iArrFld = iArrFld;
         var9 = var9;
      }

      long var10 = (long)(var0 + Float.floatToIntBits(var1) + var2 + var12 + var4 + var14 + var6 + var7 + var8 + (var9 ? 1 : 0));
      bMeth_check_sum += var10;
      return var10 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 13;
      int var4 = -197;
      int var5 = 211;
      boolean var6 = true;
      int var7 = -58016;
      short var8 = 18242;

      int var9;
      for(var9 = 9; 222 > var9; ++var9) {
         for(var4 = 5; var4 < 118; var4 += 2) {
            if (bMeth(var4, fFld, var8)) {
            }
         }

         var5 += var9 - var5;
         var3 += (int)fFld;
      }

      fFld += (float)var4;
      int var10 = 18;

      while(var10 < 291) {
         switch ((var4 >>> 1) % 1 + 97) {
            case 97:
               var3 += var9;
            default:
               lArrFld[var10 + 1] = (long)var3;
               var3 ^= var5;
               ++var10;
         }
      }

      byte var11 = -108;
      this.dFld *= (double)var4;
      var5 = var8 - var10;
      FuzzerUtils.out.println("i i1 i2 = " + var9 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 s3 i22 = " + var5 + "," + var8 + "," + var10);
      FuzzerUtils.out.println("i23 = " + var11);
      FuzzerUtils.out.println("Test.instanceCount Test.fFld dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("Test.iArrFld Test.lArrFld Test.fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-182);
      FuzzerUtils.init(lArrFld, -6087713711903524745L);
      FuzzerUtils.init(fArrFld, -4.232F);
      bMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
