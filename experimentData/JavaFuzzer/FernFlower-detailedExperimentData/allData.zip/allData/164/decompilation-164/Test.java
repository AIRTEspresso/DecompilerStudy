public class Test {
   public static final int N = 400;
   public static long instanceCount = 107L;
   public static volatile int iFld = -8;
   public long lFld = 13L;
   public static volatile byte byFld = -21;
   public static boolean bFld = false;
   public static float[] fArrFld = new float[400];
   public static volatile int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long fMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(long var0) {
      int var2 = 10789;
      var2 *= (int)instanceCount;
      var0 = -14075L;
      vMeth1_check_sum += var0 + (long)var2;
   }

   public static float fMeth(double var0, byte var2, long var3) {
      boolean var5 = true;
      int var6 = 63504;
      int var7 = -62949;
      int[] var8 = new int[400];
      float var9 = 0.913F;
      short var10 = -9867;
      short[] var11 = new short[400];
      FuzzerUtils.init((int[])var8, (int)50986);
      FuzzerUtils.init(var11, (short)-4317);
      int var15 = 1;

      do {
         int var12 = 0;
         var9 += (float)(var15 * var15);
         vMeth1(instanceCount);
         int var10000 = var12 * var15;

         try {
            var12 = -216 / var15;
            var12 = var15 / var12;
            var8[var15 + 1] = -1323004922 / var12;
         } catch (ArithmeticException var14) {
         }

         ++var15;
      } while(var15 < 226);

      var0 -= (double)var15;
      var6 = 1;

      while(true) {
         label39:
         while(true) {
            var6 += 3;
            if (var6 >= 234) {
               long var16 = Double.doubleToLongBits(var0) + (long)var2 + var3 + (long)var15 + (long)Float.floatToIntBits(var9) + (long)var6 + (long)var7 + (long)var10 + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var11);
               fMeth_check_sum += var16;
               return (float)var16;
            }

            var8[var6 - 1] = var15;
            switch (var6 % 4 + 63) {
               case 63:
               case 64:
                  var7 = 1;

                  do {
                     var9 = var9;
                     switch (var7 % 1 + 10) {
                        case 10:
                           var11[var6 - 1] = (short)var15;
                           var10 += (short)(var7 * var7);
                     }

                     var8[var7] *= -91;
                     ++var7;
                  } while(var7 < 20);
               case 65:
                  instanceCount = (long)var9;
               case 66:
                  break label39;
               default:
                  iFld += var6 | var7;
            }
         }

         iFld = 17008;
      }
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -8;
      int var4 = -14;
      short var5 = 28617;
      int var6 = 36801;
      int[] var7 = new int[400];
      double var8 = 57.26152;
      float var10 = 50.231F;
      byte var11 = -40;
      boolean var12 = true;
      FuzzerUtils.init((int[])var7, (int)10);
      int var17 = 216;

      int var18;
      do {
         var7[var17] >>= -14;
         instanceCount *= (long)(var8++ - (double)Integer.reverseBytes(Integer.reverseBytes(var17)));

         for(var18 = 21; var18 > 1; var18 -= 3) {
            var3 += var18;
            var0 += (int)var8;
         }

         var3 += (int)var8;
         var17 -= 3;
      } while(var17 > 0);

      instanceCount &= (long)(var10++ - (float)((long)var3 - ((long)var0 - instanceCount)));
      float[] var13 = fArrFld;
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         float var10000 = var13[var15];

         for(var4 = 1; var4 < 4; ++var4) {
            var6 = 2;

            while(true) {
               --var6;
               if (var6 <= 0) {
                  break;
               }

               instanceCount += (long)(var6 * var18 + var6 - var4);
               instanceCount *= (long)var4;
               var7[var6 - 1] = (int)((float)(var0--) + fMeth(-114.7178, var11, instanceCount));
               if (var12) {
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var17) + Double.doubleToLongBits(var8) + (long)var18 + (long)var3 + (long)Float.floatToIntBits(var10) + (long)var4 + (long)var5 + (long)var6 + (long)var11 + (long)(var12 ? 1 : 0) + FuzzerUtils.checkSum(var7);
   }

   public void mainTest(String[] var1) {
      int var2 = 42031;
      int var3 = -1;
      int var4 = -231;
      int var5 = -20701;
      boolean var6 = true;
      int var7 = -3;
      int var8 = -190;
      int var9 = -2;
      double var10 = -1.48991;
      double var12 = 82.119659;
      boolean var14 = false;
      float var15 = -98.489F;
      short var16 = -6115;
      byte[] var17 = new byte[400];
      long[] var18 = new long[400];
      FuzzerUtils.init(var17, (byte)-66);
      FuzzerUtils.init(var18, 2711281106836039529L);

      int[] var10000;
      for(var2 = 4; var2 < 255; ++var2) {
         var17[var2 + 1] -= (byte)((int)(instanceCount++));
         vMeth(var2);

         for(var4 = var2; var4 < 100; var4 += 3) {
            var3 = (int)((long)var3 + ((long)(var4 * iFld) + this.lFld - (long)iFld));
            iArrFld[var2 - 1] = var4;
            iFld *= (int)var10;
            var10000 = iArrFld;
            var10000[var4 - 1] -= var5;
         }
      }

      iFld %= (int)(instanceCount | 1L);
      int var19 = 1;

      while(true) {
         label85:
         while(true) {
            ++var19;
            if (var19 >= 198) {
               FuzzerUtils.out.println("i i1 i14 = " + var2 + "," + var3 + "," + var4);
               FuzzerUtils.out.println("i15 d2 i16 = " + var5 + "," + Double.doubleToLongBits(var10) + "," + var19);
               FuzzerUtils.out.println("d3 i17 i18 = " + Double.doubleToLongBits(var12) + "," + var7 + "," + var8);
               FuzzerUtils.out.println("b1 f3 s1 = " + (var14 ? 1 : 0) + "," + Float.floatToIntBits(var15) + "," + var16);
               FuzzerUtils.out.println("i19 byArr lArr = " + var9 + "," + FuzzerUtils.checkSum(var17) + "," + FuzzerUtils.checkSum(var18));
               FuzzerUtils.out.println("Test.instanceCount Test.iFld lFld = " + instanceCount + "," + iFld + "," + this.lFld);
               FuzzerUtils.out.println("Test.byFld Test.bFld Test.fArrFld = " + byFld + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
               FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
               FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
               FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               return;
            }

            label112: {
               label80: {
                  label79: {
                     switch (var19 % 8 + 43) {
                        case 43:
                        case 44:
                           for(var12 = 1.0; ++var12 < 127.0; var3 += 63916) {
                              var10000 = iArrFld;
                              var10000[(int)var12] -= 585660258;
                              iFld *= var3;

                              for(var7 = (int)var12; var7 < 1 && !var14; ++var7) {
                                 iFld = (int)((float)iFld + ((float)((long)var7 * this.lFld) + var15 - (float)var5));
                                 iFld = var16;
                                 iFld = var8;
                                 this.lFld >>= byFld;
                                 var9 += -3 + var7 * var7;
                                 instanceCount += (long)var7;
                                 var5 = (int)instanceCount;
                                 var8 = var9;
                              }

                              var9 -= (int)instanceCount;
                           }

                           var15 += (float)((long)(var19 * var9) + instanceCount - (long)var19);
                           float var20 = var15 + (float)var19;
                           var15 = (float)this.lFld;
                        case 45:
                           var18[var19 - 1] = (long)iFld;
                        case 46:
                           break;
                        case 47:
                           break label79;
                        case 48:
                           break label80;
                        case 49:
                           break label85;
                        case 50:
                           var14 = var14;
                        default:
                           break label112;
                     }

                     var17[var19 + 1] &= (byte)((int)this.lFld);
                  }

                  if (var14) {
                     continue;
                  }
               }

               if (bFld) {
                  continue;
               }
               break;
            }

            var3 = -8;
         }

         instanceCount >>= (int)this.lFld;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 90.263F);
      FuzzerUtils.init((int[])iArrFld, (int)44029);
      vMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
