public class Test {
   public static final int N = 400;
   public static long instanceCount = -172524961L;
   public static double dFld = -49.11037;
   public static double[] dArrFld = new double[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2() {
      short var0 = 21596;
      instanceCount -= (long)var0;
      vMeth2_check_sum += (long)var0;
   }

   public static void vMeth1() {
      int var0 = -8;
      boolean var1 = true;
      boolean var2 = true;
      byte var3 = 5;
      int[][] var4 = new int[400][400];
      float var5 = 8.437F;
      short var6 = 32209;
      FuzzerUtils.init((int[][])var4, (int)3);
      var0 |= var0;
      int var7 = 1;

      while(true) {
         ++var7;
         if (var7 >= 288) {
            var4[(var0 >>> 1) % 400][(var7 >>> 1) % 400] |= var7;

            int var8;
            for(var8 = 16; var8 < 345; ++var8) {
               instanceCount -= -12L;
               instanceCount = 5L;
               var0 = var0;
            }

            instanceCount >>= var8;
            vMeth1_check_sum += (long)(var0 + var7 + Float.floatToIntBits(var5) + var6 + var8 + var3) + FuzzerUtils.checkSum(var4);
            return;
         }

         vMeth2();
         var0 *= (int)var5;
         instanceCount = (long)var7;
         dFld -= dFld;
         var6 += (short)((int)((long)var7 * instanceCount + (long)var6 - (long)var7));
         var5 *= (float)var7;
      }
   }

   public static void vMeth() {
      int var0 = 126;
      int var1 = 40630;
      boolean var2 = true;
      short var3 = -130;
      int var4 = 39783;
      int var5 = -4301;
      int var6 = -5;
      byte var7 = 9;
      float var8 = 0.748F;
      boolean var9 = true;
      var0 %= (int)((long)((float)(var1++) - var8) | 1L);
      vMeth1();
      var9 = var9;

      int var10;
      for(var10 = 1; 271 > var10; ++var10) {
         dFld += (double)instanceCount;

         for(var4 = 1; var4 < 6; ++var4) {
            switch (var10 % 1 + 59) {
               case 59:
                  for(var6 = 2; var6 > var4; var6 -= 3) {
                     var8 = (float)var7;
                     instanceCount = instanceCount;
                     var5 += var1;
                     var8 += 6.0F;
                     var9 = true;
                  }

                  if (var6 != 0) {
                     vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var8) + (var9 ? 1 : 0) + var10 + var3 + var4 + var5 + var6 + var7);
                     return;
                  }
            }

            dArrFld = dArrFld;
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var8) + (var9 ? 1 : 0) + var10 + var3 + var4 + var5 + var6 + var7);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -107;
      boolean var4 = true;
      short var5 = 210;
      int var6 = -10;
      int var7 = -28026;
      byte var8 = -7;
      int var9 = -134;
      int[] var10 = new int[400];
      float var11 = -2.213F;
      float var12 = 117.753F;
      long[] var13 = new long[400];
      FuzzerUtils.init((int[])var10, (int)-52);
      FuzzerUtils.init(var13, 4273287049834774936L);
      int var16 = 1;

      do {
         var3 *= (int)((double)(++var10[var16]) - (double)var11 * dFld * (double)((long)var3 - instanceCount));
         if (Math.max((long)(dFld * (double)instanceCount), (long)(var3++ * (var10[var16] = (int)instanceCount))) == (long)(var3++)) {
            vMeth();

            try {
               var3 = -13135 % var16;
               var3 = 3139 % var3;
               var3 = var16 % -27682;
            } catch (ArithmeticException var15) {
            }
         }

         ++var16;
      } while(var16 < 382);

      byte var18 = 111;
      var3 = var18 << var18;
      var3 *= var3;
      var11 *= (float)var16;
      var10 = var10;

      int var17;
      label50:
      for(var17 = 9; var17 < 178; ++var17) {
         var10[var17 + 1] <<= (int)instanceCount;
         var5 = 101;
         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 148) {
               var13[var17] = (long)var11;

               for(var7 = 7; var7 < 148; ++var7) {
                  var3 += -5 + var7 * var7;
                  var3 -= var3;
                  instanceCount += (long)(var7 + var8);
                  var11 *= 8.0F;
               }

               var9 = 1;

               while(true) {
                  ++var9;
                  if (var9 >= 148) {
                     instanceCount = (long)var16;
                     var10[var17 - 1] += 11;
                     continue label50;
                  }

                  var12 -= var11;
               }
            }

            var11 *= -6.0F;
         }
      }

      FuzzerUtils.out.println("i i1 f = " + var16 + "," + var3 + "," + Float.floatToIntBits(var11));
      FuzzerUtils.out.println("i14 i15 i16 = " + var17 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i17 i18 i19 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("f3 iArr lArr = " + Float.floatToIntBits(var12) + "," + FuzzerUtils.checkSum(var10) + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.dArrFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, -53.37468);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
