public class Test {
   public static final int N = 400;
   public static long instanceCount = 31092L;
   public boolean bFld = false;
   public static float fFld = 2.355F;
   public static int iFld = -14;
   public static double dFld = 0.9752;
   public static short sFld = 3781;
   public int iFld1 = 391;
   public static double[] dArrFld = new double[400];
   public static volatile float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(long var0, byte var2) {
      boolean var3 = true;
      int var4 = 37992;
      int var5 = -7;
      int var6 = 254;
      boolean var7 = true;
      byte var8 = 4;
      int[][] var9 = new int[400][400];
      float var10 = -2.32F;
      short var11 = 11932;
      FuzzerUtils.init((int[][])var9, (int)99);

      int var12;
      for(var12 = 8; 197 > var12; ++var12) {
         var4 = var4;

         for(var5 = 8; var5 > 1; --var5) {
            var4 >>= (int)instanceCount;
            var6 = (int)instanceCount;
         }

         var10 += (float)var12;
         short var13 = 19178;
         var6 = var13 - (int)var10;
         var0 += (long)var12 ^ (long)var10;
         var4 = var11;
         var0 *= (long)var5;
      }

      int var14;
      for(var14 = 2; var14 < 304; ++var14) {
         var9[var14][var14] += var8;
         instanceCount += (long)(var14 ^ var5);
         var4 -= var4;
      }

      vMeth2_check_sum += var0 + (long)var2 + (long)var12 + (long)var4 + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var10) + (long)var11 + (long)var14 + (long)var8 + FuzzerUtils.checkSum(var9);
   }

   public void vMeth1(float var1) {
      boolean var2 = true;
      int var3 = 53410;
      int var4 = -118;
      int var5 = -5944;
      int[][][] var6 = new int[400][400][400];
      byte var7 = 60;
      double var8 = -1.10406;
      long[] var10 = new long[400];
      FuzzerUtils.init(var10, 0L);
      FuzzerUtils.init((Object[][])var6, -13);
      vMeth2(instanceCount, (byte)113);
      instanceCount += -9L;
      var10 = var10;

      int var13;
      for(var13 = 12; var13 < 244; ++var13) {
         var3 += var13 - var3;
         if (!this.bFld) {
            instanceCount = (long)var3;
            var3 = var3;

            for(var4 = var13; var4 < 7; ++var4) {
               try {
                  var5 = var4 % var5;
                  var5 = 139 / var5;
                  var6[var4][var13 - 1][var13 + 1] = var5 / -21;
               } catch (ArithmeticException var12) {
               }

               var6[var13][var13] = FuzzerUtils.int1array(400, 9);
               var10[var13] += (long)var13;
               if (this.bFld) {
                  var5 = 1;
               } else {
                  var3 += (int)var8;
               }
            }
         }
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var1) + var13 + var3 + var4 + var5 + var7) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum((Object[][])var6);
   }

   public void vMeth(int var1) {
      boolean var2 = true;
      int var3 = 54;
      int var4 = 37188;
      byte var5 = -3;
      int var6 = -1;
      int[] var7 = new int[400];
      FuzzerUtils.init((int[])var7, (int)-4);
      this.vMeth1(fFld);
      instanceCount += (long)var1;
      var1 /= var1 | 1;
      iFld = (int)instanceCount;

      int var8;
      for(var8 = 2; 149 > var8; ++var8) {
         float[] var10000 = fArrFld;
         var10000[var8] -= (float)iFld;

         for(var4 = 11; var4 > 1; --var4) {
            var7[var8 - 1] -= -34288;
            var7 = FuzzerUtils.int1array(400, -12);
         }

         var6 = 1;

         do {
            dFld += (double)var5;
            ++var6;
         } while(var6 < 11);

         var3 += var3;
         fFld -= (float)var4;
      }

      var3 += sFld;
      vMeth_check_sum += (long)(var1 + var8 + var3 + var4 + var5 + var6) + FuzzerUtils.checkSum(var7);
   }

   public void mainTest(String[] var1) {
      int var2 = 33;
      boolean var3 = true;
      int var4 = -45;
      int var5 = -9;
      int var6 = 6;
      byte var7 = 4;
      int var8 = 11;
      int var9 = -2;
      int[] var10 = new int[400];
      byte var11 = 70;
      byte[] var12 = new byte[400];
      boolean[] var13 = new boolean[400];
      FuzzerUtils.init((byte[])var12, (byte)14);
      FuzzerUtils.init((int[])var10, (int)-55);
      FuzzerUtils.init(var13, true);
      var2 = -(var2 * -Math.max(var2, var2));
      int var14 = 1;

      while(true) {
         var14 += 2;
         if (var14 >= 237) {
            FuzzerUtils.out.println("i i1 by2 = " + var2 + "," + var14 + "," + var11);
            FuzzerUtils.out.println("i18 i19 i20 = " + var4 + "," + var5 + "," + var6);
            FuzzerUtils.out.println("i21 i22 i23 = " + var7 + "," + var8 + "," + var9);
            FuzzerUtils.out.println("byArr iArr3 bArr = " + FuzzerUtils.checkSum(var12) + "," + FuzzerUtils.checkSum(var10) + "," + FuzzerUtils.checkSum(var13));
            FuzzerUtils.out.println("Test.instanceCount bFld Test.fFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
            FuzzerUtils.out.println("Test.iFld Test.dFld Test.sFld = " + iFld + "," + Double.doubleToLongBits(dFld) + "," + sFld);
            FuzzerUtils.out.println("iFld1 Test.dArrFld Test.fArrFld = " + this.iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         this.vMeth(0);
         var11 += (byte)var2;

         for(var4 = 212; 1 < var4; --var4) {
            var5 -= (int)fFld;
            var5 += var4;
            switch ((var5 >>> 1) % 2 * 5 + 110) {
               case 116:
                  instanceCount ^= (long)var6;
                  var2 = var6;
                  instanceCount <<= iFld;
                  iFld = 52943;
                  break;
               case 119:
                  switch (var4 % 2 + 124) {
                     case 124:
                        var6 += var4 * var4;

                        for(var8 = var4; var8 < 2; ++var8) {
                           switch (var8 % 2 + 109) {
                              case 109:
                                 var12[var8 - 1] = (byte)(var12[var8 - 1] * 13);
                                 var11 += (byte)var8;
                                 instanceCount += instanceCount;
                                 break;
                              case 110:
                                 var11 -= (byte)var7;
                                 var9 -= 3;
                                 var9 *= var6;
                                 break;
                              default:
                                 var6 -= var5;
                                 instanceCount += -8L;
                           }

                           var2 = (int)((float)var2 + ((float)(var8 * var4 + var7) - fFld));
                           var10 = FuzzerUtils.int1array(400, 4639);
                           instanceCount -= instanceCount;
                           fFld -= (float)var5;
                           var5 = var9;
                           this.iFld1 -= 114;
                        }
                     case 125:
                        var13[var14] = true;
                        continue;
                  }
               default:
                  instanceCount += instanceCount;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 1.37436);
      FuzzerUtils.init(fArrFld, -87.315F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
