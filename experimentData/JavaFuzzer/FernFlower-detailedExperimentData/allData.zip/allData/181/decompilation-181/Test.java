public class Test {
   public static final int N = 400;
   public static long instanceCount = 65317L;
   public static double dFld = 1.31994;
   public static boolean bFld = true;
   public static float fFld = 0.377F;
   public static int iFld = -33496;
   public byte byFld = -122;
   public static int iFld1 = 250;
   public boolean bFld1 = true;
   public static int[] iArrFld = new int[400];
   public static byte[][] byArrFld = new byte[400][400];
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth() {
      boolean var0 = true;
      int var1 = -84;
      int var2 = -122;
      int var3 = -61610;
      int var4 = -8246;
      byte var5 = -52;
      long[] var6 = new long[400];
      boolean[] var7 = new boolean[400];
      float[] var8 = new float[400];
      FuzzerUtils.init(var6, 8407702357601404726L);
      FuzzerUtils.init(var7, true);
      FuzzerUtils.init(var8, 1.184F);
      fFld = (float)iFld;
      iFld <<= -128;

      int var11;
      for(var11 = 391; var11 > 11; --var11) {
         iFld = iFld;
         var2 = 1;

         do {
            iFld = var2;

            for(var3 = 1; var3 < 4; ++var3) {
               var1 += var4;
               var6 = FuzzerUtils.long1array(400, -7L);
               var7[var11] = bFld;
            }

            switch (var2 % 5 + 103) {
               case 103:
                  var4 = var11;
                  var5 >>= (byte)((int)instanceCount);
                  iFld = 42462;
                  int[] var10000 = iArrFld;
                  var10000[var11] += -2;
                  break;
               case 104:
                  var1 = var4;
                  break;
               case 105:
                  iFld %= var11 | 1;
                  break;
               case 106:
                  var8[var11] += fFld;
                  break;
               case 107:
                  var4 += var2 * var2;
            }

            var2 += 3;
         } while(var2 < 4);
      }

      long var9 = (long)(var11 + var1 + var2 + var3 + var4 + var5) + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public static long lMeth(int var0) {
      boolean var1 = true;
      int var2 = -5;
      int var3 = 5896;
      int var4 = -21814;
      short var5 = 213;
      int[] var6 = new int[400];
      float var7 = -10.491F;
      byte var8 = 69;
      byte[] var9 = new byte[400];
      FuzzerUtils.init((int[])var6, (int)-227);
      FuzzerUtils.init(var9, (byte)-1);
      var0 &= var0--;

      int var12;
      for(var12 = 4; 356 > var12; ++var12) {
         var2 += var12 * var12;

         for(var7 = 5.0F; var7 > 1.0F; --var7) {
            instanceCount = (long)(Math.min(var12, var12) / (var6[var12 + 1] | 1) * var9[(int)var7]);
            if (bFld) {
               var0 -= var3;

               for(var4 = (int)var7; var4 < 2; ++var4) {
                  if (bFld == (var2 == iMeth())) {
                     var3 |= (int)(-((double)(instanceCount++) - (double)instanceCount * dFld));
                  } else {
                     var6[(int)(var7 - 1.0F)] = iFld;
                     var2 = var2;
                  }

                  var8 += (byte)((int)instanceCount);
                  instanceCount *= (long)iFld;
                  var3 += var4 * var4;
               }
            }
         }
      }

      long var10 = (long)(var0 + var12 + var2 + Float.floatToIntBits(var7) + var3 + var4 + var5 + var8) + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var9);
      lMeth_check_sum += var10;
      return var10;
   }

   public static void vMeth(byte var0, byte var1) {
      boolean var2 = true;
      int var3 = 40641;
      int var4 = 97;
      int[][] var5 = new int[400][400];
      double var6 = -16.17851;
      FuzzerUtils.init((int[][])var5, (int)-11101);
      lMeth(iFld);
      iFld = (int)instanceCount;
      dFld *= -30.0;

      int var8;
      for(var8 = 1; var8 < 173; ++var8) {
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 9) {
               byArrFld = byArrFld;
               break;
            }

            iFld >>= -3;
            var6 = 1.0;

            do {
               int[] var10000 = iArrFld;
               var10000[(int)(var6 - 1.0)] >>= iFld;
               var5 = var5;
               iFld = var3;
            } while(++var6 < 1.0);

            var5[var8 + 1] = FuzzerUtils.int1array(400, 4);
            instanceCount *= (long)dFld;
            fFld *= (float)var3;
            var3 += var4 * iFld + var0 - var4;
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var8 + var3 + var4) + Double.doubleToLongBits(var6) + FuzzerUtils.checkSum(var5);
   }

   public void mainTest(String[] var1) {
      boolean var2 = false;
      int var3 = 61;
      int var4 = 61;
      int var5 = 6;
      short var6 = 18687;
      byte var7 = 12;
      byte var8 = -14;
      short var9 = -228;
      int var10 = 0;
      boolean[][] var11 = new boolean[400][400];
      long[][] var12 = new long[400][400];
      FuzzerUtils.init(var11, true);
      FuzzerUtils.init(var12, -60058L);
      vMeth(this.byFld, this.byFld);
      fFld -= (float)iFld;

      int var13;
      for(var13 = 3; var13 < 275; ++var13) {
         if (bFld) {
            var11[var13][var13 - 1] = bFld;
            var12[var13][var13] += (long)fFld;
         } else if (bFld) {
            var3 &= iFld1;
            var12[var13][var13] = (long)iFld1;
            var4 = 92;

            do {
               iFld = var4;
               iFld1 += (int)fFld;
               byte[] var10000 = byArrFld[var13];
               var10000[var13 + 1] <<= (byte)var13;
               int[] var14 = iArrFld;
               var14[var4] <<= (int)instanceCount;
               var14 = iArrFld;
               var14[var4 - 1] *= 7;
               --var4;
            } while(var4 > 0);
         } else if (bFld) {
            bFld = bFld;
         }

         iFld += (int)dFld;
         if (bFld) {
            break;
         }

         var3 -= (int)instanceCount;
         instanceCount -= 191L;

         for(var5 = 5; var5 < 92; ++var5) {
            if (bFld) {
            }
         }

         var10 = var3;
      }

      FuzzerUtils.out.println("i14 i15 i16 = " + var13 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i17 i18 i19 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i20 i21 i22 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("bArr1 lArr1 = " + FuzzerUtils.checkSum(var11) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.fFld Test.iFld byFld = " + Float.floatToIntBits(fFld) + "," + iFld + "," + this.byFld);
      FuzzerUtils.out.println("Test.iFld1 bFld1 Test.iArrFld = " + iFld1 + "," + (this.bFld1 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.byArrFld = " + FuzzerUtils.checkSum(byArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)194);
      FuzzerUtils.init((byte[][])byArrFld, (byte)6);
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
