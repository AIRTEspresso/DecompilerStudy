public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 4L;
   public static double dFld = -1.116122;
   public static float fFld = -24.797F;
   public static short sFld = -3192;
   public static boolean bFld = false;
   public static volatile byte byFld = 101;
   public static long iMeth_check_sum = 0L;
   public static long fMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;

   public static void vMeth() {
      boolean var0 = true;
      int var1 = -4;
      int var2 = 7;
      int[] var3 = new int[400];
      long[] var4 = new long[400];
      boolean[] var5 = new boolean[400];
      FuzzerUtils.init(var4, 1535816565L);
      FuzzerUtils.init((int[])var3, (int)158);
      FuzzerUtils.init(var5, false);

      int var10;
      for(var10 = 7; var10 < 246; ++var10) {
         var4[var10 - 1] = (long)var10;
         var1 += var10 * var10;
         var2 = 1;

         while(true) {
            ++var2;
            if (var2 >= 7) {
               break;
            }

            var3[var10] = var10;

            try {
               var3[var2 - 1] = -54826 / var2;
               var1 = var2 / var2;
               var1 = var3[var2] % var10;
            } catch (ArithmeticException var9) {
            }

            var3[var2 - 1] >>= (int)instanceCount;
            var1 *= (int)instanceCount;
            var1 -= (int)dFld;

            try {
               var3[var10] = var2 / -5462;
               var1 = 619 % var1;
               var1 = '胿' % var3[var10 - 1];
            } catch (ArithmeticException var8) {
            }

            var5[var10] = false;
            switch (var10 % 3 * 5 + 2) {
               case 3:
               case 6:
                  fFld += (float)(98 + var2 * var2);
                  var1 <<= var2;
                  instanceCount &= instanceCount;
               case 5:
                  try {
                     var1 %= var1;
                     var1 /= 21370;
                     var1 = var10 / 148821730;
                  } catch (ArithmeticException var7) {
                  }
                  break;
               case 4:
               default:
                  var1 += var2;
            }
         }
      }

      vMeth_check_sum += (long)(var10 + var1 + var2) + FuzzerUtils.checkSum(var4) + FuzzerUtils.checkSum(var3) + FuzzerUtils.checkSum(var5);
   }

   public static float fMeth(long var0) {
      boolean var2 = true;
      int var3 = -166;
      int[] var4 = new int[400];
      float var5 = 0.584F;
      float[] var6 = new float[400];
      FuzzerUtils.init(var6, 0.269F);
      FuzzerUtils.init((int[])var4, (int)199);
      vMeth();

      int var9;
      for(var9 = 3; 189 > var9; ++var9) {
         var3 += var9 - var3;
         var6[var9 - 1] = (float)var3;
      }

      var5 = 1.0F;

      do {
         dFld += (double)var9;
         fFld = (float)var3;
         var3 <<= 60455486;
         var3 += (int)((long)var5 | (long)fFld);
         var4 = var4;
         var3 += var9;
         var3 -= var9;
         var3 -= var9;
         var3 *= var3;
         sFld <<= (short)var9;
      } while(++var5 < 304.0F);

      long var7 = var0 + (long)var9 + (long)var3 + (long)Float.floatToIntBits(var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var6)) + FuzzerUtils.checkSum(var4);
      fMeth_check_sum += var7;
      return (float)var7;
   }

   public static int iMeth(int var0) {
      int var1 = 36820;
      int var2 = 234;
      boolean var3 = true;
      byte var4 = -13;
      int[] var5 = new int[400];
      short var6 = 6559;
      short[] var7 = new short[400];
      long[] var8 = new long[400];
      FuzzerUtils.init((int[])var5, (int)-36);
      FuzzerUtils.init(var8, 1290L);
      FuzzerUtils.init((short[])var7, (short)22764);
      int[] var9 = var5;
      int var10 = var5.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var12 = var9[var11];
         int var10002 = (var12 >>> 1) % 400;
         int var10004 = var5[(var12 >>> 1) % 400];
         var5[var10002] = var5[(var12 >>> 1) % 400] + 1;
         var0 >>= var10004;
         instanceCount = Math.max((long)(fMeth(instanceCount) + (float)var0), instanceCount);

         for(var1 = 1; var1 < 4; ++var1) {
            var2 += (int)instanceCount;
            var5 = var5;
            var0 <<= var12;
            sFld = -33;
         }

         instanceCount = instanceCount;
         instanceCount |= instanceCount;
         var8 = var8;
         if (bFld) {
         }
      }

      int var13;
      for(var13 = 2; 237 > var13; ++var13) {
         var2 = (int)((float)var2 + (float)var13 + fFld);
         var7[var13] &= var6;
      }

      long var14 = (long)(var0 + var1 + var2 + var13 + var4 + var6) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var7);
      iMeth_check_sum += var14;
      return (int)var14;
   }

   public void mainTest(String[] var1) {
      int var2 = 6;
      int var3 = -23733;
      int var4 = -250;
      int var5 = -14;
      int var6 = 89;
      int var7 = 55;
      int var8 = 11;
      int[] var9 = new int[400];
      long var10 = -3198898865L;
      long[] var12 = new long[400];
      boolean[][] var13 = new boolean[400][400];
      FuzzerUtils.init(var12, -19L);
      FuzzerUtils.init((int[])var9, (int)0);
      FuzzerUtils.init(var13, true);
      iMeth(var2);
      long[] var14 = var12;
      int var15 = var12.length;

      for(int var16 = 0; var16 < var15; ++var16) {
         long var17 = var14[var16];

         for(var3 = 2; var3 < 63; ++var3) {
            var12[(var2 >>> 1) % 400] -= (long)var2;
            int var10000 = var2 * var3;
            var2 = (int)instanceCount;
            switch (var3 % 2 * 5 + 62) {
               case 64:
                  var5 /= 11;
                  var10000 = var4 + var3 + sFld;
                  break;
               case 70:
               default:
                  var9[var3 + 1] += (int)instanceCount;
                  fFld -= -4.0F;
                  var5 = (int)fFld;
            }

            var9[var3] = var3;
            var5 += var3 | sFld;
            var4 = 57696;

            for(var6 = 1; var6 < 2; ++var6) {
               var9 = var9;
               switch (var6 + 122) {
                  case 122:
                     var17 = (long)((float)var17 + ((float)(var6 * var5 + var5) - fFld));
                     var2 = (int)fFld;
                     var9[var3 - 1] >>>= var7;
                     dFld -= (double)var7;
                     break;
                  case 123:
                     var5 += var6 * var3;
                     var2 &= (int)instanceCount;
                     break;
                  case 124:
                     switch ((var5 >>> 1) % 10 + 52) {
                        case 52:
                           var9[var3] = var3;
                           var4 = 178;
                           var2 -= 72;
                           var17 *= (long)fFld;
                           break;
                        case 53:
                           var2 %= (int)(instanceCount | 1L);
                           break;
                        case 54:
                        case 55:
                           var7 = (int)((long)var7 + ((long)var6 - instanceCount));
                           break;
                        case 56:
                           var9[var6 - 1] += (int)dFld;
                        case 57:
                           var7 += var6 + var6;
                           break;
                        case 58:
                           fFld *= (float)var5;
                           break;
                        case 59:
                           instanceCount = (long)dFld;
                           break;
                        case 60:
                           dFld += (double)var5;
                           break;
                        case 61:
                           instanceCount += (long)(var6 + var7);
                     }
                  case 125:
                     var9[var6] |= var2;
                     break;
                  case 126:
                     var9[var6] = -14;
                  case 127:
                     bFld = bFld;
                  case 128:
                     var5 = (int)((long)var5 + ((long)(var6 * var3) + var17 - (long)var2));
                     break;
                  case 129:
                     var2 += var6 * var2 + var8 - var8;
                     break;
                  case 130:
                     try {
                        var10000 = var2 % var6;
                        var5 /= var3;
                        var8 = var9[var3 + 1] / var3;
                     } catch (ArithmeticException var20) {
                     }
                  case 131:
                  default:
                     break;
                  case 132:
                     var2 += var6;
                  case 133:
                     var10 = (long)var5;
                     break;
                  case 134:
                     var12[var6] -= (long)fFld;
                     break;
                  case 135:
                     dFld = (double)fFld;
                     break;
                  case 136:
                     var12[var3] *= -74L;
                     break;
                  case 137:
                     dFld = (double)var7;
                     break;
                  case 138:
                     var2 <<= var2;
                  case 139:
                     var5 += 99;
                     break;
                  case 140:
                     var10 += (long)(var6 | var3);
                  case 141:
                     var12[var6] &= var17;
                     break;
                  case 142:
                     var2 = var3;
                  case 143:
                     var8 >>= 69;
                     break;
                  case 144:
                     var5 = 60370;
                     break;
                  case 145:
                  case 146:
                     sFld += (short)((int)instanceCount);
                  case 147:
                     sFld = (short)(sFld & -1);
                     break;
                  case 148:
                     var17 >>= var7;
                     break;
                  case 149:
                     fFld -= (float)var10;
                     break;
                  case 150:
                     var8 = var6;
                     break;
                  case 151:
                     dFld *= (double)var17;
                     break;
                  case 152:
                     fFld *= (float)var8;
                     break;
                  case 153:
                     var7 += var2;
                     break;
                  case 154:
                     var4 += (int)var17;
                     break;
                  case 155:
                     instanceCount -= 6161L;
                     break;
                  case 156:
                     instanceCount <<= -12972;
                  case 157:
                     fFld += (float)(var6 * var5 + var7 - var7);
                     break;
                  case 158:
                     var13[var3][var3 + 1] = bFld;
                  case 159:
                     var4 -= var6;
                     break;
                  case 160:
                     var9[var6] = (int)var10;
                     break;
                  case 161:
                     var4 -= (int)var10;
                     break;
                  case 162:
                     var5 += (int)(-1.329F + (float)(var6 * var6));
                     break;
                  case 163:
                     var4 = 5;
                     break;
                  case 164:
                     var2 -= 50415;
                     break;
                  case 165:
                     var17 += 1583L;
                     break;
                  case 166:
                     sFld = (short)var2;
                     break;
                  case 167:
                     var10 = -236L;
                  case 168:
                     var8 += var6 - var8;
                     break;
                  case 169:
                     sFld = (short)(sFld + 18698);
                     break;
                  case 170:
                     var4 = 195304623;
                     break;
                  case 171:
                     var12[var3] = (long)var3;
                     break;
                  case 172:
                     var7 += (int)(105L + (long)(var6 * var6));
                     break;
                  case 173:
                     fFld *= (float)var5;
                     break;
                  case 174:
                     var5 -= var4;
                  case 175:
                     var7 = var5;
                  case 176:
                     var7 += var6 * var6;
                     break;
                  case 177:
                     var17 += (long)byFld;
                     break;
                  case 178:
                     var8 <<= var3;
                  case 179:
                     var2 -= var8;
                     break;
                  case 180:
                     var12[var3] = (long)var2;
                     break;
                  case 181:
                     var8 ^= var6;
                     break;
                  case 182:
                     var9[var3 + 1] = 208;
                     break;
                  case 183:
                     var12[var3] = 10L;
                     break;
                  case 184:
                     var9[var3 + 1] *= var8;
                  case 185:
                     sFld <<= -4623;
                     break;
                  case 186:
                     bFld = bFld;
                     break;
                  case 187:
                     if (bFld) {
                        break;
                     }
                  case 188:
                     var12[var6 - 1] -= 178L;
                     break;
                  case 189:
                     dFld = (double)var4;
                  case 190:
                     var17 -= (long)var5;
                  case 191:
                     fFld += (float)((long)var6 - var17);
               }
            }
         }
      }

      FuzzerUtils.out.println("i11 i12 i13 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i14 i15 i16 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i17 l2 lArr2 = " + var8 + "," + var10 + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("iArr3 bArr1 = " + FuzzerUtils.checkSum(var9) + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.sFld Test.bFld Test.byFld = " + sFld + "," + (bFld ? 1 : 0) + "," + byFld);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
