public class Test {
   public static final int N = 400;
   public static long instanceCount = 3167832886L;
   public static int iFld = 8;
   public static float fFld = 1.288F;
   public static double dFld = -3.67625;
   public static float[] fArrFld = new float[400];
   public long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(short var0) {
      int var1 = 13;
      boolean var2 = true;
      int var3 = 197;
      int var4 = 0;
      boolean var5 = true;
      short var6 = 233;
      int var7 = 13;
      int var8 = -1;
      int[] var9 = new int[400];
      double var10 = -76.68049;
      boolean var12 = false;
      long[] var13 = new long[400];
      FuzzerUtils.init((int[])var9, (int)38);
      FuzzerUtils.init(var13, 970730100L);
      iFld -= var1;

      int var14;
      for(var14 = 6; var14 < 128; ++var14) {
         var4 = 1;

         do {
            var9[var14] *= (int)fFld;
            ++var4;
         } while(var4 < 13);
      }

      var10 -= -60664.0;
      instanceCount -= (long)iFld;

      int var15;
      for(var15 = 6; var15 < 183; ++var15) {
         switch (var15 % 9 + 47) {
            case 47:
               var13[var15] = instanceCount;
               var1 *= (int)fFld;
               var3 = (int)((long)var3 + ((long)var15 ^ instanceCount));
            case 48:
               for(var7 = 1; var7 < 9; ++var7) {
                  var13[var15 - 1] -= 5L;
               }

               var3 *= (int)instanceCount;
            case 49:
               var8 = 34;
               break;
            case 50:
               iFld >>>= 23821;
               break;
            case 51:
            case 52:
               var12 = var12;
               break;
            case 53:
               iFld = var14;
            case 54:
               var3 -= var1;
               break;
            case 55:
               var8 = (int)((float)var8 + ((float)(var15 * var8) + fFld - (float)var7));
               break;
            default:
               iFld = 8;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var14 + var3 + var4) + Double.doubleToLongBits(var10) + (long)var15 + (long)var6 + (long)var7 + (long)var8 + (long)(var12 ? 1 : 0) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var13);
   }

   public static void vMeth(int var0, int var1) {
      short var2 = -30748;
      vMeth1(var2);
      var0 |= iFld;
      vMeth_check_sum += (long)(var0 + var1 + var2);
   }

   public static int iMeth(int var0) {
      boolean var1 = true;
      byte var2 = 11;
      int var3 = 11;
      byte var4 = -11;
      long var5 = 2247622150L;
      double var7 = 0.118598;
      float[] var9 = new float[400];
      FuzzerUtils.init(var9, 1.73F);

      int var12;
      for(var12 = 4; var12 < 323; ++var12) {
         var5 = 1L;

         do {
            vMeth(iFld, var0);
            var9[(int)var5] += -207.0F;
            instanceCount = (long)var12;
            iFld -= (int)var5;

            for(var3 = 1; var3 < 1; ++var3) {
               instanceCount -= (long)var4;
               iFld += iFld;
               instanceCount *= var5;
               iFld += (int)var7;
               iFld &= var12;
               instanceCount += (long)(var3 * var3);
            }
         } while(++var5 < 5L);
      }

      long var10 = (long)(var0 + var12 + var2) + var5 + (long)var3 + (long)var4 + Double.doubleToLongBits(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
      iMeth_check_sum += var10;
      return (int)var10;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -9;
      int var4 = -14;
      int var5 = -22081;
      int var6 = -48658;
      byte var7 = -124;
      short var8 = -10242;
      boolean var9 = true;
      byte var10 = 70;
      int var11 = 15088;
      int[] var12 = new int[400];
      short var13 = 32408;
      double var14 = -1.7699;
      boolean var16 = true;
      byte var17 = 95;
      FuzzerUtils.init((int[])var12, (int)12);
      var12 = var12;
      iFld <<= iFld -= var12[(iFld >>> 1) % 400];

      int var20;
      for(var20 = 14; var20 < 295; ++var20) {
         try {
            var3 = 28353 / var20;
            iFld = var12[var20 - 1] / -62267;
            var3 = 204 / iFld;
         } catch (ArithmeticException var19) {
         }

         var3 -= (int)((long)iMeth(iFld) + instanceCount);
         var12[var20] = -5;

         for(var4 = 5; var4 < 89; ++var4) {
            fArrFld[var4] = (float)instanceCount;
            instanceCount >>= var4;
            var5 *= var13;
            iFld -= var20;
            var3 = var20;
         }
      }

      var3 += var4;

      for(var6 = 6; 395 > var6; ++var6) {
         this.lArrFld[var6] = (long)dFld;
      }

      for(var14 = 2.0; var14 < 370.0; ++var14) {
         fFld = (float)var13;
         var7 = var7;
         instanceCount -= (long)var3;
      }

      instanceCount -= (long)var6;

      int var21;
      for(var21 = 14; var21 < 317; ++var21) {
         var11 = 1;

         do {
            fFld += (float)var5;
            var3 >>= var20;
            if (var16) {
               break;
            }

            instanceCount = (long)var4;
            var10 = var17;
            fFld = (float)var13;
            iFld = var11;
            iFld /= var3 | 1;
            ++var11;
         } while(var11 < 83);
      }

      FuzzerUtils.out.println("i i1 i17 = " + var20 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i18 s2 i19 = " + var5 + "," + var13 + "," + var6);
      FuzzerUtils.out.println("i20 d2 i21 = " + var7 + "," + Double.doubleToLongBits(var14) + "," + var8);
      FuzzerUtils.out.println("i22 i23 i24 = " + var21 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("b1 by iArr = " + (var16 ? 1 : 0) + "," + var17 + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.dFld Test.fArrFld lArrFld = " + Double.doubleToLongBits(dFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 71.1013F);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
