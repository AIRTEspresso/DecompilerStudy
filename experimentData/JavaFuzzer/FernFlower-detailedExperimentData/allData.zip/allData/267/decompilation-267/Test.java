public class Test {
   public static final int N = 400;
   public static long instanceCount = 43L;
   public static double dFld = 1.7067;
   public static volatile boolean bFld = false;
   public static double[][] dArrFld = new double[400][400];
   public static int[] iArrFld = new int[400];
   public static volatile long[] lArrFld = new long[400];
   public byte[][] byArrFld = new byte[400][400];
   public static long lMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(int var0) {
      boolean var1 = true;
      int var2 = 197;
      int var3 = -7;
      int var4 = -21;
      int var5 = -1643;
      int var6 = 63323;
      boolean var7 = false;
      boolean var8 = true;
      float var9 = 103.462F;

      int var12;
      for(var12 = 2; 160 > var12; ++var12) {
         for(var3 = 1; 10 > var3; ++var3) {
            dFld -= (double)instanceCount;
            var4 += (int)dFld;

            for(var5 = 1; var5 < 2; ++var5) {
               if (var0 != 0) {
               }

               double[] var10000 = dArrFld[var5];
               var10000[var12] *= (double)instanceCount;
            }

            var6 += var3 * var4 + var0 - var12;
         }

         var2 = var6;
         if (var7) {
         }
      }

      byte var13 = (byte)((int)instanceCount);
      iArrFld[(var12 >>> 1) % 400] = var5;
      var6 = (int)var9;
      lArrFld[(var5 >>> 1) % 400] = instanceCount;
      long var10 = (long)(var0 + var12 + var2 + var3 + var4 + var5 + var6 + (var7 ? 1 : 0) + var13 + Float.floatToIntBits(var9));
      iMeth_check_sum += var10;
      return (int)var10;
   }

   public static void vMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      char var4 = 'ꎡ';
      int var5 = -2;
      int var6 = 37738;
      double var7 = 68.129823;
      float var9 = -2.928F;
      instanceCount += (long)var2;

      int var10;
      for(var10 = 7; var10 < 146; ++var10) {
         var0 = var1++;
         if (bFld) {
            var7 -= (double)iMeth(var0);
            long[] var11 = lArrFld;
            var11[(var2 >>> 1) % 400] >>= var4;
         }

         bFld = true;
         int[] var12 = iArrFld;
         var12[var10 + 1] &= (int)instanceCount;
         var9 -= (float)var1;
         var2 >>= -186;
         if (var0 != 0) {
            vMeth_check_sum += (long)(var0 + var1 + var2 + var10 + var4) + Double.doubleToLongBits(var7) + (long)Float.floatToIntBits(var9) + (long)var5 + (long)var6;
            return;
         }

         for(var5 = 1; var5 < 11; ++var5) {
            var1 = var0;
            if (var10 != 0) {
               vMeth_check_sum += (long)(var0 + var0 + var2 + var10 + var4) + Double.doubleToLongBits(var7) + (long)Float.floatToIntBits(var9) + (long)var5 + (long)var6;
               return;
            }

            var6 = 1118122118;
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var10 + var4) + Double.doubleToLongBits(var7) + (long)Float.floatToIntBits(var9) + (long)var5 + (long)var6;
   }

   public static long lMeth(long var0, int var2) {
      int var3 = 9;
      short var4 = 17008;
      char var5 = '鉣';
      int var6 = 43607;
      byte var7 = -7;
      int var8 = 6;
      char var9 = 1;
      long var10 = -2480036132L;
      byte var12 = 118;
      vMeth(var2, var2, var2);
      var2 >>= (int)instanceCount;
      var2 *= -71;

      try {
         lArrFld[(var2 >>> 1) % 400] = 31923L;
         var2 = (int)dFld;

         for(var3 = 3; 334 > var3; ++var3) {
            for(var10 = 1L; var10 < 5L; ++var10) {
               for(var6 = 1; var6 < 2; ++var6) {
                  instanceCount = (long)var5;
               }

               for(var8 = (int)var10; 2 > var8; var8 += 2) {
                  int[] var10000 = iArrFld;
                  var10000[(int)(var10 - 1L)] -= var12;
                  iArrFld = iArrFld;
                  var9 = var5;
                  var4 = 85;
               }
            }
         }
      } catch (NullPointerException var15) {
         var0 += -12L;
      }

      long var13 = var0 + (long)var2 + (long)var3 + (long)var4 + var10 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var12;
      lMeth_check_sum += var13;
      return var13;
   }

   public void mainTest(String[] var1) {
      double var2 = 0.4767;
      int var4 = -119;
      boolean var5 = true;
      int var6 = 0;
      int var7 = -60776;
      int var8 = -1;
      int var9 = 0;
      int var10 = -4329;
      int var11 = -13;
      int var12 = 6;
      float var13 = 2.519F;
      float[] var14 = new float[400];
      boolean[] var15 = new boolean[400];
      FuzzerUtils.init(var15, false);
      FuzzerUtils.init(var14, -40.79F);
      var2 = (double)lMeth(instanceCount, var4);

      int var16;
      for(var16 = 7; var16 < 162; ++var16) {
         var13 += (float)(var16 * var4 + var6 - var4);
         switch (15) {
            case 9:
               var6 >>= var4;
               instanceCount = instanceCount;
               break;
            case 10:
               var4 = (int)((long)var4 + ((long)(var16 * var16 + var6) - instanceCount));
               var6 = var16;
               break;
            case 11:
               var4 = (int)((long)var4 + ((long)var16 * instanceCount + (long)var6 - (long)var4));
               var7 = 1;

               do {
                  switch (var7 % 8 * 5 + 103) {
                     case 106:
                        var13 = (float)var7;
                        break;
                     case 111:
                        instanceCount >>= var16;
                        break;
                     case 112:
                        var15[var16 + 1] = bFld;
                        this.byArrFld[var7 + 1] = this.byArrFld[var7];

                        for(var8 = 1; var8 < 1; ++var8) {
                           var9 = var7;
                           var10 += var8;
                           var10 += var8 * var8;
                           byte[] var18 = this.byArrFld[var8];
                           var18[var8 - 1] *= (byte)var7;
                        }

                        var4 += var7 ^ var10;
                        break;
                     case 115:
                     case 124:
                        var6 += var7;
                        var9 = (int)instanceCount;
                        int[] var10000 = iArrFld;
                        var10000[var7 - 1] ^= var10;
                     case 114:
                        var14[var7 + 1] = (float)var16;

                        for(var11 = 1; 1 > var11; ++var11) {
                           int var17 = var6 + var10;
                           var4 += var11 * var16;
                           var6 = var16;
                        }
                     case 140:
                        var4 += var8;
                        break;
                     case 126:
                        var9 += 99 + var7 * var7;
                     default:
                        instanceCount <<= var16;
                  }

                  ++var7;
               } while(var7 < 162);
               break;
            case 12:
               var4 *= -62298;
            case 13:
               var9 = 852093173;
               break;
            case 14:
               instanceCount -= instanceCount;
            case 15:
               instanceCount = (long)var6;
               break;
            case 16:
            case 17:
               var13 = (float)var11;
               break;
            case 18:
               var12 += var16 * var16;
         }
      }

      FuzzerUtils.out.println("d i22 i23 = " + Double.doubleToLongBits(var2) + "," + var4 + "," + var16);
      FuzzerUtils.out.println("i24 f2 i25 = " + var6 + "," + Float.floatToIntBits(var13) + "," + var7);
      FuzzerUtils.out.println("i26 i27 i28 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i29 i30 bArr = " + var11 + "," + var12 + "," + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.dArrFld Test.iArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("byArrFld = " + FuzzerUtils.checkSum(this.byArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 91.129012);
      FuzzerUtils.init((int[])iArrFld, (int)5);
      FuzzerUtils.init(lArrFld, -7418724081430529930L);
      lMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
