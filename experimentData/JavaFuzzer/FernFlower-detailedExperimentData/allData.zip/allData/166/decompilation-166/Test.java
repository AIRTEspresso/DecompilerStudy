public class Test {
   public static final int N = 400;
   public static long instanceCount = 55909L;
   public volatile byte byFld = 21;
   public static boolean bFld = true;
   public double dFld = -1.87946;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long bMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(float var0, boolean var1) {
      int var2 = -12;
      short var3 = 30000;
      var2 -= var3;
      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + (var1 ? 1 : 0) + var2 + var3);
   }

   public static boolean bMeth() {
      boolean var0 = true;
      int var1 = -10;
      int var2 = -4;
      int var3 = 11;
      float var4 = 1.889F;
      float[] var5 = new float[400];
      boolean var6 = false;
      double var7 = -1.113372;
      double var9 = -2.122995;
      short var11 = -14312;
      FuzzerUtils.init(var5, 4.362F);

      int var14;
      int[] var10000;
      for(var14 = 217; var14 > 4; --var14) {
         var1 += var14;
         vMeth(var4, var6);
         instanceCount += (long)(var14 * var1 + var14 - var1);
         var1 += 119;
         var10000 = iArrFld;
         var10000[var14 - 1] += (int)instanceCount;
      }

      var1 = (int)instanceCount;
      switch ((var14 >>> 1) % 10 + 18) {
         case 18:
            var10000 = iArrFld;
            var10000[5] %= (int)(instanceCount | 1L);
            var7 = 1.0;

            do {
               double var12 = -2.34221;
               var12 = (double)var14;

               for(var2 = 1; var2 < 7; ++var2) {
                  instanceCount <<= var14;
                  var1 *= var11;
                  var6 = var6;
               }
            } while(++var7 < 215.0);
         case 19:
            var4 += (float)instanceCount;
            break;
         case 20:
            var1 += var14;
         case 21:
            var9 *= (double)instanceCount;
            break;
         case 22:
         case 23:
            var4 = var4;
         case 24:
            var1 += (int)instanceCount;
         case 25:
         case 26:
            var9 -= (double)instanceCount;
         case 27:
            var3 += 53102;
            break;
         default:
            var5[(var2 >>> 1) % 400] = (float)instanceCount;
      }

      long var15 = (long)(var14 + var1 + Float.floatToIntBits(var4) + (var6 ? 1 : 0)) + Double.doubleToLongBits(var7) + (long)var2 + (long)var3 + (long)var11 + Double.doubleToLongBits(var9) + Double.doubleToLongBits(FuzzerUtils.checkSum(var5));
      bMeth_check_sum += var15;
      return var15 % 2L > 0L;
   }

   public int iMeth(int var1) {
      double var2 = 2.47596;
      int var4 = 41874;
      int var5 = -5;
      int var6 = -3;
      int var7 = 14;
      long[][] var8 = new long[400][400];
      FuzzerUtils.init(var8, -3609588869374174902L);
      instanceCount = (long)iArrFld[(var1 >>> 1) % 400] * (long)var1 * instanceCount + (instanceCount = --instanceCount);

      label47:
      for(var2 = 10.0; var2 < 164.0; ++var2) {
         var8 = FuzzerUtils.long2array(400, -745058389391775611L);
         var8[(int)var2][(int)(var2 + 1.0)] -= (long)(var4--);
         bMeth();
         var1 -= (int)var2;
         var5 = 1;

         while(true) {
            label42:
            while(true) {
               ++var5;
               if (var5 >= 10) {
                  continue label47;
               }

               var1 += var5 - var5;
               var4 = this.byFld;
               switch ((int)(var2 % 10.0 * 5.0 + 116.0)) {
                  case 120:
                     var1 = -29;
                     break;
                  case 123:
                     var7 += var5;
                     break;
                  case 124:
                  case 160:
                     var4 *= this.byFld;
                  case 121:
                     var1 += var5 * var6 + var7 - var7;
                     break;
                  case 127:
                     instanceCount = (long)var4;
                     var6 = 1;

                     while(true) {
                        if (var6 >= 1) {
                           continue label42;
                        }

                        var4 &= var1;
                        var1 += var6 ^ var5;
                        if (bFld) {
                           continue label42;
                        }

                        ++var6;
                     }
                  case 131:
                     bFld = bFld;
                     break;
                  case 162:
                     var7 += (int)instanceCount;
                     break;
                  case 163:
                     instanceCount &= (long)var6;
                  case 135:
                     this.byFld += (byte)var7;
               }
            }
         }
      }

      long var9 = (long)var1 + Double.doubleToLongBits(var2) + (long)var4 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void mainTest(String[] var1) {
      int var2 = -236;
      boolean var3 = true;
      int var4 = -25;
      boolean var5 = true;
      int var6 = 0;
      int var7 = 175;
      int var8 = -13;
      int var9 = 5;
      int var10 = -229;
      int var11 = 29903;
      int var12 = -10;
      byte var13 = -14;
      float var14 = 0.553F;
      short var15 = 29954;
      instanceCount = (long)this.iMeth(var2);
      instanceCount = instanceCount;

      int var16;
      for(var16 = 183; var16 > 5; --var16) {
         var2 -= this.byFld;
      }

      int var17;
      for(var17 = 13; var17 < 352; ++var17) {
         this.dFld -= 209.0;
         var2 -= (int)var14;
         bFld = false;

         for(var7 = var17; var7 < 74; ++var7) {
            var2 >>= -27937;
            var2 -= var7;

            for(var9 = 1; var9 < 1; ++var9) {
               if (!bFld) {
                  var14 += (float)var9;
                  var6 = (int)instanceCount;
                  var10 = var4;
                  if (bFld) {
                     var11 &= (int)instanceCount;
                     int var10000 = var4 + (int)(-34808L + (long)(var9 * var9));
                     var8 += (int)(-14L + (long)(var9 * var9));
                     var11 *= 145;
                  }

                  var4 = 2;
                  var8 += (int)this.dFld;
               }
            }

            for(var12 = 1; 1 > var12; ++var12) {
               instanceCount = (long)var11;
               instanceCount -= (long)var15;
               if (!bFld) {
                  var15 -= (short)((int)instanceCount);
                  instanceCount = 182L;
               }
            }

            var4 = (int)((long)var4 + ((long)(var7 * var8) + instanceCount - (long)var4));
         }
      }

      FuzzerUtils.out.println("i10 i11 i12 = " + var2 + "," + var16 + "," + var4);
      FuzzerUtils.out.println("i13 i14 f2 = " + var17 + "," + var6 + "," + Float.floatToIntBits(var14));
      FuzzerUtils.out.println("i15 i16 i17 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i18 i19 i20 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("i21 s2 = " + var13 + "," + var15);
      FuzzerUtils.out.println("Test.instanceCount byFld Test.bFld = " + instanceCount + "," + this.byFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("dFld Test.iArrFld = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(iArrFld, -64100);
      iMeth_check_sum = 0L;
      bMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
