public class Test {
   public static final int N = 400;
   public static long instanceCount = -1332573968L;
   public static float fFld = 7.613F;
   public static short sFld = 9739;
   public static byte byFld = 41;
   public static double dFld = -2.128732;
   public static boolean bFld = true;
   public static volatile int iFld = 28865;
   public static long vMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(long var0, int var2) {
      boolean var3 = true;
      int var4 = -27186;
      int var5 = -33291;
      byte var6 = -10;
      int var7 = 30;
      byte var8 = 7;
      float[] var9 = new float[400];
      FuzzerUtils.init(var9, 73.434F);

      int var10;
      for(var10 = 3; 242 > var10; var10 += 3) {
         for(var5 = 1; var5 < 19; var5 += 3) {
            var0 |= 238L;
            var4 >>= var10;
            var2 += (int)fFld;
            byFld = (byte)((int)var0);
         }

         if (bFld) {
            var4 += var10;
            sFld >>= -143;

            for(var7 = 19; 1 < var7; var7 -= 2) {
               var0 = (long)dFld;
               var0 >>= var6;
               if (bFld) {
                  break;
               }

               var0 += (long)var7;
               if (var2 != 0) {
                  vMeth1_check_sum += var0 + (long)var2 + (long)var10 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
                  return;
               }
            }
         } else {
            var9[(var5 >>> 1) % 400] *= (float)var6;
         }
      }

      vMeth1_check_sum += var0 + (long)var2 + (long)var10 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
   }

   public static int iMeth(int var0, int var1) {
      boolean var2 = true;
      int var3 = 51248;
      int var4 = 101;
      int var5 = -23606;
      boolean var6 = true;
      int var7 = -16542;
      int var8 = -58896;
      int[] var9 = new int[400];
      FuzzerUtils.init(var9, -38440);
      var9[(var1 >>> 1) % 400] -= Math.abs(var1 / (var0 | 1) + var1 + sFld);
      var1 = (int)(instanceCount - (long)var1 - (long)(++var9[(var1 >>> 1) % 400]));

      int var13;
      for(var13 = 6; var13 < 237; ++var13) {
         fFld += (float)var13;
         var0 -= 9;
         vMeth1(instanceCount, var0);

         for(var4 = 1; var4 < 7; ++var4) {
            var1 += var4 * var0 + var1 - var5;
            fFld = (float)var5;
         }

         var0 += var13 * var13;
      }

      sFld += (short)((int)fFld);

      int var14;
      for(var14 = 9; var14 < 266; ++var14) {
         var8 = 1;

         do {
            byFld = (byte)((int)instanceCount);

            try {
               var3 %= var4;
               var5 = var8 / var8;
               var7 = var14 / var9[var14 - 1];
            } catch (ArithmeticException var12) {
            }

            ++var8;
         } while(var8 < 6);
      }

      long var10 = (long)(var0 + var1 + var13 + var3 + var4 + var5 + var14 + var7 + var8) + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var10;
      return (int)var10;
   }

   public static void vMeth(int var0, long var1) {
      int var3 = -61669;
      int var4 = -152;
      int var5 = 0;
      byte var6 = 0;
      int var7 = 55;
      int var8 = 15770;
      int[][] var9 = new int[400][400];
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, 1.263F);
      FuzzerUtils.init((int[][])var9, (int)-12);
      if (bFld) {
         for(var3 = 7; var3 < 189; ++var3) {
            iMeth(var4, 2);

            for(var5 = 1; var5 < 9; ++var5) {
               var0 = var0;

               try {
                  var4 = var6 % 151;
                  var0 = var5 % 156;
                  var4 = 986784701 % var3;
               } catch (ArithmeticException var13) {
               }

               var10[var3 - 1] *= 7.0F;

               for(var7 = 2; var7 > 1; --var7) {
                  var0 = (int)((long)var0 + ((long)var7 - var1));
                  var9[var3 + 1] = var9[var7];
                  var1 = instanceCount;
                  var0 += var5;
                  var1 <<= (int)instanceCount;

                  try {
                     var8 = var3 % -23;
                     var0 = var5 / -37367;
                     var9[var5 + 1][var3 + 1] = var0 % var6;
                  } catch (ArithmeticException var12) {
                  }

                  var0 += var4;
               }
            }
         }
      } else if (bFld) {
         iFld -= sFld;
      }

      vMeth_check_sum += (long)var0 + var1 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var9);
   }

   public void mainTest(String[] var1) {
      int var2 = -16644;
      boolean var3 = true;
      int var4 = -32052;
      int var5 = 12;
      int var6 = -39497;
      int var7 = -13;
      int var8 = -53024;
      int var9 = -11;
      int[] var10 = new int[400];
      long[][][] var11 = new long[400][400][400];
      FuzzerUtils.init((int[])var10, (int)-16655);
      FuzzerUtils.init((Object[][])var11, -31221L);
      var2 += (int)(--fFld);
      vMeth(iFld, instanceCount);
      bFld = bFld;
      int var12 = 1;

      while(true) {
         label42:
         while(true) {
            ++var12;
            if (var12 >= 372) {
               FuzzerUtils.out.println("i i24 i25 = " + var2 + "," + var12 + "," + var4);
               FuzzerUtils.out.println("i26 i27 i28 = " + var5 + "," + var6 + "," + var7);
               FuzzerUtils.out.println("i29 i30 iArr2 = " + var8 + "," + var9 + "," + FuzzerUtils.checkSum(var10));
               FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum((Object[][])var11));
               FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
               FuzzerUtils.out.println("Test.byFld Test.dFld Test.bFld = " + byFld + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
               FuzzerUtils.out.println("Test.iFld = " + iFld);
               FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
               FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               return;
            }

            switch (var12 % 7 * 5 + 55) {
               case 59:
               case 89:
                  instanceCount &= (long)var12;
                  var2 -= (int)instanceCount;
                  var2 = (int)((long)var2 + ((long)var12 * instanceCount + (long)var12 - (long)var12));
                  break;
               case 62:
               case 81:
                  byFld -= (byte)((int)instanceCount);
                  break;
               case 64:
                  var9 -= var2;
                  break;
               case 67:
                  for(var4 = 2; var4 < 68; ++var4) {
                     bFld = bFld;
                     iFld = (int)dFld;
                     instanceCount = (long)var2;
                     var2 = (int)((float)var2 + ((float)var4 * fFld + (float)iFld - (float)var12));
                     var10 = var10;
                     var2 = 39212;
                     iFld = (int)fFld;

                     for(var6 = 1; var6 < 2; ++var6) {
                        iFld -= var4;
                        fFld += (float)var6;
                        var2 >>= -8;
                        var10[var6 - 1] = (int)instanceCount;
                        instanceCount >>= var7;
                        var7 = var6;
                        var5 = (int)((long)var5 + ((long)var6 * instanceCount + (long)iFld - instanceCount));
                        iFld += (int)instanceCount;
                        var11[var12][var12][var4 - 1] -= (long)var12;
                     }
                  }
               case 70:
                  break label42;
               default:
                  var2 = var8;
            }
         }

         for(var8 = 68; var8 > 1; var8 -= 2) {
            iFld += (int)dFld;
            fFld += (float)instanceCount;
            var2 = var6;
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
