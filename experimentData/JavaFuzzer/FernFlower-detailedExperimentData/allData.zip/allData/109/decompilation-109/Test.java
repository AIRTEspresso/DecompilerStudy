public class Test {
   public static final int N = 400;
   public static long instanceCount = -2045395048L;
   public byte byFld = -23;
   public static int iFld = 49267;
   public static volatile int iFld1 = 36669;
   public static short sFld = 27557;
   public static volatile float fFld = 1.39F;
   public static int[][] iArrFld = new int[400][400];
   public static float[] fArrFld = new float[400];
   public static long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(double var0) {
      iArrFld[(iFld >>> 1) % 400][(iFld >>> 1) % 400] = iFld;
      vMeth_check_sum += Double.doubleToLongBits(var0);
   }

   public static int iMeth1(byte var0, int var1) {
      double var2 = 0.6885;
      boolean var4 = true;
      int var5 = -169;
      int var6 = 149;
      short var7 = 31927;
      int var8 = 49957;
      int var9 = 39110;
      boolean var10 = false;
      vMeth(var2);

      int var13;
      for(var13 = 3; var13 < 149; ++var13) {
         int[] var10000;
         for(var6 = 11; 1 < var6; var6 -= 2) {
            var5 >>>= var7;
            iArrFld[var13] = iArrFld[var13 + 1];
            var10 = var10;
            lArrFld = lArrFld;
            instanceCount = instanceCount;
            var10000 = iArrFld[var6 - 1];
            var10000[var13 - 1] &= var7;
         }

         var1 += var13;

         for(var8 = 1; var8 < 11; ++var8) {
            iArrFld[var13][var13 + 1] = var13;
            instanceCount <<= iFld1;
            var9 -= 122;
            var10000 = iArrFld[var8 - 1];
            var10000[var8] -= -21208;
         }
      }

      long var11 = (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var13 + (long)var5 + (long)var6 + (long)var7 + (long)(var10 ? 1 : 0) + (long)var8 + (long)var9;
      iMeth1_check_sum += var11;
      return (int)var11;
   }

   public static int iMeth(int var0, int var1) {
      float var2 = -95.459F;
      boolean var3 = false;
      int var4 = -125;
      int var5 = -3;
      byte var6 = 76;
      byte var7 = -72;
      boolean var8 = true;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, 236L);
      float[] var10000 = fArrFld;
      var10000[(var1 >>> 1) % 400] += (float)(-87 - var1--);
      var9[(var0 >>> 1) % 400] *= (long)(((float)var1 + var2 + (float)instanceCount) * (float)iMeth1((byte)47, iFld1));
      var0 *= (int)var2;

      int var12;
      for(var12 = 17; var12 < 293; ++var12) {
         var4 >>= -14;
         sFld -= (short)((int)instanceCount);
         int[] var13;
         if (var8) {
            var4 = var4;
            var7 <<= (byte)iFld1;
            var7 = (byte)((int)instanceCount);

            for(var5 = 6; 1 < var5; var5 -= 2) {
               var4 = iFld;
               var13 = iArrFld[var5 - 1];
               var13[var12] += -983216869;
               iFld -= (int)instanceCount;
               var9 = var9;
            }
         } else if (var8) {
            var2 += (float)((long)var12 + instanceCount);
         } else {
            var13 = iArrFld[var12 + 1];
            var13[var12 - 1] /= sFld | 1;
         }
      }

      long var10 = (long)(var0 + var1 + Float.floatToIntBits(var2) + var12 + var4 + var7 + var5 + var6 + (var8 ? 1 : 0)) + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var10;
      return (int)var10;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -3;
      byte var4 = 11;
      int var5 = 29847;
      int var6 = -224;
      int var7 = -216;
      int var8 = -37466;
      int var9 = 9;
      long var10 = -6L;
      float var12 = -118.151F;
      boolean var13 = true;
      double[] var14 = new double[400];
      FuzzerUtils.init(var14, 0.111897);

      int var17;
      for(var17 = 325; var17 > 19; var17 -= 2) {
         for(var10 = (long)var17; 164L > var10; ++var10) {
            var3 += -iArrFld[(int)var10][(int)(var10 - 1L)] - (this.byFld + -32130) - var17 * iMeth(iFld, var4);
            sFld += (short)((int)(var10 * var10));
         }

         label69:
         for(var5 = 1; var5 < 164; ++var5) {
            iArrFld[var17] = iArrFld[var17 + 1];
            int[] var10000 = iArrFld[var17 - 1];
            var10000[var17] += (int)var10;
            var3 += var5;
            switch ((iFld1 >>> 1) % 9 * 5 + 35) {
               case 41:
               case 63:
                  instanceCount *= var10;
                  var7 = 1;

                  while(true) {
                     if (var7 >= 2) {
                        continue label69;
                     }

                     long[] var20 = lArrFld;
                     var20[var17] ^= 7L;
                     instanceCount += (long)(-50642 + var7 * var7);
                     var10000 = iArrFld[var5 - 1];
                     var10000[var7] += -36247;
                     var3 >>= var6;
                     ++var7;
                  }
               case 46:
                  instanceCount += (long)(var5 * var5);

                  try {
                     iArrFld[var17 - 1][var5 - 1] = var17 % -100;
                     iArrFld[var5][var17 + 1] = 2123209591 / iFld;
                     var6 = iArrFld[var17 + 1][var17] / 695888026;
                  } catch (ArithmeticException var16) {
                  }
               case 73:
                  var12 = 2.0F;

                  while(true) {
                     if (!(var12 > 1.0F)) {
                        continue label69;
                     }

                     var14[(int)var12] -= (double)var4;
                     int var19 = var6 + (int)(var12 - (float)var4);
                     switch (var5 % 2 * 5 + 124) {
                        case 134:
                           iArrFld[(int)(var12 + 1.0F)][var5 - 1] = var17;
                           iArrFld[var5 - 1] = iArrFld[var5 - 1];
                        case 132:
                           fFld = (float)instanceCount;
                           var3 += var8;
                           var3 >>= 4741;
                        default:
                           var3 = (int)instanceCount;
                           byte var18 = -12;
                           var6 = var18 + (int)((long)var12 ^ (long)var12);
                           --var12;
                     }
                  }
               case 52:
                  var8 -= var6;
               case 42:
                  instanceCount <<= var6;
                  break;
               case 55:
                  lArrFld[var5 - 1] = instanceCount;
                  break;
               case 70:
                  if (var13) {
                  }
                  break;
               case 78:
                  var9 = var8;
            }
         }
      }

      FuzzerUtils.out.println("i i1 l = " + var17 + "," + var3 + "," + var10);
      FuzzerUtils.out.println("i2 i16 i17 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i18 i19 f1 = " + var7 + "," + var8 + "," + Float.floatToIntBits(var12));
      FuzzerUtils.out.println("i20 b2 dArr = " + var9 + "," + (var13 ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)));
      FuzzerUtils.out.println("Test.instanceCount byFld Test.iFld = " + instanceCount + "," + this.byFld + "," + iFld);
      FuzzerUtils.out.println("Test.iFld1 Test.sFld Test.fFld = " + iFld1 + "," + sFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.iArrFld Test.fArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[][])iArrFld, (int)-140);
      FuzzerUtils.init(fArrFld, -2.671F);
      FuzzerUtils.init(lArrFld, -9098027689776070920L);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
