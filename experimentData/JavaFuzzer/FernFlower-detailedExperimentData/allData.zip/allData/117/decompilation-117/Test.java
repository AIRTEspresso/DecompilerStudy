public class Test {
   public static final int N = 400;
   public static long instanceCount = 49988L;
   public static int iFld = 14104;
   public static int iFld1 = -127;
   public static int[] iArrFld = new int[400];
   public static short[] sArrFld = new short[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2() {
      int var0 = -58723;
      int var1 = 9;
      byte var2 = -6;
      int var3 = -4;
      int var4 = 4;
      int[] var5 = new int[400];
      float var6 = 73.164F;
      float[] var7 = new float[400];
      FuzzerUtils.init(var7, 65.871F);
      FuzzerUtils.init((int[])var5, (int)-49);
      var0 = 1;

      while(true) {
         ++var0;
         if (var0 >= 276) {
            vMeth2_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var6)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + FuzzerUtils.checkSum(var5);
            return;
         }

         iFld = 50789;
         var7[var0] += (float)iFld;
         iFld = iFld;
         iFld = 737250344;
         var5[var0] = 214;
         iFld = var0;

         label27:
         for(var1 = 1; var1 < 6; ++var1) {
            instanceCount = (long)iFld1;
            var5[var1 + 1] *= (int)instanceCount;
            switch (var0 % 1 + 109) {
               case 109:
                  iFld = (int)instanceCount;
                  var3 = 1;

                  while(true) {
                     if (var3 >= 2) {
                        continue label27;
                     }

                     var6 = 2656.0F;
                     iFld |= var2;
                     ++var3;
                  }
               default:
                  var4 += (int)var6;
            }
         }
      }
   }

   public static void vMeth1() {
      int var0 = -3;
      boolean var1 = false;
      byte var2 = 6;
      int var3 = -41464;
      short var4 = 19521;
      int[] var5 = new int[400];
      float var6 = -1.2F;
      boolean var7 = true;
      long[] var8 = new long[400];
      FuzzerUtils.init((int[])var5, (int)29352);
      FuzzerUtils.init(var8, 1661686759729466649L);
      int var10000 = var0 - (int)var6;
      int var11 = 1;

      do {
         vMeth2();
         var0 = var2 + (int)instanceCount;
         var0 = 8;
         if (var7) {
            break;
         }

         var0 = iFld;
         var3 = 1;

         while(var3 < 9) {
            double var9 = -116.115108;
            var5[var11 - 1] -= -14;
            switch (var3 % 1 + 50) {
               case 50:
                  var8[var3 + 1] = (long)var2;
               default:
                  var9 = 8.0;
                  var7 = var7;
                  var6 += (float)var2;
                  ++var3;
            }
         }

         ++var11;
      } while(var11 < 185);

      vMeth1_check_sum += (long)(var0 + Float.floatToIntBits(var6) + var11 + var2 + (var7 ? 1 : 0) + var3 + var4) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var8);
   }

   public static void vMeth(int var0, int var1) {
      int var2 = -65397;
      int var3 = -6;
      boolean var4 = true;
      short var5 = -177;
      int var6 = 29118;
      byte var7 = 88;
      int var8 = 199;
      char var9 = '읟';
      double var10 = 0.4802;
      short[] var12 = new short[400];
      long[] var13 = new long[400];
      FuzzerUtils.init((short[])var12, (short)31517);
      FuzzerUtils.init(var13, -8434740146338999967L);
      vMeth1();

      for(var2 = 368; 5 < var2; var2 -= 2) {
         iFld1 ^= var3;
         iFld1 >>= var0;
         var12[var2 + 1] |= (short)((int)instanceCount);
         instanceCount += (long)var1;
      }

      int var10001 = (iFld1 >>> 1) % 400;
      var13[var10001] >>>= iFld1;
      var3 >>= var3;
      var10 = (double)var1;
      iArrFld = iArrFld;

      int var14;
      for(var14 = 4; var14 < 341; ++var14) {
         for(var6 = 1; var6 < 5; ++var6) {
            for(var8 = 2; var8 > 1; --var8) {
               iFld = var7;
               var0 = (int)instanceCount;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3) + Double.doubleToLongBits(var10) + (long)var14 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var13);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -7;
      boolean var4 = true;
      short var5 = -4396;
      int var6 = 118;
      int var7 = 10;
      int var8 = -253;
      int var9 = -12685;
      int var10 = 19835;
      short var11 = 247;
      boolean var12 = false;
      float var13 = 0.687F;
      short var14 = 3933;
      byte var15 = -46;
      long[] var16 = new long[400];
      FuzzerUtils.init(var16, -44435L);
      vMeth(iFld, 0);

      int var19;
      for(var19 = 9; var19 < 365; ++var19) {
         iFld1 <<= iFld1;
         instanceCount += (long)(var19 | iFld);
         instanceCount = (long)var3;
         iFld1 = iFld;
         instanceCount -= (long)var19;
      }

      iFld1 = var19;
      var16[(var19 >>> 1) % 400] *= (long)var3;
      var16[(var19 >>> 1) % 400] *= (long)var19;

      int var20;
      for(var20 = 374; var20 > 22; var20 -= 3) {
         for(var6 = 5; var6 < 214; ++var6) {
            for(var8 = var6; var8 < 2; ++var8) {
               instanceCount += (long)(var8 * var20 + var6 - iFld1);
               iArrFld[var20] = (int)instanceCount;
               iFld1 = var6;
               var7 += var8 - var7;
               iFld1 = (int)instanceCount;
               instanceCount = (long)iFld1;
               instanceCount = (long)iFld;
               instanceCount += (long)var8 * instanceCount + instanceCount - instanceCount;
               var9 *= var9;
            }

            instanceCount += (long)var3;

            try {
               iFld = iArrFld[var6] % '북';
               var3 = -207 % var5;
               iArrFld[var6 - 1] = -24542 % var9;
            } catch (ArithmeticException var18) {
            }

            var13 += (float)(var6 * var9 + var3 - var14);
         }

         for(var10 = 6; var10 < 214; ++var10) {
            var9 = 2;
            var15 *= (byte)var3;
            short[] var10000 = sArrFld;
            var10000[var10 - 1] >>>= (short)iFld1;
         }
      }

      FuzzerUtils.out.println("i20 i21 b1 = " + var19 + "," + var3 + "," + (var12 ? 1 : 0));
      FuzzerUtils.out.println("i22 i23 i24 = " + var20 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i25 i26 i27 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("f2 s i28 = " + Float.floatToIntBits(var13) + "," + var14 + "," + var10);
      FuzzerUtils.out.println("i29 by lArr2 = " + var11 + "," + var15 + "," + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
      FuzzerUtils.out.println("Test.iArrFld Test.sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)105);
      FuzzerUtils.init((short[])sArrFld, (short)20522);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
