public class Test {
   public static final int N = 400;
   public static long instanceCount = -62556L;
   public static volatile double dFld = -2.82475;
   public static byte byFld = 11;
   public static float fFld = -124.883F;
   public static short[] sArrFld = new short[400];
   public int[] iArrFld = new int[400];
   public long[][][] lArrFld = new long[400][400][400];
   public long[] lArrFld1 = new long[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, float var1) {
      boolean var2 = true;
      short var3 = 141;
      int var4 = 34626;
      short var5 = 5878;
      int var6 = -15212;
      byte var7 = -1;
      boolean var8 = true;
      short var9 = -11268;
      long[][] var10 = new long[400][400];
      FuzzerUtils.init(var10, -130L);
      dFld -= (double)instanceCount;
      byFld += (byte)((int)dFld);
      var0 += var0;

      int var11;
      for(var11 = 1; 181 > var11; ++var11) {
         if (var8) {
            dFld += (double)instanceCount;
         } else {
            for(var4 = 1; var4 < 9; ++var4) {
               var0 += -24 + var4 * var4;

               for(var6 = var4; var6 < 2; ++var6) {
                  var9 = (short)var6;
                  var10[var11][(var11 >>> 1) % 400] += (long)var4;
                  dFld = (double)var5;
                  sArrFld[var4] = 162;
                  short[] var10000 = sArrFld;
                  var10000[var4 + 1] &= (short)var7;
                  var0 = (int)instanceCount;
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var11 + var3 + (var8 ? 1 : 0) + var4 + var5 + var6 + var7 + var9) + FuzzerUtils.checkSum(var10);
   }

   public static int iMeth1(boolean var0, int var1, int var2) {
      int[] var3 = new int[400];
      FuzzerUtils.init((int[])var3, (int)12);
      vMeth(var1, fFld);
      var3[(var1 >>> 1) % 400] += var2;
      var1 -= 11;
      long var4 = (long)((var0 ? 1 : 0) + var1 + var2) + FuzzerUtils.checkSum(var3);
      iMeth1_check_sum += var4;
      return (int)var4;
   }

   public static int iMeth(byte var0) {
      boolean var1 = true;
      int var2 = -102;
      int var3 = 49280;
      int var4 = 91;
      int var5 = -149;
      int[] var6 = new int[400];
      float var7 = 79.444F;
      short var8 = -31119;
      boolean var9 = false;
      long[] var10 = new long[400];
      FuzzerUtils.init((int[])var6, (int)-8);
      FuzzerUtils.init(var10, 7L);

      int var14;
      for(var14 = 10; 352 > var14; ++var14) {
         var6[var14 - 1] -= var6[var14 + 1];

         label43:
         for(var3 = 5; var3 > 1; --var3) {
            instanceCount += (long)(var3 * var3);
            var2 = (int)((long)(var3 + var2 + --var6[var3]) + Math.max(var10[var3 - 1], (long)(var7 + (float)var0)));
            var2 += var3 ^ var14;
            var4 -= --var6[var14 - 1];
            var5 = 1;

            while(true) {
               ++var5;
               if (var5 >= 2) {
                  try {
                     var4 = var5 / var6[var3 + 1];
                     var2 = 1140166361 / var5;
                     var2 %= var3;
                  } catch (ArithmeticException var13) {
                  }

                  switch (var3 % 2 * 5 + 99) {
                     case 105:
                        var7 = (float)instanceCount;
                        continue label43;
                     case 107:
                        var6[var3 - 1] -= var4;
                        var2 = var3 & var14;
                        continue label43;
                     default:
                        var7 = (float)var5;
                        continue label43;
                  }
               }

               var0 -= (byte)(var8 += (short)((int)((float)iMeth1(var9, var5, var14) + fFld)));
            }
         }
      }

      long var11 = (long)(var0 + var14 + var2 + var3 + var4 + Float.floatToIntBits(var7) + var5 + var8 + (var9 ? 1 : 0)) + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public void mainTest(String[] var1) {
      int var2 = -54651;
      int var3 = 6;
      int var4 = -11716;
      int var5 = 11;
      int var6 = -32187;
      int var7 = -12;
      int var8 = 243;
      boolean var9 = false;
      long var10 = 3654779942L;
      short var12 = -26734;
      double[] var13 = new double[400];
      FuzzerUtils.init(var13, -21.37566);
      double[] var14 = var13;
      int var15 = var13.length;

      for(int var16 = 0; var16 < var15; ++var16) {
         double var17 = var14[var16];
         var2 += var2 * iMeth(byFld);

         for(var3 = 3; 63 > var3; ++var3) {
            int[] var10000 = this.iArrFld;
            var10000[var3 + 1] += 219;
            var9 = var9;
            var4 >>= byFld;
            instanceCount += (long)var3;
         }

         for(var10 = 3L; var10 < 63L; ++var10) {
            char var19 = '쾿';
            instanceCount -= (long)var4;
            var5 = 2;
            var2 = (int)fFld;
            label40:
            switch ((int)(var10 % 3L * 5L + 24L)) {
               case 27:
                  var2 += 64048;
               case 28:
               case 30:
               default:
                  break;
               case 29:
                  var6 = 1;

                  while(true) {
                     if (var6 >= 2) {
                        break label40;
                     }

                     byte var20 = 88;
                     var5 = (int)((long)var5 + ((long)var6 * var10 + (long)var4 - instanceCount));
                     var2 += var6;
                     byFld = (byte)(byFld | 12);
                     int var21 = var20 + var6;
                     var17 *= (double)var10;
                     var8 = var6++;
                  }
               case 31:
                  var5 = var12;
            }

            var9 = false;
            var8 &= 2;
            long[] var22 = this.lArrFld[(int)(var10 - 1L)][(int)(var10 + 1L)];
            var22[(int)var10] <<= var5;
            var7 = var2;
         }
      }

      dFld = (double)fFld;
      var5 += (int)instanceCount;
      var5 = (int)var10;
      FuzzerUtils.out.println("i i15 i16 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("b3 l i17 = " + (var9 ? 1 : 0) + "," + var10 + "," + var5);
      FuzzerUtils.out.println("i18 i19 i20 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("s2 dArr = " + var12 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
      FuzzerUtils.out.println("Test.fFld Test.sArrFld iArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("lArrFld lArrFld1 = " + FuzzerUtils.checkSum((Object[][])this.lArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld1));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(sArrFld, (short)-12561);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
