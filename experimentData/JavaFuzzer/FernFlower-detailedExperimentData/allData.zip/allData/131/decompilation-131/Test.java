public class Test {
   public static final int N = 400;
   public static long instanceCount = 7L;
   public byte byFld = -123;
   public static volatile int iFld = 7957;
   public static volatile double dFld = -65.26047;
   public static volatile float fFld = 0.954F;
   public static boolean bFld = true;
   public static short sFld = -12381;
   public static double[] dArrFld = new double[400];
   public static int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0, long var1, int var3) {
      boolean var4 = false;
      byte var5 = -46;
      boolean var6 = true;
      int var7 = 31316;
      int var8 = 6;
      int var9 = 31185;
      byte var10 = -11;
      boolean var11 = false;
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, -4L);

      int var15;
      for(var15 = 2; var15 < 355; var15 += 3) {
         var1 -= -12L;
      }

      int var16 = 1;

      while(true) {
         int[] var17;
         do {
            ++var16;
            if (var16 >= 333) {
               long var13 = (long)var0 + var1 + (long)var3 + (long)var15 + (long)var5 + (long)var16 + (long)var7 + (long)var8 + (long)(var11 ? 1 : 0) + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var12);
               lMeth_check_sum += var13;
               return var13;
            }

            for(var7 = 5; var7 > 1; --var7) {
               var0 = var5;
               var3 = var5;
               var8 *= var16;
               double[] var10000 = dArrFld;
               var10000[var16] -= (double)iFld;
               var17 = iArrFld;
               var17[var16 + 1] *= (int)var1;
               var12[var16 - 1] = (long)dFld;
            }
         } while(var11);

         var17 = iArrFld;
         var17[var16 - 1] -= var3;

         for(var9 = 1; var9 < 5; ++var9) {
            instanceCount += (long)var10;
            var8 ^= (int)instanceCount;
         }
      }
   }

   public static int iMeth(double var0, long var2, int var4) {
      boolean var5 = true;
      int var6 = -11;
      short var7 = -3294;
      int var8 = -6215;
      byte var9 = 4;
      byte var10 = -72;
      int var13 = 1;

      while(true) {
         ++var13;
         if (var13 >= 341) {
            long var11 = Double.doubleToLongBits(var0) + var2 + (long)var4 + (long)var13 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10;
            iMeth_check_sum += var11;
            return (int)var11;
         }

         int[] var10000;
         if (bFld) {
            lMeth(var4, instanceCount, iFld);
            var10000 = iArrFld;
            var10000[var13] -= (int)fFld;
         }

         for(var6 = 1; var6 < 5; ++var6) {
            for(var8 = var6; var8 < 2; ++var8) {
               var10000 = iArrFld;
               var10000[var6 + 1] <<= var7;
               var10 += (byte)var9;
               if (bFld) {
                  switch ((var4 >>> 1) % 2 + 118) {
                     case 118:
                        iFld += (int)instanceCount;
                        fFld += (float)(var8 * var6);
                        break;
                     case 119:
                        fFld = (float)var9;
                        fArrFld[var13 - 1] = (float)dFld;
                        iFld += var8;
                        break;
                     default:
                        instanceCount = (long)var0;
                  }
               } else {
                  var0 -= (double)var7;
               }
            }
         }
      }
   }

   public static void vMeth(int var0, int var1, float var2) {
      byte var3 = -66;
      int var4 = 47371;
      boolean var5 = true;
      int var6 = -36219;
      int var7 = -13950;
      byte var8 = 32;
      double var9 = -34.9041;
      boolean[][][] var11 = new boolean[400][400][400];
      FuzzerUtils.init((Object[][])var11, true);
      var0 -= (int)(dArrFld[2] * (double)(var3--));
      var4 = 1;

      do {
         var3 = (byte)iMeth(-1.90511, instanceCount, iFld);
         var2 += (float)((long)var4 ^ (long)var4);
         ++var4;
      } while(var4 < 228);

      iFld <<= var1;

      int var12;
      for(var12 = 14; var12 < 224; ++var12) {
         dFld += (double)iFld;
         instanceCount = -1L;
         var9 = 1.0;

         do {
            for(var7 = 1; var7 < 1; ++var7) {
               switch (var12 % 5 + 16) {
                  case 16:
                     bFld = bFld;
                     sFld = (short)((int)fFld);
                     break;
                  case 17:
                     instanceCount = (long)var12;
                     var11 = var11;
                     break;
                  case 18:
                     var0 = (int)instanceCount;
                     break;
                  case 19:
                     instanceCount -= -61L;
                     break;
                  case 20:
                  default:
                     if (bFld) {
                     }
               }
            }
         } while(++var9 < 8.0);
      }

      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + var3 + var4 + var12 + var6) + Double.doubleToLongBits(var9) + (long)var7 + (long)var8 + FuzzerUtils.checkSum((Object[][])var11);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -17202;
      int var4 = -11;
      int var5 = -12903;
      int var6 = 7;
      int var7 = 198;
      int var8 = -8;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, -2L);
      int var10 = 1;

      while(true) {
         while(true) {
            ++var10;
            if (var10 >= 264) {
               FuzzerUtils.out.println("i i23 i24 = " + var10 + "," + var3 + "," + var4);
               FuzzerUtils.out.println("i25 i26 i27 = " + var5 + "," + var6 + "," + var7);
               FuzzerUtils.out.println("i28 lArr1 = " + var8 + "," + FuzzerUtils.checkSum(var9));
               FuzzerUtils.out.println("Test.instanceCount byFld Test.iFld = " + instanceCount + "," + this.byFld + "," + iFld);
               FuzzerUtils.out.println("Test.dFld Test.fFld Test.bFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
               FuzzerUtils.out.println("Test.sFld Test.dArrFld Test.iArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
               FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
               FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
               FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               return;
            }

            this.byFld -= (byte)(19819 * var10);
            switch (((int)(instanceCount - (long)var10) >>> 1) % 9 + 54) {
               case 54:
                  vMeth(-39985, -172, fFld);
                  iFld += var10;
                  break;
               case 55:
                  instanceCount = (long)this.byFld;
                  break;
               case 56:
                  iFld <<= var10;

                  for(var3 = 5; var3 < 95; var3 += 2) {
                     for(var5 = 1; 3 > var5; ++var5) {
                        var4 -= (int)fFld;
                        var4 += this.byFld;
                        dFld = (double)var10;
                        var6 = this.byFld;
                        var4 <<= var10;
                        instanceCount = instanceCount;
                        iFld += -95 + var5 * var5;
                        this.byFld = (byte)var3;
                     }

                     instanceCount = (long)sFld;

                     for(var7 = 1; var7 < 3; ++var7) {
                        var4 >>= (int)instanceCount;
                        dFld = (double)iFld;
                        var8 -= var5;
                        iArrFld[var3 - 1] = (int)dFld;
                        var9[var10 + 1] += instanceCount;
                     }

                     var6 -= (int)instanceCount;
                     var4 -= var6;
                     int[] var11 = iArrFld;
                     var11[var3] *= var5;
                     fArrFld[var10 - 1] = (float)var3;
                  }
                  break;
               case 57:
                  float[] var10000 = fArrFld;
                  var10000[var10] *= (float)this.byFld;
                  break;
               case 58:
               case 59:
                  fFld -= (float)var8;
               case 60:
                  var6 += var10 * var7;
               case 61:
                  iArrFld = FuzzerUtils.int1array(400, 10);
                  break;
               case 62:
                  var6 -= (int)instanceCount;
                  break;
               default:
                  fFld -= (float)var6;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 2.93474);
      FuzzerUtils.init((int[])iArrFld, (int)61183);
      FuzzerUtils.init(fArrFld, -127.946F);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
