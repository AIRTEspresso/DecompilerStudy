public class Test {
   public static final int N = 400;
   public static long instanceCount = -73L;
   public static volatile int iFld = -39797;
   public static boolean bFld = true;
   public static double dFld = 3.15632;
   public static float fFld = -2.177F;
   public static byte byFld = 55;
   public int iFld1 = 8;
   public static short sFld = -7885;
   public static boolean bFld1 = true;
   public static long[] lArrFld = new long[400];
   public double[][][] dArrFld = new double[400][400][400];
   public int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(double var0) {
      boolean var2 = true;
      byte var3 = -10;
      int var4 = 136;
      int var5 = 130;
      int var6 = -8;
      int var7 = -43993;
      byte var8 = -6;
      int[] var9 = new int[400];
      double var10 = -41.96886;
      boolean[] var12 = new boolean[400];
      FuzzerUtils.init(var12, true);
      FuzzerUtils.init((int[])var9, (int)-198);

      int var13;
      for(var13 = 13; 268 > var13; ++var13) {
         for(var10 = 6.0; var10 > 1.0; --var10) {
            var4 *= -29920;
         }

         for(var5 = 1; var5 < 6; ++var5) {
            var12[var5] = bFld;
            iFld = (int)((long)iFld + ((long)var5 ^ instanceCount));
            instanceCount %= (long)(var13 | 1);

            for(var7 = 2; 1 < var7; var7 -= 3) {
               var9[var13 - 1] += var4;
               var4 = var5;
               instanceCount *= (long)var3;
               long[] var10000 = lArrFld;
               var10000[var13 + 1] >>= var13;
               var6 -= iFld;
               if (bFld) {
                  break;
               }

               var4 = var13;
            }
         }
      }

      vMeth2_check_sum += Double.doubleToLongBits(var0) + (long)var13 + (long)var3 + Double.doubleToLongBits(var10) + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var9);
   }

   public static void vMeth1(int var0) {
      int var1 = -59969;
      int var2 = 51840;
      int var3 = -9;
      short var4 = 21085;
      int var5 = -7;
      byte var6 = -12;
      int var7 = 51;
      byte var8 = 5;
      float[] var9 = new float[400];
      FuzzerUtils.init(var9, -2.782F);
      vMeth2(dFld);

      for(var1 = 11; var1 < 282; var1 += 3) {
         for(var3 = 1; var3 < 17; ++var3) {
            var9[(var1 >>> 1) % 400] += (float)var3;
            if (!bFld) {
               if (bFld) {
                  fFld = (float)var2;
               } else {
                  for(var5 = 1; var5 < 2; ++var5) {
                     lArrFld[var3 + 1] = (long)fFld;
                     iFld = (int)fFld;
                     lArrFld[var3 + 1] = (long)var2;
                  }

                  for(var7 = 1; var7 < 2; ++var7) {
                     var2 = (int)((float)var2 + ((float)var7 * fFld + (float)var2 - (float)instanceCount));
                     iFld = 58440;
                     if (bFld) {
                        break;
                     }
                  }
               }
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
   }

   public void vMeth(int var1, long var2, long var4) {
      boolean var6 = true;
      int var7 = -12;
      int var8 = 11;
      byte var9 = 64;
      int[] var10 = new int[400];
      double var11 = 101.56145;
      short var13 = 20639;
      FuzzerUtils.init((int[])var10, (int)4);
      var1 *= iFld;
      vMeth1(iFld);

      int var16;
      for(var16 = 10; var16 < 384; ++var16) {
         if (bFld) {
            iFld *= iFld;
         } else {
            var7 *= (int)fFld;
            var10[var16 - 1] = -89;
         }

         switch (var16 % 7 + 24) {
            case 24:
               iFld = iFld;
               var11 = 1.0;

               do {
                  for(var8 = 1; 1 > var8; ++var8) {
                     var13 = (short)(var13 * byFld);
                     var2 = (long)iFld;
                  }
               } while(++var11 < 5.0);
            case 25:
               try {
                  var10[var16 + 1] = var9 % var9;
                  var10[var16] = 30 / iFld;
                  var10[var16 + 1] = -1488794660 % var8;
               } catch (ArithmeticException var15) {
               }
               break;
            case 26:
               fFld -= (float)var8;
               break;
            case 27:
               if (var9 != 0) {
                  vMeth_check_sum += (long)var1 + var2 + var4 + (long)var16 + (long)var7 + Double.doubleToLongBits(var11) + (long)var8 + (long)var9 + (long)var13 + FuzzerUtils.checkSum(var10);
                  return;
               }
               break;
            case 28:
            case 29:
               iFld = 52293;
               break;
            case 30:
               byFld *= (byte)iFld;
               break;
            default:
               var13 = (short)((int)var4);
         }
      }

      vMeth_check_sum += (long)var1 + var2 + var4 + (long)var16 + (long)var7 + Double.doubleToLongBits(var11) + (long)var8 + (long)var9 + (long)var13 + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -5;
      int var4 = 10;
      byte var5 = 0;
      byte var6 = -13;
      int var7 = 6;
      char var8 = 'ﯚ';
      byte var9 = 10;
      int var10 = -9;
      float var11 = 4.56F;
      int var12 = 371;

      while(true) {
         --var12;
         if (var12 <= 0) {
            break;
         }

         var3 <<= --iFld + var3;
         this.vMeth(var12, -49L, instanceCount);
         double[] var10000 = this.dArrFld[var12 + 1][var12];
         var10000[var12 + 1] += (double)instanceCount;
         this.dArrFld[var12 + 1][var12 + 1][var12 + 1] = (double)var12;
         if (bFld) {
            break;
         }

         this.iArrFld[var12] = iFld;
         fFld += (float)var12;
         iFld = 30403;
      }

      if (bFld1) {
         for(var4 = 223; var4 > 9; var4 -= 3) {
            var7 -= (int)instanceCount;
         }
      } else {
         var10 -= (int)dFld;
      }

      FuzzerUtils.out.println("i i1 i24 = " + var12 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i25 i26 i27 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i28 i29 f = " + var8 + "," + var9 + "," + Float.floatToIntBits(var11));
      FuzzerUtils.out.println("i30 = " + var10);
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.dFld Test.fFld Test.byFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + byFld);
      FuzzerUtils.out.println("iFld1 Test.sFld Test.bFld1 = " + this.iFld1 + "," + sFld + "," + (bFld1 ? 1 : 0));
      FuzzerUtils.out.println("Test.lArrFld dArrFld iArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])this.dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 6L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
