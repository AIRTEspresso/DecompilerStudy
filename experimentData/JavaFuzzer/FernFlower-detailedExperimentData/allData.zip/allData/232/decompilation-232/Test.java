public class Test {
   public static final int N = 400;
   public static long instanceCount = 60531L;
   public double dFld = -104.96747;
   public boolean bFld = true;
   public static volatile byte byFld = 67;
   public int[][] iArrFld = new int[400][400];
   public static int[] iArrFld1 = new int[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = -68;
      int var2 = 272;
      int var3 = 89;
      int var4 = 196;
      double var5 = -2.27109;
      float var7 = -2.561F;
      long var8 = 7047316164572904437L;
      boolean var10 = true;
      short var11 = -2126;
      int var12 = 1;

      do {
         label41:
         switch ((var12 >>> 1) % 6 + 103) {
            case 103:
               if (var12 != 0) {
                  vMeth1_check_sum += (long)var12 + Double.doubleToLongBits(var5) + (long)Float.floatToIntBits(var7) + (long)var1 + (long)var2 + var8 + (long)var3 + (long)var4 + (long)(var10 ? 1 : 0) + (long)var11;
                  return;
               }

               var5 = (double)var7;
               var1 += var1;
               break;
            case 104:
               var2 = 1;

               while(true) {
                  ++var2;
                  if (var2 >= 5) {
                     break label41;
                  }

                  for(var8 = 1L; var8 < 1L; ++var8) {
                     var1 = (int)instanceCount;
                     var3 += (int)(var8 * (long)var1 + var8 - instanceCount);
                     instanceCount >>= var2;
                  }

                  var4 = 1;

                  while(true) {
                     var3 >>= var3;
                     var3 -= 206;
                     if (var10) {
                        break;
                     }

                     var3 = (int)((float)var3 + ((float)(var4 * var2 + var11) - var7));
                     ++var4;
                     if (var4 >= 1) {
                        break;
                     }
                  }
               }
            case 105:
               var3 = var2;
            case 106:
            case 107:
               var7 += (float)((long)(var12 * var12) + instanceCount - (long)var1);
               break;
            case 108:
               var11 += (short)(var12 * var12);
               break;
            default:
               var3 = var11;
         }

         ++var12;
      } while(var12 < 301);

      vMeth1_check_sum += (long)var12 + Double.doubleToLongBits(var5) + (long)Float.floatToIntBits(var7) + (long)var1 + (long)var2 + var8 + (long)var3 + (long)var4 + (long)(var10 ? 1 : 0) + (long)var11;
   }

   public static void vMeth(int var0) {
      long var1 = -374L;
      double var3 = -49.123755;
      double var5 = -37.22115;
      int var7 = 0;
      int var8 = 217;
      byte var9 = -8;
      float var10 = -15.14F;
      float[][][] var11 = new float[400][400][400];
      byte[] var12 = new byte[400];
      short[] var13 = new short[400];
      FuzzerUtils.init(var12, (byte)-116);
      FuzzerUtils.init(var13, (short)-5612);
      FuzzerUtils.init((Object[][])var11, -2.684F);
      instanceCount += Math.max(instanceCount, instanceCount) - (long)var12[(var0 >>> 1) % 400];
      var0 = var0++ - (int)((long)var0 * (instanceCount - (long)var0) + Math.abs(4269128188L * (long)var0));
      vMeth1();
      var0 *= var0;
      var0 = (int)instanceCount;
      var1 = 1L;

      do {
         var13[(int)(var1 + 1L)] -= (short)((int)var3);
         int[] var14 = iArrFld1;
         var14[(int)var1] <<= var0;

         for(var5 = 6.0; var5 > 1.0; --var5) {
            var11[(int)(var1 + 1L)][(int)(var5 - 1.0)][(int)(var1 + 1L)] *= 22826.0F;
            var7 += (int)(var5 * var5);

            for(var8 = 1; var8 < 2; ++var8) {
               instanceCount %= (long)(var9 | 1);
               instanceCount -= (long)var10;
            }
         }
      } while(++var1 < 283L);

      vMeth_check_sum += (long)var0 + var1 + Double.doubleToLongBits(var3) + Double.doubleToLongBits(var5) + (long)var7 + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var13) + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var11));
   }

   public static int iMeth(int var0, int var1, int var2) {
      int var3 = -62669;
      boolean var4 = true;
      short var5 = -183;
      int var6 = -4;
      int var7 = -58;
      byte var8 = 13;
      double var9 = 0.95156;
      float var11 = 34.384F;
      short var12 = -29931;
      long[] var13 = new long[400];
      byte[] var14 = new byte[400];
      FuzzerUtils.init(var13, -57635L);
      FuzzerUtils.init(var14, (byte)-29);
      var3 = 1;

      while(true) {
         ++var3;
         if (var3 >= 226) {
            var1 *= var2;

            int var17;
            for(var17 = 20; 354 > var17; ++var17) {
               var6 = 1;

               do {
                  for(var7 = var6; var7 < 1; ++var7) {
                     var1 -= var3;
                     var11 += (float)var7;
                  }

                  var11 += (float)var3;
                  var13[var17 - 1] -= (long)var12;
                  instanceCount += instanceCount;
                  ++var6;
               } while(var6 < 5);
            }

            long var15 = (long)(var0 + var1 + var2 + var3) + Double.doubleToLongBits(var9) + (long)var17 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var11) + (long)var12 + FuzzerUtils.checkSum(var13) + FuzzerUtils.checkSum(var14);
            iMeth_check_sum += var15;
            return (int)var15;
         }

         instanceCount = (long)(-(iArrFld1[var3]++));
         int var10002 = var3 - 1;
         long var10004 = var13[var3 - 1];
         var13[var10002] = var13[var3 - 1] - 1L;
         var2 *= (int)var10004;
         instanceCount = (long)(-14.0 + var9);
         vMeth(var3);
      }
   }

   public void mainTest(String[] var1) {
      float var2 = -12.851F;
      float[] var3 = new float[400];
      int var4 = -22373;
      int var5 = 241;
      int var6 = -6;
      int var7 = -6721;
      int var8 = 0;
      short[] var9 = new short[400];
      byte[] var10 = new byte[400];
      boolean[] var11 = new boolean[400];
      long[] var12 = new long[400];
      FuzzerUtils.init(var9, (short)-13660);
      FuzzerUtils.init((byte[])var10, (byte)102);
      FuzzerUtils.init(var11, true);
      FuzzerUtils.init(var12, 13L);
      FuzzerUtils.init(var3, 7.917F);
      var2 += (float)(this.dFld -= (double)(--this.iArrFld[(var4 >>> 1) % 400][(var4 >>> 1) % 400]));
      var4 /= iMeth(var4, var4, var4) + var4 | 1;
      int[] var13 = iArrFld1;
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         int var16 = var13[var15];
         if (this.bFld) {
            break;
         }

         label62:
         for(var5 = 1; var5 < 63; ++var5) {
            int[] var10000 = this.iArrFld[var5 + 1];
            var10000[var5 - 1] += var4;
            var4 += var5;
            byFld >>= (byte)var4;
            switch (var5 % 9 * 5 + 113) {
               case 129:
                  var16 -= 8;
                  break;
               case 130:
               case 131:
               case 132:
               case 134:
               case 135:
               case 136:
               case 138:
               case 139:
               case 140:
               case 141:
               case 142:
               case 145:
               case 146:
               case 147:
               case 148:
               case 149:
               case 150:
               case 152:
               case 154:
               case 156:
               case 157:
               default:
                  var4 = (int)this.dFld;
                  break;
               case 137:
                  var10000 = this.iArrFld[var5];
                  var10000[var5 + 1] += var16;
                  break;
               case 143:
                  var16 *= var7;
                  break;
               case 144:
                  var9[var5 + 1] *= (short)var5;
                  var7 = 1;

                  while(true) {
                     if (2 <= var7) {
                        continue label62;
                     }

                     var6 += (int)instanceCount;
                     if (!this.bFld) {
                        switch (83) {
                           case 51:
                              var6 += var7;
                              var2 += 10.0F;
                              var16 += var7 * var7;
                              break;
                           case 58:
                              var3[var5] = (float)this.dFld;
                              break;
                           case 64:
                              var10000 = iArrFld1;
                              var10000[var7 + 1] |= (int)instanceCount;
                              var16 = var7;
                              break;
                           case 67:
                              var16 *= var6;
                              break;
                           case 68:
                              var4 = var5;
                              break;
                           case 73:
                              var8 -= 213;
                              break;
                           case 77:
                              var10[var7] >>= (byte)((int)instanceCount);
                              var11[var7 + 1] = this.bFld;
                              var6 *= (int)this.dFld;
                              var12[var7 + 1] = instanceCount;
                           case 90:
                              instanceCount -= (long)var7;
                              var8 = (int)((long)var8 + ((long)(var7 * var5 + var6) - instanceCount));
                           case 83:
                              break;
                           default:
                              var6 += var8;
                        }
                     }

                     ++var7;
                  }
               case 151:
               case 153:
                  var6 -= var7;
               case 133:
                  var8 -= (int)instanceCount;
                  break;
               case 155:
                  var16 = var7;
                  break;
               case 158:
                  instanceCount += (long)(39 + var5 * var5);
            }
         }
      }

      FuzzerUtils.out.println("f i i20 = " + Float.floatToIntBits(var2) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i21 i22 i23 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("sArr1 byArr2 bArr = " + FuzzerUtils.checkSum(var9) + "," + FuzzerUtils.checkSum(var10) + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("lArr1 fArr1 = " + FuzzerUtils.checkSum(var12) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var3)));
      FuzzerUtils.out.println("Test.instanceCount dFld bFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.byFld iArrFld Test.iArrFld1 = " + byFld + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld1, (int)-14);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
