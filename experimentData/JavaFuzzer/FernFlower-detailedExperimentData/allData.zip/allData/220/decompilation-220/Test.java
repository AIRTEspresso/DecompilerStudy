public class Test {
   public static final int N = 400;
   public static long instanceCount = -4071716049L;
   public static byte byFld = -4;
   public static float fFld = 79.222F;
   public static double dFld = 126.128416;
   public static boolean bFld = true;
   public static int iFld = -5;
   public static int[] iArrFld = new int[400];
   public static long fMeth_check_sum;
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(double var0, int var2) {
      boolean var3 = true;
      int var4 = 14;
      int var5 = -6;
      int var6 = -13051;
      int[][] var7 = new int[400][400];
      long[] var8 = new long[400];
      FuzzerUtils.init((int[][])var7, (int)-186);
      FuzzerUtils.init(var8, -4L);

      int var11;
      for(var11 = 6; var11 < 205; ++var11) {
         instanceCount = (long)fFld;
         fFld += (float)instanceCount;
         var0 *= (double)instanceCount;

         for(var5 = 1; var5 < 8; ++var5) {
            var7[var11][var11] = (int)instanceCount;
            var2 = 2;
            var4 %= var2 | 1;
            var6 += (int)instanceCount;
            var4 += var4;
            instanceCount -= (long)var5;
            var4 -= 58143;
            dFld -= (double)var5;
         }

         if (var6 != 0) {
         }

         var8[var11 + 1] *= (long)var6;
      }

      long var9 = Double.doubleToLongBits(var0) + (long)var2 + (long)var11 + (long)var4 + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var8);
      iMeth1_check_sum += var9;
      return (int)var9;
   }

   public static int iMeth() {
      boolean var0 = true;
      int var1 = -181;
      short var2 = -177;
      int var3 = 48;
      int var4 = -51;
      int var7 = 1;

      while(true) {
         ++var7;
         if (var7 >= 252) {
            break;
         }

         fFld += (float)(-var7 + (iMeth1(dFld, 40797) - var7));
         if (bFld) {
            break;
         }

         if (var7 != 0) {
         }

         for(var1 = 6; var1 > 1; --var1) {
            for(var3 = var7; 2 > var3; ++var3) {
               var4 = var1 + '\ue8d3';
               fFld = (float)instanceCount;
               var4 -= var4;
            }
         }

         byFld *= (byte)var1;
         var4 = (int)instanceCount;
         int[] var10000 = iArrFld;
         var10000[var7 - 1] *= -1841375820;
         instanceCount += (long)(var7 - var2);
         var10000 = iArrFld;
         var10000[var7] /= (int)((long)fFld | 1L);
      }

      long var5 = (long)(var7 + var1 + var2 + var3 + var4);
      iMeth_check_sum += var5;
      return (int)var5;
   }

   public static float fMeth() {
      boolean var0 = true;
      int var1 = 14;
      int var2 = 2;

      int var5;
      label32:
      for(var5 = 6; var5 < 125; ++var5) {
         fFld = (float)iMeth();
         switch ((var5 >>> 1) % 4 + 11) {
            case 11:
               switch (var5 % 1 * 5 + 7) {
                  case 11:
                     fFld += (float)(var5 - var5);
                     fFld = fFld;
                     iArrFld[var5] = 33712;
                     continue;
                  default:
                     var1 *= var1;
                     instanceCount += (long)(var5 + var5);
                     if (bFld) {
                        continue;
                     }

                     var2 = 1;

                     while(true) {
                        iArrFld[var5] = var1;
                        var1 -= var2;
                        var1 += var1;
                        var1 = 76;
                        ++var2;
                        if (var2 >= 13) {
                           continue label32;
                        }
                     }
               }
            case 12:
               var1 = var2;
            case 13:
               byFld = (byte)var5;
               break;
            case 14:
               instanceCount = (long)var1;
         }
      }

      long var3 = (long)(var5 + var1 + var2);
      fMeth_check_sum += var3;
      return (float)var3;
   }

   public void mainTest(String[] var1) {
      int var2 = 62713;
      int var3 = -4;
      int var4 = -159;
      int var5 = -1;
      int var6 = -57275;
      int var7 = 0;
      int var8 = -76;
      short var9 = -245;
      double var10 = -98.6628;
      float var12 = 0.628F;
      float[] var13 = new float[400];
      short var14 = -6096;
      long[] var15 = new long[400];
      byte[] var16 = new byte[400];
      FuzzerUtils.init(var15, 48934L);
      FuzzerUtils.init(var16, (byte)-71);
      FuzzerUtils.init(var13, 37.761F);
      var15 = var15;
      instanceCount = (long)Integer.reverseBytes(Math.abs(14395));

      label57:
      for(var2 = 344; 4 < var2; --var2) {
         var4 = 1;

         while(true) {
            do {
               ++var4;
               if (var4 >= 74) {
                  var7 <<= var7;
                  var12 += -6.5252849E18F;
                  var5 -= 58;
                  var12 += var12;

                  for(var8 = 3; var8 < 74; ++var8) {
                     dFld += (double)var9;
                     var15[var8 + 1] -= instanceCount;
                     instanceCount += (long)var8 * instanceCount + (long)var5 - instanceCount;
                     var12 *= (float)iFld;
                     iArrFld[var8 - 1] = 11;
                     iFld >>= (int)instanceCount;
                  }
                  continue label57;
               }

               --var3;
               byFld = (byte)((int)((double)(-144 + var3) - var10++ + (double)(var12-- - (float)(instanceCount + (long)var3))));
            } while(instanceCount-- > (long)(var16[var2 + 1] = (byte)(-(var5--))));

            var12 += (float)((long)(var4 * var4 + byFld) - instanceCount);

            for(var6 = 1; var6 < 1; ++var6) {
               instanceCount += (long)(var6 + var7);
               var13[var4] *= (float)(var4 - var14) + fMeth() - 63.0F;

               try {
                  iArrFld[var6] = iArrFld[var2 + 1] / iArrFld[370];
                  var7 = var3 % -100;
                  var3 = -136669383 % var4;
               } catch (ArithmeticException var18) {
               }

               var3 = (int)instanceCount;
               var15[var6 + 1] /= (long)(var5 | 1);
               var7 -= 1142;
               var3 *= (int)instanceCount;
               var10 -= (double)var4;
               var5 += var6 ^ var4;
               instanceCount = (long)((float)instanceCount + ((float)((long)var6 * instanceCount) + fFld - (float)var7));
            }

            var3 *= byFld;
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("d f i3 = " + Double.doubleToLongBits(var10) + "," + Float.floatToIntBits(var12) + "," + var5);
      FuzzerUtils.out.println("i4 i5 s = " + var6 + "," + var7 + "," + var14);
      FuzzerUtils.out.println("i19 i20 lArr = " + var8 + "," + var9 + "," + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("byArr fArr = " + FuzzerUtils.checkSum(var16) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.dFld Test.bFld Test.iFld = " + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0) + "," + iFld);
      FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-9);
      fMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
