public class Test {
   public static final int N = 400;
   public static long instanceCount = 79L;
   public int iFld = -3;
   public static float fFld = -1.311F;
   public static boolean bFld = true;
   public static double dFld = 0.98551;
   public byte byFld = 93;
   public int iFld1 = -6207;
   public static float fFld1 = 17.148F;
   public int[][] iArrFld = new int[400][400];
   public static long bMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;

   public static void vMeth(long var0, int var2) {
      boolean var3 = true;
      short var4 = 17884;
      boolean var5 = true;
      int var6 = 2730;
      int var7 = 0;
      int var8 = -6;
      int var9 = -9;
      byte var10 = -106;
      long var11 = 242L;
      long[] var13 = new long[400];
      float[] var14 = new float[400];
      double[] var15 = new double[400];
      FuzzerUtils.init(var13, -9L);
      FuzzerUtils.init(var14, 3.569F);
      FuzzerUtils.init(var15, -100.96964);
      int var17 = 1;

      int var18;
      do {
         var13 = FuzzerUtils.long1array(400, 6L);

         for(var11 = 1L; var11 < 8L; ++var11) {
            instanceCount = (long)var17;
         }

         for(var18 = 1; var18 < 8; ++var18) {
            var6 <<= (int)instanceCount;
         }

         switch (var17 % 3 * 5 + 90) {
            case 101:
               var6 ^= (int)instanceCount;
               instanceCount -= (long)var4;

               for(var7 = var17; var7 < 8; ++var7) {
                  for(var9 = 1; var9 < 1; ++var9) {
                     byte var16 = -27;
                     dFld += dFld;
                     var6 = var6;
                     var14[var17] -= (float)var0;
                     var16 += (byte)(45 + var9 * var9);
                  }
               }
               break;
            case 105:
               var8 = (int)((long)var8 + ((long)var17 * var11 + var11 - (long)var10));
            case 94:
               var15 = var15;
         }

         ++var17;
      } while(var17 < 194);

      vMeth_check_sum += var0 + (long)var2 + (long)var17 + var11 + (long)var4 + (long)var18 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var13) + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var15));
   }

   public static int iMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      boolean var4 = true;
      int var5 = 108;
      int var6 = 33566;
      int var7 = 40034;
      int var8 = 2;
      int var9 = -55934;
      byte var10 = 99;
      double[][] var11 = new double[400][400];
      FuzzerUtils.init(var11, -2.31288);
      int var14 = 1;

      do {
         ++var0;
         instanceCount *= (long)var0;
         ++var14;
      } while(var14 < 265);

      vMeth(instanceCount, -11);

      int var15;
      for(var15 = 3; var15 < 126; ++var15) {
         for(var6 = 13; var15 < var6; --var6) {
            var7 *= var0;
            instanceCount = (long)var6;
            var2 %= var6 | 1;

            for(var8 = var15; 1 > var8; ++var8) {
               instanceCount += instanceCount;
               var11[var15 + 1] = FuzzerUtils.double1array(400, 72.82947);
               var1 = var0;
               var7 = var10;
            }

            instanceCount *= (long)var6;
            var5 >>= 135;
         }
      }

      long var12 = (long)(var0 + var1 + var2 + var14 + var15 + var5 + var6 + var7 + var8 + var9 + var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11));
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public static boolean bMeth(long var0, int var2, int var3) {
      byte var4 = 92;
      float var5 = 0.163F;
      float var6 = -117.318F;
      int var7 = 86;
      int var8 = 11;
      int var9 = 21913;
      int var10 = 12;
      int[] var11 = new int[400];
      long[] var12 = new long[400];
      short[] var13 = new short[400];
      FuzzerUtils.init(var11, -58175);
      FuzzerUtils.init(var12, -5950751739634349034L);
      FuzzerUtils.init((short[])var13, (short)17374);
      byte var17 = (byte)(var4 + (byte)Math.max((var2 << (int)var0) - var11[47], (int)((-168.0F - (fFld - (float)var3)) * (fFld += (float)var3))));
      var5 = 1.0F;

      do {
         var3 >>>= (int)((float)((long)Short.reverseBytes((short)-12927) + ((long)var2 - instanceCount)) - ((float)(++instanceCount) - fFld++));
         var11 = var11;
      } while(++var5 < 183.0F);

      bFld = var2 < iMeth(-4, 23834, var3);
      label54:
      switch ((var3 >>> 1) % 5 * 5 + 83) {
         case 85:
            var11[(var3 >>> 1) % 400] = var7;
            break;
         case 89:
            var7 = 13;

            while(true) {
               if (var7 >= 268) {
                  break label54;
               }

               var8 &= var3;

               try {
                  int var10000 = var8 / var7;
                  var3 = -231 % var3;
                  var8 = var2 % -65249;
               } catch (ArithmeticException var16) {
               }

               fFld = (float)var2;
               var0 = (long)var2;
               var6 = 1.0F;

               while(++var6 < 6.0F) {
                  for(var9 = 1; 1 > var9; ++var9) {
                     var10 = (int)var6;
                     instanceCount *= (long)var10;
                  }
               }

               ++var7;
            }
         case 95:
         case 103:
            var2 -= 3;
            break;
         case 107:
            var12[(var3 >>> 1) % 400] = (long)var6;
            break;
         default:
            var13 = var13;
      }

      long var14 = var0 + (long)var2 + (long)var3 + (long)var17 + (long)Float.floatToIntBits(var5) + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var6) + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var11) + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var13);
      bMeth_check_sum += var14;
      return var14 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      short var2 = 628;
      int var3 = 1;
      int var4 = 17;
      int var5 = -6;
      int var6 = 8;
      int var7 = 19569;
      int var8 = -6;
      int var9 = -13;
      int var10 = -36174;
      int var11 = -26243;
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, -1348721604L);

      try {
         this.iFld &= -((var2 += (short)this.iFld) - Short.reverseBytes(var2));
         bMeth(instanceCount, -39869, 6);
         this.iFld = this.iFld;
         this.byFld %= (byte)((int)((long)dFld | 1L));
      } catch (ArrayIndexOutOfBoundsException var16) {
         for(var3 = 9; var3 < 265; ++var3) {
            instanceCount <<= var3;
            if (bFld) {
               for(var5 = 2; var5 < 98; ++var5) {
                  this.iFld -= var4;
               }
            } else {
               for(var7 = 2; 98 > var7; ++var7) {
                  fFld *= (float)var5;

                  for(var9 = 1; var9 < 2; ++var9) {
                     bFld = bFld;
                     this.iArrFld[var7 - 1][var9] = var3;
                     var6 = var3 >> -44981;
                     switch (var7 % 5 * 5 + 32) {
                        case 36:
                           switch (var9 % 9 * 5 + 56) {
                              case 69:
                                 this.iFld += -53180 + var9 * var9;
                                 var8 -= var5;
                                 var12[var9 + 1] = (long)var3;
                                 instanceCount += (long)(-185 + var9 * var9);
                              case 75:
                              case 93:
                                 var6 = -28;
                                 this.iFld += this.iFld;
                                 instanceCount += (long)(93.434F + (float)(var9 * var9));
                                 int[] var17 = this.iArrFld[var9 + 1];
                                 var17[var9] -= -970703437;
                                 break;
                              case 72:
                                 this.iFld = (int)((long)this.iFld + ((long)(var9 * this.byFld + var4) - instanceCount));
                              case 84:
                                 try {
                                    int var10000 = this.iFld1 / this.iFld;
                                    var6 = this.iArrFld[var9 + 1][var3] % -5603;
                                    var11 = var8 / var8;
                                 } catch (ArithmeticException var15) {
                                 }
                              case 98:
                                 var10 = var6;
                              case 85:
                              case 95:
                                 if (bFld) {
                                 }
                                 break;
                              case 82:
                                 fFld1 = (float)this.iFld1;
                              case 70:
                              case 71:
                              case 73:
                              case 74:
                              case 76:
                              case 77:
                              case 78:
                              case 79:
                              case 80:
                              case 81:
                              case 83:
                              case 86:
                              case 87:
                              case 88:
                              case 89:
                              case 90:
                              case 91:
                              case 92:
                              case 94:
                              case 96:
                              case 97:
                              default:
                                 this.iFld1 >>= var10;
                           }
                        case 38:
                        default:
                           break;
                        case 42:
                           var10 <<= (int)instanceCount;
                           break;
                        case 49:
                           var4 += (int)(0.8F + (float)(var9 * var9));
                           break;
                        case 56:
                           instanceCount -= (long)var9;
                     }
                  }
               }
            }
         }
      }

      FuzzerUtils.out.println("s i25 i26 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i27 i28 i29 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i30 i31 i32 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i33 lArr2 = " + var11 + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld Test.dFld byFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld) + "," + this.byFld);
      FuzzerUtils.out.println("iFld1 Test.fFld1 iArrFld = " + this.iFld1 + "," + Float.floatToIntBits(fFld1) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
