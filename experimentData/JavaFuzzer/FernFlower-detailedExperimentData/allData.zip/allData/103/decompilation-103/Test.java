public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 119L;
   public float fFld = 0.86F;
   public volatile double dFld = 1.1487;
   public byte byFld = -100;
   public int iFld = -12;
   public int[] iArrFld = new int[400];
   public static long vMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public void vMeth1() {
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -31917;
      int var4 = -13;
      boolean var5 = true;
      long var6 = 173L;
      long[] var8 = new long[400];
      FuzzerUtils.init(var8, 8L);
      this.iFld = this.iFld;
      int var9 = 1;

      byte var11;
      do {
         this.iFld %= var9 | 1;
         instanceCount <<= -43505;
         this.iFld >>>= (int)instanceCount;
         var11 = (byte)var9;
         this.iFld += 54123;
         var8[var9 + 1] -= (long)this.fFld;
         this.iFld >>= (int)instanceCount;
         this.iFld -= (int)instanceCount;
         instanceCount = (long)this.iFld;
         ++var9;
      } while(var9 < 355);

      int var10;
      for(var10 = 375; var10 > 18; var10 -= 3) {
         for(var6 = 1L; var6 < 13L; ++var6) {
            var3 &= (int)var6;
            var4 += 1533772819;
         }
      }

      vMeth1_check_sum += (long)(var9 + var11 + var10 + var3) + var6 + (long)var4 + FuzzerUtils.checkSum(var8);
   }

   public int iMeth(float var1, int var2, int var3) {
      long var4 = 322988233L;
      long[] var6 = new long[400];
      int var7 = 39944;
      int var8 = 166;
      FuzzerUtils.init(var6, -34428L);
      this.vMeth1();

      for(var4 = 20L; var4 < 357L; ++var4) {
         int[] var10000 = this.iArrFld;
         var10000[(int)(var4 - 1L)] -= (int)var4;
         var8 = 1;

         while(true) {
            ++var8;
            if (var8 >= 5) {
               var7 ^= -96;
               var7 = (int)var4;
               this.iFld = (int)var4;
               var3 = (int)instanceCount;
               break;
            }

            var10000 = this.iArrFld;
            var10000[var8 - 1] -= this.iFld;
            var6[(int)var4] = (long)var3;
            var2 *= (int)this.dFld;
            this.iFld = var7;
            instanceCount = (long)this.fFld;
            var3 += var3;
         }
      }

      this.byFld = (byte)var2;
      long var9 = (long)(Float.floatToIntBits(var1) + var2 + var3) + var4 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var6);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void vMeth(long var1, long var3, int var5) {
      double var6 = 38.125686;
      short var8 = -28390;
      int var9 = -57210;
      byte var10 = 4;
      int var11 = 27585;
      byte var12 = 104;
      short var13 = 8266;
      int[] var14 = new int[400];
      int[] var15 = new int[400];
      FuzzerUtils.init((int[])var14, (int)-136);
      FuzzerUtils.init((int[])var15, (int)46784);

      for(var6 = 3.0; var6 < 194.0; ++var6) {
         if ((float)instanceCount >= this.fFld) {
         }
      }

      for(var9 = 12; var9 < 365; ++var9) {
         int var10003 = var9 - 1;
         int var10005 = var14[var9 - 1];
         var14[var10003] = var14[var9 - 1] - 1;
         this.dFld -= (double)var10005;

         for(var11 = 1; var11 < 5; ++var11) {
            var3 += (long)(var11 * var8) + var3 - (long)this.byFld;
            this.fFld *= (float)(--instanceCount + (long)(-this.iMeth(this.fFld, var13, var9)));
            var5 += var11 * var12;
            var15[var9 + 1] <<= var13;
            int var10000 = var8 + (var11 ^ var11);
            var8 = 10;
            var5 += (int)this.fFld;
            this.iFld += var11;
            long var16 = var1 + (long)var11;
            var1 = (long)var10;
         }
      }

      vMeth_check_sum += var1 + var3 + (long)var5 + Double.doubleToLongBits(var6) + (long)var8 + (long)var9 + (long)var10 + (long)var11 + (long)var12 + (long)var13 + FuzzerUtils.checkSum(var14) + FuzzerUtils.checkSum(var15);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 240;
      boolean var4 = true;
      short var5 = -26960;
      boolean var6 = false;
      double var7 = -99.123034;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, 13L);
      this.vMeth(instanceCount, instanceCount, this.iFld);
      this.fFld *= (float)this.dFld;
      this.fFld = -71.0F;
      instanceCount -= 28707L;
      this.iArrFld = this.iArrFld;
      this.dFld -= 0.6660000085830688;
      this.iFld *= this.iFld;
      this.iFld = -3;
      ++this.iFld;
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 319) {
            this.iFld *= this.iFld;
            int var13 = 1;

            while(true) {
               ++var13;
               if (var13 >= 167) {
                  FuzzerUtils.out.println("i15 s i16 = " + var12 + "," + var5 + "," + var3);
                  FuzzerUtils.out.println("b d1 i17 = " + (var6 ? 1 : 0) + "," + Double.doubleToLongBits(var7) + "," + var13);
                  FuzzerUtils.out.println("lArr2 = " + FuzzerUtils.checkSum(var9));
                  FuzzerUtils.out.println("Test.instanceCount fFld dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(this.dFld));
                  FuzzerUtils.out.println("byFld iFld iArrFld = " + this.byFld + "," + this.iFld + "," + FuzzerUtils.checkSum(this.iArrFld));
                  FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                  FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                  FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                  return;
               }

               try {
                  this.iFld = 69748159 / this.iArrFld[var13];
                  this.iFld = this.iArrFld[(this.iFld >>> 1) % 400] % -11;
                  this.iFld = 31025 % var13;
               } catch (ArithmeticException var11) {
               }

               this.iFld = this.iFld;
               this.fFld += (float)var12;
               instanceCount -= -82L;
               this.iFld -= -36391;
               instanceCount *= (long)this.byFld;
            }
         }

         instanceCount *= (long)var12;
         this.fFld = (float)var5;
         var3 = 1;

         while(true) {
            ++var3;
            if (var3 >= 79) {
               instanceCount -= (long)var3;
               var7 = (double)this.fFld;
               this.iArrFld[var12 + 1] = var3;
               this.iFld -= var3;
               var6 = true;
               var9[var12] = 98L;
               this.iFld += var12 ^ var5;
               break;
            }

            this.iFld += var3 + var3;
            if (var6) {
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
