public class Test {
   public static final int N = 400;
   public static long instanceCount = 1450631406L;
   public static double dFld = 119.83042;
   public static boolean bFld = false;
   public static volatile byte byFld = 103;
   public static volatile long[] lArrFld = new long[400];
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      int var0 = 3;
      int var1 = -39164;
      int var2 = 137;
      int var3 = -204;
      int var4 = -12;
      int var5 = -13;
      short var6 = -937;
      double var7 = 0.67195;
      var0 -= var0;

      for(var1 = 9; var1 < 333; ++var1) {
         var2 += var0;
         var3 = 1;

         while(true) {
            ++var3;
            if (var3 >= 5) {
               if (!bFld) {
                  var2 -= 223;
                  var4 = (int)instanceCount;

                  for(var5 = 1; var5 < 5; ++var5) {
                     instanceCount = (long)var5;
                  }

                  var4 += var1 * var3 + var6 - var6;
               }
               break;
            }

            for(var7 = 1.0; var7 < 1.0; ++var7) {
               var4 %= -99;
               instanceCount += (long)var1;
               instanceCount += (long)var7;
            }
         }
      }

      dFld += (double)instanceCount;
      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3) + Double.doubleToLongBits(var7) + (long)var4 + (long)var5 + (long)var6;
   }

   public static int iMeth(long var0, int var2) {
      boolean var3 = true;
      int var4 = -80;
      int var5 = -8163;
      int var6 = -19863;
      int var7 = -160;
      float var8 = 51.948F;
      short var9 = 11005;

      int var12;
      for(var12 = 9; 214 > var12; ++var12) {
         var8 *= (float)((91L * (long)(var12 + var9) + (long)var4) * 14106L);
         var5 = 1;

         while(true) {
            ++var5;
            if (var5 >= 8) {
               break;
            }

            vMeth1();

            for(var6 = 1; var6 < 1; ++var6) {
               var2 += var6;
               int[] var10000 = iArrFld;
               var10000[var12 + 1] += var9;
               bFld = bFld;
               var4 = (int)instanceCount;
               var7 += var6 * var6;
               var4 >>= var2;
               var2 = (int)instanceCount;
               var7 -= var4;
               if (bFld) {
               }
            }
         }
      }

      long var10 = var0 + (long)var2 + (long)var12 + (long)var4 + (long)Float.floatToIntBits(var8) + (long)var9 + (long)var5 + (long)var6 + (long)var7;
      iMeth_check_sum += var10;
      return (int)var10;
   }

   public static void vMeth(long var0, int var2, long var3) {
      short var5 = 8074;
      boolean var6 = true;
      int var7 = 22163;
      int var8 = -21607;
      int var9 = 4;
      int var10 = 5;
      int var11 = -11307;
      int[] var12 = new int[400];
      boolean var13 = false;
      boolean[] var14 = new boolean[400];
      byte var15 = -109;
      float[][][] var16 = new float[400][400][400];
      FuzzerUtils.init(var12, -51910);
      FuzzerUtils.init((Object[][])var16, 51.22F);
      FuzzerUtils.init(var14, false);
      double var10001 = (double)var5 + (double)var2 * dFld;
      int var10005 = var12[4];
      int var10002 = var12[4];
      var12[4] = var10005 - 1;
      var2 -= (int)(var10001 - (double)var10002);

      int var19;
      for(var19 = 4; var19 < 190; ++var19) {
         if (var13) {
            for(var8 = 9; var8 > 1; var8 -= 3) {
               var15 += (byte)(16999 + var8 * var8);

               for(var10 = 5; var10 > var8; --var10) {
                  var16[var10 - 1][var8][var10 + 1] = (float)((long)var2 - ++var3);
                  var13 = var2-- <= var7 + iMeth(var0, var9);
                  var0 *= (long)var8;

                  try {
                     var7 = 95 / var2;
                     iArrFld[var8 + 1] /= -8809;
                     var7 = 1112982427 / var7;
                  } catch (ArithmeticException var18) {
                  }

                  var9 = var19;
                  var14 = var14;
                  var11 += 36;
               }

               var7 += var8 * var8;
               var2 <<= 0;
            }
         }
      }

      vMeth_check_sum += var0 + (long)var2 + var3 + (long)var5 + (long)var19 + (long)var7 + (long)(var13 ? 1 : 0) + (long)var8 + (long)var9 + (long)var15 + (long)var10 + (long)var11 + FuzzerUtils.checkSum(var12) + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var16)) + FuzzerUtils.checkSum(var14);
   }

   public void mainTest(String[] var1) {
      int var2 = -202;
      boolean var3 = true;
      int var4 = -131;
      byte var5 = 72;
      int var6 = 217;
      char var7 = 'ꄮ';
      char var8 = '쵓';
      int var9 = 146;
      int var10 = 10;
      int var11 = -41757;
      short var12 = 1373;
      var2 -= 14;
      var2 ^= (int)lArrFld[(var2 >>> 1) % 400];

      int var14;
      for(var14 = 245; 15 < var14; --var14) {
         float var13 = 1.48F;
         var4 = (int)instanceCount;
         vMeth(instanceCount, var4, instanceCount);
         if (!bFld) {
            var4 = (int)var13;
            instanceCount = (long)dFld;
            byFld += (byte)((int)var13);
            var13 *= 6.0F;
            var9 = 1;

            do {
               instanceCount += (long)var8;
               var13 = (float)var12;

               for(var10 = 1; 1 > var10; ++var10) {
                  var2 *= var2;
                  iArrFld[var9 - 1] = (int)instanceCount;
                  var6 = (int)((float)var6 + ((float)((long)var10 * instanceCount + instanceCount) - var13));
                  iArrFld = iArrFld;
                  instanceCount >>= var4;
               }

               ++var9;
            } while(var9 < 109);
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var14 + "," + var4);
      FuzzerUtils.out.println("i23 i24 s2 = " + var5 + "," + var6 + "," + var12);
      FuzzerUtils.out.println("i25 i26 i27 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i28 i29 = " + var10 + "," + var11);
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.byFld Test.lArrFld Test.iArrFld = " + byFld + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 180L);
      FuzzerUtils.init((int[])iArrFld, (int)-2);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
