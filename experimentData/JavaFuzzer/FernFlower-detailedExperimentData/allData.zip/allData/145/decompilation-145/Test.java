public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 54321L;
   public static int iFld = 57895;
   public static volatile boolean bFld = true;
   public int[] iArrFld = new int[400];
   public static float[][] fArrFld = new float[400][400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(long var0, float var2) {
      int var3 = -59333;
      boolean var4 = true;
      boolean var5 = true;
      int var6 = 231;
      int var7 = 93;
      boolean var8 = false;
      short var9 = 22632;
      short[] var10 = new short[400];
      double var11 = -2.128752;
      double[] var13 = new double[400];
      FuzzerUtils.init((short[])var10, (short)31140);
      FuzzerUtils.init(var13, -74.19942);
      var3 -= var3;
      int var16 = 1;

      int var17;
      do {
         var0 |= -1237057457L;
         var10[var16 - 1] >>= (short)var16;
         var17 = 1;

         while(true) {
            ++var17;
            if (var17 >= 6) {
               ++var16;
               break;
            }

            for(var6 = 1; var6 < 1; ++var6) {
               var10[var17 - 1] ^= (short)var7;
               var3 = var3;
               if (var8) {
                  break;
               }

               var3 += var6 * var16 + var9 - var3;
               var7 *= (int)var11;
               var7 -= (int)var0;
               var3 += 26770 + var6 * var6;
               var13[var17 + 1] += (double)var17;
               var11 -= (double)var6;
            }
         }
      } while(var16 < 254);

      long var14 = var0 + (long)Float.floatToIntBits(var2) + (long)var3 + (long)var16 + (long)var17 + (long)var6 + (long)var7 + (long)(var8 ? 1 : 0) + (long)var9 + Double.doubleToLongBits(var11) + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
      iMeth_check_sum += var14;
      return (int)var14;
   }

   public static void vMeth1() {
      float var0 = -3.913F;
      float[] var1 = new float[400];
      boolean var2 = true;
      int var3 = 225;
      int var4 = -19169;
      int var5 = 30659;
      int var6 = -13;
      byte var7 = 9;
      int[][] var8 = new int[400][400];
      double var9 = 90.21355;
      FuzzerUtils.init(var1, 1.596F);
      FuzzerUtils.init(var8, -46583);
      iMeth(-2932141964L, var0);

      int var11;
      for(var11 = 4; var11 < 318; var11 += 3) {
         short var12 = 13038;
         var3 = var12 >> iFld;

         for(var4 = 1; var4 < 15; var4 += 3) {
            iFld += (int)var9;
            int var10000 = var5 * var3;
            var5 = var11;
            var1[var4 - 1] -= -132.0F;
            var8[var4][var4 - 1] = var3;
         }

         var3 = var3;
         iFld += var11 * var11;

         for(var6 = var11; var6 < 15; ++var6) {
            var0 += (float)var6;
            instanceCount = (long)iFld;
         }
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var11 + var3 + var4 + var5) + Double.doubleToLongBits(var9) + (long)var6 + (long)var7 + Double.doubleToLongBits(FuzzerUtils.checkSum(var1)) + FuzzerUtils.checkSum(var8);
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      byte var2 = 4;
      int var3 = -139;
      int var4 = -55;
      int[] var5 = new int[400];
      float var6 = -9.42F;
      short var7 = 3880;
      byte var8 = 2;
      FuzzerUtils.init((int[])var5, (int)1);
      vMeth1();
      iFld = 190;
      var0 |= (int)instanceCount;

      int var10;
      for(var10 = 14; var10 < 273; ++var10) {
         boolean var9 = true;
         instanceCount -= (long)var6;
         instanceCount += 41127L;
         if (!var9) {
            var0 = (int)((long)var0 + ((long)var10 * instanceCount + instanceCount - (long)var7));
         } else {
            var3 = 1;

            while(true) {
               ++var3;
               if (var3 >= 6) {
                  break;
               }

               iFld = -35;
               var4 = 1;

               while(true) {
                  var0 += 185 + var4 * var4;
                  instanceCount += (long)var7;
                  instanceCount += (long)var4;
                  var2 = var8;
                  var6 *= (float)var8;
                  ++var4;
                  if (var4 >= 1) {
                     break;
                  }
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var10 + var2 + Float.floatToIntBits(var6) + var3 + var4 + var7 + var8) + FuzzerUtils.checkSum(var5);
   }

   public void mainTest(String[] var1) {
      int var2 = 45102;
      boolean var3 = true;
      int var4 = -43;
      short var5 = -9641;
      boolean var6 = true;
      int var7 = 16846;
      int var8 = 0;
      int var9 = -63869;
      byte var10 = 110;
      double var11 = 125.45846;
      long var13 = -15078L;
      long[] var15 = new long[400];
      float var16 = 83.183F;
      short var17 = 9910;
      boolean[] var18 = new boolean[400];
      FuzzerUtils.init(var15, -9L);
      FuzzerUtils.init(var18, true);
      var15[(var2 >>> 1) % 400] = (long)this.iArrFld[(var2 >>> 1) % 400];
      vMeth(var2);
      byte var23 = (byte)(var10 >>> 6);
      var11 -= (double)instanceCount;
      var15[(var2 >>> 1) % 400] += (long)var2;

      int var21;
      for(var21 = 1; 145 > var21; ++var21) {
         var4 += var21 * var21;

         try {
            int var10000 = iFld / var21;
            var2 = 23869 % var21;
            this.iArrFld[var21 + 1] = this.iArrFld[var21 - 1] / var5;
         } catch (ArithmeticException var20) {
         }
      }

      var13 = 1L;

      int var22;
      do {
         for(var22 = 232; var22 > 4; --var22) {
            var2 += (int)instanceCount;
            instanceCount *= -19L;
            iFld *= (int)var16;

            for(var8 = 1; var8 < 2; ++var8) {
               var9 *= (int)var13;
               --var9;
               iFld ^= var7;
               int[] var24 = this.iArrFld;
               var24[var8 - 1] -= var8;
               var18[var22 + 1] = bFld;
               switch (var22 % 4 * 5 + 78) {
                  case 82:
                  case 91:
                     iFld = 188;
                     var7 = iFld;
                     var17 = (short)var8;
                     instanceCount += (long)var8;
                  case 98:
                     var15[181] ^= (long)var9;
                     bFld = bFld;
                     instanceCount >>= -736314550;
                     var4 = (int)var13;
                     break;
                  case 97:
                     float[] var25 = fArrFld[(int)(var13 + 1L)];
                     var25[var22] += -10.0F;
                     var2 += (int)var16;
               }
            }
         }
      } while((var13 += 3L) < 325L);

      FuzzerUtils.out.println("i by1 d2 = " + var2 + "," + var23 + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("i18 i19 i20 = " + var21 + "," + var4 + "," + var5);
      FuzzerUtils.out.println("l1 i21 i22 = " + var13 + "," + var22 + "," + var7);
      FuzzerUtils.out.println("f3 i23 i24 = " + Float.floatToIntBits(var16) + "," + var8 + "," + var9);
      FuzzerUtils.out.println("s2 lArr bArr = " + var17 + "," + FuzzerUtils.checkSum(var15) + "," + FuzzerUtils.checkSum(var18));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 0.356F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
