public class Test {
   public static final int N = 400;
   public static long instanceCount = 45803L;
   public static int iFld = 34175;
   public byte byFld = -110;
   public volatile double dFld = 0.74703;
   public boolean bFld = false;
   public volatile short sFld = -2749;
   public int iFld1 = -11;
   public static int[] iArrFld = new int[400];
   public long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      float var1 = -37.791F;
      float var2 = -1.832F;
      double var3 = 79.95961;
      int var5 = 50303;
      int var6 = 1;
      int var7 = 64321;
      int var8 = -231;
      boolean var9 = true;
      var1 = 219.0F;

      while((var1 -= 2.0F) > 0.0F) {
         var3 += (double)instanceCount;

         for(var5 = 1; var5 < 14; var6 = var5++) {
            iArrFld[(int)var1] = var0;
            var0 += var0;
            var9 = false;
            var6 %= (int)(instanceCount | 1L);
            var0 <<= iFld;
         }

         if (!var9) {
            var2 += 62.205F;
            int[] var10000 = iArrFld;
            var10000[(int)var1] /= -1140288642;
         }
      }

      for(var7 = 9; var7 < 364; ++var7) {
         try {
            var8 = 255 / var7;
            iFld = -1069863247 / var8;
            var0 = -136820661 % var5;
         } catch (ArithmeticException var11) {
         }

         var6 = var6;
      }

      vMeth1_check_sum += (long)(var0 + Float.floatToIntBits(var1)) + Double.doubleToLongBits(var3) + (long)var5 + (long)var6 + (long)(var9 ? 1 : 0) + (long)Float.floatToIntBits(var2) + (long)var7 + (long)var8;
   }

   public static long lMeth(byte var0) {
      vMeth1(142);
      long var1 = (long)var0;
      lMeth_check_sum += var1;
      return var1;
   }

   public void vMeth(int var1, int var2, byte var3) {
      double var4 = 2.95095;
      boolean var6 = true;
      int var7 = -11469;
      int var8 = 0;
      int var9 = 160;
      int var10 = 5;
      byte var11 = -68;
      float var12 = -20.621F;
      int[] var10000 = iArrFld;
      int var10001 = (var2 >>> 1) % 400;
      int var10002 = var10000[(var2 >>> 1) % 400];
      long[] var10004 = this.lArrFld;
      int var10005 = (var1 >>> 1) % 400;
      long var10007 = var10004[(var1 >>> 1) % 400];
      var10004[var10005] = var10004[(var1 >>> 1) % 400] - 1L;
      var10000[var10001] = var10002 - (int)((long)Integer.reverseBytes('턚' >> (int)var10007) * lMeth((byte)-89) * 1507375961L);
      var4 = (double)instanceCount;

      int var13;
      for(var13 = 6; var13 < 320; ++var13) {
         var10000 = iArrFld;
         var10000[var13 - 1] -= (int)var12;

         label32:
         for(var8 = 1; var8 < 5; ++var8) {
            var9 |= var9;
            switch (var13 % 4 + 43) {
               case 43:
                  var10 = 1;

                  while(true) {
                     if (var10 >= 2) {
                        continue label32;
                     }

                     var1 = (int)((long)var1 + ((long)var10 * instanceCount + (long)var11 - (long)var1));
                     var9 = 7;
                     var7 -= var11;
                     iFld = var7;
                     var4 = (double)var11;
                     long[] var14 = this.lArrFld;
                     var14[var8] -= (long)var2;
                     var12 -= var12;
                     ++var10;
                  }
               case 44:
                  var2 += -7985 + var8 * var8;
                  break;
               case 45:
                  instanceCount += (long)var8;
                  break;
               case 46:
                  var9 -= var1;
            }
         }
      }

      vMeth_check_sum += (long)(var1 + var2 + var3) + Double.doubleToLongBits(var4) + (long)var13 + (long)var7 + (long)Float.floatToIntBits(var12) + (long)var8 + (long)var9 + (long)var10 + (long)var11;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 5;
      int var4 = 10925;
      int var5 = -49468;
      int var6 = 229;
      int var7 = -116;
      short var8 = -135;
      int var9 = -50606;
      byte var10 = -3;
      float var11 = 0.249F;
      byte[] var12 = new byte[400];
      FuzzerUtils.init((byte[])var12, (byte)5);

      int var15;
      for(var15 = 8; var15 < 317; ++var15) {
         label330: {
            label331: {
               label332: {
                  label268: {
                     label333: {
                        label334: {
                           label335: {
                              label255: {
                                 label254: {
                                    label336: {
                                       label337: {
                                          label242: {
                                             var3 = (int)(-Math.abs(instanceCount = (long)var15));
                                             int[] var10000;
                                             switch (var15 + 51) {
                                                case 51:
                                                   this.vMeth(var3, var3, this.byFld);
                                                   continue;
                                                case 52:
                                                   var3 += var15 + var3;
                                                   var4 = var15;
                                                   if (var15 < 81) {
                                                      for(var6 = 1; var6 < 1; ++var6) {
                                                         var10000 = iArrFld;
                                                         var10000[var6] -= (int)var11;
                                                         var5 += (int)this.dFld;
                                                         var3 >>>= 269236742;
                                                         var3 ^= iFld;
                                                         var5 += 0;
                                                         var5 = var4;
                                                      }
                                                   }
                                                case 53:
                                                   var11 = (float)instanceCount;
                                                case 54:
                                                   break label331;
                                                case 55:
                                                   instanceCount = instanceCount;
                                                   continue;
                                                case 56:
                                                   var9 += var15;
                                                case 57:
                                                case 58:
                                                case 59:
                                                   break label332;
                                                case 60:
                                                   var7 -= 30;
                                                case 61:
                                                   break label268;
                                                case 62:
                                                   this.dFld = (double)instanceCount;
                                                   continue;
                                                case 63:
                                                   var11 = (float)var10;
                                                case 64:
                                                   instanceCount -= -24581L;
                                                case 65:
                                                case 66:
                                                   var7 = var10;
                                                case 67:
                                                   break label335;
                                                case 68:
                                                   this.bFld = this.bFld;
                                                   continue;
                                                case 69:
                                                   var3 >>= var7;
                                                case 70:
                                                   break label333;
                                                case 71:
                                                   var10000 = iArrFld;
                                                   var10000[var15] -= 9;
                                                case 72:
                                                   break label334;
                                                case 73:
                                                   if (this.bFld) {
                                                   }
                                                   continue;
                                                case 74:
                                                   var7 = (int)this.dFld;
                                                case 75:
                                                   continue;
                                                case 76:
                                                   var5 -= var6;
                                                   continue;
                                                case 77:
                                                   var7 += var5;
                                                   continue;
                                                case 78:
                                                   var3 -= 12;
                                                   continue;
                                                case 79:
                                                   var9 *= this.sFld;
                                                   continue;
                                                case 80:
                                                   var5 <<= var3;
                                                case 81:
                                                   break label255;
                                                case 82:
                                                   var11 += (float)((long)(var15 * var9 + var8) - instanceCount);
                                                   continue;
                                                case 83:
                                                   this.byFld <<= (byte)var7;
                                                case 84:
                                                   break label254;
                                                case 85:
                                                   var9 += 800768368;
                                                case 86:
                                                   break label336;
                                                case 87:
                                                   this.bFld = this.bFld;
                                                case 88:
                                                   break label337;
                                                case 89:
                                                   this.sFld += (short)(var15 * var15);
                                                   continue;
                                                case 90:
                                                   var3 += var15 * var15;
                                                   continue;
                                                case 91:
                                                   var5 += this.sFld;
                                                   continue;
                                                case 92:
                                                   this.lArrFld = FuzzerUtils.long1array(400, 9169L);
                                                   continue;
                                                case 93:
                                                   if (this.bFld) {
                                                   }
                                                   continue;
                                                case 94:
                                                   this.sFld = (short)(this.sFld - 31910);
                                                   continue;
                                                case 95:
                                                   var10000 = iArrFld;
                                                   var10000[var15 - 1] >>>= (int)instanceCount;
                                                   continue;
                                                case 96:
                                                   if (this.bFld) {
                                                   }
                                                   continue;
                                                case 97:
                                                case 98:
                                                   var5 *= var8;
                                                   continue;
                                                case 99:
                                                   var5 = (int)((long)var5 + ((long)var15 * instanceCount + (long)var4 - (long)var15));
                                                case 100:
                                                   break label242;
                                                case 101:
                                                   var9 -= 36639;
                                                   continue;
                                                case 102:
                                                   iFld %= 1;
                                                   continue;
                                                case 103:
                                                   instanceCount += (long)var7;
                                                case 104:
                                                   var11 = (float)this.dFld;
                                                case 105:
                                                   break;
                                                case 106:
                                                   this.byFld = (byte)var10;
                                                case 107:
                                                   iFld >>= var9;
                                                case 108:
                                                   instanceCount = (long)var8;
                                                case 109:
                                                   this.dFld += (double)var10;
                                                case 110:
                                                   break label330;
                                                case 111:
                                                   var7 = var10;
                                                   continue;
                                                case 112:
                                                   this.iFld1 >>>= var6;
                                                   continue;
                                                case 113:
                                                   instanceCount >>>= (int)instanceCount;
                                                   continue;
                                                case 114:
                                                   var5 = (int)((float)var5 + ((float)var15 * var11 + (float)var8 - (float)var8));
                                                   continue;
                                                case 115:
                                                   instanceCount += (long)var15;
                                                   continue;
                                                case 116:
                                                case 117:
                                                   this.iFld1 *= 1;
                                                   continue;
                                                case 118:
                                                   var9 *= (int)this.dFld;
                                                   continue;
                                                case 119:
                                                   var3 <<= var4;
                                                   continue;
                                                case 120:
                                                   var5 &= -14;
                                                   continue;
                                                default:
                                                   iArrFld[var15 + 1] = var7;
                                                   continue;
                                             }

                                             instanceCount += (long)(var15 - iFld);
                                             continue;
                                          }

                                          this.byFld += (byte)((int)((float)var15 * var11 + (float)this.byFld - (float)var6));
                                          continue;
                                       }

                                       this.dFld -= (double)instanceCount;
                                       continue;
                                    }

                                    var11 += (float)iFld;
                                    continue;
                                 }

                                 var7 >>= 61865;
                                 continue;
                              }

                              var9 >>= var15;
                              continue;
                           }

                           try {
                              var9 = -49751630 % iFld;
                              var5 = var8 % var9;
                              var3 = -239 / var4;
                           } catch (ArithmeticException var14) {
                           }
                           continue;
                        }

                        var11 += -13.0F;
                        continue;
                     }

                     var11 = (float)var6;
                     continue;
                  }

                  iFld <<= (int)instanceCount;
                  continue;
               }

               var7 *= (int)instanceCount;
               continue;
            }

            instanceCount = (long)var6;
            continue;
         }

         var3 = var15;
      }

      FuzzerUtils.out.println("i i1 i15 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i16 i17 i18 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("f3 i19 i20 = " + Float.floatToIntBits(var11) + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i21 byArr = " + var10 + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld byFld = " + instanceCount + "," + iFld + "," + this.byFld);
      FuzzerUtils.out.println("dFld bFld sFld = " + Double.doubleToLongBits(this.dFld) + "," + (this.bFld ? 1 : 0) + "," + this.sFld);
      FuzzerUtils.out.println("iFld1 Test.iArrFld lArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)2);
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
