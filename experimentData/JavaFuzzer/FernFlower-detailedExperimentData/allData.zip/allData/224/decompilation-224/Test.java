public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 1705898175L;
   public int iFld = -8304;
   public static byte byFld = -69;
   public static short sFld = -18477;
   public static double[] dArrFld = new double[400];
   public static volatile boolean[] bArrFld = new boolean[400];
   public static int[] iArrFld = new int[400];
   public static volatile float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      --var0;
      vMeth1_check_sum += (long)var0;
   }

   public static long lMeth(boolean var0, float var1) {
      int var2 = -44614;
      int var3 = 106;
      int var4 = 76;
      int var5 = 0;
      char var6 = '\uea06';
      int var7 = -183;
      byte var8 = -5;
      int[] var9 = new int[400];
      FuzzerUtils.init((int[])var9, (int)-132);

      for(var2 = 1; 196 > var2; ++var2) {
         vMeth1(var4);

         for(var5 = 1; var5 < 8; ++var5) {
            var9[var2 + 1] >>= var4;
            var3 = var4 + var5;
            if (var4 != 0) {
            }

            for(var7 = 1; var7 < 2; ++var7) {
               double[] var10000 = dArrFld;
               var10000[var2] /= (double)(instanceCount | 1L);

               try {
                  var3 = var5 / var9[var7 - 1];
                  var4 = var9[var5] / var6;
                  var9[var7] = 23 / var5;
               } catch (ArithmeticException var12) {
               }

               bArrFld = FuzzerUtils.boolean1array(400, true);
               var9[var2 - 1] &= var3;
               instanceCount -= (long)var1;
            }

            var9[var2 + 1] <<= (int)instanceCount;
         }

         var1 = var1;
      }

      long var10 = (long)((var0 ? 1 : 0) + Float.floatToIntBits(var1) + var2 + var3 + var4 + var5 + var6 + var7 + var8) + FuzzerUtils.checkSum(var9);
      lMeth_check_sum += var10;
      return var10;
   }

   public static void vMeth() {
      double var0 = -47.18541;
      double var2 = -77.11773;
      double var4 = 108.110919;
      boolean var6 = true;
      float var7 = 46.42F;
      int var8 = -161;
      boolean var9 = true;
      int var10 = 92;
      byte var11 = 4;
      int var12 = -50265;
      int[][] var13 = new int[400][400];
      short var14 = 1643;
      FuzzerUtils.init((int[][])var13, (int)7);
      var0 += (double)(lMeth(var6, var7) + (long)var8);
      var8 /= var8 | 1;

      int var15;
      for(var15 = 271; var15 > 8; var15 -= 3) {
         var10 = var15 * (int)var0;
         var0 -= (double)instanceCount;
         instanceCount = (long)byFld;

         for(var2 = 1.0; var2 < 18.0; ++var2) {
            var13[var15][(int)var2] = var10;

            for(var4 = (double)var15; 2.0 > var4; ++var4) {
               var8 -= var11;
               var14 = (short)((int)var2);
               iArrFld[(int)var2] = 203;
               byFld += (byte)var10;
            }
         }
      }

      vMeth_check_sum += Double.doubleToLongBits(var0) + (long)(var6 ? 1 : 0) + (long)Float.floatToIntBits(var7) + (long)var8 + (long)var15 + (long)var10 + Double.doubleToLongBits(var2) + (long)var11 + Double.doubleToLongBits(var4) + (long)var12 + (long)var14 + FuzzerUtils.checkSum(var13);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -101;
      int var4 = -124;
      int var5 = 15271;
      int var6 = -2;
      int var7 = 34445;
      int var8 = 11;
      int[] var9 = new int[400];
      float var10 = -25.873F;
      double var11 = -1.50751;
      double var13 = -118.124478;
      boolean var15 = false;
      long[] var16 = new long[400];
      FuzzerUtils.init((int[])var9, (int)1);
      FuzzerUtils.init(var16, 6194027090030472735L);
      int var20 = 359;

      do {
         this.iFld = (int)((long)this.iFld + ((long)(var20 * var20) + instanceCount - (long)var20));
         var20 -= 3;
      } while(var20 > 0);

      this.iFld = var9[(var20 >>> 1) % 400] -= (int)Math.abs((long)(var10 + (float)this.iFld));
      this.iFld += (int)((double)this.iFld - -(var11 - (double)instanceCount));
      var9[20] = -this.iFld;

      for(var13 = 1.0; var13 < 323.0; ++var13) {
         vMeth();

         label80:
         for(var4 = 1; var4 < 78; ++var4) {
            float[] var10000 = fArrFld;
            var10000[(int)(var13 + 1.0)] += (float)var4;
            var6 = 1;

            do {
               if (!var15) {
                  var11 = -62758.0;
                  var10 += (float)(var6 * var6);
                  switch ((int)(var13 % 1.0 + 13.0)) {
                     case 13:
                        instanceCount = 21976L;
                        var5 -= var3;
                        iArrFld[var4 - 1] = (int)instanceCount;
                        this.iFld += var6;
                        break;
                     default:
                        fArrFld = fArrFld;
                  }

                  instanceCount += (long)(var6 ^ var5);
               }

               ++var6;
            } while(var6 < 2);

            switch ((var3 >>> 1) % 3 * 5 + 47) {
               case 48:
               case 49:
               case 51:
               default:
                  break;
               case 50:
                  var7 = 1;

                  while(true) {
                     if (var7 >= 2) {
                        continue label80;
                     }

                     switch ((var6 >>> 1) % 8 + 64) {
                        case 64:
                           instanceCount += (long)var7;
                           switch (78) {
                              case 75:
                                 sFld <<= (short)var7;
                                 iArrFld[var4] = var20;
                                 var8 += var7 * var7;

                                 try {
                                    var3 = 2036700165 / var5;
                                    int var21 = var3 / var9[var4];
                                    var5 = var4 % -36330;
                                 } catch (ArithmeticException var19) {
                                 }
                                 break;
                              case 81:
                                 try {
                                    this.iFld = var4 % iArrFld[var7];
                                    var8 = var5 / var4;
                                    var3 = 209 / var3;
                                 } catch (ArithmeticException var18) {
                                 }
                                 break;
                              default:
                                 this.iFld += (int)(-117.773F + (float)(var7 * var7));
                           }
                        case 65:
                        case 66:
                           var3 -= sFld;
                           break;
                        case 67:
                           var10 += (float)((long)var7 + instanceCount);
                           break;
                        case 68:
                           var10 += (float)var7 - var10;
                        case 69:
                        case 70:
                           var5 -= (int)var13;
                           break;
                        case 71:
                           var16[var4 - 1] = -55L;
                     }

                     ++var7;
                  }
               case 52:
                  var3 += var20;
            }
         }
      }

      FuzzerUtils.out.println("i f d = " + var20 + "," + Float.floatToIntBits(var10) + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("d1 i1 i15 = " + Double.doubleToLongBits(var13) + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i16 i17 b2 = " + var5 + "," + var6 + "," + (var15 ? 1 : 0));
      FuzzerUtils.out.println("i18 i19 iArr = " + var7 + "," + var8 + "," + FuzzerUtils.checkSum(var9));
      FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.byFld = " + instanceCount + "," + this.iFld + "," + byFld);
      FuzzerUtils.out.println("Test.sFld Test.dArrFld Test.bArrFld = " + sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
      FuzzerUtils.out.println("Test.iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 93.81697);
      FuzzerUtils.init(bArrFld, true);
      FuzzerUtils.init((int[])iArrFld, (int)-2);
      FuzzerUtils.init(fArrFld, -2.892F);
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
