public class Test {
   public static final int N = 400;
   public static long instanceCount = -8933235804963499611L;
   public static boolean bFld = false;
   public int iFld = -43857;
   public static int[] iArrFld = new int[400];
   public static double[] dArrFld = new double[400];
   public static long vSmallMeth_check_sum;
   public static long vMeth_check_sum;
   public static long sMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vSmallMeth(int var0, int var1, int var2) {
      float[] var3 = new float[400];
      FuzzerUtils.init(var3, 60.671F);
      var3[(var1 >>> 1) % 400] = -6.0F;
      vSmallMeth_check_sum += (long)(var0 + var1 + var2) + Double.doubleToLongBits(FuzzerUtils.checkSum(var3));
   }

   public static void vMeth1(double var0, float var2, int var3) {
      boolean var4 = true;
      int var5 = -44421;
      boolean var6 = true;
      int var7 = -11;
      short var8 = -234;
      boolean var9 = true;
      int var10 = -213;
      int[] var11 = new int[400];
      long var12 = 6838349389279639813L;
      long[] var14 = new long[400];
      FuzzerUtils.init((int[])var11, (int)-14);
      FuzzerUtils.init(var14, 95L);
      var11[46] = var3;

      int var15;
      for(var15 = 4; var15 < 326; ++var15) {
         instanceCount = (long)var3;
         instanceCount += instanceCount;
      }

      var14[(var15 >>> 1) % 400] &= 10L;

      int var16;
      for(var16 = 156; var16 > 6; --var16) {
         var11[var16 + 1] = (int)instanceCount;
         var5 = (int)instanceCount;
         var2 -= (float)var15;

         for(var12 = 11L; var12 > 1L; var12 -= 2L) {
            instanceCount += var12 - var12;
            var7 += 166;
         }
      }

      int var17;
      for(var17 = 2; var17 < 201; ++var17) {
         var5 += var17;
         var10 += var17 * var17;
      }

      vMeth1_check_sum += Double.doubleToLongBits(var0) + (long)Float.floatToIntBits(var2) + (long)var3 + (long)var15 + (long)var5 + (long)var16 + (long)var7 + var12 + (long)var8 + (long)var17 + (long)var10 + FuzzerUtils.checkSum(var11) + FuzzerUtils.checkSum(var14);
   }

   public static short sMeth(long var0, long var2, int var4) {
      double var5 = 108.69093;
      float var7 = -34.42F;
      boolean var8 = true;
      boolean var9 = true;
      int var10 = -38321;
      int var11 = 112;
      int var12 = -46295;
      boolean var13 = true;
      byte var14 = -11;
      int var15 = -41008;
      short var16 = 1899;
      int[] var17 = new int[400];
      int[][][] var18 = new int[400][400][400];
      long[] var19 = new long[400];
      FuzzerUtils.init(var19, 3188266214L);
      FuzzerUtils.init((int[])var17, (int)204);
      FuzzerUtils.init((Object[][])var18, -62320);
      vMeth1(var5, var7, -35740);
      int var22 = 128;

      int var23;
      do {
         var19[var22] = (long)var4;

         for(var23 = 12; var23 > var22; --var23) {
            float var10000 = var7 - (float)var10;
            var7 = (float)var5;

            for(var11 = 1; var11 > 1; --var11) {
               var2 -= (long)var5;
               instanceCount = (long)((float)instanceCount + ((float)var11 * var7 + (float)var12 - (float)var22));
               var7 += (float)(var11 * var4 + var12 - var4);
            }
         }

         var17[var22] = var12;
         --var22;
      } while(var22 > 0);

      int var24;
      for(var24 = 6; 272 > var24; ++var24) {
         for(var15 = 1; 6 > var15; ++var15) {
            var18 = var18;
            var7 = 8.0F;
         }
      }

      long var20 = var0 + var2 + (long)var4 + Double.doubleToLongBits(var5) + (long)Float.floatToIntBits(var7) + (long)var22 + (long)var23 + (long)var10 + (long)var11 + (long)var12 + (long)var24 + (long)var14 + (long)var15 + (long)var16 + FuzzerUtils.checkSum(var19) + FuzzerUtils.checkSum(var17) + FuzzerUtils.checkSum((Object[][])var18);
      sMeth_check_sum += var20;
      return (short)((int)var20);
   }

   public static void vMeth(boolean var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 239;
      int var5 = 11;
      int var6 = -32;
      int var7 = 16;
      short var8 = -201;
      float var9 = 0.673F;

      int var10;
      for(var10 = 10; 265 > var10; ++var10) {
         vSmallMeth(var10, (int)((long)(var2++) % ((long)sMeth(instanceCount, instanceCount, var10) + instanceCount | 1L)), 206);
         if (var0) {
            instanceCount = (long)var10;
            int[] var10000 = iArrFld;
            var10000[var10 + 1] -= var4;
            var2 += var10;
            var4 = (int)((long)var4 + ((long)var10 * instanceCount + (long)var1 - instanceCount));
         }

         for(var5 = 1; var5 < 6; ++var5) {
            var9 -= (float)instanceCount;
            var6 *= var4;
            double[] var11 = dArrFld;
            var11[var5] += (double)var2;

            for(var7 = 1; var7 < 2; ++var7) {
               if (var1 != 0) {
                  vMeth_check_sum += (long)((var0 ? 1 : 0) + var1 + var2 + var10 + var4 + var5 + var6 + Float.floatToIntBits(var9) + var7 + var8);
                  return;
               }

               var1 *= (int)instanceCount;
               var1 -= 49;
            }
         }
      }

      vMeth_check_sum += (long)((var0 ? 1 : 0) + var1 + var2 + var10 + var4 + var5 + var6 + Float.floatToIntBits(var9) + var7 + var8);
   }

   public void mainTest(String[] var1) {
      int var2 = 960;
      boolean var3 = false;
      int var4 = -9;
      int var5 = -13;
      int var6 = -16687;
      int var7 = 161;
      int var8 = -235;
      int[][] var9 = new int[400][400];
      float var10 = 1.797F;
      double var11 = -72.86975;
      long[] var13 = new long[400];
      FuzzerUtils.init((int[][])var9, (int)0);
      FuzzerUtils.init(var13, -7L);

      for(int var14 = 0; var14 < 204; ++var14) {
         int var10000 = var2++;
         --var2;
         vSmallMeth(var10000, var2, var2);
      }

      var2 *= (int)(--var10);
      vMeth(bFld, var2, var2);
      var2 ^= var2;

      int var16;
      for(var16 = 1; var16 < 192; ++var16) {
         switch (var16 % 2 * 5 + 121) {
            case 126:
               for(var5 = 131; var5 > var16; --var5) {
                  var7 = 1;

                  while(var7 < 1) {
                     instanceCount += (long)(var7 | var7);
                     int[] var17 = iArrFld;
                     var17[var7 - 1] *= (int)instanceCount;
                     switch (var16 % 1 + 21) {
                        case 21:
                           var2 = var2;
                           var17 = iArrFld;
                           var17[var16 - 1] >>>= -13;
                           instanceCount |= (long)var4;
                           instanceCount = (long)var16;
                        default:
                           var9 = var9;
                           var8 = var8;
                           switch (var7 % 10 * 5 + 91) {
                              case 96:
                                 this.iFld += var7 | var6;
                              case 97:
                              case 98:
                              case 99:
                              case 100:
                              case 101:
                              case 102:
                              case 103:
                              case 104:
                              case 105:
                              case 106:
                              case 107:
                              case 108:
                              case 111:
                              case 112:
                              case 113:
                              case 114:
                              case 117:
                              case 119:
                              case 120:
                              case 121:
                              case 123:
                              case 124:
                              case 125:
                              case 127:
                              case 128:
                              case 130:
                              case 131:
                              case 132:
                              case 133:
                              default:
                                 break;
                              case 109:
                                 var6 += (int)var11;
                                 break;
                              case 116:
                                 var4 >>>= (int)instanceCount;
                                 var6 = (int)instanceCount;
                                 if (bFld) {
                                    var8 = (int)instanceCount;
                                 } else {
                                    var8 += var7 * var7;
                                    var10 -= (float)var5;
                                 }
                                 break;
                              case 118:
                                 var4 += var7;
                                 var13[var16 - 1] >>= var5;
                                 var2 = (int)instanceCount;
                              case 115:
                                 var13 = var13;
                                 break;
                              case 122:
                                 var4 &= var5;
                              case 110:
                                 var8 = var4;
                                 var2 += var7 * var7;
                                 break;
                              case 126:
                                 try {
                                    this.iFld = var9[var7 - 1][var5] / var16;
                                    var6 = this.iFld / var2;
                                    var9[var5][var16 + 1] = -679811288 % this.iFld;
                                 } catch (ArithmeticException var15) {
                                 }
                                 break;
                              case 129:
                                 var8 += var7 | var16;
                                 break;
                              case 134:
                                 bFld = bFld;
                           }

                           ++var7;
                     }
                  }
               }
               break;
            case 131:
               var2 -= (int)var11;
         }
      }

      FuzzerUtils.out.println("i3 f i30 = " + var2 + "," + Float.floatToIntBits(var10) + "," + var16);
      FuzzerUtils.out.println("i31 i32 i33 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i34 i35 d2 = " + var7 + "," + var8 + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("iArr3 lArr2 = " + FuzzerUtils.checkSum(var9) + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + this.iFld);
      FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)93);
      FuzzerUtils.init(dArrFld, -106.100693);
      vSmallMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      sMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
