public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -222L;
   public static int iFld = 31231;
   public double dFld = -25.42777;
   public static float fFld = 4.476F;
   public short sFld = -6543;
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, int var1) {
      int var2 = -62787;
      int var3 = -7;
      int var4 = 15595;
      int var5 = 0;
      int var6 = -37579;
      byte var7 = 51;
      int[] var8 = new int[400];
      int[] var9 = new int[400];
      short var10 = -9439;
      byte var11 = 29;
      double var12 = 116.121409;
      FuzzerUtils.init((int[])var8, (int)6);
      FuzzerUtils.init((int[])var9, (int)9);
      var8 = var8;

      for(var2 = 7; var2 < 328; ++var2) {
         var0 -= (int)instanceCount;
         iFld += var2 * var0 + var1 - var3;

         for(var4 = 1; var4 < 5; ++var4) {
            switch (var2 % 2 + 26) {
               case 26:
                  var1 = iFld;
                  if (var2 != 0) {
                     vMeth2_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var10 + var6 + var7 + var11) + Double.doubleToLongBits(var12) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var9);
                     return;
                  }

                  var10 -= (short)var0;

                  try {
                     var3 = var2 % var4;
                     var9[var2 + 1] = var8[var4 + 1] / -48370;
                     var5 = iFld % var3;
                  } catch (ArithmeticException var15) {
                  }
               case 27:
                  for(var6 = 2; var6 > 1; var6 -= 3) {
                     var11 = (byte)(var11 * 55);
                     var12 = (double)var4;
                     var3 -= (int)instanceCount;
                     iFld += var6;
                  }
            }
         }
      }

      vMeth2_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var10 + var6 + var7 + var11) + Double.doubleToLongBits(var12) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var9);
   }

   public static void vMeth1() {
      double var0 = -91.8643;
      boolean var2 = true;
      int var3 = -6;
      int var4 = -10;
      int var5 = -54571;
      short var6 = 159;
      int[] var7 = new int[400];
      short var8 = -13900;
      byte var9 = -76;
      FuzzerUtils.init((int[])var7, (int)-191);
      vMeth2(iFld, 18352);
      var7[(iFld >>> 1) % 400] = (int)fFld;
      var0 = (double)instanceCount;
      iFld -= iFld;

      int var10;
      for(var10 = 3; var10 < 157; ++var10) {
         var3 -= (int)instanceCount;
         var3 *= var8;
         instanceCount += (long)var10;
         var4 = 10;

         do {
            var9 = (byte)((int)var0);

            for(var5 = 1; var5 < 1; ++var5) {
               iFld -= (int)instanceCount;
               fFld = (float)var6;
               fFld *= -14.0F;
            }

            --var4;
         } while(var4 > 0);
      }

      vMeth1_check_sum += Double.doubleToLongBits(var0) + (long)var10 + (long)var3 + (long)var8 + (long)var4 + (long)var9 + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7);
   }

   public static void vMeth(short var0) {
      boolean var1 = true;
      long var2 = 92L;
      double var4 = 1.51951;
      int var6 = 1;

      while(true) {
         ++var6;
         if (var6 >= 384) {
            vMeth1();
            vMeth_check_sum += (long)(var0 + var6) + var2 + Double.doubleToLongBits(var4);
            return;
         }

         instanceCount ^= var2;
         fFld = (float)var4;
         iFld >>= (int)(var2 = (long)Math.min((int)((double)iFld - var4), iFld));
      }
   }

   public void mainTest(String[] var1) {
      float var2 = -28.479F;
      int var3 = -62635;
      int var4 = 24419;
      int var5 = 25205;
      int var6 = 38788;
      int var7 = -5;
      int var8 = 6;
      int var9 = 37;
      int[] var10 = new int[400];
      long var11 = -7L;
      boolean var13 = false;
      double[] var14 = new double[400];
      FuzzerUtils.init(var14, 123.4443);
      FuzzerUtils.init((int[])var10, (int)3);
      int var10001 = (iFld >>> 1) % 400;
      var14[var10001] += (double)(lArrFld[(iFld >>> 1) % 400]--);
      iFld = (int)((double)(-(iFld * iFld)) * (this.dFld + -62.452999114990234 - ((double)var2 + this.dFld)));

      for(var3 = 5; 136 > var3; ++var3) {
         byte var15 = -49;
         var2 += (float)((long)var3 * instanceCount + (long)var3) - var2;
         var4 += (int)(var2 - (float)(-159L + (long)var4 * instanceCount) - (var2 + (float)(var3 - var15)));

         label52:
         for(var5 = 8; var5 < 191; ++var5) {
            this.dFld = (double)Math.max(instanceCount, lArrFld[var3 + 1]);
            var6 += var6;
            vMeth((short)-655);
            switch ((iFld >>> 1) % 10 * 5 + 94) {
               case 102:
                  var7 = 1;

                  while(true) {
                     if (var7 >= 2) {
                        continue label52;
                     }

                     var14[var3] += (double)instanceCount;
                     var8 += var7 ^ iFld;
                     ++var7;
                  }
               case 108:
                  fFld += (float)var5;
                  var10[var5 - 1] -= -1;
                  break;
               case 112:
                  instanceCount = (long)var7;
               case 113:
                  var4 >>= var6;
               case 138:
                  iFld += var5;
                  break;
               case 115:
                  this.dFld += 0.8349999785423279;
                  iFld -= (int)instanceCount;
                  var2 += var2;
               case 117:
                  for(var11 = 1L; var11 < 2L; ++var11) {
                     instanceCount += var11;
                     var8 = var8;
                     var9 += (int)(var11 - (long)var5);
                     var4 += (int)((float)(var11 * (long)var6) + fFld - (float)var11);
                     var10[(int)(var11 + 1L)] += var8;
                     var9 += var8;
                  }

                  var14[var5 - 1] = 1.1710000038146973;
                  var2 += (float)var6;
                  break;
               case 116:
                  var8 = (int)((long)var8 + ((long)var5 * var11 + instanceCount - (long)var5));
               default:
                  if (var13) {
                  }
                  break;
               case 118:
                  var13 = var13;
                  break;
               case 142:
                  this.dFld = 45909.0;
                  this.sFld <<= (short)var8;
            }
         }
      }

      FuzzerUtils.out.println("f i i1 = " + Float.floatToIntBits(var2) + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i2 i3 i18 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i19 l1 i20 = " + var8 + "," + var11 + "," + var9);
      FuzzerUtils.out.println("b dArr iArr3 = " + (var13 ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)) + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("Test.fFld sFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -10L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
