public class Test {
   public static final int N = 400;
   public static long instanceCount = 4L;
   public static int iFld = 0;
   public static float fFld = 81.434F;
   public static boolean bFld = true;
   public double dFld = 0.7376;
   public static long[] lArrFld = new long[400];
   public int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(int var0, int var1) {
      long var2 = 67L;
      short var4 = -15342;
      int[] var5 = new int[400];
      FuzzerUtils.init((int[])var5, (int)142);

      for(var2 = 7L; 126L > var2; ++var2) {
         var5[(int)var2] += (int)instanceCount;
         instanceCount -= (long)iFld;
         var0 -= 10;
      }

      fFld += -44338.0F;
      long var6 = (long)(var0 + var1) + var2 + (long)var4 + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var6;
      return (int)var6;
   }

   public static void vMeth1(int var0, int var1, long var2) {
      boolean var4 = true;
      int var5 = -10850;
      int var6 = 4;
      int var7 = -10;
      short var8 = 28227;
      int[] var9 = new int[400];
      float var10 = -122.496F;
      short var11 = -19766;
      double var12 = -1.123341;
      FuzzerUtils.init((int[])var9, (int)-21);

      int var14;
      for(var14 = 5; var14 < 184; ++var14) {
         for(var10 = 1.0F; var10 < 9.0F; ++var10) {
            var11 += (short)((int)(var10 * (float)var6 + (float)var11 - (float)var1));
            instanceCount = (long)iMeth(-12773, var6);
            var12 += -43119.0;

            for(var7 = 1; var7 < 2; ++var7) {
               var12 = (double)fFld;
               var2 -= (long)var8;
               iFld <<= (int)instanceCount;
            }

            var9[var14 + 1] *= var14;
            var5 += (int)(var10 * var10);
         }

         bFld = bFld;
         var9[var14] <<= (int)var2;
         var6 += 8231;
      }

      iFld = (int)instanceCount;
      vMeth1_check_sum += (long)(var0 + var1) + var2 + (long)var14 + (long)var5 + (long)Float.floatToIntBits(var10) + (long)var6 + (long)var11 + Double.doubleToLongBits(var12) + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
   }

   public void vMeth(double var1) {
      int var3 = 14;
      int var4 = 8461;
      int var5 = 2;
      int var6 = 50;
      int var7 = 49255;
      int[] var8 = new int[400];
      boolean var9 = false;
      boolean[] var10 = new boolean[400];
      float var11 = 1.57F;
      short var12 = 13523;
      FuzzerUtils.init((int[])var8, (int)30278);
      FuzzerUtils.init(var10, false);
      if (var9 ^= var10[(var3 >>> 1) % 400] = var9) {
         var3 -= Math.abs(var8[(var3 >>> 1) % 400]);
         instanceCount = (long)Math.abs((int)(4564187144736978884L << (int)(-244L - ((long)var3 & instanceCount)) << var3 - -23071));
      } else {
         label53:
         for(var4 = 13; var4 < 274; ++var4) {
            var11 += (float)(var4 * var4);
            if (var9) {
               switch (var4 % 9 + 13) {
                  case 13:
                     var6 = 1;

                     while(true) {
                        if (var6 >= 6) {
                           continue label53;
                        }

                        vMeth1(var4, iFld, instanceCount);
                        var7 *= var5;
                        var7 -= var5;
                        instanceCount += (long)(var6 * var6);
                        if (iFld != 0) {
                           vMeth_check_sum += Double.doubleToLongBits(var1) + (long)var3 + (long)(var9 ? 1 : 0) + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var11) + (long)var6 + (long)var7 + (long)var12 + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var10);
                           return;
                        }

                        var7 *= var6;
                        instanceCount = (long)var7;
                        ++var6;
                     }
                  case 14:
                     var11 = 1.476F;
                  case 15:
                     if (bFld) {
                     }
                     break;
                  case 16:
                     var7 = var5;
                     break;
                  case 17:
                     fFld = (float)var1;
                  case 18:
                     var12 = (short)var3;
                     break;
                  case 19:
                     instanceCount = 88L;
                     break;
                  case 20:
                     instanceCount -= (long)var7;
                  case 21:
                     var3 >>>= var6;
                     break;
                  default:
                     instanceCount += (long)var4;
               }
            } else {
               var5 = var4;
            }
         }
      }

      vMeth_check_sum += Double.doubleToLongBits(var1) + (long)var3 + (long)(var9 ? 1 : 0) + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var11) + (long)var6 + (long)var7 + (long)var12 + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      byte var2 = -54;
      float var3 = 105.953F;
      int var4 = 7;
      boolean var5 = true;
      int var6 = -53709;
      int var7 = 47867;
      int var8 = -35;
      int var9 = -131;
      int var10 = -38442;
      int var11 = -96;
      short var12 = 11073;
      this.vMeth(this.dFld);
      iFld += -584236848;
      instanceCount *= (long)iFld;
      int[] var10000 = this.iArrFld;
      int var10001 = (iFld >>> 1) % 400;
      var10000[var10001] >>= var2;
      this.iArrFld[(iFld >>> 1) % 400] = iFld;
      fFld -= (float)iFld;
      instanceCount -= (long)var2;

      for(var3 = 5.0F; 165.0F > var3; ++var3) {
         bFld = false;
         var4 = var4;
      }

      int var13 = 1;

      do {
         switch (var13 % 9 * 5 + 24) {
            case 33:
               iFld += -5 + var13 * var13;
               iFld = (int)instanceCount;
               var6 = 3;

               for(; var6 < 103; ++var6) {
                  for(var8 = 1; var8 < 2; ++var8) {
                     this.iArrFld[var6 - 1] = var13;
                     iFld = var4;
                     var12 = (short)var8;
                  }

                  switch (var13 % 2 * 5 + 67) {
                     case 71:
                        var2 <<= (byte)((int)instanceCount);
                        break;
                     case 76:
                        iFld -= -6;

                        for(var10 = var13; var10 < 2; var10 += 3) {
                           var11 *= -81;
                           this.dFld += -189.0;
                           var7 += var10;
                        }

                        switch (var6 % 4 * 5 + 120) {
                           case 124:
                              var4 = var7;
                           case 133:
                              iFld *= var7;
                              var7 += var6 * var6;
                              var9 = 159;
                           case 123:
                              var11 = 163;
                           case 140:
                              iFld = var6;
                              continue;
                        }
                     default:
                        this.iArrFld = FuzzerUtils.int1array(400, 17119);
                  }
               }
               break;
            case 44:
            case 68:
               var11 += var13;
               break;
            case 45:
               var4 = (int)((long)var4 + (long)var13 * instanceCount);
            default:
               iFld = var9;
               break;
            case 52:
               var9 += var11;
               break;
            case 54:
               iFld = var8;
               break;
            case 58:
               instanceCount += 188L + (long)(var13 * var13);
               break;
            case 66:
               instanceCount += -6L;
            case 28:
               instanceCount = (long)var13;
         }

         ++var13;
      } while(var13 < 244);

      FuzzerUtils.out.println("by f2 i16 = " + var2 + "," + Float.floatToIntBits(var3) + "," + var4);
      FuzzerUtils.out.println("i17 i18 i19 = " + var13 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i20 i21 s2 = " + var8 + "," + var9 + "," + var12);
      FuzzerUtils.out.println("i22 i23 = " + var10 + "," + var11);
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld dFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iArrFld = " + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 3983984012L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
