public class Test {
   public static final int N = 400;
   public static long instanceCount = -57488L;
   public static long[] lArrFld = new long[400];
   public volatile int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2() {
      boolean var0 = true;
      boolean var1 = true;
      int var2 = -14;
      int var3 = 12;
      int var4 = -7;
      int[] var5 = new int[400];
      byte var6 = 6;
      boolean var7 = true;
      double var8 = -55.90724;
      FuzzerUtils.init((int[])var5, (int)175);
      int var12 = -14;

      int var13;
      for(var13 = 15; var13 < 306; ++var13) {
         if (var7) {
            for(var3 = 6; var3 > var13; --var3) {
               try {
                  var2 = var5[var3] % var3;
                  var2 = var3 / -46140;
                  var2 = var4 / -1812897527;
               } catch (ArithmeticException var11) {
               }
            }
         } else {
            var4 -= var6;
            var12 = var2;
            var5[var13 + 1] <<= (int)instanceCount;
         }

         var12 -= var13;
         var12 += -102 + var13 * var13;
         var12 = var12;
         var5[var13 + 1] *= -243;
         var5 = var5;
         instanceCount -= (long)var8;
      }

      vMeth2_check_sum += (long)(var12 + var13 + var2 + var3 + var4 + var6 + (var7 ? 1 : 0)) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var5);
   }

   public static void vMeth1(long var0) {
      boolean var2 = true;
      byte var3 = 13;
      int var4 = -4;
      int var5 = 58;
      int[] var6 = new int[400];
      long var7 = -218L;
      byte var9 = 84;
      short var10 = -20484;
      FuzzerUtils.init((int[])var6, (int)-22546);
      vMeth2();

      int var14;
      for(var14 = 389; 18 < var14; --var14) {
         var3 = 123;
         instanceCount -= -108L;

         for(var7 = 1L; var7 < 5L; ++var7) {
            double var11 = 2.82676;
            float var13 = -93.234F;
            instanceCount = instanceCount;
            var6 = FuzzerUtils.int1array(400, -7896);
            var9 *= (byte)((int)var0);
            var3 = 2;
            var11 -= 154.0;
            float var10000 = var13 + (float)var3;
         }

         var5 = 1;

         do {
            var4 >>= (int)instanceCount;
            var10 >>>= (short)var3;
            var4 <<= 6;
            ++var5;
         } while(var5 < 5);
      }

      vMeth1_check_sum += var0 + (long)var14 + (long)var3 + var7 + (long)var4 + (long)var9 + (long)var5 + (long)var10 + FuzzerUtils.checkSum(var6);
   }

   public static void vMeth(long var0, byte var2, long var3) {
      boolean var5 = true;
      int var6 = -35923;
      int var7 = 158;
      short var8 = 24892;
      char var9 = '\uef4d';
      int var10 = -104;
      short var11 = 11679;
      int[] var12 = new int[400];
      short var13 = -929;
      short[] var14 = new short[400];
      long var15 = 7L;
      boolean var17 = false;
      FuzzerUtils.init((int[])var12, (int)-9);
      FuzzerUtils.init((short[])var14, (short)17566);
      int var18 = 267;

      while(true) {
         --var18;
         if (var18 <= 0) {
            vMeth_check_sum += var0 + (long)var2 + var3 + (long)var18 + (long)var6 + (long)var13 + (long)var7 + (long)var8 + var15 + (long)var9 + (long)var10 + (long)var11 + (long)(var17 ? 1 : 0) + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var14);
            return;
         }

         var6 += var18;
         vMeth1(var3);
         var12 = var12;
         var13 = -5;

         for(var7 = 6; var7 > 1; --var7) {
            for(var15 = 2L; var15 > (long)var7; --var15) {
               var12[var7 + 1] += var18;
            }

            for(var10 = 1; var10 < 2; var10 += 2) {
               switch ((var7 >>> 1) % 2 + 120) {
                  case 120:
                  case 121:
                     instanceCount = -14L;
                     break;
                  default:
                     var17 = false;
                     float[] var10000 = fArrFld;
                     var10000[var18 - 1] *= (float)var9;
               }

               var12[var7 + 1] |= (int)var15;
               var14[var7 + 1] >>= (short)var11;
            }
         }
      }
   }

   public void mainTest(String[] var1) {
      long var2 = 20266L;
      int var4 = 104;
      boolean var5 = true;
      int var6 = -29459;
      int var7 = -4;
      int var8 = 10;
      byte var9 = -33;
      byte[] var10 = new byte[400];
      boolean var11 = false;
      float var12 = -80.438F;
      double[] var13 = new double[400];
      FuzzerUtils.init(var10, (byte)-108);
      FuzzerUtils.init(var13, 2.67153);
      instanceCount += ++instanceCount;

      int[] var10000;
      for(var2 = 6L; var2 < 340L; ++var2) {
         long var16 = ++lArrFld[(int)(var2 - 1L)];
         int var10002 = var4 + var4;
         --var4;
         var9 *= (byte)((int)(var16 * (long)(var10002 % (var4 | 1))));
         int var17 = (int)(var2 - 1L);
         var10002 = var9-- + var4;
         --var4;
         this.iArrFld[var17] = var10002 ^ var4;
         int[] var18 = this.iArrFld;
         var10002 = (int)var2;
         int var10004 = var18[(int)var2];
         var18[var10002] = var18[(int)var2] + 1;
         instanceCount += (long)var10004;
         if (var11) {
            var9 >>= (byte)var4;
            var10[(int)(var2 + 1L)] = (byte)((int)(instanceCount = ++lArrFld[(int)(var2 + 1L)]));
            vMeth(instanceCount, (byte)-113, var2);
         } else {
            var4 = var4;
            var12 += (float)var2;
            var10000 = this.iArrFld;
            var10000[(int)(var2 - 1L)] ^= (int)var2;
         }

         var4 = var4;
         float var15 = var12 + (float)var2;
         this.iArrFld[(int)var2] = 77;
         var12 = (float)var4;
      }

      int var14;
      for(var14 = 254; var14 > 1; var14 -= 2) {
         lArrFld[var14] = (long)var4;
         var7 = 12;

         while(199 > var7) {
            lArrFld[var14 + 1] = -14L;
            switch (var14 % 1 * 5 + 1) {
               case 2:
                  instanceCount <<= var6;
                  var6 += var7;
                  var8 *= (int)instanceCount;
               default:
                  var10000 = this.iArrFld;
                  var10000[var7] -= 9;
                  var10000 = this.iArrFld;
                  var10000[var14] <<= -14;
                  var12 += var12;
                  var12 = (float)var7;
                  ++var7;
            }
         }
      }

      FuzzerUtils.out.println("l i by = " + var2 + "," + var4 + "," + var9);
      FuzzerUtils.out.println("b2 f1 i17 = " + (var11 ? 1 : 0) + "," + Float.floatToIntBits(var12) + "," + var14);
      FuzzerUtils.out.println("i18 i19 i20 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("byArr dArr = " + FuzzerUtils.checkSum(var10) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)));
      FuzzerUtils.out.println("Test.instanceCount Test.lArrFld iArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 2368852000L);
      FuzzerUtils.init(fArrFld, 125.129F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
