public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -3010636510L;
   public static volatile double dFld = -106.101249;
   public long lFld = -213L;
   public static short sFld = -14224;
   public byte byFld = 114;
   public static int[] iArrFld = new int[400];
   public static long lMeth_check_sum;
   public static long iMeth_check_sum;
   public static long fMeth_check_sum;

   public static float fMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = -82;
      int var5 = 43966;
      int var6 = -39349;
      int var7 = -3;
      byte var8 = 0;
      double var9 = -29.112939;
      boolean var11 = true;
      boolean[] var12 = new boolean[400];
      FuzzerUtils.init(var12, false);

      int var15;
      for(var15 = 7; var15 < 182; ++var15) {
         int[] var10000 = iArrFld;
         var10000[var15] -= (int)instanceCount;
         var10000 = iArrFld;
         var10000[var15] <<= var1;
         var9 += (double)var15;
         var12[var15] = var11;
         var0 = -4;

         for(var5 = 9; var5 > 1; var5 -= 3) {
            for(var7 = var15; 5 > var7; ++var7) {
               var1 -= (int)instanceCount;
               var2 >>>= var7;
               if (var11) {
                  break;
               }

               var4 -= var7;
               if (var1 != 0) {
               }
            }

            var2 *= var8;
            iArrFld[var5 - 1] = (int)instanceCount;
         }
      }

      long var13 = (long)(var0 + var1 + var2 + var15 + var4) + Double.doubleToLongBits(var9) + (long)(var11 ? 1 : 0) + (long)var5 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var12);
      fMeth_check_sum += var13;
      return (float)var13;
   }

   public static int iMeth(byte var0) {
      int var1;
      int var2;
      int var3;
      int var4;
      int var5;
      double var6;
      double[] var8;
      float var9;
      boolean var10;
      var1 = 7;
      var2 = -80;
      var3 = -8;
      var4 = 5024;
      var5 = 11;
      var6 = 2.21364;
      var8 = new double[400];
      var9 = 1.97F;
      var10 = false;
      FuzzerUtils.init(var8, 89.62794);
      label55:
      switch (((int)((double)var1 + -2.3076) >>> 1) % 2 + 121) {
         case 121:
            var2 = 1;

            while(true) {
               ++var2;
               if (var2 >= 191) {
                  var1 += var1;
                  var1 -= 112;
                  break label55;
               }

               fMeth(12, -82, var1);
               iArrFld = iArrFld;
               var6 = var6;
            }
         case 122:
            var3 = 1;

            while(true) {
               label45:
               while(true) {
                  ++var3;
                  if (var3 >= 238) {
                     break label55;
                  }

                  var6 /= (double)(var3 | 1);
                  switch (var3 % 10 + 81) {
                     case 81:
                        var6 *= (double)var3;
                        var1 = var3;
                        var4 = 1;

                        while(true) {
                           if (var4 >= 7) {
                              continue label45;
                           }

                           instanceCount -= (long)var3;
                           var5 &= var4;
                           ++var4;
                        }
                     case 82:
                        instanceCount = (long)((float)instanceCount + ((float)(var3 * var4) + var9 - (float)var0));
                     case 83:
                        instanceCount += (long)var3;
                        break;
                     case 84:
                        var5 |= var5;
                        break;
                     case 85:
                        if (var10) {
                        }
                        break;
                     case 86:
                        instanceCount *= (long)var3;
                        break;
                     case 87:
                        var1 = var2;
                        break;
                     case 88:
                        instanceCount = (long)var1;
                     case 89:
                        break label45;
                     case 90:
                        var0 = (byte)var1;
                     default:
                        var8[var3 + 1] -= (double)var4;
                  }
               }

               int[] var10000 = iArrFld;
               var10000[var3 - 1] >>= -10291;
            }
         default:
            instanceCount = (long)var9;
      }

      long var11 = (long)(var0 + var1 + var2) + Double.doubleToLongBits(var6) + (long)var3 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var9) + (long)(var10 ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static long lMeth(int var0, long var1, int var3) {
      boolean var4 = true;
      int var5 = 29;
      int var6 = 3;
      byte var7 = 14;
      long[][] var8 = new long[400][400];
      FuzzerUtils.init(var8, -3816269848L);
      --var0;
      instanceCount += (long)var0;
      var1 += (long)iMeth((byte)78);

      int var11;
      for(var11 = 374; var11 > 16; var11 -= 3) {
         int[] var10000 = iArrFld;
         var10000[var11 + 1] += (int)dFld;

         for(var6 = 1; var6 < 13; ++var6) {
            instanceCount = (long)var3;
            var5 >>= var6;
            var3 += var6 + var5;
            var10000 = iArrFld;
            var10000[var6] -= var5;
            iArrFld[var6 + 1] = 14;
            var1 += (long)(-82.667F + (float)(var6 * var6));
            var0 = var7 * var3;
            var8[var11][var6] >>= -39;
         }

         if (var7 != 0) {
         }
      }

      long var9 = (long)var0 + var1 + (long)var3 + (long)var11 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
      lMeth_check_sum += var9;
      return var9;
   }

   public void mainTest(String[] var1) {
      int var2 = 20;
      boolean var3 = true;
      boolean var4 = true;
      int var5 = -193;
      int var6 = 227;
      int var7 = -22548;
      int var8 = 138;
      int var9 = 54241;
      float var10 = 0.873F;
      boolean var11 = true;
      var2 >>= (int)lMeth(var2, this.lFld, var2);
      var2 -= (int)instanceCount;
      int var14 = 1;

      int var15;
      do {
         for(var15 = 4; var15 < 65; var15 += 2) {
            int[] var10000;
            for(var6 = 1; 3 > var6; ++var6) {
               var10000 = iArrFld;
               var10000[var14 - 1] <<= 10;
               this.lFld -= (long)var2;
               dFld = (double)this.lFld;
               var7 *= 1;
            }

            var7 *= sFld;
            this.byFld += (byte)var5;
            var5 += var2;
            instanceCount += (long)dFld;
            dFld -= (double)var10;
            var2 = (int)((long)var2 + ((long)var15 ^ (long)var10));
            var2 += var6;

            for(var8 = 1; 3 > var8; ++var8) {
               iArrFld = iArrFld;
               var2 += var15;
               var10 -= (float)dFld;
               switch (var14 % 6 + 2) {
                  case 2:
                     var5 = var6;
                     var10000 = iArrFld;
                     var10000[var14 + 1] *= var15;
                     var9 *= var6;
                     break;
                  case 3:
                     if (var11) {
                        break;
                     }

                     instanceCount += (long)(var8 * var8);
                  case 4:
                     this.byFld = (byte)var15;
                     var9 *= (int)dFld;
                     var10000 = iArrFld;
                     var10000[var8] ^= (int)instanceCount;
                     var9 = (int)var10;
                  case 5:
                     try {
                        var2 = -169 / var6;
                        var5 = '\uf54d' % var9;
                        var7 = var6 % 1521408199;
                     } catch (ArithmeticException var13) {
                     }
                     break;
                  case 6:
                     this.byFld >>= (byte)var15;
                  case 7:
                     if (var11) {
                     }
               }
            }
         }

         ++var14;
      } while(var14 < 386);

      FuzzerUtils.out.println("i i21 i22 = " + var2 + "," + var14 + "," + var15);
      FuzzerUtils.out.println("i23 i24 i25 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("f1 i26 i27 = " + Float.floatToIntBits(var10) + "," + var8 + "," + var9);
      FuzzerUtils.out.println("b2 = " + (var11 ? 1 : 0));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld lFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + this.lFld);
      FuzzerUtils.out.println("Test.sFld byFld Test.iArrFld = " + sFld + "," + this.byFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)6);
      lMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
   }
}
