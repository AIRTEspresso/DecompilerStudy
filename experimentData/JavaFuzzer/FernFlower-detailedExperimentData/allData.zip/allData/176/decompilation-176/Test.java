public class Test {
   public static final int N = 400;
   public static long instanceCount = 216L;
   public static float fFld = 0.587F;
   public static int[] iArrFld = new int[400];
   public static double[] dArrFld = new double[400];
   public static float[][] fArrFld = new float[400][400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0) {
      byte var1 = 113;
      boolean var2 = true;
      int var3 = 43697;
      int var4 = -20;
      int var5 = 31518;
      int var6 = 5;
      int var7 = -107;
      double var8 = -1.4457;
      boolean var10 = false;
      short var11 = -29349;
      iArrFld[(var0 >>> 1) % 400] = (int)instanceCount;
      int[] var10000 = iArrFld;
      var10000[(var0 >>> 1) % 400] &= var1;

      int var14;
      for(var14 = 3; var14 < 125; ++var14) {
         var0 |= var0;
         switch (var14 % 9 + 29) {
            case 29:
               var0 >>= var0;

               for(var4 = 13; var4 > 1; var4 -= 2) {
                  for(var6 = 1; var6 < 3; ++var6) {
                     var0 += var6;
                     iArrFld[var6] = var0;
                     if (var3 != 0) {
                     }

                     var5 *= var7;
                     instanceCount -= (long)fFld;
                     iArrFld[var6 + 1] = 134;
                     var3 = var3;
                  }
               }
               break;
            case 30:
               var8 *= (double)fFld;
            case 31:
               iArrFld[var14] = var4;
            case 32:
               instanceCount -= (long)var14;
               break;
            case 33:
               var3 = -7870;
               break;
            case 34:
               var1 += (byte)var14;
            case 35:
               var10 = var10;
            case 36:
               var3 += -81 + var14 * var14;
            case 37:
               if (var10) {
               }
               break;
            default:
               var7 *= var11;
         }
      }

      long var12 = (long)(var0 + var1 + var14 + var3 + var4 + var5 + var6 + var7) + Double.doubleToLongBits(var8) + (long)(var10 ? 1 : 0) + (long)var11;
      lMeth_check_sum += var12;
      return var12;
   }

   public static void vMeth1(float var0, boolean var1, byte var2) {
      boolean var3 = true;
      int var4 = -121;
      int var5 = 53510;
      int var6 = 136;
      double var7 = 0.37123;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, -3677485691447833902L);

      int var10;
      for(var10 = 16; var10 < 313; ++var10) {
         var0 -= (float)(var4 * '\udaaa');

         for(var5 = 1; 6 > var5; ++var5) {
            int[] var10000 = iArrFld;
            var10000[var5] += (int)(var0 - (float)(--iArrFld[var5]));
            var10000 = iArrFld;
            var10000[var10] >>>= (int)var9[var10 + 1];
            switch ((var10 >>> 1) % 10 * 5 + 7) {
               case 11:
                  var4 *= var6;
               case 12:
               case 13:
               case 14:
               case 15:
               case 17:
               case 18:
               case 19:
               case 20:
               case 21:
               case 22:
               case 23:
               case 25:
               case 26:
               case 27:
               case 28:
               case 30:
               case 32:
               case 33:
               case 34:
               case 35:
               case 37:
               case 38:
               case 40:
               case 41:
               case 42:
               case 43:
               case 46:
               default:
                  break;
               case 24:
                  var6 += 23;
                  break;
               case 29:
                  var6 <<= -19;
                  break;
               case 31:
                  fFld = (float)var6;
                  var4 += var5 * var5;
                  break;
               case 36:
               case 44:
                  double[] var11 = dArrFld;
                  var11[(var5 >>> 1) % 400] -= 11.0;
                  break;
               case 39:
                  var0 = (float)var4;
                  var6 += var5;
                  break;
               case 45:
                  instanceCount += (long)var10;
                  break;
               case 47:
                  var6 >>>= (int)((instanceCount -= (long)(var7 + (double)var2)) * lMeth(var5));
                  fFld -= (float)var7;
               case 16:
                  var4 += var5 * var4 + var5 - var2;
                  var4 += var5 * var4;
            }
         }
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + (var1 ? 1 : 0) + var2 + var10 + var4 + var5 + var6) + Double.doubleToLongBits(var7) + FuzzerUtils.checkSum(var9);
   }

   public static void vMeth() {
      byte var0 = 67;
      int var1 = 37531;
      int var2 = -2;
      int var3 = 9;
      int var4 = -12743;
      int var5 = -52049;
      double var6 = -14.59992;
      long[] var8 = new long[400];
      short[] var9 = new short[400];
      FuzzerUtils.init(var8, 24885L);
      FuzzerUtils.init((short[])var9, (short)15054);
      vMeth1(-1.957F, true, var0);

      for(var1 = 11; var1 < 397; ++var1) {
         var2 *= (int)var6;

         for(var3 = 4; var3 > 1; var3 -= 2) {
            fFld += (float)var1;
            var5 = 1;

            do {
               var8[var5] <<= var1;
               ++var5;
            } while(var5 < 4);

            switch (var1 % 4 * 5 + 69) {
               case 74:
                  var4 = -1;
                  break;
               case 78:
                  var2 = (int)((long)var2 + ((long)(var3 * var2) + instanceCount - (long)var4));
                  var2 *= var2;
                  var4 = (int)((long)var4 + ((long)var3 - instanceCount));
                  var2 = var1;
                  break;
               case 87:
                  instanceCount = instanceCount;
               case 89:
                  var9[var3 - 1] = (short)var5;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2) + Double.doubleToLongBits(var6) + (long)var3 + (long)var4 + (long)var5 + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var9);
   }

   public void mainTest(String[] var1) {
      int var2 = 52929;
      int var3 = -5;
      boolean var4 = true;
      int var5 = 61;
      float var6 = -92.28F;
      double var7 = 0.127586;
      instanceCount = -19053L;

      for(var2 = 2; var2 < 273; ++var2) {
         int var10000 = var3 * (var2 << (int)((long)((float)(var2 >>> var3) + var6)));
         var3 = iArrFld[var2 - 1];
         vMeth();
         fFld = (float)var7;
      }

      instanceCount -= (long)var6;

      int var9;
      for(var9 = 12; 213 > var9; ++var9) {
         var5 += 191 + var9 * var9;
      }

      float[] var10 = fArrFld[(var2 >>> 1) % 400];
      var10[183] += 4.0F;
      FuzzerUtils.out.println("i i1 f = " + var2 + "," + var3 + "," + Float.floatToIntBits(var6));
      FuzzerUtils.out.println("d3 i19 i20 = " + Double.doubleToLongBits(var7) + "," + var9 + "," + var5);
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.dArrFld Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(iArrFld, -46777);
      FuzzerUtils.init(dArrFld, 60.85987);
      FuzzerUtils.init(fArrFld, 65.453F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
