public class Test {
   public static final int N = 400;
   public static long instanceCount = -3576743641427970674L;
   public static int[] iArrFld = new int[400];
   public static volatile double[] dArrFld = new double[400];
   public static float[] fArrFld = new float[400];
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, byte var1, short var2) {
      double var3 = -1.129178;
      int var5 = 58684;
      int var6 = 23824;
      int var7 = -16;
      float var8 = 122.329F;
      float[] var9 = new float[400];
      boolean var10 = false;
      FuzzerUtils.init(var9, 0.857F);
      var0 = (int)instanceCount;
      var3 = (double)var1;
      var5 = 1;

      do {
         var0 *= var0;
         var6 += var5 * var5;
         label29:
         switch ((var6 >>> 1) % 10 + 112) {
            case 112:
               var6 += 'ꁀ' + var5 * var5;
            case 113:
               var0 += var5 * var0 + var6 - var2;
               break;
            case 114:
               var6 &= var6;
               break;
            case 115:
               var7 = 1;

               while(true) {
                  ++var7;
                  if (var7 >= 7) {
                     instanceCount += 41L + (long)(var5 * var5);
                     instanceCount += (long)(var5 * var5);
                     break label29;
                  }

                  var6 += 0 + var7 * var7;
               }
            case 116:
               var6 = (int)((float)var6 + ((float)((long)var5 * instanceCount) + var8 - var8));
               break;
            case 117:
               var0 = var0;
               break;
            case 118:
               var10 = false;
               break;
            case 119:
               var0 = (int)instanceCount;
            case 120:
               var6 += var5 * var6 + var7 - var7;
               break;
            case 121:
               var2 = 0;
               break;
            default:
               var0 = (int)instanceCount;
         }

         ++var5;
      } while(var5 < 224);

      vMeth1_check_sum += (long)(var0 + var1 + var2) + Double.doubleToLongBits(var3) + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var8) + (long)(var10 ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
   }

   public static int iMeth(int var0, int var1, int var2) {
      short var3 = -15448;
      boolean var4 = true;
      byte var5 = 4;
      int var6 = 9;
      int var7 = -241;
      int var8 = 2820;
      double var9 = -2.33613;
      float var11 = 0.537F;
      byte var12 = 10;
      vMeth1(var2, (byte)58, var3);

      int var16;
      for(var16 = 13; var16 < 324; ++var16) {
         var9 = -3.5626879521929318E18;
         fArrFld[var16 + 1] = (float)var5;

         for(var6 = var16; var6 < 5; ++var6) {
            var0 *= (int)var11;
            var9 /= (double)((long)var11 | 1L);

            try {
               var1 = var6 % var7;
               int var10000 = var6 % var0;
               var2 = iArrFld[var6 + 1] % '觱';
            } catch (ArithmeticException var15) {
            }

            var8 = 1;

            while(true) {
               ++var8;
               if (var8 >= 1) {
                  break;
               }

               switch ((var5 >>> 1) % 2 * 5 + 26) {
                  case 28:
                     instanceCount -= -62370L;
                     var11 += (float)(-8L + (long)(var8 * var8));
                     var2 = -17405;
                     break;
                  case 36:
                     var12 = (byte)var0;
                     var7 = (int)instanceCount;
                     break;
                  default:
                     var0 = var5;
               }
            }
         }
      }

      long var13 = (long)(var0 + var1 + var2 + var3 + var16 + var5) + Double.doubleToLongBits(var9) + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var11) + (long)var8 + (long)var12;
      iMeth_check_sum += var13;
      return (int)var13;
   }

   public void vMeth() {
      int var1 = -12497;
      int var2 = 45755;
      byte var3 = 3;
      int var4 = -11;
      short var5 = 19782;
      short var6 = 129;
      short var7 = 32230;
      double var8 = -1.6744;
      instanceCount = instanceCount += (long)iMeth(var1, var1, var1);
      var1 = 14;
      var8 -= (double)instanceCount;
      instanceCount -= (long)var1;

      for(var2 = 12; var2 < 287; ++var2) {
         var1 *= var3;

         for(var4 = 6; var4 > 1; --var4) {
            var1 = var5;
         }
      }

      vMeth_check_sum += (long)var1 + Double.doubleToLongBits(var8) + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -123;
      boolean var4 = true;
      int var5 = -6;
      int var6 = -10;
      int var7 = 77;
      int var8 = 172;
      int var9 = -22957;
      int var10 = -35403;
      int var11 = 12;
      short var12 = 11998;
      float var13 = -117.313F;

      int[] var10000;
      int var17;
      for(var17 = 8; var17 < 145; ++var17) {
         this.vMeth();
         var10000 = iArrFld;
         var10000[var17] *= var17;
      }

      var3 += 2;
      lArrFld[(var3 >>> 1) % 400] = (long)var17;
      var3 = 9;

      int var18;
      for(var18 = 9; var18 < 154; var18 += 3) {
         var5 += var18 * var18;
         byte var19 = 7;
         var12 = (short)(var19 + (short)(var18 * var18));
         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 275) {
               break;
            }

            for(var7 = 2; var18 < var7; --var7) {
               iArrFld[var6] = var6;
               iArrFld[var18] = (int)instanceCount;
               dArrFld[var18] = 6.20961168E8;
            }

            var12 -= (short)((int)var13);
            instanceCount = (long)var5;

            for(var9 = 1; var9 < 2; ++var9) {
               var5 = -8;
               var8 += var9 * var6 + var17 - var7;

               try {
                  var10 = 199 % var18;
                  var3 = var17 % -127;
                  iArrFld[var18 - 1] = 1566000365 % var17;
               } catch (ArithmeticException var16) {
               }

               var10000 = iArrFld;
               var10000[var6] |= var3;
               var10000 = iArrFld;
               var10000[var6 - 1] *= var8;
               switch (var18 % 8 + 25) {
                  case 25:
                     var5 = var9;

                     try {
                        var5 = var7 / var5;
                        var3 = var10 / var10;
                        int var20 = var10 / var5;
                     } catch (ArithmeticException var15) {
                     }

                     var8 = var11;
                     ++var5;
                     break;
                  case 26:
                     instanceCount = 0L;
                     var13 += (float)(var9 * var9);
                     break;
                  case 27:
                     var8 += (int)instanceCount;
                     break;
                  case 28:
                     var11 = var17;
                     break;
                  case 29:
                  case 30:
                     var10 -= var6;
                     break;
                  case 31:
                     instanceCount = (long)var6;
                     break;
                  case 32:
                     var12 = 9525;
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 i22 = " + var17 + "," + var3 + "," + var18);
      FuzzerUtils.out.println("i23 s2 i24 = " + var5 + "," + var12 + "," + var6);
      FuzzerUtils.out.println("i25 i26 f3 = " + var7 + "," + var8 + "," + Float.floatToIntBits(var13));
      FuzzerUtils.out.println("i27 i28 i29 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("Test.instanceCount Test.iArrFld Test.dArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("Test.fArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)84);
      FuzzerUtils.init(dArrFld, 14.75313);
      FuzzerUtils.init(fArrFld, -2.37F);
      FuzzerUtils.init(lArrFld, 3133525093405025388L);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
