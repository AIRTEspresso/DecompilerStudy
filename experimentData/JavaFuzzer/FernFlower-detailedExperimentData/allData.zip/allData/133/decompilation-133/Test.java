public class Test {
   public static final int N = 400;
   public static long instanceCount = -3L;
   public short sFld = 4906;
   public volatile boolean[] bArrFld = new boolean[400];
   public boolean[] bArrFld1 = new boolean[400];
   public volatile int[] iArrFld = new int[400];
   public static long iMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(long var0) {
      int var2 = -13;
      boolean var3 = true;
      int var4 = -40535;
      int var5 = 52359;
      int[][] var6 = new int[400][400];
      byte var7 = -100;
      float var8 = 19.738F;
      float var9 = 1.285F;
      boolean var10 = true;
      FuzzerUtils.init((int[][])var6, (int)-23420);
      var2 += var2;
      var2 = var7;
      var8 = 1.0F;

      int var11;
      do {
         var2 = var2;
         var11 = 1;

         while(true) {
            ++var11;
            if (var11 >= 7) {
               break;
            }

            for(var4 = 1; var4 < 1; ++var4) {
               switch ((int)(var8 % 5.0F + 67.0F)) {
                  case 67:
                     var5 = (int)((long)var5 + ((long)var4 - instanceCount));
                     break;
                  case 68:
                     if (!var10) {
                        var9 -= -41761.0F;
                        var2 *= 195;
                     }
                     break;
                  case 69:
                     var6[var11][var11] += (int)var0;
                     var2 >>>= var2;
                     break;
                  case 70:
                  case 71:
                  default:
                     var9 -= (float)var5;
               }
            }
         }
      } while(++var8 < 232.0F);

      vMeth1_check_sum += var0 + (long)var2 + (long)var7 + (long)Float.floatToIntBits(var8) + (long)var11 + (long)var4 + (long)var5 + (long)(var10 ? 1 : 0) + (long)Float.floatToIntBits(var9) + FuzzerUtils.checkSum(var6);
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = -8759;
      int var2 = 7;
      int var3 = 48;
      int var4 = -203;
      int var5 = -39454;
      int var6 = 8;
      int[] var7 = new int[400];
      float var8 = 97.63F;
      FuzzerUtils.init((int[])var7, (int)0);
      vMeth1(instanceCount);

      int var12;
      for(var12 = 13; var12 < 388; ++var12) {
         instanceCount = (long)var12;

         for(var2 = var12; var2 < 5; ++var2) {
            var3 = (int)instanceCount;
            var1 = var12;
            var3 += var2;
         }

         instanceCount += (long)var12;
         var7[var12] |= var2;
         var4 = 5;

         do {
            var8 += (float)(var4 * var4);
            label48:
            switch (79) {
               case 80:
                  try {
                     var6 = -200 / var3;
                     var6 = 1775423490 % var5;
                     var3 = '鸰' / var12;
                  } catch (ArithmeticException var10) {
                  }
                  break;
               case 81:
                  var3 *= (int)instanceCount;
                  break;
               case 92:
                  var1 = var4;
                  break;
               case 99:
               case 104:
                  var1 += var4;
                  break;
               case 103:
                  var5 = 3;

                  while(true) {
                     if (var5 <= var4) {
                        break label48;
                     }

                     try {
                        var1 = -124 / var7[164];
                        var3 = var2 / -17995;
                        var1 = var6 / var7[var4];
                     } catch (ArithmeticException var11) {
                     }

                     instanceCount -= (long)var2;
                     --var5;
                  }
               default:
                  var6 += var4 - var2;
            }

            var4 -= 3;
         } while(var4 > 0);
      }

      vMeth_check_sum += (long)(var12 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var8) + var5 + var6) + FuzzerUtils.checkSum(var7);
   }

   public static int iMeth(int var0) {
      float var1 = -1.169F;
      boolean var2 = true;
      short var3 = -11936;
      int var4 = -7;
      int var5 = -71;
      int var6 = 230;
      int var7 = -38420;
      int var8 = 228;
      int[] var9 = new int[400];
      byte var10 = -59;
      boolean var11 = false;
      FuzzerUtils.init(var9, -37605);
      var0 *= (int)((float)var0 + -(var1 - var1) + (float)var9[(var0 >>> 1) % 400]);
      --var0;
      var0 = Integer.reverseBytes(var0) / (Math.min((int)(31086L + ((long)var0 - instanceCount)), var0) | 1);

      int var14;
      for(var14 = 5; var14 < 162; ++var14) {
         for(var4 = var14; var4 < 10; ++var4) {
            var5 >>= (int)(instanceCount--);
            int var10001 = var14 - 1;
            int var10002 = var9[var14 - 1];
            int var10003 = var3 - Math.min(var4, var3);
            --var0;
            var9[var10001] = var10002 + var10003 * Math.abs(var0);
            var6 = 1;

            while(true) {
               ++var6;
               if (var6 >= 1) {
                  vMeth();
                  var11 = var11;

                  for(var7 = 1; var7 > 1; --var7) {
                     var8 += var6;
                     var9[var4 - 1] = var4;
                     var9[var7] &= 10;
                     var0 = var14;
                  }
                  break;
               }

               var10001 = Integer.reverseBytes(var6) * (var5 + var6);
               ++var5;
               var10 -= (byte)(var10001 % (var5 | 1));
            }
         }
      }

      long var12 = (long)(var0 + Float.floatToIntBits(var1) + var14 + var3 + var4 + var5 + var6 + var10 + (var11 ? 1 : 0) + var7 + var8) + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void mainTest(String[] var1) {
      double var2 = 19.106742;
      int var4 = 13;
      int var5 = -34574;
      int var6 = -36;
      int var7 = -180;
      short var8 = -187;
      boolean var9 = true;
      boolean var10 = false;
      boolean var11 = false;
      byte var12 = 12;

      for(var2 = 10.0; 185.0 > var2; ++var2) {
         float var13 = -73.358F;
         var9 = var13 >= (float)this.sFld == (var9 ^ var9) != (instanceCount > 200L | var9 | var9);
         this.bArrFld[(int)(var2 + 1.0)] = var10;
         var4 = iMeth(var4);
         var13 = (float)instanceCount;
         if (var9) {
            var4 += (int)var13;
         } else {
            var4 = (int)instanceCount;
         }

         var4 += var12;

         for(var5 = 8; var5 < 143; ++var5) {
            var13 -= -42.0F;
            var12 >>= (byte)((int)instanceCount);
            var10 = var9;
            var6 = var6;

            for(var7 = (int)var2; 2 > var7; ++var7) {
               this.bArrFld1[(var6 >>> 1) % 400] = var9;
               var6 += var7 * var7;
               var6 >>= 11;
               switch (77) {
                  case 77:
                     int[] var10000 = this.iArrFld;
                     var10000[var7] &= var4;
                     this.iArrFld[(int)(var2 + 1.0)] = var8;
                     if (var11) {
                        var13 *= (float)var6;
                        var6 += var7 * var5;
                        var13 += (float)var7;
                     }

                     switch (var7 % 1 + 106) {
                        case 106:
                           var6 = var4;
                        default:
                           continue;
                     }
                  case 78:
                     var4 ^= var7;
                     break;
                  case 79:
                     var4 -= (int)var2;
                     break;
                  case 80:
                     var11 = var10;
                  default:
                     try {
                        var6 = var7 % this.iArrFld[var7];
                        var6 = -38772 / var7;
                        var4 = this.iArrFld[var5 + 1] / 2132987612;
                     } catch (ArithmeticException var15) {
                     }
               }
            }
         }
      }

      FuzzerUtils.out.println("d i b = " + Double.doubleToLongBits(var2) + "," + var4 + "," + (var9 ? 1 : 0));
      FuzzerUtils.out.println("b1 by2 i20 = " + (var10 ? 1 : 0) + "," + var12 + "," + var5);
      FuzzerUtils.out.println("i21 i22 i23 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("b4 = " + (var11 ? 1 : 0));
      FuzzerUtils.out.println("Test.instanceCount sFld bArrFld = " + instanceCount + "," + this.sFld + "," + FuzzerUtils.checkSum(this.bArrFld));
      FuzzerUtils.out.println("bArrFld1 iArrFld = " + FuzzerUtils.checkSum(this.bArrFld1) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
