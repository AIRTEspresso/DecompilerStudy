public class Test {
   public static final int N = 400;
   public static long instanceCount = 11L;
   public static int iFld = -47;
   public static short sFld = 2948;
   public static byte byFld = -26;
   public boolean bFld = false;
   public static double dFld = 2.66763;
   public static float fFld = -7.287F;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static short[] sArrFld = new short[400];
   public static byte[] byArrFld = new byte[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(int var0, int var1) {
      boolean var2 = true;
      int var3 = 35954;
      int var4 = -5;
      byte var5 = 8;
      double var6 = -2.73343;
      float var8 = 1.286F;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, 1980381468L);
      instanceCount = instanceCount;
      instanceCount += (long)var1;
      iFld += -6;

      int var12;
      for(var12 = 15; var12 < 262; ++var12) {
         var0 += 14;
         var6 -= (double)sFld;
         var4 = 1;

         while(var4 < 7) {
            instanceCount = (long)var8;
            switch ((var3 >>> 1) % 1 * 5 + 127) {
               case 131:
                  var9[var12] = (long)var0;
                  instanceCount += (long)(var4 | var5);
                  iFld >>>= sFld;
                  instanceCount *= (long)sFld;
               default:
                  var0 >>= byFld;
                  var3 = (int)instanceCount;
                  ++var4;
            }
         }
      }

      long var10 = (long)(var0 + var1 + var12 + var3) + Double.doubleToLongBits(var6) + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var8) + FuzzerUtils.checkSum(var9);
      iMeth1_check_sum += var10;
      return (int)var10;
   }

   public static int iMeth() {
      byte var0 = 117;
      boolean var1 = true;
      int var2 = -36215;
      int var3 = 233;
      float var4 = 95.287F;
      float var5 = 62.931F;
      float[] var6 = new float[400];
      long[] var7 = new long[400];
      FuzzerUtils.init(var6, 0.207F);
      FuzzerUtils.init(var7, -560020216L);
      int var10000 = iFld;
      int var12 = ++iArrFld[(iFld >>> 1) % 400] * Math.max(iFld, iFld);
      int var10002 = iFld - iFld;
      iFld = var0;
      iFld = var10000 - var12 * (var10002 + var0);
      iFld = sFld;
      int var11 = 1;

      do {
         instanceCount *= (long)var11;
         var6[var11] = (float)((var11 + iMeth1(var11, var11)) * 8);

         for(var4 = 1.0F; var4 < 4.0F; ++var4) {
            try {
               iFld = iArrFld[var11 - 1] / iFld;
               var2 = iFld % 178;
               iFld = -11284 % iFld;
            } catch (ArithmeticException var10) {
            }

            var3 = 1;

            while(true) {
               var3 += 2;
               if (var3 >= 2) {
                  break;
               }

               var7[var11 - 1] -= (long)sFld;
               switch (var3 % 7 * 5 + 15) {
                  case 16:
                     sFld += (short)(-12406 + var3 * var3);
                  case 39:
                     instanceCount >>= -1384129393;
                  case 27:
                  default:
                     break;
                  case 30:
                     iArrFld = iArrFld;
                     var2 = (int)((long)var2 + (long)var3 + instanceCount);
                     var2 = -1;
                     iFld -= var11;
                     break;
                  case 41:
                     iArrFld[var11] = (int)var4;
                     break;
                  case 42:
                     iArrFld[var11] = var2;
                     break;
                  case 47:
                     var5 += (float)(var3 * var2 + iFld - var11);
               }
            }
         }

         ++var11;
      } while(var11 < 396);

      long var8 = (long)(var0 + var11 + Float.floatToIntBits(var4) + var2 + var3 + Float.floatToIntBits(var5)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var6)) + FuzzerUtils.checkSum(var7);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public static void vMeth(int var0) {
      int var1;
      int var2;
      int var3;
      int var4;
      int var5;
      int var6;
      short var7;
      int var8;
      int var9;
      double var10;
      float var12;
      float var13;
      boolean var14;
      var1 = 57371;
      var2 = -22209;
      var3 = 22;
      var4 = 8;
      var5 = -32640;
      var6 = -5;
      var7 = -222;
      var8 = 2;
      var9 = 0;
      var10 = -6.49078;
      var12 = -1.147F;
      var13 = -51.353F;
      var14 = true;
      iMeth();
      label66:
      switch ((iFld >>> 1) % 9 + 49) {
         case 49:
            var1 = 5;

            while(true) {
               if (var1 >= 121) {
                  break label66;
               }

               for(var3 = 2; var3 < 40; ++var3) {
                  for(var10 = 1.0; var10 < 2.0; ++var10) {
                     var2 -= (int)var12;
                  }

                  iFld += var3 + iFld;
                  instanceCount >>>= var3;
                  if (var14) {
                     break;
                  }
               }

               var1 += 3;
            }
         case 50:
            var6 = 324;

            while(true) {
               if (12 >= var6) {
                  break label66;
               }

               for(var8 = 1; 15 > var8; ++var8) {
                  var9 += 21167;
                  var13 += (float)(var8 + sFld);
                  var2 = var4;
                  long[] var15 = lArrFld;
                  var15[var6 - 1] *= -205L;
               }

               var6 -= 3;
            }
         case 51:
            var2 -= var0;
            break;
         case 52:
            short[] var10000 = sArrFld;
            var10000[(var4 >>> 1) % 400] -= (short)var1;
            break;
         case 53:
            var4 <<= sFld;
            break;
         case 54:
            var2 -= (int)instanceCount;
         case 55:
            var5 |= (int)instanceCount;
            break;
         case 56:
            var12 = (float)var2;
            break;
         case 57:
            instanceCount *= (long)iFld;
            break;
         default:
            var4 <<= (int)instanceCount;
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var10) + (long)var5 + (long)Float.floatToIntBits(var12) + (long)(var14 ? 1 : 0) + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var13);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = 8;
      int var5 = 25895;
      int var6 = 37204;
      int var7 = -224;
      int var8 = 206;
      vMeth(iFld);
      instanceCount ^= (long)iFld;
      int var9 = 1;

      int[] var10000;
      do {
         var10000 = iArrFld;
         var10000[var9 - 1] -= var9;
         byFld *= (byte)((int)instanceCount);
         byArrFld[var9] = 4;
         var9 += 3;
      } while(var9 < 330);

      int var10;
      for(var10 = 6; var10 < 176; ++var10) {
         var5 = 1;

         do {
            var4 = var5 + var10;
            var4 += var5 | var5;
            iFld += var5;
            var6 *= (int)instanceCount;

            for(var7 = 1; var7 < 2; ++var7) {
               var4 = var5;
               iFld += var7 * var5 + var9 - var7;
               iFld += var8;
               sFld = (short)var5;
               instanceCount >>>= (int)instanceCount;
               this.bFld = false;
               switch (var5 % 10 + 4) {
                  case 4:
                     iFld += var6;
                     if (this.bFld) {
                        iArrFld[var5 - 1] = (int)dFld;
                        iArrFld[var5] = (int)instanceCount;
                     } else if (this.bFld) {
                        sFld >>= (short)var9;
                     } else {
                        var6 >>= var9;
                     }
                  case 5:
                     fFld += (float)iFld;
                     dFld *= (double)var5;
                     break;
                  case 6:
                     var4 = -35063;
                     break;
                  case 7:
                     iArrFld[var7] = -244;
                     break;
                  case 8:
                     lArrFld[var5 + 1] = (long)var5;
                  case 9:
                     if (this.bFld) {
                     }
                     break;
                  case 10:
                     var10000 = iArrFld;
                     var10000[var5 + 1] -= -40985;
                     break;
                  case 11:
                     var8 *= (int)fFld;
                     break;
                  case 12:
                  case 13:
                     iArrFld[var7 + 1] = (int)fFld;
               }
            }

            var5 += 2;
         } while(var5 < 148);
      }

      FuzzerUtils.out.println("i19 i20 i21 = " + var9 + "," + var10 + "," + var4);
      FuzzerUtils.out.println("i22 i23 i24 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i25 = " + var8);
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
      FuzzerUtils.out.println("Test.byFld bFld Test.dFld = " + byFld + "," + (this.bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.fFld Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("Test.sArrFld Test.byArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)154);
      FuzzerUtils.init(lArrFld, -234L);
      FuzzerUtils.init((short[])sArrFld, (short)7255);
      FuzzerUtils.init((byte[])byArrFld, (byte)28);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
