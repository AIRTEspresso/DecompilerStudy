public class Test {
   public static final int N = 400;
   public static long instanceCount = 12L;
   public static float fFld = 2.137F;
   public static volatile short sFld = -5507;
   public static double dFld = 2.98592;
   public static int iFld = 7;
   public boolean bFld = false;
   public static int[] iArrFld = new int[400];
   public volatile double[] dArrFld = new double[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(long var0) {
      int var2 = 35915;
      int var3 = -63271;
      int var4 = -245;
      int var5 = 13;
      boolean var6 = true;
      int var7 = -14;
      byte var8 = 58;
      int var9 = -9265;
      byte var10 = -10;
      boolean var11 = true;
      double var12 = -1.63441;

      for(var2 = 4; var2 < 170; ++var2) {
         fFld += (float)var2;
         var3 = (int)var0;
         var3 = sFld;

         for(var4 = 1; var4 < 10; ++var4) {
            instanceCount -= -6L;
         }

         sFld ^= (short)var4;
      }

      var5 <<= var2;

      int var16;
      for(var16 = 17; var16 < 387; var16 += 3) {
         sFld *= (short)var4;
         var3 -= var8;
         var11 = false;

         for(var9 = 13; var9 > 1; var9 -= 3) {
            var7 = (int)((float)var7 + ((float)var9 - fFld));
            var12 += (double)var7;
         }
      }

      long var14 = var0 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var16 + (long)var7 + (long)var8 + (long)(var11 ? 1 : 0) + (long)var9 + (long)var10 + Double.doubleToLongBits(var12);
      iMeth_check_sum += var14;
      return (int)var14;
   }

   public static void vMeth1(long var0) {
      int var2 = -188;
      int var3 = 61329;
      int var4 = 82;
      int var5 = -52645;
      int var6 = -150;
      int var7 = 34;
      byte var8 = 70;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, 37341L);
      var2 -= iMeth(var0);

      for(var3 = 1; 196 > var3; ++var3) {
         for(var5 = 1; 8 > var5; ++var5) {
            var2 = -187;
         }

         var4 += 13;
         var7 = 1;

         do {
            var2 += var8;
            ++var7;
         } while(var7 < 8);

         var4 >>= (int)instanceCount;
         var6 += var3 * var3;
         var2 += var3;
         if (var5 != 0) {
            vMeth1_check_sum += var0 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
            return;
         }

         iArrFld[var3 + 1] = (int)instanceCount;
      }

      var6 >>>= var8;
      var9[(var3 >>> 1) % 400] = (long)var5;
      vMeth1_check_sum += var0 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
   }

   public void vMeth(int var1, int var2, int var3) {
      int var4 = 70;
      int var5 = -4;
      int var6 = 21012;
      int[] var7 = new int[400];
      boolean var8 = true;
      FuzzerUtils.init(var7, -58173);
      int[] var9 = var7;
      int var10 = var7.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var12 = var9[var11];
         vMeth1(instanceCount);
         var2 = var12;
         var4 = 1;

         do {
            instanceCount -= (long)var3;
            label39:
            switch (var4 % 9 * 5 + 21) {
               case 23:
               case 39:
                  var5 = 1;

                  while(true) {
                     if (1 <= var5) {
                        break label39;
                     }

                     var7 = FuzzerUtils.int1array(400, -93);
                     var12 += var12;
                     instanceCount *= (long)dFld;
                     var12 += (int)instanceCount;
                     instanceCount = (long)var2;
                     var1 -= 14;
                     ++var5;
                  }
               case 25:
                  sFld >>= (short)var3;
                  break;
               case 27:
                  var1 <<= var2;
                  if (var8) {
                  }
                  break;
               case 38:
                  var1 += var12;
                  break;
               case 45:
                  if (var8) {
                     break;
                  }
               case 26:
                  fFld = (float)instanceCount;
               case 52:
               default:
                  break;
               case 66:
                  var6 = var2;
            }

            ++var4;
         } while(var4 < 4);
      }

      vMeth_check_sum += (long)(var1 + var2 + var3 + var4 + (var8 ? 1 : 0) + var5 + var6) + FuzzerUtils.checkSum(var7);
   }

   public void mainTest(String[] var1) {
      int var2 = 13788;
      int var3 = 206;
      int var4 = -2;
      int var5 = -166;
      int var6 = -126;
      int var7 = -2554;
      int var8 = -6;
      int var9 = -19;
      int var10 = 4;
      double var11 = 0.14337;
      this.vMeth(iFld, iFld, iFld);
      if (this.bFld) {
         for(var2 = 11; var2 < 393; ++var2) {
            sFld = (short)var2;
            iFld += iFld;
            instanceCount += -46409L;

            for(var4 = 4; var4 < 66; ++var4) {
               sFld = (short)var2;
               var5 -= var4;
               iFld <<= -52206;
            }
         }

         int[] var10000 = iArrFld;
         var10000[(var3 >>> 1) % 400] += (int)instanceCount;

         for(var11 = 12.0; var11 < 239.0; ++var11) {
            var6 *= var2;
            this.dArrFld[(int)var11] = (double)var5;
            iArrFld[(int)(var11 + 1.0)] = var4;
            if (!this.bFld) {
               iFld >>= var5;
            } else {
               for(var7 = 111; var7 > 5; var7 -= 3) {
                  var8 += var3;

                  for(var9 = 1; var9 < 4; ++var9) {
                     instanceCount -= (long)fFld;
                     if (this.bFld) {
                        switch ((int)(var11 % 2.0 + 43.0)) {
                           case 43:
                              fFld += (float)var2;
                              var5 -= (int)instanceCount;
                              iFld -= var3;
                              break;
                           case 44:
                              var3 = var10;
                              var6 = (int)((long)var6 + ((long)var9 * instanceCount + (long)var10 - (long)var2));
                              var10 += 41313;
                              break;
                           default:
                              iFld = var2;
                        }
                     }
                  }
               }
            }
         }
      } else {
         dFld = 4.258766189E9;
      }

      FuzzerUtils.out.println("i22 i23 i24 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i25 d1 i26 = " + var5 + "," + Double.doubleToLongBits(var11) + "," + var6);
      FuzzerUtils.out.println("i27 i28 i29 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i30 = " + var10);
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + sFld);
      FuzzerUtils.out.println("Test.dFld Test.iFld bFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.iArrFld dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-9);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
