public class Test {
   public static final int N = 400;
   public static long instanceCount = 5L;
   public static int iFld = 55569;
   public double dFld = 106.59753;
   public float fFld = -1.409F;
   public boolean bFld = false;
   public int[] iArrFld = new int[400];
   public static short[] sArrFld = new short[400];
   public static long bMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, long var2) {
      boolean var4 = true;
      float var5 = 8.263F;
      float[] var6 = new float[400];
      boolean var7 = true;
      short var8 = 10972;
      long[] var9 = new long[400];
      double[] var10 = new double[400];
      FuzzerUtils.init(var6, 0.497F);
      FuzzerUtils.init(var9, -2444275299L);
      FuzzerUtils.init(var10, -2.116215);
      int var11 = 1;

      while(true) {
         ++var11;
         if (var11 >= 269) {
            vMeth1_check_sum += (long)(var0 + var1) + var2 + (long)var11 + (long)Float.floatToIntBits(var5) + (long)(var7 ? 1 : 0) + (long)var8 + Double.doubleToLongBits(FuzzerUtils.checkSum(var6)) + FuzzerUtils.checkSum(var9) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
            return;
         }

         switch (var11 % 7 * 5 + 32) {
            case 40:
               var1 += (int)var5;
               instanceCount *= (long)var0;
               var2 += (long)var11 * instanceCount + var2 - (long)var1;
               var0 |= iFld;
               break;
            case 42:
               var1 += var11 * var0 + var0 - var1;
            case 63:
               if (!var7) {
                  var6[var11] *= (float)var8;
               }
               break;
            case 51:
               var9[var11 - 1] -= 97L;
               break;
            case 55:
               var0 += var11 * var11;
               var10[var11 + 1] *= (double)var2;
               var5 = (float)var11;
            case 65:
               var1 = var0;
               break;
            case 60:
               var0 = var11;
         }
      }
   }

   public static void vMeth() {
      boolean var0 = true;
      byte var1 = 8;
      int var2 = -10;
      char var3 = '홅';
      int[] var4 = new int[400];
      float var5 = 0.268F;
      float[][] var6 = new float[400][400];
      double var7 = -108.109856;
      FuzzerUtils.init((int[])var4, (int)9375);
      FuzzerUtils.init(var6, 2.21F);
      iFld = iFld;
      vMeth1(iFld, iFld, instanceCount);
      iFld *= iFld;
      var4[45] *= iFld;
      iFld = iFld;
      iFld = iFld;

      int var9;
      for(var9 = 10; var9 < 207; ++var9) {
         var2 = 1;

         while(true) {
            ++var2;
            if (var2 >= 8) {
               break;
            }

            instanceCount -= (long)var9;

            for(var5 = 1.0F; var5 < 1.0F; ++var5) {
               instanceCount = -5L;
               var4[(int)(var5 + 1.0F)] -= var2;
               var6[(int)var5][(int)var5] += 8.0F;
               instanceCount = (long)var7;
               var4[354] += (int)var5;
            }
         }
      }

      vMeth_check_sum += (long)(var9 + var1 + var2 + Float.floatToIntBits(var5) + var3) + Double.doubleToLongBits(var7) + FuzzerUtils.checkSum(var4) + Double.doubleToLongBits(FuzzerUtils.checkSum(var6));
   }

   public static boolean bMeth(int var0, short var1, int var2) {
      double var3 = -115.88184;
      double[] var5 = new double[400];
      int var6 = 51051;
      int[] var7 = new int[400];
      float var8 = -2.614F;
      boolean var9 = true;
      byte[] var10 = new byte[400];
      FuzzerUtils.init((int[])var7, (int)78);
      FuzzerUtils.init(var5, 83.2875);
      FuzzerUtils.init((byte[])var10, (byte)58);
      var2 -= var7[(var2 >>> 1) % 400];
      vMeth();
      instanceCount += (long)var0;
      var7[69] *= (int)instanceCount;
      iFld *= -294958096;
      var5[(var2 >>> 1) % 400] *= (double)iFld;
      byte[] var11 = var10;
      int var12 = var10.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         byte var10000 = var11[var13];
         var2 -= (int)var3;
         var0 -= var2;
      }

      var0 = var0;
      var6 = 1;

      byte var15;
      do {
         var8 = (float)instanceCount;
         instanceCount = 1L;
         var15 = (byte)var0;
         sArrFld[var6 + 1] = (short)var0;
         ++var6;
      } while(var6 < 350);

      long var16 = (long)(var0 + var1 + var2) + Double.doubleToLongBits(var3) + (long)var6 + (long)Float.floatToIntBits(var8) + (long)var15 + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var5)) + FuzzerUtils.checkSum(var10);
      bMeth_check_sum += var16;
      return var16 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      int var2 = -48;
      int var3 = -161;
      int var4 = 134;
      int var5 = 238;
      long[][] var6 = new long[400][400];
      FuzzerUtils.init(var6, -544060613407401985L);
      int[] var7 = this.iArrFld;
      int var8 = var7.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         int var10 = var7[var9];
         bMeth(var10, (short)21006, iFld);
         this.iArrFld[(var10 >>> 1) % 400] = (int)this.dFld;
         this.iArrFld = this.iArrFld;
         var10 *= (int)instanceCount;

         int[] var10000;
         for(var2 = 3; var2 < 63; ++var2) {
            var4 = 1;

            while(var4 < 2) {
               switch (var2 % 2 * 5 + 103) {
                  case 109:
                     iFld += 7137;
                     var6[var2][var4 + 1] &= (long)var3;
                     switch (var2 % 1 + 1) {
                        case 1:
                           var5 *= iFld;
                           iFld = (int)instanceCount;
                           sArrFld = sArrFld;
                           var10000 = this.iArrFld;
                           var10000[var4 + 1] -= -13;
                           break;
                        default:
                           switch (var2 % 1 + 71) {
                              case 71:
                                 var10 += var4;
                                 var3 = (int)instanceCount;
                           }
                     }

                     var3 >>= var3;
                  default:
                     this.fFld += (float)var4;
                     this.fFld = (float)instanceCount;

                     try {
                        iFld = var5 / var10;
                        iFld = this.iArrFld[var2] / -3633;
                        iFld = -30624 / var5;
                     } catch (ArithmeticException var12) {
                     }

                     iFld = (int)((long)iFld + ((long)var4 * instanceCount + instanceCount - (long)var2));
                  case 105:
                     ++var4;
               }
            }

            iFld += var2 * var5 + iFld - var4;
         }

         var6[(var4 >>> 1) % 400][(iFld >>> 1) % 400] = (long)this.dFld;
         int var13 = var10 * var2;
         var10000 = this.iArrFld;
         var10000[(var5 >>> 1) % 400] <<= var4;
      }

      this.bFld = this.bFld;
      FuzzerUtils.out.println("i12 i13 i14 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i15 lArr1 = " + var5 + "," + FuzzerUtils.checkSum(var6));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("fFld bFld iArrFld = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(sArrFld, (short)-25998);
      bMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
