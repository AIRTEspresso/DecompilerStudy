public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -162L;
   public static volatile int iFld = 27866;
   public static float fFld = 42.615F;
   public static volatile double dFld = -2.7781;
   public static short sFld = 29534;
   public static boolean bFld = false;
   public static long vMeth_check_sum = 0L;
   public static long sMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;

   public static int iMeth(int var0) {
      int var1 = 44222;
      int var2 = -63977;
      int var3 = -14;
      int var4 = 8;
      int var5 = -25;
      boolean var6 = true;
      byte var7 = 0;
      int[] var8 = new int[400];
      short var9 = 14446;
      FuzzerUtils.init(var8, -64739);

      for(var1 = 1; 244 > var1; ++var1) {
         instanceCount += (long)(var1 * var1);

         for(var3 = 1; 7 > var3; ++var3) {
            var2 = (int)((long)var2 + ((long)(var3 * var4) + instanceCount - (long)var9));
            instanceCount = (long)var0;
         }

         var5 = 1;

         do {
            float var10 = -2.763F;
            long var11 = 4L;
            var10 = (float)instanceCount;
            var2 += var5 * var5 + iFld - var5;
            instanceCount += (long)var5 * var11 + var11 - (long)iFld;
            ++var5;
         } while(var5 < 7);

         instanceCount += (long)var0;
         var4 = (int)instanceCount;
         var8[var1 - 1] = (int)fFld;
      }

      int var13;
      for(var13 = 13; var13 < 380; ++var13) {
         instanceCount = (long)((float)instanceCount + (float)var13 + fFld);
         var0 = (int)dFld;
      }

      long var14 = (long)(var0 + var1 + var2 + var3 + var4 + var9 + var5 + var13 + var7) + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var14;
      return (int)var14;
   }

   public static short sMeth(int var0) {
      double var1 = -2.56164;
      char var3 = '祈';
      boolean var4 = true;
      int var5 = 42308;
      byte[][][] var6 = new byte[400][400][400];
      long[] var7 = new long[400];
      FuzzerUtils.init((Object[][])var6, -94);
      FuzzerUtils.init(var7, 11671L);
      var6[(var0 >>> 1) % 400][(var0 >>> 1) % 400][(var0 >>> 1) % 400] -= (byte)((int)((instanceCount = (long)iMeth(iFld)) * (long)iFld));

      for(var1 = 1.0; var1 < 134.0; ++var1) {
         var0 += sFld;
         var0 *= var3;
      }

      instanceCount -= (long)var0;

      int var10;
      for(var10 = 8; var10 < 171; ++var10) {
         iFld -= (int)fFld;
         var5 += var10 | iFld;
         iFld |= (int)instanceCount;
         instanceCount += (long)(var10 * sFld + var10 - iFld);
         iFld += (int)instanceCount;
      }

      switch (78) {
         case 71:
            iFld += var0;
            break;
         case 75:
            var7[(var10 >>> 1) % 400] -= (long)fFld;
            instanceCount <<= 35171436;
            instanceCount *= (long)var3;
            break;
         case 77:
            instanceCount = (long)var5;
      }

      long var8 = (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var10 + (long)var5 + FuzzerUtils.checkSum((Object[][])var6) + FuzzerUtils.checkSum(var7);
      sMeth_check_sum += var8;
      return (short)((int)var8);
   }

   public static void vMeth(int var0, double var1) {
      int var3 = 62329;
      int var4 = -2;
      int var5 = 22414;
      int var6 = 72;
      int[] var7 = new int[400];
      FuzzerUtils.init((int[])var7, (int)58);
      var0 += sMeth(var0);
      var7[(var0 >>> 1) % 400] = iFld;
      var0 = 18151;
      bFld = bFld;
      var3 = 1;

      while(true) {
         ++var3;
         if (var3 >= 215) {
            vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var4 + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7);
            return;
         }

         var4 = 1;

         while(var4 < 7) {
            switch (var4 % 1 * 5 + 116) {
               case 119:
                  fFld = 13.0F;
                  var6 = var5;
                  instanceCount += (long)(var4 - var5);
                  iFld = var4;
               default:
                  var5 = var6;
                  instanceCount += (long)fFld;
                  var6 *= (int)instanceCount;
                  var0 += 198;
                  ++var4;
            }
         }
      }
   }

   public void mainTest(String[] var1) {
      int var2 = 48942;
      int var3 = -9;
      int var4 = 24196;
      int var5 = 0;
      int var6 = -62266;
      int var7 = 30268;
      int var8 = 241;
      int[] var9 = new int[400];
      float var10 = 0.235F;
      float[][][] var11 = new float[400][400][400];
      short var12 = -31888;
      byte var13 = -30;
      byte[] var14 = new byte[400];
      long[] var15 = new long[400];
      double[] var16 = new double[400];
      FuzzerUtils.init(var15, -177L);
      FuzzerUtils.init(var16, -88.6756);
      FuzzerUtils.init((Object[][])var11, -21.24F);
      FuzzerUtils.init((int[])var9, (int)213);
      FuzzerUtils.init(var14, (byte)-93);
      var2 = 1;

      while(true) {
         ++var2;
         if (var2 >= 166) {
            FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var3 + "," + var4);
            FuzzerUtils.out.println("i3 i4 f = " + var5 + "," + var6 + "," + Float.floatToIntBits(var10));
            FuzzerUtils.out.println("s i22 by = " + var12 + "," + var7 + "," + var13);
            FuzzerUtils.out.println("i23 lArr dArr = " + var8 + "," + FuzzerUtils.checkSum(var15) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var16)));
            FuzzerUtils.out.println("fArr iArr2 byArr1 = " + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var11)) + "," + FuzzerUtils.checkSum(var9) + "," + FuzzerUtils.checkSum(var14));
            FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
            FuzzerUtils.out.println("Test.dFld Test.sFld Test.bFld = " + Double.doubleToLongBits(dFld) + "," + sFld + "," + (bFld ? 1 : 0));
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         for(var3 = 3; var3 < 151; ++var3) {
            for(var5 = 1; var5 < 2; ++var5) {
               var6 = (int)((var15[var2 - 1] -= ++instanceCount) + (long)var6);
               var15[var5] |= (long)var6;
               var15[(var5 >>> 1) % 400] ^= Long.reverseBytes((long)((var10 - (float)var5) * (float)(instanceCount - (long)var6)));
               var10 *= 267.0F;
               int var10000 = var6;
               long var10001 = (long)(2.65315 + (double)var3 + -31.31911) << (int)(-62851027L ^ instanceCount + (long)var12);
               --var6;
               var6 = var10000 * (int)(var10001 / ((long)var6 - (instanceCount - -80L) | 1L));
               vMeth(var2, dFld);
               var15 = FuzzerUtils.long1array(400, -1768316691L);
               var6 = (int)var10;
               var6 *= (int)instanceCount;
               iFld = var6;
            }

            switch (var2 % 9 + 116) {
               case 116:
                  iFld += var3;
                  var7 = (int)((long)var7 + ((long)(var3 * var13) + instanceCount - instanceCount));
                  var4 += var3;
                  var16 = var16;
                  break;
               case 117:
                  var6 += -110 + var3 * var3;
                  var10 *= (float)var5;
                  switch (var3 % 2 + 36) {
                     case 36:
                        var8 = 1;

                        do {
                           var4 = (int)dFld;
                           var4 -= var2;
                           var11[var3][var2 - 1][var2 + 1] *= (float)instanceCount;
                           fFld += (float)((long)(var8 * var8) + instanceCount - (long)iFld);
                           var9[var3 + 1] *= (int)instanceCount;
                           ++var8;
                        } while(var8 < 2);

                        if (bFld) {
                           continue;
                        }
                     case 37:
                        if (!bFld) {
                           var15[var2 + 1] -= (long)var5;
                        }
                        break;
                     default:
                        var6 += (int)var10;
                  }
               case 118:
                  var4 += (int)dFld;
                  break;
               case 119:
                  var7 += 12 + var3 * var3;
                  break;
               case 120:
                  var7 = (int)instanceCount;
               case 121:
                  var14[var2 + 1] *= (byte)var5;
                  break;
               case 122:
                  var4 = (int)((long)var4 + ((long)var3 * instanceCount + (long)var7 - (long)var4));
               case 123:
                  try {
                     iFld = var7 % var6;
                     var6 = var9[var2] / 168;
                     iFld = -490270453 / var9[var2 - 1];
                  } catch (ArithmeticException var18) {
                  }
                  break;
               case 124:
                  var11[var2 + 1][var3][var3] = (float)var4;
               default:
                  sFld += (short)(var3 * var5 + var2 - var4);
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
