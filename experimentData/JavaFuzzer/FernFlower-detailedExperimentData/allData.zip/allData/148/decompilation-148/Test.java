public class Test {
   public static final int N = 400;
   public static long instanceCount = -7L;
   public double dFld = -59.36948;
   public static volatile int iFld = 70;
   public static int iFld1 = 1328;
   public static byte byFld = -5;
   public static float fFld = 1.37F;
   public static int iFld2 = -37124;
   public short sFld = -21197;
   public static double[] dArrFld = new double[400];
   public static byte[] byArrFld = new byte[400];
   public static short[] sArrFld = new short[400];
   public static long[][] lArrFld = new long[400][400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1() {
      float var0 = 114.875F;
      boolean var1 = true;
      short var2 = 7813;
      int var3 = 41;
      byte var4 = -11;
      int var5 = 10;
      int var6 = 42848;
      double var7 = 0.81882;
      iFld += iFld;
      var0 = (float)iFld;

      int var11;
      for(var11 = 15; 293 > var11; ++var11) {
         double[] var10000 = dArrFld;
         var10000[var11 + 1] += (double)var11;

         for(var3 = var11; var3 < 6; ++var3) {
            boolean var9 = true;
            byArrFld[var3] = (byte)iFld;

            for(var5 = 1; var5 < 1; ++var5) {
               var10000 = dArrFld;
               var10000[var5 + 1] += (double)var0;
               instanceCount ^= -177L;
               instanceCount += (long)var3;
            }

            short var12 = (short)((int)var7);
            var2 = 13;
            var7 -= (double)var4;
            var6 = -1;
            iFld = (int)instanceCount;
         }
      }

      long var13 = (long)(Float.floatToIntBits(var0) + var11 + var2 + var3 + var4 + var5 + var6) + Double.doubleToLongBits(var7);
      iMeth1_check_sum += var13;
      return (int)var13;
   }

   public static void vMeth(int var0, long var1) {
      int var3 = 23979;
      int var4 = 0;
      int var5 = 1174;
      int var6 = 135;
      int[] var7 = new int[400];
      float var8 = -30.798F;
      boolean var9 = true;
      FuzzerUtils.init((int[])var7, (int)-16508);
      if (var9) {
         var7[(var0 >>> 1) % 400] += (var0 >>= var0) + iMeth1() + -18514;
         var0 <<= iFld;
         instanceCount *= (long)iFld;
      } else if (var9) {
         if (var9) {
            var3 = 1;

            do {
               var7 = var7;

               for(var4 = 1; var4 < 5; ++var4) {
                  instanceCount += -8L;
                  var5 >>= -1574304524;
                  var0 -= (int)var1;
                  var6 = 1;

                  while(true) {
                     ++var6;
                     if (var6 >= 2) {
                        break;
                     }

                     instanceCount -= (long)var6;
                     var8 = -4.0F;
                  }
               }

               ++var3;
            } while(var3 < 331);
         } else if (var9) {
            var9 = var9;
         } else {
            var8 *= (float)var1;
         }
      } else {
         var7[(var6 >>> 1) % 400] += var6;
      }

      vMeth_check_sum += (long)var0 + var1 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var8) + (long)(var9 ? 1 : 0) + FuzzerUtils.checkSum(var7);
   }

   public static int iMeth() {
      double var0 = -101.18504;
      boolean var2 = false;
      int var3 = 651;
      byte var4 = -14;
      int[] var5 = new int[400];
      long var6 = -4L;
      FuzzerUtils.init(var5, -35082);
      vMeth(9323, 205L);
      if (var2) {
         int var10001 = (iFld1 >>> 1) % 400;
         var5[var10001] *= iFld;
         short[] var10000 = sArrFld;
         var10001 = (iFld >>> 1) % 400;
         var10000[var10001] += -25134;
         var0 = (double)instanceCount;
         byFld -= (byte)iFld1;
      } else {
         try {
            var5 = FuzzerUtils.int1array(400, -46273);
            var5[342] = 2625;
            iFld1 = -16070;

            for(var3 = 323; 12 < var3; var3 -= 3) {
               if (iFld1 != 0) {
               }
            }
         } catch (ArrayIndexOutOfBoundsException var10) {
            iFld1 = iFld;
         } catch (NullPointerException var11) {
            var6 >>>= iFld;
         }
      }

      long var8 = Double.doubleToLongBits(var0) + (long)(var2 ? 1 : 0) + (long)var3 + (long)var4 + var6 + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 4;
      int var4 = 51409;
      int var5 = 0;
      int var6 = -50894;
      int var7 = 23808;
      int var8 = 4;
      int var9 = 12709;
      byte var10 = 14;
      int[] var11 = new int[400];
      float var12 = 0.885F;
      FuzzerUtils.init((int[])var11, (int)-35);
      this.dFld -= (double)iMeth() - this.dFld;

      int var15;
      label84:
      for(var15 = 325; var15 > 17; --var15) {
         instanceCount = instanceCount;
         iFld1 &= 228;
         instanceCount += (long)this.dFld;
         var11[var15 + 1] += 2;
         switch (75) {
            case 75:
               fFld = var12;
            case 76:
            case 77:
            case 78:
            case 81:
            case 82:
            case 83:
            case 85:
            case 86:
            case 87:
            case 88:
            case 90:
            case 91:
            case 92:
            case 93:
            case 95:
            case 97:
            case 99:
            case 100:
            case 101:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            default:
               break;
            case 79:
               for(var12 = 2.0F; var12 < 82.0F; ++var12) {
                  var3 += (int)this.dFld;
                  iFld -= var4;
               }

               var4 += var4;
               this.dFld *= (double)iFld2;
               break;
            case 80:
               var4 = (int)this.dFld;
               break;
            case 84:
               this.dFld = -1.5438132247448407E18;
               break;
            case 89:
               var6 <<= var15;
               break;
            case 94:
               iFld1 += var15 | var3;
               break;
            case 96:
               var11[var15 + 1] >>= var10;
               break;
            case 98:
               instanceCount += (long)var15;
               break;
            case 102:
               var5 = 2;

               while(true) {
                  if (var5 >= 82) {
                     continue label84;
                  }

                  var11[var15 - 1] >>= (int)instanceCount;
                  iFld += var5 - var6;
                  long[] var10000 = lArrFld[var5];
                  var10000[var15 - 1] <<= byFld;
                  this.dFld += 5.9053043563246377E18;
                  var11 = var11;
                  fFld -= (float)this.sFld;
                  switch (var5 % 6 + 41) {
                     case 41:
                        label65:
                        switch (var15 % 8 + 107) {
                           case 107:
                              var7 = 1;

                              while(true) {
                                 if (var7 >= 2) {
                                    break label65;
                                 }

                                 var6 = var3;
                                 byFld = (byte)var9;
                                 iFld = this.sFld;

                                 try {
                                    iFld1 = -10253 % var7;
                                    var11[var5] = '엀' / iFld2;
                                    iFld2 = var15 % '钊';
                                 } catch (ArithmeticException var14) {
                                 }

                                 switch ((iFld1 >>> 1) % 1 * 5 + 58) {
                                    case 62:
                                       instanceCount *= (long)var7;
                                       lArrFld[var5][var15] = (long)iFld;
                                       break;
                                    default:
                                       var9 += var7;
                                 }

                                 ++var7;
                              }
                           case 108:
                              instanceCount += (long)var5 ^ instanceCount;
                              break;
                           case 109:
                              instanceCount >>>= 10198;
                              break;
                           case 110:
                              var11[var15 - 1] %= (int)(instanceCount | 1L);
                           case 111:
                              lArrFld[var15 - 1] = lArrFld[var15 - 1];
                              break;
                           case 112:
                              lArrFld[var5 - 1][var5] = -14L;
                           case 113:
                              var8 -= 1401629452;
                              break;
                           case 114:
                              var3 += '꧕' + var5 * var5;
                              break;
                           default:
                              iFld2 += var5 * var5;
                        }
                     case 42:
                        instanceCount ^= (long)iFld2;
                        break;
                     case 43:
                        var11[var15] += var8;
                     case 44:
                        var11[var5] += -2244;
                        break;
                     case 45:
                        iFld2 >>= (int)instanceCount;
                        break;
                     case 46:
                        var6 += var5 * var6 + var4 - iFld;
                  }

                  ++var5;
               }
            case 113:
               byFld += (byte)((int)instanceCount);
         }
      }

      FuzzerUtils.out.println("i13 i14 f2 = " + var15 + "," + var3 + "," + Float.floatToIntBits(var12));
      FuzzerUtils.out.println("i15 i16 i17 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i18 i19 i20 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i21 iArr2 = " + var10 + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + iFld);
      FuzzerUtils.out.println("Test.iFld1 Test.byFld Test.fFld = " + iFld1 + "," + byFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.iFld2 sFld Test.dArrFld = " + iFld2 + "," + this.sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("Test.byArrFld Test.sArrFld Test.lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 15.99761);
      FuzzerUtils.init(byArrFld, (byte)-94);
      FuzzerUtils.init((short[])sArrFld, (short)2505);
      FuzzerUtils.init(lArrFld, -8L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
