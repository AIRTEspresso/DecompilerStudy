public class Test {
   public static final int N = 400;
   public static long instanceCount = -3L;
   public volatile byte byFld = 68;
   public float fFld = -2.386F;
   public static float[] fArrFld = new float[400];
   public volatile short[] sArrFld = new short[400];
   public static long vMeth_check_sum;
   public static long dMeth_check_sum;
   public static long byMeth_check_sum;

   public static byte byMeth(long var0, long var2, int var4) {
      boolean var5 = true;
      boolean var6 = true;
      byte var7 = 97;
      short var8 = -252;
      short var9 = 245;
      float var10 = -78.772F;
      boolean var11 = false;
      double[] var12 = new double[400];
      FuzzerUtils.init(var12, 96.95171);
      int var15 = 235;

      int var16;
      do {
         var12[var15 + 1] = 24951.0;

         for(var16 = 1; 7 > var16; ++var16) {
         }

         --var15;
      } while(var15 > 0);

      long var13 = var0 + var2 + (long)var4 + (long)var15 + (long)var16 + (long)var7 + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var10) + (long)(var11 ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(var12));
      byMeth_check_sum += var13;
      return (byte)((int)var13);
   }

   public static double dMeth(int var0, long var1) {
      boolean var3 = true;
      int var4 = 25163;
      int var5 = 39624;
      char var6 = '\uf3c0';
      int[][][] var7 = new int[400][400][400];
      double var8 = -100.67351;
      double[][] var10 = new double[400][400];
      float var11 = -1.842F;
      FuzzerUtils.init((Object[][])var7, -14);
      FuzzerUtils.init(var10, 35.20581);

      int var14;
      for(var14 = 8; var14 < 189; ++var14) {
         if (var0 != 0) {
         }
      }

      for(var8 = 156.0; var8 > 5.0; var8 -= 2.0) {
         int[] var10001 = var7[(int)(var8 + 1.0)][(int)var8];
         int var10002 = (int)(var8 - 1.0);
         int var10004 = var10001[(int)(var8 - 1.0)];
         var10001[var10002] = var10001[(int)(var8 - 1.0)] + 1;
         var5 -= (int)((double)(-var10004) * var10[(int)var8][(int)(var8 + 1.0)]);
         byMeth(instanceCount, var1, var5);
         var1 = -2L;
         float var10000 = var11 + (float)var1;
         float[] var15 = fArrFld;
         var15[(int)(var8 - 1.0)] -= 3.54143616E9F;
         var4 = var0;
         var5 -= 115;
         var11 = 50.0F;
      }

      var7[41][(var14 >>> 1) % 400][(var6 >>> 1) % 400] -= -32168;
      long var12 = (long)var0 + var1 + (long)var14 + (long)var4 + Double.doubleToLongBits(var8) + (long)var5 + (long)Float.floatToIntBits(var11) + (long)var6 + FuzzerUtils.checkSum((Object[][])var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
      dMeth_check_sum += var12;
      return (double)var12;
   }

   public static void vMeth(float var0, short var1, byte var2) {
      int var3 = 15;
      int var4 = 49946;
      int var5 = 13;
      short var6 = -241;
      int[] var7 = new int[400];
      float[] var8 = new float[400];
      long[] var9 = new long[400];
      FuzzerUtils.init((int[])var7, (int)-11981);
      FuzzerUtils.init(var8, 94.829F);
      FuzzerUtils.init(var9, -2086867153L);
      int[] var10 = var7;
      int var11 = var7.length;

      for(int var12 = 0; var12 < var11; ++var12) {
         int var13 = var10[var12];
         int var10001 = (var13 >>> 1) % 400;
         float var10002 = var8[(var13 >>> 1) % 400];
         --var1;
         var8[var10001] = var10002 * (float)var1;
         switch ((Integer.reverseBytes(var13) >>> 1) % 4 * 5 + 120) {
            case 127:
               var4 <<= var5;
            case 139:
               instanceCount = (long)var6;
               break;
            case 135:
               int var10000 = var13 | var7[57];
               break;
            case 138:
               dMeth(var13, instanceCount);
               var8[(var13 >>> 1) % 400] *= -47907.0F;

               for(var3 = 1; var3 < 4; ++var3) {
                  var4 = 125;
                  instanceCount += (long)var3;
                  var5 = 1;

                  do {
                     var0 = (float)var4;
                     var4 = var3;

                     try {
                        var13 = var7[var5 - 1] / var4;
                        var13 = -10449 % var5;
                        var7[var3] = var6 / var6;
                     } catch (ArithmeticException var15) {
                     }

                     var13 *= var3;
                     var13 += var3;
                     ++var5;
                  } while(var5 < 2);
               }
         }
      }

      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1 + var2 + var3 + var4 + var5 + var6) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8)) + FuzzerUtils.checkSum(var9);
   }

   public void mainTest(String[] var1) {
      int var2 = -23636;
      boolean var3 = true;
      int var4 = -4;
      boolean var5 = true;
      int var6 = 33819;
      int var7 = -23645;
      int var8 = -175;
      int var9 = 2688;
      byte var10 = 10;
      int var11 = 7;
      byte var12 = -2;
      int[][][] var13 = new int[400][400][400];
      float var14 = 0.215F;
      short var15 = -21836;
      boolean var16 = true;
      long[] var17 = new long[400];
      FuzzerUtils.init((Object[][])var13, -13);
      FuzzerUtils.init(var17, -8L);
      int var10000 = var2++;
      long var10001 = (long)var2;
      long var10002 = (long)var2 + instanceCount;
      ++var2;
      var2 = var10000 - (int)(var10001 + (var10002 - (long)var2));
      vMeth(var14, var15, (byte)83);
      var13[(var2 >>> 1) % 400][(var2 >>> 1) % 400][(var2 >>> 1) % 400] = var15;
      var2 -= var2;
      int var20 = 1;

      do {
         var2 = 51656;
         var4 &= (int)instanceCount;
         var20 += 3;
      } while(var20 < 132);

      int var21;
      for(var21 = 22; var21 < 389; ++var21) {
         if (!var16 && !var16) {
            for(var7 = 69; var7 > 1; --var7) {
               try {
                  var6 = var13[var21 + 1][var7][var21] / 229;
                  var8 = var4 % var20;
                  var13[var21][var7 + 1][var21] = 232 / var2;
               } catch (ArithmeticException var19) {
               }
            }

            var13[var21 - 1][var21][var21] = var20;
            var13[var21 + 1][var21][var21 - 1] = var6;
            var8 *= var20;
            var6 -= var4;
            switch (var21 % 8 * 5 + 60) {
               case 85:
                  var6 = 109;
                  var4 &= (int)instanceCount;
                  var14 += (float)var2;
               case 66:
                  var2 = (int)instanceCount;
                  var13[var21 + 1][var21 - 1][var21 - 1] <<= -6;
                  break;
               case 86:
                  for(var11 = 1; var11 < 69; ++var11) {
                     var4 = var20;
                  }

                  this.sArrFld[var21 + 1] = (short)((int)this.fFld);
                  instanceCount *= (long)var2;
                  break;
               case 93:
               case 97:
                  instanceCount -= instanceCount;
                  break;
               case 94:
                  var4 += var21 * var21;
                  break;
               case 95:
                  for(var9 = 2; 69 > var9; ++var9) {
                     this.byFld -= (byte)var10;
                     var4 += var9 * var10 + var6 - var20;
                  }

                  var10 = -19;
                  break;
               case 96:
                  var13[var21 - 1][var21 - 1][var21 + 1] = var11;
                  break;
               default:
                  var17 = var17;
            }
         }
      }

      FuzzerUtils.out.println("i f3 s1 = " + var2 + "," + Float.floatToIntBits(var14) + "," + var15);
      FuzzerUtils.out.println("i17 i18 i19 = " + var20 + "," + var4 + "," + var21);
      FuzzerUtils.out.println("i20 b1 i21 = " + var6 + "," + (var16 ? 1 : 0) + "," + var7);
      FuzzerUtils.out.println("i22 i23 i24 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i25 i26 iArr2 = " + var11 + "," + var12 + "," + FuzzerUtils.checkSum((Object[][])var13));
      FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(var17));
      FuzzerUtils.out.println("Test.instanceCount byFld fFld = " + instanceCount + "," + this.byFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.fArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.sArrFld));
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 55.666F);
      vMeth_check_sum = 0L;
      dMeth_check_sum = 0L;
      byMeth_check_sum = 0L;
   }
}
