public class Test {
   public static final int N = 400;
   public static long instanceCount = -9019415368366877483L;
   public static volatile boolean bFld = false;
   public static short sFld = 10356;
   public static volatile float fFld = 62.337F;
   public volatile int iFld = 13;
   public static int[] iArrFld = new int[400];
   public static long vSmallMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth() {
      int var0 = -141;
      int var1 = 0;
      int var2 = -16415;
      boolean var3 = true;
      int var4 = -40727;
      double var5 = -77.115893;
      float var7 = -38.11F;
      long[] var8 = new long[400];
      FuzzerUtils.init(var8, 0L);
      int[] var9 = iArrFld;
      int var10 = var9.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var12 = var9[var11];
         var12 *= -1;
         var0 -= (int)instanceCount;

         for(var1 = 1; 4 > var1; ++var1) {
            var8[var1 - 1] -= (long)var2;
            var2 -= (int)var5;
            iArrFld[var1 + 1] = 10;
            var0 >>= var2;
            var7 += (float)var1;

            try {
               var2 = var1 / var12;
               var0 = iArrFld[var1] % var1;
               var0 %= 37622;
            } catch (ArithmeticException var14) {
            }
         }

         var2 = var12;
         int[] var10000 = iArrFld;
         var10000[(var12 >>> 1) % 400] -= -5;
      }

      int var15;
      for(var15 = 21; var15 < 351; ++var15) {
         var0 >>= -64364;
         var4 -= var1;
      }

      long var16 = (long)(var0 + var1 + var2) + Double.doubleToLongBits(var5) + (long)Float.floatToIntBits(var7) + (long)var15 + (long)var4 + FuzzerUtils.checkSum(var8);
      iMeth_check_sum += var16;
      return (int)var16;
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = -4;
      int var2 = -197;
      boolean var3 = true;
      short var4 = -10711;
      int[][][] var5 = new int[400][400][400];
      int[][] var6 = new int[400][400];
      float var7 = 61.757F;
      double var8 = 42.8349;
      double var10 = 53.84925;
      FuzzerUtils.init((Object[][])var5, 9);
      FuzzerUtils.init((int[][])var6, (int)5);

      int var12;
      for(var12 = 294; var12 > 10; --var12) {
         instanceCount = (long)Math.abs(--var5[var12][var12 - 1][var12 + 1]);
         instanceCount = (long)((double)var12 * (2.0 - -((double)var7 - var8)));
         var6 = FuzzerUtils.int2array(400, -54362);
         var1 = iMeth();
         var7 *= var7;
      }

      for(var10 = 6.0; 334.0 > var10; ++var10) {
         var2 *= 5;
         var7 -= (float)var8;
      }

      var6[(var2 >>> 1) % 400][(var12 >>> 1) % 400] = var1;
      var1 = (int)instanceCount;

      int var13;
      for(var13 = 13; var13 < 269; ++var13) {
         var7 = (float)var2;
      }

      var7 %= 83.0F;
      vMeth_check_sum += (long)(var12 + var1 + Float.floatToIntBits(var7)) + Double.doubleToLongBits(var8) + Double.doubleToLongBits(var10) + (long)var2 + (long)var13 + (long)var4 + FuzzerUtils.checkSum((Object[][])var5) + FuzzerUtils.checkSum(var6);
   }

   public static void vSmallMeth(int var0) {
      vMeth();
      vSmallMeth_check_sum += (long)var0;
   }

   public void mainTest(String[] var1) {
      int var2 = -6997;
      boolean var3 = true;
      int var4 = 10;
      int var5 = 61748;
      int var6 = 53900;
      int var7 = 199;
      int var8 = -209;
      int var9 = 20174;
      int var10 = -32;
      boolean var11 = true;
      int var12 = 44839;
      int var13 = 10857;
      byte var14 = 1;
      int var15 = 0;
      int var16 = -49854;
      double var17 = -1.5458;
      double[][] var19 = new double[400][400];
      byte[] var20 = new byte[400];
      FuzzerUtils.init(var19, -5.52689);
      FuzzerUtils.init(var20, (byte)-42);

      for(int var21 = 0; var21 < 173; ++var21) {
         vSmallMeth(var2);
      }

      var19[(var2 >>> 1) % 400][359] *= (double)var2;

      int[] var10000;
      int var23;
      for(var23 = 9; var23 < 147; ++var23) {
         for(var5 = 1; 182 > var5; ++var5) {
            instanceCount -= -17L;

            for(var7 = 1; var7 < 2; ++var7) {
               var8 -= 11199;
               var2 = var6;
               bFld = false;

               try {
                  var4 = 176 % var4;
                  var9 = -105 % var23;
                  var4 = var23 / -72;
               } catch (ArithmeticException var22) {
               }

               var10000 = iArrFld;
               var10000[var23 + 1] += var6;
               var6 += var7 - sFld;
               var9 = var4;
            }

            if (bFld) {
               break;
            }

            var17 = (double)var23;
            var6 = (int)fFld;
            var10 = 1;

            do {
               var10000 = iArrFld;
               var10000[var23 + 1] -= var4;
               var20[var23 + 1] += (byte)var2;
               ++var10;
            } while(var10 < 2);

            var6 += var5;
         }

         fFld += (float)var5;
         bFld = bFld;
      }

      var10000 = iArrFld;
      int var10001 = (this.iFld >>> 1) % 400;
      var10000[var10001] *= var7;

      int var24;
      for(var24 = 145; 2 < var24; --var24) {
         for(var13 = var24; 175 > var13; ++var13) {
            for(var15 = 1; var15 < 1; ++var15) {
               var9 = 42417;
               if (bFld) {
                  break;
               }

               var2 += var4;
               var12 *= (int)instanceCount;
            }
         }
      }

      FuzzerUtils.out.println("i12 i13 i14 = " + var2 + "," + var23 + "," + var4);
      FuzzerUtils.out.println("i15 i16 i17 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i18 i19 d3 = " + var8 + "," + var9 + "," + Double.doubleToLongBits(var17));
      FuzzerUtils.out.println("i20 i21 i22 = " + var10 + "," + var24 + "," + var12);
      FuzzerUtils.out.println("i23 i24 i25 = " + var13 + "," + var14 + "," + var15);
      FuzzerUtils.out.println("i26 dArr byArr = " + var16 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var19)) + "," + FuzzerUtils.checkSum(var20));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.sFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + sFld);
      FuzzerUtils.out.println("Test.fFld iFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-131);
      vSmallMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
