public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 2L;
   public static volatile long lFld = 50L;
   public static boolean bFld = false;
   public float fFld = -1.773F;
   public static long fMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;
   public static long dMeth_check_sum = 0L;

   public static double dMeth(int var0, int var1, boolean var2) {
      float var3 = 1.949F;
      double var4 = -1.112982;
      boolean var6 = true;
      byte var7 = 2;
      int var8 = 5895;
      byte var9 = 37;
      int var10 = 53;
      int[] var11 = new int[400];
      short var12 = 28882;
      FuzzerUtils.init((int[])var11, (int)117);
      var3 -= (float)var4;

      int var15;
      for(var15 = 122; var15 > 5; --var15) {
         var12 += (short)var15;
         instanceCount = (long)var15;
         var1 <<= var1;
         var0 -= 107;
         instanceCount *= lFld;
         instanceCount = 64338L;
         var4 = 16717.0;

         for(var8 = 1; 13 > var8; ++var8) {
            var2 = var2;
            var10 = 1;

            do {
               var1 -= (int)lFld;
               var11 = var11;
               instanceCount = instanceCount;
               ++var10;
            } while(var10 < 2);
         }
      }

      long var13 = (long)(var0 + var1 + (var2 ? 1 : 0) + Float.floatToIntBits(var3)) + Double.doubleToLongBits(var4) + (long)var15 + (long)var7 + (long)var12 + (long)var8 + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var11);
      dMeth_check_sum += var13;
      return (double)var13;
   }

   public static int iMeth(short var0, int var1) {
      boolean var2 = true;
      int var3 = -168;
      int var4 = 37;
      int[] var5 = new int[400];
      float var6 = -1.838F;
      FuzzerUtils.init((int[])var5, (int)-10);
      instanceCount = (long)Math.max(var1--, (int)(dMeth(var1, var1, var2) + (double)var1));
      int[] var7 = var5;
      int var8 = var5.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         int var10 = var7[var9];
         var10 <<= var1;

         for(var3 = 1; var3 < 4; ++var3) {
            var6 *= (float)var3;
            var10 += var3 - var1;
            lFld += (long)(var3 * var3);
         }

         var10 *= var1;
         if (var2) {
            var0 |= -18918;
            lFld -= (long)var10;
         }

         byte var12 = -126;
         if (var1 != 0) {
         }

         var5[(var12 >>> 1) % 400] -= var3;
         var4 <<= var3;
      }

      long var11 = (long)(var0 + var1 + (var2 ? 1 : 0) + var3 + var4 + Float.floatToIntBits(var6)) + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static float fMeth() {
      short var0 = -23274;
      int var1 = -8;
      int var2 = -11;
      byte var3 = 11;
      int var4 = 10;
      byte var5 = -9;
      double var6 = 0.94587;
      float var8 = 2.221F;
      float[] var9 = new float[400];
      boolean[] var10 = new boolean[400];
      FuzzerUtils.init(var9, -2.662F);
      FuzzerUtils.init(var10, true);
      iMeth(var0, var1);
      float[] var11 = var9;
      int var12 = var9.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         float var10000 = var11[var13];

         for(var2 = 1; var2 < 4; ++var2) {
            var1 += 41;
         }

         if (!bFld) {
            for(var4 = 1; var4 < 4; ++var4) {
               var1 &= var1;
               var1 += var0;
               instanceCount += (long)var4 * instanceCount + (long)var5 - (long)var1;
               var10[var4] = bFld;
               var1 -= 123;
            }

            var1 <<= var2;
            var6 += (double)var1;
         }
      }

      var8 -= -7.0F;
      var8 = (float)var3;
      long var15 = (long)(var0 + var1 + var2 + var3 + var4 + var5) + Double.doubleToLongBits(var6) + (long)Float.floatToIntBits(var8) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)) + FuzzerUtils.checkSum(var10);
      fMeth_check_sum += var15;
      return (float)var15;
   }

   public void mainTest(String[] var1) {
      int var2 = -62;
      int var3 = 37535;
      int var4 = -34787;
      int var5 = -58939;
      int var6 = -186;
      int var7 = 39027;
      int[] var8 = new int[400];
      byte var9 = 15;
      short var10 = 8185;
      double var11 = 124.88787;
      FuzzerUtils.init((int[])var8, (int)-168);
      var2 = var2++;

      for(var3 = 1; 260 > var3; ++var3) {
         var4 += -85 + var3 * var3;
         var5 = 1;

         do {
            var4 |= Math.abs(var4 * var9);

            for(var6 = 1; var6 < 1; ++var6) {
               var7 = (int)((double)(var7--) - ((double)Short.reverseBytes(var10) + var11));
               var10 += (short)((int)(fMeth() + (float)var7 + (float)var5));
               var2 = var3;
               var7 = (int)((float)var7 + ((float)(var6 * var5 + var3) - this.fFld));
               var8[var5 - 1] += var4;
               var7 += 8;
               switch (var3 % 5 + 63) {
                  case 63:
                     var11 = (double)instanceCount;
                     switch (var6 % 1 * 5 + 112) {
                        case 117:
                           var2 = var3 + var6 + var5;
                           var2 -= var6;
                           break;
                        default:
                           var8[var6 + 1] *= var3;
                     }

                     var4 = (int)((float)var4 + ((float)var6 * this.fFld + (float)var7 - (float)var3));
                  case 64:
                  case 65:
                  case 66:
                     var11 = (double)var6;
                     break;
                  case 67:
                     byte var13 = 1;
                     var4 = var13 << -241;
                     this.fFld += (float)var6;
                     lFld *= lFld;
               }
            }

            var9 = 31;
            var10 = (short)(var10 - 243);
            var7 *= (int)instanceCount;
            ++var5;
         } while(var5 < 97);

         var7 <<= var7;
         var4 = var7;
         var2 += var3;
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 by i4 = " + var5 + "," + var9 + "," + var6);
      FuzzerUtils.out.println("i5 s d = " + var7 + "," + var10 + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(var8));
      FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.bFld = " + instanceCount + "," + lFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("fFld = " + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
