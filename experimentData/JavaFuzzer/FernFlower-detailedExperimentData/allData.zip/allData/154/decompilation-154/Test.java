public class Test {
   public static final int N = 400;
   public static long instanceCount = 5588716753445120000L;
   public short sFld = -23480;
   public short sFld1 = -16171;
   public static long iMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long iMeth1_check_sum = 0L;

   public static int iMeth1(int var0) {
      boolean var1 = true;
      short var2 = 20702;
      int var3 = -10;
      int var4 = -8;
      int[][] var5 = new int[400][400];
      FuzzerUtils.init((int[][])var5, (int)-48);

      int var9;
      for(var9 = 235; var9 > 9; --var9) {
         try {
            var3 = 14 / var0;
            var0 = var5[var9 + 1][var9] % var9;
            var4 = var3 / 653800839;
         } catch (ArithmeticException var8) {
         }
      }

      long var6 = (long)(var0 + var9 + var2 + var3 + var4) + FuzzerUtils.checkSum(var5);
      iMeth1_check_sum += var6;
      return (int)var6;
   }

   public static void vMeth(int var0, double var1, boolean var3) {
      boolean var4 = true;
      int var5 = -46256;
      int var6 = 42621;
      int var7 = -3;
      byte var8 = -3;
      int[] var9 = new int[400];
      float var10 = -67.183F;
      FuzzerUtils.init((int[])var9, (int)-1);
      var0 = (int)((double)(-iMeth1(var0)) * var1);

      int var11;
      label45:
      for(var11 = 2; 347 > var11; ++var11) {
         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 5) {
               switch (var11 % 1 * 5 + 58) {
                  case 61:
                     instanceCount -= -191L;
                     if (var3) {
                        continue label45;
                     }
                  default:
                     var0 >>= var11;
                     if (var3) {
                        for(var7 = 1; var7 < 5; ++var7) {
                           var9[(var6 >>> 1) % 400] ^= (int)instanceCount;
                           var10 += (float)var5;
                           var5 *= -32;
                        }
                     } else if (!var3) {
                        var9 = var9;
                     }
                     continue label45;
               }
            }

            instanceCount = (long)var6;
            var0 = var6 + 13 + var6 * var6;
         }
      }

      vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)(var3 ? 1 : 0) + (long)var11 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var9);
   }

   public static int iMeth(double var0) {
      boolean var2 = true;
      int var3 = 7;
      int var4 = -38228;
      int[] var5 = new int[400];
      boolean var6 = false;
      float var7 = 85.897F;
      FuzzerUtils.init((int[])var5, (int)101);

      int var10;
      for(var10 = 7; var10 < 379; ++var10) {
         var5[var10] = var10;
         vMeth(38805, var0, var6);
         var6 = var6;
         var7 = -8.7536821E18F;
         if (!var6) {
            instanceCount -= (long)var3;
            var3 += var10;
            var3 += var10 ^ var3;
            var4 /= var10 | 1;
         }
      }

      long var8 = Double.doubleToLongBits(var0) + (long)var10 + (long)var3 + (long)(var6 ? 1 : 0) + (long)Float.floatToIntBits(var7) + (long)var4 + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      double var3 = 0.89714;
      double var5 = 0.22961;
      boolean var7 = true;
      int var8 = -55832;
      int var9 = 4;
      byte var10 = 10;
      boolean var11 = true;
      byte var12 = -29;
      int var13 = -231;
      int var14 = 99;
      int var15 = 32;
      int var16 = -480;
      int[] var17 = new int[400];
      byte var18 = -69;
      float var19 = -1.445F;
      float[][][] var20 = new float[400][400][400];
      long var21 = 23773L;
      FuzzerUtils.init((int[])var17, (int)7439);
      FuzzerUtils.init((Object[][])var20, 108.203F);
      var2 = iMeth(var3) > this.sFld;
      int var25 = var18;

      for(var8 = 4; var8 < 396; ++var8) {
         this.sFld1 += (short)(var8 + var9);
         var9 -= (int)instanceCount;
         if (var2) {
            break;
         }
      }

      instanceCount *= -10L;
      var19 = (float)var9;

      for(var21 = 1L; var21 < 272L; ++var21) {
         var9 *= 36541;
      }

      int var26;
      for(var26 = 1; var26 < 163; ++var26) {
         for(var13 = 4; var13 < 155; ++var13) {
            this.sFld += (short)((int)((long)(var13 * var9) + instanceCount - (long)var25));
            var3 = (double)var14;

            for(var5 = 1.0; var5 < 2.0; var5 += 2.0) {
               var15 <<= (int)instanceCount;
               var14 += var26;

               try {
                  var17[var26] = var14 / var17[var13];
                  var14 = -35716 % var17[var26 + 1];
                  var25 = 243 / var12;
               } catch (ArithmeticException var24) {
               }
            }

            var14 = 92;
            var16 = 1;

            do {
               if (var2) {
                  var25 = (int)var19;
               }

               var25 = var25;
               var15 += (int)var3;
               instanceCount -= (long)var10;
               var17[var16 + 1] += var14;
               var20[var26][var16 + 1][var26] += (float)var14;
               var17[var26] <<= var9;
               ++var16;
            } while(var16 < 2);
         }
      }

      FuzzerUtils.out.println("b d2 i14 = " + (var2 ? 1 : 0) + "," + Double.doubleToLongBits(var3) + "," + var25);
      FuzzerUtils.out.println("by i15 i16 = " + var18 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("f2 l i17 = " + Float.floatToIntBits(var19) + "," + var21 + "," + var10);
      FuzzerUtils.out.println("i18 i19 i20 = " + var26 + "," + var12 + "," + var13);
      FuzzerUtils.out.println("i21 d3 i22 = " + var14 + "," + Double.doubleToLongBits(var5) + "," + var15);
      FuzzerUtils.out.println("i23 iArr3 fArr = " + var16 + "," + FuzzerUtils.checkSum(var17) + "," + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var20)));
      FuzzerUtils.out.println("Test.instanceCount sFld sFld1 = " + instanceCount + "," + this.sFld + "," + this.sFld1);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
