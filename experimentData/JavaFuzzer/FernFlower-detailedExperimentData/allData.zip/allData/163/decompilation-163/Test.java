public class Test {
   public static final int N = 400;
   public static long instanceCount = -13920L;
   public static byte byFld = 95;
   public float fFld = -38.168F;
   public short sFld = -27092;
   public static int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, int var1) {
      float var2 = -2.89F;
      float[][][] var3 = new float[400][400][400];
      boolean var4 = true;
      int var5 = -23109;
      int var6 = -12;
      int var7 = -8333;
      double var8 = -104.27888;
      short var10 = 30785;
      FuzzerUtils.init((Object[][])var3, 0.71F);
      var0 = var1;
      var2 = (float)var1;
      int var11 = 1;

      while(true) {
         ++var11;
         if (var11 >= 237) {
            vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + var11 + var5 + var6 + var7) + Double.doubleToLongBits(var8) + (long)var10 + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var3));
            return;
         }

         var2 -= (float)var1;

         for(var5 = 1; var5 < 7; ++var5) {
            var7 = 1;

            while(true) {
               ++var7;
               if (var7 >= 2) {
                  break;
               }

               var6 = 799373918;
               instanceCount = (long)var8;
               iArrFld = FuzzerUtils.int1array(400, 193);
               iArrFld = iArrFld;
               var3[var5][var7][var5 - 1] = (float)var5;
               switch (var7 % 1 * 5 + 67) {
                  case 68:
                  default:
                     var6 = var7;
                     var0 = (int)((long)var0 + ((long)var7 * instanceCount + (long)var0 - (long)var10));
                     instanceCount = 12L;
               }
            }
         }
      }
   }

   public static int iMeth1() {
      int var0 = -6;
      boolean var1 = true;
      int var2 = -25023;
      int var3 = 10;
      int var4 = 253;
      short var5 = -16776;
      long[] var6 = new long[400];
      FuzzerUtils.init(var6, 6655L);
      vMeth(var0, var0);
      int var9 = 1;

      while(true) {
         ++var9;
         if (var9 >= 163) {
            long var10 = (long)(var0 + var9 + var2 + var3 + var4 + var5) + FuzzerUtils.checkSum(var6);
            iMeth1_check_sum += var10;
            return (int)var10;
         }

         var6[var9 - 1] *= instanceCount;

         for(var2 = 1; 10 > var2; ++var2) {
            instanceCount += 32473L + (long)(var2 * var2);
            var3 *= byFld;
            var0 *= var2;
            instanceCount <<= var2;
            var4 = 1;

            do {
               double var7 = -124.48152;
               instanceCount += (long)(107.914F + (float)(var4 * var4));
               var3 *= 110;
               var6[var9 + 1] -= (long)var7;
               var3 = 52967;
               var0 *= var9;
               ++var4;
            } while(var4 < 2);
         }

         int[] var10000 = iArrFld;
         var10000[var9] += var5;
      }
   }

   public static int iMeth(int var0, float var1, long var2) {
      int var4 = 39242;
      byte var5 = -7;
      int var6 = 11946;
      int var7 = -58508;
      int var8 = 11590;
      short var9 = 134;
      int var10 = -24646;
      byte var11 = -109;
      double var12 = 0.117562;
      double[] var14 = new double[400];
      float[] var15 = new float[400];
      FuzzerUtils.init(var14, -50.79292);
      FuzzerUtils.init(var15, 2.813F);

      for(var4 = 19; var4 < 367; ++var4) {
         iArrFld[var4] = (int)var2;
         var14[var4] = var12;
         iMeth1();

         for(var6 = 1; var6 < 5; ++var6) {
            for(var8 = 1; var8 < 2; ++var8) {
               var15[var6] -= var1;
               instanceCount -= (long)var7;
               var7 += var9;
            }

            var0 += (int)var12;
            var0 *= -26;

            for(var10 = 1; var10 < 2; ++var10) {
               var7 <<= var8;
            }

            var0 = var4;
            var1 -= -68.0F;
         }
      }

      long var16 = (long)(var0 + Float.floatToIntBits(var1)) + var2 + (long)var4 + (long)var5 + Double.doubleToLongBits(var12) + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + (long)var11 + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var15));
      iMeth_check_sum += var16;
      return (int)var16;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 30594;
      int var4 = -12754;
      int var5 = 153;
      int var6 = -10;
      int var7 = -26818;
      int var8 = 4;
      byte var9 = -11;
      long var10 = 7976563264421262774L;
      long[] var12 = new long[400];
      double var13 = 126.120803;
      boolean var15 = false;
      byte[] var16 = new byte[400];
      FuzzerUtils.init(var12, -223L);
      FuzzerUtils.init((byte[])var16, (byte)20);

      int var17;
      for(var17 = 311; var17 > 2; --var17) {
         var3 = (int)(-((long)var3 * 1826508092L) * --var12[var17 - 1]);

         for(var4 = var17; var4 < 81; ++var4) {
            var3 >>= (int)Math.min((long)(-iMeth(var4, this.fFld, instanceCount) + var3), instanceCount);
            var5 = (int)instanceCount;
            instanceCount = instanceCount;
            var5 += var4;
         }

         for(var10 = 2L; var10 < 81L; ++var10) {
            for(var7 = 2; var7 > 1; var7 -= 2) {
               var6 += var7;
            }

            var6 >>= var8;
            var12[(int)var10] = 13L;
            this.fFld = (float)var4;

            for(var13 = 1.0; var13 < 2.0; ++var13) {
               this.sFld *= -28111;
               instanceCount = -6872L;
               var8 += (int)var13;
               instanceCount = (long)((double)instanceCount + 221.0 + var13 * var13);
               this.sFld = (short)(this.sFld * -11);
               var16[(int)var10] = (byte)var6;
               fArrFld[(int)var10] = (float)var4;
               var3 += (int)var13;
            }

            var16[(int)(var10 - 1L)] <<= (byte)var3;
            iArrFld[(int)var10] = (int)var10;
            switch ((int)(var10 % 10L * 5L + 90L)) {
               case 102:
                  instanceCount += (long)this.fFld;
               case 103:
               case 105:
               case 106:
               case 107:
               case 108:
               case 109:
               case 110:
               case 111:
               case 113:
               case 115:
               case 116:
               case 117:
               case 118:
               case 119:
               case 120:
               case 121:
               case 122:
               case 124:
               case 125:
               case 128:
               case 129:
               case 130:
               case 132:
               case 134:
               default:
                  break;
               case 104:
                  int[] var10000 = iArrFld;
                  var10000[var17] *= (int)var10;
               case 131:
                  if (var15) {
                     break;
                  }
               case 123:
                  var5 = var17;
                  break;
               case 112:
                  var3 = (int)var13;
                  var8 *= var4;
                  this.sFld -= (short)var3;
                  instanceCount *= instanceCount;
               case 127:
                  instanceCount -= var10;
                  break;
               case 114:
                  var3 |= var8;
                  break;
               case 126:
                  this.fFld /= (float)(var9 | 1);
                  break;
               case 133:
                  this.fFld += (float)(var10 * (long)var4);
                  break;
               case 135:
                  var3 -= var7;
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var17 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 l1 i24 = " + var5 + "," + var10 + "," + var6);
      FuzzerUtils.out.println("i25 i26 d3 = " + var7 + "," + var8 + "," + Double.doubleToLongBits(var13));
      FuzzerUtils.out.println("i27 b lArr = " + var9 + "," + (var15 ? 1 : 0) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("byArr = " + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld fFld = " + instanceCount + "," + byFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("sFld Test.iArrFld Test.fArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-250);
      FuzzerUtils.init(fArrFld, -99.458F);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
