public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 970087989L;
   public static float fFld = 23.629F;
   public static byte byFld = -4;
   public static boolean bFld = true;
   public static long[] lArrFld = new long[400];
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long bMeth_check_sum;

   public static boolean bMeth() {
      int var0 = -42;
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -56065;
      int var4 = 16886;
      int var5 = -156;
      int var6 = 21107;
      int[][] var7 = new int[400][400];
      FuzzerUtils.init((int[][])var7, (int)61);
      long[] var10000 = lArrFld;
      var10000[(var0 >>> 1) % 400] += (long)var0;
      instanceCount += (long)var0;
      var0 = (int)instanceCount;
      int var11 = 1;

      do {
         var7[var11][var11 + 1] = 29268;
         ++var11;
      } while(var11 < 356);

      var0 = var0;

      int var12;
      for(var12 = 14; var12 < 263; ++var12) {
         instanceCount = (long)var3;
         fFld -= (float)instanceCount;

         for(var4 = 1; 7 > var4; ++var4) {
            try {
               var0 = var11 / var12;
               var7[var12 - 1][var4] = 135 % var4;
               int var14 = var7[var4 - 1][var12] / var7[var12 + 1][var4];
            } catch (ArithmeticException var10) {
            }

            boolean var13 = true;
            var6 -= var6;
            var6 <<= (int)instanceCount;
            var5 = var11;
         }
      }

      long var8 = (long)(var0 + var11 + var12 + var3 + var4 + var5 + var6) + FuzzerUtils.checkSum(var7);
      bMeth_check_sum += var8;
      return var8 % 2L > 0L;
   }

   public static void vMeth(int var0) {
      int var1 = 43001;
      int var2 = -5;
      int var3 = -18838;
      int var4 = -132;
      int var5 = 165;
      int[][] var6 = new int[400][400];
      float var7 = -52.108F;
      FuzzerUtils.init((int[][])var6, (int)5);

      for(var1 = 208; var1 > 6; var1 -= 3) {
         short var8 = 22006;
         var0 = (int)((long)var0 + ((long)(var1 * var2 + var0) - instanceCount));
         var2 -= (int)((float)instanceCount + var7);
         long var10000 = --instanceCount;
         ++var0;
         var10000 -= (long)var0;
         --var0;
         var0 = (int)(var10000 + (long)var0);
         if (bMeth()) {
            if (var2 != 0) {
               vMeth_check_sum += (long)(var0 + var1 + var2 + Float.floatToIntBits(var7) + var3 + var4 + var5) + FuzzerUtils.checkSum(var6);
               return;
            }

            var0 -= var0++;
            var2 = Integer.reverseBytes(var0);
            var8 *= (short)((int)instanceCount);
         }

         for(var3 = 1; var3 < 23; ++var3) {
            var6[var3 - 1][var3] -= var3;
            var5 = 1;

            do {
               var4 <<= -122;
               fFld = (float)instanceCount;
               instanceCount = (long)var5;
               ++var5;
            } while(var5 < 2);
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + Float.floatToIntBits(var7) + var3 + var4 + var5) + FuzzerUtils.checkSum(var6);
   }

   public static int iMeth(double var0, int var2) {
      boolean var3 = true;
      int var4 = 9;
      byte var5 = -1;
      byte var6 = 5;
      byte var7 = 6;
      int var8 = 24433;
      int[] var9 = new int[400];
      boolean var10 = true;
      long var11 = -1234202050064652872L;
      FuzzerUtils.init((int[])var9, (int)11);
      var2 = (int)instanceCount;
      vMeth(var2);
      byFld -= -31;

      int var15;
      for(var15 = 309; var15 > 6; var15 -= 3) {
         switch ((var15 >>> 1) % 2 * 5 + 102) {
            case 109:
               var10 = true;
               break;
            case 110:
               var4 += var2;
               var8 += var4;
               break;
            default:
               var11 *= (long)var5;
         }
      }

      long var13 = Double.doubleToLongBits(var0) + (long)var2 + (long)var15 + (long)var4 + (long)(var10 ? 1 : 0) + (long)var5 + (long)var6 + (long)var7 + (long)var8 + var11 + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var13;
      return (int)var13;
   }

   public void mainTest(String[] var1) {
      int var2 = -3;
      int var3 = 28;
      int var4 = 9;
      int var5 = -46591;
      int var6 = -10;
      int var7 = -7;
      byte var8 = 61;
      long var9 = 30031L;
      short var11 = 24496;

      try {
         var2 += Integer.reverseBytes(iMeth(22.111932, var2));
         instanceCount -= (long)var2;
         instanceCount = (long)var2;
      } catch (UserDefinedExceptionTest var13) {
         for(var9 = 4L; 240L > var9; ++var9) {
            var3 -= var3;
         }

         for(var4 = 9; 231 > var4; ++var4) {
            var5 <<= -8;
            var2 = (int)((float)var2 + ((float)var4 * fFld + (float)var2 - (float)instanceCount));
            var2 -= (int)instanceCount;
         }

         var3 = -34601;
         var6 = 1;

         do {
            var3 = var4;
            var11 += (short)((int)((long)var6 | (long)fFld));

            for(var7 = var6; var7 < 73; ++var7) {
               iArrFld = FuzzerUtils.int1array(400, 61056);
               var11 = (short)var3;
            }

            bFld = bFld;
            ++var6;
         } while(var6 < 346);
      }

      var11 *= (short)var2;
      FuzzerUtils.out.println("i l1 i22 = " + var2 + "," + var9 + "," + var3);
      FuzzerUtils.out.println("i23 i24 i25 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("s1 i26 i27 = " + var11 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
      FuzzerUtils.out.println("Test.bFld Test.lArrFld Test.iArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 0L);
      FuzzerUtils.init((int[])iArrFld, (int)-200);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      bMeth_check_sum = 0L;
   }
}
