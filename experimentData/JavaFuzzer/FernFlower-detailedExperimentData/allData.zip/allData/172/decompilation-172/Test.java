public class Test {
   public static final int N = 400;
   public static long instanceCount = -32298L;
   public static float fFld = 1.78F;
   public static float[][] fArrFld = new float[400][400];
   public static short[] sArrFld = new short[400];
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;
   public static long lMeth1_check_sum;

   public static long lMeth1(int var0) {
      double var1 = -1.1255;
      int var3 = -4;
      int var4 = 1665;
      int var5 = 29681;
      int[] var6 = new int[400];
      boolean var7 = true;
      boolean[] var8 = new boolean[400];
      short var9 = -9717;
      long[][] var10 = new long[400][400];
      FuzzerUtils.init(var10, 1178025789L);
      FuzzerUtils.init(var6, -40446);
      FuzzerUtils.init(var8, true);

      for(var1 = 382.0; var1 > 8.0; var1 -= 2.0) {
         if (var7) {
            var10[(int)var1][(int)(var1 + 1.0)] = (long)var0;
            instanceCount -= 8173192795504588315L;
            var3 = var3;
         } else {
            var3 += (int)(var1 * (double)var3 + (double)var0 - (double)var3);
         }

         var0 -= 2;
         var3 -= var0;
         var6 = FuzzerUtils.int1array(400, 62);

         for(var4 = 1; var4 < 9; ++var4) {
            var8[(int)(var1 + 1.0)] = true;
            switch ((int)(var1 % 8.0 * 5.0 + 39.0)) {
               case 44:
                  var5 = (int)((float)var5 + ((float)(var4 * var5) + fFld - (float)var4));
               case 49:
                  var6[var4] = (int)instanceCount;
                  break;
               case 45:
               case 56:
                  var9 = (short)(var9 + 16667);
                  break;
               case 50:
                  var5 = (int)var1;
                  break;
               case 51:
                  var0 <<= (int)instanceCount;
                  break;
               case 67:
                  var5 = var5;
                  var0 += 174;
                  break;
               case 75:
                  instanceCount -= instanceCount;
            }
         }
      }

      long var11 = (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)(var7 ? 1 : 0) + (long)var4 + (long)var5 + (long)var9 + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var8);
      lMeth1_check_sum += var11;
      return var11;
   }

   public static long lMeth() {
      int var0 = 55977;
      boolean var1 = true;
      int var2 = -104;
      int var3 = 1;
      int var4 = -7;
      byte var5 = -7;
      int[] var6 = new int[400];
      byte var7 = -91;
      boolean var8 = true;
      FuzzerUtils.init((int[])var6, (int)-13);
      var0 = 1;

      int var11;
      do {
         for(var11 = 1; var11 < 7; ++var11) {
            short[] var10000 = sArrFld;
            var10000[var0] += (short)((int)instanceCount);

            for(var3 = 1; 2 > var3; ++var3) {
               var4 = (int)instanceCount;
               var7 += (byte)(var3 * var0 + var4 - var2);
               instanceCount = (long)var11;
               var2 = var4;
               int var12 = var4 - var3;
               if (var8) {
               }
            }

            var6[var0] = var3;
            var4 = var5;
            var8 = true;
         }

         ++var0;
      } while(var0 < 221);

      long var9 = (long)(var0 + var11 + var2 + var3 + var4 + var7 + (var8 ? 1 : 0) + var5) + FuzzerUtils.checkSum(var6);
      lMeth_check_sum += var9;
      return var9;
   }

   public static void vMeth(int var0, int var1, double var2) {
      boolean var4 = true;
      int var5 = -2;
      int[] var6 = new int[400];
      boolean var7 = true;
      byte var8 = -108;
      FuzzerUtils.init((int[])var6, (int)-179);

      int var9;
      for(var9 = 248; 7 < var9; --var9) {
         var0 <<= (int)(-(Math.abs(instanceCount) + -8L * lMeth()));
         var5 = var0;
         var1 = -2083620938;
         if (var9 != 0) {
            vMeth_check_sum += (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var9 + (long)var0 + (long)(var7 ? 1 : 0) + (long)var8 + FuzzerUtils.checkSum(var6);
            return;
         }

         var1 -= (int)fFld;
         var1 ^= (int)instanceCount;
         var1 -= 5007;
         if (var7) {
            switch (59) {
               case 59:
                  instanceCount %= (long)fFld | 1L;
                  var6[var9 + 1] = (int)instanceCount;
                  var0 *= var0;
                  float[] var10000 = fArrFld[var9 - 1];
                  var10000[var9] /= (float)(var1 | 1);
               case 60:
                  var5 = (int)var2;
            }
         } else {
            fFld += (float)var8;
         }
      }

      vMeth_check_sum += (long)(var0 + var1) + Double.doubleToLongBits(var2) + (long)var9 + (long)var5 + (long)(var7 ? 1 : 0) + (long)var8 + FuzzerUtils.checkSum(var6);
   }

   public void mainTest(String[] var1) {
      int var2;
      int var3;
      int var4;
      int var5;
      int var6;
      int var7;
      int var8;
      int[] var9;
      double var10;
      short var12;
      long var13;
      var2 = -178;
      var3 = 35940;
      var4 = -31163;
      var5 = 212;
      var6 = -41705;
      var7 = 60665;
      var8 = 11;
      var9 = new int[400];
      var10 = 0.10765;
      var12 = 7489;
      var13 = -241L;
      FuzzerUtils.init((int[])var9, (int)-14);
      var2 = var2;
      var9[(var2 >>> 1) % 400] += (int)(instanceCount = (long)((var10 - -4121.0) * 65379.0));
      label47:
      switch (((int)(instanceCount - 11000L) >>> 1) % 2 * 5 + 43) {
         case 48:
            var2 >>= (int)instanceCount;
            int var10000 = var2;
            float var20 = ++fArrFld[(var2 >>> 1) % 400][0];
            ++var2;
            var2 = var10000 << (int)(var20 + (float)(instanceCount - (long)var2));
            vMeth(var2, var2, var10);
            int[] var15 = var9;
            int var16 = var9.length;
            int var17 = 0;

            while(true) {
               if (var17 >= var16) {
                  break label47;
               }

               int var18 = var15[var17];
               instanceCount -= -154L;

               for(var3 = 3; var3 < 63; ++var3) {
                  instanceCount += (long)(var3 * var3);
                  var12 <<= (short)var18;
                  var9[var3] >>= (int)instanceCount;
                  fFld += (float)(var3 * var2) + fFld - (float)var3;
                  char var19 = '톴';
                  var2 = (int)var10;
                  var4 = var19 << (int)instanceCount;
               }

               var9[(var3 >>> 1) % 400] = var3;

               for(var5 = 3; var5 < 63; ++var5) {
                  var18 += var6;
                  var4 += var5 + var4;
                  var7 = var5;

                  while(var7 < 2) {
                     ++var2;
                     var8 = 35;
                     fFld = (float)var18;
                     switch (var5 % 2 * 5 + 98) {
                        case 101:
                        case 102:
                           var8 += var2;
                           var10000 = var8 * (int)var13;
                           var18 += var7 ^ var18;
                           var8 = var2;
                        default:
                           var9[var5] <<= (int)var13;
                           ++var7;
                     }
                  }
               }

               ++var17;
            }
         case 50:
            var2 = var2;
            break;
         default:
            var6 -= var6;
      }

      FuzzerUtils.out.println("i d i16 = " + var2 + "," + Double.doubleToLongBits(var10) + "," + var3);
      FuzzerUtils.out.println("i17 s1 i18 = " + var4 + "," + var12 + "," + var5);
      FuzzerUtils.out.println("i19 i20 i21 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("l iArr = " + var13 + "," + FuzzerUtils.checkSum(var9));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.fArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 1.816F);
      FuzzerUtils.init((short[])sArrFld, (short)18506);
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      lMeth1_check_sum = 0L;
   }
}
