public class Test {
   public static final int N = 400;
   public static long instanceCount = 7709079513175631415L;
   public static int iFld = -22204;
   public double dFld = -2.91153;
   public static float fFld = -1.24F;
   public static byte byFld = -34;
   public static double dFld1 = 100.68138;
   public static volatile boolean bFld = false;
   public static byte[] byArrFld = new byte[400];
   public static volatile double[] dArrFld = new double[400];
   public static float[] fArrFld = new float[400];
   public static long bMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth() {
      boolean var0 = true;
      int var1 = 7398;
      boolean var2 = true;
      int var3 = -56;
      boolean var4 = true;
      short var5 = -11;
      int var6 = -110;
      int var7 = -1;
      int[] var8 = new int[400];
      short var9 = 31184;
      double var10 = 33.110441;
      byte var12 = -126;
      FuzzerUtils.init((int[])var8, (int)12);
      iFld = -252;

      int var15;
      for(var15 = 2; var15 < 272; ++var15) {
         iFld += var15;
         iFld += var1;
      }

      int var16;
      for(var16 = 7; 387 > var16; ++var16) {
         fFld += (float)var1;
      }

      int var17;
      for(var17 = 13; var17 < 297; ++var17) {
         var5 = var9;
         switch (var17 % 6 + 43) {
            case 43:
               var1 -= var9;

               for(var6 = 1; 6 > var6; ++var6) {
                  var10 = (double)var12;
                  var8[var17 - 1] += var17;
                  byte[] var10000 = byArrFld;
                  var10000[var17 - 1] >>= (byte)var17;

                  try {
                     var3 = var6 / var3;
                     var8[var6] = var15 / var17;
                     var8[var6] = var8[var6 + 1] / iFld;
                  } catch (ArithmeticException var14) {
                  }
               }
            case 44:
               var3 += var17;
               break;
            case 45:
               iFld += var15;
               break;
            case 46:
               var8[var17 + 1] = var17;
               break;
            case 47:
               var3 = 9;
               break;
            case 48:
               var7 = (int)instanceCount;
         }
      }

      vMeth_check_sum += (long)(var15 + var1 + var16 + var3 + var17 + var5 + var9 + var6 + var7) + Double.doubleToLongBits(var10) + (long)var12 + FuzzerUtils.checkSum(var8);
   }

   public static int iMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      byte var4 = -88;
      int var5 = -2;
      int var6 = -56755;
      int var7 = -7;
      char var8 = '\uf720';
      int[][] var9 = new int[400][400];
      int[] var10 = new int[400];
      short var11 = 17743;
      boolean var12 = false;
      FuzzerUtils.init((int[][])var9, (int)137);
      FuzzerUtils.init((int[])var10, (int)10);

      int var17;
      for(var17 = 3; var17 < 360; ++var17) {
         iFld = var1 = (int)Math.abs((long)var2 + instanceCount);
         vMeth();
         var5 = 1;

         do {
            var6 = 1;

            while(true) {
               ++var6;
               if (var6 >= 1) {
                  var11 = (short)(var11 - 56);
                  ++var5;
                  break;
               }

               var2 = var4;
               instanceCount -= (long)fFld;
            }
         } while(var5 < 5);

         var1 = (int)((float)var1 + ((float)var17 * fFld + (float)instanceCount - (float)var6));
      }

      var9[(var6 >>> 1) % 400][(var17 >>> 1) % 400] -= byFld;
      int[] var13 = var10;
      int var14 = var10.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         int var10000 = var13[var15];

         for(var7 = 1; var7 < 4; ++var7) {
            var12 = true;
            var1 -= (int)dFld1;
            var10[var7] -= (int)fFld;
         }
      }

      long var18 = (long)(var0 + var1 + var2 + var17 + var4 + var5 + var6 + var11 + var7 + var8 + (var12 ? 1 : 0)) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var18;
      return (int)var18;
   }

   public static boolean bMeth(int var0, int var1) {
      int var2 = -7;
      int var3 = 58;
      int var4 = -94;
      int var5 = -9;
      int[] var6 = new int[400];
      long var7 = -37580L;
      long[][] var9 = new long[400][400];
      long[] var10 = new long[400];
      FuzzerUtils.init((int[])var6, (int)-191);
      FuzzerUtils.init(var9, -2006617079L);
      FuzzerUtils.init(var10, 1644995907L);
      var6[(var1 >>> 1) % 400] &= 36213;
      if (bFld) {
         var0 = (int)((long)iMeth(iFld, iFld, 49048) + -149430473L);

         for(var2 = 9; 195 > var2; ++var2) {
            var9[var2 - 1][var2 + 1] -= -15871L;
            var7 = 1L;

            do {
               for(var4 = 1; var4 < 1; var4 += 3) {
                  switch (var4 % 7 + 44) {
                     case 44:
                        iFld = var5;
                        var3 *= -12;
                        var0 -= (int)fFld;
                        fFld -= (float)instanceCount;
                        break;
                     case 45:
                        iFld = 8;
                        var6[var4] = var2;
                        var5 += -3441 + var4 * var4;
                        break;
                     case 46:
                        double[] var10000 = dArrFld;
                        var10000[var2 - 1] += (double)var7;
                        break;
                     case 47:
                        dFld1 = 4.9984419067641201E18;
                        break;
                     case 48:
                        if (var5 != 0) {
                           return (int)((long)(var0 + var1 + var2 + var3) + var7 + (long)var4 + (long)var5 + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var10)) % 2 > 0;
                        }
                     case 49:
                        var0 -= var3;
                        break;
                     case 50:
                        var1 += var4 * var3 + var3 - var3;
                        break;
                     default:
                        fArrFld = fArrFld;
                  }
               }
            } while(++var7 < 9L);
         }
      } else if (bFld) {
         bFld = bFld;
      }

      long var11 = (long)(var0 + var1 + var2 + var3) + var7 + (long)var4 + (long)var5 + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var10);
      bMeth_check_sum += var11;
      return var11 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 3;
      byte var4 = 23;
      int var5 = -193;
      int var6 = 14;
      byte var7 = -112;
      boolean var8 = true;
      int var9 = -143;
      int var10 = -17035;
      int var11 = -229;
      int var12 = 115;
      int[] var13 = new int[400];
      float var14 = 29.446F;
      double var15 = -1.126296;
      short var17 = -10674;
      long[][][] var18 = new long[400][400][400];
      FuzzerUtils.init((Object[][])var18, -2L);
      FuzzerUtils.init((int[])var13, (int)77);
      byArrFld[82] = (byte)iFld;
      long var10001 = (long)iFld;
      long var10002 = (long)(this.dFld + (double)instanceCount);
      long[] var10003 = var18[69][(iFld >>> 1) % 400];
      instanceCount += var10001 - (var10002 >> (int)(var10003[324] -= (long)iFld));

      int var19;
      for(var19 = 10; 208 > var19; ++var19) {
         if (!bMeth(iFld, var19)) {
            for(var14 = 4.0F; var14 < 127.0F; ++var14) {
               for(var5 = 1; 2 > var5 && !bFld; ++var5) {
               }
            }

            var3 += (int)instanceCount;
            var3 += var3;
            fFld += (float)(var19 - iFld);

            for(var15 = 6.0; var15 < 127.0; ++var15) {
               iFld += (int)(var15 * (double)instanceCount);
               fFld += (float)var3;
            }

            instanceCount %= (long)(var7 | 1);
            instanceCount += (long)var19;
         }
      }

      int var20;
      for(var20 = 6; var20 < 214; ++var20) {
         for(var10 = 121; 7 < var10; var10 -= 2) {
            var12 = 3;

            do {
               fFld -= (float)var17;
               var18[var10][var10 - 1][var12] = instanceCount;
               var11 = (int)((long)var11 + ((long)(var12 * var7 + var12) - instanceCount));
               var13[var10 - 1] -= var5;
               var9 = var5 * var7;
               switch (var20 % 2 + 107) {
                  case 107:
                     var13 = FuzzerUtils.int1array(400, 43629);
                     var6 = var9;
                     double[] var10000 = dArrFld;
                     var10000[var10 - 1] += (double)var9;
                     iFld += var12 | var9;
                     break;
                  case 108:
                     var3 <<= 60;
                     break;
                  default:
                     fFld += (float)instanceCount;
               }

               --var12;
            } while(var12 > 0);
         }
      }

      FuzzerUtils.out.println("i i1 f = " + var19 + "," + var3 + "," + Float.floatToIntBits(var14));
      FuzzerUtils.out.println("i26 i27 i28 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("d1 i29 i30 = " + Double.doubleToLongBits(var15) + "," + var7 + "," + var20);
      FuzzerUtils.out.println("i31 i32 i33 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("i34 s2 lArr = " + var12 + "," + var17 + "," + FuzzerUtils.checkSum((Object[][])var18));
      FuzzerUtils.out.println("iArr4 = " + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("Test.fFld Test.byFld Test.dFld1 = " + Float.floatToIntBits(fFld) + "," + byFld + "," + Double.doubleToLongBits(dFld1));
      FuzzerUtils.out.println("Test.bFld Test.byArrFld Test.dArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(byArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((byte[])byArrFld, (byte)103);
      FuzzerUtils.init(dArrFld, 2.44158);
      FuzzerUtils.init(fArrFld, 1.69F);
      bMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
