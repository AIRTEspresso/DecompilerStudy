public class Test {
   public static final int N = 400;
   public static long instanceCount = 30605L;
   public int iFld = -38635;
   public static short sFld = 2324;
   public static int iFld1 = 8;
   public static boolean bFld = false;
   public boolean bFld1 = false;
   public static int[] iArrFld = new int[400];
   public static double[] dArrFld = new double[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(float var0) {
      int var1 = 202;
      boolean var2 = true;
      byte var3 = 54;
      int var4 = 41;
      int var5 = 104;
      double var6 = 1.8612;
      long[] var8 = new long[400];
      FuzzerUtils.init(var8, 2648983453L);
      var1 *= 11;

      int var9;
      for(var9 = 343; 7 < var9; var9 -= 2) {
         var1 -= (int)instanceCount;
         int[] var10000 = iArrFld;
         var10000[var9 + 1] >>= var3;
         var10000 = iArrFld;
         var10000[var9] += (int)var0;
         iArrFld = iArrFld;

         for(var4 = 1; var4 < 9; ++var4) {
            double[] var10 = dArrFld;
            var10[var9] *= (double)var4;
         }

         instanceCount += -2471792388101766201L;
         var8[var9 + 1] -= (long)var5;
         var0 *= -135.0F;
         var5 -= (int)var6;
      }

      instanceCount >>= '\udf91';
      instanceCount += (long)var4;
      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1 + var9 + var3 + var4 + var5) + Double.doubleToLongBits(var6) + FuzzerUtils.checkSum(var8);
   }

   public static int iMeth1() {
      int var0 = -11;
      boolean var1 = true;
      int var2 = -12985;
      int var3 = 4;
      int var4 = -14;
      int var5 = 141;
      int var6 = 10;
      float var7 = 2.307F;
      boolean var8 = true;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, -3134388285L);
      int var10000 = var0 >>> (int)var9[(var0 >>> 1) % 400];
      var0 = 45291;
      vMeth(var7);

      int var12;
      for(var12 = 13; var12 < 290; ++var12) {
         for(var3 = 1; var3 < 6; var3 += 2) {
            instanceCount += (long)(var3 * sFld);

            for(var5 = 1; var5 < 3; ++var5) {
               if (!var8) {
                  var6 >>>= (int)instanceCount;
                  var4 += (int)instanceCount;
               }
            }

            switch (var12 % 2 * 5 + 16) {
               case 22:
                  var2 += var3 ^ var2;
                  var6 += var3;
                  break;
               case 23:
                  instanceCount += (long)var2;
                  var0 += var3;
                  break;
               default:
                  var4 += 10;
            }
         }
      }

      long var10 = (long)(var0 + Float.floatToIntBits(var7) + var12 + var2 + var3 + var4 + var5 + var6 + (var8 ? 1 : 0)) + FuzzerUtils.checkSum(var9);
      iMeth1_check_sum += var10;
      return (int)var10;
   }

   public static int iMeth(int var0, int var1, float var2) {
      int var3 = 53037;
      byte var4 = 33;
      int var5 = 10;
      int var6 = 24893;
      int var7 = 4;
      byte var8 = -5;
      int var9 = -190;
      byte var10 = 9;
      byte var11 = 7;
      byte var12 = -21;
      double var13 = -6.6663;
      boolean var15 = true;
      boolean[] var16 = new boolean[400];
      long[][][] var17 = new long[400][400][400];
      FuzzerUtils.init(var16, false);
      FuzzerUtils.init((Object[][])var17, -2765748243573170087L);

      for(var3 = 196; 7 < var3; var3 -= 3) {
         for(var5 = var3; 24 > var5; ++var5) {
            iArrFld[var5 + 1] = var7;
            var12 *= (byte)(var7++);
         }

         label50:
         for(var13 = 1.0; var13 < 24.0; ++var13) {
            var16[var3] = var15;
            var2 += (float)(var13 * (double)instanceCount + (double)var1 - (double)var1);
            var0 >>= var6-- >> iMeth1();
            iFld1 = var3;
            int[] var10000 = iArrFld;
            var10000[var3 - 1] *= (int)var2;
            switch (var3 % 8 + 46) {
               case 46:
                  var2 += (float)var13;
                  var9 = 1;

                  while(true) {
                     if (var9 >= 2) {
                        continue label50;
                     }

                     instanceCount += instanceCount;
                     instanceCount <<= var5;
                     ++var9;
                  }
               case 47:
                  var0 = var6;
                  break;
               case 48:
                  var17[var3 + 1][(int)var13][(int)(var13 + 1.0)] += (long)var11;
                  break;
               case 49:
                  var6 = var9;
                  break;
               case 50:
                  instanceCount = instanceCount;
                  break;
               case 51:
                  instanceCount &= (long)var7;
               case 52:
                  iArrFld[var3] = (int)instanceCount;
                  break;
               case 53:
                  var15 = var15;
            }
         }
      }

      long var18 = (long)(var0 + var1 + Float.floatToIntBits(var2) + var3 + var4 + var5 + var6 + var7 + var12) + Double.doubleToLongBits(var13) + (long)var8 + (long)(var15 ? 1 : 0) + (long)var9 + (long)var10 + (long)var11 + FuzzerUtils.checkSum(var16) + FuzzerUtils.checkSum((Object[][])var17);
      iMeth_check_sum += var18;
      return (int)var18;
   }

   public void mainTest(String[] var1) {
      float var2 = 110.93F;
      boolean var3 = true;
      int var4 = 30670;
      int var5 = -24787;
      int var6 = 61226;
      int var7 = -4;
      int var8 = 11;
      byte var9 = -12;
      int var10 = 174;
      double var11 = -116.124496;
      byte var13 = 92;
      long[] var14 = new long[400];
      FuzzerUtils.init(var14, -3L);
      instanceCount &= -6L;
      this.iFld >>= (int)(-7L - (long)iArrFld[(this.iFld >>> 1) % 400] + instanceCount + (long)this.iFld + (long)iMeth(this.iFld, iFld1, var2));
      instanceCount -= (long)this.iFld;
      int var10001 = (iFld1 >>> 1) % 400;
      var14[var10001] >>= iFld1;
      iFld1 = iFld1;
      int var17 = 1;

      while(true) {
         label77:
         while(true) {
            ++var17;
            if (var17 >= 323) {
               FuzzerUtils.out.println("f3 i23 d2 = " + Float.floatToIntBits(var2) + "," + var17 + "," + Double.doubleToLongBits(var11));
               FuzzerUtils.out.println("i24 i25 i26 = " + var4 + "," + var5 + "," + var6);
               FuzzerUtils.out.println("i27 i28 i29 = " + var7 + "," + var8 + "," + var9);
               FuzzerUtils.out.println("by1 i30 lArr3 = " + var13 + "," + var10 + "," + FuzzerUtils.checkSum(var14));
               FuzzerUtils.out.println("Test.instanceCount iFld Test.sFld = " + instanceCount + "," + this.iFld + "," + sFld);
               FuzzerUtils.out.println("Test.iFld1 Test.bFld bFld1 = " + iFld1 + "," + (bFld ? 1 : 0) + "," + (this.bFld1 ? 1 : 0));
               FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
               FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
               return;
            }

            switch ((this.iFld >>> 1) % 10 + 74) {
               case 74:
                  this.iFld += 13;
                  this.iFld *= -3;
                  var11 += (double)instanceCount;
                  break;
               case 75:
                  this.iFld = (int)var2;
                  if (bFld) {
                     try {
                        this.iFld = iArrFld[var17 - 1] / -119;
                        iFld1 = iArrFld[var17] / iFld1;
                        iFld1 = var17 % iFld1;
                     } catch (ArithmeticException var16) {
                     }
                  }
               case 76:
                  for(var4 = var17; var4 < 78; ++var4) {
                     var11 -= (double)var17;
                     switch (89) {
                        case 89:
                           var2 += (float)var17;
                           break;
                        case 90:
                           for(var6 = 1; var6 < 1; var6 += 3) {
                              this.iFld -= this.iFld;
                           }

                           for(var8 = 1; var8 < 1; ++var8) {
                              var13 = (byte)((int)instanceCount);
                              var2 += 12376.0F;
                              var7 = var4;
                           }

                           this.iFld >>= 1205108582;
                           var13 += (byte)((int)(127.642F + (float)(var4 * var4)));
                           break;
                        case 91:
                           bFld = this.bFld1;
                           bFld = this.bFld1;
                           this.iFld = 1;
                     }

                     instanceCount += (long)var4 * instanceCount + (long)iFld1 - instanceCount;
                     var14[var17] += instanceCount;
                  }
                  break;
               case 77:
                  var7 = var9;
                  break;
               case 78:
                  var7 >>>= var17;
               case 79:
                  iFld1 -= -13;
                  break;
               case 80:
                  var10 -= 24120;
                  break;
               case 81:
                  instanceCount >>= -65003;
                  break;
               case 82:
                  dArrFld = FuzzerUtils.double1array(400, 2.75698);
               case 83:
                  break label77;
            }
         }

         var5 = (int)var11;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-216);
      FuzzerUtils.init(dArrFld, -116.86471);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
