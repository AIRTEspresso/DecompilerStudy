public class Test {
   public static final int N = 400;
   public static long instanceCount = 5449956700307727638L;
   public static int iFld = -5;
   public static float fFld = -124.618F;
   public static byte byFld = 74;
   public static boolean bFld = false;
   public static short sFld = -31319;
   public static byte[] byArrFld = new byte[400];
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long fMeth_check_sum;

   public static float fMeth() {
      short var0 = 30806;
      double var1 = -1.48171;
      double[] var3 = new double[400];
      boolean var4 = true;
      int var5 = 211;
      int var6 = -45744;
      byte var7 = 3;
      long[][] var8 = new long[400][400];
      FuzzerUtils.init(var8, -745590333L);
      FuzzerUtils.init(var3, 122.114756);
      byte[] var9 = byArrFld;
      int var10 = var9.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         byte var10000 = var9[var11];
         iFld = (int)instanceCount;
         var0 = (short)iFld;
         iFld = iFld;
      }

      iFld += (int)var1;
      fFld -= -16.10104F;
      int var13 = 1;

      while(true) {
         ++var13;
         if (var13 >= 239) {
            long var14 = (long)var0 + Double.doubleToLongBits(var1) + (long)var13 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8) + Double.doubleToLongBits(FuzzerUtils.checkSum(var3));
            fMeth_check_sum += var14;
            return (float)var14;
         }

         var5 = 1;

         while(true) {
            iFld = (int)((float)iFld + ((float)(var5 * var5) + fFld - (float)iFld));
            var8[var5 + 1] = var8[var5];
            var3[var13] += -5.4740311899065528E18;

            for(var6 = 1; var6 < 1; ++var6) {
               byFld = (byte)iFld;
               int[] var15 = iArrFld;
               var15[var5 + 1] -= (int)fFld;
            }

            iFld += -122 + var5 * var5;
            ++var5;
            if (var5 >= 7) {
               break;
            }
         }
      }
   }

   public static int iMeth1(long var0, float var2, int var3) {
      boolean var4 = true;
      int var5 = 11291;
      int var6 = 307;
      int var7 = 153;
      int var8 = -2;
      double var9 = 1.57526;
      long var11 = -34939L;
      fMeth();
      int var16 = 1;

      while(true) {
         ++var16;
         if (var16 >= 269) {
            long var13 = var0 + (long)Float.floatToIntBits(var2) + (long)var3 + (long)var16 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(var9) + var11;
            iMeth1_check_sum += var13;
            return (int)var13;
         }

         var3 = var16;
         iFld = var16;

         for(var5 = 1; var5 < 6; ++var5) {
            for(var7 = var16; var7 < 2; ++var7) {
               var9 -= (double)var7;
               var3 += 40207;
               var8 >>>= (int)var0;
               iFld += (int)var9;

               try {
                  var6 = var5 % var8;
                  var3 = iArrFld[var16 - 1] / iFld;
                  var8 = 235 / var16;
               } catch (ArithmeticException var15) {
               }

               var6 += var7;
               iFld >>= (int)var11;
               int[] var10000 = iArrFld;
               var10000[var5 + 1] += var16;
               instanceCount &= (long)var16;
            }
         }
      }
   }

   public static int iMeth(float var0, float var1, short var2) {
      boolean var3 = true;
      int var4 = -57;
      int var5 = 125;
      byte var6 = 7;
      int[][] var7 = new int[400][400];
      byte var8 = 67;
      long var9 = 3281820677L;
      double var11 = -61.73448;
      double[] var13 = new double[400];
      float[][] var14 = new float[400][400];
      FuzzerUtils.init((int[][])var7, (int)-6);
      FuzzerUtils.init(var13, 21.24085);
      FuzzerUtils.init(var14, -2.486F);
      int var17 = 321;

      while(true) {
         var17 -= 3;
         if (var17 <= 0) {
            var4 -= 26243;
            if (bFld) {
               instanceCount += (long)var17;
            } else if (bFld) {
               var14[(var6 >>> 1) % 400][(iFld >>> 1) % 400] = 38730.0F;
            } else if (bFld) {
               var11 = (double)var2;
            }

            long var15 = (long)(Float.floatToIntBits(var0) + Float.floatToIntBits(var1) + var2 + var17 + var8) + var9 + (long)var4 + (long)var5 + (long)var6 + Double.doubleToLongBits(var11) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var14));
            iMeth_check_sum += var15;
            return (int)var15;
         }

         iFld = (int)((float)var7[var17][var17] - ((float)(iFld - var8) - ((float)iFld + var1)));

         for(var9 = (long)var17; 15L > var9; ++var9) {
            iFld = (int)(--instanceCount);
            iFld = iMeth1(instanceCount, -1.719F, var17);
            var2 += (short)var17;

            for(var5 = 1; var5 < 1; ++var5) {
               var13[var5 - 1] += (double)var6;
               var4 = iFld;
            }
         }

         iFld += var4;
         var4 += var17;
      }
   }

   public void mainTest(String[] var1) {
      double var2;
      int var4;
      int var5;
      int var6;
      int var7;
      int var8;
      int var9;
      int var10;
      int var11;
      int var12;
      int var13;
      int var14;
      boolean[] var15;
      var2 = -36.46758;
      var4 = 135;
      var5 = 239;
      var6 = -20600;
      var7 = 10;
      var8 = -33963;
      var9 = 11;
      var10 = -1;
      var11 = 45;
      var12 = 12;
      var13 = 61;
      var14 = -31384;
      var15 = new boolean[400];
      FuzzerUtils.init(var15, true);
      int[] var10000;
      label89:
      switch ((iMeth(fFld, fFld, sFld) >>> 1) % 10 + 100) {
         case 100:
            sFld -= (short)((int)var2);
            break;
         case 101:
         case 102:
            for(var4 = 134; var4 > 4; --var4) {
               instanceCount <<= byFld;
               byFld += (byte)iFld;

               for(var6 = 7; 193 > var6; ++var6) {
                  if (!bFld) {
                     var5 += (int)fFld;
                     var8 = 1;

                     do {
                        var5 >>= var7;
                        fFld = (float)var6;
                        var2 = (double)instanceCount;
                        var7 += var8 * var8;
                        var5 += (int)fFld;
                        instanceCount = instanceCount;
                        ++var8;
                     } while(var8 < 2);

                     var5 -= iFld;
                     var5 -= 49535;
                  }
               }

               byFld += (byte)var6;
               if (bFld) {
                  break;
               }

               for(var9 = 10; var9 < 193; ++var9) {
                  bFld = bFld;
                  iFld += var9;
                  bFld = bFld;
               }

               var5 <<= (int)instanceCount;
            }

            var11 = 6;

            while(true) {
               if (var11 >= 157) {
                  break label89;
               }

               if (!bFld) {
                  for(var13 = 6; var13 < 166; ++var13) {
                     var10000 = iArrFld;
                     var10000[var11 + 1] -= iFld;
                     var12 += var8;
                  }

                  var10000 = iArrFld;
                  var10000[var11 + 1] += var11;
               }

               ++var11;
            }
         case 103:
            var14 -= 1061;
         case 104:
            var15[(var13 >>> 1) % 400] = bFld;
         case 105:
            var10 = (int)instanceCount;
            break;
         case 106:
            instanceCount = (long)var8;
            break;
         case 107:
            bFld = bFld;
            break;
         case 108:
            var7 += sFld;
            break;
         case 109:
            var10 = var4;
            break;
         default:
            var10000 = iArrFld;
            var10000[(var4 >>> 1) % 400] -= (int)instanceCount;
      }

      FuzzerUtils.out.println("d3 i14 i15 = " + Double.doubleToLongBits(var2) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i16 i17 i18 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i19 i20 i21 = " + var9 + "," + var10 + "," + var11);
      FuzzerUtils.out.println("i22 i23 i24 = " + var12 + "," + var13 + "," + var14);
      FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.byFld Test.bFld Test.sFld = " + byFld + "," + (bFld ? 1 : 0) + "," + sFld);
      FuzzerUtils.out.println("Test.byArrFld Test.iArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(byArrFld, (byte)-72);
      FuzzerUtils.init((int[])iArrFld, (int)-217);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      fMeth_check_sum = 0L;
   }
}
