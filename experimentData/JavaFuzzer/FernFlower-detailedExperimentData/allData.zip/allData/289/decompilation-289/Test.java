public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -5L;
   public int iFld = 143;
   public static int iFld1 = -25963;
   public static float fFld = 2.984F;
   public static long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = 14;
      int var2 = 184;
      int var3 = 68;
      byte var4 = -63;
      int[] var5 = new int[400];
      boolean var6 = true;
      long var7 = 57L;
      FuzzerUtils.init((int[])var5, (int)-7090);

      int var9;
      for(var9 = 11; var9 < 336; ++var9) {
         var1 += var9 * var9;
         if (var9 != 0) {
            vMeth1_check_sum += (long)(var9 + var1 + (var6 ? 1 : 0) + var2 + var3) + var7 + (long)var4 + FuzzerUtils.checkSum(var5);
            return;
         }

         var5[var9 + 1] = var9;
         var1 = 127;
         switch (var9 % 5 * 5 + 116) {
            case 128:
               var5 = var5;
               break;
            case 129:
            case 130:
            case 132:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            default:
               var5[var9] = (int)instanceCount;
               break;
            case 131:
               var1 ^= -207;
               break;
            case 133:
               if (var6) {
                  break;
               }

               var2 = 1;

               for(; var2 < 5; ++var2) {
                  var1 = var1;

                  for(var7 = (long)var9; 2L > var7; ++var7) {
                     var3 = (int)var7;
                     var1 += (int)instanceCount;
                     if (var1 != 0) {
                        vMeth1_check_sum += (long)(var9 + var1 + (var6 ? 1 : 0) + var2 + var3) + var7 + (long)var4 + FuzzerUtils.checkSum(var5);
                        return;
                     }

                     var3 += (int)(var7 * (long)var1 + (long)var9 - (long)var3);
                     if (var6) {
                        break;
                     }
                  }
               }
               break;
            case 141:
               var5[var9 + 1] += -13728;
            case 140:
               lArrFld = lArrFld;
         }
      }

      vMeth1_check_sum += (long)(var9 + var1 + (var6 ? 1 : 0) + var2 + var3) + var7 + (long)var4 + FuzzerUtils.checkSum(var5);
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = 46095;
      int var2 = -27211;
      byte var3 = -9;
      boolean var4 = true;
      int var5 = -36752;
      int[] var6 = new int[400];
      boolean var7 = false;
      float var8 = -20.36F;
      byte var9 = -104;
      FuzzerUtils.init((int[])var6, (int)3);

      int var11;
      for(var11 = 6; 180 > var11; ++var11) {
         vMeth1();
         var6[var11 + 1] *= var11;
         instanceCount <<= var11;
         if (!var7) {
            for(var2 = 1; var2 < 9; var2 += 3) {
               var6[var11 + 1] = var3;
               var8 *= var8;
            }

            var1 += var2;
         }
      }

      int var12;
      for(var12 = 6; var12 < 140; ++var12) {
         short var10 = -1947;
         instanceCount += (long)var12 | instanceCount;
         if (var7) {
            instanceCount <<= var9;
            var1 = (int)((long)var1 + ((long)var12 ^ (long)var8));
            var9 = (byte)var12;
         } else {
            var8 += (float)((long)(var12 * var10 + var12) - instanceCount);
         }
      }

      vMeth_check_sum += (long)(var11 + var1 + (var7 ? 1 : 0) + var2 + var3 + Float.floatToIntBits(var8) + var12 + var5 + var9) + FuzzerUtils.checkSum(var6);
   }

   public static int iMeth(int var0) {
      boolean var1 = true;
      int var2 = -131;
      int var3 = -36580;
      int[][] var4 = new int[400][400];
      float var5 = -58.967F;
      byte var6 = 83;
      long var7 = -9L;
      boolean var9 = false;
      short var10 = 15254;
      FuzzerUtils.init((int[][])var4, (int)0);
      vMeth();
      int var13 = 1;

      do {
         var2 -= var13;
         ++var13;
      } while(var13 < 246);

      var0 -= (int)var5;
      var4[(var2 >>> 1) % 400][(var2 >>> 1) % 400] &= (int)instanceCount;
      var3 = 1;

      while(true) {
         ++var3;
         if (var3 >= 133) {
            long var11 = (long)(var0 + var13 + var2 + Float.floatToIntBits(var5) + var3 + var6) + var7 + (long)(var9 ? 1 : 0) + (long)var10 + FuzzerUtils.checkSum(var4);
            iMeth_check_sum += var11;
            return (int)var11;
         }

         var6 = (byte)var3;
         if (var0 != 0) {
         }

         var0 >>= var3;

         for(var7 = 1L; ++var7 < 12L; var4[(int)(var7 - 1L)] = var4[(int)var7]) {
            var9 = var9;
            var2 += (int)var7;
            var2 -= var10;
            var4[(var0 >>> 1) % 400][(int)(var7 - 1L)] &= var0;
         }
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -226;
      int var4 = -3;
      int var5 = 8371;
      int[] var6 = new int[400];
      long var7 = -9170598587590241171L;
      short var9 = 24302;
      float var10 = 0.728F;
      float[] var11 = new float[400];
      boolean var12 = true;
      FuzzerUtils.init(var11, -1.1015F);
      FuzzerUtils.init((int[])var6, (int)-13);
      int var13 = 1;

      while(true) {
         while(true) {
            while(true) {
               var13 += 2;
               if (var13 >= 364) {
                  FuzzerUtils.out.println("i i1 l2 = " + var13 + "," + var3 + "," + var7);
                  FuzzerUtils.out.println("i19 s2 f2 = " + var4 + "," + var9 + "," + Float.floatToIntBits(var10));
                  FuzzerUtils.out.println("i20 b3 fArr = " + var5 + "," + (var12 ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)));
                  FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(var6));
                  FuzzerUtils.out.println("Test.instanceCount iFld Test.iFld1 = " + instanceCount + "," + this.iFld + "," + iFld1);
                  FuzzerUtils.out.println("Test.fFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(lArrFld));
                  FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                  FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                  FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                  return;
               }

               var3 -= (int)((float)Math.min((int)(2.605F + 92.597F + (float)(var13 + var13)), var3) + var11[var13]);
               if (var12) {
                  var3 = iMeth(var13);
                  switch (var13 % 4 * 5 + 99) {
                     case 100:
                        instanceCount -= (long)var3;
                        var3 = var13;
                        break;
                     case 107:
                     case 119:
                     default:
                        this.iFld = this.iFld;

                        for(var7 = (long)var13; 138L > var7; ++var7) {
                           iFld1 -= 1482667220;
                           this.iFld = var9;

                           for(var10 = (float)var13; var10 < 1.0F; ++var10) {
                              instanceCount -= instanceCount;
                              fFld += (float)var3;
                              var4 = 0;
                              switch ((int)(var10 % 9.0F * 5.0F + 63.0F)) {
                                 case 72:
                                 case 73:
                                 case 74:
                                 case 75:
                                 case 76:
                                 case 78:
                                 case 79:
                                 case 80:
                                 case 81:
                                 case 82:
                                 case 83:
                                 case 85:
                                 case 89:
                                 case 90:
                                 case 91:
                                 case 92:
                                 case 93:
                                 case 96:
                                 case 97:
                                 case 98:
                                 case 99:
                                 case 100:
                                 case 101:
                                 default:
                                    break;
                                 case 77:
                                    lArrFld[(int)var10] = (long)iFld1;
                                    break;
                                 case 84:
                                    var4 *= var13;
                                    break;
                                 case 86:
                                    var5 *= 214;
                                    break;
                                 case 87:
                                    var4 >>= 214;
                                    var3 >>= this.iFld;
                                    break;
                                 case 88:
                                    instanceCount -= var7;
                                 case 95:
                                    var5 += 66;
                                 case 71:
                                    instanceCount += (long)(var10 * (float)this.iFld);
                                    break;
                                 case 94:
                                    this.iFld = (int)((float)this.iFld + -81.0F + var10 * var10);
                                    break;
                                 case 102:
                                    var5 -= (int)instanceCount;
                                    iFld1 += (int)instanceCount;
                                    var3 += (int)var10;
                              }
                           }
                        }
                        break;
                     case 110:
                        instanceCount += (long)var13 ^ instanceCount;
                        this.iFld = 39826;
                        instanceCount *= (long)this.iFld;
                  }
               } else {
                  var6[var13 - 1] = (int)instanceCount;
               }
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 32608L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
