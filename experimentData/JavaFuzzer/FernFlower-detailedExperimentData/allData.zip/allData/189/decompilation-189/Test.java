public class Test {
   public static final int N = 400;
   public static long instanceCount = -6003932471390524530L;
   public static volatile int iFld = 24387;
   public short sFld = 30223;
   public static double[] dArrFld = new double[400];
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(int var0, int var1, long var2) {
      float var4 = -56.808F;
      float var5 = 113.39F;
      float var6 = 0.302F;
      float[] var7 = new float[400];
      boolean var8 = true;
      int var9 = -1;
      int var10 = -12116;
      int var11 = 26741;
      int var12 = 232;
      int var13 = 6;
      int[][] var14 = new int[400][400];
      double var15 = 0.5746;
      boolean var17 = true;
      byte var18 = -114;
      short var19 = -10182;
      short[][] var20 = new short[400][400];
      long[] var21 = new long[400];
      FuzzerUtils.init((int[][])var14, (int)-22);
      FuzzerUtils.init(var7, 0.294F);
      FuzzerUtils.init(var21, -2105289493L);
      FuzzerUtils.init((short[][])var20, (short)8806);
      var1 *= var0;
      var4 = 1.0F;

      int var28;
      do {
         instanceCount |= (long)var0;
         var28 = 1;

         do {
            int var10000;
            label122:
            switch (var28 * 5 + 51) {
               case 53:
                  if (var17) {
                     break;
                  }
               case 150:
                  var1 = (int)instanceCount;
                  break;
               case 59:
                  var5 = (float)var13;
                  break;
               case 68:
                  if (!var17) {
                     break;
                  }

                  var10 += var28 ^ var0;
                  var11 = 1;

                  while(true) {
                     --var11;
                     if (var11 <= 0) {
                        break label122;
                     }

                     var14[(int)var4][var11] >>= var0;
                     var0 = var11;
                     var7[var28] = 89.0F;
                     var21[(int)var4] -= (long)var1;
                  }
               case 74:
                  var12 = var11;
               case 62:
                  var13 ^= var28;
                  break;
               case 80:
                  var14[var28 + 1][var28 + 1] = 118;
                  break;
               case 81:
                  var13 += var28;
                  break;
               case 97:
                  var18 >>= (byte)var28;
                  break;
               case 99:
                  var5 += 2.0F;
                  break;
               case 101:
                  var9 = 1;

                  while(true) {
                     if (var9 >= 1) {
                        break label122;
                     }

                     var1 -= var0;
                     var15 -= (double)var2;
                     ++var9;
                  }
               case 108:
                  try {
                     var0 = 1636636196 / var14[var28 + 1][(int)var4];
                     var1 = var14[(int)(var4 + 1.0F)][(int)var4] % 1374888923;
                     var10 = var1 / var0;
                  } catch (ArithmeticException var26) {
                  }
               case 165:
                  var10 += var28;
               case 185:
                  instanceCount <<= var9;
                  break;
               case 121:
                  var2 -= (long)iFld;
                  break;
               case 154:
                  var12 = 2;
                  break;
               case 157:
                  var10 += var28;
                  break;
               case 167:
                  var21[(int)(var4 - 1.0F)] += (long)var4;
                  break;
               case 175:
               case 341:
                  var14[(var9 >>> 1) % 400] = var14[var28 - 1];
                  break;
               case 196:
                  instanceCount *= instanceCount;
               case 72:
                  var13 -= (int)var2;
                  break;
               case 198:
                  var12 += var28 * var28;
                  break;
               case 205:
                  var10 <<= var28;
               case 94:
                  dArrFld[(int)(var4 - 1.0F)] = (double)var13;
                  break;
               case 207:
                  instanceCount -= (long)var13;
                  break;
               case 210:
                  try {
                     var10000 = var10 / var0;
                     var14[var28][(int)var4] = var12 % -197;
                     var14[var28 - 1][(int)var4] = 85 % var12;
                  } catch (ArithmeticException var25) {
                  }
               case 251:
                  var13 = var10;
                  break;
               case 213:
                  var10000 = var1 + var10;
               case 380:
                  var1 = var19;
                  break;
               case 215:
                  var14[(int)var4][var28] ^= (int)var2;
               case 325:
                  var17 = var17;
               case 195:
                  var21[(int)(var4 + 1.0F)] *= (long)var0;
                  break;
               case 216:
                  var14[(int)(var4 - 1.0F)][var28 + 1] *= var28;
               case 247:
               case 321:
                  var5 += (float)instanceCount;
               case 270:
                  var5 = 18.0F;
               case 342:
                  if (var12 != 0) {
                  }
                  break;
               case 246:
                  var2 -= (long)var9;
                  break;
               case 263:
                  var12 = (int)((long)var12 + ((long)var28 | (long)var5));
                  break;
               case 267:
                  var0 -= 60;
               case 133:
                  var20[var28] = var20[(int)(var4 - 1.0F)];
               case 138:
                  var1 += var28;
               case 199:
                  var14[var28][(int)var4] = 2;
               case 151:
                  try {
                     var10 = var9 / var1;
                     var12 = var10 / var0;
                     var10 = var11 % -172;
                  } catch (ArithmeticException var27) {
                  }
               case 78:
                  var21[var28] |= (long)var28;
                  break;
               case 272:
                  var2 += (long)(var28 - var1);
               case 330:
                  var12 -= (int)instanceCount;
               case 308:
                  var0 += var28;
                  break;
               case 279:
                  var10 ^= var0;
               case 155:
                  var21[var28 + 1] = 68L;
                  break;
               case 283:
                  var12 *= var9;
                  break;
               case 302:
                  var14[var28 - 1][(int)(var4 - 1.0F)] -= (int)instanceCount;
                  break;
               case 316:
                  var14[var28 - 1][(int)(var4 + 1.0F)] *= var1;
                  break;
               case 328:
                  try {
                     var0 = 198 / var12;
                     var10 = '뻈' % var9;
                     var1 = var11 / var14[(int)var4][var28 + 1];
                  } catch (ArithmeticException var24) {
                  }
               case 305:
                  var1 += var10;
                  break;
               case 332:
                  instanceCount += (long)(var28 * var13) + instanceCount - var2;
                  break;
               case 334:
                  instanceCount += (long)(14 + var28 * var28);
                  break;
               case 340:
                  var13 += -63626 + var28 * var28;
                  break;
               case 356:
                  var1 += var28 * var28;
                  break;
               case 374:
                  var6 += (float)var28;
                  break;
               case 376:
                  var1 = (int)var2;
                  break;
               case 378:
                  dArrFld[(int)var4] = (double)var28;
               case 194:
                  var5 += 18.0F;
                  break;
               case 379:
                  instanceCount += (long)var4;
                  break;
               case 382:
               case 399:
                  var10 += var28 * var28;
               case 202:
                  var15 -= (double)var5;
                  break;
               case 390:
                  var10 = -160;
               case 315:
                  var1 &= var11;
            }

            ++var28;
         } while(var28 < 7);
      } while(++var4 < 215.0F);

      long var22 = (long)(var0 + var1) + var2 + (long)Float.floatToIntBits(var4) + (long)var28 + (long)var9 + (long)var10 + Double.doubleToLongBits(var15) + (long)var11 + (long)(var17 ? 1 : 0) + (long)var12 + (long)Float.floatToIntBits(var5) + (long)var18 + (long)var13 + (long)var19 + (long)Float.floatToIntBits(var6) + FuzzerUtils.checkSum(var14) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + FuzzerUtils.checkSum(var21) + FuzzerUtils.checkSum(var20);
      iMeth1_check_sum += var22;
      return (int)var22;
   }

   public static void vMeth(float var0) {
      int var1 = 202;
      boolean var2 = true;
      char var3 = '趟';
      var1 &= 3902;

      int var4;
      for(var4 = 5; 129 > var4; ++var4) {
         int var10000 = var1 + var4 * var4;
         var1 = (int)((long)iMeth1(var3, iFld, instanceCount) - instanceCount);
         var1 += iFld;
         iArrFld = FuzzerUtils.int1array(400, -17150);
         var0 += var0;
      }

      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1 + var4 + var3);
   }

   public static int iMeth() {
      boolean var0 = true;
      char var1 = '늧';
      int var2 = 12;
      int var3 = 63689;
      int var4 = -24749;
      int var5 = -201;
      int var6 = -11;
      byte var7 = -4;
      float var8 = 109.885F;
      double var9 = -6.56664;
      boolean var11 = false;
      long[][] var12 = new long[400][400];
      FuzzerUtils.init(var12, -467464507L);

      int var15;
      for(var15 = 10; var15 < 314; ++var15) {
         vMeth(var8);

         for(var2 = 1; var2 < 5; ++var2) {
            byte var13 = 18;
            var3 += -49100 + var2 * var2;
            iFld -= var2;
            iFld += var2;
            instanceCount >>= iFld;
            byte var16 = (byte)(var13 + (byte)(var2 + var15));
         }

         for(var4 = 1; var4 < 5; ++var4) {
            if (var3 != 0) {
            }

            for(var6 = 2; var6 > 1; --var6) {
               iFld += var6;
               var12[var4][var4] -= (long)var9;
               var5 = (int)instanceCount;
               if (var11) {
               }
            }
         }
      }

      long var17 = (long)(var15 + var1 + Float.floatToIntBits(var8) + var2 + var3 + var4 + var5 + var6 + var7) + Double.doubleToLongBits(var9) + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var12);
      iMeth_check_sum += var17;
      return (int)var17;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -26;
      int var4 = -9;
      int var5 = 143;
      int var6 = 245;
      int var7 = 222;
      int var8 = 8128;
      byte var9 = 108;
      float var10 = -1.847F;
      float[] var11 = new float[400];
      boolean var12 = true;
      FuzzerUtils.init(var11, 58.1F);

      int var15;
      for(var15 = 6; var15 < 274; ++var15) {
         switch (var15 % 3 * 5 + 34) {
            case 36:
               var10 = (float)var6;
            case 37:
            case 38:
            case 39:
            default:
               continue;
            case 40:
               var4 = 4;
         }

         while(var4 < 94) {
            var3 += iMeth();
            lArrFld[var15 + 1] = (long)var9;
            var10 -= 5.0F;
            var6 = 1;

            do {
               switch ((var7 >>> 1) % 10 + 116) {
                  case 116:
                     instanceCount += (long)var6;
                     this.sFld *= (short)var4;
                     var11[var15 - 1] -= (float)instanceCount;
                     var10 *= (float)var15;
                  case 117:
                     instanceCount = instanceCount;
                     break;
                  case 118:
                  case 119:
                     this.sFld += (short)(var6 + var3);
                     instanceCount -= (long)var9;
                     break;
                  case 120:
                     var7 -= (int)instanceCount;
                     iFld = var5;

                     try {
                        iArrFld[var6] = var7 % var7;
                        var3 = var15 / -77;
                        var7 = iArrFld[var6 - 1] % 27708;
                     } catch (ArithmeticException var14) {
                     }
                     break;
                  case 121:
                     instanceCount -= (long)var9;
                     var8 += var6 * iFld + var6 - var15;
                     if (var12) {
                        var8 += var8;
                     } else if (var12) {
                        iFld &= var4;
                        iArrFld[var15] = var15;
                     }

                     iFld -= (int)var10;
                  case 122:
                     var3 *= -211;
                     var7 += var7;
                     var5 = (int)instanceCount;
                     break;
                  case 123:
                     var10 += (float)var15;
                     long[] var10000 = lArrFld;
                     var10000[var4 + 1] *= -16444L;
                     break;
                  case 124:
                     if (var12) {
                     }
                     break;
                  case 125:
                     var7 -= 54;
                     break;
                  default:
                     int[] var16 = iArrFld;
                     var16[var6] += var15;
               }

               ++var6;
            } while(var6 < 2);

            ++var4;
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 by2 f5 = " + var5 + "," + var9 + "," + Float.floatToIntBits(var10));
      FuzzerUtils.out.println("i23 i24 i25 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("b2 fArr1 = " + (var12 ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
      FuzzerUtils.out.println("Test.dArrFld Test.iArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 0.82587);
      FuzzerUtils.init((int[])iArrFld, (int)-144);
      FuzzerUtils.init(lArrFld, -4183428435L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
