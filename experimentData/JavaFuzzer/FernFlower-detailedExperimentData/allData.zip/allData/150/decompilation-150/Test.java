public class Test {
   public static final int N = 400;
   public static long instanceCount = -44818L;
   public static boolean bFld = true;
   public static float fFld = 1.6F;
   public static short sFld = 13796;
   public static int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static volatile long[] lArrFld = new long[400];
   public double[] dArrFld = new double[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, int var1, long var2) {
      float var4;
      int var5;
      int var6;
      double var7;
      short var9;
      long[][][] var10;
      var4 = 0.462F;
      var5 = -6076;
      var6 = -3;
      var7 = 0.70422;
      var9 = -27677;
      var10 = new long[400][400][400];
      FuzzerUtils.init((Object[][])var10, -159L);
      var0 -= (int)var4;
      instanceCount = var2;
      var10[(var0 >>> 1) % 400][(var1 >>> 1) % 400][(var1 >>> 1) % 400] = (long)var4;
      label33:
      switch ((var0 >>> 1) % 7 * 5 + 72) {
         case 73:
            fArrFld[(var6 >>> 1) % 400] = (float)var9;
            break;
         case 74:
            var4 *= (float)var0;
            bFld = bFld;
            break;
         case 86:
            var7 *= (double)var4;
            break;
         case 94:
            var4 *= (float)var0;
            break;
         case 98:
            var5 = 365;

            while(true) {
               --var5;
               if (var5 <= 0) {
                  break label33;
               }

               iArrFld[var5] = var1;
               var6 = 1;

               do {
                  iArrFld = iArrFld;
                  ++var6;
               } while(var6 < 5);

               switch (var5 % 1 + 109) {
                  case 109:
                     var0 += var5;
                     instanceCount += var2;
                  default:
                     int[] var10000 = iArrFld;
                     var10000[var5] -= (int)var2;
                     if (var5 != 0) {
                        vMeth_check_sum += (long)(var0 + var1) + var2 + (long)Float.floatToIntBits(var4) + (long)var5 + (long)var6 + Double.doubleToLongBits(var7) + (long)var9 + FuzzerUtils.checkSum((Object[][])var10);
                        return;
                     }
               }
            }
         case 99:
            var1 -= 62014;
         case 89:
            var1 = (int)var4;
            break;
         default:
            var10[(var1 >>> 1) % 400][(var6 >>> 1) % 400][(var6 >>> 1) % 400] += (long)var6;
      }

      vMeth_check_sum += (long)(var0 + var1) + var2 + (long)Float.floatToIntBits(var4) + (long)var5 + (long)var6 + Double.doubleToLongBits(var7) + (long)var9 + FuzzerUtils.checkSum((Object[][])var10);
   }

   public static int iMeth1(int var0) {
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -137;
      boolean var4 = true;
      byte var5 = 8;
      int var6 = 1;
      char var7 = '\ue837';
      double var8 = -1.18361;
      double[] var10 = new double[400];
      float var11 = -2.967F;
      short var12 = -8378;
      long[] var13 = new long[400];
      FuzzerUtils.init(var10, 2.124942);
      FuzzerUtils.init(var13, 3202827185623507262L);
      int var16 = 1;

      while(true) {
         ++var16;
         if (var16 >= 132) {
            var10[(var0 >>> 1) % 400] -= (double)var0;
            instanceCount += instanceCount;

            int var17;
            for(var17 = 176; var17 > 7; --var17) {
               double var14 = 0.53432;
               double var10000 = var14 * (double)var17;
               var13[var17 - 1] = (long)var17;
            }

            var8 += (double)var3;
            var3 += var16;

            int var18;
            for(var18 = 258; var18 > 13; --var18) {
               for(var6 = 1; var6 < 7; ++var6) {
                  var11 += (float)(var6 * var7 + var12 - var18);
                  int[] var20 = iArrFld;
                  var20[var6 - 1] += var12;
               }

               var3 = (int)((long)var3 + ((long)var18 ^ instanceCount));
               var11 += (float)instanceCount;
            }

            long var19 = (long)(var0 + var16 + var17 + var3) + Double.doubleToLongBits(var8) + (long)var18 + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var11) + (long)var12 + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var13);
            iMeth1_check_sum += var19;
            return (int)var19;
         }

         vMeth(var0, var16, instanceCount);
      }
   }

   public int iMeth(int var1, int var2) {
      int var3 = -50211;
      int var4 = -1;
      int var5 = 13705;
      int var6 = 35010;
      int var7 = 0;
      var3 = 362;

      while(true) {
         --var3;
         if (var3 <= 0) {
            long var8 = (long)(var1 + var2 + var3 + var4 + var5 + var6 + var7);
            iMeth_check_sum += var8;
            return (int)var8;
         }

         label33:
         for(var4 = 1; var4 < 5; ++var4) {
            switch ((var5 >>> 1) % 6 + 13) {
               case 13:
                  int[] var10 = iArrFld;
                  var10[var3 - 1] -= iMeth1(var4);
                  long[] var11 = lArrFld;
                  var11[var3 - 1] >>= (int)instanceCount;
                  var5 = (int)((long)var5 + ((long)(var4 * var4) + instanceCount - instanceCount));
                  var6 = 1;

                  while(true) {
                     if (var6 >= 2) {
                        continue label33;
                     }

                     var7 ^= var7;
                     instanceCount += (long)(-67 + var6 * var6);
                     iArrFld[var6 + 1] = var4;
                     var1 += var6;
                     var2 += var3;
                     ++var6;
                  }
               case 14:
                  var1 += 60;
                  break;
               case 15:
                  var7 >>= var4;
               case 16:
                  instanceCount += 253L;
                  break;
               case 17:
                  double[] var10000 = this.dArrFld;
                  var10000[var3 - 1] += (double)var2;
                  break;
               case 18:
                  instanceCount = (long)var5;
            }
         }
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -10916;
      int var4 = -1;
      int var5 = -113;
      int var6 = -40603;
      int var7 = 59160;
      byte var8 = 123;
      int var9 = -118;
      int var10 = 35168;
      int[] var11 = new int[400];
      double var12 = 0.57251;
      byte var14 = -52;
      boolean[] var15 = new boolean[400];
      FuzzerUtils.init((int[])var11, (int)-63);
      FuzzerUtils.init(var15, true);

      int var16;
      int[] var10000;
      for(var16 = 7; var16 < 341; ++var16) {
         instanceCount += (long)(var16 * var16);
         var3 += var16 - var3;
         var11 = FuzzerUtils.int1array(400, -29189);

         for(var4 = var16; var4 < 75; var4 += 2) {
            var3 = this.iMeth(var16, var5);
            var5 /= var3 | 1;
            var12 += 4.0;
            fFld += (float)var4;
            var10000 = iArrFld;
            var10000[var16] -= var4;
         }
      }

      var6 = 1;

      do {
         instanceCount = instanceCount;
         var15[var6] = bFld;
         instanceCount = (long)var4;
         var3 += var3;
         fFld = (float)var12;
         sFld = (short)((int)instanceCount);
         var14 -= (byte)((int)instanceCount);
         ++var6;
      } while(var6 < 325);

      for(var7 = 3; 122 > var7; ++var7) {
         fFld += (float)var7 * fFld + (float)var5 - (float)var5;
         fFld = (float)var5;
         var3 = var7;
         var5 = var8;

         for(var9 = var7; var9 < 211; ++var9) {
            iArrFld[var7] = var8;
            var10 = (int)((float)var10 + ((float)(var9 * var9 + var7) - fFld));
            var10000 = iArrFld;
            var10000[var7 + 1] -= var5;
            instanceCount = (long)var10;
            instanceCount -= instanceCount;
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var16 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 d3 i24 = " + var5 + "," + Double.doubleToLongBits(var12) + "," + var6);
      FuzzerUtils.out.println("by i25 i26 = " + var14 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i27 i28 iArr = " + var9 + "," + var10 + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.sFld Test.iArrFld Test.fArrFld = " + sFld + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("Test.lArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-22462);
      FuzzerUtils.init(fArrFld, 0.5F);
      FuzzerUtils.init(lArrFld, -26182552L);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
