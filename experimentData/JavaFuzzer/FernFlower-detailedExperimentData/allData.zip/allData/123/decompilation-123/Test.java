public class Test {
   public static final int N = 400;
   public static long instanceCount = -58487L;
   public static short sFld = -24700;
   public static long[] lArrFld = new long[400];
   public volatile double[][][] dArrFld = new double[400][400][400];
   public int[] iArrFld = new int[400];
   public long[][] lArrFld1 = new long[400][400];
   public int[][] iArrFld1 = new int[400][400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth() {
      boolean var0 = true;
      int var1 = 10;
      int var2 = -11;
      short var3 = 247;
      int var4 = -15555;
      byte var5 = -3;
      int[] var6 = new int[400];
      float var7 = -33.896F;
      float var8 = -2.34F;
      double var9 = -96.20907;
      byte var11 = 25;
      FuzzerUtils.init((int[])var6, (int)57874);
      int var14 = 1;

      do {
         label36:
         for(var7 = (float)var14; var7 < 5.0F; ++var7) {
            var1 += (int)var7;
            var6[(int)(var7 + 1.0F)] = (int)var9;
            switch ((var1 >>> 1) % 2 * 5 + 111) {
               case 113:
                  for(var4 = (int)var7; var4 < 1; ++var4) {
                     instanceCount = (long)var4;
                     var11 += (byte)((int)((float)var4 * var7 + (float)instanceCount - (float)var14));
                  }

                  var6[(int)(var7 - 1.0F)] >>= var14;
                  break;
               case 120:
                  var9 = 46531.0;
                  var8 += (float)var14;
                  var2 = 1;

                  while(true) {
                     if (var2 >= 1) {
                        continue label36;
                     }

                     instanceCount -= (long)var1;
                     var8 += (float)var2;
                     instanceCount += (long)var1;
                     ++var2;
                  }
               default:
                  var1 = var5;
            }
         }

         ++var14;
      } while(var14 < 341);

      long var12 = (long)(var14 + Float.floatToIntBits(var7) + var1) + Double.doubleToLongBits(var9) + (long)Float.floatToIntBits(var8) + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)var11 + FuzzerUtils.checkSum(var6);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public static void vMeth1(int var0, int var1) {
      short var2 = -6437;
      float var3 = 66.929F;
      long[] var10000 = lArrFld;
      var10000[91] >>= Math.min(80 + var2, (int)(var3 - (float)var0)) - (iMeth() - var1);
      vMeth1_check_sum += (long)(var0 + var1 + var2 + Float.floatToIntBits(var3));
   }

   public static void vMeth(int var0, int var1, long var2) {
      boolean var4 = true;
      int var5 = 48;
      int var6 = 1;
      int var7 = -1;
      int var8 = 26099;
      int var9 = 11588;
      int[][] var10 = new int[400][400];
      long var11 = 2074981987686830504L;
      double var13 = 0.1631;
      byte var15 = 104;
      byte[] var16 = new byte[400];
      float[] var17 = new float[400];
      FuzzerUtils.init((int[][])var10, (int)1);
      FuzzerUtils.init(var17, -1.738F);
      FuzzerUtils.init((byte[])var16, (byte)0);

      int var22;
      for(var22 = 268; var22 > 4; var22 -= 3) {
         label96: {
            switch (var22 % 9 + 76) {
               case 76:
                  for(var6 = 1; var6 < 18; ++var6) {
                     for(var11 = 1L; 2L > var11; ++var11) {
                        var13 += (double)var2;
                        int[] var10000 = var10[var6 + 1];
                        int var10001 = (int)(var11 - 1L);
                        int var10002 = var10000[(int)(var11 - 1L)];
                        int[] var10003 = var10[var6 + 1];
                        int var10004 = var22 - 1;
                        int var10006 = var10003[var22 - 1];
                        var10003[var10004] = var10003[var22 - 1] - 1;
                        var10000[var10001] = var10002 - (int)((long)var10006 - lArrFld[var22]);
                        vMeth1(var1, -99);
                     }

                     var2 = -3L;
                     var9 = 1;

                     do {
                        byte var18 = -70;
                        var17[var6 + 1] = (float)var6;

                        try {
                           var0 = var10[var22 + 1][var6] % var1;
                           var7 = -58704 / var22;
                           var5 = var1 % -1235870547;
                        } catch (ArithmeticException var21) {
                        }

                        var18 += (byte)var9;
                        var13 = (double)var6;
                        ++var9;
                     } while(var9 < 2);

                     var16 = var16;
                     var10[var22 + 1][var6 - 1] >>= var7;
                  }
               case 77:
                  try {
                     var0 = var10[var22][var22 + 1] % var10[var22 - 1][var22 - 1];
                     var8 = -20843 % var8;
                     var5 = -21 % var1;
                  } catch (ArithmeticException var20) {
                  }
               case 78:
                  break label96;
               case 79:
                  var10[var22][var22] = var1;
               case 80:
                  break;
               case 81:
                  var5 += var22 * var0 + var7 - var9;
                  continue;
               case 82:
                  var5 = var6;
                  continue;
               case 83:
                  var1 -= var8;
               case 84:
               default:
                  continue;
            }

            var2 = (long)var9;
            continue;
         }

         var8 = var15;
      }

      vMeth_check_sum += (long)(var0 + var1) + var2 + (long)var22 + (long)var5 + (long)var6 + (long)var7 + var11 + (long)var8 + Double.doubleToLongBits(var13) + (long)var9 + (long)var15 + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var17)) + FuzzerUtils.checkSum(var16);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 18415;
      int var4 = 11;
      int var5 = 4;
      int var6 = -254;
      int var7 = -156;
      int var8 = 4;
      int var9 = 6;
      int var10 = 11;
      boolean var11 = false;
      boolean[] var12 = new boolean[400];
      double var13 = 28.15279;
      double var15 = -1.104601;
      double var17 = 1.65179;
      float var19 = -65.49F;
      FuzzerUtils.init(var12, true);

      int var20;
      label113:
      for(var20 = 10; 304 > var20; ++var20) {
         vMeth(var3, var3, instanceCount);
         if (!var11) {
            for(var13 = 86.0; var13 > (double)var20; var13 -= 2.0) {
               for(var5 = 1; var5 < 1; ++var5) {
                  instanceCount *= -1L;
                  var4 *= var3;
               }

               var7 = 1;

               while(true) {
                  var7 += 3;
                  if (var7 >= 1) {
                     break;
                  }

                  this.dArrFld[var20 + 1][var20][42] = (double)var3;
                  var12[var20] = var11;
                  this.dArrFld[var7 + 1][var20 + 1] = this.dArrFld[var7][var20];
               }
            }

            var8 = 86;

            while(true) {
               while(true) {
                  var8 -= 3;
                  if (var8 <= 0) {
                     continue label113;
                  }

                  label89: {
                     label129: {
                        label86: {
                           var6 |= var3;
                           sFld += (short)(var8 + var4);
                           instanceCount ^= (long)var20;
                           switch (var8 % 9 * 5 + 44) {
                              case 55:
                              case 56:
                              case 57:
                              case 58:
                              case 59:
                              case 60:
                              case 61:
                              case 62:
                              case 63:
                              case 64:
                              case 65:
                              case 66:
                              case 67:
                              case 71:
                              case 73:
                              case 74:
                              case 76:
                              case 77:
                              case 78:
                              case 81:
                              case 82:
                              default:
                                 break label129;
                              case 68:
                                 break label89;
                              case 69:
                              case 70:
                                 instanceCount *= 3801956899L;
                                 break label129;
                              case 75:
                                 if (var11) {
                                    continue;
                                 }
                              case 54:
                                 var6 ^= -136;
                                 var6 = var4;

                                 for(var15 = (double)var20; var15 < 3.0; ++var15) {
                                    var10 += (int)(var15 * var15);
                                    var10 += (int)var15;
                                    switch (var20 % 7 + 12) {
                                       case 12:
                                          if (!var11) {
                                             var4 += (int)(var15 * var15);
                                             var3 = var4;
                                             var10 += (int)(var15 + (double)instanceCount);
                                          }
                                          break;
                                       case 13:
                                          var4 *= var4;
                                          int[] var21 = this.iArrFld;
                                          var21[var8 + 1] >>= var6;
                                          instanceCount += (long)var15;
                                          break;
                                       case 14:
                                          var19 += (float)var7;
                                          break;
                                       case 15:
                                          var17 -= -12.0;
                                          break;
                                       case 16:
                                          long[] var10000 = lArrFld;
                                          var10000[var20] <<= (int)instanceCount;
                                          break;
                                       case 17:
                                          this.lArrFld1 = FuzzerUtils.long2array(400, -127L);
                                       case 18:
                                          var3 += (int)(var15 * (double)var20 + (double)sFld - (double)var10);
                                    }
                                 }
                              case 72:
                                 this.iArrFld1 = this.iArrFld1;
                                 break;
                              case 79:
                                 break label86;
                              case 80:
                                 var6 -= 1502486984;
                                 continue;
                              case 83:
                           }

                           var6 = -55;
                        }

                        var9 = (int)((float)var9 + ((float)((long)var8 * instanceCount) + var19 - (float)var10));
                        break label89;
                     }

                     instanceCount <<= (int)instanceCount;
                     continue;
                  }

                  var3 = (int)var19;
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 b = " + var20 + "," + var3 + "," + (var11 ? 1 : 0));
      FuzzerUtils.out.println("d2 i18 i19 = " + Double.doubleToLongBits(var13) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i20 i21 i22 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("d3 i23 i24 = " + Double.doubleToLongBits(var15) + "," + var9 + "," + var10);
      FuzzerUtils.out.println("f3 d4 bArr = " + Float.floatToIntBits(var19) + "," + Double.doubleToLongBits(var17) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.lArrFld = " + instanceCount + "," + sFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("dArrFld iArrFld lArrFld1 = " + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])this.dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld1));
      FuzzerUtils.out.println("iArrFld1 = " + FuzzerUtils.checkSum(this.iArrFld1));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -7L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
