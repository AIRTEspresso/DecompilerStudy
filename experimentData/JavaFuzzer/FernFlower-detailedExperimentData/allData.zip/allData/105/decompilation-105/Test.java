public class Test {
   public static final int N = 400;
   public static long instanceCount = -2384593840L;
   public int iFld = 5;
   public static float fFld = -1.614F;
   public static boolean bFld = true;
   public static short sFld = 17155;
   public double dFld = 22.101494;
   public int iFld1 = -57;
   public long[] lArrFld = new long[400];
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long vMeth2_check_sum = 0L;

   public static void vMeth2() {
      boolean var0 = true;
      int var1 = 203;
      int var2 = -10;
      int var3 = 10839;
      int var4 = -84;
      int var5 = -146;
      byte var6 = -57;
      double var7 = -61.91178;

      int var9;
      for(var9 = 3; var9 < 123; ++var9) {
         if (var1 != 0) {
            vMeth2_check_sum += (long)(var9 + var1 + var2 + var3 + var6 + var4 + var5) + Double.doubleToLongBits(var7);
            return;
         }

         var1 &= var1;

         for(var2 = 1; var2 < 13 && !bFld; ++var2) {
            var1 = var6;
            var3 += var3;
            if (bFld) {
               for(var4 = 1; var4 < 2; ++var4) {
                  var1 = var1;
                  var3 += var4 * var4;
                  var6 = (byte)((int)instanceCount);
                  var5 += var4;
               }
            } else {
               var1 = var6 + (var2 | var3);
               var3 = (int)var7;
            }
         }
      }

      vMeth2_check_sum += (long)(var9 + var1 + var2 + var3 + var6 + var4 + var5) + Double.doubleToLongBits(var7);
   }

   public static void vMeth1(long var0) {
      long var2 = -2613817603206054323L;
      long var4 = -6428L;
      int var6 = 9;
      int var7 = -229;
      int var8 = -64427;
      short[] var9 = new short[400];
      FuzzerUtils.init(var9, (short)-1223);
      fFld = (float)(var2++);

      for(var4 = 2L; var4 < 343L; ++var4) {
         var6 = (int)((long)var6 + -54L + var4 * var4);
         vMeth2();

         for(var7 = 1; var7 < 5; ++var7) {
            var6 = (int)fFld;
            var8 -= 1602019451;
            var8 <<= -48160;
            bFld = bFld;
            var6 *= -2;
            var9[(int)(var4 + 1L)] += -17462;
            var8 >>>= var6;
            var6 >>= var6;
            var6 = (int)((float)var6 + ((float)(var7 * var6 + var6) - fFld));
            var8 %= -40;
         }
      }

      vMeth1_check_sum += var0 + var2 + var4 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
   }

   public static void vMeth() {
      int var0 = 48880;
      int var1 = 37416;
      int var2 = -40901;
      int[] var3 = new int[400];
      byte var4 = 85;
      FuzzerUtils.init((int[])var3, (int)1);
      var0 = 1;

      do {
         for(var1 = 14; var1 > 1; --var1) {
            float var5 = -16.463F;
            float var10000 = var5 - (float)var2;
            vMeth1(instanceCount);
            fFld += (float)((long)var1 * instanceCount + instanceCount - (long)var0);
            var2 *= var4;
            var2 += var1;
            var2 += (int)instanceCount;
            var2 -= var4;
            var2 += var1;
            instanceCount = (long)var0;
         }

         instanceCount += (long)(-211 + var0 * var0);
         var3[var0] *= sFld;
         var3 = var3;
         var2 *= 32427;
         var0 += 2;
      } while(var0 < 216);

      vMeth_check_sum += (long)(var0 + var1 + var2 + var4) + FuzzerUtils.checkSum(var3);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -56001;
      int var4 = 0;
      int var5 = -14;
      int var6 = -36414;
      short var7 = 133;
      int var8 = 15540;
      int var9 = -4;
      int[] var10 = new int[400];
      float var11 = -53.503F;
      FuzzerUtils.init((int[])var10, (int)-112);
      this.iFld -= -19;
      int var14 = 379;

      while(true) {
         --var14;
         long[] var10000;
         if (var14 <= 0) {
            var10000 = this.lArrFld;
            var10000[(var14 >>> 1) % 400] += -188L;
            this.iFld <<= (int)instanceCount;
            var4 -= var4;
            instanceCount += (long)this.iFld;
            var6 = 1;

            while(true) {
               ++var6;
               if (var6 >= 285) {
                  try {
                     for(var11 = 3.0F; var11 < 188.0F; ++var11) {
                        var4 <<= -30083;

                        for(var8 = (int)var11; var8 < 136; ++var8) {
                           var9 += var9;
                           this.iFld1 = (int)((float)this.iFld1 + (float)var8 + fFld);
                        }
                     }
                  } catch (ArithmeticException var13) {
                     var9 <<= 7;
                  }

                  FuzzerUtils.out.println("i i1 i2 = " + var14 + "," + var3 + "," + var4);
                  FuzzerUtils.out.println("i15 i16 f1 = " + var5 + "," + var6 + "," + Float.floatToIntBits(var11));
                  FuzzerUtils.out.println("i17 i18 i19 = " + var7 + "," + var8 + "," + var9);
                  FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(var10));
                  FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
                  FuzzerUtils.out.println("Test.bFld Test.sFld dFld = " + (bFld ? 1 : 0) + "," + sFld + "," + Double.doubleToLongBits(this.dFld));
                  FuzzerUtils.out.println("iFld1 lArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(this.lArrFld));
                  FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                  FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                  FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                  return;
               }

               var4 += var6;
               var4 <<= -4;
            }
         }

         for(var3 = var14; var3 < 66; ++var3) {
            var10000 = this.lArrFld;
            var10000[var14] >>= var3;
            vMeth();
            this.iFld *= (int)fFld;
            var5 = 1;

            do {
               var10[var5 + 1] = (int)this.dFld;
               var4 = (int)instanceCount;
               this.iFld = this.iFld;
               var5 += 3;
            } while(var5 < 1);

            var4 = (int)instanceCount;
            bFld = true;
            var4 *= (int)instanceCount;
            this.dFld -= (double)var14;
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
