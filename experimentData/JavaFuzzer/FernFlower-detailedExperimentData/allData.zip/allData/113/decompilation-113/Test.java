public class Test {
   public static final int N = 400;
   public static long instanceCount = 827199520796677453L;
   public static int iFld = -56638;
   public static double[][] dArrFld = new double[400][400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, float var1, boolean var2) {
      boolean var3 = true;
      int var4 = -175;
      int var5 = 222;
      int var6 = 44;
      int[] var7 = new int[400];
      double var8 = -1.58659;
      float[] var10 = new float[400];
      FuzzerUtils.init((int[])var7, (int)-225);
      FuzzerUtils.init(var10, -22.102F);
      int var13 = 1;

      while(true) {
         while(true) {
            label43:
            while(true) {
               ++var13;
               if (var13 >= 350) {
                  vMeth1_check_sum += (long)(var0 + Float.floatToIntBits(var1) + (var2 ? 1 : 0) + var13 + var4 + var5 + var6) + Double.doubleToLongBits(var8) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
                  return;
               }

               switch (var13 % 2 + 45) {
                  case 45:
                     iFld += var0;

                     try {
                        iFld = var13 % 4694;
                        var0 = var13 / var13;
                        var7[var13 + 1] = iFld / var0;
                     } catch (ArithmeticException var12) {
                     }
                  case 46:
                     break label43;
               }
            }

            if (var2) {
               var10[var13 - 1] = (float)var0;
            } else {
               switch (var13 % 3 + 10) {
                  case 10:
                  case 11:
                     for(var4 = var13; var4 < 5; ++var4) {
                        instanceCount += (long)(var4 * iFld + var5 - iFld);
                        switch (var13 % 1 * 5 + 30) {
                           case 34:
                           default:
                              iFld -= var4;
                              var6 = 1;
                        }

                        while(true) {
                           ++var6;
                           if (var6 >= 1) {
                              break;
                           }

                           iFld += (int)var8;
                           iFld = (int)instanceCount;
                           var1 *= (float)var6;
                        }
                     }
                  case 12:
                     var7[var13] *= var5;
                     break;
                  default:
                     var5 += var5;
               }
            }
         }
      }
   }

   public static void vMeth(int var0) {
      double var1 = 2.2807;
      short var3 = 18468;
      boolean var4 = true;
      int var5 = -9;
      int var6 = 140;
      int var7 = 4;
      short var8 = -144;
      boolean var9 = true;
      float var10 = -9.649F;
      long[] var11 = new long[400];
      FuzzerUtils.init(var11, 74L);
      ++var3;
      var1 = (double)var3;

      int var12;
      for(var12 = 121; var12 > 7; --var12) {
         vMeth1(var0, 0.676F, var9);
         var0 = (int)((long)var0 + ((long)var12 ^ (long)var10));
         switch (var12 % 4 + 12) {
            case 12:
               var1 += (double)var5;
               var5 += var12;
               break;
            case 13:
               var10 += -5.0F;
               if (var9) {
               }
               break;
            case 14:
               instanceCount = 13L;
               var6 = 1;

               do {
                  for(var7 = 1; var7 < 1; ++var7) {
                     var11[var7 + 1] = (long)var5;
                     var1 += -171.0;
                     iFld <<= (int)instanceCount;
                  }

                  ++var6;
               } while(var6 < 14);
               break;
            case 15:
               instanceCount += (long)(var12 * iFld);
         }
      }

      vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var12 + (long)var5 + (long)(var9 ? 1 : 0) + (long)Float.floatToIntBits(var10) + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var11);
   }

   public static int iMeth() {
      double var0 = -76.35665;
      int var2 = -184;
      int var3 = 2;
      int var4 = 14778;
      int[] var5 = new int[400];
      boolean var6 = true;
      float var7 = 0.816F;
      long[] var8 = new long[400];
      FuzzerUtils.init(var8, -8L);
      FuzzerUtils.init((int[])var5, (int)146);
      vMeth(iFld);
      dArrFld = dArrFld;

      for(var0 = 10.0; var0 < 228.0 && !var6; ++var0) {
         var7 = (float)instanceCount;
         var3 = 1;

         do {
            var8[(int)var0] = -57974L;
            label42:
            switch ((int)(var0 % 4.0 + 124.0)) {
               case 124:
                  if (var2 != 0) {
                  }

                  var4 = 1;

                  while(true) {
                     switch (var4 % 1 + 22) {
                        case 22:
                           var2 = (int)instanceCount;
                           var2 = (int)var7;
                           var2 = (int)instanceCount;
                           break;
                        default:
                           var7 *= (float)var3;
                     }

                     --var4;
                     if (var4 <= 0) {
                        break label42;
                     }
                  }
               case 125:
                  iFld = (int)((long)iFld + ((long)(var3 * var2 + iFld) - instanceCount));
                  break;
               case 126:
                  iFld -= iFld;
                  break;
               case 127:
                  var5[(int)var0] -= iFld;
            }

            ++var3;
         } while(var3 < 7);
      }

      long var9 = Double.doubleToLongBits(var0) + (long)var2 + (long)(var6 ? 1 : 0) + (long)Float.floatToIntBits(var7) + (long)var3 + (long)var4 + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void mainTest(String[] var1) {
      short var2 = -238;
      int[] var3 = new int[400];
      FuzzerUtils.init(var3, -63462);
      var3[(var2 >>> 1) % 400] ^= iMeth();
      FuzzerUtils.out.println("i iArr = " + var2 + "," + FuzzerUtils.checkSum(var3));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dArrFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, -49.68167);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
