public class Test {
   public static final int N = 400;
   public static long instanceCount = -694741276L;
   public static long lFld = 0L;
   public static double dFld = -2.653;
   public static float fFld = -95.279F;
   public short sFld = -16283;
   public static long[] lArrFld = new long[400];
   public int[][] iArrFld = new int[400][400];
   public float[] fArrFld = new float[400];
   public static long bMeth_check_sum;
   public static long fMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 7;
      int var5 = 9;
      int var6 = 47618;
      short var7 = -214;
      boolean var8 = true;
      int var9 = -14341;
      int var10 = 9;
      int[] var11 = new int[400];
      FuzzerUtils.init((int[])var11, (int)-18228);
      var0 -= var1;

      int var15;
      for(var15 = 7; var15 < 140; ++var15) {
         var5 = 1;

         while(true) {
            ++var5;
            if (var5 >= 12) {
               break;
            }

            var2 += 14;

            for(var6 = 1; var6 < 1; ++var6) {
               var11[var6] *= var5;
               var0 = var4;
               lFld = 135L;
               fFld = fFld;
            }
         }
      }

      int var16;
      for(var16 = 16; var16 < 385; ++var16) {
         boolean var12 = true;
         instanceCount = lFld;
         var11 = var11;
         if (var12) {
            var11[var16] += var6;
         } else if (var12) {
            var2 >>= var15;
         } else if (var12) {
            var4 += (int)(44073L + (long)(var16 * var16));
         } else {
            try {
               var2 = var4 % var11[var16];
               var10 = -52308 % var2;
               var9 /= var11[var16];
            } catch (ArithmeticException var14) {
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var15 + var4 + var5 + var6 + var7 + var16 + var9 + var10) + FuzzerUtils.checkSum(var11);
   }

   public static float fMeth() {
      float var0 = 32.17F;
      int var1 = 8;
      boolean var2 = true;
      int var3 = -5;
      int var4 = -110;
      int var5 = 4;
      int[] var6 = new int[400];
      boolean var7 = false;
      double var8 = 0.94521;
      short[][][] var10 = new short[400][400][400];
      FuzzerUtils.init((int[])var6, (int)-18037);
      FuzzerUtils.init((Object[][])var10, -17943);
      var0 = (float)(lFld++);
      int var10000 = var1;
      short var10001 = Short.reverseBytes((short)9910);
      ++var1;
      var1 = var10000 * (int)(dFld = (double)(var10001 - var1));
      vMeth(var1, var1, -2923);
      long[] var14 = lArrFld;
      var14[(var1 >>> 1) % 400] <<= (int)instanceCount;
      lFld = (long)var1;

      int var13;
      for(var13 = 14; 313 > var13; ++var13) {
         var3 /= (int)((long)fFld | 1L);
         if (var7) {
            break;
         }

         for(var8 = (double)var13; var8 < 6.0; ++var8) {
            var6[var13 + 1] = var4;
            var5 = 1;

            do {
               var0 = -7.0F;
               var4 += var4;
               var6[var5] -= var4;
               var10[var5 + 1][var5 - 1][(int)(var8 + 1.0)] *= (short)((int)fFld);
               ++var5;
            } while(var5 < 1);
         }
      }

      long var11 = (long)(Float.floatToIntBits(var0) + var1 + var13 + var3 + (var7 ? 1 : 0)) + Double.doubleToLongBits(var8) + (long)var4 + (long)var5 + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum((Object[][])var10);
      fMeth_check_sum += var11;
      return (float)var11;
   }

   public static boolean bMeth(float var0) {
      boolean var1 = true;
      int var2 = 60;
      boolean var3 = false;
      int var4 = 11418;
      int[] var5 = new int[400];
      FuzzerUtils.init((int[])var5, (int)-32364);
      var1 = true;
      long[] var10000 = lArrFld;
      var10000[(var2 >>> 1) % 400] <<= (int)(-(instanceCount + lFld));
      int var8 = 3;

      while(var8 < 146) {
         var5[var8] = (int)instanceCount;
         switch (var8 % 1 + 119) {
            case 119:
               instanceCount = (lFld << var4 << (int)((long)((float)var4 + 0.82F))) - (long)(-(var2 + var4));
            default:
               ++var8;
         }
      }

      float var9 = (float)(151L + (long)(var8 - var4)) - (var0 + (float)var4);
      --var4;
      int var10 = (int)(var9 + (float)var4);
      var2 = (int)((float)(--instanceCount) + (-fMeth() - 52843.0F));
      var5[(var4 >>> 1) % 400] = var8;
      fFld *= -248.0F;
      long var6 = (long)(Float.floatToIntBits(var0) + (var1 ? 1 : 0) + var2 + var8 + var4) + FuzzerUtils.checkSum(var5);
      bMeth_check_sum += var6;
      return var6 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 22319;
      int var4 = -34790;
      int var5 = -4;
      int var6 = -7;
      int var7 = -222;
      boolean var8 = false;
      byte var9 = -60;
      float var10 = -41.53F;

      int var13;
      for(var13 = 5; 298 > var13 && !(var8 = bMeth(fFld)); ++var13) {
         lFld += (long)(var13 * var9 + var13) - lFld;
         if (var8) {
            break;
         }

         fFld *= (float)var3;
         this.sFld = (short)var3;

         for(var4 = 5; var4 < 86; ++var4) {
            var5 += var4 ^ var4;

            for(var6 = 2; var6 > 1; --var6) {
               instanceCount -= instanceCount;

               try {
                  var3 = 26462 % var5;
                  this.iArrFld[var6 + 1][var6] = 15502 % var5;
                  var3 = -178 % this.iArrFld[var4][var13 - 1];
               } catch (ArithmeticException var12) {
               }

               lFld += 50L;
               this.iArrFld[(var7 >>> 1) % 400] = FuzzerUtils.int1array(400, 12);
               int[] var10000 = this.iArrFld[var13 + 1];
               var10000[var4] |= var6;
               var7 = var9;
               if (var8) {
                  var3 += var6 ^ var4;
               }

               var5 = var9;
               switch (var4 % 3 * 5 + 73) {
                  case 74:
                     var3 = this.sFld;
                     float[] var14 = this.fArrFld;
                     var14[var6] += (float)var13;
                     lFld += (long)var3;
                     break;
                  case 75:
                     var7 = var9 + var6;
                     var10 += (float)var9;
                  case 76:
                  case 77:
                  default:
                     break;
                  case 78:
                     instanceCount += (long)(var6 * var4 + var4 - var9);
               }

               var10 *= (float)var9;
            }

            var3 += 107;
            var3 -= var4;
            dFld = (double)lFld;
         }
      }

      FuzzerUtils.out.println("i i1 b = " + var13 + "," + var3 + "," + (var8 ? 1 : 0));
      FuzzerUtils.out.println("by i21 i22 = " + var9 + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i23 i24 f2 = " + var6 + "," + var7 + "," + Float.floatToIntBits(var10));
      FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.dFld = " + instanceCount + "," + lFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.fFld sFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("iArrFld fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 45L);
      bMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
