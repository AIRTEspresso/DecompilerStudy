public class Test {
   public static final int N = 400;
   public static long instanceCount = 4L;
   public float[] fArrFld = new float[400];
   public static long lMeth_check_sum = 0L;
   public static long dMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;

   public static void vMeth(int var0, int var1) {
      boolean var2 = true;
      int var3 = -165;
      int var4 = 102;
      short var5 = 227;
      short var6 = 9076;
      byte var7 = -109;
      int[] var8 = new int[400];
      float var9 = -86.678F;
      float[] var10 = new float[400];
      long var11 = -5L;
      long[] var13 = new long[400];
      boolean var14 = false;
      FuzzerUtils.init(var13, 4319310807116406889L);
      FuzzerUtils.init(var10, 87.964F);
      FuzzerUtils.init((int[])var8, (int)-6);

      int var15;
      for(var15 = 17; var15 < 283; ++var15) {
         var13[var15 - 1] = (long)var3;
         var1 += var15 * var0 + var1 - var15;
         var3 += (int)instanceCount;
         instanceCount += (long)var9;

         for(var4 = 1; var4 < 6; ++var4) {
            for(var11 = 1L; var11 < 2L; ++var11) {
               var8[(int)var11] *= var5;
               int var10000 = var1 + (int)(var11 + (long)var6);
               var1 = (int)var9;
               var14 = false;
               var1 += (int)(var11 * (long)var1 + (long)var3 - (long)var7);
               instanceCount = -3955237631L;
               var3 += (int)(var11 | (long)var9);
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var15 + var3 + Float.floatToIntBits(var9) + var4 + var5) + var11 + (long)var6 + (long)(var14 ? 1 : 0) + (long)var7 + FuzzerUtils.checkSum(var13) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var8);
   }

   public static double dMeth(int var0, float var1) {
      boolean var2 = true;
      int var3 = -185;
      byte var4 = -14;
      int var5 = 65202;
      int var6 = -12;
      int[] var7 = new int[400];
      byte var8 = 97;
      FuzzerUtils.init(var7, -60316);
      vMeth(var0, var0);
      var7[(var0 >>> 1) % 400] >>>= -14;
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 275) {
            long var13 = (long)(var0 + Float.floatToIntBits(var1) + var12 + var3 + var4 + var5 + var6 + var8) + FuzzerUtils.checkSum(var7);
            dMeth_check_sum += var13;
            return (double)var13;
         }

         for(var3 = 1; 6 > var3; ++var3) {
            for(var5 = var3; var5 < 2; ++var5) {
               boolean var9 = false;
               long var10 = -1907497295189160996L;
               var0 <<= (int)instanceCount;
               if (var9) {
                  var0 -= 27902;
                  var1 *= -24772.0F;
                  var1 = (float)var3;
               } else if (var9) {
                  instanceCount += (long)var5;
               }

               switch (var5 % 7 * 5 + 60) {
                  case 66:
                     var7[var5 + 1] = var8;
                     break;
                  case 67:
                     instanceCount >>= var5;
                     break;
                  case 78:
                     var8 += (byte)((int)((long)(var5 * var8 + var4) - instanceCount));
                     break;
                  case 83:
                     var6 -= var12;
                  case 74:
                     var8 = 39;
                  case 92:
                     var10 += 90L;
                     break;
                  case 86:
                     var7 = var7;
                     var0 += var5 * var5;
                     var0 -= var0;
               }
            }
         }
      }
   }

   public long lMeth(int var1) {
      float var2 = 20.951F;
      dMeth(var1, var2);
      instanceCount = 0L;
      this.fArrFld = this.fArrFld;
      long var3 = (long)(var1 + Float.floatToIntBits(var2));
      lMeth_check_sum += var3;
      return var3;
   }

   public void mainTest(String[] var1) {
      int var2 = 211;
      byte var3 = -26;
      byte var4 = 53;
      var2 -= (int)(((double)(var2 - var4) + 5.72502 / (double)(var2 >> (int)instanceCount | 1)) * (double)((long)(var2++) + -3953315401L + this.lMeth(var3)));
      FuzzerUtils.out.println("i by i16 = " + var2 + "," + var4 + "," + var3);
      FuzzerUtils.out.println("Test.instanceCount fArrFld = " + instanceCount + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
