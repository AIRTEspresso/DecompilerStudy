public class Test {
   public static final int N = 400;
   public static long instanceCount = 2322956587539681484L;
   public static float fFld = -2.775F;
   public static double dFld = 8.7092;
   public static short sFld = 28341;
   public int iFld = 6591;
   public static volatile long[] lArrFld = new long[400];
   public static long vSmallMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = -17;
      int var5 = -60891;
      int var6 = -241;
      int var7 = 44;
      int var8 = 1;
      short var9 = -200;
      int[] var10 = new int[400];
      int[][][] var11 = new int[400][400][400];
      long[][][] var12 = new long[400][400][400];
      float[][] var13 = new float[400][400];
      FuzzerUtils.init((Object[][])var12, 3015630487L);
      FuzzerUtils.init(var13, -2.562F);
      FuzzerUtils.init((int[])var10, (int)-6);
      FuzzerUtils.init((Object[][])var11, -10);
      var12[(var1 >>> 1) % 400][(var2 >>> 1) % 400][(var1 >>> 1) % 400] = (long)var2;
      int var16 = 384;

      while(true) {
         var16 -= 2;
         if (var16 <= 0) {
            vMeth1_check_sum += (long)(var0 + var1 + var2 + var16 + var4 + var5 + var6 + var7 + var8 + var9) + FuzzerUtils.checkSum((Object[][])var12) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13)) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum((Object[][])var11);
            return;
         }

         var12[var16 - 1][var16 - 1][var16 - 1] = (long)var16;

         for(var4 = 8; var4 > var16; --var4) {
            for(var6 = 1; var6 < 1; ++var6) {
               var13[var4 - 1][var6 + 1] -= (float)instanceCount;
               var13[var4][var4 + 1] -= (float)dFld;
               var2 += sFld;
               instanceCount += (long)('鞟' + var6 * var6);
            }

            for(var8 = 1; var8 < 1; ++var8) {
               try {
                  var0 = -1299865018 % var6;
                  var7 = var16 % var10[var16 - 1];
                  var11[var8 + 1][var4 - 1][var4] = var0 % -27922;
               } catch (ArithmeticException var15) {
               }

               sFld = (short)((int)fFld);
               var0 *= var8;
               instanceCount += instanceCount;
               var10[var16 - 1] = -182;
            }
         }
      }
   }

   public static void vMeth(boolean var0, int var1) {
      float var2 = -16.386F;
      float[] var3 = new float[400];
      boolean var4 = true;
      int var5 = 209;
      int var6 = 14;
      int var7 = -18420;
      int var8 = 4894;
      int var9 = 14;
      long var10 = -2L;
      long[] var12 = new long[400];
      long[] var13 = new long[400];
      byte var14 = -11;
      FuzzerUtils.init(var12, -34068L);
      FuzzerUtils.init(var3, -1.992F);
      FuzzerUtils.init(var13, 571902546L);
      var1 = (int)(-6.0F + (float)var1 + fFld - (float)var1);
      var1 = var1++ << var1;
      fFld *= -55306.0F - (float)var1 * var2 - (float)var12[(var1 >>> 1) % 400];

      int var15;
      for(var15 = 4; var15 < 213; ++var15) {
         for(var6 = 8; var6 > 1; var6 -= 2) {
            var7 -= 8;
            switch (var6 % 2 + 127) {
               case 127:
                  vMeth1(var1, var5, -22300);
                  switch (var15 % 9 * 5 + 111) {
                     case 128:
                        if (var0) {
                           continue;
                        }
                     case 156:
                        var3[var6 - 1] *= (float)var8;
                        continue;
                     case 131:
                        instanceCount = (long)var6;
                        continue;
                     case 136:
                        var7 *= var9;
                        continue;
                     case 139:
                        var1 = var14;
                        continue;
                     case 150:
                        instanceCount += (long)var6;
                     case 140:
                        instanceCount -= -6249500597848774621L;
                        continue;
                     case 153:
                        for(var10 = (long)var15; var10 < 3L; ++var10) {
                           var5 <<= (int)instanceCount;
                           var2 = -106.35549F;
                           instanceCount = var10;
                           var8 = var1;
                           var5 = 14;
                        }
                     case 113:
                        var9 = var7;
                        continue;
                  }
               case 128:
                  var14 = (byte)var15;
                  break;
               default:
                  var13[var15 - 1] ^= (long)var7;
            }
         }
      }

      vMeth_check_sum += (long)((var0 ? 1 : 0) + var1 + Float.floatToIntBits(var2) + var15 + var5 + var6 + var7) + var10 + (long)var8 + (long)var9 + (long)var14 + FuzzerUtils.checkSum(var12) + Double.doubleToLongBits(FuzzerUtils.checkSum(var3)) + FuzzerUtils.checkSum(var13);
   }

   public static void vSmallMeth(int var0) {
      boolean var1 = true;
      vMeth(var1, var0);
      instanceCount += (long)var0;
      vSmallMeth_check_sum += (long)(var0 + (var1 ? 1 : 0));
   }

   public void mainTest(String[] var1) {
      int var2 = -146;
      boolean var3 = true;
      int var4 = 99;
      boolean var5 = true;
      int var6 = 8;
      int var7 = -11739;
      int var8 = 11;
      int var9 = 44;
      byte var10 = -3;
      int var11 = -3;
      byte var12 = -7;
      int[][] var13 = new int[400][400];
      boolean var14 = false;
      FuzzerUtils.init((int[][])var13, (int)-132);

      for(int var15 = 0; var15 < 382; ++var15) {
         vSmallMeth(-50856);
      }

      var2 <<= (int)instanceCount;

      int var16;
      for(var16 = 7; 193 > var16; var16 += 2) {
         var2 *= sFld;
      }

      long[] var10000 = lArrFld;
      var10000[(var4 >>> 1) % 400] += (long)var16;
      var2 >>= var2;
      var4 <<= var16;
      var2 -= var2;

      int var17;
      for(var17 = 18; 396 > var17; ++var17) {
         for(var7 = 4; var7 < 67; ++var7) {
            var13[var17 - 1] = var13[var17 + 1];
            var2 &= var6;

            for(var9 = 1; var9 < 2; ++var9) {
               byte var18 = 2;
               var8 = var18 - var9;
               var8 += var6;
               instanceCount += (long)(var9 * var10 + var10) - instanceCount;
               instanceCount = (long)var17;
               var6 = this.iFld;
               var13[var17][var7 + 1] -= var2;
            }

            for(var11 = var17; var11 < 2; var11 += 3) {
               instanceCount = (long)var4;
               this.iFld = (int)((long)this.iFld + ((long)var11 - instanceCount));
               fFld *= (float)var2;
               if (var14) {
                  if (var14) {
                     break;
                  }

                  var4 += var8;
               } else if (var14) {
                  var13[var17][var11 - 1] <<= this.iFld;
                  var6 = 13420;
               } else {
                  instanceCount ^= (long)var10;
               }
            }
         }
      }

      FuzzerUtils.out.println("i18 i19 i20 = " + var2 + "," + var16 + "," + var4);
      FuzzerUtils.out.println("i21 i22 i23 = " + var17 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i24 i25 i26 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i27 i28 b2 = " + var11 + "," + var12 + "," + (var14 ? 1 : 0));
      FuzzerUtils.out.println("iArr2 = " + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.sFld iFld Test.lArrFld = " + sFld + "," + this.iFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 13748L);
      vSmallMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
