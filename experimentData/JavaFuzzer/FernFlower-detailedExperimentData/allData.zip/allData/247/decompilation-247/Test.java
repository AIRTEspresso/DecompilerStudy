public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 9137146112630515312L;
   public static byte byFld = -126;
   public static boolean bFld = true;
   public static float fFld = 2.582F;
   public short sFld = 7484;
   public double dFld = 2.69772;
   public static boolean[] bArrFld = new boolean[400];
   public static long[] lArrFld = new long[400];
   public static int[] iArrFld = new int[400];
   public static long fMeth_check_sum;
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth() {
      boolean var0 = true;
      int var1 = -1;
      boolean var2 = true;
      int var3 = -65184;
      int var4 = -46985;
      int var5 = -42940;
      int var6 = -4802;
      int[] var7 = new int[400];
      float var8 = 32.616F;
      long[] var9 = new long[400];
      FuzzerUtils.init(var9, -250L);
      FuzzerUtils.init((int[])var7, (int)-2);

      int var12;
      for(var12 = 8; var12 < 295; ++var12) {
         instanceCount = (long)var1;
         var1 += var12 * var12;
      }

      int var13;
      for(var13 = 8; var13 < 159; ++var13) {
         var4 = 10;

         do {
            var9[var4] = (long)var4;

            for(var5 = 1; var5 < 1; ++var5) {
               bArrFld[var4 - 1] = true;

               try {
                  var1 = var4 % 18441;
                  var3 = -20752 / var5;
                  var3 = var7[var4] % 143;
               } catch (ArithmeticException var11) {
               }

               var1 *= 57747;
               var6 = (int)((float)var6 + ((float)(var5 * byFld) + var8 - (float)var5));
               var7[var5] <<= -11;
               var8 += (float)((long)var5 | (long)var6);
            }

            --var4;
         } while(var4 > 0);

         instanceCount += (long)var5;
      }

      vMeth_check_sum += (long)(var12 + var1 + var13 + var3 + var4 + var5 + var6 + Float.floatToIntBits(var8)) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var7);
   }

   public static int iMeth(int var0, float var1) {
      boolean var2 = true;
      int var3 = -42;
      int var4 = -94;
      short var5 = -251;
      byte var6 = 9;
      int[] var7 = new int[400];
      long var8 = -13L;
      short[] var10 = new short[400];
      FuzzerUtils.init((int[])var7, (int)14);
      FuzzerUtils.init((short[])var10, (short)14662);
      vMeth();

      int var14;
      for(var14 = 1; var14 < 322; ++var14) {
         var0 = (int)instanceCount;

         try {
            var3 = var14 / var14;
            var0 %= var0;
            var7[var14 - 1] = var0 % 162;
         } catch (ArithmeticException var13) {
         }

         var8 = 1L;
         if (5L > var8) {
            var4 <<= -51364;
            bFld = bFld;
            var10[var14 + 1] *= (short)var4;
         }

         var3 += var3;
      }

      long var11 = (long)(var0 + Float.floatToIntBits(var1) + var14 + var3) + var8 + (long)var4 + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static float fMeth(int var0, int var1) {
      int var2 = 55257;
      int var3 = 0;
      int var4 = 7;
      int[][][] var5 = new int[400][400][400];
      short var6 = 16511;
      FuzzerUtils.init((Object[][])var5, 93);

      for(var2 = 133; var2 > 5; var2 -= 3) {
         instanceCount += (long)(++byFld) * -1111387205437454085L;
         var5[var2 - 1][var2][var2] -= var3++;
         var1 -= (int)((long)iMeth(-13, fFld) + instanceCount);
         fFld += (float)(var2 * var0) + fFld - fFld;
         var4 = 1;

         do {
            var0 ^= var4;
            lArrFld = lArrFld;
            var6 += (short)var4;
            var0 <<= var1;
            fFld += (float)var2;
            bFld = bFld;
            if (bFld) {
               break;
            }

            instanceCount = (long)((float)instanceCount + ((float)(var4 * var2 + var3) - fFld));
            var3 -= var3;
            ++var4;
         } while(var4 < 36);
      }

      long var7 = (long)(var0 + var1 + var2 + var3 + var4 + var6) + FuzzerUtils.checkSum((Object[][])var5);
      fMeth_check_sum += var7;
      return (float)var7;
   }

   public void mainTest(String[] var1) {
      int var2 = 14158;
      boolean var3 = true;
      int var4 = -77;
      int var5 = -20715;
      int var6 = 46;
      int var7 = -6;
      int var8 = -10;
      int var9 = 153;
      int var10 = 2;
      int[][][] var11 = new int[400][400][400];
      float var12 = 0.848F;
      float var13 = -1.24F;
      float[] var14 = new float[400];
      long var15 = -63278L;
      FuzzerUtils.init(var14, 103.682F);
      FuzzerUtils.init((Object[][])var11, 27309);
      instanceCount <<= var2;

      int var20;
      for(var20 = 8; var20 < 150; ++var20) {
         for(var5 = 8; var5 < 177; ++var5) {
            var12 += fMeth(var4, var6);

            for(var7 = 1; var7 < 2; ++var7) {
               this.sFld -= (short)((int)this.dFld);
               if (!bFld) {
                  var6 += 23;
                  switch ((var20 >>> 1) % 1 * 5 + 9) {
                     case 14:
                        instanceCount += (long)(-12 + var7 * var7);
                        var14[var20 - 1] += -177.0F;
                        var11[var5][var7][var5 + 1] += (int)var12;
                     default:
                        var8 = (int)((float)var8 + ((float)(var7 * var8 + var7) - fFld));
                        var12 = (float)var5;
                  }
               }
            }

            var15 >>= var6;
            var15 -= (long)this.dFld;
         }

         try {
            var11[var20 - 1][var20][var20] = 96 % var5;
            int var10000 = var8 / var5;
            var8 = var6 % var2;
         } catch (ArithmeticException var18) {
         }

         fFld -= (float)var7;
         iArrFld = var11[var20 + 1][var20 + 1];
      }

      for(var13 = 14.0F; var13 < 324.0F; ++var13) {
         var15 = (long)this.dFld;
         var10 = 81;

         do {
            var9 = (int)instanceCount;
            if (bFld) {
               break;
            }

            switch ((int)(var13 % 5.0F * 5.0F + 107.0F)) {
               case 108:
                  try {
                     var6 = var11[var10][(int)(var13 - 1.0F)][var10] % var4;
                     iArrFld[(int)(var13 - 1.0F)] = var7 / 109338388;
                     var9 = var7 / var20;
                  } catch (ArithmeticException var19) {
                  }
               case 128:
                  var9 += var10 * var10;
                  var2 -= var20;
                  this.dFld -= 10.0;
                  break;
               case 110:
                  var4 += var10;
                  break;
               case 120:
                  var14[(int)var13] = (float)var10;
                  break;
               case 131:
                  var12 += (float)var4;
            }

            --var10;
         } while(var10 > 0);
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var20 + "," + var4);
      FuzzerUtils.out.println("i3 i4 f = " + var5 + "," + var6 + "," + Float.floatToIntBits(var12));
      FuzzerUtils.out.println("i23 i24 l1 = " + var7 + "," + var8 + "," + var15);
      FuzzerUtils.out.println("f3 i25 i26 = " + Float.floatToIntBits(var13) + "," + var9 + "," + var10);
      FuzzerUtils.out.println("fArr iArr3 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)) + "," + FuzzerUtils.checkSum((Object[][])var11));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.bFld = " + instanceCount + "," + byFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.fFld sFld dFld = " + Float.floatToIntBits(fFld) + "," + this.sFld + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("Test.bArrFld Test.lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(bArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(bArrFld, false);
      FuzzerUtils.init(lArrFld, -117L);
      FuzzerUtils.init((int[])iArrFld, (int)0);
      fMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
