public class Test {
   public static final int N = 400;
   public static long instanceCount = 58788L;
   public static int iFld = 23969;
   public double dFld = -1.11906;
   public static long[] lArrFld = new long[400];
   public static long lMeth_check_sum;
   public static long fMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(double var0, int var2) {
      boolean var3 = true;
      int var4 = -149;
      int var5 = -247;
      int var6 = 11;
      int var7 = 38;
      int[][] var8 = new int[400][400];
      double var9 = 120.41676;
      FuzzerUtils.init((int[][])var8, (int)40743);

      int var11;
      for(var11 = 203; var11 > 1; --var11) {
         long[] var10000 = lArrFld;
         var10000[var11 - 1] /= 2379255939094521235L;
         var8[var11][var11 + 1] = (int)instanceCount;
      }

      for(var9 = 3.0; 229.0 > var9; ++var9) {
         var8[(int)(var9 - 1.0)] = var8[(int)var9];
         var4 += (int)instanceCount;

         for(var6 = 1; var6 < 7; ++var6) {
            var5 <<= 14;
            var7 += var7;
         }

         instanceCount -= -13L;
         var7 *= var5;
         var4 -= 112;
         int var12 = var4 - (int)var0;
         instanceCount <<= var7;
         var4 = var7;
      }

      vMeth_check_sum += Double.doubleToLongBits(var0) + (long)var2 + (long)var11 + (long)var4 + Double.doubleToLongBits(var9) + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8);
   }

   public static float fMeth(float var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 48908;
      byte var5 = -122;
      int[] var6 = new int[400];
      long var7 = 0L;
      FuzzerUtils.init((int[])var6, (int)-14);
      --var2;
      var0 = (float)var2;
      ++var2;
      var0 += (float)var2;
      int var13 = 292;

      do {
         vMeth(-1.128013, 52466);
         var1 >>= var2;
         instanceCount |= instanceCount;
         var13 -= 2;
      } while(var13 > 0);

      int[] var9 = var6;
      int var10 = var6.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var10000 = var9[var11];

         for(var4 = 4; var4 > 1; var4 -= 3) {
            var2 += var4;

            for(var7 = 1L; ++var7 < 4L; var2 -= (int)var7) {
            }

            var2 += 12;
            instanceCount = var7;
            long[] var15 = lArrFld;
            var15[var4] += var7;
         }
      }

      long var14 = (long)(Float.floatToIntBits(var0) + var1 + var2 + var13 + var4 + var5) + var7 + FuzzerUtils.checkSum(var6);
      fMeth_check_sum += var14;
      return (float)var14;
   }

   public long lMeth(boolean var1, long var2, byte var4) {
      boolean var5 = true;
      int var6 = 44914;
      int var7 = -5;
      int var8 = -2;
      int[] var9 = new int[400];
      double var10 = -11.55899;
      double var12 = -48.1605;
      long var14 = 164L;
      float var16 = -42.821F;
      FuzzerUtils.init((int[])var9, (int)-133);
      int var20 = 305;

      while(true) {
         do {
            var20 -= 3;
            if (var20 <= 0) {
               long var17 = (long)(var1 ? 1 : 0) + var2 + (long)var4 + (long)var20 + Double.doubleToLongBits(var10) + (long)var6 + Double.doubleToLongBits(var12) + var14 + (long)Float.floatToIntBits(var16) + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
               lMeth_check_sum += var17;
               return var17;
            }
         } while(var1 == var1);

         for(var10 = 1.0; var10 < 15.0; ++var10) {
            var12 -= (double)Integer.reverseBytes((int)((var14 *= (long)var6) * 42406L));
            var6 = (int)(-((float)(var6 - var6) * ((float)var6 - var16)));
            instanceCount += (long)(var10 * (double)var2 + (double)var6 - (double)var16);
            var6 = (int)(-((long)(var6 - 21103) | instanceCount));
            var9[(int)var10] += (int)(var16 + (float)(var6 + (var6 - var20)));

            for(var7 = 2; 1 < var7; var7 -= 2) {
               var8 *= (int)(--lArrFld[var20]);

               try {
                  int var10000 = var8 / var6;
                  var8 = var20 / 211;
                  var6 = var7 % var6;
               } catch (ArithmeticException var19) {
               }

               switch (var20 % 1 * 5 + 98) {
                  case 101:
                     var12 = (double)lArrFld[(int)(var10 - 1.0)];
                     var1 = var1 || var1;
               }
            }

            var8 = (int)fMeth(-25.313F, var6, var20);
         }
      }
   }

   public void mainTest(String[] var1) {
      int var2 = -14;
      int var3 = -34935;
      int var4 = -3304;
      int var5 = -1;
      int var6 = -122;
      int var7 = -58655;
      int var8 = 178;
      int var9 = 6;
      int var10 = 6;
      byte var11 = 3;
      int[] var12 = new int[400];
      short var13 = -29242;
      byte var14 = 87;
      double[] var15 = new double[400];
      FuzzerUtils.init((int[])var12, (int)-209);
      FuzzerUtils.init(var15, 1.48625);
      var12[(var2 >>> 1) % 400] = (int)((float)this.lMeth(false, -96L, (byte)38) + 1.584F);
      var12[(var2 >>> 1) % 400] += 9880;

      for(var3 = 17; var3 < 318; ++var3) {
         instanceCount = instanceCount;

         for(var5 = 1; var5 < 84; ++var5) {
            for(var7 = 2; var7 > 1; --var7) {
               var15[var3 - 1] -= (double)var8;
            }

            var9 = 1;

            do {
               var13 = (short)((int)instanceCount);
               var8 -= 60002;
               int var10000 = var8 - var5;
               instanceCount = (long)var5;
               var2 = (int)instanceCount;
               var8 = var4 + var9;
               var6 += var9;
               ++var9;
            } while(var9 < 2);

            var12[var3] = var6;
            var2 >>>= iFld;
            var4 += var5 * var5;
            iFld *= (int)this.dFld;
            instanceCount = (long)var6;

            for(var10 = var5; var10 < 2; ++var10) {
               this.dFld = 53.0;
               var6 = var11;
               iFld *= var2;
               iFld += var10 * var10;
               var12 = var12;
               instanceCount = (long)var14;
            }
         }
      }

      FuzzerUtils.out.println("i i17 i18 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i19 i20 i21 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i22 i23 s = " + var8 + "," + var9 + "," + var13);
      FuzzerUtils.out.println("i24 i25 by1 = " + var10 + "," + var11 + "," + var14);
      FuzzerUtils.out.println("iArr dArr = " + FuzzerUtils.checkSum(var12) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var15)));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -173L);
      lMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
