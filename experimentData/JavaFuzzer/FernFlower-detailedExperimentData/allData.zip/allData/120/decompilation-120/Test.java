public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -55718L;
   public int iFld = 99;
   public static float fFld = 0.585F;
   public static boolean bFld = false;
   public static long lFld = -49429L;
   public static long[] lArrFld = new long[400];
   public static volatile float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long byMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      int var1 = -65;
      short var2 = 21115;
      int var3 = -3;
      short var4 = 1929;
      int var5 = 2;
      byte var6 = -7;
      int var7 = 9;
      byte var8 = -6;
      boolean var9 = true;
      if (var9) {
         instanceCount <<= var0;

         for(var1 = 7; var1 < 125; ++var1) {
            for(var3 = 1; var3 < 13; ++var3) {
               fFld = (float)var2;
            }

            for(var5 = 1; 13 > var5; ++var5) {
               var7 = 1;

               while(var7 < 2) {
                  var0 -= var7;
                  long[] var10000 = lArrFld;
                  var10000[var5 + 1] -= 78L;
                  switch (var1 % 1 + 25) {
                     case 25:
                        var0 = 82;
                     default:
                        if (var3 != 0) {
                           vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8 + (var9 ? 1 : 0));
                           return;
                        }

                        instanceCount += (long)var7;
                        instanceCount = (long)var5;
                        var7 += 2;
                  }
               }
            }

            var6 = -69;
         }
      } else if (var9) {
         var8 = 39;
      } else {
         instanceCount = (long)var4;
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8 + (var9 ? 1 : 0));
   }

   public static byte byMeth(long var0, int var2, int var3) {
      boolean var4 = true;
      int var5 = 1;
      int var6 = -2;
      byte var7 = -51;
      double var8 = 0.32039;

      int var12;
      for(var12 = 19; var12 < 319; ++var12) {
         vMeth1(-11);
         var7 = (byte)var12;
         if (bFld) {
            break;
         }

         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 6) {
               break;
            }

            fFld += fFld;
            lArrFld[var6] = 0L;
            var5 -= 29489;
            var8 *= (double)var6;
         }
      }

      long var10 = var0 + (long)var2 + (long)var3 + (long)var12 + (long)var5 + (long)var7 + (long)var6 + Double.doubleToLongBits(var8);
      byMeth_check_sum += var10;
      return (byte)((int)var10);
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      int var2 = -4653;
      int var3 = 12;
      int var4 = -49763;
      byte var5 = 13;
      double var6 = -108.37499;
      byte var8 = 64;
      byMeth(instanceCount, var0, var0);
      var0 = var0;

      int var11;
      for(var11 = 12; var11 < 245; ++var11) {
         var2 >>>= -38783;
         var0 += 0;
         var2 <<= var11;
         var0 <<= (int)instanceCount;
      }

      try {
         var3 = 1;

         while(true) {
            ++var3;
            if (var3 >= 194) {
               break;
            }

            for(var4 = 1; var4 < 8; ++var4) {
               lFld >>= var3;
               fFld += (float)var4;
               float[] var10000 = fArrFld;
               var10000[var4 + 1] += (float)var0;
               long[] var12 = lArrFld;
               var12[var4] -= (long)var6;
            }
         }
      } catch (ArithmeticException var10) {
         var8 -= (byte)var0;
      }

      vMeth_check_sum += (long)(var0 + var11 + var2 + var3 + var4 + var5) + Double.doubleToLongBits(var6) + (long)var8;
   }

   public void mainTest(String[] var1) {
      int[][] var2 = new int[400][400];
      FuzzerUtils.init(var2, -61212);
      int[] var10000 = var2[(this.iFld >>> 1) % 400];
      int var10001 = (this.iFld >>> 1) % 400;
      var10000[var10001] <<= (int)Math.abs((long)(lArrFld[(this.iFld >>> 1) % 400]--));
      vMeth(this.iFld);
      var10000 = var2[(this.iFld >>> 1) % 400];
      var10001 = (this.iFld >>> 1) % 400;
      var10000[var10001] *= -3;
      this.iFld >>= this.iFld;
      FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(var2));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld Test.lFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + lFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 2000137365L);
      FuzzerUtils.init(fArrFld, -1.951F);
      vMeth_check_sum = 0L;
      byMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
