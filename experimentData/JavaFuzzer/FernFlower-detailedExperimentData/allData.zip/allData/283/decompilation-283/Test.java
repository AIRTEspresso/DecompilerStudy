public class Test {
   public static final int N = 400;
   public static long instanceCount = 676462310L;
   public static volatile double dFld = 1.60385;
   public static short sFld = -7647;
   public static byte[] byArrFld = new byte[400];
   public static float[] fArrFld = new float[400];
   public static int[] iArrFld = new int[400];
   public static long lMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = -1;
      boolean var5 = true;
      int var6 = 100;
      short var7 = -173;
      int var8 = 14;
      int var9 = -196;
      float var10 = 2.321F;
      double var11 = 0.118152;
      short var13 = 29556;
      long[] var14 = new long[400];
      FuzzerUtils.init(var14, 143L);

      int var15;
      for(var15 = 7; var15 < 157; ++var15) {
         var2 = (int)var10;
      }

      int var16;
      for(var16 = 4; var16 < 149; ++var16) {
         switch ((var6 >>> 1) % 4 * 5 + 13) {
            case 24:
               var9 = (int)((long)var9 + ((long)var16 ^ instanceCount));
               break;
            case 25:
            case 26:
            case 28:
            case 29:
            case 30:
            case 31:
            default:
               var13 = (short)(var13 << -7);
               break;
            case 27:
               var6 = (int)instanceCount;
               var4 >>>= var6;
               var14[var16 + 1] ^= (long)var6;

               for(var11 = 1.0; var11 < 11.0; ++var11) {
                  for(var8 = var16; var8 < 2; ++var8) {
                     ++instanceCount;
                     var6 ^= (int)instanceCount;
                     var2 += var8 * var8;
                     var0 += 1013919762;
                  }
               }
            case 32:
               byte[] var10000 = byArrFld;
               var10000[var16 + 1] += (byte)var6;
               break;
            case 33:
               var10 += (float)(var16 * var6) + var10 - (float)instanceCount;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var15 + var4 + Float.floatToIntBits(var10) + var16 + var6) + Double.doubleToLongBits(var11) + (long)var7 + (long)var8 + (long)var9 + (long)var13 + FuzzerUtils.checkSum(var14);
   }

   public static void vMeth(int var0, double var1, int var3) {
      boolean var4 = true;
      boolean var5 = true;
      int var6 = -20455;
      int var7 = 11877;
      int[] var8 = new int[400];
      float var9 = 0.125F;
      byte var10 = -21;
      short var11 = -5222;
      short[][] var12 = new short[400][400];
      long[][][] var13 = new long[400][400][400];
      FuzzerUtils.init(var12, (short)-32186);
      FuzzerUtils.init((Object[][])var13, 54980L);
      FuzzerUtils.init((int[])var8, (int)-19709);
      var12[(var0 >>> 1) % 400][(var3 >>> 1) % 400] = (short)(var3-- - -63588);
      var4 = var4;

      int var16;
      for(var16 = 13; var16 < 293; ++var16) {
         var9 += (float)(var16 * var16 + var6 - var0);
         vMeth1(23955, -32589, var16);
         var7 = 1;

         while(true) {
            ++var7;
            if (var7 >= 6) {
               break;
            }

            var0 = (int)((long)var0 + ((long)(var7 * var3 + var7) - instanceCount));
            var0 >>>= (int)instanceCount;
            var6 -= var3;
            switch ((var3 >>> 1) % 10 + 124) {
               case 124:
                  var0 *= var16;
                  var6 = var0;
                  var3 = var3;
                  var13[var16 - 1][var16 + 1][var16] = (long)var10;
                  break;
               case 125:
                  var8[var7] -= var11;
                  break;
               case 126:
                  var4 = false;
                  break;
               case 127:
                  float[] var17 = fArrFld;
                  var17[var16] *= (float)var3;
               case 128:
                  instanceCount = (long)var3;
               case 129:
                  try {
                     var6 = var0 / -2124804010;
                     var3 = 1245464536 / var16;
                     var3 = -1491358623 % var0;
                  } catch (ArithmeticException var15) {
                  }
                  break;
               case 130:
                  var8 = FuzzerUtils.int1array(400, 5);
                  break;
               case 131:
                  var0 += var3;
                  break;
               case 132:
                  var6 ^= var16;
               case 133:
                  var0 = -246;
                  break;
               default:
                  var9 += (float)var6;
            }
         }
      }

      vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)(var4 ? 1 : 0) + (long)var16 + (long)var6 + (long)Float.floatToIntBits(var9) + (long)var7 + (long)var10 + (long)var11 + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum((Object[][])var13) + FuzzerUtils.checkSum(var8);
   }

   public static long lMeth(int var0, long var1) {
      boolean var3 = true;
      int var4 = 0;
      int var5 = 0;
      int var6 = -12;
      int var7 = 44242;
      short var8 = 28339;
      int var9 = 18;
      int var10 = 241;
      int[] var11 = new int[400];
      float var12 = 1.118F;
      FuzzerUtils.init((int[])var11, (int)63358);
      int var16 = 1;

      while(true) {
         ++var16;
         if (var16 >= 256) {
            for(var7 = 11; var7 < 332; ++var7) {
               for(var9 = 5; var9 > 1; --var9) {
                  var10 &= (int)var1;
                  var5 ^= var16;
               }
            }

            long var17 = (long)var0 + var1 + (long)var16 + (long)var4 + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var12) + (long)var7 + (long)var8 + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var11);
            lMeth_check_sum += var17;
            return var17;
         }

         for(var4 = 1; var4 < 6; var0 = var4++) {
            boolean var13 = false;
            vMeth(var4, dFld, var16);
         }

         var5 -= 23821;

         try {
            var0 = var11[var16] % var16;
            var5 = -23133 / var0;
            var11[var16] = var4 % -30131;
         } catch (ArithmeticException var15) {
         }

         int var10000 = var0 - var16;
         var6 = 1;

         do {
            var11[var6] = (int)var12;
            ++var6;
         } while(var6 < 6);

         var0 = var16;
      }
   }

   public void mainTest(String[] var1) {
      int var2 = -11760;
      int var3 = 16739;
      int var4 = 159;
      int var5 = 211;
      int var6 = 176;
      byte var7 = -7;
      byte var8 = -5;
      float var9 = 0.608F;
      boolean var10 = false;
      long[] var11 = new long[400];
      FuzzerUtils.init(var11, -51467L);
      if (var10) {
         var2 = 1;

         do {
            var9 += (float)lMeth(-10, instanceCount);

            for(var3 = 3; var3 < 169; ++var3) {
               var4 |= (int)instanceCount;
               iArrFld[var3 - 1] = var2;
               var5 = 1;

               do {
                  var4 = (int)((long)var4 + ((long)var5 | (long)var9));
                  var9 += (float)var5;
                  int var10000 = var4 + var5 * var5;
                  byte var13 = 12;
                  int[] var14 = iArrFld;
                  var14[var3 + 1] *= (int)instanceCount;
                  var4 = var13 - 6;
                  sFld = (short)var3;
                  var4 = var3;
                  var9 -= (float)instanceCount;
                  instanceCount &= (long)var3;
                  ++var5;
               } while(var5 < 2);

               for(var6 = 1; var6 < 2; ++var6) {
                  boolean var12 = true;
                  instanceCount *= (long)var4;
                  var9 = 24357.0F;
                  iArrFld[var3] = var7;
                  fArrFld[var6 - 1] = var9;
                  var4 = (int)instanceCount;
                  switch (var3 % 2 * 5 + 109) {
                     case 111:
                        if (var12) {
                           instanceCount += (long)var4;
                        } else {
                           var12 = true;
                           var11[var6 + 1] = (long)var5;
                        }
                        break;
                     case 117:
                        instanceCount *= (long)sFld;
                  }
               }
            }

            ++var2;
         } while(var2 < 148);
      } else {
         var7 = var8;
      }

      FuzzerUtils.out.println("i f i25 = " + var2 + "," + Float.floatToIntBits(var9) + "," + var3);
      FuzzerUtils.out.println("i26 i27 i28 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i29 b3 i30 = " + var7 + "," + (var10 ? 1 : 0) + "," + var8);
      FuzzerUtils.out.println("lArr2 = " + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.sFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + sFld);
      FuzzerUtils.out.println("Test.byArrFld Test.fArrFld Test.iArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((byte[])byArrFld, (byte)101);
      FuzzerUtils.init(fArrFld, -1.566F);
      FuzzerUtils.init((int[])iArrFld, (int)14);
      lMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
