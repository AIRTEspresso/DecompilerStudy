public class Test {
   public static final int N = 400;
   public static long instanceCount = 21295L;
   public int iFld = -8;
   public static boolean bFld = true;
   public long[] lArrFld = new long[400];
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long bMeth_check_sum;

   public boolean bMeth() {
      float var1 = -94.316F;
      var1 *= var1;
      long var2 = (long)Float.floatToIntBits(var1);
      bMeth_check_sum += var2;
      return var2 % 2L > 0L;
   }

   public void vMeth1() {
      boolean var1 = true;
      boolean var2 = true;
      int var3 = -234;
      int var4 = -46;
      int var5 = 14;
      int[] var6 = new int[400];
      double var7 = 0.127445;
      float var9 = 63.29F;
      FuzzerUtils.init((int[])var6, (int)-189);
      var1 = this.bMeth();

      int var10;
      for(var10 = 1; var10 < 247; ++var10) {
         instanceCount = (long)var3;

         for(var4 = 1; var4 < 7; ++var4) {
            long[] var10000 = this.lArrFld;
            var10000[var4 + 1] -= (long)var3;
            var6[(var10 >>> 1) % 400] = var10;
            var7 = 1.0;

            while(++var7 < 2.0) {
               switch ((int)(var7 % 10.0 * 5.0 + 24.0)) {
                  case 26:
                     break;
                  case 32:
                     int var11 = var5 + var4;
                     var5 = var10;
                     instanceCount = (long)var10;
                     var9 = -205.0F;
                     break;
                  case 35:
                     var3 += (int)(var7 * var7);
                     break;
                  case 43:
                     if (var1) {
                     }
                     break;
                  case 58:
                     var5 *= (int)instanceCount;
                     break;
                  case 59:
                     var6[var4] += 6;
                     var5 = var3;
                     break;
                  case 62:
                     var3 -= var10;
                     break;
                  case 65:
                     var5 = (int)instanceCount;
                     break;
                  case 69:
                     var1 = var1;
                     break;
                  case 72:
                     var5 = (int)instanceCount;
                     break;
                  default:
                     instanceCount *= (long)var7;
               }
            }
         }
      }

      vMeth1_check_sum += (long)((var1 ? 1 : 0) + var10 + var3 + var4 + var5) + Double.doubleToLongBits(var7) + (long)Float.floatToIntBits(var9) + FuzzerUtils.checkSum(var6);
   }

   public void vMeth(int var1, int var2) {
      int var3 = 33724;
      int var4 = -1406;
      int var5 = 48;
      int var6 = 7;
      int var7 = -21450;
      int var8 = 213;
      int[] var9 = new int[400];
      double var10 = 2.82964;
      byte var12 = -92;
      short var13 = 32613;
      float[] var14 = new float[400];
      FuzzerUtils.init((int[])var9, (int)3);
      FuzzerUtils.init(var14, 2.564F);
      var9[(var2 >>> 1) % 400] = var1;

      for(var3 = 10; var3 < 215; ++var3) {
         long[] var10000 = this.lArrFld;
         var10000[var3] -= (long)(var14[47] + (float)(++var9[var3]));
         this.vMeth1();
         instanceCount += (long)var3;
         switch (var3 % 10 + 45) {
            case 45:
               var5 = var3;

               for(; var5 < 8; ++var5) {
                  var10 %= (double)(var4 | 1);

                  for(var7 = 1; 1 > var7; ++var7) {
                     float var15 = 0.801F;
                     var15 -= (float)instanceCount;
                     instanceCount = (long)var4;
                  }

                  switch ((var6 >>> 1) % 1 * 5 + 58) {
                     case 60:
                        this.lArrFld[var3] = -82L;
                        var1 += var5;
                        var8 &= var12;
                        break;
                     default:
                        var6 = var2;
                  }
               }
               break;
            case 46:
               var6 += var3 * var13;
            case 47:
               var4 += 61659;
            case 48:
               var6 &= (int)instanceCount;
               break;
            case 49:
               var4 += var3 ^ this.iFld;
               break;
            case 50:
               var9[var3] = var4;
               break;
            case 51:
               var9[var3 + 1] -= -11099;
            case 52:
               instanceCount = (long)this.iFld;
               break;
            case 53:
               var1 += var3;
               break;
            case 54:
               var6 += var4;
               break;
            default:
               var9[var3] = var2;
         }
      }

      vMeth_check_sum += (long)(var1 + var2 + var3 + var4 + var5 + var6) + Double.doubleToLongBits(var10) + (long)var7 + (long)var8 + (long)var12 + (long)var13 + FuzzerUtils.checkSum(var9) + Double.doubleToLongBits(FuzzerUtils.checkSum(var14));
   }

   public void mainTest(String[] var1) {
      int var2 = -43100;
      int var3 = 6;
      int var4 = 10;
      int var5 = 44982;
      float var6 = -103.643F;
      float var7 = -88.139F;
      short var8 = -20050;
      this.vMeth(-36, -33116);

      for(var2 = 21; var2 < 397; ++var2) {
         try {
            var3 = this.iFld / 117;
            this.iFld %= var3;
            var3 = var2 / this.iFld;
         } catch (ArithmeticException var10) {
         }

         label108: {
            label82: {
               int[] var10000;
               switch (var2 % 10 * 5 + 30) {
                  case 34:
                     var10000 = iArrFld;
                     var10000[var2 - 1] >>>= 1;
                     continue;
                  case 39:
                     this.iFld >>>= -83;
                  case 52:
                     break label82;
                  case 62:
                  case 76:
                     break label108;
                  case 65:
                     instanceCount = (long)var2;
                     continue;
                  case 67:
                     for(var4 = 1; var4 < 67; ++var4) {
                        var6 += -55.0F;
                        this.lArrFld[var4 - 1] = (long)var2;
                        iArrFld[var4] = 5;
                        if (bFld) {
                           long[] var11 = this.lArrFld;
                           var11[var2 - 1] *= instanceCount;
                           var5 += 1604715977;
                        } else {
                           var3 *= 2;
                           var3 += var4 * var5 + this.iFld - var4;

                           for(var7 = 1.0F; ++var7 < 2.0F; var5 -= var4) {
                              var3 += (int)(var7 * (float)instanceCount);
                              var6 = 5.0F;
                              instanceCount += (long)(var7 * (float)this.iFld + (float)var8 - (float)instanceCount);
                              var5 >>= -25805;
                              var5 = (int)((float)var5 + 48198.0F + var7 * var7);
                              var6 += var7 + (float)var5;
                           }
                        }

                        var3 -= this.iFld;
                        instanceCount += (long)var4;
                        var3 *= (int)instanceCount;
                        if (bFld) {
                           break;
                        }
                     }

                     var10000 = iArrFld;
                     var10000[var2 - 1] -= -63;
                  case 51:
                     this.iFld = (int)((long)this.iFld + (long)var2 + instanceCount);
                     break label108;
                  case 68:
                     var5 += var8;
                     continue;
                  case 73:
                     var10000 = iArrFld;
                     var10000[var2] >>= var4;
                     continue;
               }

               instanceCount = -90L;
               continue;
            }

            var3 += (int)instanceCount;
            continue;
         }

         instanceCount = (long)this.iFld;
         instanceCount += (long)(var2 * var2) + instanceCount - (long)var2;
      }

      FuzzerUtils.out.println("i12 i13 i14 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i15 f3 f4 = " + var5 + "," + Float.floatToIntBits(var6) + "," + Float.floatToIntBits(var7));
      FuzzerUtils.out.println("s1 = " + var8);
      FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)8);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      bMeth_check_sum = 0L;
   }
}
