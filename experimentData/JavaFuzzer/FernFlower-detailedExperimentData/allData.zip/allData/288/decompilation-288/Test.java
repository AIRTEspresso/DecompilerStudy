public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -1648678541L;
   public static float fFld = -41.324F;
   public static byte byFld = -39;
   public static double dFld = 121.9915;
   public boolean[] bArrFld = new boolean[400];
   public static long[] lArrFld = new long[400];
   public static long lMeth_check_sum;
   public static long iMeth_check_sum;
   public static long lMeth1_check_sum;

   public static long lMeth1(double var0, long var2) {
      int var4 = -231;
      int var5 = -100;
      int var6 = -41799;
      int var7 = -11;
      int var8 = 151;
      int var9 = 5;
      int[] var10 = new int[400];
      float var11 = -2.85F;
      short var12 = 26557;
      boolean var13 = true;
      byte var14 = 4;
      FuzzerUtils.init((int[])var10, (int)-193);
      instanceCount -= (long)fFld;
      if (var13) {
         var4 = 242;

         while(true) {
            --var4;
            if (var4 <= 0) {
               break;
            }

            for(var11 = 1.0F; var11 < 7.0F; ++var11) {
               var10[var4 + 1] = var5;
               var5 += (int)(var11 * (float)var12);

               for(var6 = 2; var6 > 1; --var6) {
                  var7 *= var4;
                  var5 *= -78089762;
               }

               if (var13) {
                  break;
               }

               var14 -= var14;

               for(var8 = 1; var8 < 2; ++var8) {
                  var9 -= var5;
                  var5 = var14 * var6;
               }
            }
         }
      } else if (var13) {
         var5 += var6;
      } else {
         var9 -= var8;
      }

      long var15 = Double.doubleToLongBits(var0) + var2 + (long)var4 + (long)Float.floatToIntBits(var11) + (long)var5 + (long)var12 + (long)var6 + (long)var7 + (long)(var13 ? 1 : 0) + (long)var14 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
      lMeth1_check_sum += var15;
      return var15;
   }

   public static int iMeth() {
      int var0 = 39837;
      int var1 = -21276;
      int var2 = -39748;
      int var3 = -155;
      byte var4 = 3;
      int[] var5 = new int[400];
      float var6 = 0.824F;
      float[] var7 = new float[400];
      boolean var8 = true;
      double var9 = 0.3236;
      short var11 = 10602;
      FuzzerUtils.init(var7, -2.301F);
      FuzzerUtils.init((int[])var5, (int)15339);

      for(var0 = 3; 168 > var0; ++var0) {
         for(var6 = 1.0F; var6 < 10.0F; ++var6) {
            var1 += (int)(var6 - (float)var2);
            switch ((int)(var6 % 8.0F * 5.0F + 96.0F)) {
               case 106:
                  var5 = var5;
               case 107:
               case 110:
               case 112:
               case 114:
               case 115:
               case 116:
               case 118:
               case 119:
               default:
                  break;
               case 111:
                  instanceCount += (long)(var6 * var6);
                  break;
               case 117:
                  fFld += (float)var4;
               case 113:
                  var1 <<= 1;
                  break;
               case 120:
                  var2 = var2++;
                  var8 = var8;
                  instanceCount = (long)var2;
               case 109:
                  var7[var0 + 1] = (float)lMeth1(var9, instanceCount);
                  var1 += (int)(var6 - var6);

                  for(var3 = 1; var3 < 2; ++var3) {
                     var5 = var5;
                     fFld -= (float)var4;
                     instanceCount <<= var0;
                     var1 += var3 * var3;
                     var1 += 79;
                  }
               case 108:
                  var11 *= (short)((int)instanceCount);
                  break;
               case 121:
                  fFld += (float)instanceCount;
            }
         }
      }

      long var12 = (long)(var0 + var1 + Float.floatToIntBits(var6) + var2 + (var8 ? 1 : 0)) + Double.doubleToLongBits(var9) + (long)var3 + (long)var4 + (long)var11 + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public static long lMeth(long var0, int var2, int var3) {
      long var4 = 1050116900L;
      long[] var6 = new long[400];
      int var7 = 64773;
      int var8 = -2;
      int var9 = -39;
      int var10 = 7;
      int[] var11 = new int[400];
      double var12 = 0.1193;
      float[] var14 = new float[400];
      FuzzerUtils.init(var6, -11L);
      FuzzerUtils.init(var14, -2.631F);
      FuzzerUtils.init((int[])var11, (int)190);

      for(var4 = 1L; var4 < 281L; ++var4) {
         for(var8 = 1; var8 < 6; ++var8) {
            int var15 = -61395;
            instanceCount += (long)var8;
            var9 *= var2;
            var12 -= (double)iMeth();
            int var10000;
            switch (var8 % 9 + 66) {
               case 66:
                  switch ((int)(var4 % 3L * 5L + 73L)) {
                     case 79:
                        var2 = (int)((long)var2 + ((long)(var8 * var7 + var8) - var0));
                        continue;
                     case 80:
                        var9 &= var7;
                        if (var2 != 0) {
                        }

                        var10 = 1;

                        do {
                           byFld ^= -15;
                           switch (var8 % 4 + 53) {
                              case 53:
                                 var6[(int)(var4 + 1L)] -= (long)fFld;
                                 var2 ^= var9;
                                 break;
                              case 54:
                                 var6[var8 - 1] = (long)var7;
                                 break;
                              case 55:
                                 instanceCount = -10L;
                              case 56:
                                 var14[var8 + 1] = (float)var12;
                              default:
                                 var7 += var3;
                           }

                           ++var10;
                        } while(var10 < 2);
                     case 85:
                        var7 = var10;
                        continue;
                  }
               case 67:
                  var10000 = var15 & var10;
                  break;
               case 68:
                  var11[var8 + 1] = (int)var0;
                  break;
               case 69:
                  var11[(int)var4] >>>= 8;
                  break;
               case 70:
               case 71:
                  var0 = 5104L;
                  break;
               case 72:
                  var3 >>= var8;
                  break;
               case 73:
                  var10000 = var15 + (var8 - var9);
                  break;
               case 74:
                  var12 -= (double)var2;
            }
         }
      }

      long var17 = var0 + (long)var2 + (long)var3 + var4 + (long)var7 + (long)var8 + (long)var9 + Double.doubleToLongBits(var12) + (long)var10 + FuzzerUtils.checkSum(var6) + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)) + FuzzerUtils.checkSum(var11);
      lMeth_check_sum += var17;
      return var17;
   }

   public void mainTest(String[] var1) {
      long var2 = 7044678282479838156L;
      int var4 = -235;
      boolean var5 = true;
      int var6 = 1;
      int var7 = -3;
      int var8 = 22825;
      int var9 = -12;
      int var10 = 127;
      int var11 = 4;
      int var12 = -38749;
      byte var13 = -49;
      int[] var14 = new int[400];
      short var15 = -25931;
      boolean var16 = false;
      float var17 = -10.84F;
      FuzzerUtils.init((int[])var14, (int)-323);
      var2 = 1L;

      do {
         try {
            var4 = var14[(int)var2] % var4;
            var4 = 18807 % var4;
            var4 /= var4;
         } catch (ArithmeticException var19) {
         }
      } while(++var2 < 371L);

      int var20;
      for(var20 = 10; var20 < 382; var20 += 2) {
         var4 ^= (int)lMeth(var2, var4, var4);
         fFld *= (float)var15;
         this.bArrFld[var20] = var16;
         int var10000 = var6 + var20;
         var6 = var20;

         for(var7 = 2; var7 < 135; ++var7) {
            var6 += var7;
            var6 -= byFld;
         }

         switch (var20 % 7 + 63) {
            case 63:
               var4 += var4;
               var8 += var20 * var20 + var6 - var15;
               break;
            case 64:
            case 65:
               var6 = 39931;
               var9 = 3;

               for(; var9 < 135; ++var9) {
                  for(var11 = 1; var11 < 2; ++var11) {
                     var6 <<= var11;
                     lArrFld = FuzzerUtils.long1array(400, -212898003798579950L);
                     var10 = 10280;
                     var4 /= (int)((long)fFld | 1L);
                  }

                  var14[var20] *= (int)dFld;
                  var17 = 1.0F;
                  if (2.0F > var17) {
                     var4 -= (int)var17;
                     var4 = (int)((float)var4 + -157.0F + var17 * var17);
                  }
               }
               break;
            case 66:
               var14[var20] <<= var6;
               break;
            case 67:
               var14[var20 - 1] = (int)dFld;
               break;
            case 68:
               fFld += (float)var15;
               break;
            case 69:
               var10 = var7;
         }
      }

      FuzzerUtils.out.println("l i i1 = " + var2 + "," + var4 + "," + var20);
      FuzzerUtils.out.println("i2 s2 b2 = " + var6 + "," + var15 + "," + (var16 ? 1 : 0));
      FuzzerUtils.out.println("i21 i22 i23 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i24 i25 i26 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("f2 i27 iArr = " + Float.floatToIntBits(var17) + "," + var13 + "," + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
      FuzzerUtils.out.println("Test.dFld bArrFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(this.bArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -13528L);
      lMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      lMeth1_check_sum = 0L;
   }
}
