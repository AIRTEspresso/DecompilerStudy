public class Test {
   public static final int N = 400;
   public static long instanceCount = 743154865L;
   public static int iFld = 48177;
   public static byte byFld = -86;
   public static short sFld = -21802;
   public static boolean bFld = true;
   public int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(long var0, long var2, int var4) {
      int[] var5 = new int[400];
      FuzzerUtils.init((int[])var5, (int)-105);
      var5[(var4 >>> 1) % 400] >>>= 32737;
      vMeth1_check_sum += var0 + var2 + (long)var4 + FuzzerUtils.checkSum(var5);
   }

   public static long lMeth(long var0) {
      float var2 = -1.827F;
      float var3 = 2.176F;
      int var4 = -9;
      int var5 = -217;
      int var6 = -14;
      int var7 = 11;
      short var8 = -229;
      int[] var9 = new int[400];
      boolean var10 = true;
      FuzzerUtils.init((int[])var9, (int)-162);
      vMeth1(var0, instanceCount, iFld);

      for(var2 = 7.0F; var2 < 122.0F; ++var2) {
         for(var5 = 1; var5 < 14; ++var5) {
            var9[var5] = 0;
            iFld += var5 * byFld + var5 - sFld;
         }

         var4 += 36124;

         for(var7 = 1; var7 < 14; ++var7) {
            if (iFld != 0) {
            }

            if (!var10) {
               var0 = 0L;
               iFld >>>= var7;
               var6 -= var5;
               var3 = 48486.0F;
            }
         }

         var6 += (int)(var2 * (float)var6 + (float)var4 - (float)var4);
      }

      var4 >>>= var8;
      long var11 = var0 + (long)Float.floatToIntBits(var2) + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)(var10 ? 1 : 0) + (long)Float.floatToIntBits(var3) + FuzzerUtils.checkSum(var9);
      lMeth_check_sum += var11;
      return var11;
   }

   public void vMeth(int var1) {
      long var2 = -25L;
      int var4 = -130;
      int var5 = 7;
      int var6 = 40732;
      int var7 = 19417;
      int var8 = 34;
      float var9 = -28.436F;
      double var10 = -103.87417;
      double var12 = 2.8014;

      label60:
      for(var2 = 6L; var2 < 150L; ++var2) {
         var5 = 1;

         while(true) {
            ++var5;
            if (var5 >= 11) {
               if (bFld) {
                  break label60;
               }

               var1 -= var5;
               var1 += (int)(var2 * var2);
               var9 = (float)var10;

               for(var12 = 1.0; 11.0 > var12; ++var12) {
                  switch ((int)(var12 % 4.0 + 2.0)) {
                     case 2:
                        instanceCount >>= iFld;

                        for(var7 = 1; var7 < 2; ++var7) {
                           sFld = (short)var6;
                           var1 = var7;
                           int[] var10000 = this.iArrFld;
                           var10000[(int)var12] += (int)var12;
                           this.iArrFld[(int)var12] = (int)var2;
                        }
                     case 3:
                        var8 += (int)var9;
                     case 4:
                        break;
                     case 5:
                        var8 >>= var8;
                        continue;
                     default:
                        var6 = (int)((double)var6 + 35.0 + var12 * var12);
                        continue;
                  }

                  iFld <<= var7;
               }
               break;
            }

            var4 |= (int)((lMeth(var2) - (long)iFld) * instanceCount);
         }
      }

      vMeth_check_sum += (long)var1 + var2 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var9) + Double.doubleToLongBits(var10) + Double.doubleToLongBits(var12) + (long)var6 + (long)var7 + (long)var8;
   }

   public void mainTest(String[] var1) {
      int var2 = 142;
      boolean var3 = true;
      int var4 = -228;
      int var5 = 33520;
      int var6 = -52152;
      char var7 = '鿈';
      int var8 = -8;
      int var9 = 59824;
      int var10 = -34714;
      int var11 = 210;
      short var12 = 185;
      double var13 = -123.3001;
      float var15 = -1.274F;
      boolean[] var16 = new boolean[400];
      long[] var17 = new long[400];
      FuzzerUtils.init(var16, true);
      FuzzerUtils.init(var17, 18827L);
      var2 = var2--;
      this.vMeth(var2);

      int var19;
      for(var19 = 13; var19 < 358; ++var19) {
         iFld += (int)var13;
         iFld += (int)instanceCount;
         instanceCount -= (long)var5;
         var4 *= -29991;
         var2 += var19;
         var5 = (int)var13;
      }

      var4 += 152;

      for(var6 = 168; var6 > 8; var6 -= 3) {
         var8 = 129;

         do {
            var13 = (double)instanceCount;
            var5 <<= var5;
            --var8;
         } while(var8 > 0);

         for(var9 = 17; 344 > var9; ++var9) {
            for(var11 = var6; var11 < 2; ++var11) {
               float var18 = -88.276F;
               this.iArrFld[var9] = var4;
               float[] var20 = fArrFld;
               var20[var11 + 1] *= (float)instanceCount;
               instanceCount >>= var10;
               if (!bFld) {
                  var4 *= (int)var18;
                  var18 = (float)var9;
                  byFld -= (byte)((int)instanceCount);
               }
            }

            int[] var21 = this.iArrFld;
            var21[var9 + 1] *= (int)var13;
            var15 *= (float)var19;
            var16[var9] = true;
            bFld = bFld;
            var17[var9] -= -1L;
            var5 += var9;
            if (bFld) {
               break;
            }
         }
      }

      FuzzerUtils.out.println("i i13 i14 = " + var2 + "," + var19 + "," + var4);
      FuzzerUtils.out.println("d2 i15 i16 = " + Double.doubleToLongBits(var13) + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i17 i18 i19 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i20 i21 i22 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("f4 bArr lArr = " + Float.floatToIntBits(var15) + "," + FuzzerUtils.checkSum(var16) + "," + FuzzerUtils.checkSum(var17));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + byFld);
      FuzzerUtils.out.println("Test.sFld Test.bFld iArrFld = " + sFld + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 2.25F);
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
