public class Test {
   public static final int N = 400;
   public static long instanceCount = -1686312975L;
   public static byte byFld = 97;
   public static boolean bFld = false;
   public static short sFld = -13813;
   public volatile double dFld = 0.104667;
   public static volatile long[] lArrFld = new long[400];
   public static byte[] byArrFld = new byte[400];
   public static int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth() {
      boolean var0 = true;
      int var1 = -49407;
      boolean var2 = true;
      int[] var3 = new int[400];
      float var4 = 118.929F;
      boolean var5 = true;
      FuzzerUtils.init((int[])var3, (int)-10);

      int var8;
      for(var8 = 1; 128 > var8; ++var8) {
         instanceCount -= (long)var1;
         var1 >>>= var8;
         var1 += var1;
         var1 *= -6170;
      }

      var3[(var1 >>> 1) % 400] = -248;
      var4 = (float)byFld;
      int var9 = 1;

      do {
         instanceCount += (long)(-102 + var9 * var9);
         int var10000 = var1 + (var9 ^ var9);
         var5 = var5;
         var1 = (int)instanceCount;
         var1 *= (int)instanceCount;
         ++var9;
      } while(var9 < 248);

      long var6 = (long)(var8 + var1 + Float.floatToIntBits(var4) + var9 + (var5 ? 1 : 0)) + FuzzerUtils.checkSum(var3);
      lMeth_check_sum += var6;
      return var6;
   }

   public static void vMeth1(float var0) {
      int var1 = -27;
      int var2 = -170;
      int var3 = -58143;
      int var4 = 1;
      int var5 = 49675;
      int var6 = 5;
      int[] var7 = new int[400];
      short var8 = 19168;
      boolean[] var9 = new boolean[400];
      FuzzerUtils.init((int[])var7, (int)13);
      FuzzerUtils.init(var9, false);

      try {
         for(var1 = 5; var1 < 137; ++var1) {
            try {
               int var10000 = var2 / var1;
               var2 = 21500 % var7[var1];
               var2 /= var1;
            } catch (ArithmeticException var11) {
            }

            lArrFld[var1 + 1] = (long)(var2--);

            for(var3 = 1; 12 > var3; ++var3) {
               var8 -= (short)(var4++);
               if (bFld) {
                  for(var5 = 1; var5 < 2; ++var5) {
                     instanceCount = (long)(var6--) + lMeth();
                     instanceCount += (long)var5;
                     instanceCount >>= (int)instanceCount;
                     byte[] var14 = byArrFld;
                     var14[var1] -= (byte)var2;
                  }
               }
            }
         }
      } catch (ArithmeticException var12) {
         var6 *= (int)instanceCount;
      } catch (UserDefinedExceptionTest var13) {
         var6 >>= var6;
      }

      vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var1 + var2 + var3 + var4 + var8 + var5 + var6) + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var9);
   }

   public void vMeth(int var1) {
      float var2 = 3.363F;
      boolean var3 = true;
      int var4 = 18399;
      short var5 = 476;
      short var6 = 213;
      short var7 = -225;
      double var8 = -48.466;
      double var10 = 85.109066;
      vMeth1(var2);

      int var12;
      for(var12 = 1; var12 < 209; ++var12) {
         var4 = (int)instanceCount;
         var5 = 1;
         if (var5 < 8) {
         }
      }

      vMeth_check_sum += (long)(var1 + Float.floatToIntBits(var2) + var12 + var4 + var5 + var6) + Double.doubleToLongBits(var8) + (long)var7 + Double.doubleToLongBits(var10);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -6;
      int var4 = 62949;
      int var5 = 14;
      int var6 = 12;
      int var7 = -81;
      int var8 = 62174;
      int var9 = -64542;
      long var10 = 8L;
      boolean[][] var12 = new boolean[400][400];
      FuzzerUtils.init(var12, true);

      int var13;
      for(var13 = 277; var13 > 12; --var13) {
         this.vMeth(19035);
         byFld = (byte)var3;
         var4 = 1;

         while(!bFld) {
            instanceCount += (long)(var4 | var4);
            var3 %= var4 | 1;
            byFld -= (byte)var4;

            for(var10 = 1L; var10 < 1L; ++var10) {
               var12[var13 - 1][var13] = bFld;
               var5 += (int)(var10 * (long)byFld + var10 - var10);
            }

            var3 = (int)((long)var3 + ((long)var4 * instanceCount + (long)var3 - (long)var13));
            var3 ^= (int)instanceCount;
            var5 = 2139298166;
            ++var4;
            if (var4 >= 95) {
               break;
            }
         }

         label59:
         for(var6 = 2; var6 < 95; ++var6) {
            var7 += var7;
            var7 += var6;
            switch (var6 % 6 + 107) {
               case 107:
                  var7 = sFld;
                  instanceCount += (long)this.dFld;
                  var8 = 1;

                  while(true) {
                     if (var8 >= 2) {
                        continue label59;
                     }

                     var9 += var3;
                     lArrFld = FuzzerUtils.long1array(400, -1380765706L);
                     instanceCount += (long)var8;
                     instanceCount += (long)var8 ^ var10;
                     this.dFld -= (double)var9;
                     fArrFld[var8 - 1] = (float)var8;
                     var3 <<= 131;
                     var9 = var8++;
                  }
               case 108:
                  iArrFld[var6] = var13;
               case 109:
                  instanceCount += (long)var7;
                  break;
               case 110:
                  var7 += var6;
                  break;
               case 111:
                  var9 >>= var7;
                  break;
               case 112:
                  var3 <<= 42434;
            }
         }
      }

      FuzzerUtils.out.println("i i1 i18 = " + var13 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("l i19 i20 = " + var10 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i21 i22 i23 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("bArr1 = " + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.bFld = " + instanceCount + "," + byFld + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.sFld dFld Test.lArrFld = " + sFld + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("Test.byArrFld Test.iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -12L);
      FuzzerUtils.init(byArrFld, (byte)-117);
      FuzzerUtils.init((int[])iArrFld, (int)-85);
      FuzzerUtils.init(fArrFld, 0.341F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
