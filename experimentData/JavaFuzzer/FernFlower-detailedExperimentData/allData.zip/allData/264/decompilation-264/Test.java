public class Test {
   public static final int N = 400;
   public static long instanceCount = 25949L;
   public static double dFld = 1.60341;
   public static int iFld = 234;
   public static boolean bFld = false;
   public static int iFld1 = 3;
   public static float fFld = 0.339F;
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long fMeth_check_sum;

   public static float fMeth(long var0) {
      boolean var2 = true;
      int var3 = -3;
      int var4 = 10;
      int var5 = -131;
      int var6 = 56273;
      float var7 = 2.512F;

      int var10;
      for(var10 = 8; var10 < 225; ++var10) {
         var3 += var10;

         for(var4 = 7; var4 > var10; --var4) {
            var0 = (long)var4;
            var6 = 1;

            do {
               var5 *= (int)var0;
               dFld = (double)var0;
               var3 = (int)var0;
               var0 += (long)(var6 + var3);
               var7 *= (float)var3;
               lArrFld = FuzzerUtils.long1array(400, -6L);
               ++var6;
            } while(var6 < 1);
         }
      }

      long var8 = var0 + (long)var10 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var7);
      fMeth_check_sum += var8;
      return (float)var8;
   }

   public static void vMeth1(int var0, long var1) {
      long var3 = -5885814242179828052L;
      var0 = (int)(-((float)(-lArrFld[(var0 >>> 1) % 400]) - fMeth(var3)));
      vMeth1_check_sum += (long)var0 + var1 + var3;
   }

   public static void vMeth(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 5;
      int var5 = 28963;
      int var6 = -9357;
      int var7 = 7;
      int var8 = 11;
      float var9 = -3.636F;
      short[] var10 = new short[400];
      FuzzerUtils.init(var10, (short)-12627);

      int var11;
      for(var11 = 277; var11 > 12; --var11) {
         for(var5 = 1; var5 < 6; ++var5) {
            var10[var5 + 1] = (short)(var2++);
            vMeth1(208, instanceCount);
            var6 += (int)dFld;

            for(var7 = 1; var7 < 2; ++var7) {
               var8 -= 6;
               var9 += 12.0F;
               instanceCount *= instanceCount;
               var4 = var1;
               iFld += -242;
               if (!bFld) {
                  var6 <<= var5;
                  var2 = 579060275;
                  if (bFld) {
                  }
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var11 + var4 + var5 + var6 + var7 + var8 + Float.floatToIntBits(var9)) + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 47999;
      int var4 = -9;
      int var5 = 7;
      int var6 = -40872;
      int var7 = -76;
      int var8 = 1;
      byte var9 = 7;
      byte var10 = 7;
      byte var11 = -48;
      long var12 = 59668411734707021L;
      double[] var14 = new double[400];
      FuzzerUtils.init(var14, 64.49329);
      vMeth(iFld, iFld, iFld1);

      int var15;
      for(var15 = 16; 263 > var15; ++var15) {
         for(var4 = var15; var4 < 102; ++var4) {
            for(var6 = 1; 1 < var6; --var6) {
               dFld = 30023.0;
               var8 += var8;
               switch ((iFld >>> 1) % 5 + 27) {
                  case 27:
                     var7 *= 1;
                     break;
                  case 28:
                     var11 -= (byte)((int)instanceCount);
                     iFld1 *= (int)dFld;
                     iFld = var5;
                     break;
                  case 29:
                     dFld -= (double)var5;
                     var3 = -23612;
                     long[] var10000 = lArrFld;
                     var10000[var4] -= instanceCount;
                     var8 = var5;
                     break;
                  case 30:
                     var8 = var5;
                     fFld *= (float)instanceCount;
                  case 31:
               }

               var5 *= (int)fFld;
            }
         }

         var12 = (long)var15;
         if (var12 < 102L) {
            var3 += 100;
         }
      }

      FuzzerUtils.out.println("i15 i16 i17 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i18 i19 i20 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i21 by l3 = " + var8 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("i22 i23 dArr = " + var9 + "," + var10 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var14)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
      FuzzerUtils.out.println("Test.bFld Test.iFld1 Test.fFld = " + (bFld ? 1 : 0) + "," + iFld1 + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -8173476577053773151L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      fMeth_check_sum = 0L;
   }
}
