public class Test {
   public static final int N = 400;
   public static long instanceCount = -3139461427362276786L;
   public int iFld = 191;
   public static double dFld = 1.385;
   public static float fFld = -22.27F;
   public static boolean bFld = true;
   public static byte byFld = 7;
   public static int iFld1 = -39535;
   public static int[] iArrFld = new int[400];
   public long[] lArrFld = new long[400];
   public static short[][] sArrFld = new short[400][400];
   public static long iMeth_check_sum;
   public static long lMeth_check_sum;
   public static long fMeth_check_sum;

   public static float fMeth() {
      boolean var0 = true;
      int var1 = 128;
      int var2 = 45101;
      int var3 = 229;
      int var4 = -111;
      int var5 = 23381;
      boolean var6 = true;
      short var7 = 18441;

      int var10;
      for(var10 = 5; 385 > var10; ++var10) {
         if (!var6) {
            var1 = (int)instanceCount;
            dFld = (double)var2;
            if (!var6) {
               if (var6) {
                  var1 += (int)instanceCount;
               } else {
                  var1 += var10;
               }
            } else {
               switch (var10 % 2 * 5 + 78) {
                  case 80:
                     var4 *= var5;
                     break;
                  case 81:
                     var3 = 1;

                     while(4 > var3) {
                        var5 = 1;

                        while(true) {
                           ++var5;
                           if (var5 >= 2) {
                              var1 -= var7;
                              instanceCount = (long)((float)instanceCount + ((float)(var3 * var1) + fFld - (float)var1));
                              var2 = (int)((float)var2 + ((float)var3 - fFld));
                              ++var3;
                              break;
                           }

                           iArrFld[var3] = var7;
                        }
                     }

                     var4 = (int)((long)var4 + ((long)var10 | (long)fFld));
                     var1 += var10;
                     break;
                  default:
                     var2 *= (int)fFld;
               }
            }
         }
      }

      long var8 = (long)(var10 + var1 + (var6 ? 1 : 0) + var2 + var3 + var4 + var5 + var7);
      fMeth_check_sum += var8;
      return (float)var8;
   }

   public static long lMeth() {
      int var0 = -11547;
      int var1 = -13;
      int var2 = -12;
      byte var3 = -14;
      short var4 = 13755;
      long var5 = -3919467807L;
      int[] var7 = iArrFld;
      int var8 = var7.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         int var10 = var7[var9];

         int[] var12;
         for(var0 = 1; var0 < 4; ++var0) {
            var4 = --sArrFld[var0][var0 + 1];
            var10 += (int)(-(--dFld * (double)fMeth()));
            var5 = 1L;

            do {
               var12 = iArrFld;
               var12[(int)(var5 + 1L)] *= var10;
               instanceCount -= (long)fFld;
               iArrFld[var0 + 1] = (int)instanceCount;
               bFld = bFld;
               var1 -= var10;
            } while(++var5 < 2L);
         }

         fFld = (float)var0;
         var12 = iArrFld;
         var12[193] <<= var10;

         for(var2 = 1; var2 < 4; ++var2) {
            fFld *= (float)var10;
            var1 = (int)((long)var1 + ((long)var2 * var5 + (long)var2 - (long)var10));
         }
      }

      long var11 = (long)(var0 + var1 + var4) + var5 + (long)var2 + (long)var3;
      lMeth_check_sum += var11;
      return var11;
   }

   public static int iMeth() {
      boolean var0 = true;
      int var1 = 180;
      boolean var2 = false;
      boolean var3 = true;
      short var4 = 21521;
      int var5 = -5;
      int var6 = -28;
      short var7 = -166;
      int var10 = 172;

      do {
         var1 += var10 * var10;
         lMeth();
         var1 += 8740;
         --var10;
      } while(var10 > 0);

      var1 *= var10;
      int var11 = 1;

      int var12;
      do {
         int[] var10000 = iArrFld;
         var10000[var11] |= var11;

         for(var12 = 1; var12 < 4; ++var12) {
            byFld = (byte)((int)instanceCount);

            for(var5 = var11; var5 < 2; ++var5) {
               var1 &= var6;
               var6 = (int)((float)var6 + ((float)(var5 * var1 + byFld) - fFld));
            }

            if (iFld1 != 0) {
            }

            var10000 = iArrFld;
            var10000[var12 - 1] -= -2;
            var7 = var4;
         }

         ++var11;
      } while(var11 < 391);

      long var8 = (long)(var10 + var1 + var11 + var12 + var4 + var5 + var6 + var7);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      float var2 = -103.274F;
      float[] var3 = new float[400];
      boolean var4 = true;
      int var5 = -6;
      int var6 = -65;
      int var7 = 13;
      int var8 = -34669;
      boolean var9 = false;
      double[] var10 = new double[400];
      FuzzerUtils.init(var3, -91.144F);
      FuzzerUtils.init(var10, -1.58);
      var2 *= (float)(this.iFld |= Math.abs((int)(dFld + (double)this.iFld)));
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 132) {
            FuzzerUtils.out.println("f i i1 = " + Float.floatToIntBits(var2) + "," + var12 + "," + var5);
            FuzzerUtils.out.println("i2 b i22 = " + var6 + "," + (var9 ? 1 : 0) + "," + var7);
            FuzzerUtils.out.println("i23 fArr dArr = " + var8 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var3)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)));
            FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
            FuzzerUtils.out.println("Test.fFld Test.bFld Test.byFld = " + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0) + "," + byFld);
            FuzzerUtils.out.println("Test.iFld1 Test.iArrFld lArrFld = " + iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
            FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
            FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
            FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            return;
         }

         iArrFld[var12] = (int)(this.lArrFld[var12 + 1] = this.lArrFld[var12]);

         label60:
         for(var5 = 11; var5 < 190; ++var5) {
            float var11 = 0.547F;
            int var10000 = -(-(var12 - var5)) + var6;
            int[] var10001 = iArrFld;
            int var10002 = var12 + 1;
            int var10004 = var10001[var12 + 1];
            var10001[var10002] = var10001[var12 + 1] + 1;
            var6 = var10000 + Math.abs(var10004);
            if (var9) {
               break;
            }

            var3[var12 - 1] *= (float)(-this.iFld);
            --var6;
            instanceCount = (long)var6;
            this.iFld <<= (int)((long)Math.abs(Integer.reverseBytes(23015)) * (instanceCount-- + (long)Integer.reverseBytes(-240)));
            switch (var5 % 6 + 35) {
               case 35:
                  int[] var14 = iArrFld;
                  var14[var5] %= iMeth() | 1;
                  this.iFld -= var6;
                  iArrFld[var12] = (int)instanceCount;
                  var7 = 2;

                  while(true) {
                     if (var7 <= 1) {
                        continue label60;
                     }

                     switch (var7 % 5 + 120) {
                        case 120:
                           var6 *= (int)var2;
                           if (bFld) {
                              this.iFld -= var6;
                              instanceCount ^= instanceCount;
                           } else {
                              var8 = var12;
                              iFld1 += var7;
                              var2 += (float)var7;
                              this.iFld = this.iFld;
                           }
                           break;
                        case 121:
                           iFld1 = (int)((float)iFld1 + ((float)var7 - fFld));
                           break;
                        case 122:
                           iFld1 *= -4321;
                           var14 = iArrFld;
                           var14[var5 - 1] += (int)instanceCount;
                           var2 += (float)(var7 * var12);
                           instanceCount *= -55L;
                           break;
                        case 123:
                           instanceCount += (long)(3 + var7 * var7);
                           instanceCount += (long)var2;
                           break;
                        case 124:
                           var6 += var7;
                     }

                     var7 -= 2;
                  }
               case 36:
                  this.iFld += var5 + var8;
                  break;
               case 37:
                  float var13 = var11 + (float)(var5 * this.iFld + var12 - var12);
               case 38:
                  if (bFld) {
                  }
                  break;
               case 39:
                  this.iFld = var7;
               case 40:
               default:
                  var10[var5 - 1] = (double)var12;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-10);
      FuzzerUtils.init((short[][])sArrFld, (short)27125);
      iMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
   }
}
