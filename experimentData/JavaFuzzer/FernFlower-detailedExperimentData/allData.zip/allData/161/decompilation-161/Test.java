public class Test {
   public static final int N = 400;
   public static long instanceCount = -3479512115273054217L;
   public static volatile short sFld = 7380;
   public static float fFld = 1.146F;
   public static boolean bFld = false;
   public static byte byFld = -60;
   public static long[] lArrFld = new long[400];
   public boolean[][] bArrFld = new boolean[400][400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth() {
      int var0 = 8;
      int var1 = -60145;
      int var2 = -19194;
      int var3 = 8;
      int[] var4 = new int[400];
      byte var5 = -98;
      FuzzerUtils.init((int[])var4, (int)40232);
      var0 += (int)fFld;
      var0 += var0;
      var0 = (int)instanceCount;
      long[] var6 = lArrFld;
      int var7 = var6.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         long var9 = var6[var8];
         var1 = (int)instanceCount;
         var4[(var1 >>> 1) % 400] = (int)instanceCount;
         var9 -= var9;
         var4[(var1 >>> 1) % 400] -= var0;

         for(var2 = 1; var2 < 4; ++var2) {
            var5 = (byte)var2;
            var0 = var2;
            byte var11 = -89;
            var3 = var2 - 252;
            var1 = var11 - (int)fFld;
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var5) + FuzzerUtils.checkSum(var4);
   }

   public static int iMeth1(int var0) {
      int var1 = -59434;
      short var2 = 11177;
      int var3 = -138;
      int var4 = -53;
      long var5 = 4L;
      var1 = 1;

      while(true) {
         ++var1;
         if (var1 >= 325) {
            long var7 = (long)(var0 + var1) + var5 + (long)var2 + (long)var3 + (long)var4;
            iMeth1_check_sum += var7;
            return (int)var7;
         }

         var0 -= (int)((float)var1 + --fFld + (float)(var0 * var1));
         vMeth();
         var0 |= -5;
         var0 -= (int)instanceCount;
         bFld = false;

         for(var5 = 5L; var5 > 1L; var5 -= 3L) {
            var2 = 58;

            for(var3 = 1; var3 < 5; ++var3) {
            }

            fFld = (float)var0;
            var4 += (int)fFld;
            var4 = sFld;
         }
      }
   }

   public static int iMeth() {
      boolean var0 = true;
      boolean var1 = true;
      int var2 = -8245;
      long var3 = -30168L;
      double var5 = 2.5068;
      int var9 = 1;

      int var10;
      do {
         iMeth1(var9);
         var10 = 1;

         do {
            if (var10 != 0) {
            }

            for(var3 = 1L; var3 < 1L; ++var3) {
               fFld -= (float)var10;
               long[] var10000 = lArrFld;
               var10000[(int)var3] += (long)var9;
               var2 += 34004;
               var5 = (double)var2;
               instanceCount += var3 * var3 + (long)var9 - instanceCount;
               var2 *= var2;
               switch ((int)(var3 % 8L * 5L + 59L)) {
                  case 62:
                     var2 <<= var9;
                     break;
                  case 66:
                     var2 = var2;
                  case 60:
                     byFld <<= -17;
                  case 91:
                     instanceCount >>= (int)instanceCount;
                  case 85:
                     var2 += (int)(var3 * (long)var9 + instanceCount - (long)var9);
                     break;
                  case 70:
                     var2 += (int)(var3 ^ (long)var2);
                     break;
                  case 89:
                     if (var2 != 0) {
                     }
                     break;
                  case 95:
                     fFld = -53.574F;
                     instanceCount >>= 63;
                     var2 = 2;
                     break;
                  default:
                     fFld = (float)var10;
               }
            }

            ++var10;
         } while(var10 < 7);

         ++var9;
      } while(var9 < 221);

      long var7 = (long)(var9 + var10) + var3 + (long)var2 + Double.doubleToLongBits(var5);
      iMeth_check_sum += var7;
      return (int)var7;
   }

   public void mainTest(String[] var1) {
      int var2 = -8627;
      boolean var3 = true;
      int var4 = -106;
      int var5 = 47758;
      int var6 = -59;
      int var7 = 53087;
      short var8 = -183;
      int var9 = 11387;
      byte var10 = 57;
      int[][] var11 = new int[400][400];
      double var12 = -9.3033;
      long var14 = -11L;
      FuzzerUtils.init((int[][])var11, (int)26369);
      instanceCount <<= sFld - var2 + (var2 ^ var2) + iMeth();
      var11[(var2 >>> 1) % 400][381] >>= (int)instanceCount;

      int var18;
      for(var18 = 7; var18 < 171; ++var18) {
         var2 = (int)var12;
         var4 = var2;
         if (bFld) {
            this.bArrFld[var18][var18 + 1] = bFld;
            fFld *= (float)var18;
         }

         for(var5 = 7; 153 > var5; ++var5) {
            instanceCount |= -37278L;
            var11[var5][var18 + 1] = var6;
         }

         switch (var18 % 2 + 53) {
            case 53:
               instanceCount -= (long)var2;

               try {
                  var2 = var6 % -244;
                  var6 = var11[var18 - 1][var18 - 1] % -146;
                  var2 = var6 / -37733;
               } catch (ArithmeticException var17) {
               }

               var6 = (int)instanceCount;
               continue;
            case 54:
               fFld += (float)(var18 * var18);
               continue;
            default:
               var4 = var2 << var2;
               var7 = var18;
         }

         while(153 > var7) {
            switch (var7 % 2 + 80) {
               case 80:
               case 81:
                  var11[var7 + 1][var7 + 1] >>>= var18;
                  var2 -= var5;
                  var6 -= var6;
                  var12 = (double)var7;
               default:
                  var6 = (int)instanceCount;
                  var4 = var8;
                  var6 = var2;
                  var9 = 1;
            }

            while(var9 > 1) {
               var4 = var10;
               var14 = (long)var5;
               var11[var7 + 1][var7 + 1] -= (int)fFld;
               --var9;
            }

            ++var7;
         }
      }

      FuzzerUtils.out.println("i i13 i14 = " + var2 + "," + var18 + "," + var4);
      FuzzerUtils.out.println("d1 i15 i16 = " + Double.doubleToLongBits(var12) + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i17 i18 i19 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i20 l3 iArr1 = " + var10 + "," + var14 + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + sFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld Test.byFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + byFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("bArrFld = " + FuzzerUtils.checkSum(this.bArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -3705431464775492841L);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
