public class Test {
   public static final int N = 400;
   public static long instanceCount = 1723977013L;
   public byte byFld = 15;
   public volatile float fFld = -93.335F;
   public static int[] iArrFld = new int[400];
   public boolean[][][] bArrFld = new boolean[400][400][400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static int iMeth(int var0) {
      --var0;
      long var1 = (long)var0;
      iMeth_check_sum += var1;
      return (int)var1;
   }

   public static void vMeth2() {
      short var0 = 172;
      vMeth2_check_sum += (long)var0;
   }

   public static void vMeth1() {
      int var0 = 53;
      int var1 = -58396;
      short var2 = -8681;
      int var3 = -8;
      int var4 = 11268;
      short var5 = 21390;
      byte var6 = 36;
      boolean var7 = false;
      short[] var8 = new short[400];
      FuzzerUtils.init((short[])var8, (short)7937);
      vMeth2();
      var0 &= (int)instanceCount;

      for(var1 = 3; var1 < 226; ++var1) {
         var6 = (byte)var2;
         var2 = var2;
         instanceCount += 26L;
         var3 = 1;

         while(!var7) {
            var7 = var7;

            for(var4 = 1; 1 > var4; ++var4) {
               int var10000 = var0 + (var4 ^ var5);
               var0 = (int)instanceCount;
               var10000 = var5 + var4;
               var8[var1 + 1] >>>= (short)var0;
               var5 = 225;
            }

            ++var3;
            if (var3 >= 7) {
               break;
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var6 + var3 + (var7 ? 1 : 0) + var4 + var5) + FuzzerUtils.checkSum(var8);
   }

   public static void vMeth(float var0) {
      boolean var1 = true;
      boolean var2 = true;
      int var3 = 64798;
      int var4 = -1;
      short var5 = -23269;
      int var8 = 1;

      while(true) {
         ++var8;
         if (var8 >= 224) {
            int var9;
            for(var9 = 173; var9 > 2; var9 -= 3) {
               instanceCount ^= (long)var9;
               switch (119) {
                  case 119:
                     var3 = var9 * -110;
                     iArrFld[var9] = var9;
                     switch (var9 % 2 + 61) {
                        case 61:
                           instanceCount = (long)var8;

                           try {
                              var3 = var9 % var9;
                              var3 = '釩' % var3;
                              var3 = -10 / var3;
                           } catch (ArithmeticException var7) {
                           }

                           var3 = var9;
                           continue;
                        case 62:
                           var5 = (short)var4;
                           instanceCount <<= var3;
                           var4 -= var8;
                        default:
                           continue;
                     }
                  default:
                     var4 -= 24524;
               }
            }

            vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var8 + var9 + var3 + var5 + var4);
            return;
         }

         vMeth1();
      }
   }

   public void mainTest(String[] var1) {
      int var2 = -138;
      boolean var3 = true;
      boolean var4 = true;
      short var5 = -12281;
      double var6 = 0.124347;
      double[] var8 = new double[400];
      long[][] var9 = new long[400][400];
      FuzzerUtils.init(var9, 1447614521L);
      FuzzerUtils.init(var8, 45.35738);
      ++var2;
      var2 = (int)((long)var2 * (long)(12 + iMeth(-56875)) * instanceCount);
      var2 <<= -21451 + --this.byFld;
      vMeth(this.fFld);
      var9[(var2 >>> 1) % 400] = var9[(var2 >>> 1) % 400];
      int var10 = 1;

      int var11;
      do {
         var8[var10 + 1] = -126.10907;

         for(var11 = 101; var11 > 6; var11 -= 2) {
            this.bArrFld[var11 - 1][var11 - 1] = this.bArrFld[var11 + 1][var11 - 1];
            var2 = 43276;
            this.byFld += (byte)var11;
         }

         var2 = (int)((long)var2 + ((long)var10 ^ instanceCount));
         ++var10;
      } while(var10 < 248);

      FuzzerUtils.out.println("i d i13 = " + var2 + "," + Double.doubleToLongBits(var6) + "," + var10);
      FuzzerUtils.out.println("i14 i15 lArr = " + var11 + "," + var5 + "," + FuzzerUtils.checkSum(var9));
      FuzzerUtils.out.println("dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var8)));
      FuzzerUtils.out.println("Test.instanceCount byFld fFld = " + instanceCount + "," + this.byFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.iArrFld bArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.bArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)33391);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
