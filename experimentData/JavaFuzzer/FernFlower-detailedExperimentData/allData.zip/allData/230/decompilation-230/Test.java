public class Test {
   public static final int N = 400;
   public static long instanceCount = -27496L;
   public static short sFld = -10814;
   public static long lFld = 15L;
   public static float fFld = -2.144F;
   public int iFld = 2;
   public static int[] iArrFld = new int[400];
   public static double[] dArrFld = new double[400];
   public float[] fArrFld = new float[400];
   public volatile long[] lArrFld = new long[400];
   public static volatile short[] sArrFld = new short[400];
   public static long vMeth_check_sum;
   public static long byMeth_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(int var0, int var1) {
      float var2 = -1.864F;
      boolean var3 = true;
      int var4 = -161;
      byte var5 = -32;
      short[] var6 = new short[400];
      FuzzerUtils.init((short[])var6, (short)633);
      var1 += var1;
      var2 -= -104.0F;
      instanceCount = (long)var0;

      int var10;
      for(var10 = 6; var10 < 133; ++var10) {
         var2 -= (float)var10;
         instanceCount += (long)(var10 * var4 + var0) - instanceCount;
         var5 *= (byte)((int)var2);
         var4 += var10;
         short var9 = -187;
         int[] var10000 = iArrFld;
         var10000[var10] -= var9;
         var0 = var9 >> -1611071117;
         var4 *= (int)instanceCount;
      }

      var1 += var0;
      var0 -= (int)var2;
      long var7 = (long)(var0 + var1 + Float.floatToIntBits(var2) + var10 + var4 + var5) + FuzzerUtils.checkSum(var6);
      iMeth_check_sum += var7;
      return (int)var7;
   }

   public static byte byMeth(double var0, double var2) {
      int var4 = -12800;
      boolean var5 = true;
      int var6 = 4;
      int var7 = -17016;
      int var8 = -25;
      int var9 = 38233;
      float var10 = 1.402F;
      long var11 = 4385430486641923231L;
      long[] var13 = new long[400];
      FuzzerUtils.init(var13, -3028360344L);
      var4 -= -iMeth(var4, var4);
      var4 -= var4;
      instanceCount = instanceCount;
      var4 *= (int)var10;

      int var16;
      for(var16 = 8; var16 < 192; ++var16) {
         var11 = 1L;

         while(++var11 < 9L) {
            for(var7 = 1; var7 < 1; ++var7) {
               var9 += var7 ^ var9;
               var9 = (int)var11;
               --var6;
               var8 >>= var16;
               var9 -= var16;
               var13[var7 + 1] &= var11;
               instanceCount += (long)(-23950 + var7 * var7);
               instanceCount += (long)var2;
            }
         }
      }

      long var14 = Double.doubleToLongBits(var0) + Double.doubleToLongBits(var2) + (long)var4 + (long)Float.floatToIntBits(var10) + (long)var16 + (long)var6 + var11 + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var13);
      byMeth_check_sum += var14;
      return (byte)((int)var14);
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = -105;
      int var2 = 95;
      int var3 = 3;
      int var4 = -204;
      double var5 = 53.30768;
      byte var7 = -107;
      byte[] var8 = new byte[400];
      FuzzerUtils.init((byte[])var8, (byte)110);

      int var11;
      for(var11 = 155; var11 > 9; var11 -= 3) {
         var1 += var11 * var11 + var1 - var11;

         for(var2 = 32; var2 > 2; --var2) {
            var4 = 1;

            while(true) {
               ++var4;
               if (var4 >= 2) {
                  lFld *= (long)var7;
                  lFld += (long)(var2 + var3);
                  var3 -= var7;

                  try {
                     int var10000 = var2 / iArrFld[var11 - 1];
                     var1 = var4 / 1595;
                     var1 = -523912631 / var11;
                  } catch (ArithmeticException var10) {
                  }
                  break;
               }

               var1 <<= byMeth(var5, var5);
               instanceCount += (long)var5;
               iArrFld[var4 + 1] = var3;
               instanceCount >>= var1;
               sFld = (short)(sFld + 69);
               var3 >>= var7;
               var8[var11] = (byte)((int)instanceCount);
            }
         }
      }

      vMeth_check_sum += (long)(var11 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var5) + (long)var7 + FuzzerUtils.checkSum(var8);
   }

   public void mainTest(String[] var1) {
      byte var2 = -21;
      double var3 = 34.66381;
      double var5 = 0.22094;
      int var7 = 210;
      int var8 = -35805;
      byte var9 = -6;
      char var10 = '댤';
      byte var11 = 94;
      byte var12 = -5;
      boolean var13 = true;
      instanceCount *= instanceCount % (long)(Math.abs((int)((double)var2 + -97.127346)) | 1);
      vMeth();

      for(var3 = 8.0; var3 < 287.0; ++var3) {
         if (var13) {
            var7 += (int)instanceCount;
            var7 += (int)var3;
            var2 = 12;
         } else if (var13) {
            instanceCount -= (long)this.iFld;
         } else {
            var7 = var12;
         }
      }

      FuzzerUtils.out.println("s d4 i15 = " + var2 + "," + Double.doubleToLongBits(var3) + "," + var7);
      FuzzerUtils.out.println("i16 i17 i18 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i19 b i20 = " + var11 + "," + (var13 ? 1 : 0) + "," + var12);
      FuzzerUtils.out.println("d5 = " + Double.doubleToLongBits(var5));
      FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.lFld = " + instanceCount + "," + sFld + "," + lFld);
      FuzzerUtils.out.println("Test.fFld iFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.dArrFld fArrFld lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)101);
      FuzzerUtils.init(dArrFld, -2.101023);
      FuzzerUtils.init(sArrFld, (short)-6577);
      vMeth_check_sum = 0L;
      byMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
