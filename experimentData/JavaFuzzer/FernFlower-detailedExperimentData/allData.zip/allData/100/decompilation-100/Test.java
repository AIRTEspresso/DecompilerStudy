public class Test {
   public static final int N = 400;
   public static long instanceCount = -164L;
   public static int iFld = -191;
   public static short sFld = 9040;
   public static float fFld = 6.937F;
   public boolean bFld = true;
   public static int[] iArrFld = new int[400];
   public static short[] sArrFld = new short[400];
   public static long[] lArrFld = new long[400];
   public byte[] byArrFld = new byte[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, int var1) {
      boolean var2 = true;
      int var3 = -12;
      int var4 = -100;
      int var5 = 61712;
      byte var6 = 2;
      int[][][] var7 = new int[400][400][400];
      float var8 = -1.207F;
      short var9 = -15259;
      short[] var10 = new short[400];
      FuzzerUtils.init(var10, (short)-26343);
      FuzzerUtils.init((Object[][])var7, -43);
      var10[45] = (short)(var10[45] >> 5587);

      int var13;
      for(var13 = 5; var13 < 232; ++var13) {
         instanceCount += (long)(var13 | var13);
         var4 = 1;

         do {
            var0 = (int)instanceCount;
            var8 -= (float)var9;
            ++var4;
         } while(var4 < 7);

         iFld = iFld;
         var3 = (int)instanceCount;
         iFld = var4;

         for(var5 = var13; var5 < 7; ++var5) {
            var7[var13][var13 + 1][var13 + 1] = iFld;
            var0 = var1;
            var6 = -9;

            try {
               var7[var13 - 1][(iFld >>> 1) % 400][var13] = -28 / iFld;
               var3 = iFld / 120;
               var3 = iFld % var3;
            } catch (ArithmeticException var12) {
            }

            var3 += 167;
         }
      }

      vMeth2_check_sum += (long)(var0 + var1 + var13 + var3 + var4 + Float.floatToIntBits(var8) + var9 + var5 + var6) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum((Object[][])var7);
   }

   public static void vMeth1(int var0) {
      int var1 = 64905;
      int var2 = 14;
      int var3 = -144;
      int var4 = 55921;
      int var5 = 10;
      float var6 = 93.277F;
      double var7 = 122.97533;
      long[] var9 = new long[400];
      boolean[] var10 = new boolean[400];
      FuzzerUtils.init(var9, -6530L);
      FuzzerUtils.init(var10, true);
      vMeth2(var0, iFld);
      var1 = 1;

      while(true) {
         ++var1;
         if (var1 >= 332) {
            vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + Float.floatToIntBits(var6)) + Double.doubleToLongBits(var7) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var10);
            return;
         }

         label45:
         for(var2 = 1; 5 > var2; ++var2) {
            int[] var10000 = iArrFld;
            var10000[var1 - 1] += var0;
            var3 = sFld;
            switch (var2 % 5 + 124) {
               case 124:
                  var4 = 2;

                  while(true) {
                     if (var4 <= 1) {
                        continue label45;
                     }

                     var0 += var4 * iFld;
                     var3 = (int)((float)var3 + ((float)var4 * var6 + (float)var2 - (float)var5));
                     switch (var2 % 9 + 54) {
                        case 54:
                           var0 += -10 + var4 * var4;
                           var6 += (float)var1;
                           sFld -= (short)var4;
                        case 55:
                           var7 += (double)var3;
                        case 56:
                        default:
                           break;
                        case 57:
                           var5 += var4 * var0 + sFld - var1;
                           break;
                        case 58:
                           var5 = var1;
                           break;
                        case 59:
                           iFld = var0;
                           break;
                        case 60:
                           var9[var4 + 1] &= (long)iFld;
                           break;
                        case 61:
                           var10[var2 - 1] = true;
                           break;
                        case 62:
                           instanceCount += (long)(var4 | var0);
                     }

                     var4 -= 3;
                  }
               case 125:
               case 126:
                  instanceCount += (long)(var2 * var1) + instanceCount - (long)var0;
                  break;
               case 127:
                  iFld = 30724;
               case 128:
                  var9[var1] += instanceCount;
            }
         }
      }
   }

   public static void vMeth(int var0, int var1) {
      boolean var2 = true;
      int var3 = 4341;
      int var4 = -21348;
      int var5 = 18502;
      int var6 = -12;
      byte var7 = -5;
      int var8 = -37552;
      byte var9 = -9;
      double var10 = 10.11893;

      int var12;
      for(var12 = 6; var12 < 344; ++var12) {
         vMeth1(var0);

         for(var4 = var12; var4 < 5; ++var4) {
            for(var6 = 1; 1 > var6; ++var6) {
               var0 = (int)instanceCount;
               var10 = (double)instanceCount;
               var10 = (double)var4;
            }

            var5 = 105465785;

            for(var8 = 1; var8 < 1; ++var8) {
               int var10000 = var3 - (int)var10;
               instanceCount = (long)fFld;
               var3 = (int)fFld;
               var5 += var8 * var8;
               fFld -= -11.0F;
               instanceCount -= 104L;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var12 + var3 + var4 + var5 + var6 + var7) + Double.doubleToLongBits(var10) + (long)var8 + (long)var9;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -56;
      int var4 = -143;
      int var5 = -15659;
      int var6 = -214;
      int var7 = -59920;
      int var8 = 14;
      short var9 = -144;
      int var10 = 40380;
      int[] var11 = new int[400];
      long var12 = 12L;
      double var14 = 0.22206;
      FuzzerUtils.init((int[])var11, (int)25274);
      vMeth(iFld, iFld);

      int var16;
      for(var16 = 9; var16 < 163; ++var16) {
         int[] var10000;
         for(var4 = var16; var4 < 163; ++var4) {
            var10000 = iArrFld;
            var10000[var16 + 1] *= var3;

            for(var12 = 1L; ++var12 < 1L; instanceCount = (long)var3) {
               sArrFld = sArrFld;
               iFld -= var5;
            }
         }

         for(var6 = 9; var6 < 163; ++var6) {
            var3 = (int)fFld;
            var14 = 37426.0;
            var11[var6] += (int)var12;
            iFld = (int)fFld;
            var5 -= var4;
            var7 += (int)instanceCount;

            for(var8 = var6; var8 < 2; ++var8) {
               var5 += var9;
               iArrFld = iArrFld;
               var5 -= var5;
               instanceCount += (long)var5;
            }

            var10 = 1;

            do {
               var10000 = iArrFld;
               var10000[var6] *= iFld;
               var10000 = iArrFld;
               var10000[var16 - 1] <<= (int)var12;
               instanceCount <<= var9;
               var3 += var10;
               if (!this.bFld) {
                  instanceCount = (long)var3;
                  long[] var17 = lArrFld;
                  var17[var6] -= (long)var16;
               }

               ++var10;
            } while(var10 < 2);

            iFld >>>= var8;
         }

         this.byArrFld = this.byArrFld;
      }

      FuzzerUtils.out.println("i23 i24 i25 = " + var16 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i26 l i27 = " + var5 + "," + var12 + "," + var6);
      FuzzerUtils.out.println("i28 d2 i29 = " + var7 + "," + Double.doubleToLongBits(var14) + "," + var8);
      FuzzerUtils.out.println("i30 i31 iArr1 = " + var9 + "," + var10 + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + sFld);
      FuzzerUtils.out.println("Test.fFld bFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.sArrFld Test.lArrFld byArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)41383);
      FuzzerUtils.init((short[])sArrFld, (short)16014);
      FuzzerUtils.init(lArrFld, -2009317289L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
