public class Test {
   public static final int N = 400;
   public static long instanceCount = 2L;
   public static double dFld = -1.43384;
   public boolean bFld = true;
   public static byte byFld = 18;
   public static long vSmallMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1() {
      int var0 = 52282;
      char var1 = '更';
      int var2 = -36503;
      int var3 = -192;
      int var4 = 26016;
      int[] var5 = new int[400];
      float var6 = 1.23F;
      short var7 = -7560;
      long var8 = 44635L;
      long[] var10 = new long[400];
      byte[] var11 = new byte[400];
      FuzzerUtils.init(var10, 2555038843L);
      FuzzerUtils.init((int[])var5, (int)-21805);
      FuzzerUtils.init((byte[])var11, (byte)88);

      for(var0 = 266; var0 > 9; --var0) {
         var10[var0 - 1] = (long)var0;
         instanceCount >>= (int)instanceCount;

         for(var2 = 6; var2 > 1; --var2) {
            var5[var0] += 38549;
            var3 += var4;
            var6 += (float)(21722 + var2 * var2);
            dFld = (double)var7;
         }

         instanceCount += (long)(69 + var0 * var0);
         var4 >>>= var3;
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var6) + var7) + var8 + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var11);
   }

   public static void vMeth(boolean var0, int var1, int var2) {
      boolean var3 = true;
      short var4 = -210;
      int var5 = 61;
      byte var6 = 12;
      float var7 = -115.688F;
      vMeth1();
      byte var8 = 6;
      if (var8 < 125) {
         for(var5 = 1; var5 < 13; ++var5) {
            instanceCount = instanceCount;
            instanceCount = (long)var1;
         }
      }

      vMeth_check_sum += (long)((var0 ? 1 : 0) + var1 + var2 + var8 + var4 + var5 + var6 + Float.floatToIntBits(var7));
   }

   public static void vSmallMeth() {
      boolean var0 = false;
      short var1 = -242;
      int[] var2 = new int[400];
      FuzzerUtils.init((int[])var2, (int)-8);
      vMeth(var0, var1, var1);
      var2[10] = 96;
      vSmallMeth_check_sum += (long)((var0 ? 1 : 0) + var1) + FuzzerUtils.checkSum(var2);
   }

   public void mainTest(String[] var1) {
      int var2 = 20767;
      int var3 = -171;
      int var4 = 53658;
      int var5 = -63109;
      int var6 = -14385;
      int var7 = 3691;
      int var8 = -14208;
      int var9 = 8;
      int var10 = 4;
      int[] var11 = new int[400];
      float var12 = 16.997F;
      float var13 = -53.762F;
      float var14 = 47.1005F;
      short var15 = -15362;
      double[][][] var16 = new double[400][400][400];
      FuzzerUtils.init((int[])var11, (int)73);
      FuzzerUtils.init((Object[][])var16, 36.7684);

      for(int var17 = 0; var17 < 675; ++var17) {
         vSmallMeth();
      }

      instanceCount = (long)var2;
      var12 = 172.0F;

      while((var12 -= 2.0F) > 0.0F) {
         for(var13 = var12; var13 < 291.0F; var13 += 2.0F) {
            dFld -= -4.0;
            int var10000 = var2 + (int)var13;
            instanceCount += -14L;
            instanceCount = -38L;
            var2 = var3;
         }

         var2 += (int)instanceCount;

         for(var4 = 4; var4 < 291; ++var4) {
            for(var6 = 1; var6 < 2; ++var6) {
               dFld = (double)var5;
               var3 &= var6;
               var15 = (short)(var15 + 15259);
            }

            for(var8 = 1; 2 > var8; ++var8) {
               var7 *= var4;
               var3 = var15;
               if (this.bFld) {
                  var5 = (int)instanceCount;
                  var9 += var8;
                  if (this.bFld) {
                  }
               } else {
                  var2 = (int)((long)var2 + ((long)var8 - instanceCount));
                  var7 += (int)instanceCount;
                  var11[(int)(var12 + 1.0F)] += 10;
                  switch ((var7 >>> 1) % 10 + 127) {
                     case 127:
                        var16[var4 - 1][(int)(var12 - 1.0F)][var8 - 1] = (double)var7;
                        break;
                     case 128:
                        dFld += (double)var8;
                        var5 += var8;
                        break;
                     case 129:
                        var5 += -192 + var8 * var8;
                        break;
                     case 130:
                        var9 -= var6;
                     case 131:
                        var11[var4] += var6;
                        break;
                     case 132:
                        var14 += (float)instanceCount;
                        break;
                     case 133:
                        var7 ^= (int)instanceCount;
                        break;
                     case 134:
                        var2 = byFld;
                        break;
                     case 135:
                        instanceCount += (long)var2;
                     case 136:
                        var3 = var15 ^ var4;
                        break;
                     default:
                        var10 = (int)((float)var10 + ((float)((long)var8 * instanceCount) + var13 - (float)instanceCount));
                  }
               }
            }
         }
      }

      FuzzerUtils.out.println("i12 f2 f3 = " + var2 + "," + Float.floatToIntBits(var12) + "," + Float.floatToIntBits(var13));
      FuzzerUtils.out.println("i13 i14 i15 = " + var3 + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i16 i17 s1 = " + var6 + "," + var7 + "," + var15);
      FuzzerUtils.out.println("i18 i19 f4 = " + var8 + "," + var9 + "," + Float.floatToIntBits(var14));
      FuzzerUtils.out.println("i20 iArr2 dArr = " + var10 + "," + FuzzerUtils.checkSum(var11) + "," + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var16)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.byFld = " + byFld);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
