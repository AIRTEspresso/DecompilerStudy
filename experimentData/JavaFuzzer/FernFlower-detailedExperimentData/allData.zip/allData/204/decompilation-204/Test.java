public class Test {
   public static final int N = 400;
   public static long instanceCount = -3981599709L;
   public static int iFld = -11;
   public byte byFld = -35;
   public static double dFld = -94.5653;
   public short sFld = 18050;
   public static int[] iArrFld = new int[400];
   public int[] iArrFld1 = new int[400];
   public float[] fArrFld = new float[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0, int var1, int var2) {
      int var3;
      int var4;
      short var5;
      int var6;
      float var7;
      float[] var8;
      float[] var9;
      byte var10;
      double var11;
      double[] var13;
      var3 = -13;
      var4 = -219;
      var5 = -31463;
      var6 = -45;
      var7 = 89.338F;
      var8 = new float[400];
      var9 = new float[400];
      var10 = 58;
      var11 = 62.6696;
      var13 = new double[400];
      FuzzerUtils.init(var8, -40.14F);
      FuzzerUtils.init(var9, -2.17F);
      FuzzerUtils.init(var13, 0.54139);
      label43:
      switch ((var2 >>> 1) % 9 * 5 + 51) {
         case 53:
            var0 = var3;
         default:
            iArrFld[(var5 >>> 1) % 400] = -20974;
            break;
         case 72:
            iArrFld[(var4 >>> 1) % 400] = var5;
            break;
         case 75:
            var11 += (double)var0;
            break;
         case 79:
            var3 = 1;

            while(true) {
               var8[var3 + 1] = var7;

               for(var4 = 1; var4 < 12; ++var4) {
                  var2 >>= var0;
                  instanceCount -= (long)var0;
                  var6 = 1;

                  while(true) {
                     ++var6;
                     if (var6 >= 2) {
                        break;
                     }

                     var9[var6 - 1] = (float)var10;
                     if (var3 != 0) {
                     }

                     instanceCount >>= (int)instanceCount;
                     instanceCount = (long)iFld;
                     var13[var6 + 1] -= (double)var6;
                     iFld = -82;
                     instanceCount += instanceCount;
                     var8 = var8;
                  }
               }

               ++var3;
               if (var3 >= 131) {
                  break label43;
               }
            }
         case 86:
            var9[(var2 >>> 1) % 400] += (float)instanceCount;
         case 63:
            iArrFld[45] = 69954769;
            break;
         case 89:
            var1 -= var0;
            break;
         case 93:
            var5 = var10;
            break;
         case 96:
            var1 >>= var4;
      }

      long var14 = (long)(var0 + var1 + var2 + var3 + Float.floatToIntBits(var7) + var4 + var5 + var6 + var10) + Double.doubleToLongBits(var11) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
      lMeth_check_sum += var14;
      return var14;
   }

   public static void vMeth(float var0) {
      iArrFld[(iFld >>> 1) % 400] = (int)lMeth(iFld, iFld, iFld);
      vMeth_check_sum += (long)Float.floatToIntBits(var0);
   }

   public static int iMeth(long var0, long var2, int var4) {
      float var5 = -2.233F;
      boolean var6 = true;
      byte var7 = -100;
      var4 -= (int)((long)(++iFld) * (-15174L + var0 * (long)var4));
      if (var6) {
         instanceCount <<= ++iArrFld[(iFld >>> 1) % 400];
      } else if (var6) {
         vMeth(var5);
         var4 += iFld;
         dFld = (double)iFld;
      } else {
         iFld = var4;
         var7 += (byte)((int)var5);
         iFld *= 3478;
         iArrFld[8] = var4;
      }

      int[] var10000 = iArrFld;
      int var10 = (iFld >>> 1) % 400;
      var10000[var10] <<= 16986;
      long var8 = var0 + var2 + (long)var4 + (long)Float.floatToIntBits(var5) + (long)(var6 ? 1 : 0) + (long)var7;
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      float var2 = -2.135F;
      boolean var3 = true;
      int var4 = -41868;
      boolean var5 = true;
      int var6 = 185;
      int var7 = -51621;
      int var8 = 226;
      short var9 = 2081;
      int[][] var10 = new int[400][400];
      boolean var11 = true;
      double[] var12 = new double[400];
      long[] var13 = new long[400];
      FuzzerUtils.init((int[][])var10, (int)1);
      FuzzerUtils.init(var12, 113.58021);
      FuzzerUtils.init(var13, 698108647L);
      int var10000 = iFld;
      byte var10003 = this.byFld;
      this.byFld = (byte)(var10003 - 1);
      iFld = var10000 - var10003;
      iFld = iFld;
      iFld = iMeth(4445328316377560012L, instanceCount, -50883);
      instanceCount *= (long)iFld;
      iFld = iFld;
      var2 += (float)iFld;
      int[] var16 = this.iArrFld1;
      int var10001 = (iFld >>> 1) % 400;
      var16[var10001] += -906;
      this.fArrFld = this.fArrFld;

      int var14;
      for(var14 = 6; var14 < 347; ++var14) {
         instanceCount += (long)var4;
         iFld += -248 + var14 * var14;
      }

      this.sFld += (short)iFld;
      int var15 = 1;

      while(true) {
         while(true) {
            ++var15;
            if (var15 >= 226) {
               FuzzerUtils.out.println("f3 i9 i10 = " + Float.floatToIntBits(var2) + "," + var14 + "," + var4);
               FuzzerUtils.out.println("i11 b1 i12 = " + var15 + "," + (var11 ? 1 : 0) + "," + var6);
               FuzzerUtils.out.println("i13 i14 i15 = " + var7 + "," + var8 + "," + var9);
               FuzzerUtils.out.println("iArr1 dArr1 lArr = " + FuzzerUtils.checkSum(var10) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)) + "," + FuzzerUtils.checkSum(var13));
               FuzzerUtils.out.println("Test.instanceCount Test.iFld byFld = " + instanceCount + "," + iFld + "," + this.byFld);
               FuzzerUtils.out.println("Test.dFld sFld Test.iArrFld = " + Double.doubleToLongBits(dFld) + "," + this.sFld + "," + FuzzerUtils.checkSum(iArrFld));
               FuzzerUtils.out.println("iArrFld1 fArrFld = " + FuzzerUtils.checkSum(this.iArrFld1) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
               FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
               return;
            }

            var11 = var11;
            var10 = var10;
            var12[var15 + 1] = (double)iFld;
            switch (var15 % 2 + 33) {
               case 33:
                  for(var6 = 3; 111 > var6; ++var6) {
                     var7 = 8;
                     var16 = iArrFld;
                     var16[var15 - 1] -= 1613785836;
                     iFld *= var14;
                     if (var11) {
                        break;
                     }

                     for(var8 = 2; var8 > 1; --var8) {
                        var10[var8] = this.iArrFld1;
                        iFld = (int)((float)iFld + ((float)((long)var8 * instanceCount + (long)iFld) - var2));
                        instanceCount >>= var4;
                        iFld >>= -47;
                        var2 += (float)(-140 + var8 * var8);
                        var7 += (int)instanceCount;
                        var4 += var8 | var7;
                     }
                  }
                  break;
               case 34:
                  var13[var15 - 1] = (long)var9;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)34598);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
