public class Test {
   public static final int N = 400;
   public static long instanceCount = 2635474643414078350L;
   public double dFld = 126.123539;
   public static float fFld = 1.194F;
   public volatile short sFld = -19991;
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, int var1, boolean var2) {
      boolean var3 = true;
      int var4 = 219;
      int var5 = -235;
      int var6 = 8;
      int[] var7 = new int[400];
      float var8 = -110.209F;
      short var9 = -29305;
      FuzzerUtils.init(var7, -52078);
      int var10 = 1;

      while(true) {
         var10 += 2;
         if (var10 >= 229) {
            vMeth2_check_sum += (long)(var0 + var1 + (var2 ? 1 : 0) + var10 + var4 + var5 + Float.floatToIntBits(var8) + var9 + var6) + FuzzerUtils.checkSum(var7);
            return;
         }

         for(var4 = 1; var4 < 14; ++var4) {
            var7[var10] += (int)var8;
            var0 >>= var9;
            var6 = 1;

            do {
               var8 += (float)(var6 * var6);
               int var10000 = var1 - var10;
               var8 -= var8;
               var1 = var10;
               instanceCount = (long)var9;
               instanceCount += (long)(var6 * var0 + var0) - instanceCount;
               var0 -= var0;
               var5 = var10 + (var6 ^ var0);
               var0 = -20531;
               ++var6;
            } while(var6 < 2);
         }
      }
   }

   public static void vMeth1(long var0, short var2, int var3) {
      boolean var4 = false;
      boolean var5 = true;
      short var6 = 32747;
      int var7 = -129;
      short var8 = 18080;
      int var9 = 34680;
      byte var10 = 4;
      double[] var11 = new double[400];
      FuzzerUtils.init(var11, 105.79999);
      vMeth2(var3, -14, var4);
      instanceCount -= (long)var3;
      int[] var10000 = iArrFld;
      var10000[(var3 >>> 1) % 400] >>= -62707;
      var3 = var3;
      fFld -= -43.12985F;

      int var12;
      for(var12 = 2; var12 < 362; ++var12) {
         for(var7 = 1; var7 < 5; ++var7) {
            fFld = (float)var3;
            var9 = 1;

            while(true) {
               ++var9;
               if (var9 >= 2) {
                  break;
               }

               var10000 = iArrFld;
               var10000[var9 + 1] &= (int)var0;
               var6 = var8;
               var3 = (int)var0;
               var11[var9 + 1] = (double)var7;
               var2 = (short)(var2 + var10);
               if (var4) {
               }
            }
         }
      }

      vMeth1_check_sum += var0 + (long)var2 + (long)var3 + (long)(var4 ? 1 : 0) + (long)var12 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + Double.doubleToLongBits(FuzzerUtils.checkSum(var11));
   }

   public static void vMeth(double var0, float var2, long var3) {
      short var5 = 24636;
      boolean var6 = true;
      int var7 = 138;
      int var8 = -13;
      int var9 = 36;
      boolean var10 = true;
      byte var11 = 29;
      float[] var12 = new float[400];
      FuzzerUtils.init(var12, -2.416F);
      vMeth1(instanceCount, var5, 64611);
      int var13 = 1;

      do {
         if (!var10) {
            var7 ^= var13;

            for(var8 = 1; var8 < 4; ++var8) {
               var7 = (int)instanceCount;
               var9 -= (int)fFld;
               int var10000 = var7 << var8;
               var7 = (int)var3;
               var12[var13 + 1] = (float)var13;
               var7 >>= var11;
               var0 -= var0;
               if (var10) {
                  var9 = var8;
                  fFld *= (float)var8;
               } else if (var10) {
                  var7 |= var7;
               } else {
                  var3 <<= var9;
               }
            }
         }

         ++var13;
      } while(var13 < 398);

      vMeth_check_sum += Double.doubleToLongBits(var0) + (long)Float.floatToIntBits(var2) + var3 + (long)var5 + (long)var13 + (long)(var10 ? 1 : 0) + (long)var7 + (long)var8 + (long)var9 + (long)var11 + Double.doubleToLongBits(FuzzerUtils.checkSum(var12));
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 54911;
      int var4 = 107;
      int var5 = -3;
      double var6 = 88.95346;
      boolean var8 = true;
      byte var9 = -67;
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, 1.372F);

      int var13;
      for(var13 = 7; 123 > var13; ++var13) {
         try {
            var3 = var13 / 7299;
            var3 = 'ﯖ' % var13;
            var3 = -339529081 % var3;
         } catch (ArithmeticException var12) {
         }

         for(var6 = 216.0; var6 > (double)var13; --var6) {
            var3 = var4 - var4 + -(var4 - var13) - var13;
            int var10000 = var4 * (int)(this.dFld--);
            vMeth(this.dFld, fFld, 59682L);
            var4 = var3;
            if (var8) {
               break;
            }

            iArrFld[var13] = -5647;
            var5 = 1;

            do {
               boolean var14 = true;
               var3 = var4;
               this.dFld -= 4.0;
               var4 -= var13;
               switch (var13 % 1 * 5 + 110) {
                  case 114:
                     fFld = (float)var3;
                     iArrFld[var5 - 1] = var5;
                     var10[(int)(var6 + 1.0)] = fFld;
                     this.sFld = 1;
                     var4 ^= var13;
               }

               var3 += var3;
               if (var8) {
                  break;
               }

               ++var5;
            } while(var5 < 1);

            var4 ^= this.sFld;
            var4 -= var13;
         }

         var3 = -34816;
         var9 = (byte)((int)fFld);
      }

      var3 *= var13;
      FuzzerUtils.out.println("i i1 d = " + var13 + "," + var3 + "," + Double.doubleToLongBits(var6));
      FuzzerUtils.out.println("i2 b3 i19 = " + var4 + "," + (var8 ? 1 : 0) + "," + var5);
      FuzzerUtils.out.println("by2 fArr1 = " + var9 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)));
      FuzzerUtils.out.println("Test.instanceCount dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("sFld Test.iArrFld = " + this.sFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)6);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
