public class Test {
   public static final int N = 400;
   public static long instanceCount = -1550508883L;
   public static int iFld = 2578;
   public static float fFld = 95.1016F;
   public static byte byFld = -52;
   public static boolean bFld = false;
   public static double dFld = -1.121504;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, int var1) {
      int var2 = 48793;
      int var3 = -105;
      int var4 = -7;
      int var5 = 43281;
      int var6 = -54161;
      long[] var7 = new long[400];
      FuzzerUtils.init(var7, -38418L);

      for(var2 = 8; var2 < 150; var2 += 2) {
         int var10000 = var3 + var2;
         iFld += '\uede2' + var2 * var2;
         var1 += var2;
         var7[var2] += instanceCount;
         var3 = var2;
         fFld = (float)instanceCount;

         for(var4 = 1; var4 < 22; ++var4) {
            var5 += var4 | var1;
            var6 = 1;

            while(true) {
               var6 += 2;
               int[] var8;
               if (var6 >= 2) {
                  iFld = (int)instanceCount;
                  instanceCount += (long)var4;
                  var5 += 0;
                  var8 = iArrFld;
                  var8[var4] *= var1;
                  break;
               }

               var8 = iArrFld;
               var8[var2 + 1] -= iFld;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6) + FuzzerUtils.checkSum(var7);
   }

   public static int iMeth1(int var0, long var1, long var3) {
      boolean var5 = true;
      int var6 = -35;
      int var7 = 27130;
      int var8 = -105;
      double var9 = 114.112392;

      int var14;
      for(var14 = 7; var14 < 326; ++var14) {
         short var11 = 146;
         vMeth(var11, var14);
         fFld *= (float)var9;
         var6 += 159 + var14 * var14;
         var0 *= (int)var3;
         byFld = (byte)((int)instanceCount);
         var6 ^= -38819;
         int var10000 = var11 + var14;

         try {
            iFld %= var0;
            iFld = 'ꛄ' % var0;
            iArrFld[var14] = var6 % '鐌';
         } catch (ArithmeticException var13) {
         }

         for(var7 = var14; var7 < 5; ++var7) {
            var8 -= var7;
            int[] var16 = iArrFld;
            var16[var14 - 1] <<= var0;
            var1 += -153L;
            fFld *= (float)var1;
            var8 *= var7;
         }
      }

      long var15 = (long)var0 + var1 + var3 + (long)var14 + (long)var6 + Double.doubleToLongBits(var9) + (long)var7 + (long)var8;
      iMeth1_check_sum += var15;
      return (int)var15;
   }

   public static int iMeth() {
      int var0 = -47621;
      boolean var1 = true;
      boolean var2 = true;
      short var3 = 241;
      int var4 = 27100;
      int var5 = 53740;
      short var6 = -15099;
      long[] var7 = new long[400];
      FuzzerUtils.init(var7, 3659750234294669490L);
      instanceCount = (long)Math.abs(iFld--);
      var0 *= Math.abs((int)((long)var6 * 2476092117L)) * (iMeth1(-58494, -6L, instanceCount) + var6);
      iFld -= iFld;
      var7[(var0 >>> 1) % 400] -= 40156L;
      bFld = bFld;
      int var10 = 266;

      int var11;
      do {
         instanceCount = (long)var10;
         byFld -= (byte)((int)dFld);

         for(var11 = 6; 1 < var11; --var11) {
            for(var4 = 1; var4 < 2; ++var4) {
               var5 = (int)fFld;
            }

            iFld <<= var10;
            instanceCount += (long)var0;
            var0 >>= var10;
            var0 += var11 ^ var11;
         }

         --var10;
      } while(var10 > 0);

      long var8 = (long)(var0 + var6 + var10 + var11 + var3 + var4 + var5) + FuzzerUtils.checkSum(var7);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -4801;
      boolean var4 = true;
      short var5 = 14028;
      int var6 = -28969;
      short var7 = 8132;
      byte var8 = -8;
      short var9 = 214;
      byte var10 = 4;
      short var11 = 253;
      char var12 = '댡';
      short var13 = 160;
      byte var14 = 0;
      int[] var15 = new int[400];
      float[][] var16 = new float[400][400];
      long[] var17 = new long[400];
      boolean[] var18 = new boolean[400];
      FuzzerUtils.init((int[])var15, (int)32892);
      FuzzerUtils.init(var16, -60.598F);
      FuzzerUtils.init(var17, -2099759609912039697L);
      FuzzerUtils.init(var18, true);
      int var19 = 364;

      while(true) {
         --var19;
         if (var19 <= 0) {
            var3 = iMeth();
            instanceCount >>= var3;

            int var20;
            for(var20 = 17; var20 < 304; ++var20) {
               iFld = -1818386673;

               for(var6 = 4; var6 < 88; ++var6) {
                  instanceCount = (long)fFld;
                  iFld += var6;
               }

               if (bFld) {
                  break;
               }
            }

            FuzzerUtils.out.println("i i1 i21 = " + var19 + "," + var3 + "," + var20);
            FuzzerUtils.out.println("i22 i23 i24 = " + var5 + "," + var6 + "," + var7);
            FuzzerUtils.out.println("i25 i26 i27 = " + var8 + "," + var9 + "," + var10);
            FuzzerUtils.out.println("i28 i29 i30 = " + var11 + "," + var12 + "," + var13);
            FuzzerUtils.out.println("i31 iArr fArr = " + var14 + "," + FuzzerUtils.checkSum(var15) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var16)));
            FuzzerUtils.out.println("lArr2 bArr = " + FuzzerUtils.checkSum(var17) + "," + FuzzerUtils.checkSum(var18));
            FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
            FuzzerUtils.out.println("Test.byFld Test.bFld Test.dFld = " + byFld + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
            FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            return;
         }

         int var10000 = var3 * (int)((double)(instanceCount - 57L) + (double)var19 + 54.13999 - (double)(-52516L + instanceCount));
         var3 = --var15[var19];
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)4);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
