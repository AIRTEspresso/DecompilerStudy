public class Test {
   public static final int N = 400;
   public static long instanceCount = 860701209L;
   public int iFld = -6;
   public static double dFld = 112.82618;
   public boolean bFld = false;
   public float fFld = -2.148F;
   public int iFld1 = 61239;
   public short sFld = -16465;
   public static float[] fArrFld = new float[400];
   public static boolean[] bArrFld = new boolean[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(long var0, short var2, byte var3) {
      int var4 = 116;
      boolean var5 = true;
      int var6 = 10809;
      int var7 = 45960;
      int[] var8 = new int[400];
      float var9 = -1.877F;
      float[] var10 = new float[400];
      double var11 = -1.76724;
      double var13 = -2.18497;
      short[] var15 = new short[400];
      FuzzerUtils.init((int[])var8, (int)36361);
      FuzzerUtils.init(var10, 0.791F);
      FuzzerUtils.init(var15, (short)-1473);
      var4 -= 88;

      int var18;
      for(var18 = 20; var18 < 355; ++var18) {
         var6 -= (int)var9;
         var9 -= (float)var11;
         var8[var18 + 1] += var6;
         var6 <<= var18;
         var8 = var8;
         var4 -= (int)var11;
         switch (101) {
            case 98:
               var10[var18] += (float)var4;
               var4 = (int)var0;
               var4 *= (int)instanceCount;
            case 99:
               for(var13 = 1.0; var13 < 5.0; ++var13) {
                  var0 = (long)var7;
               }

               var7 = -25;
               break;
            case 100:
               var15 = var15;
               break;
            case 101:
               var4 += var18;
               break;
            default:
               var9 = (float)instanceCount;
         }
      }

      long var16 = var0 + (long)var2 + (long)var3 + (long)var4 + (long)var18 + (long)var6 + (long)Float.floatToIntBits(var9) + Double.doubleToLongBits(var11) + Double.doubleToLongBits(var13) + (long)var7 + FuzzerUtils.checkSum(var8) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var15);
      iMeth_check_sum += var16;
      return (int)var16;
   }

   public void vMeth1(int var1) {
      boolean var2 = true;
      int var3 = 17541;
      int[] var4 = new int[400];
      short var5 = 21855;
      byte var6 = -33;
      float var7 = -76.726F;
      long[][][] var8 = new long[400][400][400];
      FuzzerUtils.init((Object[][])var8, 6L);
      FuzzerUtils.init((int[])var4, (int)-2);

      int var9;
      for(var9 = 11; var9 < 319; ++var9) {
         this.iFld = iMeth(-2221516662478642684L, var5, var6);
         var3 = (int)dFld;
         var5 -= (short)((int)var7);
         var3 = this.iFld;
      }

      instanceCount -= instanceCount;
      instanceCount *= instanceCount;
      long[] var10000 = var8[(this.iFld >>> 1) % 400][(var9 >>> 1) % 400];
      var10000[(var9 >>> 1) % 400] -= (long)var1;
      float[] var10 = fArrFld;
      var10[(var9 >>> 1) % 400] += (float)var9;
      var1 <<= var9;
      this.bFld = this.bFld;
      vMeth1_check_sum += (long)(var1 + var9 + var3 + var5 + var6 + Float.floatToIntBits(var7)) + FuzzerUtils.checkSum((Object[][])var8) + FuzzerUtils.checkSum(var4);
   }

   public void vMeth(int var1, long var2, double var4) {
      boolean var6 = true;
      byte var7 = -62;
      int var8 = -1542;
      byte var9 = 8;
      int[] var10 = new int[400];
      short var11 = 3442;
      double[][] var12 = new double[400][400];
      FuzzerUtils.init(var12, 126.36653);
      FuzzerUtils.init((int[])var10, (int)-12577);

      int var13;
      for(var13 = 16; var13 < 353; ++var13) {
         this.vMeth1(-32056);
         var11 += (short)((int)((long)var13 - instanceCount));
         this.iFld >>= 51;
         this.iFld >>= this.iFld;
         if (!this.bFld) {
            this.iFld = (int)((float)this.iFld + ((float)(var13 * var1 + var11) - this.fFld));
            if (this.bFld) {
               var12[var13 + 1][var13 - 1] += (double)var1;
            } else {
               if (this.bFld) {
                  continue;
               }

               var1 -= (int)dFld;
            }

            for(var8 = 1; var8 < 5; var10[var13 - 1] = var8++) {
               this.fFld += (float)(-130 + var8 * var8);
               if (this.iFld1 != 0) {
                  vMeth_check_sum += (long)var1 + var2 + Double.doubleToLongBits(var4) + (long)var13 + (long)var7 + (long)var11 + (long)var8 + (long)var9 + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)) + FuzzerUtils.checkSum(var10);
                  return;
               }
            }
         }
      }

      vMeth_check_sum += (long)var1 + var2 + Double.doubleToLongBits(var4) + (long)var13 + (long)var7 + (long)var11 + (long)var8 + (long)var9 + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)) + FuzzerUtils.checkSum(var10);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -13;
      int var4 = -3;
      int var5 = -40;
      int var6 = 45;
      int[] var7 = new int[400];
      double var8 = 89.103368;
      double[][] var10 = new double[400][400];
      byte[] var11 = new byte[400];
      FuzzerUtils.init(var11, (byte)-62);
      FuzzerUtils.init((int[])var7, (int)-23504);
      FuzzerUtils.init(var10, 2.109179);
      this.iFld = var11[(this.iFld >>> 1) % 400];
      this.vMeth(this.iFld, 4085723069L, dFld);
      byte[] var12 = var11;
      int var13 = var11.length;

      for(int var14 = 0; var14 < var13; ++var14) {
         byte var10000 = var12[var14];
         instanceCount = -403528749L;
         byte var15 = (byte)this.sFld;
         this.fFld -= (float)this.iFld1;
      }

      var7[396] = -10;
      instanceCount = (long)this.fFld;
      this.sFld -= (short)this.iFld1;
      int var16 = 275;

      while(true) {
         --var16;
         if (var16 <= 0) {
            FuzzerUtils.out.println("i12 d3 i13 = " + var16 + "," + Double.doubleToLongBits(var8) + "," + var3);
            FuzzerUtils.out.println("i14 i15 i16 = " + var4 + "," + var5 + "," + var6);
            FuzzerUtils.out.println("byArr iArr3 dArr1 = " + FuzzerUtils.checkSum(var11) + "," + FuzzerUtils.checkSum(var7) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)));
            FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
            FuzzerUtils.out.println("bFld fFld iFld1 = " + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(this.fFld) + "," + this.iFld1);
            FuzzerUtils.out.println("sFld Test.fArrFld Test.bArrFld = " + this.sFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         this.bFld = this.bFld;
         var8 = 1.0;

         while(++var8 < 91.0) {
            this.iFld = (int)instanceCount;
            this.fFld += (float)(var8 * (double)instanceCount + (double)var16 - (double)var16);

            for(var3 = var16; var3 < 1; ++var3) {
               instanceCount = (long)this.iFld1;
            }

            var10[(int)(var8 - 1.0)][var16 - 1] += (double)var16;

            for(var5 = 1; var5 < 1; ++var5) {
               dFld -= (double)var5;
               var11[var16 + 1] = (byte)((int)instanceCount);
               var6 += var5 * var5;
               this.iFld = -163;
               switch (var5 % 7 + 54) {
                  case 54:
                     var10[var16 - 1][var16 + 1] = (double)var6;
                     instanceCount += instanceCount;
                     instanceCount = (long)var4;
                  case 55:
                     var4 = (int)((float)var4 + ((float)var5 * this.fFld + (float)var3 - (float)instanceCount));
                     this.fFld = (float)this.iFld1;
                     this.bFld = this.bFld;
                     ++var7[var5 + 1];
                     break;
                  case 56:
                     this.fFld -= (float)var3;
                  case 57:
                     var4 = var4;
                     break;
                  case 58:
                     var6 = (int)this.fFld;
                     break;
                  case 59:
                     var4 += var5;
                     break;
                  case 60:
                     var7 = FuzzerUtils.int1array(400, 10);
                     break;
                  default:
                     bArrFld[var5] = this.bFld;
               }
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 2.96F);
      FuzzerUtils.init(bArrFld, false);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
