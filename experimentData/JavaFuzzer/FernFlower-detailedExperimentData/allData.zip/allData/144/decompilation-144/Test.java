public class Test {
   public static final int N = 400;
   public static long instanceCount = -1331392317368199387L;
   public static int iFld = 241;
   public volatile float fFld = 0.213F;
   public static int iFld1 = -1;
   public volatile boolean bFld = true;
   public double dFld = -32.37157;
   public volatile long[] lArrFld = new long[400];
   public int[] iArrFld = new int[400];
   public static long dMeth_check_sum = 0L;
   public static long lMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;

   public int iMeth(double var1, int var3, int var4) {
      boolean var5 = true;
      int var6 = -55;
      int var7 = -4;
      int var8 = -14;
      int var9 = -68;
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 390) {
            long var10 = Double.doubleToLongBits(var1) + (long)var3 + (long)var4 + (long)var12 + (long)var6 + (long)var7 + (long)var8 + (long)var9;
            iMeth_check_sum += var10;
            return (int)var10;
         }

         instanceCount *= (long)iFld;
         var4 *= var12;

         for(var6 = 1; 4 > var6; var6 += 3) {
            for(var8 = 1; var8 < 4; ++var8) {
               this.fFld -= -46619.0F;
               iFld += var8 | var12;
               var9 /= var6 | 1;
               if (this.bFld) {
                  var1 += -19554.0;
                  var3 = (int)var1;
                  switch ((iFld >>> 1) % 1 * 5 + 67) {
                     case 68:
                        var3 *= iFld;
                        iFld = iFld1;
                        var7 = var3;
                  }
               } else {
                  var4 -= var12;
               }
            }
         }
      }
   }

   public long lMeth(int var1) {
      double var2 = -2.56817;
      boolean var4 = true;
      short var5 = 11541;
      int var6 = 12;
      short var7 = -10;
      int var8 = -212;
      int var9 = 40200;
      int var10 = 8;
      iFld <<= (int)instanceCount;
      iFld = this.iMeth(var2, iFld1, iFld1);
      this.iArrFld[(iFld >>> 1) % 400] = (int)instanceCount;

      int var13;
      for(var13 = 228; var13 > 12; --var13) {
         var1 = 6312;
         var2 -= -166.0;

         for(var6 = 1; var6 < 7; ++var6) {
            for(var8 = 2; var8 > 1; --var8) {
               var2 -= (double)this.fFld;
               iFld1 *= (int)this.fFld;
               var10 *= 56162;
               instanceCount += instanceCount;
               var7 = var5;
               var9 += var8 | var10;
            }
         }
      }

      long var11 = (long)var1 + Double.doubleToLongBits(var2) + (long)var13 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10;
      lMeth_check_sum += var11;
      return var11;
   }

   public double dMeth() {
      boolean var1 = true;
      int var2 = 61;
      boolean var3 = true;
      short var4 = 3790;
      int var5 = 11;
      int var6 = -114;
      int var7 = -11929;
      byte var8 = -91;
      short var9 = -10896;
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, -2.32F);

      int var13;
      for(var13 = 21; var13 < 349; ++var13) {
         var10[var13 - 1] = (float)((long)(var2 *= var2) - instanceCount - this.lMeth(-10053));
         iFld = (int)instanceCount;
         iFld1 = var13;
         this.dFld += (double)instanceCount;
         iFld &= var2;
      }

      var8 += (byte)var13;

      int var14;
      for(var14 = 12; var14 < 344; ++var14) {
         var5 = 1;

         while(true) {
            ++var5;
            if (var5 >= 5) {
               break;
            }

            iFld &= var9;
            this.fFld -= this.fFld;

            for(var6 = 1; var6 < 1; ++var6) {
               if (var6 != 0) {
               }

               long[] var10000 = this.lArrFld;
               var10000[var6 + 1] += (long)iFld1;
               var7 -= var14;
            }
         }
      }

      long var11 = (long)(var13 + var2 + var8 + var14 + var4 + var5 + var9 + var6 + var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
      dMeth_check_sum += var11;
      return (double)var11;
   }

   public void mainTest(String[] var1) {
      double var2 = 3.58387;
      double[] var4 = new double[400];
      byte var5 = -1;
      int var6 = 50158;
      int var7 = 183;
      int var8 = 75;
      short var9 = -30656;
      byte var10 = 113;
      boolean[] var11 = new boolean[400];
      float[] var12 = new float[400];
      FuzzerUtils.init(var4, 65.23246);
      FuzzerUtils.init(var11, true);
      FuzzerUtils.init(var12, 2.5F);
      long[] var10000 = this.lArrFld;
      int var10001 = (iFld >>> 1) % 400;
      var10000[var10001] += (long)(-((double)this.iArrFld[115] * var2 * 18557.0));
      int[] var13 = this.iArrFld;
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         int var16 = var13[var15];
         var5 = 3;
         if (var5 < 63) {
            iFld = (int)((double)Math.abs(var9 + var6) + var4[var5]);

            for(var7 = 1; var7 < 2; ++var7) {
               boolean var17 = false;
               if (!(var11[var5 + 1] = instanceCount > (long)var16)) {
                  long var20 = (long)var10;
                  --var8;
                  iFld -= (int)(var20 + 5637493953923160993L * (long)var8 + --this.lArrFld[var7]);
                  switch (var7 % 2 + 48) {
                     case 48:
                        this.fFld *= (float)(var10--);
                        this.dMeth();
                        iFld -= var6;
                        break;
                     case 49:
                        instanceCount += (long)(var7 * var7);
                        var6 += 12;
                  }

                  label43:
                  switch ((var5 >>> 1) % 2 * 5 + 123) {
                     case 129:
                        var10 >>>= (byte)((int)instanceCount);
                        int[] var19 = this.iArrFld;
                        var19[var5 - 1] += var6;
                        switch ((var16 >>> 1) % 1 * 5 + 17) {
                           case 22:
                              iFld1 = var5;
                              var16 += 13132;
                              var12[var5 + 1] = 1.0F;
                           default:
                              this.fFld += (float)(var7 * iFld) + this.fFld - (float)var7;
                              break label43;
                        }
                     case 130:
                        this.iArrFld[var7] = var6;
                        iFld += (int)this.dFld;
                        iFld <<= var5;
                  }

                  instanceCount += (long)(var7 * var7);
               }
            }

            try {
               iFld = this.iArrFld[(iFld1 >>> 1) % 400] / 1986380531;
               var8 = var7 / -48368;
               this.iArrFld[var5] = 244 / var6;
            } catch (ArithmeticException var18) {
            }

            instanceCount += 188L;
            var10 += (byte)(var5 * var6 + var6 - iFld);
            iFld -= (int)this.dFld;
         }
      }

      FuzzerUtils.out.println("d i1 i2 = " + Double.doubleToLongBits(var2) + "," + var5 + "," + var6);
      FuzzerUtils.out.println("s i3 i4 = " + var9 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("by dArr bArr = " + var10 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var4)) + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("fArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("Test.iFld1 bFld dFld = " + iFld1 + "," + (this.bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("lArrFld iArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
