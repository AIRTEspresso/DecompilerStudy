public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 9L;
   public volatile float fFld = 0.82F;
   public static double dFld = 30.32936;
   public static float fFld1 = -9.21F;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(boolean var0, int var1, float var2) {
      int var3 = 2;
      byte var4 = -94;
      int var5 = 5;
      int var6 = 22656;
      char var7 = '\uee17';
      char var8 = 3;
      int[] var9 = new int[400];
      short var10 = 7257;
      float var11 = 1.108F;
      FuzzerUtils.init((int[])var9, (int)4);
      if (var0) {
         if (var0) {
            for(var3 = 6; var3 < 204; ++var3) {
               var1 += var3;
               var5 = 1;

               while(true) {
                  var5 += 2;
                  if (var5 >= 8) {
                     for(var6 = 1; 8 > var6; ++var6) {
                        instanceCount = instanceCount;

                        for(var11 = 1.0F; var11 < 2.0F; ++var11) {
                           dFld += -40264.0;
                           float var10000 = var2 + (var11 * (float)var1 + (float)var1 - (float)instanceCount);
                           var9[(var7 >>> 1) % 400] -= var5;
                           var2 = (float)var5;
                        }
                     }
                     break;
                  }

                  var1 = (int)((long)var1 + ((long)var5 ^ instanceCount));
                  var1 += var5 * var5;
                  dFld = (double)var10;
               }
            }

            vMeth_check_sum += (long)((var0 ? 1 : 0) + var1 + Float.floatToIntBits(var2) + var3 + var4 + var5 + var10 + var6 + var7 + Float.floatToIntBits(var11) + var8) + FuzzerUtils.checkSum(var9);
            return;
         }

         if (var0) {
            var8 = var7;
         } else if (var0) {
            var2 = (float)var1;
         } else {
            instanceCount = (long)var4;
         }
      } else {
         var1 *= (int)var2;
      }

      vMeth_check_sum += (long)((var0 ? 1 : 0) + var1 + Float.floatToIntBits(var2) + var3 + var4 + var5 + var10 + var6 + var7 + Float.floatToIntBits(var11) + var8) + FuzzerUtils.checkSum(var9);
   }

   public static int iMeth1(int var0, int var1, int var2) {
      boolean var3 = false;
      int var4 = 55277;
      int var5 = -4;
      int var6 = -3;
      byte var7 = -9;
      int var8 = 7;
      int var9 = -149;
      int var10 = -14409;
      long var11 = 1598912768L;
      vMeth(var3, var0, fFld1);
      instanceCount = 153L;

      for(var4 = 8; 143 > var4; ++var4) {
         var5 -= var4;

         for(var6 = 1; var6 < 12; ++var6) {
            var2 += (int)instanceCount;
         }

         var8 = 1;

         while(true) {
            ++var8;
            if (var8 >= 12) {
               break;
            }

            instanceCount = (long)var6;

            for(var9 = 1; var9 < 1; ++var9) {
               short var13 = 9313;
               var10 <<= (int)instanceCount;
               var1 += var13;
               var1 <<= var6;
               iArrFld[var8 + 1] = (int)instanceCount;
               var2 = (int)((long)var2 + ((long)var9 * instanceCount + instanceCount - var11));
            }

            iArrFld[var8] = var7;
         }
      }

      long var15 = (long)(var0 + var1 + var2 + (var3 ? 1 : 0) + var4 + var5 + var6 + var7 + var8 + var9 + var10) + var11;
      iMeth1_check_sum += var15;
      return (int)var15;
   }

   public int iMeth(long var1, int var3) {
      boolean var4 = true;
      int[] var5 = new int[400];
      short var6 = -23804;
      FuzzerUtils.init((int[])var5, (int)-8);
      int var9 = 1;

      do {
         var3 = var3-- - Integer.reverseBytes(var3);
         label21:
         switch (var9 % 6 + 115) {
            case 115:
               if (var3 != 0) {
               }

               var5 = var5;
               var3 *= iMeth1(-195, var9, var9) - -208;
            case 116:
               var3 = var3;
            case 117:
               fFld1 = -3.0F;
               switch ((var9 >>> 1) % 1 + 111) {
                  case 111:
                     dFld -= -22231.0;
                     iArrFld[var9 + 1] = (int)instanceCount;
                     var1 += (long)(6 + var9 * var9);
                  default:
                     this.fFld = 99.0F;
                     var3 <<= var6;
                     break label21;
               }
            case 118:
               this.fFld += (float)(var9 * var9 + var9 - var3);
               break;
            case 119:
               this.fFld = (float)instanceCount;
               break;
            case 120:
            default:
               instanceCount = (long)var3;
         }

         ++var9;
      } while(var9 < 303);

      long var7 = var1 + (long)var3 + (long)var9 + (long)var6 + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var7;
      return (int)var7;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -40545;
      int var4 = -7;
      int var5 = 0;
      boolean var6 = true;
      int var7 = 19375;
      int var8 = 83;
      int var9 = 58164;
      int var10 = -22017;
      short var11 = -15580;
      short[] var12 = new short[400];
      double var13 = 97.15975;
      boolean var15 = false;
      float[] var16 = new float[400];
      FuzzerUtils.init(var12, (short)-28031);
      FuzzerUtils.init(var16, -2.988F);

      int var17;
      for(var17 = 12; var17 < 194; ++var17) {
         var3 = (int)((float)var17 - this.fFld);

         for(var4 = 5; 138 > var4; ++var4) {
            this.fFld *= (float)this.iMeth(instanceCount, var5);
            var3 = (int)((float)var3 + ((float)var4 * fFld1 + (float)var4 - (float)var4));
            var11 = (short)(var11 % -10);
            var3 >>= var5;
         }

         int var10000 = var3 + var17;
         var3 = var4;
      }

      iArrFld[(var5 >>> 1) % 400] = (int)instanceCount;
      long[] var19 = lArrFld;
      var19[(var3 >>> 1) % 400] -= (long)var4;
      var3 = -61103;
      iArrFld[(var4 >>> 1) % 400] = var3;
      var3 |= (int)instanceCount;

      int var18;
      for(var18 = 17; var18 < 293; ++var18) {
         var8 = 1;

         do {
            var3 += (int)(4529079815672162736L + (long)(var8 * var8));
            ++var8;
         } while(var8 < 91);

         for(var13 = 1.0; var13 < 91.0; ++var13) {
            this.fFld += (float)var3;
            var12[var18 + 1] = (short)var8;
            var7 += 2;
            var5 += (int)var13;
            var15 = var15;
            int[] var20;
            switch (var18 % 6 * 5 + 126) {
               case 129:
               default:
                  break;
               case 134:
                  var20 = iArrFld;
                  var20[var18] += -52042;
                  break;
               case 137:
                  var7 <<= var17;
                  var9 = (int)dFld;
               case 154:
                  var20 = iArrFld;
                  var20[var18 + 1] *= var3;
                  break;
               case 144:
                  fFld1 -= (float)var9;
                  break;
               case 145:
                  var10 <<= var18;
                  var16[(int)var13] += fFld1;
                  instanceCount += (long)var13;
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var17 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 s3 i23 = " + var5 + "," + var11 + "," + var18);
      FuzzerUtils.out.println("i24 i25 d = " + var7 + "," + var8 + "," + Double.doubleToLongBits(var13));
      FuzzerUtils.out.println("i26 b2 i27 = " + var9 + "," + (var15 ? 1 : 0) + "," + var10);
      FuzzerUtils.out.println("sArr fArr = " + FuzzerUtils.checkSum(var12) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var16)));
      FuzzerUtils.out.println("Test.instanceCount fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.fFld1 Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(fFld1) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)156);
      FuzzerUtils.init(lArrFld, -10L);
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
