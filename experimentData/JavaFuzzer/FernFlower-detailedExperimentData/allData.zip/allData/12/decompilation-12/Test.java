public class Test {
   public static final int N = 400;
   public static long instanceCount = 1065939410768721658L;
   public static short sFld = -17924;
   public static boolean bFld = true;
   public volatile int[] iArrFld = new int[400];
   public static float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(byte var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = -182;
      int var5 = -98;
      int var6 = 12;
      boolean var7 = true;
      float var8 = 2.118F;
      double var9 = 2.7693;
      var2 = 389038952;

      int var14;
      for(var14 = 5; var14 < 163; ++var14) {
         var4 += (int)instanceCount;
         var8 = var8;

         for(var5 = var14; var5 < 10; ++var5) {
            var6 += var5 * var5;
            var9 += -12.0;
         }

         try {
            var1 = -664335621 / var14;
            var2 = -12 % var6;
            var2 = var5 % 110;
         } catch (ArithmeticException var13) {
         }

         instanceCount += (long)var14 * instanceCount + (long)var1 - (long)sFld;
      }

      int var15 = 1;

      do {
         var6 += var15 * var15;
         var4 <<= (int)instanceCount;
         instanceCount -= (long)var6;
         var1 *= -24630;
         var9 += (double)var4;
         var15 += 3;
      } while(var15 < 330);

      long var11 = (long)(var0 + var1 + var2 + var14 + var4 + Float.floatToIntBits(var8) + var5 + var6) + Double.doubleToLongBits(var9) + (long)var15;
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static void vMeth1(int var0, int var1, int var2) {
      byte var3 = 108;
      int var4 = 48428;
      int var5 = -248;
      byte var6 = 11;
      int var7 = 149;
      int var8 = 80;
      long var9 = 7156431638399464735L;
      double var11 = 2.37983;
      float var13 = 92.659F;
      boolean var14 = false;
      var0 ^= iMeth(var3, var0, -59014);
      var4 = 1;

      while(true) {
         label55:
         while(true) {
            ++var4;
            if (var4 >= 381) {
               vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8) + var9 + Double.doubleToLongBits(var11) + (long)Float.floatToIntBits(var13) + (long)(var14 ? 1 : 0);
               return;
            }

            switch (var4 % 2 + 126) {
               case 126:
                  if (var14) {
                     for(var5 = 1; var5 < 4; ++var5) {
                        var2 += var5 * var0;
                        if (var14) {
                           instanceCount -= (long)var2;

                           for(var7 = 1; var7 < 2; ++var7) {
                              boolean var15 = true;
                              var9 = instanceCount;
                              var11 += -13.0;
                              var9 = (long)((float)var9 + ((float)var7 * var13 + (float)var9 - (float)var2));
                              var8 &= (int)instanceCount;
                           }
                        } else if (var14) {
                           var13 *= (float)var0;
                        } else if (var14) {
                           var0 = var0;
                        }
                     }
                  } else if (var14) {
                     var1 += var4 * var8;
                  } else {
                     var13 += (float)(var4 + var8);
                  }
               case 127:
                  break label55;
            }
         }

         var2 += 793010601;
      }
   }

   public static void vMeth(int var0) {
      boolean var1 = true;
      int var2 = 10;
      int var3 = -168;
      int var4 = 1808;
      boolean var5 = true;
      int var6 = 55450;
      short var7 = -165;
      int[] var8 = new int[400];
      double var9 = -2.47648;
      float var11 = -1.305F;
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, 902049967L);
      FuzzerUtils.init((int[])var8, (int)-185);

      int var13;
      for(var13 = 10; var13 < 337; ++var13) {
         for(var3 = var13; var3 < 5; ++var3) {
            vMeth1(var2, var0, var4);
         }

         var4 = var3;
         var9 = (double)var11;
         var12[var13 - 1] = 83L;
         var2 += sFld;
         var11 += (float)sFld;
      }

      int var14 = 1;

      while(true) {
         var14 += 3;
         if (var14 >= 275) {
            vMeth_check_sum += (long)(var0 + var13 + var2 + var3 + var4) + Double.doubleToLongBits(var9) + (long)Float.floatToIntBits(var11) + (long)var14 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var12) + FuzzerUtils.checkSum(var8);
            return;
         }

         for(var6 = 17; var6 > 1; --var6) {
            var12[var14 + 1] = (long)var13;
            var8[var6] -= var7;
            bFld = bFld;
            var0 <<= var2;
         }

         instanceCount -= (long)var7;
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -56907;
      int var4 = 0;
      int var5 = -38985;
      int var6 = 221;
      int var7 = -4528;
      int[] var8 = new int[400];
      double var9 = -2.26414;
      float var11 = -77.26F;
      byte var12 = -56;
      FuzzerUtils.init((int[])var8, (int)-3);
      vMeth(-3);
      int var14 = 1;

      while(true) {
         ++var14;
         if (var14 >= 290) {
            FuzzerUtils.out.println("i23 i24 i25 = " + var14 + "," + var3 + "," + var4);
            FuzzerUtils.out.println("i26 d3 f3 = " + var5 + "," + Double.doubleToLongBits(var9) + "," + Float.floatToIntBits(var11));
            FuzzerUtils.out.println("by2 i27 i28 = " + var12 + "," + var6 + "," + var7);
            FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(var8));
            FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + sFld + "," + (bFld ? 1 : 0));
            FuzzerUtils.out.println("iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         for(var3 = var14; var3 < 87; ++var3) {
            int var13 = -11930;
            var5 = 1;

            while(true) {
               --var5;
               if (var5 <= 0) {
                  for(var6 = var3; var6 < 1; ++var6) {
                     var11 = (float)instanceCount;
                     var7 += 143;
                     var4 >>>= -16235;
                     int var10000 = var7 + (int)(1.626F + (float)(var6 * var6));
                     var7 = 14809;
                  }

                  var7 = (int)((long)var7 + ((long)var3 * instanceCount + (long)sFld - (long)var14));
                  var13 += (int)instanceCount;
                  break;
               }

               var4 += var5;
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 0.235F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
