public class Test {
   public static final int N = 400;
   public static long instanceCount = 137134303L;
   public static boolean bFld = true;
   public static short sFld = -24267;
   public static byte byFld = 3;
   public double dFld = 0.84604;
   public static volatile int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth() {
      double var0 = 5.56812;
      int var2 = 0;
      boolean var3 = true;
      int var4 = 59;
      int var5 = 103;
      int var6 = 136;
      int var7 = -205;
      char var8 = '蔮';
      float var9 = 66.436F;
      float[] var10 = new float[400];
      long[] var11 = new long[400];
      FuzzerUtils.init(var11, 175L);
      FuzzerUtils.init(var10, 2.114F);

      for(var0 = 261.0; var0 > 6.0; --var0) {
         int[] var10000 = iArrFld;
         var10000[(int)(var0 + 1.0)] -= var2;
      }

      int var15;
      for(var15 = 8; var15 < 281; ++var15) {
         try {
            iArrFld[var15] = 'ꀏ' % var4;
            var4 %= var15;
            var4 %= iArrFld[var15];
         } catch (ArithmeticException var14) {
         }

         var5 = 1;

         do {
            instanceCount += (long)var15;
            ++var5;
         } while(var5 < 6);

         var6 = 1;

         do {
            var11 = var11;
            ++var6;
         } while(var6 < 6);

         var2 *= var7;
      }

      if (bFld) {
         var10 = FuzzerUtils.float1array(400, -7.732F);
      } else {
         var7 /= (int)(instanceCount | 1L);
      }

      long var12 = Double.doubleToLongBits(var0) + (long)var2 + (long)var15 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var9) + (long)var8 + FuzzerUtils.checkSum(var11) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public static void vMeth1(int var0, int var1) {
      boolean var2 = true;
      int var3 = 5424;
      int var4 = 7203;
      int var5 = 42863;
      int var6 = -29387;
      int var7 = 11232;
      long var8 = -51064L;
      float var10 = 1.571F;
      int var12 = 1;

      while(true) {
         ++var12;
         if (var12 >= 316) {
            vMeth1_check_sum += (long)(var0 + var1 + var12) + var8 + (long)var3 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var10) + (long)var6 + (long)var7;
            return;
         }

         for(var8 = 1L; var8 < 5L; ++var8) {
            var0 += var0 >> iMeth();
            var3 = sFld;
            var1 = (int)((long)var1 + 209L + var8 * var8);

            for(var4 = (int)var8; var4 < 2; ++var4) {
               short var11 = sFld;
               var10 += -102.0F;
               instanceCount += (long)(var4 - var5);
               var3 = (int)var10;
               var1 = var11 + (int)(181L + (long)(var4 * var4));
               var5 += var3;
            }

            for(var6 = 1; var6 < 2; ++var6) {
               instanceCount = 0L;
               var7 += var6;
            }
         }
      }
   }

   public static void vMeth(int var0, int var1, float var2) {
      double var3 = 120.74754;
      short var5 = -19386;
      boolean var6 = true;
      int var7 = 9;
      boolean var8 = true;
      int var9 = -10;
      int var10 = 20846;
      byte var11 = -116;
      float[] var12 = new float[400];
      FuzzerUtils.init(var12, -51.905F);
      vMeth1(var0, -209);

      for(var3 = 8.0; var3 < 152.0; ++var3) {
         instanceCount = (long)var1;
      }

      var12[(var1 >>> 1) % 400] += (float)var5;

      int var17;
      for(var17 = 5; var17 < 268; ++var17) {
         var7 <<= var1;
         iArrFld[var17] = (int)var2;
      }

      int[] var13 = iArrFld;
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         int var16 = var13[var15];
         var0 = var16;
      }

      int var18;
      for(var18 = 10; 253 > var18; ++var18) {
         byFld += (byte)(var18 * var18);
         var9 <<= (int)instanceCount;

         for(var10 = 1; 7 > var10; ++var10) {
            instanceCount += (long)var11;
            bFld = bFld;
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2)) + Double.doubleToLongBits(var3) + (long)var5 + (long)var17 + (long)var7 + (long)var18 + (long)var9 + (long)var10 + (long)var11 + Double.doubleToLongBits(FuzzerUtils.checkSum(var12));
   }

   public void mainTest(String[] var1) {
      int var2 = -14;
      boolean var3 = true;
      char var4 = '푂';
      int var5 = 231;
      short var6 = 10981;
      int var7 = -223;
      int var8 = -50376;
      int var9 = 1;
      float var10 = 67.374F;
      long var11 = 334838838L;
      vMeth(var2, var2, var10);
      int[] var10000 = iArrFld;
      var10000[41] *= (int)this.dFld;
      int var13 = 1;

      while(true) {
         ++var13;
         if (var13 >= 321) {
            FuzzerUtils.out.println("i25 f3 i26 = " + var2 + "," + Float.floatToIntBits(var10) + "," + var13);
            FuzzerUtils.out.println("i27 i28 i29 = " + var4 + "," + var5 + "," + var6);
            FuzzerUtils.out.println("i30 l1 i31 = " + var7 + "," + var11 + "," + var8);
            FuzzerUtils.out.println("i32 = " + var9);
            FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.sFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + sFld);
            FuzzerUtils.out.println("Test.byFld dFld Test.iArrFld = " + byFld + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         var2 &= sFld;
         var7 -= (int)this.dFld;
         var5 += (int)var11;
         var7 += 117 + var13 * var13;
         var9 = 1;

         while(true) {
            ++var9;
            if (var9 >= 78) {
               break;
            }

            var10 /= -57173.0F;
            var8 = var8;
            var2 += -90 + var9 * var9;
            instanceCount >>>= 28192;
            var10000 = iArrFld;
            var10000[var13 - 1] += (int)var11;
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(iArrFld, -58212);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
