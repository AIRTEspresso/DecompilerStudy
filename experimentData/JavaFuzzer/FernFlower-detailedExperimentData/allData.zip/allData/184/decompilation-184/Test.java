public class Test {
   public static final int N = 400;
   public static long instanceCount = 268906671L;
   public static float fFld = -1.843F;
   public static byte byFld = -67;
   public static int iFld = 48874;
   public static boolean bFld = true;
   public static short sFld = -19932;
   public static long[] lArrFld = new long[400];
   public short[] sArrFld = new short[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(long var0) {
      boolean var2 = true;
      int var3 = -35598;
      int var4 = 13954;
      int var5 = -61852;
      int var6 = 122;
      double var7 = -112.79484;
      boolean var9 = true;

      int var12;
      for(var12 = 7; var12 < 129; ++var12) {
         var3 = 1;
         var7 = (double)fFld;
         instanceCount = (long)var3;
         var7 -= -46548.0;

         for(var4 = 1; 13 > var4; ++var4) {
            if (!var9) {
               var0 -= -10L;
               var5 = -9;
            }
         }

         var5 += var12 * var12;
         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 13) {
               break;
            }

            var5 += 20272;
            var3 = (int)fFld;
            var3 *= var3;
            fFld -= (float)byFld;
         }
      }

      long var10 = var0 + (long)var12 + (long)var3 + Double.doubleToLongBits(var7) + (long)var4 + (long)var5 + (long)(var9 ? 1 : 0) + (long)var6;
      iMeth1_check_sum += var10;
      return (int)var10;
   }

   public static void vMeth() {
      int var0 = -2;
      int[] var1 = new int[400];
      boolean var2 = true;
      FuzzerUtils.init((int[])var1, (int)61524);
      instanceCount += (long)(-Math.max(iMeth1(instanceCount), var0));
      var0 -= var0;
      var1[(var0 >>> 1) % 400] -= -2;
      fFld -= (float)var0;
      vMeth_check_sum += (long)(var0 + (var2 ? 1 : 0)) + FuzzerUtils.checkSum(var1);
   }

   public static int iMeth() {
      boolean var0 = true;
      byte var1 = 1;
      int var2 = -14;
      int var3 = -20634;
      int var4 = -159;
      int[] var5 = new int[400];
      long var6 = 20298L;
      FuzzerUtils.init((int[])var5, (int)6);
      vMeth();
      fFld = (float)iFld;

      int var10;
      for(var10 = 13; var10 < 378; ++var10) {
         for(var2 = 1; var2 < 5; ++var2) {
            var5[var10 + 1] |= byFld;
            var5[var2] ^= 5;

            for(var6 = 1L; var6 < 2L; ++var6) {
               lArrFld[(int)var6] = (long)var10;
               long[] var10000 = lArrFld;
               var10000[(int)(var6 + 1L)] *= (long)var10;
               var3 += (int)instanceCount;
               switch (30) {
                  case 30:
                  case 31:
                     var4 += 16616;
                     var3 = 109;
                     var4 *= (int)fFld;
                     break;
                  case 32:
                     if (bFld) {
                        break;
                     }
                  case 33:
                     var4 += iFld;
                     break;
                  case 34:
                     sFld += (short)((int)(var6 | (long)fFld));
                     break;
                  case 35:
                     var10000 = lArrFld;
                     var10000[(int)var6] >>= iFld;
                     break;
                  case 36:
                     var4 = 1;
                     break;
                  default:
                     instanceCount += var6 - (long)iFld;
               }
            }
         }
      }

      long var8 = (long)(var10 + var1 + var2 + var3) + var6 + (long)var4 + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var8;
      return (int)var8;
   }

   public void mainTest(String[] var1) {
      int var2 = 11387;
      boolean var3 = true;
      int var4 = 52;
      int var5 = -151;
      int var6 = 27;
      int var7 = -12;
      char var8 = '餓';
      int var9 = 21111;
      byte var10 = -12;
      int[] var11 = new int[400];
      float var12 = 2.582F;
      double var13 = 2.5768;
      long[][] var15 = new long[400][400];
      FuzzerUtils.init((int[])var11, (int)-14);
      FuzzerUtils.init(var15, 2641272992L);
      var11 = var11;
      var11[69] += 163;
      var2 = (int)((long)(var2--) - instanceCount--);
      ++var2;
      var12 -= (float)(var2 + iMeth());
      iFld += var2;

      int var20;
      for(var20 = 1; 151 > var20; ++var20) {
         for(var5 = 7; var5 < 167; ++var5) {
            var12 += (float)iFld;
            var11[var5] -= iFld;
            var4 >>= iFld;
            var2 |= (int)instanceCount;
            var6 ^= var2;
         }

         iFld *= var4;
         instanceCount = instanceCount;
         if (!bFld) {
            for(var7 = var20; var7 < 167; ++var7) {
               var6 = (int)instanceCount;
            }

            var11 = var11;
            instanceCount += (long)var20 * instanceCount + (long)var8 - (long)var20;
            var12 += (float)var8;

            for(var9 = 4; var9 < 167; ++var9) {
               if (!bFld) {
                  var11[var9] += (int)var13;
                  var2 += var9 * var8 + sFld - var7;
                  fFld = 0.101F;
                  var6 ^= var20;
               }
            }
         }
      }

      int[] var16 = var11;
      int var17 = var11.length;

      for(int var18 = 0; var18 < var17; ++var18) {
         int var10000 = var16[var18];
         var15[(var2 >>> 1) % 400][(var7 >>> 1) % 400] = (long)var9;
         fFld = (float)var6;
         this.sArrFld[(iFld >>> 1) % 400] = -28362;
      }

      FuzzerUtils.out.println("i f i12 = " + var2 + "," + Float.floatToIntBits(var12) + "," + var20);
      FuzzerUtils.out.println("i13 i14 i15 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i16 i17 i18 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i19 d1 iArr = " + var10 + "," + Double.doubleToLongBits(var13) + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + byFld);
      FuzzerUtils.out.println("Test.iFld Test.bFld Test.sFld = " + iFld + "," + (bFld ? 1 : 0) + "," + sFld);
      FuzzerUtils.out.println("Test.lArrFld sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 97L);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
