public class Test {
   public static final int N = 400;
   public static long instanceCount = -26853L;
   public static byte byFld = 91;
   public static short sFld = 22461;
   public static volatile int iFld = -182;
   public static boolean bFld = false;
   public static float fFld = -61.758F;
   public static boolean[] bArrFld = new boolean[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long iMeth_check_sum;

   public static int iMeth(byte var0, int var1) {
      boolean var2 = true;
      int var3 = -3;
      int var4 = -6123;
      int var5 = 1;
      int var6 = 8981;
      int var7 = 178;
      int var8 = -2;
      int[] var9 = new int[400];
      float var10 = -2.806F;
      FuzzerUtils.init((int[])var9, (int)33462);
      int var14 = 1;

      do {
         var1 ^= var14;
         var1 /= 215196806;
         var1 >>= 8;
         sFld += (short)((int)((long)var14 * instanceCount + (long)var1 - instanceCount));
         var10 += (float)instanceCount;
         label42:
         switch (var14 % 2 + 89) {
            case 89:
               for(var3 = 1; var3 < 6; ++var3) {
                  var4 |= var3;
               }
            case 90:
               var5 = 1;

               while(true) {
                  if (var5 >= 6) {
                     break label42;
                  }

                  var7 += (int)var10;
                  var8 = 1;

                  do {
                     int var10000 = var6 + var8;

                     try {
                        var7 = var9[var8 + 1] % -127;
                        var9[var14 + 1] = var3 / -989867320;
                        var6 = iFld / -476362724;
                     } catch (ArithmeticException var13) {
                     }

                     var6 = var7;
                     ++var8;
                  } while(var8 < 2);

                  ++var5;
               }
            default:
               bArrFld[var14 - 1] = bFld;
         }

         ++var14;
      } while(var14 < 274);

      long var11 = (long)(var0 + var1 + var14 + Float.floatToIntBits(var10) + var3 + var4 + var5 + var6 + var7 + var8) + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static void vMeth1(long var0, int var2) {
      boolean var3 = true;
      byte var4 = 0;
      int var5 = 5;
      int var6 = -16105;
      int var7 = -32;
      int var8 = 31192;
      int[] var9 = new int[400];
      float var10 = 7.325F;
      long[] var11 = new long[400];
      FuzzerUtils.init((int[])var9, (int)-21148);
      FuzzerUtils.init(var11, 9007L);

      int var12;
      for(var12 = 8; 149 > var12; ++var12) {
         byFld *= (byte)(iMeth((byte)-20, var2) + var2);
         var2 *= -39877;
         var2 = (int)((long)var2 + ((long)(var12 * var4 + var4) - var0));
         var9[var12 + 1] += byFld;

         for(var5 = 1; var5 < 11; ++var5) {
            var9 = var9;
            var11 = var11;
            iFld = (int)((long)iFld + ((long)(var5 * var6 + var2) - instanceCount));
            var6 += var2;

            for(var7 = 1; var7 < 2; ++var7) {
               var9[var12] >>= byFld;
               var6 = var8;
            }

            var8 += (int)var10;
            var2 -= 219;
         }
      }

      vMeth1_check_sum += var0 + (long)var2 + (long)var12 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var11);
   }

   public static void vMeth(int var0, long var1) {
      long var3 = -2609573023L;
      short var5 = 249;
      boolean var6 = true;
      int var7 = -6;
      boolean var8 = true;
      int var9 = 228;
      byte var10 = 14;
      int[] var11 = new int[400];
      float var12 = -1.49F;
      FuzzerUtils.init((int[])var11, (int)-11);
      vMeth1(instanceCount, var0);

      for(var3 = 7L; var3 < 251L; ++var3) {
         iFld -= (int)var12;
         var11 = var11;
         instanceCount >>= -2;
      }

      int var13;
      for(var13 = 262; 13 < var13; --var13) {
         fFld += (float)(var13 * var0);
      }

      int var14 = 1;

      do {
         iFld += var0;
         switch (var14 % 1 * 5 + 123) {
            case 127:
               for(var9 = 9; var9 > 1; --var9) {
                  var7 = (int)((long)var7 + ((long)(var9 * var7) + var3 - (long)var9));
                  var0 -= iFld;
                  var11[var9 - 1] &= var7;
                  iFld = (int)var1;
               }
         }

         ++var14;
      } while(var14 < 172);

      vMeth_check_sum += (long)var0 + var1 + var3 + (long)var5 + (long)Float.floatToIntBits(var12) + (long)var13 + (long)var7 + (long)var14 + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var11);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = 5700;
      int var5 = -13;
      int var6 = 151;
      int var7 = 56909;
      int var8 = 28700;
      int var9 = 8;
      int[][][] var10 = new int[400][400][400];
      double var11 = 1.15459;
      FuzzerUtils.init((Object[][])var10, 0);
      vMeth(45065, instanceCount);
      int var16 = 1;

      int var17;
      do {
         iFld = var16;
         instanceCount = -53819L;
         var17 = 1;

         label59:
         while(true) {
            ++var17;
            if (var17 >= 72) {
               try {
                  var5 = iFld % -35808;
                  var5 = -33188 % iFld;
                  var5 = var17 % 2;
               } catch (ArithmeticException var15) {
               }

               var11 += -7.0;
               switch (var16 % 4 + 86) {
                  case 86:
                     var11 *= -6715.0;
                     break label59;
                  case 87:
                     var5 = (int)instanceCount;

                     try {
                        var5 /= var17;
                        var10[var16 + 1][var16 - 1][var16 - 1] = 8863 % var4;
                        iFld = var5 % 28967;
                     } catch (ArithmeticException var14) {
                     }
                  case 88:
                     var5 -= 21;
                     if (!bFld) {
                        if (bFld) {
                           iFld = -4;
                        }
                        break label59;
                     }

                     var10[var16][var16 - 1][var16 + 1] = -4;
                     var6 = var16;

                     while(var6 < 72) {
                        bFld = bFld;

                        for(var8 = 1; var8 < 1; ++var8) {
                           var7 += var8;
                           bFld = bFld;
                        }

                        switch (var16 % 2 + 28) {
                           case 28:
                              instanceCount -= (long)var7;
                           case 29:
                              var10[(var5 >>> 1) % 400][var16 - 1][var6 + 1] = iFld;
                              var9 = (int)instanceCount;
                              var9 = var6;
                           default:
                              ++var6;
                        }
                     }
                     break label59;
                  case 89:
                     instanceCount -= (long)var7;
                  default:
                     instanceCount += (long)var8;
                     break label59;
               }
            }

            instanceCount += instanceCount;
            instanceCount = instanceCount;

            for(var4 = 1; var4 < 1; ++var4) {
               var5 += var4;
            }

            iFld >>= var5;
         }

         ++var16;
      } while(var16 < 350);

      FuzzerUtils.out.println("i22 i23 i24 = " + var16 + "," + var17 + "," + var4);
      FuzzerUtils.out.println("i25 d i26 = " + var5 + "," + Double.doubleToLongBits(var11) + "," + var6);
      FuzzerUtils.out.println("i27 i28 i29 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum((Object[][])var10));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + byFld + "," + sFld);
      FuzzerUtils.out.println("Test.iFld Test.bFld Test.fFld = " + iFld + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bArrFld = " + FuzzerUtils.checkSum(bArrFld));
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(bArrFld, false);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      iMeth_check_sum = 0L;
   }
}
