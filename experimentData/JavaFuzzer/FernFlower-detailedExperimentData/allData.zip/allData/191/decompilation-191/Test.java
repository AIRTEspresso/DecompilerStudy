public class Test {
   public static final int N = 400;
   public static long instanceCount = 62L;
   public static short sFld = -32176;
   public static float fFld = 0.12F;
   public static boolean bFld = true;
   public double dFld = 1.68015;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static long[][] lArrFld1 = new long[400][400];
   public short[] sArrFld = new short[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2() {
      boolean var0 = true;
      int var1 = 9497;
      int var2 = 20114;
      int var3 = -126;
      boolean var4 = true;
      int var5 = -8374;
      int var6 = -3;
      byte var7 = 14;
      int[] var8 = new int[400];
      double var9 = 2.51093;
      float var11 = 17.197F;
      boolean var12 = true;
      FuzzerUtils.init((int[])var8, (int)-13464);

      int var14;
      for(var14 = 264; var14 > 1; --var14) {
         for(var9 = 6.0; var9 > 1.0; --var9) {
            short var13 = -25066;
            var13 &= (short)var1;
            var3 = 1;

            while(true) {
               ++var3;
               if (var3 >= 2) {
                  instanceCount += (long)var9 | (long)var2;
                  break;
               }

               instanceCount = -4L;
            }
         }

         var2 *= var2;
         var2 = var2;
         var1 /= (int)(instanceCount | 1L);
      }

      int var15;
      label43:
      for(var15 = 18; var15 < 289; ++var15) {
         switch (var15 % 6 + 75) {
            case 75:
               var6 = 1;

               while(true) {
                  if (var6 >= 6) {
                     continue label43;
                  }

                  instanceCount += (long)var6;
                  var5 = (int)var9;
                  var1 >>= var1;
                  ++var6;
               }
            case 76:
               var8[var15 + 1] &= -3;
               break;
            case 77:
               var11 += (float)var15;
               break;
            case 78:
            case 79:
               instanceCount *= (long)var1;
            case 80:
               if (var12) {
               }
         }
      }

      vMeth2_check_sum += (long)(var14 + var1) + Double.doubleToLongBits(var9) + (long)var2 + (long)var3 + (long)var15 + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var11) + (long)(var12 ? 1 : 0) + FuzzerUtils.checkSum(var8);
   }

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = 4;
      int var2 = -12;
      byte var3 = -9;
      int var4 = -52298;
      double var5 = 14.114085;
      vMeth2();
      int var8 = 144;

      while(true) {
         var8 -= 2;
         if (var8 <= 0) {
            vMeth1_check_sum += (long)var8 + Double.doubleToLongBits(var5) + (long)var1 + (long)var2 + (long)var3 + (long)var4;
            return;
         }

         for(var5 = 1.0; 21.0 > var5; ++var5) {
            iArrFld[(int)(var5 - 1.0)] = sFld;
            var1 *= sFld;

            long[] var10000;
            for(var2 = 1; var2 < 2; ++var2) {
               boolean var7 = false;
               if (!var7) {
                  var10000 = lArrFld;
                  var10000[var8 + 1] *= (long)var8;
                  var1 *= var2;
               }
            }

            sFld = (short)(sFld << 0);
            var1 %= (int)((long)fFld | 1L);
            var1 -= var8;
            lArrFld[var8 + 1] = (long)var4;
            var10000 = lArrFld;
            var10000[var8 - 1] -= -1L;
            bFld = bFld;
         }
      }
   }

   public static void vMeth(long var0) {
      int var2 = 1;
      boolean var3 = true;
      int var4 = 207;
      int var5 = 0;
      vMeth1();
      iArrFld[365] = var2;
      lArrFld1 = lArrFld1;

      int var7;
      for(var7 = 4; var7 < 174; ++var7) {
         iArrFld[var7] = (int)var0;
         var5 = 1;

         do {
            byte var6 = -22;
            var2 -= var2;
            var0 = -69L;
            switch (var5 % 1 + 91) {
               case 91:
                  label34:
                  switch ((var2 >>> 1) % 10 + 18) {
                     case 18:
                        instanceCount += (long)(var5 + var7);
                        switch (var7 % 1 + 53) {
                           case 53:
                              if (bFld) {
                                 break label34;
                              }

                              instanceCount >>= var5;
                              break;
                           default:
                              fFld += (float)(var5 * var4);
                        }
                     case 19:
                        var2 += 5990;
                        break;
                     case 20:
                        instanceCount &= -894L;
                        break;
                     case 21:
                        var4 += var6;
                        break;
                     case 22:
                        var4 = var7;
                        break;
                     case 23:
                        var4 >>= 9;
                        break;
                     case 24:
                        var4 -= (int)var0;
                        break;
                     case 25:
                        var4 -= var5;
                        break;
                     case 26:
                        var4 += var5 * var5;
                        break;
                     case 27:
                        long[] var10000 = lArrFld1[var7];
                        var10000[var7] -= (long)var4;
                  }
            }

            ++var5;
         } while(var5 < 9);
      }

      vMeth_check_sum += var0 + (long)var2 + (long)var7 + (long)var4 + (long)var5;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -3;
      int var4 = 35;
      int var5 = 58518;
      int var6 = -197;
      int var7 = 12;
      int var8 = 119;
      int var9 = -5;
      int var10 = 135;
      int var11 = 18457;

      int var15;
      for(var15 = 7; 124 > var15; ++var15) {
         vMeth(instanceCount);
         var3 *= (int)instanceCount;
         instanceCount <<= (int)instanceCount;

         label87:
         for(var4 = 1; 214 > var4; ++var4) {
            fFld += (float)var4;
            int[] var10000;
            switch (var4 % 9 + 84) {
               case 84:
                  var3 += var4 * var5 + var15 - var4;

                  for(var6 = var15; 2 > var6; ++var6) {
                     byte var12 = -107;
                     fFld -= (float)instanceCount;
                     var7 *= -10106;
                     lArrFld1[var6 + 1][var6] = 170L;

                     try {
                        iArrFld[var6] = 17819 % var3;
                        var7 = var15 % -151;
                        var8 = -4555 % var4;
                     } catch (ArithmeticException var14) {
                     }

                     var5 = var12;
                  }

                  for(var9 = 1; var9 < 2; ++var9) {
                     var5 *= var6;
                     var7 = (int)instanceCount;
                  }

                  switch (var15 % 2 + 20) {
                     case 20:
                        if (bFld) {
                        }
                        continue;
                     case 21:
                        var11 = 1;

                        while(true) {
                           ++var11;
                           if (var11 >= 2) {
                              continue label87;
                           }

                           instanceCount -= 13925L;
                           var5 += var11;
                           short[] var17 = this.sArrFld;
                           var17[var11 + 1] += (short)((int)instanceCount);
                           var10000 = iArrFld;
                           var10000[var4 - 1] -= var6;
                           var3 *= var10;
                           var8 += 62719;
                           switch (var4 % 9 + 46) {
                              case 46:
                                 instanceCount -= (long)var5;
                                 sFld += (short)(5 + var11 * var11);
                                 iArrFld[var11 - 1] = 237;
                                 break;
                              case 47:
                                 var8 *= var11;
                              case 48:
                                 var5 += (int)instanceCount;
                                 break;
                              case 49:
                                 var7 *= var4;
                              case 50:
                                 var7 >>= (int)instanceCount;
                              case 51:
                                 var10 >>= -10;
                                 break;
                              case 52:
                                 this.dFld += (double)var4;
                                 break;
                              case 53:
                                 var3 = (int)instanceCount;
                                 break;
                              case 54:
                                 var8 = 1;
                              default:
                                 this.dFld += (double)fFld;
                           }
                        }
                  }
               case 85:
                  iArrFld[var15] = var4;
                  break;
               case 86:
               case 87:
                  var10000 = iArrFld;
                  var10000[var4] += (int)instanceCount;
                  break;
               case 88:
                  var3 += 1671591720;
                  break;
               case 89:
                  boolean var16 = true;
               case 90:
                  var7 = (int)instanceCount;
                  break;
               case 91:
                  var3 -= var6;
                  break;
               case 92:
                  var3 *= (int)instanceCount;
            }
         }
      }

      FuzzerUtils.out.println("i i1 i19 = " + var15 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i20 i21 i22 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i23 i24 i25 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i26 = " + var11);
      FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + sFld + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.bFld dFld Test.iArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.lArrFld Test.lArrFld1 sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(lArrFld1) + "," + FuzzerUtils.checkSum(this.sArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)5678);
      FuzzerUtils.init(lArrFld, 7L);
      FuzzerUtils.init(lArrFld1, 18881L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
