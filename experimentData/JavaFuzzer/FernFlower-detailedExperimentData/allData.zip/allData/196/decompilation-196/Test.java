public class Test {
   public static final int N = 400;
   public static long instanceCount = 31L;
   public volatile byte byFld = -90;
   public static short sFld = 24809;
   public boolean bFld = true;
   public static int[] iArrFld = new int[400];
   public static volatile byte[] byArrFld = new byte[400];
   public static long[][] lArrFld = new long[400][400];
   public float[] fArrFld = new float[400];
   public static long fMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = 1;
      int var2 = -1;
      float var3 = 39.809F;
      double[] var4 = new double[400];
      FuzzerUtils.init(var4, 0.116437);
      int var5 = 1;

      while(true) {
         ++var5;
         if (var5 >= 248) {
            vMeth1_check_sum += (long)(var5 + var1 + var2 + Float.floatToIntBits(var3)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var4));
            return;
         }

         for(var1 = 1; var1 < 7; ++var1) {
            var4[var5 + 1] *= (double)instanceCount;
            iArrFld[var5] = (int)instanceCount;
            byArrFld[var5] = (byte)var5;
            var2 *= (int)var3;
            var3 -= (float)var1;
         }
      }
   }

   public static void vMeth(int var0) {
      short var1 = 135;
      int var2 = 89;
      int var3 = -53907;
      int var4 = 0;
      short var5 = -2102;
      float var6 = 14.461F;
      float[] var7 = new float[400];
      long[] var8 = new long[400];
      FuzzerUtils.init(var7, 0.426F);
      FuzzerUtils.init(var8, 5058943701552193298L);
      var0 <<= (int)Math.min((long)(var7[(var0 >>> 1) % 400] * (float)(var0 - var1)), (long)(25240 - (var0 + var0)));
      vMeth1();
      int[] var9 = iArrFld;
      int var10 = var9.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var10000 = var9[var11];
         boolean var13 = false;
         if (var13) {
            break;
         }

         for(var2 = 1; 4 > var2; ++var2) {
            var6 += (float)var1;

            for(var4 = 1; var4 < 2; ++var4) {
               iArrFld = iArrFld;
               instanceCount = -20L;
               var6 *= (float)var5;
               var8[var2] = (long)var2;
               instanceCount <<= var4;
               var0 += (int)instanceCount;
               iArrFld = FuzzerUtils.int1array(400, 30646);
               var3 += var1;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + Float.floatToIntBits(var6) + var4 + var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var7)) + FuzzerUtils.checkSum(var8);
   }

   public static float fMeth(long var0) {
      boolean var2 = true;
      int var3 = 104;
      int var4 = 10;
      int var5 = -7;
      int var6 = -214;
      int var7 = -28916;
      int var8 = -79;
      int var9 = 1;
      byte var10 = -127;
      boolean var11 = false;
      double var12 = 94.20718;

      int var17;
      for(var17 = 6; var17 < 317; ++var17) {
         vMeth(var17);

         for(var4 = var17; var4 < 5; var4 += 3) {
            try {
               var5 = var3 % 1297331538;
               iArrFld[var17 + 1] = var6 % 704792885;
               var6 = -64980 / iArrFld[var17 - 1];
            } catch (ArithmeticException var16) {
            }

            var6 |= sFld;
            var6 -= var10;

            for(var7 = var17; var7 < 1; ++var7) {
               switch (128) {
                  case 115:
                     var6 = var7;
                     var8 >>>= (int)var0;
                     var0 &= 22005L;
                  case 152:
                     lArrFld[var17 + 1][var4 - 1] = (long)var9;
                     var9 <<= var17;
                     var0 = (long)var7;
                     break;
                  case 117:
                     iArrFld[var17] = var8;
                     break;
                  case 126:
                     var5 = 1359880625;
                  case 150:
                     var11 = false;
                     break;
                  case 136:
                     var3 -= (int)instanceCount;
                     break;
                  case 137:
                     instanceCount += (long)(142 + var7 * var7);
                     break;
                  case 148:
                     var12 -= var12;
                     break;
                  default:
                     var0 = (long)var12;
               }
            }
         }
      }

      long var14 = var0 + (long)var17 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var10 + (long)var7 + (long)var8 + (long)var9 + (long)(var11 ? 1 : 0) + Double.doubleToLongBits(var12);
      fMeth_check_sum += var14;
      return (float)var14;
   }

   public void mainTest(String[] var1) {
      int var2 = 65203;
      boolean var3 = true;
      int var4 = -161;
      int var5 = -9;
      byte var6 = -3;
      int var7 = 192;
      float var8 = 12.179F;
      var2 += (int)((long)(-(var2 *= var2)) + (long)var2 + (long)var2 * instanceCount);
      var2 = (int)(instanceCount--);

      int var9;
      for(var9 = 123; var9 > 6; --var9) {
         this.byFld <<= (byte)((int)(++instanceCount));
         var4 *= (int)fMeth(instanceCount);
         instanceCount = (long)var4;
         var2 = var2;
         instanceCount *= (long)var2;

         for(var5 = 5; 214 > var5; ++var5) {
            sFld >>= sFld;
            var7 = 1;

            do {
               instanceCount += (long)(var7 * this.byFld + var9 - var2);
               this.bFld = this.bFld;
               instanceCount |= 43494L;
               var4 += var7 | var2;
               this.fArrFld[var7 - 1] = (float)var5;
               var8 += (float)var7;
               this.byFld += (byte)((int)((float)var7 * var8));
               switch ((var5 >>> 1) % 1 + 12) {
                  case 12:
                     if (this.bFld) {
                        break;
                     }

                     instanceCount = 69L;
                     var4 -= var9;
                     var2 += var7;
                  default:
                     if (this.bFld) {
                        ++instanceCount;
                        iArrFld = iArrFld;
                        lArrFld[var7 - 1][var5] = instanceCount;
                        var2 <<= var7;
                     } else {
                        var2 <<= 212;
                     }

                     var2 -= 1112228430;
               }

               var7 += 2;
            } while(var7 < 2);
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var9 + "," + var4);
      FuzzerUtils.out.println("i21 i22 i23 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("f2 = " + Float.floatToIntBits(var8));
      FuzzerUtils.out.println("Test.instanceCount byFld Test.sFld = " + instanceCount + "," + this.byFld + "," + sFld);
      FuzzerUtils.out.println("bFld Test.iArrFld Test.byArrFld = " + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
      FuzzerUtils.out.println("Test.lArrFld fArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(iArrFld, -33534);
      FuzzerUtils.init(byArrFld, (byte)-3);
      FuzzerUtils.init(lArrFld, -54089L);
      fMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
