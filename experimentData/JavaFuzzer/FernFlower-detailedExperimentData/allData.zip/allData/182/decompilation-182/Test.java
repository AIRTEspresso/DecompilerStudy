public class Test {
   public static final int N = 400;
   public static long instanceCount = 254L;
   public static float fFld = -2.83F;
   public static double dFld = 8.102582;
   public static volatile float fFld1 = -126.86F;
   public volatile int iFld = 26;
   public boolean bFld = true;
   public static short[] sArrFld = new short[400];
   public static int[] iArrFld = new int[400];
   public static long fMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      int var0 = 46803;
      int var1 = 95;
      int var2 = 111;
      int var3 = -232;
      int var4 = 12;
      int[] var5 = new int[400];
      FuzzerUtils.init((int[])var5, (int)18877);

      for(var0 = 3; var0 < 167; ++var0) {
         for(var2 = var0; var2 < 10; var2 += 3) {
            var3 += 83;
            var4 = 1;

            do {
               try {
                  var3 = var1 % -87;
                  var1 = var4 % 522520565;
                  var3 = var1 / var4;
               } catch (ArithmeticException var7) {
               }

               int var10000 = var1 << var3;
               instanceCount = 235L;
               var5[var2 - 1] += var0;
               var1 = var0;
               instanceCount &= 63032L;
               var3 *= var2;
               fFld += (float)var0;
               fFld = (float)var3;
               ++var4;
            } while(var4 < 1);

            var3 = var0;
            var5[var2 + 1] >>= 20184;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4) + FuzzerUtils.checkSum(var5);
   }

   public static void vMeth(int var0, long var1, int var3) {
      boolean var4 = false;
      int var5 = -8;
      int var6 = 4;
      float[] var7 = new float[400];
      FuzzerUtils.init(var7, 2.921F);
      short[] var8 = sArrFld;
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         short var11 = var8[var10];
         vMeth1();
         var1 |= var1;
         if (!var4) {
            try {
               var3 = var0 / var0;
               var3 = iArrFld[47] / -82044512;
               var3 /= iArrFld[(var0 >>> 1) % 400];
            } catch (ArithmeticException var13) {
            }

            switch (54) {
               case 53:
                  var3 -= (int)fFld;
                  var0 = (int)instanceCount;
                  var3 = (int)var1;
               case 54:
                  iArrFld[(var0 >>> 1) % 400] = (int)dFld;
                  break;
               default:
                  for(var5 = 4; var5 > 1; var5 -= 2) {
                     fFld1 += (float)var5;
                     if (var6 != 0) {
                        vMeth_check_sum += (long)var0 + var1 + (long)var3 + (long)(var4 ? 1 : 0) + (long)var5 + (long)var6 + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
                        return;
                     }

                     var6 -= var11;
                     var7[var5] -= (float)var1;
                  }
            }
         }
      }

      vMeth_check_sum += (long)var0 + var1 + (long)var3 + (long)(var4 ? 1 : 0) + (long)var5 + (long)var6 + Double.doubleToLongBits(FuzzerUtils.checkSum(var7));
   }

   public static float fMeth(long var0, long var2, int var4) {
      boolean var5 = true;
      int var6 = 52935;
      byte var7 = -7;
      float var8 = -2.29F;
      byte var9 = -7;

      int var12;
      for(var12 = 4; var12 < 170; ++var12) {
         vMeth(64278, instanceCount, var4);
         var4 += var12;
      }

      for(var8 = 7.0F; 135.0F > var8; ++var8) {
         var6 *= var9;
         var9 = (byte)var4;
         instanceCount = (long)var7;
         var6 = var6;
      }

      long var10 = var0 + var2 + (long)var4 + (long)var12 + (long)var6 + (long)Float.floatToIntBits(var8) + (long)var7 + (long)var9;
      fMeth_check_sum += var10;
      return (float)var10;
   }

   public void mainTest(String[] var1) {
      int var2 = 53565;
      int var3 = 44;
      int var4 = 45277;
      short var5 = -250;
      int var6 = 4;
      int var7 = -32626;
      int var8 = -33329;
      int var9 = 223;
      int var10 = 51;
      byte var11 = -8;
      int var12 = -9;
      int var13 = 7;
      float var14 = -72.251F;
      float[] var15 = new float[400];
      byte var16 = 44;
      long[] var17 = new long[400];
      double[][][] var18 = new double[400][400][400];
      FuzzerUtils.init(var17, 2806961701L);
      FuzzerUtils.init(var15, -83.532F);
      FuzzerUtils.init((Object[][])var18, 0.32342);

      for(var2 = 142; var2 > 5; --var2) {
         var17[var2 + 1] = (long)(var14++ + (float)(++instanceCount) + (float)(var3 = (int)fMeth(instanceCount, -13L, -17554)));

         for(var4 = 183; var4 > 2; --var4) {
            instanceCount += (long)var4;
            switch ((var2 >>> 1) % 2 + 118) {
               case 118:
                  for(var6 = 1; var6 < 2; ++var6) {
                     var3 += var6 * var3 + var4 - var2;
                     var7 = var8;
                  }

                  int[] var10000;
                  for(var9 = 1; 2 > var9; ++var9) {
                     var10000 = iArrFld;
                     var10000[var4 + 1] -= var6;
                     var7 += var9 * var9;
                     var10 *= (int)instanceCount;
                     this.iFld ^= var2;
                     var10000 = iArrFld;
                     var10000[var2 + 1] -= this.iFld;
                     this.iFld = (int)var14;
                     var8 = var11;
                     if (this.bFld) {
                        var10 = var6;
                        var15[var4] += fFld;
                        if (this.bFld) {
                           continue;
                        }
                     } else {
                        var8 = var11 * this.iFld;
                     }

                     instanceCount += 20908L;
                  }

                  for(var12 = var2; var12 < 2; ++var12) {
                     var13 = var7;
                     var10000 = iArrFld;
                     var10000[var2 - 1] ^= -32025;
                     var18[var2 - 1][var2 + 1][var2] *= -96.0;
                     instanceCount = instanceCount;
                     instanceCount = (long)var5;
                  }
               case 119:
                  var16 = (byte)var9;
            }
         }
      }

      FuzzerUtils.out.println("i i1 f = " + var2 + "," + var3 + "," + Float.floatToIntBits(var14));
      FuzzerUtils.out.println("i15 i16 i17 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i18 i19 i20 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i21 i22 i23 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("i24 by1 lArr = " + var13 + "," + var16 + "," + FuzzerUtils.checkSum(var17));
      FuzzerUtils.out.println("fArr1 dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var15)) + "," + Double.doubleToLongBits((double)FuzzerUtils.checkSum((Object[][])var18)));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.fFld1 iFld bFld = " + Float.floatToIntBits(fFld1) + "," + this.iFld + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.sArrFld Test.iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((short[])sArrFld, (short)9775);
      FuzzerUtils.init(iArrFld, -51588);
      fMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
