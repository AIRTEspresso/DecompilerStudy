public class Test {
   public static final int N = 400;
   public static long instanceCount = 2413526288303012764L;
   public static volatile short[] sArrFld = new short[400];
   public static long iMeth_check_sum;
   public static long sMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(float var0, long var1, long var3) {
      boolean var5 = true;
      int var6 = -34456;
      int var7 = -5;
      byte var8 = 10;
      int var9 = -7;
      byte var10 = 1;
      int var11 = 34833;
      byte var12 = -59;
      int[] var13 = new int[400];
      double var14 = 2.110089;
      double var16 = 21.102981;
      float[] var18 = new float[400];
      FuzzerUtils.init((int[])var13, (int)-64);
      FuzzerUtils.init(var18, 1.897F);

      int var19;
      for(var19 = 21; var19 < 351; ++var19) {
         var6 <<= (int)var1;
         var7 = 1;

         while(true) {
            ++var7;
            if (var7 >= 5) {
               break;
            }

            var6 += var7 * var7;
            var13[var7] += -1;
            var1 += (long)var7;
         }
      }

      for(var14 = 9.0; var14 < 289.0; ++var14) {
         var6 = var19;
         var1 = (long)var19;
         var16 = (double)var3;

         for(var9 = 1; 6 > var9; ++var9) {
            var18[(int)(var14 + 1.0)] = (float)var8;

            for(var11 = 2; (double)var11 > var14; --var11) {
               var3 *= 1983042612573643745L;
            }

            var0 += 0.668F;
         }
      }

      vMeth_check_sum += (long)Float.floatToIntBits(var0) + var1 + var3 + (long)var19 + (long)var6 + (long)var7 + Double.doubleToLongBits(var14) + (long)var8 + Double.doubleToLongBits(var16) + (long)var9 + (long)var10 + (long)var11 + (long)var12 + FuzzerUtils.checkSum(var13) + Double.doubleToLongBits(FuzzerUtils.checkSum(var18));
   }

   public static short sMeth(float var0, float var1, int var2) {
      double var3 = -1.44768;
      boolean var5 = true;
      int var6 = 55611;
      int var7 = 23807;
      short var8 = -21662;
      int var9 = -44272;
      int[] var10 = new int[400];
      long[] var11 = new long[400];
      FuzzerUtils.init(var11, 13L);
      FuzzerUtils.init((int[])var10, (int)38707);
      var3 = 75.0;
      vMeth(var0, instanceCount, instanceCount);
      var2 -= 25;
      var2 = (int)var3;

      int var14;
      for(var14 = 4; var14 < 235; ++var14) {
         for(var7 = var14; var7 < 7; ++var7) {
            var9 -= 36;
         }

         var6 += var14 + var9;
         var9 = -20321;
         var11 = var11;
         var10[var14 - 1] = (int)instanceCount;
         var3 = 138.0;
         int var10000 = var6 | var2;
         var6 = (int)instanceCount;
         var11[var14 - 1] -= (long)var2;
      }

      long var12 = (long)(Float.floatToIntBits(var0) + Float.floatToIntBits(var1) + var2) + Double.doubleToLongBits(var3) + (long)var14 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var11) + FuzzerUtils.checkSum(var10);
      sMeth_check_sum += var12;
      return (short)((int)var12);
   }

   public static int iMeth(long var0) {
      double var2 = -2.58044;
      int var4 = 36;
      boolean var5 = true;
      int var6 = -60753;
      int var7 = -109;
      int var8 = -31278;
      int[] var9 = new int[400];
      boolean var10 = true;
      float var11 = -11.79F;
      FuzzerUtils.init((int[])var9, (int)6);

      for(var2 = 7.0; 248.0 > var2; var2 += 3.0) {
         sArrFld[(int)(var2 + 1.0)] = (short)((int)(var0++));
      }

      var4 <<= (int)(-((long)var4 - (instanceCount - (long)var4)));
      short var15 = (short)(var4 - sArrFld[(var4 >>> 1) % 400] * sMeth(var11, var11, var4));
      var4 -= var4;
      var4 += var4;

      int var14;
      for(var14 = 14; var14 < 350; ++var14) {
         var6 += var14;
         var6 += var14 * var14;
         var15 = (short)(var15 << -6);

         for(var7 = 5; var7 > 1; --var7) {
            var8 = var14;
            var6 -= var7;
         }

         instanceCount += (long)(var14 * var14);
      }

      var9[119] >>= var15;
      long var12 = var0 + Double.doubleToLongBits(var2) + (long)var4 + (long)var15 + (long)Float.floatToIntBits(var11) + (long)var14 + (long)var6 + (long)var7 + (long)var8 + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void mainTest(String[] var1) {
      int var2 = -46445;
      int var3 = -9;
      int var4 = -504;
      int var5 = -4;
      short var6 = -22060;
      int[][][] var7 = new int[400][400][400];
      float var8 = 1.269F;
      short var9 = 8144;
      short[][][] var10 = new short[400][400][400];
      double var11 = 1.25554;
      double var13 = -114.77433;
      double[][] var15 = new double[400][400];
      long[] var16 = new long[400];
      FuzzerUtils.init((Object[][])var7, -4);
      FuzzerUtils.init(var16, 1L);
      FuzzerUtils.init((Object[][])var10, -5904);
      FuzzerUtils.init(var15, 2.125263);

      for(var2 = 2; var2 < 247; ++var2) {
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 103) {
               break;
            }

            var8 += (float)iMeth(instanceCount);
            var3 = var9 + var9;
            instanceCount += (long)(var4 * var4);
            var11 += (double)var4;
            var13 = 1.0;

            while(true) {
               instanceCount >>>= var4;
               label44:
               switch (var2 % 6 + 3) {
                  case 3:
                     try {
                        var7[var4][var4 - 1][(var3 >>> 1) % 400] = var2 % var4;
                        var3 = 1509 / var3;
                        var7[(int)(var13 + 1.0)][var4][var2] = var7[var4][var4][(int)var13] / var7[(int)var13][(int)(var13 + 1.0)][var2 + 1];
                     } catch (ArithmeticException var18) {
                     }

                     var3 = var2 * var9;
                  case 4:
                     var16[var4] <<= var3;
                  case 5:
                     var3 *= (int)var13;
                     var3 += var2;
                     var7[(int)(var13 - 1.0)][(int)var13][(int)var13] += -30008;
                     break;
                  case 6:
                     var7[var4 - 1][(int)(var13 + 1.0)] = var7[(var2 >>> 1) % 400][var2 + 1];
                     switch ((int)(var13 % 8.0 * 5.0 + 63.0)) {
                        case 71:
                           var11 += (double)instanceCount;
                           var10 = var10;
                           var3 = var3;
                           break label44;
                        case 75:
                           var3 -= (int)instanceCount;
                           break label44;
                        case 89:
                           var5 += (int)(var13 * (double)instanceCount + (double)var3 - (double)instanceCount);
                           break label44;
                        case 94:
                           instanceCount += (long)var13;
                        case 92:
                           var7[var2][(int)var13] = var7[(int)var13][(int)(var13 + 1.0)];
                           break label44;
                        case 98:
                           var3 >>= var9;
                           switch ((int)(var13 % 1.0 * 5.0 + 1.0)) {
                              case 2:
                                 var8 *= (float)var4;
                                 var3 <<= var4;
                                 var3 -= var3;
                                 var3 += (int)var8;
                                 break label44;
                              default:
                                 var3 -= var9;
                                 break label44;
                           }
                        case 103:
                           var15[var2 + 1][var2 - 1] *= (double)var2;
                        case 96:
                           instanceCount = 45127L;
                        default:
                           break label44;
                     }
                  case 7:
                     instanceCount = -46915L;
                     break;
                  case 8:
                     var8 *= (float)var6;
                     break;
                  default:
                     var8 -= var8;
               }

               if (!(++var13 < 1.0)) {
                  break;
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("f s1 d4 = " + Float.floatToIntBits(var8) + "," + var9 + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("d5 i22 i23 = " + Double.doubleToLongBits(var13) + "," + var5 + "," + var6);
      FuzzerUtils.out.println("iArr3 lArr1 sArr = " + FuzzerUtils.checkSum((Object[][])var7) + "," + FuzzerUtils.checkSum(var16) + "," + FuzzerUtils.checkSum((Object[][])var10));
      FuzzerUtils.out.println("dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var15)));
      FuzzerUtils.out.println("Test.instanceCount Test.sArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((short[])sArrFld, (short)9289);
      iMeth_check_sum = 0L;
      sMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
