public class Test {
   public static final int N = 400;
   public static long instanceCount = 6410838818528573617L;
   public static int iFld = 13;
   public static int iFld1 = 231;
   public static boolean bFld = true;
   public static float[] fArrFld = new float[400];
   public static long bMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = -32166;
      int var2 = 24633;
      short var3 = 28969;
      int var4 = -6;
      int[] var5 = new int[400];
      double var6 = 1.74993;
      boolean var8 = false;
      long[] var9 = new long[400];
      FuzzerUtils.init((int[])var5, (int)3);
      FuzzerUtils.init(var9, 2603973738L);
      iFld = (int)instanceCount;

      int var13;
      label49:
      for(var13 = 4; 285 > var13; ++var13) {
         float var10 = 2.737F;

         try {
            var1 = var5[var13 - 1] % -145;
            int var10000 = var1 / var13;
            var1 = -1738862258 % iFld;
         } catch (ArithmeticException var12) {
         }

         switch ((var13 >>> 1) % 2 * 5 + 109) {
            case 110:
               if (var8) {
                  var2 = 1;

                  while(true) {
                     if (var2 >= 6) {
                        continue label49;
                     }

                     var4 = 1;

                     do {
                        var5 = var5;
                        iFld *= -1;
                        var6 = (double)var2;
                        var6 -= -5770.0;
                        var9[var2] |= instanceCount;
                        ++var4;
                     } while(var4 < 2);

                     var1 += 14;
                     ++var2;
                  }
               } else {
                  var1 = 0;
                  break;
               }
            case 118:
               var1 /= 18222;
         }
      }

      vMeth1_check_sum += (long)(var13 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var6) + (long)(var8 ? 1 : 0) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var9);
   }

   public static void vMeth(int var0, int var1, float var2) {
      boolean var3 = true;
      int var4 = -33757;
      int var5 = 58530;
      byte var6 = 4;
      int var7 = 180;
      boolean var8 = false;
      double var9 = 1.41276;
      double[] var11 = new double[400];
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, -6080L);
      FuzzerUtils.init(var11, -23.37426);
      vMeth1();
      var12[255] = (long)iFld;

      int var13;
      for(var13 = 11; 327 > var13; ++var13) {
         var4 -= 823354691;
         var1 |= 8;

         for(var5 = 1; var5 < 5; ++var5) {
            var11[var5 + 1] = (double)iFld;
            if (var8) {
               break;
            }

            var7 = 1;

            do {
               switch (var13 % 2 * 5 + 50) {
                  case 56:
                     instanceCount -= 0L;
                     var12[(var0 >>> 1) % 400] >>= 168;
                     var4 = var7;
                     var1 += (int)var9;
                  case 58:
                     instanceCount += (long)var13;
               }

               ++var7;
            } while(var7 < 2);
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + var13 + var4 + var5 + var6 + (var8 ? 1 : 0) + var7) + Double.doubleToLongBits(var9) + FuzzerUtils.checkSum(var12) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11));
   }

   public static boolean bMeth(int var0) {
      int var1 = -63371;
      int var2 = -248;
      boolean var3 = true;
      int var4 = -203;
      short var5 = 32545;
      float var6 = 6.663F;
      byte var7 = 116;
      byte[][] var8 = new byte[400][400];
      long var9 = 130L;
      boolean var11 = true;
      FuzzerUtils.init(var8, (byte)-49);

      for(var1 = 7; var1 < 323; ++var1) {
         var0 = (int)(++instanceCount);
      }

      var6 = 1.0F;

      while(++var6 < 391.0F) {
         var2 ^= Math.abs(14);
         vMeth(98, var0, var6);
      }

      iFld += var0;
      instanceCount += instanceCount;

      int var14;
      for(var14 = 4; var14 < 154; ++var14) {
         var4 += var14 * iFld + var4 - var14;
         var7 -= (byte)iFld;

         for(var9 = 1L; var9 < 11L; ++var9) {
            var2 = (int)var9;
         }

         if (!var11) {
            var8[var14] = var8[var14 + 1];
         }
      }

      instanceCount = -4982L;
      long var12 = (long)(var0 + var1 + var2 + Float.floatToIntBits(var6) + var14 + var4 + var7) + var9 + (long)var5 + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var8);
      bMeth_check_sum += var12;
      return var12 % 2L > 0L;
   }

   public void mainTest(String[] var1) {
      float var2 = 0.236F;
      boolean var3 = true;
      int var4 = -64;
      int var5 = -1;
      int var6 = 15918;
      int var7 = 13;
      int var8 = 200;
      int[] var9 = new int[400];
      int[] var10 = new int[400];
      byte var11 = 96;
      double var12 = -2.9206;
      boolean[] var14 = new boolean[400];
      short[] var15 = new short[400];
      FuzzerUtils.init(var14, false);
      FuzzerUtils.init(var9, -40735);
      FuzzerUtils.init((int[])var10, (int)41);
      FuzzerUtils.init(var15, (short)-18776);

      for(var2 = 311.0F; (var2 -= 3.0F) > 0.0F; var14[(int)var2] = bMeth(iFld)) {
      }

      int var16;
      for(var16 = 21; var16 < 363; ++var16) {
         instanceCount += -27196L;
         float[] var10000 = fArrFld;
         var10000[var16 + 1] -= (float)iFld;
         instanceCount &= 32499L;

         for(var5 = 2; var5 < 74; ++var5) {
            var7 = 1;

            do {
               if (bFld) {
                  instanceCount += (long)(var7 - var11);
                  iFld >>>= var16;
                  switch (var5 % 2 * 5 + 122) {
                     case 125:
                        instanceCount += (long)var7;
                        instanceCount *= (long)var12;
                        iFld1 += 57;
                        var4 -= var4;
                     case 130:
                     default:
                        var10[var16] = (int)instanceCount;
                        iFld1 *= (int)instanceCount;
                        instanceCount -= (long)iFld;
                  }
               }

               var10[var16] -= 9;
               iFld |= (int)instanceCount;
               var6 = iFld1;
               ++var7;
            } while(var7 < 2);

            iFld1 *= 9;
            var8 = 1;

            while(true) {
               ++var8;
               if (var8 >= 2) {
                  break;
               }

               var15[var8 - 1] *= (short)var6;
            }
         }

         var15[var16 - 1] -= (short)((int)instanceCount);
      }

      iFld = (int)instanceCount;
      var6 ^= var4;
      var10[27] += iFld1;
      FuzzerUtils.out.println("f i19 i20 = " + Float.floatToIntBits(var2) + "," + var16 + "," + var4);
      FuzzerUtils.out.println("i21 i22 i23 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("by1 d2 i24 = " + var11 + "," + Double.doubleToLongBits(var12) + "," + var8);
      FuzzerUtils.out.println("bArr iArr1 iArr2 = " + FuzzerUtils.checkSum(var14) + "," + FuzzerUtils.checkSum(var9) + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("sArr = " + FuzzerUtils.checkSum(var15));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
      FuzzerUtils.out.println("Test.bFld Test.fArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 42.196F);
      bMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
