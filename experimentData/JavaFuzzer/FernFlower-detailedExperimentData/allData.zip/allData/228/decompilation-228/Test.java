public class Test {
   public static final int N = 400;
   public static long instanceCount = -2079407246L;
   public static float fFld = 26.1022F;
   public static volatile boolean bFld = true;
   public static byte byFld = -56;
   public static short sFld = 14238;
   public static boolean bFld1 = false;
   public static int[] iArrFld = new int[400];
   public volatile long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 1;
      int[] var5 = new int[400];
      short var6 = 30715;
      double var7 = -100.50226;
      boolean var9 = false;
      byte[] var10 = new byte[400];
      long[][][] var11 = new long[400][400][400];
      FuzzerUtils.init((int[])var5, (int)8);
      FuzzerUtils.init((byte[])var10, (byte)93);
      FuzzerUtils.init((Object[][])var11, -4L);
      instanceCount -= (long)var1;
      int var16 = 1;

      label40:
      while(true) {
         ++var16;
         if (var16 >= 185) {
            vMeth2_check_sum += (long)(var0 + var1 + var2 + var16 + var4 + var6) + Double.doubleToLongBits(var7) + (long)(var9 ? 1 : 0) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum((Object[][])var11);
            return;
         }

         double var12 = 14.34097;
         var12 = (double)var2;
         var4 = 1;

         while(true) {
            ++var4;
            if (var4 >= 9) {
               var0 -= (int)instanceCount;
               var1 -= var6;
               var10[var16 - 1] -= (byte)((int)var7);
               var1 += var16;
               switch (var16 % 6 + 51) {
                  case 51:
                     instanceCount = (long)var0;
                     var11[var16 - 1][var16][var16] = (long)var0;
                     continue label40;
                  case 52:
                     int var10000 = var2 + var16;
                     var2 = var16 << var1;
                  case 53:
                     fFld -= (float)var0;
                     continue label40;
                  case 54:
                     instanceCount += (long)(-4 + var16 * var16);
                  case 55:
                     try {
                        var2 = 1746384800 / var5[var16 - 1];
                        var0 = var1 / var0;
                        var5[var16] = var1 / var4;
                     } catch (ArithmeticException var15) {
                     }
                     continue label40;
                  case 56:
                     if (var9) {
                     }
                     continue label40;
                  default:
                     instanceCount -= (long)var0;
                     continue label40;
               }
            }

            var5 = FuzzerUtils.int1array(400, 4550);
         }
      }
   }

   public static void vMeth1(int var0, int var1) {
      boolean var2 = true;
      byte var3 = -12;
      int var4 = 11;
      byte var5 = 4;
      int var6 = -14829;
      short var7 = -26780;
      double var8 = 14.112286;
      vMeth2(29139, var0, var0);
      var0 >>= 12;

      int var10;
      for(var10 = 3; var10 < 156; ++var10) {
         var1 |= var0;
         instanceCount += (long)var10;

         for(var4 = 1; 10 > var4; ++var4) {
            instanceCount += (long)var8;
         }

         switch (66) {
            case 67:
               bFld = bFld;

               int[] var10000;
               for(var6 = 10; var6 > 1; var1 = var6--) {
                  var10000 = iArrFld;
                  var10000[var6 + 1] += var3;
                  instanceCount -= (long)var0;
               }

               var1 <<= var3;
               var10000 = iArrFld;
               var10000[var10 - 1] += var10;
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var10 + var3 + var4 + var5) + Double.doubleToLongBits(var8) + (long)var6 + (long)var7;
   }

   public static void vMeth() {
      int var0 = -231;
      boolean var1 = true;
      int var2 = -37748;
      int var3 = 10;
      double var4 = 2.877;
      double var6 = -126.701;
      short var8 = 6411;
      float var9 = -1.789F;
      long[] var10 = new long[400];
      FuzzerUtils.init(var10, -3703891573993596982L);
      vMeth1(var0, var0);
      var0 |= var0;
      var4 *= (double)fFld;
      int var11 = 1;

      while(true) {
         ++var11;
         if (var11 >= 273) {
            vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var4) + (long)var11 + Double.doubleToLongBits(var6) + (long)var2 + (long)var8 + (long)Float.floatToIntBits(var9) + (long)var3 + FuzzerUtils.checkSum(var10);
            return;
         }

         int[] var10000;
         for(var6 = (double)var11; var6 < 6.0; ++var6) {
            var0 <<= var8;
            var0 *= (int)var9;
            var2 += (int)(var6 * (double)var0);
            var10000 = iArrFld;
            var10000[var11 + 1] *= (int)instanceCount;
            byFld *= byFld;
            instanceCount >>= var0;
            var0 = (int)instanceCount;
         }

         var3 = 1;

         do {
            var10[var3] >>>= -34834;
            ++var3;
         } while(var3 < 6);

         var10000 = iArrFld;
         var10000[var11 + 1] >>>= var3;
      }
   }

   public void mainTest(String[] var1) {
      int var2 = -63357;
      boolean var3 = true;
      int var4 = -8;
      int var5 = -61;
      int var6 = 0;
      int var7 = -534;
      int var8 = -4;
      int var9 = -11;
      int var10 = 24708;
      byte var11 = 14;
      float[] var12 = new float[400];
      boolean[][][] var13 = new boolean[400][400][400];
      FuzzerUtils.init(var12, -2.458F);
      FuzzerUtils.init((Object[][])var13, true);
      vMeth();
      var2 += var2;

      int var16;
      for(var16 = 13; var16 < 263; ++var16) {
         instanceCount = (long)fFld;
         instanceCount -= (long)var2;
         var5 = 101;

         while(true) {
            var5 -= 3;
            if (var5 <= 0) {
               break;
            }

            for(var6 = 1; var6 < 3; ++var6) {
               var7 >>>= var4;
            }

            int[] var10000 = iArrFld;
            var10000[var16 - 1] -= 12;
            instanceCount = instanceCount;

            for(var8 = 1; 3 > var8; ++var8) {
               bFld = false;
               instanceCount *= (long)var8;
               var7 += var4;
               iArrFld[var8 - 1] = var6;
               switch (var5 % 2 + 87) {
                  case 87:
                     iArrFld = iArrFld;
                     var9 = var6;
                     var13[var5 - 1][var8 + 1][var8 + 1] = bFld;
                     var10000 = iArrFld;
                     var10000[var16] -= sFld;
                     break;
                  case 88:
                     var2 += var8;

                     try {
                        var7 = 7808 / var2;
                        var2 %= 89;
                        var9 = var8 / var2;
                     } catch (ArithmeticException var15) {
                     }

                     var4 &= 14;
               }

               this.lArrFld[var16] = (long)var5;
            }

            for(var10 = 1; 3 > var10; ++var10) {
               bFld1 = bFld;
               fFld += -7899.0F;
               var9 %= var9 | 1;
               instanceCount = (long)((float)instanceCount + ((float)(var10 * var11 + var10) - fFld));
               var9 -= var2;
            }
         }
      }

      FuzzerUtils.out.println("i17 i18 i19 = " + var2 + "," + var16 + "," + var4);
      FuzzerUtils.out.println("i20 i21 i22 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i23 i24 i25 = " + var8 + "," + var9 + "," + var10);
      FuzzerUtils.out.println("i26 fArr bArr = " + var11 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)) + "," + FuzzerUtils.checkSum((Object[][])var13));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.bFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.byFld Test.sFld Test.bFld1 = " + byFld + "," + sFld + "," + (bFld1 ? 1 : 0));
      FuzzerUtils.out.println("Test.iArrFld lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)2);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
