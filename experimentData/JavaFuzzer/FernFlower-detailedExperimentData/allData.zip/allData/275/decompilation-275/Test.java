public class Test {
   public static final int N = 400;
   public static long instanceCount = -2034554388294346798L;
   public static volatile int iFld = 54234;
   public static double dFld = -1.29473;
   public static boolean bFld = false;
   public static int[] iArrFld = new int[400];
   public static short[] sArrFld = new short[400];
   public static long[] lArrFld = new long[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long vMeth2_check_sum;

   public static void vMeth2(int var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = 14944;
      int var5 = -6838;
      char var6 = '塚';
      int var7 = -10;
      int var8 = -60950;
      byte var9 = -4;
      double var10 = 14.66578;
      byte var12 = 34;
      float var13 = 2.271F;

      int var14;
      for(var14 = 236; var14 > 4; --var14) {
         for(var5 = 1; var5 < 7; ++var5) {
            if (iFld != 0) {
               vMeth2_check_sum += (long)(var0 + var1 + var2 + var14 + var4 + var5 + var6) + Double.doubleToLongBits(var10) + (long)var12 + (long)var7 + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var13);
               return;
            }

            instanceCount -= (long)var6;
            instanceCount *= instanceCount;
         }

         instanceCount = (long)var10;
         var12 = (byte)((int)var10);
      }

      sArrFld[26] = (short)var0;
      var4 = var4;
      var7 = 1;

      while(true) {
         ++var7;
         if (var7 >= 380) {
            vMeth2_check_sum += (long)(var0 + var1 + var2 + var14 + var4 + var5 + var6) + Double.doubleToLongBits(var10) + (long)var12 + (long)var7 + (long)var8 + (long)var9 + (long)Float.floatToIntBits(var13);
            return;
         }

         var4 = var5;

         for(var8 = 1; 4 > var8; ++var8) {
            instanceCount = (long)var10;
            int[] var10000 = iArrFld;
            var10000[var7] *= var7;
            var13 *= 2.819F;
         }
      }
   }

   public static void vMeth1(int var0) {
      int var1 = 62902;
      byte var2 = -60;
      int var3 = -218;
      int var4 = -217;
      int var5 = 2938;
      int var6 = 36;
      int[] var7 = new int[400];
      float var8 = 109.65F;
      float[] var9 = new float[400];
      boolean var10 = false;
      double[] var11 = new double[400];
      FuzzerUtils.init(var11, 2.125508);
      FuzzerUtils.init(var9, -1.429F);
      FuzzerUtils.init(var7, -44480);

      for(var1 = 8; var1 < 277; ++var1) {
         int[] var10000 = iArrFld;
         var10000[var1] *= (int)Long.reverseBytes(++instanceCount);
         vMeth2(var0, var0, var0);
         iFld += var1;
         var10000 = iArrFld;
         var10000[var1 - 1] += var2;
         instanceCount *= (long)var1;
         var0 += var2;

         label56:
         for(var3 = 1; 6 > var3; ++var3) {
            var0 = var3;
            switch (var3 % 10 * 5 + 93) {
               case 102:
                  if (var10) {
                     break;
                  }
               case 103:
                  long[] var14 = lArrFld;
                  var14[var1] *= (long)var6;
               case 104:
               case 106:
               case 107:
               case 108:
               case 110:
               case 111:
               case 113:
               case 114:
               case 115:
               case 116:
               case 117:
               case 118:
               case 119:
               case 121:
               case 124:
               case 125:
               case 126:
               case 127:
               case 128:
               case 129:
               case 130:
               case 131:
               case 132:
               case 133:
               case 134:
               case 136:
               case 137:
               case 138:
               case 139:
               case 140:
               default:
                  break;
               case 105:
                  var9[var3 + 1] += (float)var5;
                  break;
               case 109:
                  try {
                     iFld = 12524 % var1;
                     var4 = iFld % var0;
                     iArrFld[var1] = -114 % iArrFld[var1 - 1];
                  } catch (ArithmeticException var13) {
                  }
               case 123:
                  iArrFld = var7;
                  break;
               case 112:
               case 141:
                  var11[var3 + 1] /= (double)(instanceCount | 1L);
                  break;
               case 120:
                  if (var2 != 0) {
                     vMeth1_check_sum += (long)(var3 + var1 + var2 + var3 + var4 + var5 + var6 + Float.floatToIntBits(var8) + (var10 ? 1 : 0)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)) + FuzzerUtils.checkSum(var7);
                     return;
                  }
                  break;
               case 122:
                  var5 = var3;

                  while(true) {
                     if (var5 >= 2) {
                        continue label56;
                     }

                     lArrFld[352] = instanceCount;
                     var6 = var3;
                     instanceCount += (long)var5 ^ instanceCount;
                     ++var5;
                  }
               case 135:
                  var6 = (int)((long)var6 + ((long)var3 ^ (long)var8));
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + Float.floatToIntBits(var8) + (var10 ? 1 : 0)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)) + FuzzerUtils.checkSum(var7);
   }

   public static void vMeth(float var0, int var1, int var2) {
      boolean var3 = true;
      int var4 = -206;
      int var5 = 141;
      int var6 = -3;
      boolean var7 = false;
      byte var8 = -13;
      vMeth1(var2);
      var2 = (int)dFld;

      int var10;
      for(var10 = 2; 166 > var10; ++var10) {
         short var9 = -14529;
         var0 = -57754.0F;
         instanceCount += 37L;
         var9 += (short)((int)((long)var10 * instanceCount + (long)var10 - (long)var2));

         for(var5 = 10; var5 > var10; var5 -= 2) {
            var4 += var5 | var10;
            var2 = var4;
            if (var7) {
               break;
            }

            var8 = 115;
            var1 -= (int)instanceCount;
            var4 = (int)instanceCount;
            var6 -= 1113893104;
            iFld = (int)((float)iFld + ((float)var5 - var0));
         }
      }

      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1 + var2 + var10 + var4 + var5 + var6 + (var7 ? 1 : 0) + var8);
   }

   public void mainTest(String[] var1) {
      double var2 = -69.29982;
      boolean var4 = false;
      int var5 = -137;
      int var6 = -10;
      int var7 = -6323;
      int var8 = 38814;
      int var9 = -36987;
      int var10 = -67;
      int var11 = 22345;
      byte var12 = -13;
      int var13 = 8;
      int[][] var14 = new int[400][400];
      float var15 = -4.442F;
      long var16 = -36101L;
      FuzzerUtils.init((int[][])var14, (int)3);
      var2 -= (double)iFld;

      int var18;
      for(var18 = 12; var18 < 196; ++var18) {
         var5 = var5--;
         vMeth(var15, iFld, var18);
         iArrFld = FuzzerUtils.int1array(400, 6);
         instanceCount = (long)var18;

         for(var6 = 7; var6 < 136; ++var6) {
            iFld = iFld;
         }

         for(var16 = 1L; var16 < 136L; ++var16) {
            var8 += (int)var15;
            bFld = bFld;
            iFld += var6;
            instanceCount <<= var18;
            if (bFld) {
               break;
            }

            var14 = var14;
            iFld -= (int)var2;
            var5 = iFld;
         }
      }

      for(var9 = 348; var9 > 6; var9 -= 2) {
         var5 *= (int)instanceCount;
         iArrFld[var9 + 1] = (int)instanceCount;
         if (!bFld) {
            var5 += var9 - var8;
         } else {
            for(var11 = 1; var11 < 147; ++var11) {
               iFld = var6;
               var10 -= (int)instanceCount;
               var13 = 2;

               do {
                  lArrFld = lArrFld;
                  --instanceCount;
                  instanceCount += (long)var9;
                  var7 += var13;
                  --var13;
               } while(var13 > 0);

               iFld = (int)var16;
            }
         }
      }

      FuzzerUtils.out.println("d i i1 = " + Double.doubleToLongBits(var2) + "," + var18 + "," + var5);
      FuzzerUtils.out.println("f3 i26 i27 = " + Float.floatToIntBits(var15) + "," + var6 + "," + var7);
      FuzzerUtils.out.println("l i28 i29 = " + var16 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i30 i31 i32 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("i33 iArr1 = " + var13 + "," + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.bFld Test.iArrFld Test.sArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
      FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-52);
      FuzzerUtils.init((short[])sArrFld, (short)22622);
      FuzzerUtils.init(lArrFld, -1L);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      vMeth2_check_sum = 0L;
   }
}
