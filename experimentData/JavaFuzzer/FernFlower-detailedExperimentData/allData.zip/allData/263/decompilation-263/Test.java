public class Test {
   public static final int N = 400;
   public static long instanceCount = 10L;
   public static short sFld = 27623;
   public static int iFld = -6;
   public static float fFld = 0.206F;
   public static boolean bFld = false;
   public volatile double dFld = -88.12107;
   public static long sMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(byte var0) {
      float var1 = 0.63F;
      int var2 = -208;
      boolean var3 = true;
      double var4 = -1.83869;
      short var6 = 29561;
      var1 = (float)instanceCount;
      instanceCount >>= var2;
      var2 *= var2;
      var2 *= var2;
      var2 += (int)instanceCount;
      int var9 = 1;

      do {
         instanceCount &= (long)var2;

         try {
            var2 %= 123;
            var2 %= var2;
            var2 = var9 / var2;
         } catch (ArithmeticException var8) {
         }

         var2 = (int)((long)var2 + (long)var9 * instanceCount);
         var1 /= (float)((long)var4 | 1L);
         var2 += var9;
         var1 -= (float)var9;
         var2 *= (int)instanceCount;
         ++var9;
      } while(var9 < 312);

      var4 *= (double)var2;
      var2 *= var6;
      vMeth1_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var2 + var9) + Double.doubleToLongBits(var4) + (long)var6;
   }

   public static void vMeth(int var0) {
      byte var1 = 84;
      int var2 = 64823;
      int var3 = -3;
      int var4 = 22;
      short var5 = 2549;
      int var6 = -12498;
      int var7 = -240;
      int[] var8 = new int[400];
      float var9 = 0.33F;
      FuzzerUtils.init((int[])var8, (int)30);
      vMeth1(var1);
      var0 -= 1122984600;
      var0 >>= var0;
      var0 = var0;

      for(var2 = 6; var2 < 238; ++var2) {
         for(var4 = 1; var4 < 7; ++var4) {
            for(var6 = 1; var6 < 2; ++var6) {
               var8[var2 - 1] = (int)instanceCount;
               switch (var6 % 7 + 52) {
                  case 52:
                     var0 = var4;
                     var3 += 44629;
                     var3 -= 218;
                     instanceCount -= (long)sFld;
                  case 53:
                     var1 >>= (byte)var6;
                  case 54:
                     var7 -= 17;
                     break;
                  case 55:
                     instanceCount -= (long)var4;
                  case 56:
                     var7 -= 40;
                     break;
                  case 57:
                     var8[var4 - 1] -= var0;
                     break;
                  case 58:
                     var7 -= iFld;
                     break;
                  default:
                     var0 = (int)var9;
               }
            }
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + Float.floatToIntBits(var9)) + FuzzerUtils.checkSum(var8);
   }

   public static short sMeth(int var0, float var1) {
      boolean var2 = true;
      int var3 = -99;
      short var4 = 26352;
      int var5 = 75;
      int var6 = 12;
      int var7 = 38331;
      int[] var8 = new int[400];
      byte[] var9 = new byte[400];
      long[] var10 = new long[400];
      FuzzerUtils.init((byte[])var9, (byte)81);
      FuzzerUtils.init(var10, -24573L);
      FuzzerUtils.init((int[])var8, (int)45118);
      int var13 = 1;

      while(true) {
         ++var13;
         if (var13 >= 363) {
            long var11 = (long)(var0 + Float.floatToIntBits(var1) + var13 + var3 + var4 + var5 + var6 + var7) + FuzzerUtils.checkSum(var9) + FuzzerUtils.checkSum(var10) + FuzzerUtils.checkSum(var8);
            sMeth_check_sum += var11;
            return (short)((int)var11);
         }

         vMeth(58519);

         for(var3 = var13; var3 < 5; var3 += 2) {
            var9[var13 - 1] *= (byte)((int)instanceCount);
            iFld += var3;
            var1 += -7.0F;
         }

         var5 = 5;

         while(true) {
            var10[(var5 >>> 1) % 400] *= (long)var3;
            var0 = var4;
            fFld = (float)instanceCount;

            for(var6 = var13; var6 < 1; ++var6) {
               var8[var13] += var0;
            }

            instanceCount += (long)(var5 * var5 + sFld - var13);
            bFld = false;
            var7 <<= -34271;
            --var5;
            if (var5 <= 0) {
               break;
            }
         }
      }
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 53245;
      int var4 = -47405;
      int var5 = -17813;
      int var6 = -23;
      int var7 = 19137;
      int[] var8 = new int[400];
      double var9 = 2.6389;
      short var11 = 9315;
      long var12 = 2064041513L;
      long[] var14 = new long[400];
      byte var15 = 118;
      byte[] var16 = new byte[400];
      FuzzerUtils.init((int[])var8, (int)-6);
      FuzzerUtils.init(var14, -205393022L);
      FuzzerUtils.init((byte[])var16, (byte)24);
      sMeth(iFld, fFld);
      int var19 = 1;

      do {
         switch (var19 % 7 * 5 + 70) {
            case 71:
               bFld = bFld;
               break;
            case 76:
               var8[var19 + 1] *= (int)instanceCount;
            case 75:
               for(var9 = 187.0; var9 > (double)var19; --var9) {
                  var3 = -363545526;
               }

               label85:
               for(var4 = 187; var4 > 1; var4 -= 3) {
                  switch ((var19 >>> 1) % 9 + 57) {
                     case 57:
                        var5 |= var19;
                        var5 -= var3;
                        break;
                     case 58:
                        var3 = (int)((long)var3 + ((long)(var4 * iFld + var19) - instanceCount));
                        fFld *= 23787.0F;
                        var3 = var19;
                        break;
                     case 59:
                        switch ((var19 >>> 1) % 5 + 68) {
                           case 68:
                              var3 += var4 * var11 + var19 - var4;
                              var12 = 1L;

                              while(true) {
                                 if (var12 >= 4L) {
                                    continue label85;
                                 }

                                 var14[(int)var12] += (long)var19;
                                 ++var12;
                              }
                           case 69:
                              var3 += 134;

                              try {
                                 var6 = var3 / -39367;
                                 var5 = var8[var4 - 1] % 208;
                                 var8[var4] = '\uf24b' % var5;
                              } catch (ArithmeticException var18) {
                              }
                              continue;
                           case 70:
                              var7 = 1;

                              while(true) {
                                 ++var7;
                                 if (var7 >= 4 || bFld) {
                                    break;
                                 }

                                 instanceCount = (long)((float)instanceCount + (float)var7 * fFld);
                                 if (!bFld) {
                                    var3 += var7 * sFld + var3 - var3;
                                    instanceCount += 4972554890482288877L;
                                    var8[var7 - 1] = var6;
                                    var6 += var7 * var15 + iFld - var7;
                                    var16[var7 + 1] = (byte)var5;
                                    var8[var19 + 1] = iFld;
                                    this.dFld += (double)instanceCount;
                                 }
                              }
                           case 71:
                              instanceCount *= (long)var3;
                              continue;
                           case 72:
                              var6 += var4 - iFld;
                              continue;
                        }
                     case 60:
                        instanceCount &= instanceCount;
                        break;
                     case 61:
                        var14[var19 - 1] <<= var6;
                        break;
                     case 62:
                        bFld = bFld;
                     case 63:
                        var8[var4 - 1] += iFld;
                        break;
                     case 64:
                        var3 -= (int)var9;
                        break;
                     case 65:
                        var8[var4] *= (int)fFld;
                        break;
                     default:
                        instanceCount += (long)var6;
                  }
               }
               break;
            case 94:
               instanceCount *= -49563L;
            case 96:
               var3 += var19;
               break;
            case 99:
               this.dFld = (double)fFld;
               break;
            case 103:
               this.dFld = (double)var12;
         }

         ++var19;
      } while(var19 < 134);

      FuzzerUtils.out.println("i16 d1 i17 = " + var19 + "," + Double.doubleToLongBits(var9) + "," + var3);
      FuzzerUtils.out.println("i18 i19 s1 = " + var4 + "," + var5 + "," + var11);
      FuzzerUtils.out.println("l i20 i21 = " + var12 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("by2 iArr2 lArr1 = " + var15 + "," + FuzzerUtils.checkSum(var8) + "," + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("byArr1 = " + FuzzerUtils.checkSum(var16));
      FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.iFld = " + instanceCount + "," + sFld + "," + iFld);
      FuzzerUtils.out.println("Test.fFld Test.bFld dFld = " + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
