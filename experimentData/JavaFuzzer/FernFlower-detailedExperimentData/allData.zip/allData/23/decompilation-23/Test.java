public class Test {
   public static final int N = 400;
   public static long instanceCount = 3125503453L;
   public static float fFld = 1.855F;
   public int iFld = -250;
   public boolean bFld = false;
   public static byte byFld = -50;
   public static long[] lArrFld = new long[400];
   public static int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1(long var0) {
      boolean var2 = true;
      int var3 = -141;
      int var4 = 8;
      int var5 = -13635;
      int var6 = 14184;
      int[] var7 = new int[400];
      float var8 = -127.506F;
      FuzzerUtils.init((int[])var7, (int)14);

      int var12;
      for(var12 = 13; var12 < 298; ++var12) {
         var3 = (int)var0;
         instanceCount = (long)var3;

         for(var4 = 6; 1 < var4; var4 -= 3) {
            char var13 = '쑷';
            var5 = var13;
         }

         instanceCount += (long)(var12 * var4 + var12) - var0;
         lArrFld = lArrFld;

         try {
            var3 = 209 % var4;
            var7[var12 + 1] = var4 % -151972265;
            var3 = 194 / var12;
         } catch (ArithmeticException var11) {
         }

         var5 += var12;
         var6 = 1;

         do {
            switch ((var3 >>> 1) % 3 + 24) {
               case 24:
                  var3 = var5 + (var6 | var6);
                  var5 = var5;
                  break;
               case 25:
                  var5 += var6;
                  break;
               case 26:
                  var8 *= -12.0F;
            }

            ++var6;
         } while(var6 < 6);
      }

      long var9 = var0 + (long)var12 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)Float.floatToIntBits(var8) + FuzzerUtils.checkSum(var7);
      iMeth1_check_sum += var9;
      return (int)var9;
   }

   public static int iMeth() {
      int var0 = -7;
      boolean var1 = false;
      boolean var2 = true;
      int var3 = 14;
      int var4 = 76;
      int var5 = -51569;
      double var6 = -4.90408;
      byte var8 = -5;
      boolean var9 = false;
      boolean[] var10 = new boolean[400];
      FuzzerUtils.init(var10, true);
      var0 = (int)(((float)((long)var0 + 2739312917L) + fFld * fFld) * (float)iMeth1(instanceCount));

      int var13;
      for(var13 = 17; var13 < 320; ++var13) {
         for(var6 = 5.0; var6 > 1.0; --var6) {
            fFld = (float)var13;
            var3 &= 1442167162;
            instanceCount = 4L;
            fFld += (float)(var6 - (double)var8);
            var0 = var13;
            instanceCount = 115L;
         }

         for(var4 = 1; var4 < 5; ++var4) {
            var10[var13 + 1] = var9;
         }
      }

      var8 = 119;
      int var14 = -397004895;
      long var11 = (long)(var0 + var13 + var14) + Double.doubleToLongBits(var6) + (long)var5 + (long)var8 + (long)var4 + (long)var5 + (long)(var9 ? 1 : 0) + FuzzerUtils.checkSum(var10);
      iMeth_check_sum += var11;
      return (int)var11;
   }

   public static void vMeth() {
      boolean var0 = true;
      int var1 = 173;
      int var2 = 1;
      int var3 = 58;
      int var4 = 5;
      int var5 = -14;
      boolean var6 = false;
      byte var7 = -29;

      int var8;
      for(var8 = 149; var8 > 7; var8 -= 2) {
         var1 <<= iMeth() + var2;
         int[] var10000 = iArrFld;
         var10000[var8] += (int)instanceCount;
         var2 -= var1;
         var1 = (int)((float)var1 + ((float)var8 * fFld + (float)var1 - (float)instanceCount));
         iArrFld[var8 - 1] = var8;

         for(var3 = 1; 22 > var3; ++var3) {
            var1 -= var1;
            var5 = 1;

            while(true) {
               ++var5;
               if (var5 >= 2) {
                  break;
               }

               long[] var9 = lArrFld;
               var9[var8 - 1] -= (long)var8;
               instanceCount += (long)var2;
               if (var3 != 0) {
                  vMeth_check_sum += (long)(var8 + var1 + var2 + var3 + var4 + var5 + (var6 ? 1 : 0) + var7);
                  return;
               }

               var6 = var6;
               var7 = (byte)var5;
               var4 >>= -1597847310;
            }
         }
      }

      vMeth_check_sum += (long)(var8 + var1 + var2 + var3 + var4 + var5 + (var6 ? 1 : 0) + var7);
   }

   public void mainTest(String[] var1) {
      short var2 = 30977;
      boolean var3 = true;
      int var4 = -44215;
      int var5 = 0;
      int var6 = -111;
      byte var7 = -11;
      int var8 = 47;
      char var9 = '\uf05a';
      double var10 = 116.12225;
      float[] var12 = new float[400];
      FuzzerUtils.init(var12, -1.154F);
      vMeth();
      iArrFld[(this.iFld >>> 1) % 400] = var2;
      this.iFld *= var2;
      int var10001 = (this.iFld >>> 1) % 400;
      var12[var10001] *= (float)instanceCount;

      int[] var10000;
      int var17;
      for(var17 = 379; var17 > 2; var17 -= 3) {
         var4 = (int)((long)var4 + ((long)var17 * instanceCount + instanceCount - (long)var4));
         switch ((var4 >>> 1) % 1 * 5 + 25) {
            case 29:
               var4 = -87;
               this.iFld += var17 | var17;
               break;
            default:
               var10000 = iArrFld;
               var10000[var17 + 1] += (int)fFld;
               this.iFld -= (int)instanceCount;
         }

         this.iFld = (int)((long)this.iFld + ((long)var17 * instanceCount + instanceCount - (long)var4));
         var2 = (short)var17;
         instanceCount = (long)fFld;
         fFld -= (float)this.iFld;
      }

      int[] var13 = iArrFld;
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         int var18 = var13[var15];
         var5 = 1;

         while(true) {
            ++var5;
            if (var5 >= 63) {
               for(var8 = 63; var8 > 2; --var8) {
                  var10 = -1013.0;
                  var4 -= this.iFld;
               }
               break;
            }

            if (this.bFld) {
               for(var6 = 1; var6 < 1; ++var6) {
                  iArrFld = iArrFld;
               }

               var10000 = iArrFld;
               var10000[var5 + 1] *= var17;
            }

            this.bFld = this.bFld;
            this.iFld += 28758 + var5 * var5;
            instanceCount += (long)var5;
            byFld += (byte)var4;
            this.iFld += var5;
            instanceCount = (long)var17;
         }
      }

      FuzzerUtils.out.println("s i17 i18 = " + var2 + "," + var17 + "," + var4);
      FuzzerUtils.out.println("i20 i21 i22 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i23 i24 d1 = " + var8 + "," + var9 + "," + Double.doubleToLongBits(var10));
      FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + this.iFld);
      FuzzerUtils.out.println("bFld Test.byFld Test.lArrFld = " + (this.bFld ? 1 : 0) + "," + byFld + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, 3104454649035639001L);
      FuzzerUtils.init((int[])iArrFld, (int)-180);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
