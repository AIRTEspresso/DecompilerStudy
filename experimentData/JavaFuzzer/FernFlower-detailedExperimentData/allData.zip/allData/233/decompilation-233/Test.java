public class Test {
   public static final int N = 400;
   public static long instanceCount = -10L;
   public short sFld = -3104;
   public static double dFld = -1.93154;
   public static short sFld1 = -7536;
   public static boolean bFld = false;
   public float fFld = 2.334F;
   public byte[] byArrFld = new byte[400];
   public static long[] lArrFld = new long[400];
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long lMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, boolean var1) {
      boolean var2 = true;
      int var3 = -5;
      int var4 = 55176;
      int var5 = -65024;
      int var6 = -48;
      short var7 = -16599;
      int[] var8 = new int[400];
      byte var9 = 106;
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, 0.753F);
      FuzzerUtils.init((int[])var8, (int)-83);

      int var11;
      for(var11 = 3; 331 > var11; ++var11) {
         for(var4 = 1; var4 < 5; ++var4) {
            var5 -= var11;
            switch (var4 % 1 + 126) {
               case 126:
                  long[] var10000 = lArrFld;
                  var10000[var11 - 1] >>= -139;
                  var9 <<= (byte)var11;
                  break;
               default:
                  var0 -= 142;
                  var9 = (byte)var11;
                  if (!var1) {
                     var3 = (int)instanceCount;
                  }
            }
         }

         for(var6 = 1; var6 < 5; ++var6) {
            var10[var6 - 1] += (float)var11;
            var8[var6 - 1] -= 44041;
            if (!var1) {
               var0 += (int)instanceCount;
            }
         }
      }

      vMeth_check_sum += (long)(var0 + (var1 ? 1 : 0) + var11 + var3 + var4 + var5 + var9 + var6 + var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + FuzzerUtils.checkSum(var8);
   }

   public static long lMeth(byte var0) {
      short var1 = 9;
      short var2 = 1981;
      int var3 = 7259;
      int var4 = 28851;
      int var5 = 222;
      boolean var6 = false;
      boolean[] var7 = new boolean[400];
      long var8 = -5234185637074291691L;
      float var10 = 38.225F;
      FuzzerUtils.init(var7, true);
      vMeth(var1, var6);

      for(var8 = 10L; 302L > var8; ++var8) {
         var3 = 6;

         while(true) {
            --var3;
            if (var3 <= 0) {
               break;
            }

            var2 = var1;

            for(var4 = 1; var4 < 1; ++var4) {
               dFld = (double)var8;
               instanceCount = (long)((float)instanceCount + ((float)var4 * var10 + (float)instanceCount - (float)var5));
               var7[var4 + 1] = true;
               var10 += var10;
               instanceCount = (long)var4;
               var5 += var4;
               var5 |= var2;
               var5 -= sFld1;
            }

            var2 = var2;
            var1 = var2;
         }
      }

      long var11 = (long)(var0 + var1 + (var6 ? 1 : 0)) + var8 + (long)var2 + (long)var3 + (long)var4 + (long)var5 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var7);
      lMeth_check_sum += var11;
      return var11;
   }

   public static int iMeth() {
      int var0 = -1;
      boolean var1 = true;
      boolean var2 = true;
      int var3 = 6725;
      short var4 = -21856;
      float var5 = -56.748F;
      double var6 = -1.9204;
      byte var8 = 93;
      var0 += var0 + var0 + (var0 - var0);
      var0 = (int)((float)(var0++) - ((float)lMeth((byte)-95) + var5));
      iArrFld[(var0 >>> 1) % 400] = var0;
      int var11 = 1;

      int var12;
      do {
         for(var12 = 1; var12 < 11; ++var12) {
            int[] var13;
            if (bFld) {
               var3 *= var12;
               var13 = iArrFld;
               var13[var12 + 1] /= 57;
            } else {
               var0 <<= var11;

               for(var6 = 1.0; 2.0 > var6; ++var6) {
                  if (bFld) {
                     var3 += var12;
                  } else if (bFld) {
                     var13 = iArrFld;
                     var13[(int)var6] += var8;
                     var3 += (int)instanceCount;
                  }
               }
            }
         }

         ++var11;
      } while(var11 < 146);

      long var9 = (long)(var0 + Float.floatToIntBits(var5) + var11 + var12 + var3) + Double.doubleToLongBits(var6) + (long)var4 + (long)var8;
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void mainTest(String[] var1) {
      int var2 = -85;
      boolean var3 = true;
      int var4 = 66;
      int var5 = 3;
      int var6 = -3;
      short var7 = -5;
      byte var8 = 16;
      byte[] var10002 = this.byArrFld;
      int var10003 = (var2 >>> 1) % 400;
      byte var10005 = var10002[(var2 >>> 1) % 400];
      var10002[var10003] = (byte)(var10002[(var2 >>> 1) % 400] - 1);
      var2 <<= (int)(-(131L ^ (long)var10005) << (this.sFld << var2) + iMeth());
      bFld = bFld;
      instanceCount = (long)var2;
      instanceCount -= -7596570181699054355L;

      int var9;
      for(var9 = 8; var9 < 195; ++var9) {
         lArrFld[var9] = 7L;
         instanceCount += (long)var9;
         iArrFld[var9 - 1] = var2;
         switch (var9 % 2 + 7) {
            case 7:
               if (bFld) {
                  if (bFld) {
                     var5 = 1;

                     while(true) {
                        ++var5;
                        if (var5 >= 134) {
                           break;
                        }

                        int[] var10000 = iArrFld;
                        var10000[var9] >>= -34151;
                        var2 -= (int)instanceCount;
                        var4 = (int)instanceCount;
                        var4 = this.sFld;
                        var6 = 1;

                        while(var6 < 1) {
                           var4 += var6 * var2 + var2 - var8;
                           var2 = (int)((long)var2 + (long)var6 * instanceCount);
                           switch (var6 % 1 * 5 + 63) {
                              case 68:
                                 long[] var10 = lArrFld;
                                 var10[var6 + 1] -= (long)var7;
                                 if (bFld) {
                                    var8 <<= -115;
                                    bFld = bFld;
                                    this.sFld = (short)var4;
                                    instanceCount += (long)var6;
                                 }
                              default:
                                 instanceCount += (long)var7;
                                 instanceCount = (long)var5;
                                 var2 = var9;
                                 var4 |= 9;
                                 ++var6;
                           }
                        }
                     }
                  } else if (bFld) {
                     var2 += -123 + var9 * var9;
                  } else if (bFld) {
                     sFld1 <<= (short)var7;
                  }
               } else if (bFld) {
                  this.fFld += -106.0F;
               } else {
                  var4 >>>= var6;
               }
            case 8:
               var7 = this.sFld;
         }
      }

      FuzzerUtils.out.println("i i18 i19 = " + var2 + "," + var9 + "," + var4);
      FuzzerUtils.out.println("i20 i21 i22 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("by3 = " + var8);
      FuzzerUtils.out.println("Test.instanceCount sFld Test.dFld = " + instanceCount + "," + this.sFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.sFld1 Test.bFld fFld = " + sFld1 + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(this.fFld));
      FuzzerUtils.out.println("byArrFld Test.lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(this.byArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(lArrFld, -32L);
      FuzzerUtils.init((int[])iArrFld, (int)24);
      iMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
