public class Test {
   public static final int N = 400;
   public static long instanceCount = -54790L;
   public static int iFld = -3069;
   public short sFld = 26871;
   public static byte byFld = 29;
   public static float fFld = 6.198F;
   public static short sFld1 = 30345;
   public static boolean bFld = true;
   public static double dFld = -43.102962;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static long lMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(float var0) {
      boolean var1 = true;
      short var2 = 2218;
      int var3 = 3;
      short var4 = -32055;

      int var5;
      for(var5 = 7; var5 < 135; ++var5) {
         iFld += var4;
         int[] var10000 = iArrFld;
         var10000[var5] -= var2;
         var3 <<= iFld;
      }

      iArrFld[(var2 >>> 1) % 400] = iFld;
      instanceCount -= instanceCount;
      var3 += 8738;
      vMeth1_check_sum += (long)(Float.floatToIntBits(var0) + var5 + var2 + var4 + var3);
   }

   public static void vMeth(int var0) {
      float var1 = 0.272F;
      boolean var2 = true;
      int var3 = -6;
      int var4 = -14;
      short var5 = 31108;
      int var6 = 8;
      short var7 = 146;
      vMeth1(var1);
      var0 ^= 3;
      var1 += (float)var0;

      int[] var10000;
      int var8;
      for(var8 = 211; var8 > 13; --var8) {
         var10000 = iArrFld;
         var10000[var8 - 1] |= var0;
         var3 = (int)instanceCount;
         if (var0 != 0) {
            vMeth_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var8 + var3 + var4 + var5 + var6 + var7);
            return;
         }

         for(var4 = var8; 8 > var4; ++var4) {
            var3 /= byFld | 1;
            iArrFld[var4 - 1] = var3;
            var1 = (float)var4;
            var3 >>= (int)instanceCount;
         }
      }

      for(var6 = 1; var6 < 238; ++var6) {
         iFld += var6 ^ var7;
         var10000 = iArrFld;
         var10000[var6 - 1] -= (int)var1;
      }

      vMeth_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var8 + var3 + var4 + var5 + var6 + var7);
   }

   public static long lMeth() {
      int var0 = 39033;
      int var1 = 237;
      int var2 = -249;
      int var3 = 4844;
      int var4 = 1;
      double var5 = 2.56475;
      long[][] var7 = new long[400][400];
      FuzzerUtils.init(var7, 169L);

      for(var0 = 10; var0 < 315; ++var0) {
         vMeth(var1);

         label49:
         for(var2 = 1; var2 < 5; ++var2) {
            instanceCount <<= iFld;
            instanceCount >>>= 133;
            switch (var2 % 10 + 85) {
               case 85:
                  var1 = 5;
               case 86:
                  iArrFld = FuzzerUtils.int1array(400, -5);
                  var4 = 1;

                  while(true) {
                     ++var4;
                     if (var4 >= 2) {
                        continue label49;
                     }

                     var7[var2][var0 - 1] -= (long)var5;
                     instanceCount -= (long)var4;
                     switch (var0 % 8 * 5 + 18) {
                        case 23:
                           iFld = iFld;
                           break;
                        case 33:
                           var1 += var2;
                        case 31:
                           iFld += var4 + sFld1;
                           break;
                        case 45:
                           iFld = (int)var5;
                           break;
                        case 46:
                           iFld -= (int)fFld;
                           var3 = var0;
                           fFld -= 20838.0F;
                           break;
                        case 49:
                           iFld *= (int)var5;
                        case 47:
                           int[] var10000 = iArrFld;
                           var10000[var0] /= iFld | 1;
                           break;
                        case 55:
                           var1 += var4 * var4;
                           break;
                        default:
                           fFld += (float)var4;
                     }
                  }
               case 87:
                  if (bFld) {
                  }
                  break;
               case 88:
                  var1 = (int)((float)var1 + ((float)(var2 * iFld) + fFld - fFld));
                  break;
               case 89:
                  instanceCount &= (long)var1;
                  break;
               case 90:
                  iFld *= var3;
               case 91:
                  var3 += var2 * var2 + byFld - var1;
                  break;
               case 92:
                  instanceCount -= instanceCount;
               case 93:
                  iArrFld[var2 - 1] = var2;
               case 94:
                  instanceCount = instanceCount;
                  break;
               default:
                  var7[var0 - 1][var0 + 1] >>= (int)instanceCount;
            }
         }
      }

      long var8 = (long)(var0 + var1 + var2 + var3 + var4) + Double.doubleToLongBits(var5) + FuzzerUtils.checkSum(var7);
      lMeth_check_sum += var8;
      return var8;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 14;
      int var4 = 242;
      int var5 = -9;
      int var6 = 60061;
      int var7 = 56;
      float var8 = 1.48F;
      float[] var9 = new float[400];
      double[] var10 = new double[400];
      boolean[] var11 = new boolean[400];
      FuzzerUtils.init(var10, -18.122034);
      FuzzerUtils.init(var11, true);
      FuzzerUtils.init(var9, -55.61F);

      int var14;
      for(var14 = 1; var14 < 269; ++var14) {
         if (!bFld) {
            if (bFld) {
               dFld -= (double)instanceCount;
               instanceCount <<= var5;
            } else if (bFld) {
               var9[var14] = (float)var6;
               byFld = 12;
               lArrFld[var14 + 1] = (long)var14;
            } else {
               var7 = 94;

               while(true) {
                  --var7;
                  if (var7 <= 0) {
                     break;
                  }

                  instanceCount -= (long)var14;
                  instanceCount += 76236999L + (long)(var7 * var7);
               }
            }
         } else {
            for(var8 = 4.0F; var8 < 94.0F; ++var8) {
               for(var5 = (int)var8; var5 < 2; ++var5) {
                  var10[var14] *= (double)(Math.abs(var3 - '\udf77') + iFld);
                  this.sFld %= (short)(--iArrFld[(int)var8] | 1);
                  if (bFld) {
                     lMeth();
                     var4 = var5;
                     switch ((var3 >>> 1) % 1 + 1) {
                        case 1:
                           var6 += var5 | var14;

                           try {
                              var6 = var5 % var14;
                              var3 = iFld % var5;
                              iFld = var4 % var3;
                           } catch (ArithmeticException var13) {
                           }

                           var11[(int)var8] = bFld;
                           instanceCount = 56L;
                     }
                  }

                  int var10000 = var4 + var14;
                  var3 = (int)instanceCount;
                  var3 = var14;
                  var4 = (int)instanceCount;
                  iArrFld[var14] = iFld;
                  var4 -= (int)instanceCount;
                  iFld = (int)instanceCount;
               }

               var3 *= var14;
            }
         }
      }

      FuzzerUtils.out.println("i i1 f = " + var14 + "," + var3 + "," + Float.floatToIntBits(var8));
      FuzzerUtils.out.println("i2 i3 i4 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i20 dArr bArr = " + var7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)) + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
      FuzzerUtils.out.println("Test.byFld Test.fFld Test.sFld1 = " + byFld + "," + Float.floatToIntBits(fFld) + "," + sFld1);
      FuzzerUtils.out.println("Test.bFld Test.dFld Test.iArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-236);
      FuzzerUtils.init(lArrFld, -54453L);
      lMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
