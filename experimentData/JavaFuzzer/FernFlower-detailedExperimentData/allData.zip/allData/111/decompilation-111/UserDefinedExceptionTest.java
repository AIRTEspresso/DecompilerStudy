class UserDefinedExceptionTest extends RuntimeException {
   public int field;
}
