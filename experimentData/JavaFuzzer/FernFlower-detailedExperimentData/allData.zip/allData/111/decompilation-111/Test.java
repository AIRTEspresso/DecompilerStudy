public class Test {
   public static final int N = 400;
   public static long instanceCount = -1318088676L;
   public static double dFld = 0.87392;
   public static boolean bFld = false;
   public static short sFld = -420;
   public static long vMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;
   public static long iMeth1_check_sum = 0L;

   public static int iMeth1(double var0) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = -2;
      double[] var5 = new double[400];
      long[] var6 = new long[400];
      FuzzerUtils.init(var5, -8.89364);
      FuzzerUtils.init(var6, -3489466803L);
      int var9 = 1;

      do {
         var5[var9 + 1] -= (double)instanceCount;
         ++var9;
      } while(var9 < 130);

      var5[(var9 >>> 1) % 400] -= (double)instanceCount;

      int var10;
      for(var10 = 14; 236 > var10; ++var10) {
         var4 -= (int)instanceCount;
         var4 = (int)((long)var4 + ((long)var10 * instanceCount + (long)var9 - (long)var9));
         var4 -= var4;
         var0 += 136.0;
         var4 += 8796 + var10 * var10;
         var6[var10 + 1] += -53770L;
      }

      long var7 = Double.doubleToLongBits(var0) + (long)var9 + (long)var10 + (long)var4 + Double.doubleToLongBits(FuzzerUtils.checkSum(var5)) + FuzzerUtils.checkSum(var6);
      iMeth1_check_sum += var7;
      return (int)var7;
   }

   public static int iMeth() {
      int var0 = 54889;
      int var1 = 10;
      int var2 = 245;
      int var3 = -65;
      int var4 = -64298;
      int[] var5 = new int[400];
      float var6 = 0.1013F;
      boolean[] var7 = new boolean[400];
      double[] var8 = new double[400];
      FuzzerUtils.init((int[])var5, (int)-101);
      FuzzerUtils.init(var7, true);
      FuzzerUtils.init(var8, 6.59892);

      label34:
      for(var0 = 4; var0 < 283; ++var0) {
         instanceCount += (long)var0;
         switch (((var1 = var1) >>> 1) % 7 + 20) {
            case 20:
            case 21:
               iMeth1(dFld);
               var5[var0 + 1] = -13;
               var1 = (int)instanceCount;
               instanceCount = (long)var1;
               break;
            case 22:
               var1 += var0 * var0;
               instanceCount += (long)(-9157 + var0 * var0);
               instanceCount <<= var1;
               break;
            case 23:
               var7[var0 - 1] = bFld;
               var1 = var1;
               var2 = 1;

               while(true) {
                  if (var2 >= 6) {
                     continue label34;
                  }

                  var5[var0 + 1] <<= var4;
                  var8[var0 + 1] = (double)var2;
                  ++var2;
               }
            case 24:
               try {
                  int var10000 = var1 % var0;
                  var3 = -29401 % var2;
                  var5[var0] = var5[var0 - 1] % -7197;
               } catch (ArithmeticException var11) {
               }
            case 25:
               if (bFld) {
               }
               break;
            case 26:
               instanceCount *= (long)var2;
               break;
            default:
               var6 = (float)var2;
         }
      }

      long var9 = (long)(var0 + var1 + var2 + var3 + var4 + Float.floatToIntBits(var6)) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var8));
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public static void vMeth(long var0) {
      boolean var2 = true;
      int var3 = 210;
      boolean var4 = true;
      int var5 = -7;
      int var6 = -195;
      int var7 = 32067;
      int var8 = -6;
      int var9 = -14;
      int var10 = -60534;
      int[][][] var11 = new int[400][400][400];
      byte var12 = 72;
      byte[][][] var13 = new byte[400][400][400];
      float var14 = -121.456F;
      double[] var15 = new double[400];
      FuzzerUtils.init((Object[][])var11, 10);
      FuzzerUtils.init((Object[][])var13, -100);
      FuzzerUtils.init(var15, 40.70373);

      int var16;
      for(var16 = 154; var16 > 4; --var16) {
         var11[var16 - 1][var16 + 1][var16 + 1] = (int)(var0 = (long)iMeth());
         sFld += (short)((int)instanceCount);
         var13[var16][var16 + 1][var16 - 1] >>= var12;
      }

      int var17;
      for(var17 = 1; var17 < 284; ++var17) {
         for(var6 = var17; 6 > var6; ++var6) {
            var7 |= (int)instanceCount;
         }

         var8 = 6;

         do {
            for(var9 = 1; 1 > var9; ++var9) {
               var10 >>= -64076;
               var0 += (long)(var9 * var9);
               var7 <<= 10;
               var5 += (int)var14;
               var15 = FuzzerUtils.double1array(400, 2.90576);
               var3 = 1293536941;
            }

            --var8;
         } while(var8 > 0);
      }

      vMeth_check_sum += var0 + (long)var16 + (long)var3 + (long)var12 + (long)var17 + (long)var5 + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)var10 + (long)Float.floatToIntBits(var14) + FuzzerUtils.checkSum((Object[][])var11) + FuzzerUtils.checkSum((Object[][])var13) + Double.doubleToLongBits(FuzzerUtils.checkSum(var15));
   }

   public void mainTest(String[] var1) {
      float var2 = -1.733F;
      float[] var3 = new float[400];
      int var4 = 4;
      int var5 = 9;
      short var6 = -163;
      int var7 = -55476;
      int var8 = 197;
      byte var9 = -128;
      int[][] var10 = new int[400][400];
      byte[] var11 = new byte[400];
      long[] var12 = new long[400];
      FuzzerUtils.init((int[][])var10, (int)-29);
      FuzzerUtils.init(var11, (byte)-8);
      FuzzerUtils.init(var3, 32.335F);
      FuzzerUtils.init(var12, -5L);
      vMeth(instanceCount);
      var2 *= (float)dFld;
      var10[(var4 >>> 1) % 400][(var4 >>> 1) % 400] >>= var4;
      sFld *= (short)var4;
      var4 <<= (int)instanceCount;

      try {
         var11[84] = -107;
      } catch (UserDefinedExceptionTest var14) {
         var5 = 1;

         do {
            instanceCount += (long)var4;
            instanceCount += (long)(var5 + var5);
            instanceCount >>= sFld;
            var10[var5 + 1][var5 + 1] >>>= var5;
            var10[var5 - 1][var5] >>= var4;
            var3[var5] *= (float)sFld;

            for(var8 = 204; var8 > var5; --var8) {
               var4 -= (int)instanceCount;
               var10[var8][var5] %= var9 | 1;
               var12[var5 - 1] = instanceCount;
               var7 |= -42;
               if (bFld) {
                  break;
               }
            }

            ++var5;
         } while(var5 < 123);
      }

      FuzzerUtils.out.println("f2 i17 i18 = " + Float.floatToIntBits(var2) + "," + var4 + "," + var5);
      FuzzerUtils.out.println("i19 i20 i21 = " + var6 + "," + var7 + "," + var8);
      FuzzerUtils.out.println("i22 iArr2 byArr1 = " + var9 + "," + FuzzerUtils.checkSum(var10) + "," + FuzzerUtils.checkSum(var11));
      FuzzerUtils.out.println("fArr lArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var3)) + "," + FuzzerUtils.checkSum(var12));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
      FuzzerUtils.out.println("Test.sFld = " + sFld);
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
