public class Test {
   public static final int N = 400;
   public static long instanceCount = -9L;
   public int iFld = 7;
   public static double dFld = -66.79636;
   public static byte byFld = 17;
   public static float fFld = -1.628F;
   public static double[][] dArrFld = new double[400][400];
   public static byte[] byArrFld = new byte[400];
   public int[] iArrFld = new int[400];
   public long[][][] lArrFld = new long[400][400][400];
   public static boolean[] bArrFld = new boolean[400];
   public static long iMeth_check_sum;
   public static long lMeth_check_sum;
   public static long vMeth_check_sum;

   public static void vMeth(int var0, float var1) {
      boolean var2 = true;
      byte var3 = 1;
      int[] var4 = new int[400];
      boolean var5 = false;
      byte[] var6 = new byte[400];
      FuzzerUtils.init((int[])var4, (int)-12);
      FuzzerUtils.init(var6, (byte)-51);
      var4[(var0 >>> 1) % 400] <<= -224;

      int var7;
      for(var7 = 15; var7 < 305; ++var7) {
         if (var0 != 0) {
            vMeth_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var7 + var3 + (var5 ? 1 : 0)) + FuzzerUtils.checkSum(var4) + FuzzerUtils.checkSum(var6);
            return;
         }
      }

      var1 -= (float)var3;
      var4[(var3 >>> 1) % 400] = var7;
      var6[7] += (byte)var7;
      vMeth_check_sum += (long)(var0 + Float.floatToIntBits(var1) + var7 + var3 + (var5 ? 1 : 0)) + FuzzerUtils.checkSum(var4) + FuzzerUtils.checkSum(var6);
   }

   public static long lMeth() {
      int var0 = 29128;
      int var1 = -36993;
      int var2 = -232;
      int var3 = -152;
      int var4 = -12;
      int[][] var5 = new int[400][400];
      float var6 = -42.418F;
      boolean var7 = true;
      FuzzerUtils.init((int[][])var5, (int)88);
      vMeth(var0, var6);

      label39:
      for(var1 = 160; var1 > 10; var1 -= 2) {
         switch ((var0 >>> 1) % 2 + 50) {
            case 50:
               var0 += var1 | var2;
               var5[var1] = var5[var1];
               break;
            case 51:
               var3 = 1;

               while(true) {
                  var3 += 2;
                  if (var3 >= 21) {
                     continue label39;
                  }

                  if (var2 != 0) {
                  }

                  instanceCount += (long)var6;
                  var4 = 1;

                  do {
                     var2 -= var3;
                     var2 = (int)((long)var2 + ((long)var4 * instanceCount + (long)var3 - instanceCount));
                     var0 = (int)instanceCount;
                     var0 |= -17009;
                     instanceCount += (long)(var4 * var2 + var1 - byFld);
                     ++var4;
                  } while(var4 < 3);

                  bArrFld[var1 - 1] = var7;
               }
            default:
               if (var7) {
               }
         }
      }

      long var8 = (long)(var0 + Float.floatToIntBits(var6) + var1 + var2 + var3 + var4 + (var7 ? 1 : 0)) + FuzzerUtils.checkSum(var5);
      lMeth_check_sum += var8;
      return var8;
   }

   public int iMeth() {
      float var1;
      float var2;
      int var3;
      int var4;
      int var5;
      boolean var6;
      var1 = -101.128F;
      var2 = -35.345F;
      var3 = -93;
      var4 = -9297;
      var5 = -21449;
      var6 = false;
      label38:
      switch ((this.iFld - this.iFld >>> 1) % 8 + 68) {
         case 68:
            dFld *= (double)instanceCount;
            byArrFld = byArrFld = byArrFld = byArrFld;
            this.iArrFld[(this.iFld >>> 1) % 400] = (int)((long)(this.iFld = (int)(dFld + (double)this.iFld)) - instanceCount);
            break;
         case 69:
            instanceCount *= (long)(-(-67.104506 - (double)(--instanceCount)) + (double)(instanceCount + (long)this.iFld) + (double)this.lArrFld[177][(this.iFld >>> 1) % 400][(this.iFld >>> 1) % 400]);
            break;
         case 70:
            for(var1 = 190.0F; 1.0F < var1; --var1) {
               var3 -= Math.max(this.iFld, this.iArrFld[(int)var1]);
               this.iFld = (int)lMeth();
               instanceCount *= (long)var3;
               var3 += (int)(var1 * var1 + (float)instanceCount - (float)instanceCount);
               if (var6) {
                  break;
               }
            }

            var4 = 4;

            while(true) {
               if (197 <= var4) {
                  break label38;
               }

               dFld = -11.0;
               ++var4;
            }
         case 71:
            dFld = (double)var3;
            break;
         case 72:
         case 73:
            var2 *= (float)dFld;
            break;
         case 74:
            var5 += var4;
            break;
         case 75:
            this.iFld |= var4;
      }

      long var7 = (long)(Float.floatToIntBits(var1) + var3 + (var6 ? 1 : 0) + var4 + var5 + Float.floatToIntBits(var2));
      iMeth_check_sum += var7;
      return (int)var7;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 57891;
      int var4 = -52195;
      int var5 = -2;
      int var6 = -171;
      int var7 = -11368;
      int var8 = -240;
      int var9 = 48841;
      double var10 = -1.12201;
      boolean var12 = true;
      short var13 = 15486;

      int var16;
      for(var16 = 4; var16 < 364; ++var16) {
         for(var4 = 3; 70 > var4; ++var4) {
            var3 -= (int)var10;

            for(var6 = 1; var6 < 2; ++var6) {
               int var10000 = var3 << var5;
               instanceCount = -(++instanceCount);
               double[] var17 = dArrFld[var4 + 1];
               var17[var6 - 1] -= (double)this.iMeth();
               var5 = (int)dFld;
               var3 = var4;
            }

            for(var8 = 1; var8 < 2; ++var8) {
               this.iArrFld[var8 - 1] = (int)instanceCount;
               fFld += (float)var8;
               switch (var16 % 5 * 5 + 106) {
                  case 114:
                     var7 -= (int)instanceCount;
                     var9 = (int)((long)var9 + ((long)var8 * instanceCount + (long)var5 - (long)var7));
                     switch (var16 % 8 + 112) {
                        case 112:
                           instanceCount >>= var6;
                        case 113:
                           instanceCount -= (long)var9;
                           continue;
                        case 114:
                           byFld = (byte)((int)dFld);
                           fFld += (float)var16;
                        case 115:
                        case 116:
                           var3 += var16;
                           switch ((var9 >>> 1) % 5 + 4) {
                              case 4:
                              case 5:
                                 int[] var18 = this.iArrFld;
                                 var18[var4] -= (int)instanceCount;
                                 continue;
                              case 6:
                                 if (var12) {
                                    continue;
                                 }
                              case 7:
                                 instanceCount += (long)var13;
                                 var5 += var8 - this.iFld;
                                 var3 <<= var9;
                                 fFld += (float)(var8 * var8);
                                 continue;
                              case 8:
                                 var3 <<= this.iFld;
                              default:
                                 continue;
                           }
                        case 117:
                           var5 = var7;
                           continue;
                        case 118:
                           try {
                              var3 = this.iArrFld[var8] / '\ue93e';
                              var5 = var4 / -7014;
                              var5 = 294254790 % var4;
                           } catch (ArithmeticException var15) {
                           }
                           continue;
                        case 119:
                           var9 += 8;
                        default:
                           continue;
                     }
                  case 115:
                  case 117:
                  case 118:
                  case 120:
                  case 121:
                  case 122:
                  case 124:
                  case 125:
                  case 126:
                  default:
                     var9 = var7;
                     break;
                  case 116:
                  case 127:
                     dFld -= 34800.0;
                     break;
                  case 119:
                     var5 = (int)fFld;
                     break;
                  case 123:
                     this.iArrFld[var16] = 21693;
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var16 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 d i4 = " + var5 + "," + Double.doubleToLongBits(var10) + "," + var6);
      FuzzerUtils.out.println("i5 i17 i18 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("b3 s = " + (var12 ? 1 : 0) + "," + var13);
      FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("Test.byFld Test.fFld Test.dArrFld = " + byFld + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("Test.byArrFld iArrFld lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum((Object[][])this.lArrFld));
      FuzzerUtils.out.println("Test.bArrFld = " + FuzzerUtils.checkSum(bArrFld));
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(dArrFld, 93.1927);
      FuzzerUtils.init(byArrFld, (byte)-56);
      FuzzerUtils.init(bArrFld, false);
      iMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
   }
}
