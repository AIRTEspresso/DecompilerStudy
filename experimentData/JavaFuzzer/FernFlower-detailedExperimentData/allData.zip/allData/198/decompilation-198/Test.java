public class Test {
   public static final int N = 400;
   public static long instanceCount = -5222L;
   public static volatile int iFld = 88;
   public boolean bFld = true;
   public float fFld = -36.1F;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public static double[] dArrFld = new double[400];
   public static long vMeth_check_sum;
   public static long fMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0, int var1, int var2) {
      boolean var3 = true;
      short var4 = 135;
      boolean var5 = true;
      double var6 = 124.113852;
      short var8 = -16932;
      float var9 = 0.781F;
      float[] var10 = new float[400];
      FuzzerUtils.init(var10, -1.329F);
      var10[226] *= (float)iFld;

      int var11;
      for(var11 = 14; 265 > var11; ++var11) {
         instanceCount = (long)var11;
         var0 = var11 + (int)var6;
         iArrFld[var11] = (int)instanceCount;
         var8 += (short)((int)var9);
      }

      iFld = (int)var9;
      iFld = var0;
      int var12 = 320;

      do {
         instanceCount *= instanceCount;
         var6 += (double)var0;
         iFld += var0;
         var9 += (float)(var12 + var12);
         iFld = var12;
         var12 -= 2;
      } while(var12 > 0);

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var11 + var4) + Double.doubleToLongBits(var6) + (long)var8 + (long)Float.floatToIntBits(var9) + (long)var12 + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
   }

   public static float fMeth(int var0, float var1) {
      vMeth1(var0, var0, var0);
      var0 >>= var0;
      long var2 = (long)(var0 + Float.floatToIntBits(var1));
      fMeth_check_sum += var2;
      return (float)var2;
   }

   public static void vMeth(int var0) {
      double var1;
      short var3;
      int var4;
      int var5;
      int var6;
      boolean var7;
      float var8;
      var1 = 0.54918;
      var3 = -25327;
      var4 = -10;
      var5 = 54959;
      var6 = -31164;
      var7 = true;
      var8 = 127.843F;
      var1 -= (double)(instanceCount * (long)(var3 * iArrFld[(var0 >>> 1) % 400]));
      int[] var9;
      label42:
      switch ((-14227 - (var0 + -240) >>> 1) % 4 * 5 + 110) {
         case 113:
            var9 = iArrFld;
            var9[97] *= var3;
            break;
         case 117:
            fMeth(iFld, 0.97F);
         case 125:
            var4 = 7;

            while(true) {
               if (var4 >= 175) {
                  break label42;
               }

               label37:
               switch (var4 % 1 + 28) {
                  case 28:
                     instanceCount += (long)var4;
                     if (var7) {
                        break;
                     }

                     var6 = 1;

                     while(true) {
                        var1 -= (double)var6;
                        if (!var7) {
                           long[] var10000 = lArrFld;
                           var10000[var4 + 1] += -31L;
                           iFld >>= 11;
                           var8 *= (float)instanceCount;
                           var5 = var6;
                           var9 = iArrFld;
                           var9[var4 - 1] -= (int)var8;
                        }

                        ++var6;
                        if (var6 >= 9) {
                           break label37;
                        }
                     }
                  default:
                     var5 >>= var6;
               }

               ++var4;
            }
         case 121:
            var1 = (double)instanceCount;
      }

      vMeth_check_sum += (long)var0 + Double.doubleToLongBits(var1) + (long)var3 + (long)var4 + (long)var5 + (long)(var7 ? 1 : 0) + (long)var6 + (long)Float.floatToIntBits(var8);
   }

   public void mainTest(String[] var1) {
      byte var2 = 26;
      boolean var3 = true;
      int var4 = -201;
      int var5 = -50780;
      int var6 = -13;
      int var7 = -34538;
      int var8 = -107;
      short var9 = -9896;
      double var10 = -41.74295;
      iFld = (int)(instanceCount * (long)(iFld % (var2 | 1) - (iFld + -43)));
      instanceCount >>>= (int)(3325148203513961961L * (long)(iFld + iFld + iFld++));

      int var14;
      for(var14 = 3; var14 < 152; ++var14) {
         vMeth(249);
         iFld -= (int)instanceCount;

         for(var5 = 6; var5 < 168; ++var5) {
            for(var7 = 1; var7 < 2; ++var7) {
               switch (var7 % 7 * 5 + 108) {
                  case 109:
                     var4 = (int)((long)var8 + ((long)(var7 * var5 + var6) - instanceCount));
                     this.fFld -= (float)var9;
                     break;
                  case 119:
                     var6 += var7 ^ var14;
                     break;
                  case 125:
                     switch (var14 % 4 + 90) {
                        case 90:
                           var4 += var7 ^ var9;

                           try {
                              iArrFld[var14 + 1] = -35219 / var7;
                              iFld = -18791 / var8;
                              iFld = -257669378 % var8;
                           } catch (ArithmeticException var13) {
                           }

                           switch (var7 % 8 + 21) {
                              case 21:
                                 instanceCount -= (long)var4;
                                 continue;
                              case 22:
                              case 23:
                                 instanceCount = (long)var5;
                                 var8 += var14;
                                 int[] var15 = iArrFld;
                                 var15[var14] += (int)instanceCount;
                                 continue;
                              case 24:
                                 var6 -= iFld;
                              case 25:
                                 var8 += var7 * var5;
                                 continue;
                              case 26:
                                 var4 += 5118 + var7 * var7;
                              case 27:
                                 iArrFld = iArrFld;
                                 continue;
                              case 28:
                                 var4 += var7 ^ var5;
                              default:
                                 continue;
                           }
                        case 91:
                           if (this.bFld) {
                              continue;
                           }
                        case 92:
                           var6 = -8;
                           continue;
                        case 93:
                           var8 ^= -44;
                           continue;
                        default:
                           var8 += var7;
                           continue;
                     }
                  case 132:
                     var6 = (int)instanceCount;
                     double[] var10000 = dArrFld;
                     var10000[var5] -= var10;
                     break;
                  case 134:
                     var4 += var6;
                     break;
                  case 135:
                     var8 %= iFld | 1;
                     var8 *= (int)this.fFld;
                     var9 += (short)(var7 * iFld);
                     instanceCount += (long)var7;
                     break;
                  case 140:
                     if (!this.bFld) {
                        var8 >>>= var5;
                        if (!this.bFld) {
                           iFld *= (int)instanceCount;
                        }
                     }
                     break;
                  default:
                     var2 <<= (byte)var6;
               }
            }
         }
      }

      FuzzerUtils.out.println("by i i1 = " + var2 + "," + var14 + "," + var4);
      FuzzerUtils.out.println("i13 i14 i15 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i16 s2 d2 = " + var8 + "," + var9 + "," + Double.doubleToLongBits(var10));
      FuzzerUtils.out.println("Test.instanceCount Test.iFld bFld = " + instanceCount + "," + iFld + "," + (this.bFld ? 1 : 0));
      FuzzerUtils.out.println("fFld Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
      FuzzerUtils.out.println("Test.dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-2);
      FuzzerUtils.init(lArrFld, 51240L);
      FuzzerUtils.init(dArrFld, 0.119512);
      vMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
