public class Test {
   public static final int N = 400;
   public static long instanceCount = 3510175330L;
   public static double dFld = -1.90633;
   public static int iFld = 151;
   public static boolean bFld = true;
   public static float fFld = -1.903F;
   public static int iFld1 = -98;
   public float[] fArrFld = new float[400];
   public double[] dArrFld = new double[400];
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long byMeth_check_sum = 0L;

   public static byte byMeth(long var0) {
      boolean var2 = false;
      int var3 = 1;
      int var4 = -8;
      short var5 = 134;
      int var6 = 6;
      short var7 = 25681;
      int[] var8 = new int[400];
      double[][] var9 = new double[400][400];
      float[][] var10 = new float[400][400];
      FuzzerUtils.init((int[])var8, (int)-90);
      FuzzerUtils.init(var9, -116.38173);
      FuzzerUtils.init(var10, 0.695F);

      int var13;
      for(var13 = 7; var13 < 383; var13 += 3) {
         var8[var13 + 1] = var13;
         var8[var13 + 1] = 1708639143;
         if (!bFld) {
            var9[var13 - 1][var13] -= dFld;
            var8[var13 + 1] *= iFld;

            for(var4 = 1; var4 < 13; ++var4) {
               var10[var4][var13 + 1] += -96.24669F;
               var3 *= iFld;
               var5 = 119;
               iFld += var4 * iFld;
               dFld -= 6.0;

               for(var6 = 1; 2 > var6; ++var6) {
                  instanceCount = 11L;
                  fFld += -12.0F;
               }
            }
         }
      }

      long var11 = var0 + (long)var13 + (long)var3 + (long)var4 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9)) + Double.doubleToLongBits(FuzzerUtils.checkSum(var10));
      byMeth_check_sum += var11;
      return (byte)((int)var11);
   }

   public static void vMeth1() {
      int var0 = 18301;
      int var1 = 6;
      byte var2 = 90;
      int var3 = 242;
      byte var4 = -10;
      int[][][] var5 = new int[400][400][400];
      double[] var6 = new double[400];
      boolean[][][] var7 = new boolean[400][400][400];
      FuzzerUtils.init((Object[][])var5, 189);
      FuzzerUtils.init(var6, -1.38009);
      FuzzerUtils.init((Object[][])var7, true);
      iFld -= iFld + byMeth(instanceCount);
      instanceCount = (long)iFld;
      int[] var10000 = var5[(iFld >>> 1) % 400][(iFld >>> 1) % 400];
      int var10001 = (iFld >>> 1) % 400;
      var10000[var10001] *= iFld;

      try {
         dFld = -65.86675;
         iFld -= var0;
         fFld *= (float)instanceCount;
      } catch (ArrayIndexOutOfBoundsException var9) {
         for(var1 = 3; var1 < 366; ++var1) {
            if (!bFld) {
               iFld /= 58217;

               for(var3 = 1; var3 < 5 && !bFld; ++var3) {
                  var6[var3 - 1] = dFld;
                  var7[var1 + 1][var1 + 1][var3] = false;
                  var0 >>= var2;
               }
            }
         }
      }

      vMeth1_check_sum += (long)(var0 + var1 + var2 + var3 + var4) + FuzzerUtils.checkSum((Object[][])var5) + Double.doubleToLongBits(FuzzerUtils.checkSum(var6)) + FuzzerUtils.checkSum((Object[][])var7);
   }

   public static void vMeth(int var0) {
      int var1 = 5;
      int var2 = 88;
      int var3 = -127;
      int var4 = 63718;
      int var5 = -36655;
      int[] var6 = new int[400];
      byte var7 = -23;
      long[] var8 = new long[400];
      FuzzerUtils.init((int[])var6, (int)22851);
      FuzzerUtils.init(var8, -1L);
      if (bFld) {
         for(var1 = 8; var1 < 395; ++var1) {
            instanceCount = (long)var1;
            ++var2;
            var7 >>= (byte)var2;
            vMeth1();
            var3 = 1;

            do {
               iFld |= var2;

               for(var4 = 1; var4 < 1; ++var4) {
                  var6[var4] <<= (int)instanceCount;
                  instanceCount *= (long)var3;
                  var0 %= -134705901;
                  if (bFld) {
                     break;
                  }

                  fFld = (float)var5;
                  instanceCount >>= var2;
               }

               var8[var1 - 1] &= instanceCount;
               ++var3;
            } while(var3 < 4);
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + var2 + var7 + var3 + var4 + var5) + FuzzerUtils.checkSum(var6) + FuzzerUtils.checkSum(var8);
   }

   public void mainTest(String[] var1) {
      int var2 = 65017;
      boolean var3 = true;
      int var4 = 72;
      int var5 = 0;
      char var6 = '\uf180';
      int var7 = 1;
      int var8 = 17987;
      int var9 = -179;
      int var10 = 35156;
      short var11 = 128;
      int var12 = 7;
      short var13 = -182;
      int[][] var14 = new int[400][400];
      byte var15 = 6;
      short var16 = 17318;
      long[] var17 = new long[400];
      FuzzerUtils.init((int[][])var14, (int)8);
      FuzzerUtils.init(var17, -47807L);
      this.fArrFld[(var2 >>> 1) % 400] = (float)(((double)(var2--) - --this.dArrFld[(var2 >>> 1) % 400]) * (double)var2);

      int var18;
      for(var18 = 8; var18 < 268; ++var18) {
         instanceCount = -56804L - ((long)(var4 - -3) + 26507L % ((long)(++dFld) | 1L));
      }

      label94: {
         label115: {
            label91: {
               vMeth(-59020);
               switch ((var4 >>> 1) % 10 + 20) {
                  case 20:
                     iFld = iFld;
                     break label94;
                  case 21:
                     var2 = var15;
                     break label94;
                  case 22:
                     var5 = 2;

                     while(true) {
                        if (var5 >= 351) {
                           break label94;
                        }

                        instanceCount |= (long)var5;
                        var4 >>= var6;
                        ++var5;
                     }
                  case 23:
                     var7 = 190;

                     while(true) {
                        --var7;
                        if (var7 <= 0) {
                           break;
                        }

                        instanceCount = instanceCount;

                        for(var8 = var7; var8 < 132; var8 += 2) {
                           iFld1 = var4;

                           for(var10 = 1; var10 < 1; ++var10) {
                              var14[var7 + 1][var8 - 1] = iFld1;
                              if (bFld) {
                                 dFld %= (double)(var18 | 1);
                                 var9 += var10 - iFld;
                                 var2 += var10 * var18 + var5 - var9;
                                 fFld += (float)((long)var10 * instanceCount + instanceCount - (long)var5);
                              }

                              instanceCount += (long)var15;
                           }

                           var4 = iFld1;

                           for(var12 = 1; var12 < 1; ++var12) {
                              dFld = dFld;
                              fFld += (float)var18;
                           }

                           iFld = var16;
                           var6 = var6;
                        }

                        instanceCount -= instanceCount;
                        iFld |= (int)instanceCount;
                     }
                  case 24:
                     var17[0] = (long)var7;
                  case 25:
                     break label115;
                  case 26:
                     var15 = (byte)var9;
                  case 27:
                     break label91;
                  case 28:
                     var2 = var2;
                  case 29:
                     break;
                  default:
                     break label94;
               }

               instanceCount = instanceCount;
               break label94;
            }

            var17[(var11 >>> 1) % 400] -= instanceCount;
            break label94;
         }

         var2 += var5;
      }

      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var18 + "," + var4);
      FuzzerUtils.out.println("by1 i20 i21 = " + var15 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i22 i23 i24 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("i25 i26 i27 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("i28 s iArr3 = " + var13 + "," + var16 + "," + FuzzerUtils.checkSum(var14));
      FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(var17));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
      FuzzerUtils.out.println("Test.bFld Test.fFld Test.iFld1 = " + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld) + "," + iFld1);
      FuzzerUtils.out.println("fArrFld dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
      FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
