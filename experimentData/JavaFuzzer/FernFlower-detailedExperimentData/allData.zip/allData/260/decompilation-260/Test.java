public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = -3099474333537191129L;
   public float fFld = 29.269F;
   public double dFld = -57.18327;
   public static volatile float[] fArrFld = new float[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0) {
      double var1 = -1.13784;
      double var3 = 0.90818;
      long var5 = 24502L;
      int var7 = 8;

      for(var5 = 227L; var5 > 13L; var5 -= 3L) {
         var0 &= (int)var5;
         var7 -= var0;
      }

      long var8 = (long)var0 + Double.doubleToLongBits(var3) + Double.doubleToLongBits(var3) + var5 + (long)var7;
      lMeth_check_sum += var8;
      return var8;
   }

   public static int iMeth(int var0, int var1, long var2) {
      boolean var4 = true;
      int var5 = -22;
      int var6 = -13;
      int var7 = -7;
      int[] var8 = new int[400];
      boolean var9 = true;
      float var10 = 0.893F;
      long[] var11 = new long[400];
      FuzzerUtils.init(var8, -59938);
      FuzzerUtils.init(var11, 3282737081295925556L);
      var1 = (int)(instanceCount - (long)var1 + (long)var1 + (long)(var1 + var1) * ((long)var1 - instanceCount));
      int var14 = 1;

      while(true) {
         ++var14;
         if (var14 >= 309) {
            var11[(var7 >>> 1) % 400] *= (long)var5;
            long var12 = (long)(var0 + var1) + var2 + (long)var14 + (long)(var9 ? 1 : 0) + (long)var5 + (long)var6 + (long)var7 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var11);
            iMeth_check_sum += var12;
            return (int)var12;
         }

         var0 &= (int)lMeth(var0);
         int var10000 = var1 | var14;
         var1 = -10;
         var9 = var9;

         for(var5 = var14; var5 < 5; ++var5) {
            var7 = 1;

            while(true) {
               ++var7;
               if (var7 >= 1) {
                  var8[var5] = var1;
                  var0 += var7;
                  instanceCount += var2;
                  break;
               }

               var6 = (int)var2;
               var10 = (float)var1;
               if (var6 != 0) {
               }
            }
         }
      }
   }

   public static void vMeth() {
      float var0 = 91.443F;
      int var1 = -3;
      int var2 = -53817;
      int var3 = -4;
      int var4 = -53;
      int var5 = -136;
      byte var6 = -1;
      int[] var7 = new int[400];
      double var8 = 0.46309;
      double var10 = -53.130981;
      double[] var12 = new double[400];
      boolean var13 = true;
      boolean[] var14 = new boolean[400];
      FuzzerUtils.init(var12, -113.85435);
      FuzzerUtils.init(var14, true);
      FuzzerUtils.init((int[])var7, (int)-20971);
      var0 = (float)(iMeth(var1, var1, instanceCount) + var1);
      var12[(var1 >>> 1) % 400] = 10105.0;

      for(var8 = 4.0; 386.0 > var8; ++var8) {
         for(var3 = 1; var3 < 4; ++var3) {
            var10 -= 5.0;
            instanceCount *= instanceCount;
            instanceCount >>>= (int)instanceCount;
            var4 += (int)(-10L + (long)(var3 * var3));

            for(var5 = 1; var5 < 2; ++var5) {
               var14[var5] = var13;
               var0 += (float)var4;
               var4 *= var1;
               var4 += var5 * var5;
               var1 = (int)instanceCount;
            }
         }
      }

      var7[(var4 >>> 1) % 400] <<= -41926;
      vMeth_check_sum += (long)(Float.floatToIntBits(var0) + var1) + Double.doubleToLongBits(var8) + (long)var2 + (long)var3 + (long)var4 + Double.doubleToLongBits(var10) + (long)var5 + (long)var6 + (long)(var13 ? 1 : 0) + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)) + FuzzerUtils.checkSum(var14) + FuzzerUtils.checkSum(var7);
   }

   public void mainTest(String[] var1) {
      int var2 = -39671;
      int var3 = -13;
      int var4 = -8;
      int var5 = 143;
      int var6 = -106;
      int var7 = -58827;
      int[][] var8 = new int[400][400];
      boolean var9 = true;
      short var10 = -6874;
      double[] var11 = new double[400];
      long[] var12 = new long[400];
      FuzzerUtils.init(var11, 1.28224);
      FuzzerUtils.init((int[][])var8, (int)-22388);
      FuzzerUtils.init(var12, 35192L);
      vMeth();
      var2 = 1;

      label58:
      while(true) {
         ++var2;
         if (var2 >= 160) {
            FuzzerUtils.out.println("i14 i15 b2 = " + var2 + "," + var3 + "," + (var9 ? 1 : 0));
            FuzzerUtils.out.println("s i16 i17 = " + var10 + "," + var4 + "," + var5);
            FuzzerUtils.out.println("i18 i19 dArr1 = " + var6 + "," + var7 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var11)));
            FuzzerUtils.out.println("iArr2 lArr1 = " + FuzzerUtils.checkSum(var8) + "," + FuzzerUtils.checkSum(var12));
            FuzzerUtils.out.println("Test.instanceCount fFld dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(this.dFld));
            FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
            FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         var3 = 230;

         try {
            var3 %= 209;
            var3 /= var3;
            var3 = var2 / var3;
         } catch (ArithmeticException var14) {
         }

         if (!var9) {
            var3 += var2;
            switch (var2 % 10 + 55) {
               case 55:
                  if (!var9) {
                     var8[var2][var2 - 1] -= (int)instanceCount;
                     var3 += var2 - var3;
                  }

                  instanceCount += (long)var10;
                  var4 = 2;

                  while(true) {
                     if (var4 >= 157) {
                        continue label58;
                     }

                     this.fFld += (float)(15667 + var4 * var4);
                     var5 = (int)instanceCount;
                     instanceCount = instanceCount;
                     var5 += var4 * var4;
                     var8[var4 + 1][var4] += var2;
                     var8[var4][var4] += var2;
                     var5 -= var2;
                     var6 >>= -19;
                     ++var4;
                  }
               case 56:
                  var10 = (short)(var10 - 10318);
                  break;
               case 57:
                  var3 += var6;
                  break;
               case 58:
                  var8[var2 - 1][var2] = var3;
                  var8[var2 - 1] = var8[var2];
                  var7 = 157;

                  while(true) {
                     var7 -= 3;
                     if (var7 <= 0) {
                        continue label58;
                     }

                     this.dFld -= (double)var4;
                     var6 = 182;
                     this.fFld += (float)(var7 * var7);
                  }
               case 59:
                  fArrFld[var2 - 1] = (float)var3;
               case 60:
                  var5 = (int)((long)var5 + ((long)var2 * instanceCount + (long)var10 - (long)var2));
                  break;
               case 61:
                  instanceCount = instanceCount;
                  break;
               case 62:
                  var3 -= (int)instanceCount;
                  break;
               case 63:
                  var3 = var4;
                  break;
               case 64:
                  var5 += var2;
                  break;
               default:
                  var10 -= (short)((int)this.dFld);
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, -40.976F);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
