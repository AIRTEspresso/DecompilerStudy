public class Test {
   public static final int N = 400;
   public static long instanceCount = 2L;
   public static int iFld = -218;
   public static volatile byte byFld = -102;
   public short sFld = -25450;
   public static double dFld = 1.8143;
   public static boolean bFld = true;
   public static long vMeth_check_sum = 0L;
   public static long iMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;

   public static void vMeth1(long var0, int var2) {
      vMeth1_check_sum += var0 + (long)var2;
   }

   public static int iMeth(int var0) {
      boolean var1 = false;
      float var2 = 97.812F;
      int var3 = -50639;
      short var4 = 12600;
      int var5 = 11;
      short var6 = 221;
      int[] var7 = new int[400];
      byte[] var8 = new byte[400];
      long[] var9 = new long[400];
      FuzzerUtils.init(var8, (byte)-87);
      FuzzerUtils.init((int[])var7, (int)5);
      FuzzerUtils.init(var9, -4419682554608553365L);
      vMeth1(instanceCount, iFld);
      if (var1) {
         iFld |= iFld;
         var8[(var0 >>> 1) % 400] = byFld;
      }

      var2 = (float)iFld;
      int[] var10 = var7;
      int var11 = var7.length;

      for(int var12 = 0; var12 < var11; ++var12) {
         int var10000 = var10[var12];
         int var10001 = (iFld >>> 1) % 400;
         var7[var10001] += iFld;

         for(var3 = 1; var3 < 4; ++var3) {
            iFld *= (int)var2;
            var9[var3 + 1] <<= var4;

            for(var5 = 1; var5 < 2; ++var5) {
               instanceCount *= (long)var4;
               var2 = (float)var3;
               iFld -= -9;
               instanceCount *= instanceCount;
            }
         }
      }

      long var14 = (long)(var0 + (var1 ? 1 : 0) + Float.floatToIntBits(var2) + var3 + var4 + var5 + var6) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var14;
      return (int)var14;
   }

   public static void vMeth() {
      int var0;
      int var1;
      byte var2;
      int var3;
      byte var4;
      int[] var5;
      long var6;
      long[] var8;
      byte var9;
      short var10;
      boolean var11;
      var0 = 10;
      var1 = -20950;
      var2 = 7;
      var3 = -241;
      var4 = 7;
      var5 = new int[400];
      var6 = 134L;
      var8 = new long[400];
      var9 = 78;
      var10 = -17714;
      var11 = false;
      FuzzerUtils.init((int[])var5, (int)36246);
      FuzzerUtils.init(var8, 215L);
      label37:
      switch ((9 + --iFld >>> 1) % 1 + 53) {
         case 53:
            var0 = 1;

            while(true) {
               for(var1 = var0; var1 < 9; ++var1) {
                  instanceCount -= var6 + (long)(var5[(var0 >>> 1) % 400] + iFld * iFld);
               }

               iFld >>= var2;

               for(var3 = 1; var3 < 9; ++var3) {
                  var5[var3] *= (var9 + var1 + (var4 - var9)) * var0;
                  int var10002 = var0 - 1;
                  int var10004 = var5[var0 - 1];
                  var5[var10002] = var5[var0 - 1] - 1;
                  instanceCount >>= var10004;
                  var10 |= (short)var5[var0 - 1];
                  iMeth(var2);
                  iFld = (int)instanceCount;
                  var8[var0 + 1] -= (long)var10;
                  iFld = var2;
                  instanceCount += (long)var3;
               }

               ++var0;
               if (var0 >= 169) {
                  break label37;
               }
            }
         default:
            var11 = false;
      }

      vMeth_check_sum += (long)(var0 + var1 + var2) + var6 + (long)var3 + (long)var4 + (long)var9 + (long)var10 + (long)(var11 ? 1 : 0) + FuzzerUtils.checkSum(var5) + FuzzerUtils.checkSum(var8);
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 117;
      int var4 = -169;
      int var5 = -1852;
      int var6 = -44238;
      int var7 = 9;
      short var8 = -133;
      int var9 = -61689;
      int var10 = -73;
      int[][] var11 = new int[400][400];
      float var12 = -44.284F;
      long[][][] var13 = new long[400][400][400];
      FuzzerUtils.init((Object[][])var13, -3359696756L);
      FuzzerUtils.init((int[][])var11, (int)187);
      int var16 = 1;

      while(true) {
         while(true) {
            ++var16;
            if (var16 >= 203) {
               FuzzerUtils.out.println("i i13 i14 = " + var16 + "," + var3 + "," + var4);
               FuzzerUtils.out.println("i15 i16 i17 = " + var5 + "," + var6 + "," + var7);
               FuzzerUtils.out.println("i18 f1 i19 = " + var8 + "," + Float.floatToIntBits(var12) + "," + var9);
               FuzzerUtils.out.println("i20 lArr2 iArr2 = " + var10 + "," + FuzzerUtils.checkSum((Object[][])var13) + "," + FuzzerUtils.checkSum(var11));
               FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + byFld);
               FuzzerUtils.out.println("sFld Test.dFld Test.bFld = " + this.sFld + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
               FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
               FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
               FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
               return;
            }

            switch (var16 % 2 + 44) {
               case 44:
                  vMeth();
                  iFld = iFld;
                  instanceCount = (long)var16;
                  break;
               case 45:
                  var13[var16 - 1][var16 + 1][var16] += (long)iFld;

                  for(var3 = 1; var3 < 124; ++var3) {
                     for(var5 = 1; 2 > var5; ++var5) {
                        var11[var5][var16 - 1] <<= var6;
                        this.sFld -= (short)((int)instanceCount);
                        instanceCount += (long)var5 * instanceCount;
                     }

                     for(var7 = 2; var7 > 1; --var7) {
                        iFld += (int)instanceCount;
                        instanceCount ^= (long)var4;
                        var11[var16 + 1][var3 - 1] = (int)instanceCount;
                        var11[var16 - 1] = FuzzerUtils.int1array(400, 65);
                     }

                     var4 -= (int)var12;
                     dFld = dFld;
                     if (!bFld) {
                        var4 *= var7;

                        try {
                           var4 = 436342200 % var11[var16][var3 - 1];
                           iFld = var16 % -8174;
                           var11[var16 - 1][var16] = var8 % -696068463;
                        } catch (ArithmeticException var15) {
                        }

                        var6 -= (int)dFld;

                        for(var9 = 2; var9 > var3; --var9) {
                           byFld -= (byte)var6;
                           var10 = iFld;
                           var6 -= (int)instanceCount;
                           switch (var16 % 10 + 21) {
                              case 21:
                                 var6 *= (int)instanceCount;
                                 if (bFld) {
                                 }
                                 break;
                              case 22:
                                 iFld = var10;
                                 break;
                              case 23:
                                 instanceCount += (long)var12;
                                 break;
                              case 24:
                                 var13[var9 + 1][var9 + 1][var16] += 13L;
                              case 25:
                                 var12 += var12;
                                 break;
                              case 26:
                                 if (bFld) {
                                    break;
                                 }
                              case 27:
                                 var11[var16 - 1][var3] *= -118;
                                 break;
                              case 28:
                                 var11[var16 + 1][var3 - 1] = var3;
                                 break;
                              case 29:
                              case 30:
                                 var10 += iFld;
                                 break;
                              default:
                                 var4 >>= var9;
                           }
                        }
                     }
                  }
            }
         }
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
