public class Test {
   public static final int N = 400;
   public static long instanceCount = -8651291483224068383L;
   public static volatile int iFld = 208;
   public short sFld = 1909;
   public static short[] sArrFld = new short[400];
   public int[] iArrFld = new int[400];
   public static long vMeth_check_sum;
   public static long iMeth_check_sum;
   public static long iMeth1_check_sum;

   public static void vMeth(long var0, double var2) {
      int[] var4 = new int[400];
      FuzzerUtils.init((int[])var4, (int)0);
      iFld -= (int)(var0 - (long)((iFld >>>= 17) - -var4[381]));
      vMeth_check_sum += var0 + Double.doubleToLongBits(var2) + FuzzerUtils.checkSum(var4);
   }

   public static int iMeth1(int var0, int var1) {
      long var2 = -12L;
      int var4 = 6;
      int var5 = -34128;
      int var6 = -220;
      boolean var7 = true;
      int[] var8 = new int[400];
      boolean var9 = true;
      float var10 = -2.165F;
      FuzzerUtils.init((int[])var8, (int)47014);
      short[] var10000 = sArrFld;
      var10000[(var0 >>> 1) % 400] *= (short)(iFld - -3788 - Math.abs(14) - 127);
      vMeth(instanceCount, -127.106268);
      int var10001 = (iFld >>> 1) % 400;
      var8[var10001] >>= iFld;
      var0 >>>= -8108;

      for(var2 = 5L; var2 < 332L; ++var2) {
         for(var5 = (int)var2; var5 < 5; ++var5) {
            try {
               var0 = var5 % iFld;
               var6 = var1 % var5;
               var0 = var8[(int)var2] / -939022363;
            } catch (ArithmeticException var13) {
            }

            var8[var5] = var6;
            var4 *= iFld;
            var9 = var9;
            var8[(int)var2] += iFld;
         }
      }

      int var14 = 1;

      while(true) {
         ++var14;
         if (var14 >= 373) {
            long var11 = (long)(var0 + var1) + var2 + (long)var4 + (long)var5 + (long)var6 + (long)(var9 ? 1 : 0) + (long)var14 + (long)Float.floatToIntBits(var10) + FuzzerUtils.checkSum(var8);
            iMeth1_check_sum += var11;
            return (int)var11;
         }

         var10 += (float)var1;
         var1 += (int)var10;
         iFld = -6;
      }
   }

   public static int iMeth() {
      float var0 = 38.733F;
      int var1 = -32929;
      int var2 = 13;
      int var3 = 27508;
      int var4 = 89;
      int[] var5 = new int[400];
      byte var6 = 18;
      boolean var7 = true;
      short var8 = 7711;
      FuzzerUtils.init((int[])var5, (int)-6405);
      iFld = (int)((float)iMeth1(iFld, iFld) * var0);
      int[] var9 = var5;
      int var10 = var5.length;

      for(int var11 = 0; var11 < var10; ++var11) {
         int var12 = var9[var11];
         instanceCount = (long)iFld;
         var0 = (float)var12;
         switch ((var12 >>> 1) % 2 * 5 + 90) {
            case 98:
               for(var1 = 1; 4 > var1; ++var1) {
                  for(var3 = 1; var3 < 2; ++var3) {
                     iFld -= var3;
                     switch (var3 % 5 + 97) {
                        case 97:
                           var5[var1] *= (int)var0;
                           var6 >>>= (byte)var2;
                           if (var7) {
                              var2 = var3;
                           } else {
                              var12 += var3;
                              var8 = -124;
                           }
                           break;
                        case 98:
                           var12 = iFld;
                           break;
                        case 99:
                           iFld = (int)instanceCount;
                           break;
                        case 100:
                           try {
                              var2 = iFld % 356175627;
                              var12 = iFld % 199;
                              var5[var1 + 1] = iFld % -4448;
                           } catch (ArithmeticException var14) {
                           }
                           break;
                        case 101:
                           var2 += iFld;
                     }
                  }
               }
               break;
            case 100:
               var4 += 177;
         }
      }

      long var15 = (long)(Float.floatToIntBits(var0) + var1 + var2 + var3 + var4 + var6 + (var7 ? 1 : 0) + var8) + FuzzerUtils.checkSum(var5);
      iMeth_check_sum += var15;
      return (int)var15;
   }

   public void mainTest(String[] var1) {
      double var2 = 2.18213;
      double[] var4 = new double[400];
      boolean var5 = true;
      int var6 = -116;
      int var7 = -51794;
      int var8 = 25092;
      int var9 = 11;
      int var10 = 2;
      int var11 = -93;
      byte var12 = 2;
      float var13 = -2.267F;
      byte var14 = 13;
      FuzzerUtils.init(var4, -96.81267);
      vMeth((long)(iMeth() * iFld), var2);
      switch ((iFld >>> 1) % 1 + 13) {
         case 13:
         default:
            iFld = 10070;

            int var15;
            for(var15 = 12; 298 > var15; ++var15) {
               for(var7 = 1; var7 < 88; ++var7) {
                  var13 -= 90.0F;
                  var8 *= var7;

                  for(var9 = 1; var9 < 2; ++var9) {
                     instanceCount = 200L;
                     switch (var7 % 1 * 5 + 105) {
                        case 108:
                           var8 += var9;
                           break;
                        default:
                           instanceCount = instanceCount;
                           short[] var10000 = sArrFld;
                           var10000[var9] *= (short)var9;
                           var6 -= var14;
                     }

                     instanceCount = (long)var9;
                     instanceCount = instanceCount;
                     var4 = var4;
                     iFld = (int)((long)iFld + ((long)var9 ^ instanceCount));
                     int[] var16 = this.iArrFld;
                     var16[var9 + 1] += iFld;
                     this.sFld = -7;
                  }

                  this.iArrFld[var7 - 1] = var7;

                  for(var11 = 1; 2 > var11; ++var11) {
                     instanceCount = -87L;
                     this.sFld -= (short)((int)var13);
                     var8 += (int)var13;
                     var13 += (float)(var11 * var8 + var12 - iFld);
                     var10 = var11;
                     var2 *= var2;
                     instanceCount += -4L;
                  }
               }
            }

            FuzzerUtils.out.println("d1 i11 i12 = " + Double.doubleToLongBits(var2) + "," + var15 + "," + var6);
            FuzzerUtils.out.println("i13 i14 f2 = " + var7 + "," + var8 + "," + Float.floatToIntBits(var13));
            FuzzerUtils.out.println("i15 i16 by1 = " + var9 + "," + var10 + "," + var14);
            FuzzerUtils.out.println("i17 i18 dArr = " + var11 + "," + var12 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var4)));
            FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + this.sFld);
            FuzzerUtils.out.println("Test.sArrFld iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
            FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((short[])sArrFld, (short)13224);
      vMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
