public class Test {
   public static final int N = 400;
   public static long instanceCount = -3628910667L;
   public static double dFld = 2.79858;
   public static float fFld = -60.894F;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;

   public static void vMeth1(int var0) {
      float var1 = 96.689F;
      boolean var2 = true;
      boolean var3 = true;
      int var4 = -10611;
      double[] var5 = new double[400];
      FuzzerUtils.init(var5, 23.91101);
      instanceCount = (long)var0;
      var1 += (float)var0;
      dFld += 0.0;
      var1 -= 80.0F;

      int var6;
      for(var6 = 1; var6 < 191; var6 += 3) {
         int[] var10000 = iArrFld;
         var10000[var6] %= var0 | 1;
         instanceCount = (long)var4;
         instanceCount %= (long)(var4 | 1);
         var0 <<= var0;
         var4 -= 14958;
         instanceCount = (long)var6;
         var5[var6 + 1] -= 1264.0;
      }

      vMeth1_check_sum += (long)(var0 + Float.floatToIntBits(var1) + (var2 ? 1 : 0) + var6 + var4) + Double.doubleToLongBits(FuzzerUtils.checkSum(var5));
   }

   public static void vMeth(int var0, int var1) {
      float var2 = 7.519F;
      boolean var3 = false;
      boolean var4 = true;
      int var5 = 27288;
      short var6 = 19328;
      short var7 = -17676;
      vMeth1(var1);
      var2 = -14.0F;
      var3 = var3;
      var1 = var1;
      var0 = var1;
      int var8 = 1;

      while(true) {
         ++var8;
         if (var8 >= 333) {
            vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + (var3 ? 1 : 0) + var8 + var5 + var6 + var7);
            return;
         }

         for(var5 = 1; var5 < 5; ++var5) {
            if (!var3) {
               if (var1 != 0) {
                  vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + (var3 ? 1 : 0) + var8 + var5 + var6 + var7);
                  return;
               }

               var2 += (float)instanceCount;
               var1 *= 16;
               switch (var5 % 2 + 51) {
                  case 51:
                     int[] var10000 = iArrFld;
                     var10000[var8 + 1] ^= var7;
                     var1 <<= (int)instanceCount;
                     break;
                  case 52:
                     var1 -= var0;
               }
            }
         }
      }
   }

   public static int iMeth(float var0) {
      boolean var1 = true;
      int var2 = -49981;
      int var3 = -14;
      int var4 = -61863;
      boolean var5 = true;
      short[][] var6 = new short[400][400];
      boolean var7 = true;
      long[] var8 = new long[400];
      FuzzerUtils.init(var8, -7222466420424892458L);
      FuzzerUtils.init((short[][])var6, (short)22852);

      int var11;
      for(var11 = 9; var11 < 233; ++var11) {
         var8[var11 + 1] += (long)var11;

         for(var3 = 1; var3 < 7; ++var3) {
            vMeth(var4, var11);
         }

         var8[var11 + 1] = (long)var3;
         instanceCount = 152L;
         var2 += var11;
         var2 += var11 + var2;
         var6[var11][var11] = (short)var11;
         var4 *= var11;
      }

      short var12 = (short)((int)var0);
      if (var7) {
         var2 = 74;
         var4 >>>= var2;
      } else {
         var4 += (int)instanceCount;
      }

      long var9 = (long)(Float.floatToIntBits(var0) + var11 + var2 + var3 + var4 + var12 + (var7 ? 1 : 0)) + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum(var6);
      iMeth_check_sum += var9;
      return (int)var9;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -135;
      int var4 = -7;
      int var5 = 166;
      boolean var6 = true;
      int var7 = -43722;
      int var8 = -63123;
      short var9 = -30339;
      byte var10 = -11;
      int var11 = -46;
      int var12 = -3;
      int[] var13 = new int[400];
      boolean var14 = false;
      float var15 = -37.797F;
      FuzzerUtils.init((int[])var13, (int)-9);

      int var16;
      for(var16 = 2; var16 < 371; ++var16) {
         for(var4 = 2; 68 > var4; ++var4) {
            var13[var16 - 1] = -(var3-- + (var5 <<= 222));
            var3 |= 47052;
            dFld = 63.34771;
            var5 += 15;
            var13[var4 - 1] ^= var16;
         }

         var5 += var4;
         var3 = var5;
         dFld = (double)fFld;
         var14 = var14;
      }

      int var17;
      for(var17 = 8; 392 > var17; ++var17) {
         for(var8 = var17; var8 < 66; ++var8) {
            switch ((var7 >>> 1) % 1 + 89) {
               case 89:
                  var7 <<= -8;

                  for(var15 = 1.0F; var15 < 1.0F; var15 += 2.0F) {
                     var5 -= var17;
                     if (var14) {
                        break;
                     }

                     var5 = (int)instanceCount;
                     var5 <<= var9;
                     instanceCount /= (long)(var7 | 1);
                  }

                  var5 += 5123;
            }

            for(var11 = 1; var11 < 1; ++var11) {
               if (!var14) {
                  var3 += 53660;
                  var5 <<= var10;
                  if (!var14) {
                     --var12;
                  }
               }
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var16 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 b3 i16 = " + var5 + "," + (var14 ? 1 : 0) + "," + var17);
      FuzzerUtils.out.println("i17 i18 i19 = " + var7 + "," + var8 + "," + var9);
      FuzzerUtils.out.println("f3 i20 i21 = " + Float.floatToIntBits(var15) + "," + var10 + "," + var11);
      FuzzerUtils.out.println("i22 iArr = " + var12 + "," + FuzzerUtils.checkSum(var13));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
      FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-4);
      iMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
   }
}
