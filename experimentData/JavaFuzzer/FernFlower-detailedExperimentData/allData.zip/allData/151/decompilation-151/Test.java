public class Test {
   public static final int N = 400;
   public static long instanceCount = -708077500915325689L;
   public int iFld = 27606;
   public static int[] iArrFld = new int[400];
   public static long[] lArrFld = new long[400];
   public double[] dArrFld = new double[400];
   public static long dMeth_check_sum;
   public static long vMeth_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(long var0, int var2) {
      short var3 = -794;
      var3 = (short)(var3 >> 8);
      long var4 = var0 + (long)var2 + (long)var3;
      lMeth_check_sum += var4;
      return var4;
   }

   public static void vMeth(double var0, int var2) {
      float var3 = 0.68F;
      float[] var4 = new float[400];
      int var5 = 61838;
      short var6 = -1;
      int var7 = -21888;
      long var8 = 38238L;
      boolean[] var10 = new boolean[400];
      FuzzerUtils.init(var10, false);
      FuzzerUtils.init(var4, 66.836F);
      var10[(var2 >>> 1) % 400] = (float)var2 == var4[18];
      int[] var11 = iArrFld;
      int var12 = var11.length;

      int[] var10000;
      for(int var13 = 0; var13 < var12; ++var13) {
         int var14 = var11[var13];
         var10000 = iArrFld;
         var10000[(var14 >>> 1) % 400] += var2;
      }

      var2 -= (int)var3;

      for(var5 = 134; var5 > 7; var5 -= 3) {
         var2 = var6;

         for(var8 = 1L; 36L > var8; ++var8) {
            var7 |= (int)(1479690261L + (long)iArrFld[(int)(var8 - 1L)] + -((long)var6 - var8) + (lMeth(var8, var5) - (long)var2));
            var10000 = iArrFld;
            var10000[(int)(var8 + 1L)] *= var2;
            var2 += (int)var8;
            if (var6 != 0) {
               vMeth_check_sum += Double.doubleToLongBits(var0) + (long)var2 + (long)Float.floatToIntBits(var3) + (long)var5 + (long)var6 + var8 + (long)var7 + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var4));
               return;
            }

            var7 *= var2;
            instanceCount += var8 ^ (long)var2;
         }

         if (var2 != 0) {
            vMeth_check_sum += Double.doubleToLongBits(var0) + (long)var2 + (long)Float.floatToIntBits(var3) + (long)var5 + (long)var6 + var8 + (long)var7 + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var4));
            return;
         }

         var6 = 21956;
      }

      vMeth_check_sum += Double.doubleToLongBits(var0) + (long)var2 + (long)Float.floatToIntBits(var3) + (long)var5 + (long)var6 + var8 + (long)var7 + FuzzerUtils.checkSum(var10) + Double.doubleToLongBits(FuzzerUtils.checkSum(var4));
   }

   public static double dMeth(long var0, int var2) {
      double var3 = 71.91273;
      boolean var5 = true;
      boolean var6 = true;
      int var7 = -6;
      int var8 = -69;
      byte var9 = 27;
      long[][][] var10 = new long[400][400][400];
      FuzzerUtils.init((Object[][])var10, 164L);
      vMeth(var3, var2);
      var2 <<= (int)instanceCount;

      int var13;
      for(var13 = 3; var13 < 321; ++var13) {
         for(var7 = 1; var7 < 5; ++var7) {
            var2 *= (int)var0;
            var9 = (byte)var2;
            var8 <<= 205;
            iArrFld[var13] = var8;
            instanceCount += (long)(119 + var7 * var7);
         }
      }

      short var14 = -210;
      var10[(var14 >>> 1) % 400][(var2 >>> 1) % 400][(var2 >>> 1) % 400] = (long)var7;
      instanceCount = 14L;
      var9 -= (byte)var13;
      long var11 = var0 + (long)var7 + Double.doubleToLongBits(var3) + (long)var13 + (long)var14 + (long)var7 + (long)var13 + (long)var9 + FuzzerUtils.checkSum((Object[][])var10);
      dMeth_check_sum += var11;
      return (double)var11;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = -9;
      int var4 = 0;
      int var5 = 0;
      int var6 = 5243;
      int var7 = -157;
      int[] var8 = new int[400];
      double var9 = 0.23301;
      double var11 = -1.45981;
      float var13 = 2.405F;
      short var14 = -10275;
      boolean var15 = false;
      byte var16 = -39;
      FuzzerUtils.init((int[])var8, (int)-7868);
      int var17 = 1;

      while(true) {
         ++var17;
         if (var17 >= 250) {
            break;
         }

         for(var3 = 101; var3 > var17; var3 -= 3) {
            for(var9 = 1.0; 1.0 < var9; var9 -= 2.0) {
               var8[var3] = (int)instanceCount;
               var11 -= (double)var4;
               var13 = (float)dMeth(instanceCount, this.iFld);
               var5 += var4;
               lArrFld[var3] = (long)var3;
               var11 -= (double)var5;
               instanceCount = (long)var3;
               var11 *= (double)instanceCount;
               var8 = iArrFld;
               var8[var17] <<= var17;
            }

            var5 >>= var17;
            var13 += (float)instanceCount;
            var11 += (double)var14;
            var5 += 248 + var3 * var3;
            instanceCount = 2L;
            var14 += (short)var3;
         }

         iArrFld[var17 - 1] = (int)instanceCount;
         if (var15) {
            break;
         }

         var8[var17 + 1] /= (int)((long)var9 | 1L);
         var6 = 1;

         while(true) {
            double[] var10000 = this.dArrFld;
            var10000[var17] -= (double)instanceCount;
            var4 -= var16;
            this.iFld &= var5;
            var7 = 1;

            do {
               var5 >>= (int)instanceCount;
               this.iFld -= (int)instanceCount;
               this.iFld -= (int)var11;
               ++var7;
            } while(var7 < 1);

            ++var6;
            if (var6 >= 101) {
               break;
            }
         }
      }

      FuzzerUtils.out.println("i i1 i2 = " + var17 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("d i3 d1 = " + Double.doubleToLongBits(var9) + "," + var5 + "," + Double.doubleToLongBits(var11));
      FuzzerUtils.out.println("f s1 b = " + Float.floatToIntBits(var13) + "," + var14 + "," + (var15 ? 1 : 0));
      FuzzerUtils.out.println("i15 by1 i16 = " + var6 + "," + var16 + "," + var7);
      FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(var8));
      FuzzerUtils.out.println("Test.instanceCount iFld Test.iArrFld = " + instanceCount + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("Test.lArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)68);
      FuzzerUtils.init(lArrFld, 39896L);
      dMeth_check_sum = 0L;
      vMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
