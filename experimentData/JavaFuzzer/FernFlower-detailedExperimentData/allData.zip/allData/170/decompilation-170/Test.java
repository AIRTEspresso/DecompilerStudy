public class Test {
   public static final int N = 400;
   public static volatile long instanceCount = 3032226234022873105L;
   public static float fFld = 1.207F;
   public static double dFld = 0.4622;
   public int iFld = -49138;
   public int iFld1 = 14;
   public int[] iArrFld = new int[400];
   public volatile long[] lArrFld = new long[400];
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long vMeth2_check_sum = 0L;

   public static void vMeth2(double var0) {
      boolean var2 = true;
      int var3 = -4;
      int var4 = 32;
      byte var5 = -7;
      boolean var6 = true;
      short var7 = -145;
      int var8 = 179;
      byte var9 = 110;
      byte var10 = 103;
      boolean var11 = true;
      short var12 = 9273;
      double[] var13 = new double[400];
      FuzzerUtils.init(var13, -32.3747);
      int var14 = 1;

      while(true) {
         ++var14;
         if (var14 >= 177) {
            int var15;
            for(var15 = 6; var15 < 189; ++var15) {
               instanceCount *= (long)var0;

               for(var8 = 1; var8 < 9; ++var8) {
                  var12 = (short)((int)instanceCount);
                  instanceCount = instanceCount;
               }
            }

            vMeth2_check_sum += Double.doubleToLongBits(var0) + (long)var14 + (long)var3 + (long)var4 + (long)var5 + (long)var10 + (long)(var11 ? 1 : 0) + (long)var15 + (long)var7 + (long)var8 + (long)var9 + (long)var12 + Double.doubleToLongBits(FuzzerUtils.checkSum(var13));
            return;
         }

         var13[var14 - 1] -= (double)var14;
         var3 = 1;

         while(true) {
            fFld -= (float)var3;

            for(var4 = 1; 1 < var4; --var4) {
               var10 += (byte)((int)instanceCount);
               fFld = (float)var4;
               instanceCount += (long)var4;
               instanceCount -= -123L;
            }

            if (var11) {
            }

            ++var3;
            if (var3 >= 9) {
               break;
            }
         }
      }
   }

   public static void vMeth1(int var0) {
      boolean var1 = true;
      int var2 = -4;
      int var3 = 96;
      int var4 = 32;
      int var5 = 24;
      short var6 = -248;
      int[] var7 = new int[400];
      float var8 = -122.842F;
      float[] var9 = new float[400];
      double var10 = -2.94347;
      short var12 = 31877;
      FuzzerUtils.init((int[])var7, (int)197);
      FuzzerUtils.init(var9, 4.473F);

      int var13;
      for(var13 = 1; var13 < 180; ++var13) {
         for(var3 = 1; var3 < 9; ++var3) {
            instanceCount = (long)((float)(-16757 / ((var4 /= (int)(instanceCount | 1L)) | 1)) + -(var8++));
            var2 |= (int)(-((long)var3 % ((long)var10 | 1L) - (long)var12));
            vMeth2(119.124321);
            var10 = (double)var0;
         }

         var2 = 90;

         for(var5 = 1; 9 > var5; ++var5) {
            instanceCount = instanceCount;
            var7 = var7;
            var0 += var5;
         }

         instanceCount += (long)(var13 * var6 + var6 - var13);
         var9[var13 - 1] = (float)var4;
         fFld -= (float)var5;
         var7[var13 + 1] = (int)var10;
      }

      vMeth1_check_sum += (long)(var0 + var13 + var2 + var3 + var4 + Float.floatToIntBits(var8)) + Double.doubleToLongBits(var10) + (long)var12 + (long)var5 + (long)var6 + FuzzerUtils.checkSum(var7) + Double.doubleToLongBits(FuzzerUtils.checkSum(var9));
   }

   public static void vMeth(short var0, int var1) {
      float var2 = -80.315F;
      int var3 = 11869;
      int var4 = 14;
      int var5 = 14;
      int var6 = -32022;
      int var7 = -28666;
      int var8 = -207;
      int[] var9 = new int[400];
      FuzzerUtils.init((int[])var9, (int)1);
      vMeth1(var1);
      fFld *= fFld;

      for(var2 = 4.0F; var2 < 197.0F; ++var2) {
         --var3;
         var0 += (short)((int)var2);
         var4 = 8;

         do {
            var3 *= (int)var2;
            var4 -= 2;
         } while(var4 > 0);

         switch ((int)(var2 % 4.0F + 35.0F)) {
            case 35:
            case 36:
               for(var5 = (int)var2; var5 < 8; ++var5) {
                  var9[var5] -= var1;
                  var3 += (int)var2;
                  instanceCount = -42617L;

                  for(var7 = 1; var7 > 1; var7 -= 2) {
                     var8 = (int)instanceCount;
                     var6 -= var3;
                  }
               }
               break;
            case 37:
               var1 = 1;
               break;
            case 38:
               var8 *= (int)fFld;
            default:
               var9[(int)var2] += var7;
         }
      }

      vMeth_check_sum += (long)(var0 + var1 + Float.floatToIntBits(var2) + var3 + var4 + var5 + var6 + var7 + var8) + FuzzerUtils.checkSum(var9);
   }

   public void mainTest(String[] var1) {
      int var2;
      int var3;
      int var4;
      int var5;
      int var6;
      int var7;
      int var8;
      int var9;
      int var10;
      int var11;
      int var12;
      int var13;
      byte var14;
      byte var15;
      short var16;
      boolean var17;
      float[] var18;
      var2 = -139;
      var3 = 11;
      var4 = 75;
      var5 = -211;
      var6 = 152;
      var7 = 53797;
      var8 = 8;
      var9 = 185;
      var10 = -35606;
      var11 = 220;
      var12 = 24813;
      var13 = -144;
      var14 = 105;
      var15 = -18;
      var16 = -6786;
      var17 = false;
      var18 = new float[400];
      FuzzerUtils.init(var18, -2.482F);
      vMeth((short)24513, var2);
      label74:
      switch ((var2 >>> 1) % 10 * 5 + 88) {
         case 93:
            var16 *= (short)var14;
         case 125:
            instanceCount *= (long)var13;
            break;
         case 96:
         case 98:
         case 136:
            var11 = var4;
         case 104:
            var4 = (int)instanceCount;
         case 97:
            var4 <<= var11;
            break;
         case 101:
            var4 <<= -12;
            break;
         case 110:
            var3 = 1;

            while(true) {
               if (var3 >= 378) {
                  break label74;
               }

               for(var5 = 67; var3 < var5; --var5) {
                  var6 *= 25632;

                  for(var7 = 1; var7 < 1; ++var7) {
                     var18[var7] *= (float)var4;
                     instanceCount = instanceCount;
                     var8 >>= var15;
                     this.iArrFld[var3 + 1] = var9;
                     fFld += (float)instanceCount;
                     instanceCount = instanceCount;
                     var4 += var7 | var4;
                  }

                  instanceCount -= (long)var2;
                  var9 += (int)dFld;
               }

               dFld += 54190.0;
               if (!var17) {
                  instanceCount *= instanceCount;
               } else {
                  for(var10 = 2; 67 > var10; ++var10) {
                     var12 = 1;

                     do {
                        this.iArrFld[var12] = (int)dFld;
                        fFld += (float)var16;
                        var2 = var5;
                        instanceCount += (long)var12;
                        ++var12;
                     } while(var12 < 2);

                     var6 -= var9;
                     this.lArrFld[var10] = 120L;
                     var11 = 44;
                     instanceCount += 23L + (long)(var10 * var10);

                     for(var13 = 2; 1 < var13; var13 -= 2) {
                        var6 = this.iFld;
                     }

                     instanceCount = (long)var14;
                  }
               }

               ++var3;
            }
         case 119:
            this.lArrFld[(this.iFld >>> 1) % 400] = 77L;
            break;
         default:
            var8 += var2;
      }

      FuzzerUtils.out.println("i22 i23 i24 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i25 i26 i27 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("i28 by1 i29 = " + var8 + "," + var15 + "," + var9);
      FuzzerUtils.out.println("i30 i31 i32 = " + var10 + "," + var11 + "," + var12);
      FuzzerUtils.out.println("s3 i33 i34 = " + var16 + "," + var13 + "," + var14);
      FuzzerUtils.out.println("b1 fArr1 = " + (var17 ? 1 : 0) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var18)));
      FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
      FuzzerUtils.out.println("iFld iFld1 iArrFld = " + this.iFld + "," + this.iFld1 + "," + FuzzerUtils.checkSum(this.iArrFld));
      FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
      FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
      FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
