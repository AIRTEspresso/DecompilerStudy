public class Test {
   public static final int N = 400;
   public static long instanceCount = 4278281980L;
   public static short sFld = -24456;
   public static boolean bFld = false;
   public static float fFld = 2.386F;
   public volatile byte byFld = 2;
   public static volatile float[] fArrFld = new float[400];
   public long[] lArrFld = new long[400];
   public byte[] byArrFld = new byte[400];
   public static long vMeth_check_sum;
   public static long vMeth1_check_sum;
   public static long lMeth_check_sum;

   public static long lMeth(int var0, boolean var1, int var2) {
      double var3 = 3.84741;
      double[] var5 = new double[400];
      int var6 = 49439;
      int var7 = -241;
      boolean var8 = true;
      byte var9 = 102;
      byte var10 = -105;
      int[][] var11 = new int[400][400];
      long[] var12 = new long[400];
      FuzzerUtils.init(var12, 14L);
      FuzzerUtils.init(var5, -68.84704);
      FuzzerUtils.init((int[][])var11, (int)4332);
      var3 *= (double)instanceCount;

      for(var6 = 6; var6 < 138; ++var6) {
         var12[var6 + 1] += (long)var7;
         instanceCount -= (long)var2;
         var2 = (int)var3;
         instanceCount = (long)fFld;
      }

      int var15;
      for(var15 = 4; var15 < 373; ++var15) {
         var0 = -91;
         var7 += var6;
      }

      var5[(var9 >>> 1) % 400] -= (double)var7;
      var0 *= var10;
      var11[(var15 >>> 1) % 400][(var6 >>> 1) % 400] = var9;
      instanceCount -= (long)var7;
      var7 += 306195405;
      long var13 = (long)(var0 + (var1 ? 1 : 0) + var2) + Double.doubleToLongBits(var3) + (long)var6 + (long)var7 + (long)var15 + (long)var9 + (long)var10 + FuzzerUtils.checkSum(var12) + Double.doubleToLongBits(FuzzerUtils.checkSum(var5)) + FuzzerUtils.checkSum(var11);
      lMeth_check_sum += var13;
      return var13;
   }

   public static void vMeth1() {
      double var0 = -1.23577;
      double var2 = -2.76994;
      int var4 = -14;
      boolean var5 = true;
      int var6 = -21357;
      int var7 = 168;
      int var8 = 168;
      int var9 = -4;
      int var10 = -8673;
      int var11 = -1;
      int[] var12 = new int[400];
      byte var13 = 83;
      float var14 = 2.133F;
      FuzzerUtils.init((int[])var12, (int)11);

      for(var0 = 290.0; var0 > 9.0; --var0) {
         sFld *= (short)((int)((float)var4 - ((float)var4 + -1.194F + (float)var4)));
         instanceCount += (long)(var4 + ((var4 & var4) - Integer.reverseBytes(var4)));
         instanceCount &= (long)(var4--);
      }

      var12[(var4 >>> 1) % 400] -= (int)((long)(var4 * var13 - (var4 - var4)) - instanceCount * (long)(++var12[2]));

      int var17;
      for(var17 = 4; var17 < 334; ++var17) {
         bFld = (float)((long)(var6 - var17) - instanceCount) < Math.abs(var14--);

         label42:
         for(var7 = 1; var7 < 5; ++var7) {
            var8 = (int)(var14 * (float)((long)var6 % (instanceCount | 1L) - (long)(var7 + var6)));
            switch (var7 % 2 * 5 + 86) {
               case 91:
                  var9 = 1;

                  while(true) {
                     if (var9 >= 2) {
                        continue label42;
                     }

                     instanceCount &= (long)((var12[var17] = -671314614) << (int)instanceCount >> (int)((long)((double)(--sFld) - -(++var2))));
                     var12[var9 - 1] *= var4--;
                     ++var6;
                     var6 = (int)(((long)var6 - (-3335545688L - (long)(sFld + var8))) / (long)(Math.max(var10, var4 - -153) | 1));
                     var11 += var9 * var10;
                     ++var9;
                  }
               case 92:
                  try {
                     var10 = 2834 / var10;
                     var6 = var12[var7 - 1] / -163;
                     var12[var7 - 1] = '턵' % var12[var17 + 1];
                  } catch (ArithmeticException var16) {
                  }
                  break;
               default:
                  var11 += var4 = (int)((long)Math.max(-70, var17) + lMeth(3, bFld, var10));
            }
         }
      }

      vMeth1_check_sum += Double.doubleToLongBits(var0) + (long)var4 + (long)var13 + (long)var17 + (long)var6 + (long)Float.floatToIntBits(var14) + (long)var7 + (long)var8 + (long)var9 + (long)var10 + Double.doubleToLongBits(var2) + (long)var11 + FuzzerUtils.checkSum(var12);
   }

   public static void vMeth(byte var0) {
      boolean var1 = true;
      int var2 = -10;
      int var3 = 14628;
      int var4 = -245;
      int var5 = -2;
      short var6 = -161;
      int[] var7 = new int[400];
      float var8 = 106.101F;
      double var9 = -79.96836;
      long[] var11 = new long[400];
      FuzzerUtils.init((int[])var7, (int)9);
      FuzzerUtils.init(var11, -54925L);

      int var14;
      for(var14 = 21; var14 < 392; ++var14) {
         for(var3 = 1; var3 < 5; ++var3) {
            var4 = var2--;
            instanceCount += (long)var3;
            var5 = 1;

            do {
               try {
                  var2 = var4 % 14923;
                  var7[var14 + 1] = -1213247365 / var14;
                  var2 = var14 / var5;
               } catch (ArithmeticException var13) {
               }

               ++var5;
            } while(var5 < 2);

            if (var3 != 0) {
               vMeth_check_sum += (long)(var0 + var14 + var2 + var3 + var4 + var5 + Float.floatToIntBits(var8)) + Double.doubleToLongBits(var9) + (long)var6 + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var11);
               return;
            }

            var11[var3] *= 38L;
            var7[var14] = Math.min(Math.min(var2 * -41532, (int)(var8 * (float)instanceCount)), --var7[var3 - 1]);
            vMeth1();
            var4 >>= var5;
            var7[var14 + 1] *= (int)instanceCount;
            var9 = 1.0;

            do {
               var4 += (int)var9;
               var6 = 4;
            } while(++var9 < 2.0);
         }
      }

      vMeth_check_sum += (long)(var0 + var14 + var2 + var3 + var4 + var5 + Float.floatToIntBits(var8)) + Double.doubleToLongBits(var9) + (long)var6 + FuzzerUtils.checkSum(var7) + FuzzerUtils.checkSum(var11);
   }

   public void mainTest(String[] var1) {
      int var2 = 10;
      int var3 = 44231;
      int var4 = 20;
      int var5 = 54258;
      byte var6 = 10;
      int var7 = 51192;
      int var8 = -5393;
      int[][] var9 = new int[400][400];
      long var10 = -6984477168613311786L;
      double[] var12 = new double[400];
      FuzzerUtils.init(var12, -2.49867);
      FuzzerUtils.init((int[][])var9, (int)-67);
      var2 += 62056;
      vMeth(this.byFld);
      var3 = 1;

      while(true) {
         ++var3;
         if (var3 >= 331) {
            double[] var13 = var12;
            int var14 = var12.length;

            for(int var15 = 0; var15 < var14; ++var15) {
               double var10000 = var13[var15];
               float[] var19 = fArrFld;
               var19[(var3 >>> 1) % 400] += (float)sFld;

               for(var4 = 3; var4 < 63; ++var4) {
                  var5 = var3;
                  if (!bFld) {
                     for(var10 = 1L; var10 < 2L; ++var10) {
                        var9[(int)(var10 - 1L)][(int)(var10 + 1L)] = (int)var10;
                        sFld += (short)((int)instanceCount);
                        if (bFld) {
                           this.lArrFld = this.lArrFld;
                           if (bFld) {
                              break;
                           }
                        } else {
                           instanceCount -= instanceCount;
                           instanceCount >>>= var3;
                        }
                     }

                     fFld += (float)(var4 + var6);
                     var5 = var3 + this.byFld;

                     for(var7 = 1; 2 > var7; ++var7) {
                        var9[var7 - 1][var7 + 1] = var5;
                        instanceCount += (long)(var7 * var7);
                        fFld %= (float)(var10 | 1L);
                        sFld = (short)var7;
                        instanceCount += -4256195689L + (long)(var7 * var7);
                        instanceCount += (long)sFld;
                        byte[] var20 = this.byArrFld;
                        var20[var4 - 1] &= (byte)var4;
                        var8 = var5;
                     }

                     var8 -= var7;
                  }
               }
            }

            FuzzerUtils.out.println("i i22 i23 = " + var2 + "," + var3 + "," + var4);
            FuzzerUtils.out.println("i24 l i25 = " + var5 + "," + var10 + "," + var6);
            FuzzerUtils.out.println("i26 i27 dArr1 = " + var7 + "," + var8 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)));
            FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(var9));
            FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + sFld + "," + (bFld ? 1 : 0));
            FuzzerUtils.out.println("Test.fFld byFld Test.fArrFld = " + Float.floatToIntBits(fFld) + "," + this.byFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
            FuzzerUtils.out.println("lArrFld byArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
            FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         short var18 = sFld;
         var2 = -99;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 0.988F);
      vMeth_check_sum = 0L;
      vMeth1_check_sum = 0L;
      lMeth_check_sum = 0L;
   }
}
