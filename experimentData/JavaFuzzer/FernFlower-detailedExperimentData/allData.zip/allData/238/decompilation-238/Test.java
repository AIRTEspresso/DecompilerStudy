public class Test {
   public static final int N = 400;
   public static long instanceCount = 91422406L;
   public static volatile int iFld = 48503;
   public static double dFld = -57.101559;
   public static short sFld = 14556;
   public static long vMeth_check_sum = 0L;
   public static long vMeth1_check_sum = 0L;
   public static long vMeth2_check_sum = 0L;

   public static void vMeth2() {
      boolean var0 = true;
      boolean var1 = true;
      int var2 = 4224;
      int var3 = 187;
      int[] var4 = new int[400];
      float var5 = -2.326F;
      FuzzerUtils.init((int[])var4, (int)1);
      int var8 = 1;

      int var9;
      do {
         for(var9 = 1; var9 < 13; ++var9) {
            var4 = var4;
            iFld = (int)((long)iFld + ((long)(var9 * var2) + instanceCount - instanceCount));
            iFld >>>= (int)instanceCount;
            var2 *= var2;
            instanceCount -= instanceCount;
            var3 = 1;

            while(true) {
               ++var3;
               if (var3 >= 2) {
                  break;
               }

               switch (var8 % 4 + 58) {
                  case 58:
                     instanceCount = 1529322783506501478L;
                     iFld = (int)dFld;
                     iFld += (int)(0L + (long)(var3 * var3));
                     break;
                  case 59:
                     --iFld;
                     var2 += (int)(-394978877L + (long)(var3 * var3));

                     try {
                        var4[98] = var8 % var4[var9 - 1];
                        var2 = 214 / var4[var3 + 1];
                        var2 = -107 % var4[var9 + 1];
                     } catch (ArithmeticException var7) {
                     }
                     break;
                  case 60:
                     sFld += (short)((int)var5);
                     break;
                  case 61:
                     iFld += -9;
               }
            }
         }

         ++var8;
      } while(var8 < 121);

      vMeth2_check_sum += (long)(var8 + var9 + var2 + var3 + Float.floatToIntBits(var5)) + FuzzerUtils.checkSum(var4);
   }

   public static void vMeth1() {
      boolean var0 = true;
      int var1 = 252;
      int var2 = -241;
      int var3 = -9972;
      int var4 = 6;
      int[] var5 = new int[400];
      float var6 = 0.294F;
      long var7 = -3391514436L;
      FuzzerUtils.init((int[])var5, (int)93);
      int var9 = 1;

      while(true) {
         ++var9;
         if (var9 >= 179) {
            vMeth1_check_sum += (long)(var9 + var1 + Float.floatToIntBits(var6)) + var7 + (long)var2 + (long)var3 + (long)var4 + FuzzerUtils.checkSum(var5);
            return;
         }

         instanceCount += (long)(iFld--);
         var1 = 1;

         do {
            var6 += (float)(var1 * var1);
            ++var1;
         } while(var1 < 9);

         instanceCount -= (long)var5[var9 - 1];
         vMeth2();

         for(var7 = 9L; var7 > 1L; --var7) {
            for(var3 = 1; var3 < 2; ++var3) {
               dFld += (double)var9;
               var2 += (int)(101L + (long)(var3 * var3));
               var4 = (int)((float)var4 + ((float)((long)var3 * var7) + var6 - (float)instanceCount));
               var2 *= 234;
               var6 *= (float)sFld;
               var5[(int)(var7 - 1L)] <<= iFld;
               var4 = (int)var7;
            }
         }
      }
   }

   public static void vMeth(byte var0, boolean var1) {
      boolean var2 = true;
      boolean var3 = true;
      int var4 = 35;
      float var5 = -62.619F;
      vMeth1();
      int var6 = 320;

      while(true) {
         --var6;
         if (var6 <= 0) {
            instanceCount = (long)iFld;
            iFld = 0;

            int var7;
            for(var7 = 5; var7 < 240; ++var7) {
               var4 += var7;
            }

            iFld <<= var6;
            instanceCount *= (long)sFld;
            iFld += var0;
            instanceCount >>= -1409;
            var4 += (int)dFld;
            vMeth_check_sum += (long)(var0 + (var1 ? 1 : 0) + var6 + Float.floatToIntBits(var5) + var7 + var4);
            return;
         }

         var5 *= (float)iFld;
      }
   }

   public void mainTest(String[] var1) {
      byte var2 = -10;
      boolean var3 = false;
      boolean var4 = true;
      int var5 = 137;
      int var6 = -12;
      int[] var7 = new int[400];
      long var8 = -6333598361640171668L;
      long var10 = 3717823922L;
      long[] var12 = new long[400];
      float var13 = 79.696F;
      FuzzerUtils.init((int[])var7, (int)-2);
      FuzzerUtils.init(var12, 119L);
      vMeth(var2, var3);
      int var14 = 1;

      while(true) {
         ++var14;
         if (var14 >= 313) {
            FuzzerUtils.out.println("by1 b1 i12 = " + var2 + "," + (var3 ? 1 : 0) + "," + var14);
            FuzzerUtils.out.println("l1 i13 l2 = " + var8 + "," + var5 + "," + var10);
            FuzzerUtils.out.println("f3 i14 iArr2 = " + Float.floatToIntBits(var13) + "," + var6 + "," + FuzzerUtils.checkSum(var7));
            FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(var12));
            FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(dFld));
            FuzzerUtils.out.println("Test.sFld = " + sFld);
            FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
            FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
            FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            return;
         }

         iFld += iFld;

         for(var8 = 2L; 80L > var8; ++var8) {
            for(var10 = 1L; ++var10 < 2L; var7[var14 + 1] = (int)var13) {
               var5 += (int)(var10 * var10);
               var7[(int)(var10 + 1L)] -= var5;
               var13 += (float)var10;
               var5 >>= (int)instanceCount;
               instanceCount += var10;
               switch ((int)(var10 % 1L + 60L)) {
                  case 60:
                     var5 += (int)var10;
                     break;
                  default:
                     instanceCount &= var8;
                     iFld += iFld;
                     var2 -= (byte)((int)var10);
               }
            }

            dFld -= (double)var14;
            var6 = 1;

            while(true) {
               ++var6;
               if (var6 >= 2) {
                  iFld -= (int)dFld;
                  break;
               }

               iFld = 0;
               iFld <<= var14;
               var5 >>= var5;
               var5 = iFld;
               var7[(int)var8] += var6;
               var12[var14 - 1] >>= -73;
               var2 = (byte)((int)dFld);
            }
         }

         iFld = iFld;
         var12[var14] = 30L;
         iFld += 987379418;
      }
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
