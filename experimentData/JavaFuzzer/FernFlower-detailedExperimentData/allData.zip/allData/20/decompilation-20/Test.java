public class Test {
   public static final int N = 400;
   public static long instanceCount = 199L;
   public static boolean bFld = true;
   public volatile double dFld = 1.45337;
   public static long iMeth_check_sum = 0L;
   public static long vMeth_check_sum = 0L;
   public static long bMeth_check_sum = 0L;

   public static boolean bMeth(int var0, int var1) {
      long var2 = 0L;
      int var4 = -13;
      int var5 = 5;
      int var6 = -35481;
      int var7 = 53675;
      byte var8 = -8;
      int var9 = 26720;
      int[] var10 = new int[400];
      double var11 = -2.119147;
      FuzzerUtils.init((int[])var10, (int)39814);

      for(var2 = 5L; var2 < 224L; var2 += 2L) {
         for(var5 = 1; 14 > var5; ++var5) {
            var11 -= (double)var6;
            bFld = bFld;
            var11 *= (double)var5;
            if (var6 != 0) {
               return (int)((long)(var0 + var1) + var2 + (long)var4 + (long)var5 + (long)var6 + Double.doubleToLongBits(var11) + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10)) % 2 > 0;
            }

            var10[var5 + 1] = -788283488;
            var6 <<= var6;
            var0 -= 152;
            var6 *= var4;
         }

         for(var7 = 1; var7 < 14; ++var7) {
            var4 <<= var6;
            var4 -= var9;
            var6 += var7 * var7;
            var9 = var1;
         }
      }

      long var13 = (long)(var0 + var1) + var2 + (long)var4 + (long)var5 + (long)var6 + Double.doubleToLongBits(var11) + (long)var7 + (long)var8 + (long)var9 + FuzzerUtils.checkSum(var10);
      bMeth_check_sum += var13;
      return var13 % 2L > 0L;
   }

   public static void vMeth(int var0, long var1, int var3) {
      boolean var4 = true;
      int var5 = 127;
      int var6 = 44526;
      int var7 = 11;
      char var8 = '鼚';
      int[] var9 = new int[400];
      double var10 = -9.95535;
      byte var12 = 97;
      short var13 = -28405;
      FuzzerUtils.init((int[])var9, (int)-11668);
      bFld = bMeth(var0, var0);
      var3 = var0;

      int var14;
      for(var14 = 3; 149 > var14; ++var14) {
         var9[var14 - 1] *= var5;

         for(var10 = (double)var14; var10 < 11.0; ++var10) {
            var5 += (int)var10;

            for(var7 = 1; var7 < 1; ++var7) {
               var5 -= 26;
               var0 |= var12;
               var1 *= (long)var7;
               var6 += var7 - var8;
               var9[var7 + 1] *= var13;
               var13 = (short)((int)var1);
            }
         }
      }

      var13 = (short)(var13 & 269);
      vMeth_check_sum += (long)var0 + var1 + (long)var3 + (long)var14 + (long)var5 + Double.doubleToLongBits(var10) + (long)var6 + (long)var7 + (long)var8 + (long)var12 + (long)var13 + FuzzerUtils.checkSum(var9);
   }

   public static int iMeth(long var0, short var2) {
      int var3 = 61572;
      boolean var4 = true;
      int var5 = 61250;
      int var6 = -126;
      byte var7 = 92;
      int[] var8 = new int[400];
      double var9 = 0.74282;
      long[][][] var11 = new long[400][400][400];
      FuzzerUtils.init((int[])var8, (int)-126);
      FuzzerUtils.init((Object[][])var11, -100L);
      var0 <<= 9;
      vMeth(var3, instanceCount, var3);
      var3 -= var3;
      var9 = (double)var3;
      var3 = var3;

      int var15;
      for(var15 = 13; 338 > var15; ++var15) {
         var5 = var3;

         for(var6 = var15; var6 < 5; ++var6) {
            try {
               var5 = var6 / var7;
               int var10000 = var7 / var15;
               var3 = var8[var6] / -17;
            } catch (ArithmeticException var14) {
            }

            bFld = bFld;
            var3 = (int)instanceCount;
            boolean var16 = true;
            var11[var15][var6 + 1][var15] -= (long)var2;
            var3 = 233;
         }
      }

      long var12 = var0 + (long)var2 + (long)var3 + Double.doubleToLongBits(var9) + (long)var15 + (long)var5 + (long)var6 + (long)var7 + FuzzerUtils.checkSum(var8) + FuzzerUtils.checkSum((Object[][])var11);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void mainTest(String[] var1) {
      int var2 = 60018;
      int var3 = -12710;
      int var4 = 47048;
      int var5 = 61882;
      int var6 = -12;
      int var7 = -13792;
      int var8 = 5;
      int var9 = -119;
      int[] var10 = new int[400];
      float var11 = -2.53F;
      float[] var12 = new float[400];
      short var13 = 7816;
      long var14 = 9630L;
      long[] var16 = new long[400];
      byte var17 = -117;
      FuzzerUtils.init(var12, 0.899F);
      FuzzerUtils.init(var16, -969976997L);
      FuzzerUtils.init((int[])var10, (int)116);

      for(var2 = 11; var2 < 290; ++var2) {
         instanceCount += (long)(var2 * var3 + var2 - var3);
      }

      label55:
      for(var4 = 212; var4 > 8; var4 -= 3) {
         --var5;
         bFld = (float)var5 <= (-2.0F + ++var11) * (float)var2;
         var6 = 1;

         while(true) {
            ++var6;
            if (var6 >= 368) {
               var7 = 1;

               while(true) {
                  ++var7;
                  if (var7 >= 368) {
                     var3 |= var5;
                     continue label55;
                  }

                  var12[17] -= (float)var4;
                  instanceCount = 174L;
                  instanceCount = (long)((float)instanceCount + (float)var7 * var11);
               }
            }

            instanceCount *= (long)(iMeth(instanceCount, var13) * var3);
         }
      }

      for(var14 = 2L; var14 < 165L; ++var14) {
         var9 = 1;

         do {
            var5 = (int)((float)var5 + ((float)var9 * var11 + (float)var4 - (float)var4));
            bFld = bFld;
            var11 = (float)var5;
            var3 = var5 | (int)instanceCount;
            var8 += '隿' + var9 * var9;
            var17 >>= (byte)var3;
            this.dFld = (double)var14;
            var3 >>= var3;
            var5 = 1;
            var9 += 2;
         } while(var9 < 154);

         var16[(int)var14] += -37944L;
         int var10000 = var5 + (int)(var14 ^ (long)var2);
         var5 = var4;
         instanceCount >>>= var17;
         var8 = var13;
      }

      this.dFld *= (double)var14;
      var5 += var5;
      FuzzerUtils.out.println("i i1 i2 = " + var2 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i3 f i4 = " + var5 + "," + Float.floatToIntBits(var11) + "," + var6);
      FuzzerUtils.out.println("s2 i25 l3 = " + var13 + "," + var7 + "," + var14);
      FuzzerUtils.out.println("i26 i27 by1 = " + var8 + "," + var9 + "," + var17);
      FuzzerUtils.out.println("fArr lArr1 iArr3 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(var12)) + "," + FuzzerUtils.checkSum(var16) + "," + FuzzerUtils.checkSum(var10));
      FuzzerUtils.out.println("Test.instanceCount Test.bFld dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
      FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
      FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }
}
