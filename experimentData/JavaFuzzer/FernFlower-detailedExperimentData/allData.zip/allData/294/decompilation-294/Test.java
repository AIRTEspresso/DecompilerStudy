public class Test {
   public static final int N = 400;
   public static long instanceCount = -6544749673385377619L;
   public static double dFld = 1.3548;
   public static byte byFld = -67;
   public static float fFld = -67.281F;
   public static short sFld = -20409;
   public static int[] iArrFld = new int[400];
   public static long iMeth_check_sum;
   public static long lMeth_check_sum;
   public static long iMeth1_check_sum;

   public static int iMeth1() {
      double var0 = 28.76195;
      double var2 = 2.79641;
      short var4 = -6771;
      short var5 = -15281;
      int var6 = 50483;
      int var7 = 10;
      byte var8 = 11;
      int var9 = 15372;
      short var10 = -19966;
      float var11 = 0.176F;
      boolean var12 = false;

      for(var0 = 3.0; var0 < 373.0; ++var0) {
         var10 <<= (short)var4;
      }

      for(var11 = 6.0F; var11 < 236.0F; ++var11) {
         for(var2 = (double)var11; var2 < 7.0; ++var2) {
            var6 += (int)(0.8510000109672546 + var2 * var2);
            instanceCount |= instanceCount;
            var4 = var4;
            instanceCount -= instanceCount;
         }

         for(var7 = 7; 1 < var7; var7 -= 2) {
            boolean var15 = true;
            var6 = (int)instanceCount;
            var9 = 1;

            while(true) {
               ++var9;
               if (var9 >= 3) {
                  break;
               }

               if (var4 != 0) {
               }

               if (!var12) {
                  fFld = -4.0F;
               }
            }
         }
      }

      long var13 = Double.doubleToLongBits(var0) + (long)var4 + (long)var10 + (long)Float.floatToIntBits(var11) + (long)var5 + Double.doubleToLongBits(var2) + (long)var6 + (long)var7 + (long)var8 + (long)var9 + (long)(var12 ? 1 : 0);
      iMeth1_check_sum += var13;
      return (int)var13;
   }

   public static long lMeth(boolean var0, int var1) {
      boolean var2 = true;
      int var3 = 91;
      int var4 = -3952;
      int var5 = -8;
      int var6 = -541;

      int var9;
      for(var9 = 12; 284 > var9; var9 += 3) {
         label38:
         for(var4 = 1; var4 < 17; ++var4) {
            --var3;
            var1 >>>= var3;
            var5 -= (int)instanceCount;
            switch (var4 % 2 * 5 + 102) {
               case 104:
                  var6 = 1;

                  while(true) {
                     ++var6;
                     if (var6 >= 2) {
                        continue label38;
                     }

                     var3 = var3;
                     var1 <<= byFld;
                     if (var6 != 0) {
                     }

                     fFld *= (float)var6;
                     var1 >>>= -164;
                     iArrFld = iArrFld;
                     byFld >>= -6;
                  }
               case 111:
                  var1 *= var5 - (-(var3 * var9) + iArrFld[var4]);
                  var1 -= iMeth1();
            }
         }
      }

      long var7 = (long)((var0 ? 1 : 0) + var1 + var9 + var3 + var4 + var5 + var6);
      lMeth_check_sum += var7;
      return var7;
   }

   public static int iMeth() {
      int var0 = -10;
      int var1 = -13081;
      int var2 = 59614;
      int[] var3 = new int[400];
      float var4 = 2.246F;
      boolean var5 = false;
      FuzzerUtils.init((int[])var3, (int)-190);
      int[] var6 = var3;
      int var7 = var3.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         int var9 = var6[var8];

         try {
            var9 /= var9;
            var9 %= var9;
            var9 = var3[(var9 >>> 1) % 400] % var9;
         } catch (ArithmeticException var11) {
         }

         for(var0 = 1; var0 < 4; ++var0) {
            var9 *= (int)(++instanceCount);
            var2 = 1;

            while(true) {
               var2 += 2;
               if (var2 >= 2) {
                  break;
               }

               var1 += var2 - var0;
               instanceCount *= (long)var1;
               dFld -= (double)var2;
               var1 = (int)(instanceCount - (long)var2);
               var9 = (int)(-((float)(var2 - -11) - (float)var0 * var4));
               byFld *= (byte)((int)lMeth(false, var2));
               var5 = var5;
               instanceCount *= instanceCount;
               fFld = (float)var9;
               var9 += (int)instanceCount;
            }
         }
      }

      long var12 = (long)(var0 + var1 + var2 + Float.floatToIntBits(var4) + (var5 ? 1 : 0)) + FuzzerUtils.checkSum(var3);
      iMeth_check_sum += var12;
      return (int)var12;
   }

   public void mainTest(String[] var1) {
      int var2 = 177;
      short var3 = -148;
      int var4 = -28241;
      int var5 = 9;
      int var6 = 61;
      byte var7 = -12;
      double var8 = 101.67855;
      double[] var10 = new double[400];
      long[] var11 = new long[400];
      FuzzerUtils.init(var11, -121L);
      FuzzerUtils.init(var10, -1.64031);
      var2 -= iMeth();
      instanceCount <<= var2;
      sFld *= (short)var2;
      instanceCount *= (long)var2;
      var2 += (int)instanceCount;
      short var12 = sFld;
      byFld += (byte)((int)instanceCount);
      instanceCount = instanceCount;
      var2 = var12;

      for(var8 = 2.0; var8 < 141.0; ++var8) {
         for(var4 = 9; var4 < 180; ++var4) {
            fFld = (float)dFld;
            var5 |= 57633;
            instanceCount = (long)var4;
            instanceCount *= -137L;
            var5 += var4 * var4;
            var11[(int)(var8 + 1.0)] >>= byFld;
            var5 &= -10;
            var5 += (int)instanceCount;
         }

         byFld <<= (byte)var2;
         var2 += 228;
         byFld = (byte)var5;
         instanceCount = 22244L;

         for(var6 = 2; 180 > var6; ++var6) {
            var5 %= (int)((long)dFld | 1L);
            var3 = sFld;
            fFld = (float)var7;
         }
      }

      FuzzerUtils.out.println("i d2 i17 = " + var2 + "," + Double.doubleToLongBits(var8) + "," + var3);
      FuzzerUtils.out.println("i18 i19 i20 = " + var4 + "," + var5 + "," + var6);
      FuzzerUtils.out.println("i21 lArr dArr = " + var7 + "," + FuzzerUtils.checkSum(var11) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(var10)));
      FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + byFld);
      FuzzerUtils.out.println("Test.fFld Test.sFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + sFld + "," + FuzzerUtils.checkSum(iArrFld));
      FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
      FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init((int[])iArrFld, (int)-69);
      iMeth_check_sum = 0L;
      lMeth_check_sum = 0L;
      iMeth1_check_sum = 0L;
   }
}
