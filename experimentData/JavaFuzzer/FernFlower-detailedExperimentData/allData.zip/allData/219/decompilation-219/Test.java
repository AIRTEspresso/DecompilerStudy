public class Test {
   public static final int N = 400;
   public static long instanceCount = 14L;
   public static byte byFld = -82;
   public static float[] fArrFld = new float[400];
   public static long vSmallMeth_check_sum;
   public static long iMeth_check_sum;
   public static long fMeth_check_sum;

   public static float fMeth(int var0, int var1) {
      int var2;
      int var3;
      int var4;
      int var5;
      int var6;
      double var7;
      boolean var9;
      float var10;
      var2 = 41075;
      var3 = -2;
      var4 = 4322;
      var5 = -10;
      var6 = 9;
      var7 = 57.111964;
      var9 = false;
      var10 = -29.314F;
      label49:
      switch ((var0 >>> 1) % 2 + 70) {
         case 70:
            instanceCount = (long)var0;
            var2 = 13;

            while(true) {
               if (var2 >= 289) {
                  break label49;
               }

               for(var4 = 1; var4 < 6; ++var4) {
                  var6 >>= (int)instanceCount;
                  var0 -= var3;
                  instanceCount = instanceCount;
                  var5 += var2;
                  var1 >>= var3;
                  if (var9) {
                     var5 += var4;
                     var7 = 1.0;

                     while(++var7 < 2.0) {
                        if (var9) {
                           var3 += (int)instanceCount;
                           instanceCount += (long)(var7 * var7);
                        }
                     }
                  } else if (var9) {
                     var5 += (int)instanceCount;
                  } else if (var9) {
                     var1 += (int)var10;
                  }
               }

               ++var2;
            }
         case 71:
            var1 += (int)var10;
      }

      long var11 = (long)(var0 + var1 + var2 + var3 + var4 + var5 + var6) + Double.doubleToLongBits(var7) + (long)(var9 ? 1 : 0) + (long)Float.floatToIntBits(var10);
      fMeth_check_sum += var11;
      return (float)var11;
   }

   public static int iMeth(long var0, long var2, int var4) {
      boolean var5 = true;
      byte var6 = 11;
      int var7 = -5;
      int var8 = -10430;
      int[] var9 = new int[400];
      double var10 = 0.115804;
      boolean var12 = false;
      boolean var13 = false;
      float var14 = -102.937F;
      byte var15 = 26;
      FuzzerUtils.init(var9, -52830);

      int var18;
      for(var18 = 9; var18 < 336; ++var18) {
         for(var7 = 1; var7 < 5; ++var7) {
            var8 *= (int)((double)fArrFld[var7] * (var10 + (var10 - -2.0)));
            if (var12) {
               var12 = true;
               var4 += var7 ^ var8;
               if (var13 = var13) {
                  var8 += 12456 + var7 * var7;
                  var8 += 11 + var7 * var7;
                  var14 = var14;
               }

               if (fMeth(var18, var8) != -68.256F) {
                  break;
               }
            } else {
               var4 = var6;
            }
         }
      }

      long var16 = var0 + var2 + (long)var4 + (long)var18 + (long)var6 + (long)var7 + (long)var8 + Double.doubleToLongBits(var10) + (long)(var12 ? 1 : 0) + (long)Float.floatToIntBits(var14) + (long)(var13 ? 1 : 0) + (long)var15 + FuzzerUtils.checkSum(var9);
      iMeth_check_sum += var16;
      return (int)var16;
   }

   public static void vSmallMeth() {
      short var0 = 130;
      iMeth(instanceCount, instanceCount, var0);
      vSmallMeth_check_sum += (long)var0;
   }

   public void mainTest(String[] var1) {
      boolean var2 = true;
      int var3 = 3388;
      int var4 = -79;
      int var5 = 5241;
      int var6 = 10467;
      int var7 = 171;
      int[] var8 = new int[400];
      float var9 = -125.56F;
      short var10 = 11487;
      FuzzerUtils.init((int[])var8, (int)-81);

      for(int var11 = 0; var11 < 368; ++var11) {
         vSmallMeth();
      }

      instanceCount -= 36L;

      int var12;
      for(var12 = 152; var12 > 9; --var12) {
         for(var4 = 175; var4 > var12; var4 -= 3) {
            fArrFld[var4] = (float)instanceCount;

            for(var6 = 1; var6 < 1; ++var6) {
               var5 += var3;
               var9 = (float)var10;
               switch (var12 % 5 + 106) {
                  case 106:
                     var7 <<= -9;
                     byFld = (byte)var12;
                     var8[var12 + 1] >>>= 64654;
                     var8[var12] *= var3;
                  case 107:
                     var3 >>= (int)instanceCount;
                     break;
                  case 108:
                     var8[var6] >>= (int)instanceCount;
                     var9 -= (float)var6;
                     var5 *= -2;
                     instanceCount -= (long)var6;
                     break;
                  case 109:
                     var5 = var4;
                     break;
                  case 110:
                     var5 = var4;
                     instanceCount &= -6200L;
               }

               var5 *= var4;
               var8[var6] >>= var3;
               var5 += var6 - var7;
            }

            var3 = (int)((long)var3 + (long)var4 + instanceCount);
            var7 -= 2;
            instanceCount = (long)var5;
         }

         instanceCount += (long)var12;
         var5 += var12;
      }

      FuzzerUtils.out.println("i13 i14 i15 = " + var12 + "," + var3 + "," + var4);
      FuzzerUtils.out.println("i16 i17 i18 = " + var5 + "," + var6 + "," + var7);
      FuzzerUtils.out.println("f2 s iArr1 = " + Float.floatToIntBits(var9) + "," + var10 + "," + FuzzerUtils.checkSum(var8));
      FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fArrFld = " + instanceCount + "," + byFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
      FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
      FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
      FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
   }

   public static void main(String[] var0) {
      try {
         Test var1 = new Test();

         for(int var2 = 0; var2 < 10; ++var2) {
            var1.mainTest(var0);
         }
      } catch (Exception var3) {
         FuzzerUtils.out.println(var3.getClass().getCanonicalName());
      }

   }

   static {
      FuzzerUtils.init(fArrFld, 1.518F);
      vSmallMeth_check_sum = 0L;
      iMeth_check_sum = 0L;
      fMeth_check_sum = 0L;
   }
}
