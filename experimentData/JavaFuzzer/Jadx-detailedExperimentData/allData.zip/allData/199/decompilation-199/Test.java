
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/199/original-199/Test.dex */
public class Test {
    public static long[][] lArrFld;
    public static long instanceCount = 1756888618;
    public static double dFld = 1.38551d;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long iMeth2_check_sum = 0;
    public short sFld = 2230;
    public boolean bFld = false;
    public volatile int iFld = 167;

    static {
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        lArrFld = jArr;
        FuzzerUtils.init(jArr, -14L);
        FuzzerUtils.init(fArrFld, -2.591f);
    }

    public static int iMeth2(int i, int i2, int i3) {
        int i4;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 55659);
        instanceCount >>= 62952;
        int i5 = i3 >> i3;
        int i6 = 64400;
        int i7 = 7;
        int i8 = i2;
        while (138 > i7) {
            int i9 = i7 + 1;
            try {
                i4 = iArr[i9] / (-224);
                try {
                    i8 = i7 / (-1009995685);
                    iArr[i7 - 1] = (-462777520) / i7;
                } catch (ArithmeticException e) {
                }
            } catch (ArithmeticException e2) {
                i4 = i7;
            }
            int i10 = i8 + i7;
            long j = instanceCount;
            i5 = i4 & ((int) j);
            if ((i7 % 1) + 122 == 122) {
                instanceCount = j + (i7 | (-57746));
                i6 = 1;
                do {
                    i5 <<= i10;
                    long[] jArr = lArrFld[i6 - 1];
                    jArr[i6] = jArr[i6] + instanceCount;
                    i6++;
                } while (i6 < 12);
            }
            i7 = i9;
            i8 = i10;
        }
        long checkSum = ((((i2 + i8) + i5) + i7) - 57746) + i6 + FuzzerUtils.checkSum(iArr);
        iMeth2_check_sum += checkSum;
        return (int) checkSum;
    }

    public static int iMeth1() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -35851);
        int i2 = -10;
        int i3 = -33704;
        int i4 = 11;
        int i5 = -9327;
        int i6 = 31460;
        int i7 = -37;
        int i8 = 12;
        while (i8 < 352) {
            i3 = i8;
            while (i3 < 5) {
                int i9 = i4;
                int i10 = i6;
                int i11 = i2;
                int i12 = i3;
                while (i12 < 1) {
                    try {
                        int i13 = i11 / iArr[i3];
                        i11 = i10 / (-37666);
                        i = i9 / iArr[i3 - 1];
                    } catch (ArithmeticException e) {
                        i = i11;
                    }
                    long j = instanceCount;
                    i9 = (int) (i9 + i12 + j);
                    instanceCount = j + (i12 - i12);
                    double iMeth2 = iMeth2(i3, i9, i9);
                    Double.isNaN(iMeth2);
                    i11 = ((int) (iMeth2 * (-1.16138d))) + i;
                    instanceCount |= i11;
                    i10 *= (int) (-1.16138d);
                    try {
                        i9 = iArr[i3 - 1] / i10;
                        i10 = i8 / 108;
                        i9 = i10 % i8;
                    } catch (ArithmeticException e2) {
                    }
                    i12++;
                    long[] jArr = lArrFld[i12];
                    jArr[i3] = jArr[i3] + i3;
                }
                instanceCount = i3;
                i3++;
                i2 = i11;
                i4 = i9;
                i5 = i12;
                i6 = i10;
                i7 = 2;
            }
            i8++;
        }
        long doubleToLongBits = i8 + i2 + i3 + i4 + i5 + i6 + Double.doubleToLongBits(-1.16138d) + i7 + 1 + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(10:5|6|18|48|19|20|23|52|45|3) */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0088, code lost:
        r5 = r19;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public int iMeth(int r19, byte r20, int r21) {
        /*
            Method dump skipped, instructions count: 344
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.iMeth(int, byte, int):int");
    }

    public void mainTest(String[] strArr) {
        boolean[] zArr;
        byte b;
        short[][] sArr;
        float f;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        short[][] sArr2 = (short[][]) Array.newInstance(short.class, N, N);
        boolean[] zArr2 = new boolean[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, 58);
        FuzzerUtils.init(bArr, (byte) -13);
        FuzzerUtils.init(sArr2, (short) -28163);
        FuzzerUtils.init(zArr2, false);
        FuzzerUtils.init(dArr, 56.48633d);
        int i7 = 105;
        int i8 = -62;
        int i9 = -129;
        int i10 = -233;
        int i11 = 71;
        int i12 = 8;
        int i13 = -34135;
        float f2 = 37.157f;
        byte b2 = 83;
        int i14 = 5;
        while (true) {
            int i15 = i12;
            if (i14 < 171) {
                iMeth(i14, (byte) 45, i14);
                switch ((i14 % 6) + 79) {
                    case 79:
                        int i16 = i9;
                        int i17 = i10;
                        int i18 = 15;
                        while (i18 < 302) {
                            if (((i14 >>> 1) % 1) + 37 == 37) {
                                int i19 = 2;
                                while (true) {
                                    i19--;
                                    if (i19 > 0) {
                                        int i20 = i13;
                                        instanceCount += this.iFld;
                                        if (this.bFld) {
                                            i16 += (int) dFld;
                                        }
                                        int i21 = i16;
                                        instanceCount = i21;
                                        i16 = i21;
                                        i13 = i20;
                                    } else {
                                        i6 = i13;
                                        i17 = i19;
                                    }
                                }
                            } else {
                                iArr[i14] = i7;
                                bArr[i14] = (byte) (bArr[i14] * ((byte) this.sFld));
                                i6 = i13;
                            }
                            int i22 = i16;
                            int i23 = i17;
                            long j = instanceCount * i14;
                            instanceCount = j;
                            sArr2[i14 - 1][i18] = (short) i22;
                            long j2 = i22;
                            i16 = ((int) (j2 + (((i18 * i14) + j) - j2))) + i14;
                            this.iFld *= (int) instanceCount;
                            i18++;
                            i17 = i23;
                            i13 = i6;
                            f2 = f2;
                            b2 = b2;
                        }
                        i3 = i13;
                        b = b2;
                        int i24 = 302;
                        while (true) {
                            double d = dFld;
                            int i25 = i24;
                            long j3 = instanceCount;
                            double d2 = j3;
                            Double.isNaN(d2);
                            double d3 = d + d2;
                            dFld = d3;
                            iArr[i25] = (int) j3;
                            double d4 = j3;
                            Double.isNaN(d4);
                            dFld = d3 + d4;
                            sArr = sArr2;
                            zArr = zArr2;
                            i7 = (int) (i7 + (((i25 * j3) + i14) - i17));
                            i18 = i18;
                            f2 += i18;
                            fArrFld[i25 + 1] = i17;
                            i24 = i25 - 3;
                            if (i24 > 0) {
                                sArr2 = sArr;
                                zArr2 = zArr;
                            } else {
                                char c = 3;
                                int i26 = 3;
                                while (i26 < 302) {
                                    int i27 = ((i18 >>> 1) % 2) + 125;
                                    if (i27 == 125) {
                                        zArr[c] = this.bFld;
                                        instanceCount = 43402L;
                                        i4 = i26;
                                        instanceCount = 43402 + (((i26 * i24) + i17) - 43402);
                                    } else if (i27 == 126) {
                                        i4 = i26;
                                    } else {
                                        iArr[i14 + 1] = iArr[i5] - 1;
                                        i4 = i26;
                                        i26 = i4 + 1;
                                        c = 3;
                                    }
                                    dArr[i14] = f2;
                                    i26 = i4 + 1;
                                    c = 3;
                                }
                                i8 = i18;
                                i11 = i24;
                                i9 = i16;
                                int i28 = i17;
                                i12 = i26;
                                i10 = i28;
                                double d5 = dFld;
                                double d6 = i14;
                                Double.isNaN(d6);
                                dFld = d5 * d6;
                                f2 = f2;
                                i13 = i3;
                                break;
                            }
                        }
                    case 80:
                    case 81:
                        zArr = zArr2;
                        i3 = i13;
                        b = b2;
                        i12 = i15;
                        sArr = sArr2;
                        double d52 = dFld;
                        double d62 = i14;
                        Double.isNaN(d62);
                        dFld = d52 * d62;
                        f2 = f2;
                        i13 = i3;
                        break;
                    case 82:
                        i13 += (int) f2;
                        zArr = zArr2;
                        b = b2;
                        i12 = i15;
                        i11 = i11;
                        sArr = sArr2;
                        break;
                    case 83:
                        int i29 = i11;
                        byte b3 = (byte) (b2 - ((byte) this.sFld));
                        sArr = sArr2;
                        zArr = zArr2;
                        b = b3;
                        i12 = i15;
                        i11 = i29;
                        break;
                    case 84:
                        i2 = i11;
                        instanceCount = i14;
                        zArr = zArr2;
                        i = i13;
                        f = f2;
                        b = b2;
                        sArr = sArr2;
                        i9 += i14 ^ i10;
                        i12 = i15;
                        i11 = i2;
                        i13 = i;
                        f2 = f;
                        break;
                    default:
                        zArr = zArr2;
                        i2 = i11;
                        i = i13;
                        f = f2;
                        b = b2;
                        sArr = sArr2;
                        i9 += i14 ^ i10;
                        i12 = i15;
                        i11 = i2;
                        i13 = i;
                        f2 = f;
                        break;
                }
                i14 += 2;
                sArr2 = sArr;
                b2 = b;
                zArr2 = zArr;
            } else {
                byte b4 = b2;
                short[][] sArr3 = sArr2;
                FuzzerUtils.out.println("i i1 i20 = " + i14 + "," + i7 + "," + i8);
                FuzzerUtils.out.println("i21 i22 i23 = " + i9 + "," + i10 + "," + i11);
                FuzzerUtils.out.println("f1 i24 i25 = " + Float.floatToIntBits(f2) + "," + i15 + "," + i13);
                FuzzerUtils.out.println("by1 iArr3 byArr = " + ((int) b4) + "," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(bArr));
                FuzzerUtils.out.println("sArr bArr dArr = " + FuzzerUtils.checkSum(sArr3) + "," + FuzzerUtils.checkSum(zArr2) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
                FuzzerUtils.out.println("Test.instanceCount sFld bFld = " + instanceCount + "," + ((int) this.sFld) + "," + (this.bFld ? 1 : 0));
                FuzzerUtils.out.println("Test.dFld iFld Test.lArrFld = " + Double.doubleToLongBits(dFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(lArrFld));
                FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
                FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
