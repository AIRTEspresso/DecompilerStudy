/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/152/original-152/Test.dex */
public class Test {
    public static int[] iArrFld;
    public volatile float fFld = 0.82f;
    public static volatile long instanceCount = 9;
    public static double dFld = 30.32936d;
    public static float fFld1 = -9.21f;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 156);
        FuzzerUtils.init(lArrFld, -10L);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void vMeth(boolean z, int i, float f) {
        float f2;
        int i2 = i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 4);
        int i3 = 3;
        if (z != 0) {
            if (z != 0) {
                float f3 = f;
                int i4 = 5;
                int i5 = 22656;
                float f4 = 1.108f;
                int i6 = 6;
                while (i6 < 204) {
                    i2 += i6;
                    int i7 = 1;
                    int i8 = 1;
                    while (true) {
                        i8 += 2;
                        if (i8 < 8) {
                            i2 = ((int) (i2 + (i8 ^ instanceCount))) + (i8 * i8);
                            dFld = 7257;
                        }
                    }
                    while (8 > i7) {
                        instanceCount = instanceCount;
                        float f5 = 1.0f;
                        while (f5 < 2.0f) {
                            dFld -= 40264.0d;
                            iArr[75] = iArr[75] - i8;
                            f3 = i8;
                            f5 += 1.0f;
                        }
                        i7++;
                        f4 = f5;
                    }
                    i6++;
                    i5 = i7;
                    i4 = i8;
                }
                vMeth_check_sum += ((((z + i2) + Float.floatToIntBits(f3)) + i6) - 94) + i4 + 7257 + i5 + 60951 + Float.floatToIntBits(f4) + 3 + FuzzerUtils.checkSum(iArr);
                return;
            } else if (z != 0) {
                f2 = f;
                i3 = 60951;
            } else if (z != 0) {
                f2 = i2;
            } else {
                instanceCount = -94;
                f2 = f;
            }
        } else {
            f2 = f;
            i2 *= (int) f2;
        }
        vMeth_check_sum += (((((z ? 1 : 0) + i2) + Float.floatToIntBits(f2)) + 2) - 94) + 5 + 7257 + 22656 + 60951 + Float.floatToIntBits(1.108f) + i3 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth1(int i, int i2, int i3) {
        vMeth(false, i, fFld1);
        instanceCount = 153L;
        int i4 = -4;
        int i5 = -3;
        int i6 = 7;
        int i7 = -149;
        int i8 = 8;
        while (143 > i8) {
            i4 -= i8;
            int i9 = 1;
            while (i9 < 12) {
                i3 += (int) instanceCount;
                i9++;
            }
            int i10 = 1;
            while (true) {
                i10++;
                if (i10 < 12) {
                    instanceCount = i9;
                    iArrFld[i10] = -9;
                    i7 = 1;
                }
            }
            i8++;
            i5 = i9;
            i6 = i10;
        }
        long j = ((((((((((i + i2) + i3) + 0) + i8) + i4) + i5) - 9) + i6) + i7) - 14409) + 1598912768;
        iMeth1_check_sum += j;
        return (int) j;
    }

    public int iMeth(long j, int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -8);
        int i2 = 1;
        do {
            i -= Integer.reverseBytes(i - 1);
            switch ((i2 % 6) + 115) {
                case 115:
                    i *= iMeth1(-195, i2, i2) + 208;
                case 116:
                case 117:
                    fFld1 = -3.0f;
                    if (((i2 >>> 1) % 1) + 111 == 111) {
                        dFld -= -22231.0d;
                        iArrFld[i2 + 1] = (int) instanceCount;
                        j += (i2 * i2) + 6;
                    }
                    this.fFld = 99.0f;
                    i <<= -23804;
                    break;
                case 118:
                    this.fFld += ((i2 * i2) + i2) - i;
                    break;
                case 119:
                    this.fFld = (float) instanceCount;
                    break;
                default:
                    instanceCount = i;
                    break;
            }
            i2++;
        } while (i2 < 303);
        long checkSum = (((j + i) + i2) - 23804) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr;
        short[] sArr = new short[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(sArr, (short) -28031);
        FuzzerUtils.init(fArr, -2.988f);
        int i2 = -40545;
        int i3 = -7;
        short s = -15580;
        int i4 = 12;
        while (true) {
            i = 0;
            if (i4 >= 194) {
                break;
            }
            i3 = 5;
            while (138 > i3) {
                this.fFld *= iMeth(instanceCount, 0);
                s = (short) (s % (-10));
                i3++;
            }
            i4++;
            i2 = i3;
        }
        iArrFld[0] = (int) instanceCount;
        long[] jArr = lArrFld;
        int i5 = (i2 >>> 1) % N;
        jArr[i5] = jArr[i5] - i3;
        iArrFld[(i3 >>> 1) % N] = -61103;
        int i6 = ((int) instanceCount) | (-61103);
        int i7 = 17;
        int i8 = 19375;
        int i9 = 83;
        int i10 = 58164;
        int i11 = -22017;
        double d = 97.15975d;
        while (i7 < 293) {
            int i12 = 1;
            while (true) {
                i6 += (int) ((i12 * i12) + 4529079815672162736L);
                i12++;
                if (i12 >= 91) {
                    break;
                }
            }
            double d2 = 1.0d;
            while (d2 < 91.0d) {
                short s2 = s;
                this.fFld += i6;
                int i13 = i7 + 1;
                sArr[i13] = (short) i12;
                i8 += 2;
                int i14 = (int) d2;
                int i15 = i + i14;
                int i16 = i12;
                int i17 = ((i7 % 6) * 5) + 126;
                if (i17 == 134) {
                    iArrFld[i7] = iArr[i7] - 52042;
                } else {
                    if (i17 == 137) {
                        i8 <<= i4;
                        i10 = (int) dFld;
                    } else if (i17 != 154) {
                        if (i17 == 144) {
                            fFld1 -= i10;
                        } else if (i17 == 145) {
                            fArr[i14] = fArr[i14] + fFld1;
                            instanceCount += (long) d2;
                            i11 <<= i7;
                        }
                    }
                    int[] iArr2 = iArrFld;
                    iArr2[i13] = iArr2[i13] * i6;
                }
                d2 += 1.0d;
                i = i15;
                s = s2;
                i12 = i16;
            }
            i7++;
            d = d2;
            i9 = i12;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i4 + "," + i6 + "," + i3);
        FuzzerUtils.out.println("i3 s3 i23 = " + i + "," + ((int) s) + "," + i7);
        FuzzerUtils.out.println("i24 i25 d = " + i8 + "," + i9 + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i26 b2 i27 = " + i10 + ",0," + i11);
        FuzzerUtils.out.println("sArr fArr = " + FuzzerUtils.checkSum(sArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fFld1 Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(fFld1) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
