
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/142/original-142/Test.dex */
public class Test {
    public static double[] dArrFld;
    public static long instanceCount = 3594617949L;
    public static volatile short sFld = 9772;
    public static volatile byte byFld = -22;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public int iFld = -3;
    public float fFld = 0.124f;
    public boolean bFld = false;

    static {
        double[] dArr = new double[N];
        dArrFld = dArr;
        FuzzerUtils.init(dArr, 0.98955d);
        FuzzerUtils.init(iArrFld, 13);
    }

    public int iMeth(int i) {
        int i2 = i + 1;
        int i3 = -193;
        int i4 = -119;
        int i5 = -9715;
        byte b = 108;
        long j = -14;
        int i6 = 19;
        while (i6 < 398) {
            i4 = 1;
            while (i4 < 4) {
                this.iFld = (int) instanceCount;
                i5 = 1;
                while (i5 < 4) {
                    dArrFld[i5] = -111.65f;
                    long j2 = instanceCount;
                    instanceCount = j2 * j2;
                    i5++;
                }
                long j3 = instanceCount;
                long j4 = j3 - j3;
                instanceCount = j4;
                b = (byte) j4;
                i3 = i4 * 21168;
                j = (j - i5) + ((i4 * i4) - 26549);
                i4 += 2;
            }
            i6++;
        }
        long floatToIntBits = ((((i2 + i6) + i3) + i4) - 12) + i5 + ((int) (-111.65f)) + Float.floatToIntBits(-111.65f) + b + j;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void vMeth1(float f, int i) {
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -68.326f);
        FuzzerUtils.init(jArr, 1591523943L);
        fArr[(this.iFld >>> 1) % N] = (float) (-2.65346d);
        int i2 = 9;
        while (i2 < 148) {
            i2++;
        }
        int i3 = 15;
        int i4 = 5;
        long j = 112483535;
        while (i3 < 257) {
            i4 = 1;
            do {
                j = 1;
                i4++;
            } while (i4 < 7);
            i3++;
        }
        vMeth1_check_sum += ((((Float.floatToIntBits(f) + i) + Double.doubleToLongBits(-2.65346d)) + i2) - 174) + i3 + 4 + i4 + j + 9 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr);
    }

    public void vMeth(double d, long j, double d2) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 2918919998L);
        FuzzerUtils.init(iArr, 7);
        int i = 139;
        while (true) {
            i--;
            if (i <= 0) {
                break;
            }
            int i2 = this.iFld;
            int i3 = (int) (i + jArr[i]);
            this.iFld = i3;
            this.iFld = i2 + i3;
            vMeth1(this.fFld, i);
            int i4 = this.iFld + (i ^ 98);
            this.iFld = i4;
            int i5 = i4 >>> i;
            this.iFld = i5;
            this.iFld = i5 << sFld;
        }
        int i6 = -226;
        int i7 = 94;
        int i8 = 5457;
        int i9 = 2;
        while (i9 < 348) {
            i6 = 1;
            while (i6 < 5) {
                int i10 = this.iFld + ((int) instanceCount);
                this.iFld = i10;
                i7 >>= i10;
                i6++;
                i8 = 2;
            }
            i9++;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + j + Double.doubleToLongBits(d2) + i + 98 + i9 + 58 + i6 + i7 + i8 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int[] iArr;
        int[][] iArr2 = (int[][]) Array.newInstance(int.class, N, N);
        int[] iArr3 = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr2, -193);
        FuzzerUtils.init(jArr, 2527083260L);
        FuzzerUtils.init(iArr3, 5);
        vMeth(-1.115433d, instanceCount, -1.115433d);
        int i3 = this.iFld;
        double d = i3;
        int i4 = i3 * 142;
        this.iFld = i4;
        int[] iArr4 = iArr2[(i4 >>> 1) % N];
        int i5 = (i4 >>> 1) % N;
        iArr4[i5] = iArr4[i5] + 2;
        int i6 = (i4 >>> 1) % N;
        jArr[i6] = jArr[i6] >>> ((int) instanceCount);
        int i7 = -231;
        int i8 = -239;
        int i9 = 79;
        int i10 = -72;
        int i11 = -41365;
        int i12 = 11;
        int i13 = 0;
        for (int i14 = N; i13 < i14; i14 = N) {
            int i15 = iArr3[i13];
            sFld = (short) this.iFld;
            long j = instanceCount;
            int i16 = (int) j;
            this.iFld = i16;
            long[] jArr2 = jArr;
            iArr3[(i16 >>> 1) % i14] = i16;
            int[] iArr5 = iArrFld;
            int i17 = (((int) j) >>> 1) % i14;
            iArr5[i17] = iArr5[i17] * ((int) j);
            int i18 = 1;
            while (true) {
                int i19 = this.iFld;
                int i20 = i18 - 1;
                iArr2[i20][i20] = i18;
                this.fFld -= (float) instanceCount;
                this.bFld = this.bFld;
                this.iFld = i19 - ((int) d);
                i = 1;
                i18++;
                if (i18 >= 63) {
                    break;
                }
            }
            i8 = 63;
            while (true) {
                i2 = 3;
                if (i8 <= i) {
                    iArr = iArr3;
                    break;
                }
                i9 = i8;
                while (i9 < 3) {
                    i9++;
                }
                iArr = iArr3;
                instanceCount += sFld;
                if (this.bFld) {
                    break;
                }
                i8 -= 2;
                iArr3 = iArr;
                i = 1;
            }
            iArr2[37][0] = i18;
            boolean z = this.bFld;
            if (z) {
                while (i2 < 63) {
                    i10 >>= i10;
                    this.fFld = byFld;
                    instanceCount += i18;
                    i2++;
                }
                i11 = i2;
            } else if (z) {
                i10 /= 88;
            } else {
                i12 >>= (int) instanceCount;
            }
            i13++;
            i7 = i18;
            jArr = jArr2;
            iArr3 = iArr;
        }
        FuzzerUtils.out.println("d3 i21 i22 = " + Double.doubleToLongBits(d) + "," + i7 + "," + i8);
        FuzzerUtils.out.println("i23 i24 i25 = 74," + i9 + "," + i10);
        FuzzerUtils.out.println("i26 i27 iArr1 = " + i11 + "," + i12 + "," + FuzzerUtils.checkSum(iArr2));
        FuzzerUtils.out.println("lArr2 iArr2 = " + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr3));
        FuzzerUtils.out.println("Test.instanceCount iFld fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.sFld bFld Test.byFld = " + ((int) sFld) + "," + (this.bFld ? 1 : 0) + "," + ((int) byFld));
        FuzzerUtils.out.println("Test.dArrFld Test.iArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
