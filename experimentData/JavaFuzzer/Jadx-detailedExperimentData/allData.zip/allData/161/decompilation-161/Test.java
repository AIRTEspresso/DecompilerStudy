
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/161/original-161/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public boolean[][] bArrFld = (boolean[][]) Array.newInstance(boolean.class, N, N);
    public static long instanceCount = -3479512115273054217L;
    public static volatile short sFld = 7380;
    public static float fFld = 1.146f;
    public static boolean bFld = false;
    public static byte byFld = -60;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, -3705431464775492841L);
    }

    public static void vMeth() {
        long[] jArr;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 40232);
        int i = (int) instanceCount;
        int i2 = -60145;
        int i3 = -19194;
        int i4 = 8;
        byte b = -98;
        for (long j : lArrFld) {
            long j2 = instanceCount;
            int i5 = (int) j2;
            int i6 = (i5 >>> 1) % N;
            iArr[i6] = (int) j2;
            iArr[i6] = iArr[i6] - i;
            i2 = i5;
            i3 = 1;
            while (i3 < 4) {
                b = (byte) i3;
                i4 = i3 - 252;
                i2 = (-89) - ((int) fFld);
                int i7 = i3;
                i3++;
                i = i7;
            }
        }
        vMeth_check_sum += i + i2 + i3 + i4 + b + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth1(int i) {
        int i2 = 11177;
        int i3 = -138;
        short s = -53;
        long j = 4;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 < 325) {
                float f = fFld - 1.0f;
                fFld = f;
                vMeth();
                i = ((i - ((int) (i4 + (f + (i * i4))))) | (-5)) - ((int) instanceCount);
                bFld = false;
                j = 5;
                while (j > 1) {
                    i2 = 58;
                    i3 = 1;
                    while (i3 < 5) {
                        i3++;
                    }
                    fFld = i;
                    s = sFld;
                    j -= 3;
                }
            } else {
                long j2 = i + i4 + j + i2 + i3 + s;
                iMeth1_check_sum += j2;
                return (int) j2;
            }
        }
    }

    public static int iMeth() {
        int i;
        int i2 = 1;
        do {
            iMeth1(i2);
            i = 1;
            do {
                i++;
            } while (i < 7);
            i2++;
        } while (i2 < 221);
        long doubleToLongBits = (((i2 + i) + 1) - 8245) + Double.doubleToLongBits(2.5068d);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, 26369);
        int i3 = -8627;
        long iMeth = instanceCount << (((sFld - (-8627)) + 0) + iMeth());
        instanceCount = iMeth;
        int[] iArr2 = iArr[134];
        iArr2[381] = iArr2[381] >> ((int) iMeth);
        int i4 = -106;
        int i5 = 47758;
        int i6 = -59;
        int i7 = 53087;
        int i8 = 11387;
        double d = -9.3033d;
        int i9 = 7;
        while (i9 < 171) {
            int i10 = (int) d;
            boolean z = bFld;
            if (z) {
                this.bArrFld[i9][i9 + 1] = z;
                fFld *= i9;
            }
            int i11 = 7;
            while (153 > i11) {
                instanceCount |= -37278;
                iArr[i11][i9 + 1] = i6;
                i11++;
            }
            int i12 = (i9 % 2) + 53;
            if (i12 == 53) {
                instanceCount -= i10;
                try {
                    i2 = i6 % (-244);
                    int i13 = i9 - 1;
                    try {
                        i = (iArr[i13][i13] % (-146)) / (-37733);
                    } catch (ArithmeticException e) {
                        i = i2;
                        i6 = (int) instanceCount;
                        i10 = i;
                        i4 = i10;
                        i9++;
                        int i14 = i11;
                        i3 = i10;
                        i5 = i14;
                    }
                } catch (ArithmeticException e2) {
                    i2 = i10;
                }
                i6 = (int) instanceCount;
                i10 = i;
                i4 = i10;
            } else if (i12 == 54) {
                fFld += i9 * i9;
                i4 = i10;
            } else {
                int i15 = i10 << i10;
                int i16 = i9;
                while (153 > i16) {
                    int i17 = (i16 % 2) + 80;
                    if (i17 == 80 || i17 == 81) {
                        int i18 = i16 + 1;
                        int[] iArr3 = iArr[i18];
                        iArr3[i18] = iArr3[i18] >>> i9;
                        i10 -= i11;
                        d = i16;
                    }
                    i6 = i10;
                    i16++;
                    i8 = 1;
                    i10 = i6;
                    i15 = -183;
                }
                i4 = i15;
                i7 = i16;
            }
            i9++;
            int i142 = i11;
            i3 = i10;
            i5 = i142;
        }
        FuzzerUtils.out.println("i i13 i14 = " + i3 + "," + i9 + "," + i4);
        FuzzerUtils.out.println("d1 i15 i16 = " + Double.doubleToLongBits(d) + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i17 i18 i19 = " + i7 + ",-183," + i8);
        FuzzerUtils.out.println("i20 l3 iArr1 = 57,-11," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + ((int) sFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.byFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + ((int) byFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("bArrFld = " + FuzzerUtils.checkSum(this.bArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
