
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/151/original-151/Test.dex */
public class Test {
    public static int[] iArrFld;
    public static long instanceCount = -708077500915325689L;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static long dMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public int iFld = 27606;
    public double[] dArrFld = new double[N];

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 68);
        FuzzerUtils.init(lArrFld, 39896L);
    }

    public static long lMeth(long j, int i) {
        long j2 = j + i + ((short) (-4));
        lMeth_check_sum += j2;
        return j2;
    }

    public static void vMeth(double d, int i) {
        int[] iArr;
        float[] fArr = new float[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(fArr, 66.836f);
        zArr[(i >>> 1) % N] = ((float) i) == fArr[18];
        for (int i2 : iArrFld) {
            int[] iArr2 = iArrFld;
            int i3 = (i2 >>> 1) % N;
            iArr2[i3] = iArr2[i3] + i;
        }
        long j = -1;
        int lMeth = (-21888) | ((int) (iArrFld[(int) 0] + 1479690261 + (-(j - 1)) + (lMeth(1L, 134) - (-1))));
        int[] iArr3 = iArrFld;
        int i4 = (int) 2;
        iArr3[i4] = iArr3[i4] * (-1);
        vMeth_check_sum += Double.doubleToLongBits(d) + (-1) + ((int) 1) + Float.floatToIntBits(0.68f) + 134 + j + 1 + lMeth + FuzzerUtils.checkSum(zArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static double dMeth(long j, int i) {
        long j2;
        int i2 = 3;
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) 164L);
        vMeth(71.91273d, i);
        int i3 = i << ((int) instanceCount);
        int i4 = -6;
        int i5 = -69;
        byte b = 27;
        while (i2 < 321) {
            i4 = 1;
            while (i4 < 5) {
                i3 *= (int) j;
                b = (byte) i3;
                i5 <<= 205;
                iArrFld[i2] = i5;
                instanceCount += (i4 * i4) + 119;
                i4++;
            }
            i2++;
        }
        long[][] jArr2 = jArr[343];
        int i6 = (i3 >>> 1) % N;
        long j3 = i4;
        jArr2[i6][i6] = j3;
        instanceCount = 14L;
        long doubleToLongBits = ((((j + j3) + Double.doubleToLongBits(71.91273d)) + j2) - 210) + j3 + i2 + ((byte) (b - ((byte) i2))) + FuzzerUtils.checkSum((Object[][]) jArr);
        dMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        double d;
        int i;
        int[] iArr;
        int i2;
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr2, -7868);
        int i3 = 1;
        int i4 = -9;
        int i5 = 5243;
        int i6 = -157;
        double d2 = 0.23301d;
        double d3 = -1.45981d;
        float f = 2.405f;
        short s = -10275;
        int i7 = 1;
        int i8 = 0;
        int i9 = 0;
        while (true) {
            i7 += i3;
            if (i7 >= 250) {
                FuzzerUtils.out.println("i i1 i2 = " + i7 + "," + i4 + "," + i8);
                FuzzerUtils.out.println("d i3 d1 = " + Double.doubleToLongBits(d2) + "," + i9 + "," + Double.doubleToLongBits(d3));
                FuzzerUtils.out.println("f s1 b = " + Float.floatToIntBits(f) + "," + ((int) s) + ",0");
                FuzzerUtils.out.println("i15 by1 i16 = " + i5 + ",-39," + i6);
                FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(iArr2));
                FuzzerUtils.out.println("Test.instanceCount iFld Test.iArrFld = " + instanceCount + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("Test.lArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
                return;
            }
            double d4 = d2;
            double d5 = d3;
            float f2 = f;
            short s2 = s;
            int i10 = 101;
            while (i10 > i7) {
                d4 = 1.0d;
                f2 += (float) instanceCount;
                double d6 = s2;
                Double.isNaN(d6);
                d5 += d6;
                i9 = (i9 >> i7) + (i10 * i10) + 248;
                instanceCount = 2L;
                s2 = (short) (s2 + ((short) i10));
                i10 -= 3;
            }
            iArrFld[i7 - 1] = (int) instanceCount;
            int i11 = i7 + 1;
            iArr2[i11] = iArr2[i11] / ((int) (((long) d4) | 1));
            int i12 = 1;
            while (true) {
                double[] dArr = this.dArrFld;
                double d7 = dArr[i7];
                d = d4;
                i = i10;
                long j = instanceCount;
                iArr = iArr2;
                double d8 = j;
                Double.isNaN(d8);
                dArr[i7] = d7 - d8;
                i8 -= -39;
                int i13 = this.iFld & i9;
                this.iFld = i13;
                i9 >>= (int) j;
                int i14 = i13 - ((int) j);
                this.iFld = i14;
                this.iFld = i14 - ((int) d5);
                i2 = i12 + 1;
                if (i2 >= 101) {
                    break;
                }
                i12 = i2;
                i10 = i;
                d4 = d;
                iArr2 = iArr;
            }
            i5 = i2;
            i4 = i;
            s = s2;
            f = f2;
            iArr2 = iArr;
            i3 = 1;
            i6 = 2;
            d3 = d5;
            d2 = d;
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
