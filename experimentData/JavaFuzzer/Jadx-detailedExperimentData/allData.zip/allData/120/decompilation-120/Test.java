
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/120/original-120/Test.dex */
public class Test {
    public int iFld = 99;
    public static volatile long instanceCount = -55718;
    public static float fFld = 0.585f;
    public static boolean bFld = false;
    public static long lFld = -49429;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static volatile float[] fArrFld = new float[N];
    public static long vMeth_check_sum = 0;
    public static long byMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        FuzzerUtils.init(lArrFld, 2000137365L);
        FuzzerUtils.init(fArrFld, -1.951f);
    }

    public static void vMeth1(int i) {
        instanceCount <<= i;
        int i2 = 7;
        int i3 = -3;
        int i4 = -7;
        int i5 = 9;
        int i6 = 2;
        while (i2 < 125) {
            i3 = 1;
            while (i3 < 13) {
                fFld = 21115;
                i3++;
            }
            int i7 = 1;
            while (13 > i7) {
                i5 = 1;
                while (i5 < 2) {
                    i -= i5;
                    long[] jArr = lArrFld;
                    int i8 = i7 + 1;
                    jArr[i8] = jArr[i8] - 78;
                    if ((i2 % 1) + 25 == 25) {
                        i = 82;
                    }
                    if (i3 != 0) {
                        vMeth1_check_sum += ((((((((i + i2) + 21115) + i3) + 1929) + i7) + i4) + i5) - 6) + 1;
                        return;
                    }
                    instanceCount += i5;
                    instanceCount = i7;
                    i5 += 2;
                }
                i7++;
            }
            i4 = -69;
            i2++;
            i6 = i7;
        }
        vMeth1_check_sum += ((((((((i + i2) + 21115) + i3) + 1929) + i6) + i4) + i5) - 6) + 1;
    }

    public static byte byMeth(long j, int i, int i2) {
        int i3 = -2;
        byte b = -51;
        double d = 0.32039d;
        int i4 = 19;
        int i5 = 1;
        while (i4 < 319) {
            vMeth1(-11);
            b = (byte) i4;
            if (bFld) {
                break;
            }
            i3 = 1;
            while (true) {
                i3++;
                if (i3 < 6) {
                    float f = fFld;
                    fFld = f + f;
                    lArrFld[i3] = 0;
                    i5 -= 29489;
                    double d2 = i3;
                    Double.isNaN(d2);
                    d *= d2;
                }
            }
            i4++;
        }
        long doubleToLongBits = j + i + i2 + i4 + i5 + b + i3 + Double.doubleToLongBits(d);
        byMeth_check_sum += doubleToLongBits;
        return (byte) doubleToLongBits;
    }

    public static void vMeth(int i) {
        byte b;
        byMeth(instanceCount, i, i);
        int i2 = -4653;
        int i3 = 12;
        while (i3 < 245) {
            i2 = (i2 >>> (-38783)) << i3;
            i = (i + 0) << ((int) instanceCount);
            i3++;
        }
        int i4 = -49763;
        int i5 = 1;
        while (true) {
            i5++;
            b = 64;
            if (i5 >= 194) {
                break;
            }
            i4 = 1;
            while (i4 < 8) {
                try {
                    lFld >>= i5;
                    fFld += i4;
                    float[] fArr = fArrFld;
                    int i6 = i4 + 1;
                    fArr[i6] = fArr[i6] + i;
                    long[] jArr = lArrFld;
                    jArr[i4] = jArr[i4] - ((long) (-108.37499d));
                    i4 = i6;
                } catch (ArithmeticException e) {
                    b = (byte) (64 - ((byte) i));
                }
            }
        }
        vMeth_check_sum += i + i3 + i2 + i5 + i4 + 13 + Double.doubleToLongBits(-108.37499d) + b;
    }

    public void mainTest(String[] strArr) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, -61212);
        int i = this.iFld;
        int[] iArr2 = iArr[(i >>> 1) % N];
        int i2 = (i >>> 1) % N;
        int i3 = iArr2[i2];
        long[] jArr = lArrFld;
        int i4 = (i >>> 1) % N;
        long j = jArr[i4];
        jArr[i4] = j - 1;
        iArr2[i2] = i3 << ((int) Math.abs(j));
        vMeth(this.iFld);
        int i5 = this.iFld;
        int[] iArr3 = iArr[(i5 >>> 1) % N];
        int i6 = (i5 >>> 1) % N;
        iArr3[i6] = iArr3[i6] * (-3);
        this.iFld = i5 >> i5;
        FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.lFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + lFld + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
