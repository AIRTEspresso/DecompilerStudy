
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/111/original-111/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1318088676;
    public static double dFld = 0.87392d;
    public static boolean bFld = false;
    public static short sFld = -420;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    public static int iMeth1(double d) {
        long j;
        long j2;
        double[] dArr = new double[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(dArr, -8.89364d);
        FuzzerUtils.init(jArr, -3489466803L);
        int i = 1;
        do {
            i++;
            double d2 = dArr[i];
            j = instanceCount;
            double d3 = j;
            Double.isNaN(d3);
            dArr[i] = d2 - d3;
        } while (i < 130);
        int i2 = (i >>> 1) % N;
        double d4 = dArr[i2];
        double d5 = j;
        Double.isNaN(d5);
        dArr[i2] = d4 - d5;
        int i3 = 14;
        int i4 = -2;
        while (236 > i3) {
            long j3 = i3 * instanceCount;
            long j4 = i;
            int i5 = (int) ((i4 - ((int) j2)) + ((j3 + j4) - j4));
            d += 136.0d;
            i4 = (i5 - i5) + (i3 * i3) + 8796;
            i3++;
            jArr[i3] = jArr[i3] - 53770;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + i + i3 + i4 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, -101);
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(dArr, 6.59892d);
        int i = 4;
        while (i < 283) {
            instanceCount += i;
            boolean z = bFld;
            i++;
        }
        long floatToIntBits = ((((i + 10) + 245) - 65) - 64298) + Float.floatToIntBits(0.1013f) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(zArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(long j) {
        int i;
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        byte[][][] bArr = (byte[][][]) Array.newInstance(byte.class, N, N, N);
        double[] dArr = new double[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) 10);
        FuzzerUtils.init((Object[][]) bArr, (Object) (byte) -100);
        FuzzerUtils.init(dArr, 40.70373d);
        long j2 = j;
        int i2 = 154;
        while (i2 > 4) {
            int i3 = i2 - 1;
            int i4 = i2 + 1;
            int[] iArr2 = iArr[i3][i4];
            long iMeth = iMeth();
            iArr2[i4] = (int) iMeth;
            sFld = (short) (sFld + ((short) instanceCount));
            byte[] bArr2 = bArr[i2][i4];
            bArr2[i3] = (byte) (bArr2[i3] >> 72);
            i2--;
            j2 = iMeth;
        }
        int i5 = -195;
        int i6 = 32067;
        int i7 = -6;
        int i8 = -14;
        int i9 = 1;
        while (i9 < 284) {
            int i10 = i6;
            int i11 = i9;
            while (true) {
                i = 6;
                if (6 > i11) {
                    i10 |= (int) instanceCount;
                    i11++;
                }
            }
            do {
                i--;
            } while (i > 0);
            i9++;
            i7 = i;
            i6 = i10;
            i8 = 1;
            i5 = i11;
        }
        vMeth_check_sum += ((((((((((j2 + i2) + 210) + 72) + i9) - 7) + i5) + i6) + i7) + i8) - 60534) + Float.floatToIntBits(-121.456f) + FuzzerUtils.checkSum((Object[][]) iArr) + FuzzerUtils.checkSum((Object[][]) bArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        float[] fArr = new float[N];
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        byte[] bArr = new byte[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -29);
        FuzzerUtils.init(bArr, (byte) -8);
        FuzzerUtils.init(fArr, 32.335f);
        FuzzerUtils.init(jArr, -5L);
        vMeth(instanceCount);
        float f = ((float) dFld) * (-1.733f);
        int[] iArr2 = iArr[2];
        iArr2[2] = iArr2[2] >> 4;
        sFld = (short) (sFld * ((short) 4));
        int i4 = 4 << ((int) instanceCount);
        int i5 = -55476;
        try {
            bArr[84] = -107;
            i2 = 9;
            i = 197;
        } catch (UserDefinedExceptionTest e) {
            int i6 = 1;
            while (true) {
                long j = instanceCount + i4;
                instanceCount = j;
                long j2 = j + i6 + i6;
                instanceCount = j2;
                short s = sFld;
                instanceCount = j2 >> s;
                i3 = i6 + 1;
                int[] iArr3 = iArr[i3];
                iArr3[i3] = iArr3[i3] >>> i6;
                int i7 = i6 - 1;
                int[] iArr4 = iArr[i7];
                iArr4[i6] = iArr4[i6] >> i4;
                fArr[i6] = fArr[i6] * s;
                i = 204;
                while (i > i6) {
                    long j3 = instanceCount;
                    i4 -= (int) j3;
                    int[] iArr5 = iArr[i];
                    iArr5[i6] = iArr5[i6] % (-127);
                    jArr[i7] = j3;
                    i5 |= -42;
                    if (bFld) {
                        break;
                    }
                    i--;
                }
                if (i3 >= 123) {
                    break;
                }
                i6 = i3;
            }
            i2 = i3;
        }
        FuzzerUtils.out.println("f2 i17 i18 = " + Float.floatToIntBits(f) + "," + i4 + "," + i2);
        FuzzerUtils.out.println("i19 i20 i21 = -163," + i5 + "," + i);
        FuzzerUtils.out.println("i22 iArr2 byArr1 = -128," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("fArr lArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld = " + ((int) sFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
