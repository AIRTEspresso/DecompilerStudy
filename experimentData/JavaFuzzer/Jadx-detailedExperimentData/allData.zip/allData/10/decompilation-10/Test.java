
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/10/original-10/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3446703931L;
    public static byte byFld = -2;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long fMeth_check_sum = 0;

    public static float fMeth(double d, int i) {
        int i2;
        int i3 = -99;
        int i4 = -1;
        int i5 = -153;
        short s = -191;
        float f = 0.884f;
        short s2 = 28365;
        int i6 = 4;
        while (true) {
            i2 = 1;
            if (i6 < 124) {
                i4 = 1;
                while (i4 < 13) {
                    instanceCount -= i4;
                    i5 = i6;
                    while (i5 < 2) {
                        instanceCount *= -4424;
                        i3 -= (int) f;
                        i5++;
                        s = s2;
                        i = -11861;
                    }
                    f += i6;
                    i4++;
                }
                double d2 = f;
                Double.isNaN(d2);
                d += d2;
                s2 = (short) (s2 - ((short) i3));
                i6++;
            }
        }
        while (i2 < 294) {
            d = i;
            f *= (float) instanceCount;
            i2++;
        }
        long doubleToLongBits = (((((Double.doubleToLongBits(d) + i) + i6) + i3) + i4) - 11861) + i5 + s + Float.floatToIntBits(f) + s2 + i2 + 12;
        fMeth_check_sum += doubleToLongBits;
        return (float) doubleToLongBits;
    }

    public static void vMeth1(int i, long j) {
        double[] dArr = new double[N];
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init(dArr, -111.25194d);
        FuzzerUtils.init(fArr, 1.344f);
        FuzzerUtils.init(iArr, 13);
        FuzzerUtils.init((Object[][]) jArr, (Object) 7L);
        short fMeth = (short) (23800 - ((short) (fMeth(0.122986d, -14) * i)));
        dArr[(i >>> 1) % N] = -13.0d;
        int i2 = 2;
        while (i2 < 239) {
            fArr[i2 + 1] = -1.0f;
            i2++;
        }
        vMeth1_check_sum += i + j + fMeth + Double.doubleToLongBits(0.122986d) + 1 + i2 + 181 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum((Object[][]) jArr);
    }

    public static void vMeth(int i, int i2) {
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 13);
        int i3 = i ^ i;
        vMeth1(-64855, instanceCount);
        vMeth_check_sum += (((i3 + (i2 ^ ((i2 - (i2 - i2)) * i3))) + 2) - 12) + 39 + 0 + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void mainTest(String[] strArr) {
        vMeth(5, -365956900);
        FuzzerUtils.out.println("i = 55");
        FuzzerUtils.out.println("Test.instanceCount Test.byFld = " + instanceCount + "," + ((int) byFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
