
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/182/original-182/Test.dex */
public class Test {
    public static short[] sArrFld;
    public static long instanceCount = 254;
    public static float fFld = -2.83f;
    public static double dFld = 8.102582d;
    public static volatile float fFld1 = -126.86f;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public volatile int iFld = 26;
    public boolean bFld = true;

    static {
        short[] sArr = new short[N];
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) 9775);
        FuzzerUtils.init(iArrFld, -51588);
    }

    public static void vMeth1() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 18877);
        int i = 3;
        int i2 = 95;
        int i3 = 111;
        int i4 = -232;
        int i5 = 12;
        while (i < 167) {
            i3 = i;
            while (i3 < 10) {
                int i6 = i4 + 83;
                try {
                    int i7 = i2 % (-87);
                    i6 = 1;
                } catch (ArithmeticException e) {
                }
                instanceCount = 235L;
                int i8 = i3 - 1;
                iArr[i8] = iArr[i8] + i;
                instanceCount = 235 & 63032;
                fFld += i;
                fFld = i6 * i3;
                i5 = 2;
                int i9 = i3 + 1;
                iArr[i9] = iArr[i9] >> 20184;
                i3 += 3;
                i2 = i;
                i4 = i2;
            }
            i++;
        }
        vMeth1_check_sum += i + i2 + i3 + i4 + i5 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(int i, long j, int i2) {
        short[] sArr;
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 2.921f);
        for (short s : sArrFld) {
            vMeth1();
            j |= j;
            try {
                int i3 = i / i;
                i2 = (iArrFld[47] / (-82044512)) / iArrFld[(i >>> 1) % N];
            } catch (ArithmeticException e) {
            }
            iArrFld[(i >>> 1) % N] = (int) dFld;
        }
        vMeth_check_sum += ((((i + j) + i2) + 0) - 8) + 4 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static float fMeth(long j, long j2, int i) {
        int i2 = 4;
        while (i2 < 170) {
            vMeth(64278, instanceCount, i);
            i += i2;
            i2++;
        }
        float f = 7.0f;
        int i3 = 52935;
        byte b = -7;
        while (135.0f > f) {
            i3 *= b;
            b = (byte) i;
            instanceCount = -7;
            f += 1.0f;
        }
        long floatToIntBits = ((((((j + j2) + i) + i2) + i3) + Float.floatToIntBits(f)) - 7) + b;
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        double[][][] dArr = (double[][][]) Array.newInstance(double.class, N, N, N);
        FuzzerUtils.init(jArr, 2806961701L);
        FuzzerUtils.init(fArr, -83.532f);
        FuzzerUtils.init((Object[][]) dArr, (Object) Double.valueOf(0.32342d));
        int i3 = 44;
        byte b = 44;
        int i4 = 45277;
        int i5 = 4;
        int i6 = -32626;
        int i7 = -33329;
        int i8 = 223;
        int i9 = 51;
        int i10 = -9;
        int i11 = 7;
        float f = -72.251f;
        int i12 = 142;
        while (true) {
            byte b2 = b;
            int i13 = i11;
            if (i12 > 5) {
                int i14 = i12 + 1;
                float f2 = 1.0f + f;
                long j = instanceCount + 1;
                instanceCount = j;
                int i15 = i9;
                int i16 = i8;
                int fMeth = (int) fMeth(j, -13L, -17554);
                jArr[i14] = f + ((float) j) + fMeth;
                byte b3 = b2;
                int i17 = i7;
                i11 = i13;
                i10 = i10;
                int i18 = i6;
                int i19 = i5;
                int i20 = 183;
                while (i20 > 2) {
                    int i21 = i12;
                    instanceCount += i20;
                    int i22 = ((i21 >>> 1) % 2) + 118;
                    if (i22 == 118) {
                        i = 1;
                        i19 = 1;
                        while (i19 < 2) {
                            fMeth += ((i19 * fMeth) + i20) - i21;
                            i19++;
                            i18 = i17;
                        }
                        while (2 > i) {
                            int[] iArr = iArrFld;
                            int i23 = i20 + 1;
                            iArr[i23] = iArr[i23] - i19;
                            i18 += i * i;
                            i15 *= (int) instanceCount;
                            this.iFld ^= i21;
                            int[] iArr2 = iArrFld;
                            iArr2[i14] = iArr2[i14] - this.iFld;
                            this.iFld = (int) f2;
                            boolean z = this.bFld;
                            if (z) {
                                fArr[i20] = fArr[i20] + fFld;
                                i15 = i19;
                                if (z) {
                                    i17 = -8;
                                    i++;
                                } else {
                                    i2 = -8;
                                }
                            } else {
                                i2 = this.iFld * (-8);
                            }
                            instanceCount += 20908;
                            i17 = i2;
                            i++;
                        }
                        i10 = i21;
                        while (i10 < 2) {
                            int[] iArr3 = iArrFld;
                            int i24 = i21 - 1;
                            iArr3[i24] = iArr3[i24] ^ (-32025);
                            double[] dArr2 = dArr[i24][i14];
                            dArr2[i21] = dArr2[i21] * (-96.0d);
                            instanceCount = instanceCount;
                            instanceCount = -250;
                            i10++;
                            i11 = i18;
                        }
                    } else if (i22 != 119) {
                        i20--;
                        i12 = i21;
                    } else {
                        i = i16;
                    }
                    i16 = i;
                    b3 = (byte) i;
                    i20--;
                    i12 = i21;
                }
                i12--;
                f = f2;
                b = b3;
                i4 = i20;
                i5 = i19;
                i6 = i18;
                i3 = fMeth;
                i7 = i17;
                i9 = i15;
                i8 = i16;
            } else {
                FuzzerUtils.out.println("i i1 f = " + i12 + "," + i3 + "," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("i15 i16 i17 = " + i4 + ",-250," + i5);
                FuzzerUtils.out.println("i18 i19 i20 = " + i6 + "," + i7 + "," + i8);
                FuzzerUtils.out.println("i21 i22 i23 = " + i9 + ",-8," + i10);
                FuzzerUtils.out.println("i24 by1 lArr = " + i13 + "," + ((int) b2) + "," + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("fArr1 dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) dArr)));
                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
                FuzzerUtils.out.println("Test.fFld1 iFld bFld = " + Float.floatToIntBits(fFld1) + "," + this.iFld + "," + (this.bFld ? 1 : 0));
                FuzzerUtils.out.println("Test.sArrFld Test.iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
