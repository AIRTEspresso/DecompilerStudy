/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/139/original-139/Test.dex */
public class Test {
    public static final int N = 400;
    public static short[] sArrFld;
    public static long instanceCount = -8651291483224068383L;
    public static volatile int iFld = 208;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public short sFld = 1909;
    public int[] iArrFld = new int[N];

    static {
        short[] sArr = new short[N];
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) 13224);
    }

    public static void vMeth(long j, double d) {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 0);
        int i2 = iFld;
        iFld = iFld >>> 17;
        iFld = i2 - ((int) (j - (i - (-iArr[381]))));
        vMeth_check_sum += j + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth1(int i, int i2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 47014);
        short[] sArr = sArrFld;
        int i3 = (i >>> 1) % N;
        sArr[i3] = (short) (sArr[i3] * ((short) (((iFld + 3788) - Math.abs(14)) - 127)));
        vMeth(instanceCount, -127.106268d);
        int i4 = (iFld >>> 1) % N;
        iArr[i4] = iArr[i4] >> iFld;
        int i5 = i >>> (-8108);
        int i6 = 6;
        int i7 = -34128;
        int i8 = -220;
        long j = 5;
        while (j < 332) {
            int i9 = (int) j;
            int i10 = i8;
            int i11 = i9;
            while (i11 < 5) {
                try {
                    i5 = i11 % iFld;
                    i10 = i2 % i11;
                    i5 = iArr[i9] / (-939022363);
                } catch (ArithmeticException e) {
                }
                iArr[i11] = i10;
                i6 *= iFld;
                iArr[i9] = iArr[i9] + iFld;
                i11++;
            }
            j++;
            i7 = i11;
            i8 = i10;
        }
        float f = -2.165f;
        int i12 = 1;
        while (true) {
            i12++;
            if (i12 < 373) {
                f += i2;
                i2 += (int) f;
                iFld = -6;
            } else {
                long floatToIntBits = i5 + i2 + j + i6 + i7 + i8 + 1 + i12 + Float.floatToIntBits(f) + FuzzerUtils.checkSum(iArr);
                iMeth1_check_sum += floatToIntBits;
                return (int) floatToIntBits;
            }
        }
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -6405);
        float f = 38.733f;
        iFld = (int) (iMeth1(iFld, iFld) * 38.733f);
        int i = -32929;
        int i2 = 13;
        int i3 = 27508;
        int i4 = 89;
        byte b = 18;
        int i5 = 0;
        while (i5 < 400) {
            int i6 = iArr[i5];
            instanceCount = iFld;
            float f2 = i6;
            int i7 = (((i6 >>> 1) % 2) * 5) + 90;
            if (i7 == 98) {
                i = 1;
                while (4 > i) {
                    i3 = 1;
                    while (i3 < 2) {
                        iFld -= i3;
                        switch ((i3 % 5) + 97) {
                            case 97:
                                iArr[i] = iArr[i] * ((int) f2);
                                b = (byte) (b >>> ((byte) i2));
                                i2 = i3;
                                break;
                            case 99:
                                iFld = (int) instanceCount;
                                break;
                            case 100:
                                try {
                                    i2 = iFld % 356175627;
                                    int i8 = iFld % 199;
                                    iArr[i + 1] = iFld % (-4448);
                                    break;
                                } catch (ArithmeticException e) {
                                    break;
                                }
                            case 101:
                                i2 += iFld;
                                break;
                        }
                        i3++;
                    }
                    i++;
                }
            } else if (i7 == 100) {
                i4 += 177;
            }
            i5++;
            f = f2;
        }
        long floatToIntBits = Float.floatToIntBits(f) + i + i2 + i3 + i4 + b + 1 + 7711 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        double[] dArr;
        FuzzerUtils.init(new double[N], -96.81267d);
        double d = 2.18213d;
        vMeth(iMeth() * iFld, 2.18213d);
        int i = (iFld >>> 1) % 1;
        iFld = 10070;
        int i2 = 12;
        int i3 = 2;
        int i4 = -116;
        int i5 = -51794;
        int i6 = 25092;
        int i7 = 11;
        int i8 = -93;
        float f = -2.267f;
        int i9 = 2;
        while (298 > i2) {
            i5 = 1;
            while (i5 < 88) {
                f -= 90.0f;
                i6 *= i5;
                i7 = 1;
                while (i7 < i3) {
                    instanceCount = 200L;
                    if (((i5 % 1) * 5) + 105 == 108) {
                        i6 += i7;
                    } else {
                        instanceCount = 200L;
                        short[] sArr = sArrFld;
                        sArr[i7] = (short) (sArr[i7] * ((short) i7));
                        i4 -= 13;
                    }
                    long j = i7;
                    instanceCount = j;
                    instanceCount = j;
                    iFld = (int) (iFld + (j ^ instanceCount));
                    int[] iArr = this.iArrFld;
                    i7++;
                    iArr[i7] = iArr[i7] + iFld;
                    this.sFld = (short) -7;
                    i4 = i4;
                    i3 = 2;
                }
                this.iArrFld[i5 - 1] = i5;
                i8 = 1;
                while (2 > i8) {
                    instanceCount = -87L;
                    int i10 = (int) f;
                    this.sFld = (short) (this.sFld - ((short) i10));
                    i6 += i10;
                    f += ((i8 * i6) + 2) - iFld;
                    d *= d;
                    instanceCount -= 4;
                    i9 = i8;
                    i8++;
                }
                i5++;
                i3 = 2;
            }
            i2++;
            i3 = 2;
        }
        FuzzerUtils.out.println("d1 i11 i12 = " + Double.doubleToLongBits(d) + "," + i2 + "," + i4);
        FuzzerUtils.out.println("i13 i14 f2 = " + i5 + "," + i6 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i15 i16 by1 = " + i7 + "," + i9 + ",13");
        FuzzerUtils.out.println("i17 i18 dArr = " + i8 + ",2," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + ((int) this.sFld));
        FuzzerUtils.out.println("Test.sArrFld iArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
