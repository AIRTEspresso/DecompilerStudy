
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/110/original-110/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 3510175330L;
    public static double dFld = -1.90633d;
    public static int iFld = 151;
    public static boolean bFld = true;
    public static float fFld = -1.903f;
    public static int iFld1 = -98;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long byMeth_check_sum = 0;
    public float[] fArrFld = new float[N];
    public double[] dArrFld = new double[N];

    public static byte byMeth(long j) {
        float[] fArr;
        int[] iArr = new int[N];
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        float[][] fArr2 = (float[][]) Array.newInstance(float.class, N, N);
        FuzzerUtils.init(iArr, -90);
        FuzzerUtils.init(dArr, -116.38173d);
        FuzzerUtils.init(fArr2, 0.695f);
        int i = -8;
        int i2 = 134;
        int i3 = 6;
        int i4 = 7;
        int i5 = 1;
        while (i4 < 383) {
            int i6 = i4 + 1;
            iArr[i6] = i4;
            iArr[i6] = 1708639143;
            if (!bFld) {
                double[] dArr2 = dArr[i4 - 1];
                dArr2[i4] = dArr2[i4] - dFld;
                iArr[i6] = iArr[i6] * iFld;
                i = 1;
                while (i < 13) {
                    fArr2[i][i6] = fArr[i6] - 96.24669f;
                    int i7 = iFld;
                    i5 *= i7;
                    iFld = i7 + (i * i7);
                    dFld -= 6.0d;
                    int i8 = 1;
                    while (2 > i8) {
                        instanceCount = 11L;
                        fFld -= 12.0f;
                        i8++;
                    }
                    i++;
                    i3 = i8;
                    i2 = 119;
                }
            }
            i4 += 3;
        }
        long checkSum = i4 + j + i5 + i + i2 + i3 + 25681 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr2));
        byMeth_check_sum += checkSum;
        return (byte) checkSum;
    }

    public static void vMeth1() {
        int i = 3;
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        double[] dArr = new double[N];
        boolean[][][] zArr = (boolean[][][]) Array.newInstance(boolean.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 189);
        FuzzerUtils.init(dArr, -1.38009d);
        FuzzerUtils.init((Object[][]) zArr, (Object) true);
        int i2 = iFld;
        int byMeth = i2 - (byMeth(instanceCount) + i2);
        iFld = byMeth;
        long j = byMeth;
        instanceCount = j;
        int[] iArr2 = iArr[(byMeth >>> 1) % N][(byMeth >>> 1) % N];
        int i3 = (byMeth >>> 1) % N;
        iArr2[i3] = iArr2[i3] * byMeth;
        int i4 = 18301;
        int i5 = 242;
        try {
            dFld = -65.86675d;
            iFld = byMeth - 18301;
            fFld *= (float) j;
            i = 6;
        } catch (ArrayIndexOutOfBoundsException e) {
            while (i < 366) {
                if (!bFld) {
                    iFld /= 58217;
                    int i6 = 1;
                    while (i6 < 5 && !bFld) {
                        dArr[i6 - 1] = dFld;
                        int i7 = i + 1;
                        zArr[i7][i7][i6] = false;
                        i4 >>= 90;
                        i6++;
                    }
                    i5 = i6;
                }
                i++;
            }
        }
        vMeth1_check_sum += ((((i4 + i) + 90) + i5) - 10) + FuzzerUtils.checkSum((Object[][]) iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum((Object[][]) zArr);
    }

    public static void vMeth(int i) {
        int i2;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 22851);
        FuzzerUtils.init(jArr, -1L);
        int i3 = 88;
        int i4 = -127;
        int i5 = 63718;
        byte b = -23;
        if (!bFld) {
            i2 = 5;
        } else {
            i2 = 8;
            while (i2 < 395) {
                instanceCount = i2;
                int i6 = i3 + 1;
                byte b2 = (byte) (b >> ((byte) i6));
                vMeth1();
                int i7 = 1;
                do {
                    iFld |= i6;
                    int i8 = i2 - 1;
                    jArr[i8] = jArr[i8] & instanceCount;
                    i7++;
                } while (i7 < 4);
                i2++;
                i4 = i7;
                i3 = i6;
                b = b2;
                i5 = 1;
            }
        }
        vMeth_check_sum += ((((((i + i2) + i3) + b) + i4) + i5) - 36655) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public void mainTest(String[] strArr) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        long[] jArr = new long[N];
        int i = 8;
        FuzzerUtils.init(iArr, 8);
        FuzzerUtils.init(jArr, -47807L);
        float[] fArr = this.fArrFld;
        double d = 65017;
        double[] dArr = this.dArrFld;
        double d2 = dArr[108] - 1.0d;
        dArr[108] = d2;
        Double.isNaN(d);
        double d3 = d - d2;
        double d4 = 65016;
        Double.isNaN(d4);
        fArr[108] = (float) (d3 * d4);
        while (i < 268) {
            double d5 = dFld + 1.0d;
            dFld = d5;
            instanceCount = (-56804) - (75 + (26507 % (((long) d5) | 1)));
            i++;
        }
        vMeth(-59020);
        jArr[64] = jArr[64] - instanceCount;
        FuzzerUtils.out.println("i i1 i2 = 65016," + i + ",72");
        FuzzerUtils.out.println("by1 i20 i21 = " + ((int) ((byte) (-179))) + ",0,61824");
        FuzzerUtils.out.println("i22 i23 i24 = 1,17987,-179");
        FuzzerUtils.out.println("i25 i26 i27 = 35156,128,7");
        FuzzerUtils.out.println("i28 s iArr3 = -182,17318," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + iFld);
        FuzzerUtils.out.println("Test.bFld Test.fFld Test.iFld1 = " + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld) + "," + iFld1);
        FuzzerUtils.out.println("fArrFld dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
