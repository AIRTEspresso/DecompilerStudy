/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/117/original-117/Test.dex */
public class Test {
    public static int[] iArrFld;
    public static long instanceCount = 49988;
    public static int iFld = 14104;
    public static int iFld1 = -127;
    public static final int N = 400;
    public static short[] sArrFld = new short[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 105);
        FuzzerUtils.init(sArrFld, (short) 20522);
    }

    public static void vMeth2() {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 65.871f);
        FuzzerUtils.init(iArr, -49);
        int i = 9;
        int i2 = -4;
        int i3 = 4;
        float f = 73.164f;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 < 276) {
                iFld = 50789;
                fArr[i4] = fArr[i4] + 50789;
                iFld = 50789;
                iFld = 737250344;
                iArr[i4] = 214;
                iFld = i4;
                i = 1;
                while (i < 6) {
                    long j = iFld1;
                    instanceCount = j;
                    i++;
                    iArr[i] = iArr[i] * ((int) j);
                    if ((i4 % 1) + 109 == 109) {
                        iFld = (int) j;
                        i2 = 1;
                        while (i2 < 2) {
                            f = 2656.0f;
                            iFld |= -6;
                            i2++;
                        }
                    } else {
                        i3 += (int) f;
                    }
                }
            } else {
                vMeth2_check_sum += ((i4 + i) - 6) + i2 + i3 + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vMeth1() {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 29352);
        FuzzerUtils.init(jArr, 1661686759729466649L);
        vMeth2();
        vMeth1_check_sum += (((((8 + Float.floatToIntBits(-1.2f)) + 1) + 6) + 1) - 41464) + 19521 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i, int i2) {
        short[] sArr = new short[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(sArr, (short) 31517);
        FuzzerUtils.init(jArr, -8434740146338999967L);
        vMeth1();
        int i3 = 368;
        while (5 < i3) {
            int i4 = iFld1 ^ (-6);
            iFld1 = i4;
            iFld1 = i4 >> i;
            int i5 = i3 + 1;
            short s = sArr[i5];
            long j = instanceCount;
            sArr[i5] = (short) (s | ((short) j));
            instanceCount = j + i2;
            i3 -= 2;
        }
        int i6 = iFld1;
        int i7 = (i6 >>> 1) % N;
        jArr[i7] = jArr[i7] >>> i6;
        double d = i2;
        iArrFld = iArrFld;
        int i8 = 4;
        int i9 = 29118;
        int i10 = 199;
        while (i8 < 341) {
            int i11 = i10;
            int i12 = 1;
            while (i12 < 5) {
                i11 = 2;
                while (i11 > 1) {
                    iFld = 88;
                    i = (int) instanceCount;
                    i11--;
                }
                i12++;
            }
            i8++;
            i9 = i12;
            i10 = i11;
        }
        vMeth_check_sum += ((((((i + i2) + i3) - 1) + Double.doubleToLongBits(d)) + i8) - 177) + i9 + 88 + i10 + 51039 + FuzzerUtils.checkSum(sArr) + FuzzerUtils.checkSum(jArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -44435L);
        vMeth(iFld, 0);
        int i2 = 9;
        while (true) {
            i = -7;
            if (i2 >= 365) {
                break;
            }
            int i3 = iFld1;
            iFld1 = i3 << i3;
            long j = instanceCount;
            int i4 = iFld;
            instanceCount = j + (i2 | i4);
            long j2 = -7;
            instanceCount = j2;
            iFld1 = i4;
            instanceCount = j2 - i2;
            i2++;
        }
        iFld1 = i2;
        int i5 = (i2 >>> 1) % N;
        jArr[i5] = jArr[i5] * (-7);
        jArr[i5] = jArr[i5] * i2;
        int i6 = 10;
        int i7 = -253;
        int i8 = -12685;
        int i9 = 19835;
        float f = 0.687f;
        byte b = -46;
        int i10 = 118;
        int i11 = 374;
        while (i11 > 22) {
            int i12 = i6;
            int i13 = i;
            int i14 = 5;
            while (true) {
                if (i14 >= 214) {
                    break;
                }
                int i15 = i12;
                int i16 = i8;
                int i17 = i14;
                for (int i18 = 2; i17 < i18; i18 = 2) {
                    long j3 = instanceCount + (((i17 * i11) + i14) - iFld1);
                    instanceCount = j3;
                    iArrFld[i11] = (int) j3;
                    iFld1 = i14;
                    i15 += i17 - i15;
                    int i19 = (int) j3;
                    iFld1 = i19;
                    instanceCount = i19;
                    long j4 = iFld;
                    instanceCount = j4;
                    instanceCount = j4 + (((i17 * j4) + j4) - j4);
                    i16 *= i16;
                    i17++;
                    f = f;
                }
                float f2 = f;
                instanceCount += i13;
                try {
                    iFld = iArrFld[i14] % 48513;
                    i13 = -207;
                    iArrFld[i14 - 1] = (-24542) % i16;
                } catch (ArithmeticException e) {
                }
                f = f2 + (((i14 * i16) + i13) - 3933);
                i14++;
                i12 = i15;
                i7 = i17;
                i8 = i16;
            }
            float f3 = f;
            i9 = 6;
            while (i9 < 214) {
                b = (byte) (b * ((byte) i13));
                short[] sArr = sArrFld;
                int i20 = i9 - 1;
                sArr[i20] = (short) (sArr[i20] >>> ((short) iFld1));
                i9++;
                i8 = 2;
            }
            i11 -= 3;
            f = f3;
            int i21 = i13;
            i6 = i12;
            i10 = i14;
            i = i21;
        }
        FuzzerUtils.out.println("i20 i21 b1 = " + i2 + "," + i + ",0");
        FuzzerUtils.out.println("i22 i23 i24 = " + i11 + ",-4396," + i10);
        FuzzerUtils.out.println("i25 i26 i27 = " + i6 + "," + i7 + "," + i8);
        FuzzerUtils.out.println("f2 s i28 = " + Float.floatToIntBits(f) + ",3933," + i9);
        FuzzerUtils.out.println("i29 by lArr2 = 247," + ((int) b) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.iFld1 = " + instanceCount + "," + iFld + "," + iFld1);
        FuzzerUtils.out.println("Test.iArrFld Test.sArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
