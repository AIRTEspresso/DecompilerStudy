/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/195/original-195/Test.dex */
public class Test {
    public static final int N = 400;
    public float[] fArrFld = new float[N];
    public static long instanceCount = 4;
    public static long lMeth_check_sum = 0;
    public static long dMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    public static void vMeth(int i, int i2) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 4319310807116406889L);
        FuzzerUtils.init(fArr, 87.964f);
        FuzzerUtils.init(iArr, -6);
        int i3 = i2;
        long j = -5;
        int i4 = -165;
        int i5 = 102;
        int i6 = 17;
        while (true) {
            float f = -86.678f;
            if (i6 < 283) {
                jArr[i6 - 1] = i4;
                i3 += ((i6 * i) + i3) - i6;
                long j2 = instanceCount;
                i4 += (int) j2;
                long j3 = -86.678f;
                instanceCount = j2 + j3;
                i5 = 1;
                while (i5 < 6) {
                    long j4 = 1;
                    while (j4 < 2) {
                        int i7 = (int) j4;
                        iArr[i7] = iArr[i7] * 227;
                        int i8 = (int) f;
                        long j5 = j4;
                        i3 = i8 + ((int) (((i8 * j4) + i4) - (-109)));
                        instanceCount = -3955237631L;
                        i4 += (int) (j5 | j3);
                        j4 = j5 + 1;
                        f = -86.678f;
                    }
                    i5++;
                    j = j4;
                    f = -86.678f;
                }
                i6++;
            } else {
                vMeth_check_sum += ((((((((((i + i3) + i6) + i4) + Float.floatToIntBits(-86.678f)) + i5) + 227) + j) + 9076) + 0) - 109) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static double dMeth(int i, float f) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -60316);
        vMeth(i, i);
        int i2 = (i >>> 1) % N;
        iArr[i2] = iArr[i2] >>> (-14);
        int i3 = -185;
        int i4 = 65202;
        int i5 = -12;
        byte b = 97;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 < 275) {
                i3 = 1;
                while (6 > i3) {
                    i4 = i3;
                    while (i4 < 2) {
                        long j = instanceCount;
                        i <<= (int) j;
                        int i7 = ((i4 % 7) * 5) + 60;
                        if (i7 == 66) {
                            iArr[i4 + 1] = b;
                        } else if (i7 != 67) {
                            if (i7 != 74) {
                                if (i7 == 78) {
                                    b = (byte) (b + ((byte) (((i4 * b) - 14) - j)));
                                } else if (i7 == 83) {
                                    i5 -= i6;
                                } else if (i7 == 86) {
                                    int i8 = i + (i4 * i4);
                                    i = i8 - i8;
                                } else if (i7 != 92) {
                                }
                            }
                            b = 39;
                        } else {
                            instanceCount = j >> i4;
                        }
                        i4++;
                    }
                    i3++;
                }
            } else {
                long floatToIntBits = ((((i + Float.floatToIntBits(f)) + i6) + i3) - 14) + i4 + i5 + b + FuzzerUtils.checkSum(iArr);
                dMeth_check_sum += floatToIntBits;
                return floatToIntBits;
            }
        }
    }

    public long lMeth(int i) {
        dMeth(i, 20.951f);
        instanceCount = 0L;
        this.fArrFld = this.fArrFld;
        long floatToIntBits = i + Float.floatToIntBits(20.951f);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        double d;
        double d2 = 158;
        double d3 = (211 >> ((int) instanceCount)) | 1;
        Double.isNaN(d3);
        Double.isNaN(d2);
        double d4 = d2 + (5.72502d / d3);
        Double.isNaN(211 + (lMeth(-26) - 3953315401L));
        FuzzerUtils.out.println("i by i16 = " + (211 - ((int) (d4 * d))) + ",53,-26");
        FuzzerUtils.out.println("Test.instanceCount fArrFld = " + instanceCount + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
