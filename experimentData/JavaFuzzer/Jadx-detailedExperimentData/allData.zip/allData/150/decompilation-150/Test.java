
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/150/original-150/Test.dex */
public class Test {
    public double[] dArrFld = new double[N];
    public static long instanceCount = -44818;
    public static boolean bFld = true;
    public static float fFld = 1.6f;
    public static short sFld = 13796;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static float[] fArrFld = new float[N];
    public static volatile long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, -22462);
        FuzzerUtils.init(fArrFld, 0.5f);
        FuzzerUtils.init(lArrFld, -26182552L);
    }

    public static void vMeth(int i, int i2, long j) {
        int[] iArr;
        long[] jArr;
        long[][][] jArr2 = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr2, (Object) (-159L));
        float f = 0.462f;
        int i3 = (int) 0.462f;
        int i4 = i - i3;
        instanceCount = j;
        int i5 = i4 >>> 1;
        long[][] jArr3 = jArr2[i5 % N];
        int i6 = (i2 >>> 1) % N;
        jArr3[i6][i6] = 0.462f;
        int i7 = ((i5 % 7) * 5) + 72;
        double d = 0.70422d;
        if (i7 == 73) {
            fArrFld[46] = -27677;
        } else if (i7 == 74) {
            f = 0.462f * i4;
            bFld = bFld;
        } else if (i7 == 86) {
            double d2 = 0.462f;
            Double.isNaN(d2);
            d = 0.70422d * d2;
        } else {
            if (i7 != 89) {
                if (i7 == 94) {
                    f = 0.462f * i4;
                } else if (i7 == 98) {
                    iArrFld[364] = i2;
                    int i8 = 1;
                    do {
                        iArr = iArrFld;
                        iArrFld = iArr;
                        i8++;
                    } while (i8 < 5);
                    instanceCount += j;
                    iArr[364] = iArr[364] - ((int) j);
                    vMeth_check_sum += ((((((((i4 + 364) + i2) + j) + Float.floatToIntBits(0.462f)) + 364) + i8) + Double.doubleToLongBits(0.70422d)) - 27677) + FuzzerUtils.checkSum((Object[][]) jArr2);
                    return;
                } else if (i7 != 99) {
                    jArr2[i6][46][46] = jArr[46] - 3;
                }
            }
            i2 = i3;
        }
        vMeth_check_sum += (((((((i4 + i2) + j) + Float.floatToIntBits(f)) - 6076) - 3) + Double.doubleToLongBits(d)) - 27677) + FuzzerUtils.checkSum((Object[][]) jArr2);
    }

    public static int iMeth1(int i) {
        int i2;
        int[] iArr;
        int i3;
        double[] dArr = new double[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(dArr, 2.124942d);
        FuzzerUtils.init(jArr, 3202827185623507262L);
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 >= 132) {
                break;
            }
            vMeth(i, i4, instanceCount);
        }
        int i5 = (i >>> 1) % N;
        double d = dArr[i5];
        double d2 = i;
        Double.isNaN(d2);
        dArr[i5] = d - d2;
        long j = instanceCount;
        instanceCount = j + j;
        int i6 = 176;
        while (true) {
            i2 = 7;
            if (i6 <= 7) {
                break;
            }
            jArr[i6 - 1] = i6;
            i6--;
        }
        double d3 = -137;
        Double.isNaN(d3);
        double d4 = (-1.18361d) + d3;
        int i7 = (-137) + i4;
        int i8 = 258;
        float f = -2.967f;
        int i9 = 1;
        while (i8 > 13) {
            i9 = 1;
            while (i9 < i2) {
                f += ((i9 * 59447) - 8378) - i8;
                iArrFld[i9 - 1] = iArr[i3] - 8378;
                i9++;
            }
            long j2 = instanceCount;
            i7 = (int) (i7 + (i8 ^ j2));
            f += (float) j2;
            i8--;
            i4 = i4;
            i2 = 7;
        }
        long doubleToLongBits = ((((((((((i + i4) + i6) + i7) + Double.doubleToLongBits(d4)) + i8) + 8) + i9) + 59447) + Float.floatToIntBits(f)) - 8378) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public int iMeth(int i, int i2) {
        int i3 = 13705;
        int i4 = 35010;
        int i5 = 0;
        int i6 = 362;
        int i7 = -1;
        while (true) {
            i6--;
            if (i6 <= 0) {
                long j = i + i2 + i6 + i7 + i3 + i4 + i5;
                iMeth_check_sum += j;
                return (int) j;
            }
            int i8 = 1;
            while (i8 < 5) {
                switch (((i3 >>> 1) % 6) + 13) {
                    case 13:
                        int[] iArr = iArrFld;
                        int i9 = i6 - 1;
                        iArr[i9] = iArr[i9] - iMeth1(i8);
                        long[] jArr = lArrFld;
                        long j2 = jArr[i9];
                        long j3 = instanceCount;
                        jArr[i9] = j2 >> ((int) j3);
                        i3 = (int) (i3 + (((i8 * i8) + j3) - j3));
                        i4 = 1;
                        while (i4 < 2) {
                            i5 ^= i5;
                            instanceCount += (i4 * i4) - 67;
                            int i10 = i4 + 1;
                            iArrFld[i10] = i8;
                            i += i4;
                            i2 += i6;
                            i4 = i10;
                        }
                        break;
                    case 14:
                        i += 60;
                        break;
                    case 15:
                        i5 >>= i8;
                    case 16:
                        instanceCount += 253;
                        break;
                    case 17:
                        double[] dArr = this.dArrFld;
                        int i11 = i6 - 1;
                        double d = dArr[i11];
                        double d2 = i2;
                        Double.isNaN(d2);
                        dArr[i11] = d + d2;
                        break;
                    case 18:
                        instanceCount = i3;
                        break;
                }
                i8++;
            }
            i7 = i8;
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(iArr, -63);
        FuzzerUtils.init(zArr, true);
        int i = -10916;
        int i2 = -1;
        int i3 = -113;
        double d = 0.57251d;
        int i4 = 7;
        while (i4 < 341) {
            instanceCount += i4 * i4;
            i += i4 - i;
            iArr = FuzzerUtils.int1array(N, -29189);
            i2 = i4;
            while (i2 < 75) {
                i = iMeth(i4, i3);
                i3 /= i | 1;
                d += 4.0d;
                fFld += i2;
                int[] iArr2 = iArrFld;
                iArr2[i4] = iArr2[i4] - i2;
                i2 += 2;
            }
            i4++;
        }
        byte b = -52;
        int i5 = 1;
        while (true) {
            instanceCount = instanceCount;
            zArr[i5] = bFld;
            long j = i2;
            instanceCount = j;
            i += i;
            fFld = (float) d;
            sFld = (short) j;
            b = (byte) (b - ((byte) j));
            i5++;
            if (i5 >= 325) {
                break;
            }
        }
        int i6 = 123;
        int i7 = -118;
        int i8 = 35168;
        int i9 = i;
        int i10 = 3;
        while (122 > i10) {
            float f = fFld;
            float f2 = i3;
            fFld = f + (((i10 * f) + f2) - f2);
            fFld = f2;
            i7 = i10;
            while (i7 < 211) {
                int[] iArr3 = iArrFld;
                iArr3[i10] = i6;
                i8 = (int) (i8 + (((i7 * i7) + i10) - fFld));
                int i11 = i10 + 1;
                iArr3[i11] = iArr3[i11] - i6;
                long j2 = i8;
                instanceCount = j2;
                instanceCount = j2 - j2;
                i7++;
                i6 = 123;
            }
            i9 = i10;
            i10++;
            i3 = 123;
            i6 = 123;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i4 + "," + i9 + "," + i2);
        FuzzerUtils.out.println("i3 d3 i24 = " + i3 + "," + Double.doubleToLongBits(d) + "," + i5);
        FuzzerUtils.out.println("by i25 i26 = " + ((int) b) + "," + i10 + ",123");
        FuzzerUtils.out.println("i27 i28 iArr = " + i7 + "," + i8 + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.sFld Test.iArrFld Test.fArrFld = " + ((int) sFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.lArrFld dArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
