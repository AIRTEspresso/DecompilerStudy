/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/126/original-126/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public short sFld = -15762;
    public static volatile long instanceCount = -3;
    public static double dFld = -85.81815d;
    public static byte byFld = 86;
    public static float fFld = 117.644f;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 26433);
    }

    public static int iMeth(int i, int i2, int i3) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 2916952361270809038L);
        byte b = (byte) (((byte) i2) * 110);
        int i4 = i3;
        double d = 28.83515d;
        int i5 = -141;
        int i6 = 42;
        int i7 = 35442;
        int i8 = 7;
        while (true) {
            int i9 = 2;
            if (i8 < 179) {
                instanceCount = i5;
                double d2 = d;
                int i10 = i7;
                int i11 = 1;
                while (i11 < 9) {
                    i10 = 1;
                    while (i10 < i9) {
                        instanceCount += i10 - i5;
                        i10++;
                        i9 = 2;
                    }
                    iArrFld[i11] = (int) instanceCount;
                    i11++;
                    jArr[i11] = jArr[i11] + 5;
                    double d3 = i8;
                    Double.isNaN(d3);
                    d2 *= d3;
                    i4 += 127;
                    i5 = -10467;
                    i9 = 2;
                }
                i8++;
                i6 = i11;
                i7 = i10;
                d = d2;
            } else {
                instanceCount = instanceCount;
                instanceCount = i4;
                long doubleToLongBits = ((((((((((i + i2) + i4) + b) + i8) + i5) + i6) + (48336 >> i)) + i7) + 2) - 10467) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(jArr);
                iMeth_check_sum += doubleToLongBits;
                return (int) doubleToLongBits;
            }
        }
    }

    public static void vMeth1(int i, short s, int i2) {
        int i3;
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(fArr, 57.381f);
        FuzzerUtils.init(jArr, -32798L);
        int i4 = (((((-42015) & i) >>> 1) % 6) * 5) + 97;
        int i5 = 74;
        int i6 = -1;
        int i7 = -21;
        byte b = -121;
        float f = -120.945f;
        if (i4 == 112) {
            int i8 = (i2 >>> 1) % N;
            int i9 = i + 1;
            fArr[i8] = fArr[i8] - Math.abs(i * iMeth(i9, i2, -54914));
            int i10 = 1;
            do {
                i9 += i2;
                instanceCount = i2;
                i2 += (i10 * i10) + 31466;
                i3 = 1;
                while (i3 < 7) {
                    b = (byte) (b << b);
                    i7 = i3;
                    while (i7 < 2) {
                        double d = dFld;
                        dFld = d;
                        int i11 = (i10 % 2) + 104;
                        if (i11 == 104) {
                            double d2 = i10;
                            Double.isNaN(d2);
                            double d3 = d + d2;
                            dFld = d3;
                            dFld = d3 - (-202.0d);
                            i9 = b;
                        } else if (i11 == 105) {
                            f += i7 * i7;
                        }
                        i7++;
                    }
                    i3++;
                }
                i10++;
            } while (i10 < 243);
            i5 = i10;
            i6 = i3;
            i = i9;
        } else {
            if (i4 == 115) {
                instanceCount *= i2;
            } else if (i4 != 123) {
                switch (i4) {
                    case 101:
                        i2 = (int) instanceCount;
                        break;
                    case 102:
                        i -= (int) (-120.945f);
                        break;
                }
            }
            vMeth1_check_sum += (((((((((i + s) + i2) + i5) + i6) + 184) + b) + 0) + i7) - 18597) + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr);
        }
        double d4 = dFld;
        double d5 = i2;
        Double.isNaN(d5);
        dFld = d4 * d5;
        vMeth1_check_sum += (((((((((i + s) + i2) + i5) + i6) + 184) + b) + 0) + i7) - 18597) + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i) {
        int i2 = 7;
        while (i2 < 227) {
            vMeth1(i2, (short) -11532, 62033);
            i2 += 3;
        }
        vMeth_check_sum += ((((i + i2) + 62033) + 5) - 135) + 117;
    }

    public void mainTest(String[] strArr) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 54201L);
        int i = 38;
        int i2 = 45019;
        float f = -92.67f;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 < 323) {
                i = 4;
                while (i < 78) {
                    vMeth(13350);
                    i2 += i;
                    f = 2.0f;
                    i++;
                }
            } else {
                FuzzerUtils.out.println("i i1 i2 = " + i3 + "," + i + "," + i2);
                FuzzerUtils.out.println("f1 b1 s2 = " + Float.floatToIntBits(f) + ",1,-16563");
                FuzzerUtils.out.println("i25 lArr2 = 6176," + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + ((int) byFld));
                FuzzerUtils.out.println("Test.fFld sFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + ((int) this.sFld) + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
