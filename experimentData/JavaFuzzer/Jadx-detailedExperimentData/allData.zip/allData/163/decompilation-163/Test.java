
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/163/original-163/Test.dex */
public class Test {
    public static int[] iArrFld;
    public float fFld = -38.168f;
    public short sFld = -27092;
    public static long instanceCount = -13920;
    public static byte byFld = 95;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -250);
        FuzzerUtils.init(fArrFld, -99.458f);
    }

    public static void vMeth(int i, int i2) {
        float[][][] fArr;
        FuzzerUtils.init((Object[][]) ((float[][][]) Array.newInstance(float.class, N, N, N)), (Object) Float.valueOf(0.71f));
        float f = i2;
        int i3 = -23109;
        int i4 = -8333;
        float f2 = f;
        int i5 = 1;
        while (true) {
            i5++;
            if (i5 < 237) {
                f2 -= f;
                i3 = 1;
                while (i3 < 7) {
                    i4 = 2;
                    i3++;
                }
            } else {
                vMeth_check_sum += (((((i2 + i2) + Float.floatToIntBits(f2)) + i5) + i3) - 12) + i4 + Double.doubleToLongBits(-104.27888d) + 30785 + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr));
                return;
            }
        }
    }

    public static int iMeth1() {
        int[] iArr;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 6655L);
        int i = -6;
        vMeth(-6, -6);
        int i2 = -25023;
        int i3 = 253;
        int i4 = 1;
        int i5 = 10;
        while (true) {
            i4++;
            if (i4 < 163) {
                int i6 = i4 - 1;
                jArr[i6] = jArr[i6] * instanceCount;
                i2 = 1;
                while (10 > i2) {
                    long j = instanceCount + (i2 * i2) + 32473;
                    instanceCount = j;
                    long j2 = j << i2;
                    instanceCount = j2;
                    instanceCount = j2 + 1 + 107.914f;
                    int i7 = i4 + 1;
                    jArr[i7] = jArr[i7] - ((long) (-124.48152d));
                    i5 = 52967;
                    i = i * i2 * i4;
                    i3 = 2;
                    i2++;
                }
                iArrFld[i4] = iArr[i4] - 16776;
            } else {
                long checkSum = (((((i + i4) + i2) + i5) + i3) - 16776) + FuzzerUtils.checkSum(jArr);
                iMeth1_check_sum += checkSum;
                return (int) checkSum;
            }
        }
    }

    public static int iMeth(int i, float f, long j) {
        double[] dArr = new double[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(dArr, -50.79292d);
        FuzzerUtils.init(fArr, 2.813f);
        int i2 = 11946;
        int i3 = -58508;
        int i4 = 11590;
        int i5 = -24646;
        int i6 = 19;
        while (i6 < 367) {
            iArrFld[i6] = (int) j;
            dArr[i6] = 0.117562d;
            iMeth1();
            int i7 = i5;
            int i8 = i4;
            int i9 = i3;
            int i10 = 1;
            while (i10 < 5) {
                i8 = 1;
                while (i8 < 2) {
                    fArr[i10] = fArr[i10] - f;
                    instanceCount -= i9;
                    i9 += 134;
                    i8++;
                }
                i7 = 1;
                while (i7 < 2) {
                    i9 <<= i8;
                    i7++;
                }
                f -= -68.0f;
                i10++;
                i = i6;
            }
            i6++;
            i2 = i10;
            i3 = i9;
            i4 = i8;
            i5 = i7;
        }
        long floatToIntBits = (((((((((((i + Float.floatToIntBits(f)) + j) + i6) - 7) + Double.doubleToLongBits(0.117562d)) + i2) + i3) + i4) + 134) + i5) - 109) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x0112, code lost:
        if (r7 != 127) goto L49;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void mainTest(java.lang.String[] r32) {
        /*
            Method dump skipped, instructions count: 758
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.mainTest(java.lang.String[]):void");
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
