/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/1/original-1/Test.dex */
public class Test {
    public static long instanceCount = -3576743641427970674L;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static volatile double[] dArrFld = new double[N];
    public static float[] fArrFld = new float[N];
    public static long[] lArrFld = new long[N];
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, 84);
        FuzzerUtils.init(dArrFld, 14.75313d);
        FuzzerUtils.init(fArrFld, -2.37f);
        FuzzerUtils.init(lArrFld, 3133525093405025388L);
    }

    public static void vMeth1(int i, byte b, short s) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 0.857f);
        double d = b;
        int i2 = (int) instanceCount;
        int i3 = 23824;
        int i4 = -16;
        int i5 = 1;
        short s2 = s;
        do {
            i2 *= i2;
            int i6 = i5 * i5;
            i3 += i6;
            switch (((i3 >>> 1) % 10) + 112) {
                case 112:
                    i3 += i6 + 41024;
                case 113:
                    i2 += ((i5 * i2) + i3) - s2;
                    break;
                case 114:
                    i3 &= i3;
                    break;
                case 115:
                    i4 = 1;
                    while (true) {
                        i4++;
                        if (i4 < 7) {
                            i3 += (i4 * i4) + 0;
                        } else {
                            long j = i6;
                            long j2 = instanceCount + j + 41;
                            instanceCount = j2;
                            instanceCount = j2 + j;
                            break;
                        }
                    }
                case 116:
                    i3 = (int) (i3 + ((((float) (i5 * instanceCount)) + 122.329f) - 122.329f));
                    break;
                case 117:
                case 118:
                    break;
                case 119:
                    i2 = (int) instanceCount;
                case 120:
                    i3 += ((i5 * i3) + i4) - i4;
                    break;
                case 121:
                    s2 = 0;
                    break;
                default:
                    i2 = (int) instanceCount;
                    break;
            }
            i5++;
        } while (i5 < 224);
        vMeth1_check_sum += i2 + b + s2 + Double.doubleToLongBits(d) + i5 + i3 + i4 + Float.floatToIntBits(122.329f) + 0 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static int iMeth(int i, int i2, int i3) {
        vMeth1(i3, (byte) 58, (short) -15448);
        int i4 = 9;
        int i5 = 2820;
        double d = -2.33613d;
        int i6 = 13;
        while (i6 < 324) {
            d = -3.5626879521929318E18d;
            int i7 = i6 + 1;
            fArrFld[i7] = 4;
            i4 = i6;
            while (i4 < 5) {
                i *= (int) 0.537f;
                double d2 = 0.537f | 1;
                Double.isNaN(d2);
                d /= d2;
                try {
                    i2 = i4 % (-241);
                    i3 = i4 % i;
                    i3 = iArrFld[i4 + 1] % 35313;
                } catch (ArithmeticException e) {
                }
                i5 = 2;
                i4++;
            }
            i6 = i7;
        }
        long doubleToLongBits = ((((((((i + i2) + i3) - 15448) + i6) + 4) + Double.doubleToLongBits(d)) + i4) - 241) + Float.floatToIntBits(0.537f) + i5 + 10;
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void vMeth() {
        long iMeth = instanceCount + iMeth(-12497, -12497, -12497);
        instanceCount = iMeth;
        instanceCount = iMeth;
        double d = iMeth;
        Double.isNaN(d);
        double d2 = (-1.6744d) - d;
        int i = 14;
        instanceCount = iMeth - 14;
        int i2 = -11;
        int i3 = 12;
        while (i3 < 287) {
            i *= 3;
            i2 = 6;
            while (i2 > 1) {
                i2--;
                i = 19782;
            }
            i3++;
        }
        vMeth_check_sum += i + Double.doubleToLongBits(d2) + i3 + 3 + i2 + 19782 + 129 + 32230;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public void mainTest(String[] strArr) {
        int i;
        int i2 = 8;
        while (i2 < 145) {
            vMeth();
            int[] iArr = iArrFld;
            iArr[i2] = iArr[i2] * i2;
            i2++;
        }
        lArrFld[387] = i2;
        int i3 = 9;
        int i4 = 9;
        int i5 = -6;
        int i6 = -10;
        int i7 = 77;
        int i8 = 172;
        int i9 = -22957;
        int i10 = -35403;
        int i11 = 12;
        short s = 11998;
        float f = -117.313f;
        while (i4 < 154) {
            int i12 = i4 * i4;
            i5 += i12;
            short s2 = (short) (((short) i12) + 7);
            int i13 = 1;
            while (true) {
                i13++;
                if (i13 < 275) {
                    int i14 = 2;
                    while (i4 < i14) {
                        int[] iArr2 = iArrFld;
                        iArr2[i13] = i13;
                        iArr2[i4] = (int) instanceCount;
                        dArrFld[i4] = 6.20961168E8d;
                        i14--;
                    }
                    s2 = (short) (s2 - ((short) f));
                    instanceCount = i5;
                    float f2 = f;
                    int i15 = i11;
                    int i16 = i10;
                    int i17 = 1;
                    int i18 = i5;
                    int i19 = i3;
                    int i20 = i18;
                    while (i17 < 2) {
                        i8 += ((i17 * i13) + i2) - i14;
                        try {
                            i16 = 199 % i4;
                            i19 = i2 % (-127);
                            iArrFld[i4 - 1] = 1566000365 % i2;
                        } catch (ArithmeticException e) {
                        }
                        int[] iArr3 = iArrFld;
                        iArr3[i13] = iArr3[i13] | i19;
                        int i21 = i13 - 1;
                        iArr3[i21] = iArr3[i21] * i8;
                        switch ((i4 % 8) + 25) {
                            case 25:
                                try {
                                    i = i14 / i17;
                                    try {
                                        i19 = i16 / i16;
                                        int i22 = i16 / i;
                                    } catch (ArithmeticException e2) {
                                    }
                                } catch (ArithmeticException e3) {
                                    i = i17;
                                }
                                i20 = i + 1;
                                i8 = i15;
                                break;
                            case 26:
                                instanceCount = 0L;
                                f2 += i17 * i17;
                                i20 = -8;
                                break;
                            case 27:
                                i8 += (int) instanceCount;
                                i20 = -8;
                                break;
                            case 28:
                                i15 = i2;
                                i20 = -8;
                                break;
                            case 29:
                            case 30:
                                i16 -= i13;
                                i20 = -8;
                                break;
                            case 31:
                                instanceCount = i13;
                                i20 = -8;
                                break;
                            case 32:
                                s2 = 9525;
                                i20 = -8;
                                break;
                            default:
                                i20 = -8;
                                break;
                        }
                        i17++;
                    }
                    i7 = i14;
                    i9 = i17;
                    i10 = i16;
                    i11 = i15;
                    f = f2;
                    int i23 = i19;
                    i5 = i20;
                    i3 = i23;
                }
            }
            i4 += 3;
            s = s2;
            i6 = i13;
        }
        FuzzerUtils.out.println("i i1 i22 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i23 s2 i24 = " + i5 + "," + ((int) s) + "," + i6);
        FuzzerUtils.out.println("i25 i26 f3 = " + i7 + "," + i8 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i27 i28 i29 = " + i9 + "," + i10 + "," + i11);
        FuzzerUtils.out.println("Test.instanceCount Test.iArrFld Test.dArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.fArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
