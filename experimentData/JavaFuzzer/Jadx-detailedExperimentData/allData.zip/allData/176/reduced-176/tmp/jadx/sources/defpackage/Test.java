package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;
import java.util.Random;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/strange_ones/176/reduced-176/tmp/Test.dex */
public class Test {
    public static long instanceCount = 216;
    public static float fFld = 0.587f;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static double[] dArrFld = new double[N];
    public static float[][] fArrFld = (float[][]) Array.newInstance(float.class, N, N);
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static PrintStream out = System.out;
    public static Random random = new Random(1);
    public static long seed = 1;
    public static int UnknownZero = 0;

    static {
        init(iArrFld, -46777);
        init(dArrFld, 60.85987d);
        init(fArrFld, 65.453f);
    }

    public static long lMeth(int i) {
        int[] iArr = iArrFld;
        int i2 = (i >>> 1) % N;
        iArr[i2] = (int) instanceCount;
        byte b = 113;
        iArr[i2] = iArr[i2] & 113;
        int i3 = 43697;
        int i4 = -20;
        int i5 = 31518;
        int i6 = 5;
        int i7 = -107;
        double d = -1.4457d;
        int i8 = 3;
        while (i8 < 125) {
            i |= i;
            switch ((i8 % 9) + 29) {
                case 29:
                    i >>= i;
                    i4 = 13;
                    while (i4 > 1) {
                        i6 = 1;
                        while (i6 < 3) {
                            i += i6;
                            int[] iArr2 = iArrFld;
                            iArr2[i6] = i;
                            i5 *= i7;
                            instanceCount -= fFld;
                            i6++;
                            iArr2[i6] = 134;
                        }
                        i4 -= 2;
                    }
                    break;
                case 30:
                    double d2 = fFld;
                    Double.isNaN(d2);
                    d *= d2;
                case 31:
                    iArrFld[i8] = i4;
                case 32:
                    instanceCount -= i8;
                    break;
                case 33:
                    i3 = -7870;
                    break;
                case 34:
                    b = (byte) (b + ((byte) i8));
                case 35:
                case 36:
                    i3 += (i8 * i8) - 81;
                    break;
                case 37:
                    break;
                default:
                    i7 *= -29349;
                    break;
            }
            i8++;
        }
        long doubleToLongBits = (((((((((i + b) + i8) + i3) + i4) + i5) + i6) + i7) + Double.doubleToLongBits(d)) + 0) - 29349;
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public static void vMeth1(float f, boolean z, byte b) {
        long[] jArr = new long[N];
        init(jArr, -3677485691447833902L);
        int i = -121;
        int i2 = 53510;
        int i3 = 136;
        float f2 = f;
        int i4 = 16;
        while (i4 < 313) {
            f2 -= 55978 * i;
            int i5 = i3;
            int i6 = 1;
            while (6 > i6) {
                int[] iArr = iArrFld;
                int i7 = iArr[i6];
                int i8 = iArr[i6] - 1;
                iArr[i6] = i8;
                iArr[i6] = i7 + ((int) (f2 - i8));
                iArr[i4] = iArr[i4] >>> ((int) jArr[i4 + 1]);
                int i9 = (((i4 >>> 1) % 10) * 5) + 7;
                if (i9 != 11) {
                    if (i9 != 16) {
                        if (i9 == 24) {
                            i5 += 23;
                        } else if (i9 == 29) {
                            i5 <<= -19;
                        } else if (i9 == 31) {
                            fFld = i5;
                            i += i6 * i6;
                        } else {
                            if (i9 != 36) {
                                if (i9 == 39) {
                                    f2 = i;
                                    i5 += i6;
                                } else if (i9 == 47) {
                                    long j = instanceCount;
                                    double d = b;
                                    Double.isNaN(d);
                                    long j2 = j - ((long) (d + 0.37123d));
                                    instanceCount = j2;
                                    i5 >>>= (int) (j2 * lMeth(i6));
                                    fFld -= (float) 0.37123d;
                                } else if (i9 != 44) {
                                    if (i9 == 45) {
                                        instanceCount += i4;
                                    }
                                }
                            }
                            double[] dArr = dArrFld;
                            int i10 = (i6 >>> 1) % N;
                            dArr[i10] = dArr[i10] - 11.0d;
                        }
                    }
                    int i11 = i + (((i6 * i) + i6) - b);
                    i = i11 + (i6 * i11);
                } else {
                    i *= i5;
                }
                i6++;
            }
            i4++;
            i2 = i6;
            i3 = i5;
        }
        vMeth1_check_sum += Float.floatToIntBits(f2) + (z ? 1 : 0) + b + i4 + i + i2 + i3 + Double.doubleToLongBits(0.37123d) + checkSum(jArr);
    }

    public static void vMeth() {
        long[] jArr = new long[N];
        short[] sArr = new short[N];
        init(jArr, 24885L);
        init(sArr, (short) 15054);
        vMeth1(-1.957f, true, (byte) 67);
        int i = -2;
        int i2 = 9;
        int i3 = -12743;
        int i4 = -52049;
        int i5 = 11;
        while (i5 < 397) {
            i *= (int) (-14.59992d);
            int i6 = i4;
            int i7 = i3;
            int i8 = 4;
            while (i8 > 1) {
                fFld += i5;
                i6 = 1;
                do {
                    jArr[i6] = jArr[i6] << i5;
                    i6++;
                } while (i6 < 4);
                int i9 = ((i5 % 4) * 5) + 69;
                if (i9 == 74) {
                    i7 = -1;
                } else if (i9 == 78) {
                    i7 = (int) (i7 + (i8 - instanceCount));
                    i = i5;
                } else {
                    if (i9 == 87) {
                        instanceCount = instanceCount;
                    } else if (i9 != 89) {
                    }
                    sArr[i8 - 1] = (short) i6;
                }
                i8 -= 2;
            }
            i5++;
            i2 = i8;
            i3 = i7;
            i4 = i6;
        }
        vMeth_check_sum += 67 + i5 + i + Double.doubleToLongBits(-14.59992d) + i2 + i3 + i4 + checkSum(jArr) + checkSum(sArr);
    }

    public void mainTest(String[] strArr) {
        instanceCount = -19053L;
        int i = -5;
        int i2 = 2;
        while (i2 < 273) {
            i = iArrFld[i2 - 1];
            vMeth();
            fFld = (float) 0.127586d;
            i2++;
        }
        instanceCount -= -92.28f;
        int i3 = 12;
        int i4 = 61;
        while (213 > i3) {
            i4 += (i3 * i3) + 191;
            i3++;
        }
        float[] fArr = fArrFld[(i2 >>> 1) % N];
        fArr[183] = fArr[183] + 4.0f;
        System.out.println("i i1 f = " + i2 + "," + i + "," + Float.floatToIntBits(-92.28f));
        System.out.println("d3 i19 i20 = " + Double.doubleToLongBits(0.127586d) + "," + i3 + "," + i4);
        System.out.println("Test.instanceCount Test.fFld Test.iArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + checkSum(iArrFld));
        System.out.println("Test.dArrFld Test.fArrFld = " + Double.doubleToLongBits(checkSum(dArrFld)) + "," + Double.doubleToLongBits(checkSum(fArrFld)));
        System.out.println("lMeth_check_sum: " + lMeth_check_sum);
        System.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        System.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            new Test().mainTest(strArr);
        } catch (Exception e) {
            System.out.println(e.getClass().getCanonicalName());
        }
    }

    public static int nextInt() {
        return random.nextInt();
    }

    public static long nextLong() {
        return random.nextLong();
    }

    public static float nextFloat() {
        return random.nextFloat();
    }

    public static double nextDouble() {
        return random.nextDouble();
    }

    public static boolean nextBoolean() {
        return random.nextBoolean();
    }

    public static byte nextByte() {
        return (byte) random.nextInt();
    }

    public static short nextShort() {
        return (short) random.nextInt();
    }

    public static char nextChar() {
        return (char) random.nextInt();
    }

    public static void init(boolean[] zArr, boolean z) {
        for (int i = 0; i < zArr.length; i++) {
            zArr[i] = i % 2 == 0 ? z : i % 3 == 0;
        }
    }

    public static void init(boolean[][] zArr, boolean z) {
        for (boolean[] zArr2 : zArr) {
            init(zArr2, z);
        }
    }

    public static void init(long[] jArr, long j) {
        for (int i = 0; i < jArr.length; i++) {
            jArr[i] = i % 2 == 0 ? i + j : j - i;
        }
    }

    public static void init(long[][] jArr, long j) {
        for (long[] jArr2 : jArr) {
            init(jArr2, j);
        }
    }

    public static void init(int[] iArr, int i) {
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr[i2] = i2 % 2 == 0 ? i + i2 : i - i2;
        }
    }

    public static void init(int[][] iArr, int i) {
        for (int[] iArr2 : iArr) {
            init(iArr2, i);
        }
    }

    public static void init(short[] sArr, short s) {
        for (int i = 0; i < sArr.length; i++) {
            sArr[i] = (short) (i % 2 == 0 ? s + i : s - i);
        }
    }

    public static void init(short[][] sArr, short s) {
        for (short[] sArr2 : sArr) {
            init(sArr2, s);
        }
    }

    public static void init(char[] cArr, char c) {
        for (int i = 0; i < cArr.length; i++) {
            cArr[i] = (char) (i % 2 == 0 ? c + i : c - i);
        }
    }

    public static void init(char[][] cArr, char c) {
        for (char[] cArr2 : cArr) {
            init(cArr2, c);
        }
    }

    public static void init(byte[] bArr, byte b) {
        for (int i = 0; i < bArr.length; i++) {
            bArr[i] = (byte) (i % 2 == 0 ? b + i : b - i);
        }
    }

    public static void init(byte[][] bArr, byte b) {
        for (byte[] bArr2 : bArr) {
            init(bArr2, b);
        }
    }

    public static void init(double[] dArr, double d) {
        double d2;
        for (int i = 0; i < dArr.length; i++) {
            if (i % 2 == 0) {
                double d3 = i;
                Double.isNaN(d3);
                d2 = d3 + d;
            } else {
                double d4 = i;
                Double.isNaN(d4);
                d2 = d - d4;
            }
            dArr[i] = d2;
        }
    }

    public static void init(double[][] dArr, double d) {
        for (double[] dArr2 : dArr) {
            init(dArr2, d);
        }
    }

    public static void init(float[] fArr, float f) {
        for (int i = 0; i < fArr.length; i++) {
            fArr[i] = i % 2 == 0 ? i + f : f - i;
        }
    }

    public static void init(float[][] fArr, float f) {
        for (float[] fArr2 : fArr) {
            init(fArr2, f);
        }
    }

    public static void init(Object[][] objArr, Object obj) {
        for (Object[] objArr2 : objArr) {
            init(objArr2, obj);
        }
    }

    public static void init(Object[] objArr, Object obj) {
        for (int i = 0; i < objArr.length; i++) {
            try {
                objArr[i] = obj.getClass().newInstance();
            } catch (Exception e) {
                objArr[i] = obj;
            }
        }
    }

    public static long checkSum(boolean[] zArr) {
        long j = 0;
        for (int i = 0; i < zArr.length; i++) {
            j += zArr[i] ? i + 1 : 0;
        }
        return j;
    }

    public static long checkSum(boolean[][] zArr) {
        long j = 0;
        for (boolean[] zArr2 : zArr) {
            j += checkSum(zArr2);
        }
        return j;
    }

    public static long checkSum(long[] jArr) {
        long j = 0;
        int i = 0;
        while (i < jArr.length) {
            int i2 = i + 1;
            long j2 = i2;
            j += (jArr[i] / j2) + (jArr[i] % j2);
            i = i2;
        }
        return j;
    }

    public static long checkSum(long[][] jArr) {
        long j = 0;
        for (long[] jArr2 : jArr) {
            j += checkSum(jArr2);
        }
        return j;
    }

    public static long checkSum(int[] iArr) {
        long j = 0;
        int i = 0;
        while (i < iArr.length) {
            int i2 = i + 1;
            j += (iArr[i] / i2) + (iArr[i] % i2);
            i = i2;
        }
        return j;
    }

    public static long checkSum(int[][] iArr) {
        long j = 0;
        for (int[] iArr2 : iArr) {
            j += checkSum(iArr2);
        }
        return j;
    }

    public static long checkSum(short[] sArr) {
        long j = 0;
        int i = 0;
        while (i < sArr.length) {
            int i2 = i + 1;
            j += (short) ((sArr[i] / i2) + (sArr[i] % i2));
            i = i2;
        }
        return j;
    }

    public static long checkSum(short[][] sArr) {
        long j = 0;
        for (short[] sArr2 : sArr) {
            j += checkSum(sArr2);
        }
        return j;
    }

    public static long checkSum(char[] cArr) {
        long j = 0;
        int i = 0;
        while (i < cArr.length) {
            int i2 = i + 1;
            j += (char) ((cArr[i] / i2) + (cArr[i] % i2));
            i = i2;
        }
        return j;
    }

    public static long checkSum(char[][] cArr) {
        long j = 0;
        for (char[] cArr2 : cArr) {
            j += checkSum(cArr2);
        }
        return j;
    }

    public static long checkSum(byte[] bArr) {
        long j = 0;
        int i = 0;
        while (i < bArr.length) {
            int i2 = i + 1;
            j += (byte) ((bArr[i] / i2) + (bArr[i] % i2));
            i = i2;
        }
        return j;
    }

    public static long checkSum(byte[][] bArr) {
        long j = 0;
        for (byte[] bArr2 : bArr) {
            j += checkSum(bArr2);
        }
        return j;
    }

    public static double checkSum(double[] dArr) {
        double d = 0.0d;
        int i = 0;
        while (i < dArr.length) {
            double d2 = dArr[i];
            int i2 = i + 1;
            double d3 = i2;
            Double.isNaN(d3);
            double d4 = dArr[i];
            Double.isNaN(d3);
            d += (d2 / d3) + (d4 % d3);
            i = i2;
        }
        return d;
    }

    public static double checkSum(double[][] dArr) {
        double d = 0.0d;
        for (double[] dArr2 : dArr) {
            d += checkSum(dArr2);
        }
        return d;
    }

    public static double checkSum(float[] fArr) {
        double d = 0.0d;
        int i = 0;
        while (i < fArr.length) {
            int i2 = i + 1;
            float f = i2;
            double d2 = (fArr[i] / f) + (fArr[i] % f);
            Double.isNaN(d2);
            d += d2;
            i = i2;
        }
        return d;
    }

    public static double checkSum(float[][] fArr) {
        double d = 0.0d;
        for (float[] fArr2 : fArr) {
            d += checkSum(fArr2);
        }
        return d;
    }

    public static long checkSum(Object[][] objArr) {
        long j = 0;
        for (Object[] objArr2 : objArr) {
            j += checkSum(objArr2);
        }
        return j;
    }

    public static long checkSum(Object[] objArr) {
        long j = 0;
        for (int i = 0; i < objArr.length; i++) {
            double d = j;
            double checkSum = checkSum(objArr[i]);
            double pow = Math.pow(2.0d, i);
            Double.isNaN(checkSum);
            Double.isNaN(d);
            j = (long) (d + (checkSum * pow));
        }
        return j;
    }

    public static long checkSum(Object obj) {
        if (obj == null) {
            return 0L;
        }
        return obj.getClass().getCanonicalName().length();
    }

    public static byte[] byte1array(int i, byte b) {
        byte[] bArr = new byte[i];
        init(bArr, b);
        return bArr;
    }

    public static byte[][] byte2array(int i, byte b) {
        byte[][] bArr = (byte[][]) Array.newInstance(byte.class, i, i);
        init(bArr, b);
        return bArr;
    }

    public static short[] short1array(int i, short s) {
        short[] sArr = new short[i];
        init(sArr, s);
        return sArr;
    }

    public static short[][] short2array(int i, short s) {
        short[][] sArr = (short[][]) Array.newInstance(short.class, i, i);
        init(sArr, s);
        return sArr;
    }

    public static int[] int1array(int i, int i2) {
        int[] iArr = new int[i];
        init(iArr, i2);
        return iArr;
    }

    public static int[][] int2array(int i, int i2) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, i, i);
        init(iArr, i2);
        return iArr;
    }

    public static long[] long1array(int i, long j) {
        long[] jArr = new long[i];
        init(jArr, j);
        return jArr;
    }

    public static long[][] long2array(int i, long j) {
        long[][] jArr = (long[][]) Array.newInstance(long.class, i, i);
        init(jArr, j);
        return jArr;
    }

    public static float[] float1array(int i, float f) {
        float[] fArr = new float[i];
        init(fArr, f);
        return fArr;
    }

    public static float[][] float2array(int i, float f) {
        float[][] fArr = (float[][]) Array.newInstance(float.class, i, i);
        init(fArr, f);
        return fArr;
    }

    public static double[] double1array(int i, double d) {
        double[] dArr = new double[i];
        init(dArr, d);
        return dArr;
    }

    public static double[][] double2array(int i, double d) {
        double[][] dArr = (double[][]) Array.newInstance(double.class, i, i);
        init(dArr, d);
        return dArr;
    }

    public static char[] char1array(int i, char c) {
        char[] cArr = new char[i];
        init(cArr, c);
        return cArr;
    }

    public static char[][] char2array(int i, char c) {
        char[][] cArr = (char[][]) Array.newInstance(char.class, i, i);
        init(cArr, c);
        return cArr;
    }

    public static Object[] Object1array(int i, Object obj) {
        Object[] objArr = new Object[i];
        init(objArr, obj);
        return objArr;
    }

    public static Object[][] Object2array(int i, Object obj) {
        Object[][] objArr = (Object[][]) Array.newInstance(Object.class, i, i);
        init(objArr, obj);
        return objArr;
    }

    public static boolean[] boolean1array(int i, boolean z) {
        boolean[] zArr = new boolean[i];
        init(zArr, z);
        return zArr;
    }

    public static boolean[][] boolean2array(int i, boolean z) {
        boolean[][] zArr = (boolean[][]) Array.newInstance(boolean.class, i, i);
        init(zArr, z);
        return zArr;
    }
}
