
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/176/original-176/Test.dex */
public class Test {
    public static long instanceCount = 216;
    public static float fFld = 0.587f;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static double[] dArrFld = new double[N];
    public static float[][] fArrFld = (float[][]) Array.newInstance(float.class, N, N);
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long lMeth_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, -46777);
        FuzzerUtils.init(dArrFld, 60.85987d);
        FuzzerUtils.init(fArrFld, 65.453f);
    }

    public static long lMeth(int i) {
        int[] iArr = iArrFld;
        int i2 = (i >>> 1) % N;
        iArr[i2] = (int) instanceCount;
        byte b = 113;
        iArr[i2] = iArr[i2] & 113;
        int i3 = 43697;
        int i4 = -20;
        int i5 = 31518;
        int i6 = 5;
        int i7 = -107;
        double d = -1.4457d;
        int i8 = 3;
        while (i8 < 125) {
            i |= i;
            switch ((i8 % 9) + 29) {
                case 29:
                    i >>= i;
                    i4 = 13;
                    while (i4 > 1) {
                        i6 = 1;
                        while (i6 < 3) {
                            i += i6;
                            int[] iArr2 = iArrFld;
                            iArr2[i6] = i;
                            i5 *= i7;
                            instanceCount -= fFld;
                            i6++;
                            iArr2[i6] = 134;
                        }
                        i4 -= 2;
                    }
                    break;
                case 30:
                    double d2 = fFld;
                    Double.isNaN(d2);
                    d *= d2;
                case 31:
                    iArrFld[i8] = i4;
                case 32:
                    instanceCount -= i8;
                    break;
                case 33:
                    i3 = -7870;
                    break;
                case 34:
                    b = (byte) (b + ((byte) i8));
                case 35:
                case 36:
                    i3 += (i8 * i8) - 81;
                    break;
                case 37:
                    break;
                default:
                    i7 *= -29349;
                    break;
            }
            i8++;
        }
        long doubleToLongBits = (((((((((i + b) + i8) + i3) + i4) + i5) + i6) + i7) + Double.doubleToLongBits(d)) + 0) - 29349;
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public static void vMeth1(float f, boolean z, byte b) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -3677485691447833902L);
        int i = -121;
        int i2 = 53510;
        int i3 = 136;
        float f2 = f;
        int i4 = 16;
        while (i4 < 313) {
            f2 -= 55978 * i;
            int i5 = i3;
            int i6 = 1;
            while (6 > i6) {
                int[] iArr = iArrFld;
                int i7 = iArr[i6];
                int i8 = iArr[i6] - 1;
                iArr[i6] = i8;
                iArr[i6] = i7 + ((int) (f2 - i8));
                iArr[i4] = iArr[i4] >>> ((int) jArr[i4 + 1]);
                int i9 = (((i4 >>> 1) % 10) * 5) + 7;
                if (i9 != 11) {
                    if (i9 != 16) {
                        if (i9 == 24) {
                            i5 += 23;
                        } else if (i9 == 29) {
                            i5 <<= -19;
                        } else if (i9 == 31) {
                            fFld = i5;
                            i += i6 * i6;
                        } else {
                            if (i9 != 36) {
                                if (i9 == 39) {
                                    f2 = i;
                                    i5 += i6;
                                } else if (i9 == 47) {
                                    long j = instanceCount;
                                    double d = b;
                                    Double.isNaN(d);
                                    long j2 = j - ((long) (d + 0.37123d));
                                    instanceCount = j2;
                                    i5 >>>= (int) (j2 * lMeth(i6));
                                    fFld -= (float) 0.37123d;
                                } else if (i9 != 44) {
                                    if (i9 == 45) {
                                        instanceCount += i4;
                                    }
                                }
                            }
                            double[] dArr = dArrFld;
                            int i10 = (i6 >>> 1) % N;
                            dArr[i10] = dArr[i10] - 11.0d;
                        }
                    }
                    int i11 = i + (((i6 * i) + i6) - b);
                    i = i11 + (i6 * i11);
                } else {
                    i *= i5;
                }
                i6++;
            }
            i4++;
            i2 = i6;
            i3 = i5;
        }
        vMeth1_check_sum += Float.floatToIntBits(f2) + (z ? 1 : 0) + b + i4 + i + i2 + i3 + Double.doubleToLongBits(0.37123d) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth() {
        long[] jArr = new long[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(jArr, 24885L);
        FuzzerUtils.init(sArr, (short) 15054);
        vMeth1(-1.957f, true, (byte) 67);
        int i = -2;
        int i2 = 9;
        int i3 = -12743;
        int i4 = -52049;
        int i5 = 11;
        while (i5 < 397) {
            i *= (int) (-14.59992d);
            int i6 = i4;
            int i7 = i3;
            int i8 = 4;
            while (i8 > 1) {
                fFld += i5;
                i6 = 1;
                do {
                    jArr[i6] = jArr[i6] << i5;
                    i6++;
                } while (i6 < 4);
                int i9 = ((i5 % 4) * 5) + 69;
                if (i9 == 74) {
                    i7 = -1;
                } else if (i9 == 78) {
                    i7 = (int) (i7 + (i8 - instanceCount));
                    i = i5;
                } else {
                    if (i9 == 87) {
                        instanceCount = instanceCount;
                    } else if (i9 != 89) {
                    }
                    sArr[i8 - 1] = (short) i6;
                }
                i8 -= 2;
            }
            i5++;
            i2 = i8;
            i3 = i7;
            i4 = i6;
        }
        vMeth_check_sum += 67 + i5 + i + Double.doubleToLongBits(-14.59992d) + i2 + i3 + i4 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(sArr);
    }

    public void mainTest(String[] strArr) {
        instanceCount = -19053L;
        int i = -5;
        int i2 = 2;
        while (i2 < 273) {
            i = iArrFld[i2 - 1];
            vMeth();
            fFld = (float) 0.127586d;
            i2++;
        }
        instanceCount -= -92.28f;
        int i3 = 12;
        int i4 = 61;
        while (213 > i3) {
            i4 += (i3 * i3) + 191;
            i3++;
        }
        float[] fArr = fArrFld[(i2 >>> 1) % N];
        fArr[183] = fArr[183] + 4.0f;
        FuzzerUtils.out.println("i i1 f = " + i2 + "," + i + "," + Float.floatToIntBits(-92.28f));
        FuzzerUtils.out.println("d3 i19 i20 = " + Double.doubleToLongBits(0.127586d) + "," + i3 + "," + i4);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.dArrFld Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
