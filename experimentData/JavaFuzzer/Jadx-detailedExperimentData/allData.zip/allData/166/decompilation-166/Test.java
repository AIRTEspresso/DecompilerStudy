
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/166/original-166/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public volatile byte byFld = 21;
    public double dFld = -1.87946d;
    public static long instanceCount = 55909;
    public static boolean bFld = true;
    public static long iMeth_check_sum = 0;
    public static long bMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -64100);
    }

    public static void vMeth(float f, boolean z) {
        vMeth_check_sum += ((Float.floatToIntBits(f) + (z ? 1 : 0)) - 30012) + 30000;
    }

    public static boolean bMeth() {
        float f;
        int i;
        int i2;
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 4.362f);
        int i3 = -10;
        int i4 = 217;
        while (true) {
            f = 1.889f;
            if (i4 <= 4) {
                break;
            }
            vMeth(1.889f, false);
            long j = instanceCount + (((i4 * i2) + i4) - i2);
            instanceCount = j;
            i3 = i3 + i4 + 119;
            int[] iArr = iArrFld;
            int i5 = i4 - 1;
            iArr[i5] = iArr[i5] + ((int) j);
            i4--;
        }
        long j2 = instanceCount;
        int i6 = (int) j2;
        int i7 = -4;
        int i8 = 11;
        double d = -1.113372d;
        double d2 = -2.122995d;
        switch (((i4 >>> 1) % 10) + 18) {
            case 18:
                int[] iArr2 = iArrFld;
                iArr2[5] = iArr2[5] % ((int) (j2 | 1));
                double d3 = 1.0d;
                do {
                    i = 1;
                    while (i < 7) {
                        instanceCount <<= i4;
                        i6 *= -14312;
                        i++;
                    }
                    d3 += 1.0d;
                } while (d3 < 215.0d);
                i7 = i;
                d = d3;
            case 19:
                f = 1.889f + ((float) instanceCount);
                break;
            case 20:
                i6 += i4;
            case 21:
                double d4 = instanceCount;
                Double.isNaN(d4);
                d2 = (-2.122995d) * d4;
                break;
            case 22:
            case 23:
            case 24:
                i6 += (int) instanceCount;
            case 25:
            case 26:
                double d5 = instanceCount;
                Double.isNaN(d5);
                d2 = (-2.122995d) - d5;
            case 27:
                i8 = 53113;
                break;
            default:
                fArr[46] = (float) j2;
                break;
        }
        long floatToIntBits = (((((((i4 + i6) + Float.floatToIntBits(f)) + 0) + Double.doubleToLongBits(d)) + i7) + i8) - 14312) + Double.doubleToLongBits(d2) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        bMeth_check_sum += floatToIntBits;
        return floatToIntBits % 2 > 0;
    }

    public int iMeth(int i) {
        int i2;
        int i3 = i;
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, -3609588869374174902L);
        int[] iArr = iArrFld;
        int i4 = N;
        long j = instanceCount;
        long j2 = j - 1;
        instanceCount = j2;
        instanceCount = j2;
        instanceCount = (iArr[(i3 >>> 1) % N] * i3 * j) + j2;
        double d = 10.0d;
        int i5 = 41874;
        int i6 = -5;
        int i7 = -3;
        int i8 = 14;
        double d2 = 10.0d;
        while (d2 < 164.0d) {
            jArr = FuzzerUtils.long2array(i4, -745058389391775611L);
            int i9 = (int) d2;
            long[] jArr2 = jArr[i9];
            double d3 = 1.0d + d2;
            int i10 = (int) d3;
            jArr2[i10] = jArr2[i10] - i5;
            bMeth();
            i3 -= i9;
            int i11 = 1;
            i5--;
            i6 = 1;
            while (true) {
                i6 += i11;
                if (i6 < 10) {
                    i3 += i6 - i6;
                    i5 = this.byFld;
                    int i12 = (int) (((d2 % d) * 5.0d) + 116.0d);
                    if (i12 != 120) {
                        if (i12 != 121) {
                            if (i12 != 123) {
                                if (i12 != 124) {
                                    if (i12 == 127) {
                                        instanceCount = i5;
                                        i5 = i5;
                                        i7 = 1;
                                    } else {
                                        if (i12 != 131) {
                                            if (i12 == 135) {
                                                i2 = i5;
                                            } else if (i12 != 160) {
                                                if (i12 == 162) {
                                                    i8 += (int) instanceCount;
                                                } else if (i12 != 163) {
                                                    i2 = i5;
                                                } else {
                                                    i2 = i5;
                                                    instanceCount &= i7;
                                                }
                                            }
                                            this.byFld = (byte) (this.byFld + ((byte) i8));
                                        } else {
                                            i2 = i5;
                                            bFld = bFld;
                                        }
                                        i5 = i2;
                                    }
                                }
                                i5 *= this.byFld;
                            } else {
                                i8 += i6;
                            }
                        }
                        i3 += ((i6 * i7) + i8) - i8;
                    } else {
                        i3 = -29;
                    }
                    d = 10.0d;
                    i11 = 1;
                }
            }
            d2 = d3;
            d = 10.0d;
            i4 = N;
        }
        long doubleToLongBits = i3 + Double.doubleToLongBits(d2) + i5 + i6 + i7 + i8 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = -236;
        long iMeth = iMeth(-236);
        instanceCount = iMeth;
        instanceCount = iMeth;
        int i3 = 183;
        while (true) {
            i = 5;
            if (i3 <= 5) {
                break;
            }
            i2 -= this.byFld;
            i3--;
        }
        int i4 = 13;
        int i5 = -25;
        int i6 = 175;
        int i7 = -10;
        while (i4 < 352) {
            this.dFld -= 209.0d;
            i2 -= (int) 0.553f;
            bFld = false;
            int i8 = i7;
            int i9 = i4;
            while (i9 < 74) {
                i2 = (i2 >> (-27937)) - i9;
                long j = i5;
                i5 = (int) (j + (((i9 * (-13)) + instanceCount) - j));
                i9++;
                i = 1;
                i8 = 1;
            }
            i4++;
            i6 = i9;
            i7 = i8;
        }
        FuzzerUtils.out.println("i10 i11 i12 = " + i2 + "," + i3 + "," + i5);
        FuzzerUtils.out.println("i13 i14 f2 = " + i4 + ",0," + Float.floatToIntBits(0.553f));
        FuzzerUtils.out.println("i15 i16 i17 = " + i6 + ",-13," + i);
        FuzzerUtils.out.println("i18 i19 i20 = -229,29903," + i7);
        FuzzerUtils.out.println("i21 s2 = -14,29954");
        FuzzerUtils.out.println("Test.instanceCount byFld Test.bFld = " + instanceCount + "," + ((int) this.byFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("dFld Test.iArrFld = " + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
