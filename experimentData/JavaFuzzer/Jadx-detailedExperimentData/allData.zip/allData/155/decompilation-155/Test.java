/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/155/original-155/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static volatile long instanceCount = -4896260308601194030L;
    public static volatile float fFld = -97.216f;
    public static short sFld = -10287;
    public static byte byFld = -22;
    public static long lMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 43661);
    }

    public static int iMeth1() {
        double d = instanceCount;
        Double.isNaN(d);
        double d2 = d * 100.75751d;
        double d3 = instanceCount;
        Double.isNaN(d3);
        double d4 = (-1.91412d) - d3;
        int i = 14;
        int i2 = 196;
        int i3 = 9;
        while (i3 < 320) {
            i = 5;
            while (i > 1) {
                fFld *= (float) d2;
                i2 >>= i2;
                iArrFld[i3] = 170;
                i -= 3;
            }
            i3++;
        }
        long doubleToLongBits = Double.doubleToLongBits(d2) + Double.doubleToLongBits(d4) + i3 + 170 + i + i2 + Float.floatToIntBits(-71.42f) + 0;
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static int iMeth(int i, int i2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 142960554L);
        jArr[20] = (iArrFld[19] * iMeth1()) + i;
        long doubleToLongBits = ((((((i + i2) + 19) + 120) + 1) - 72) - 14) + 15849 + 7573 + Double.doubleToLongBits(0.70164d) + 2 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public long lMeth(int i, int i2) {
        int iMeth = i - iMeth(i, i);
        int i3 = i2 << sFld;
        int i4 = -202;
        int i5 = 234;
        int i6 = 33;
        int i7 = -54699;
        int i8 = 169;
        while (i8 > 7) {
            iArrFld = iArrFld;
            instanceCount |= i3;
            instanceCount ^= i4;
            int i9 = i7;
            int i10 = i6;
            int i11 = 1;
            while (i11 < 28) {
                i9 = 1;
                while (i9 < 2) {
                    i4 &= i11;
                    long j = i9;
                    instanceCount += j;
                    instanceCount += j;
                    i9++;
                }
                i10 /= -47;
                instanceCount = i4;
                iMeth = (int) (iMeth + (i11 ^ instanceCount));
                i11++;
            }
            i8 -= 3;
            i5 = i11;
            i6 = i10;
            i7 = i9;
        }
        int[] iArr = iArrFld;
        iArr[388] = iArr[388] * iMeth;
        long j2 = iMeth + i3 + i8 + i4 + i5 + i6 + i7 + 9;
        lMeth_check_sum += j2;
        return j2;
    }

    public void mainTest(String[] strArr) {
        int lMeth = (-29049) << ((int) (((float) (lMeth(-29049, -29049) * (-29049))) - fFld));
        instanceCount += 10;
        int i = -9940;
        int i2 = -13;
        int i3 = 2;
        while (i3 < 164) {
            i ^= i2;
            byFld = (byte) sFld;
            i2 += 25200;
            i3++;
        }
        int[] iArr = iArrFld;
        int i4 = (i >>> 1) % N;
        iArr[i4] = iArr[i4] ^ ((int) instanceCount);
        instanceCount = lMeth;
        FuzzerUtils.out.println("i i23 i24 = " + lMeth + "," + i3 + "," + i);
        FuzzerUtils.out.println("i25 = " + i2);
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.sFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.byFld Test.iArrFld = " + ((int) byFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
