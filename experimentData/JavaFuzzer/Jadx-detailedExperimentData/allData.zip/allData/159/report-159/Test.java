class Test {
    int iFld = - 3;
    void mainTest(String[]strArr1){
        short s = 628;
        int i25 = 1 , i26 = 17 , i31;
        try {
            s += iFld;
        } catch(ArrayIndexOutOfBoundsException exc1){
            for(i31 = 1; ; )
                switch(i31){
                }
        }
        System.out.println("s i25 i26 = " + s + "," + i25 + "," + i26);
    }
    public static void main(String[]strArr){
        try {
            Test _instance = new Test();
            _instance.mainTest(strArr);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
