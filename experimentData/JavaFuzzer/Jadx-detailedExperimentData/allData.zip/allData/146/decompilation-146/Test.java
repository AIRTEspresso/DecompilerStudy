
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/146/original-146/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public boolean bFld = true;
    public static long instanceCount = -60085;
    public static byte byFld = -3;
    public static float fFld = 125.127f;
    public static double dFld = -2.2675d;
    public static int iFld = 12;
    public static short sFld = 22065;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 42.749f);
    }

    public static void vMeth1(int i, int i2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 21259);
        double d = 1.0d;
        while (true) {
            d += 1.0d;
            if (d >= 137.0d) {
                break;
            }
            i2 >>= i;
            instanceCount += i;
        }
        int i3 = 219;
        int i4 = -184;
        int i5 = -17594;
        while (2 < i3) {
            int i6 = ((i3 % 6) * 5) + 99;
            if (i6 != 100) {
                if (i6 != 105) {
                    if (i6 == 111) {
                        instanceCount -= 0;
                    } else if (i6 == 120) {
                        long j = instanceCount + (i3 * i3) + 42248;
                        instanceCount = j;
                        instanceCount = j ^ j;
                        i4 = 1;
                        do {
                            i5 = 1;
                            while (i5 < 3) {
                                float f = fFld - i;
                                fFld = f;
                                dFld *= 9.0d;
                                i += 182;
                                i2 = (i2 + (i5 * i)) - ((int) f);
                                i5++;
                            }
                            i4 += 2;
                        } while (i4 < 7);
                        instanceCount &= -35;
                    } else if (i6 == 117) {
                        i += 232;
                    } else if (i6 == 118) {
                        dFld -= 14589.0d;
                    }
                }
                fFld = -61718;
            } else {
                iArr[i3] = -61718;
            }
            i3--;
        }
        vMeth1_check_sum += (((((((i + i2) + Double.doubleToLongBits(d)) + i3) - 1) + i4) + i5) - 61718) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(int i) {
        byte b;
        long[][][] jArr;
        long[] jArr2;
        float[][][] fArr;
        int[] iArr;
        int i2;
        int i3;
        long j;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] iArr2 = new int[N];
        float[][][] fArr2 = (float[][][]) Array.newInstance(float.class, N, N, N);
        long[] jArr3 = new long[N];
        long[][][] jArr4 = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init(iArr2, 135);
        FuzzerUtils.init(jArr3, -1392964188L);
        FuzzerUtils.init((Object[][]) jArr4, (Object) (-1046417596L));
        FuzzerUtils.init((Object[][]) fArr2, (Object) Float.valueOf(-96.943f));
        long j2 = instanceCount;
        byFld = (byte) (byFld + 1);
        instanceCount = j2 + (i - b);
        int i11 = i;
        int i12 = 1;
        int i13 = 4;
        int i14 = 0;
        int i15 = -133;
        int i16 = 158;
        int i17 = -47214;
        int i18 = -6;
        float f = 1.405f;
        short s = 14175;
        while (true) {
            int i19 = i12 + 1;
            if (i19 >= 232) {
                int i20 = i11 + i19 + i15;
                vMeth_check_sum += i20 + i13 + i16 + i17 + 0 + Float.floatToIntBits(f) + i14 + i18 + s + FuzzerUtils.checkSum(iArr2) + FuzzerUtils.checkSum(jArr3) + FuzzerUtils.checkSum((Object[][]) jArr4) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr2));
                return;
            }
            switch (i19 + 117) {
                case 117:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    long j3 = instanceCount - 1;
                    instanceCount = j3;
                    int i21 = (int) j3;
                    int i22 = i16;
                    int i23 = i13;
                    int i24 = 1;
                    while (i24 < 7) {
                        i23 += i24;
                        int[] iArr3 = iArr2;
                        instanceCount = instanceCount * (((float) ((i23 + j) + (i24 + i19))) - ((((float) j) - 2.689f) - fFld));
                        vMeth1(i23, -8536);
                        double d = dFld;
                        double d2 = i19;
                        Double.isNaN(d2);
                        dFld = d + d2;
                        i22 = i24;
                        while (i22 < 2) {
                            byFld = (byte) -22;
                            i22++;
                        }
                        f = i19;
                        while (f < 2.0f) {
                            fFld += ((float) instanceCount) * f;
                            i23 += (int) (f - i23);
                            f += 1.0f;
                        }
                        i24++;
                        iArr2 = iArr3;
                    }
                    iArr = iArr2;
                    i11 = i21;
                    i15 = i24;
                    i13 = i23;
                    i16 = i22;
                    break;
                case 118:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i2 = i13;
                    i3 = i11;
                    instanceCount %= i2 | 1;
                    iArr = iArr2;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 119:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i2 = i13;
                    i3 = i11;
                    instanceCount = i15;
                    iArr = iArr2;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 120:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i2 = i13;
                    i3 = i11;
                    instanceCount >>= i15;
                    iArr = iArr2;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 121:
                case 122:
                case 140:
                case 151:
                case 158:
                case 178:
                default:
                    iArr = iArr2;
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i2 = i13;
                    i3 = i11;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 123:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    iArr = iArr2;
                    i13 = i16;
                    break;
                case 124:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i11 = (int) (i11 + (((i19 * i4) + instanceCount) - i17));
                    iArr = iArr2;
                    i13 = i13;
                    break;
                case 125:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    fFld += f;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 126:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    instanceCount = instanceCount;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 127:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i5 = i11;
                    i17 = i15;
                    instanceCount = i19;
                    try {
                        i17 = (-45037) / iArr2[(i15 >>> 1) % N];
                        int i25 = i13 % 48939;
                        i14 = (-25073) % i17;
                        iArr = iArr2;
                        i11 = i5;
                        break;
                    } catch (ArithmeticException e) {
                        iArr = iArr2;
                        i11 = i5;
                        break;
                    }
                case 128:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i5 = i11;
                    instanceCount = i19;
                    i17 = (-45037) / iArr2[(i15 >>> 1) % N];
                    int i252 = i13 % 48939;
                    i14 = (-25073) % i17;
                    iArr = iArr2;
                    i11 = i5;
                    break;
                case 129:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i5 = i11;
                    i17 = (-45037) / iArr2[(i15 >>> 1) % N];
                    int i2522 = i13 % 48939;
                    i14 = (-25073) % i17;
                    iArr = iArr2;
                    i11 = i5;
                    break;
                case 130:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    fFld += i19;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 131:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    int i26 = i19 - 1;
                    iArr2[i26] = iArr2[i26] + i13;
                    int i27 = i19 + 1;
                    iArr2[i27] = iArr2[i27] << i16;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 132:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    int i272 = i19 + 1;
                    iArr2[i272] = iArr2[i272] << i16;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 133:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    int i28 = i19 - 1;
                    jArr2[i28] = jArr2[i28] * i16;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 134:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    dFld = instanceCount;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 135:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i11 += i19;
                    iArr = iArr2;
                    break;
                case 136:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 137:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i11 = i17;
                    i13 >>= i13;
                    iArr = iArr2;
                    break;
                case 138:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i11 = i17;
                    i13 >>= i13;
                    iArr = iArr2;
                    break;
                case 139:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i13 >>= i13;
                    iArr = iArr2;
                    break;
                case 141:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i11 *= 1;
                    iArr = iArr2;
                    break;
                case 142:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i6 = i11;
                    i18 *= i19;
                    i17 ^= i17;
                    iArr = iArr2;
                    i11 = i6;
                    break;
                case 143:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i6 = i11;
                    i17 ^= i17;
                    iArr = iArr2;
                    i11 = i6;
                    break;
                case 144:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    int i29 = i11;
                    try {
                        i17 = 54 / i16;
                        iArr2[i19] = i17 % (-34365);
                        i18 = iArr2[i19 - 1] % 170;
                        iArr = iArr2;
                        i11 = i29;
                        break;
                    } catch (ArithmeticException e2) {
                        iArr = iArr2;
                        i11 = i29;
                        break;
                    }
                case 145:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i17 >>>= i13;
                    iArr = iArr2;
                    break;
                case 146:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    fFld += (float) ((i19 * i19) + 1);
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 147:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i7 = i11;
                    i14 -= i14;
                    i13 = i19;
                    iArr = iArr2;
                    i11 = i7;
                    break;
                case 148:
                case 149:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i7 = i11;
                    i13 = i19;
                    iArr = iArr2;
                    i11 = i7;
                    break;
                case 150:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    byFld = (byte) 4;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 152:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i13 *= 94;
                    iArr = iArr2;
                    break;
                case 153:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i17 = (int) instanceCount;
                    iArr = iArr2;
                    break;
                case 154:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i11 -= i14;
                    iArr = iArr2;
                    break;
                case 155:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    double d3 = dFld;
                    double d4 = instanceCount;
                    Double.isNaN(d4);
                    dFld = d3 + d4;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 156:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i8 = i11;
                    iArr2[i19 - 1] = (int) instanceCount;
                    i17 += i19 * i19;
                    iArr = iArr2;
                    i11 = i8;
                    break;
                case 157:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i8 = i11;
                    i17 += i19 * i19;
                    iArr = iArr2;
                    i11 = i8;
                    break;
                case 159:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i13 += i14;
                    iArr = iArr2;
                    break;
                case 160:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i14 = (int) (i14 + (i19 - instanceCount));
                    iArr = iArr2;
                    break;
                case 161:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    instanceCount += ((i19 * i15) + i19) - i15;
                    double d5 = dFld;
                    double d6 = i3;
                    Double.isNaN(d6);
                    dFld = d5 - d6;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 162:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    double d52 = dFld;
                    double d62 = i3;
                    Double.isNaN(d62);
                    dFld = d52 - d62;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 163:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i9 = i11;
                    instanceCount -= (long) dFld;
                    i18 -= i18;
                    i14 %= (int) (instanceCount | 1);
                    iArr = iArr2;
                    i11 = i9;
                    break;
                case 164:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i9 = i11;
                    i18 -= i18;
                    i14 %= (int) (instanceCount | 1);
                    iArr = iArr2;
                    i11 = i9;
                    break;
                case 165:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i9 = i11;
                    i14 %= (int) (instanceCount | 1);
                    iArr = iArr2;
                    i11 = i9;
                    break;
                case 166:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    s = (short) (s + ((short) instanceCount));
                    iArr = iArr2;
                    break;
                case 167:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    iArr2[i19 + 1] = -7;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 168:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    instanceCount = iFld;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 169:
                case 170:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    jArr[i19 - 1][i19] = FuzzerUtils.long1array(N, -212L);
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 171:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    iFld -= i11;
                    iArr = iArr2;
                    i11 = i14;
                    break;
                case 172:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    iArr = iArr2;
                    i11 = i14;
                    break;
                case 173:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    long j4 = instanceCount;
                    instanceCount = j4 + j4;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 174:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    instanceCount *= i14;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 175:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i13 = (int) (i13 + (i19 * instanceCount));
                    iArr = iArr2;
                    i11 = i11;
                    break;
                case 176:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    iArr = iArr2;
                    i18 = -34;
                    break;
                case 177:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i18 = (int) instanceCount;
                    iArr = iArr2;
                    break;
                case 179:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i14 *= (int) f;
                    iArr = iArr2;
                    break;
                case 180:
                case 181:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i10 = i11;
                    iFld += i16;
                    i11 = i10 + (i19 ^ i18);
                    iArr = iArr2;
                    break;
                case 182:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i10 = i11;
                    i11 = i10 + (i19 ^ i18);
                    iArr = iArr2;
                    break;
                case 183:
                case 184:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    iFld >>= i19;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 185:
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i3 = i11;
                    instanceCount += i3;
                    iArr = iArr2;
                    i2 = i13;
                    i11 = i3;
                    i13 = i2;
                    break;
                case 186:
                    instanceCount += i19 + i18;
                    iArr = iArr2;
                    fArr = fArr2;
                    jArr2 = jArr3;
                    jArr = jArr4;
                    i2 = i13;
                    i3 = i11;
                    i11 = i3;
                    i13 = i2;
                    break;
            }
            i12 = i19;
            iArr2 = iArr;
            fArr2 = fArr;
            jArr3 = jArr2;
            jArr4 = jArr;
        }
    }

    public int iMeth(long j, int i, short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 7);
        int i2 = -4;
        int i3 = 24;
        double d = -1.19643d;
        int i4 = 189;
        while (i4 > 10) {
            i2--;
            d = i4;
            while (d < 26.0d) {
                vMeth(14);
                byFld = (byte) (byFld - ((byte) i4));
                i += (int) d;
                i3 = 1;
                d += 1.0d;
            }
            i4 -= 3;
        }
        long doubleToLongBits = ((((((((j + i) + s) + i4) + i2) + Double.doubleToLongBits(d)) + 14) + i3) - 34437) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr;
        float[] fArr;
        int i;
        FuzzerUtils.init(new int[N], -64688);
        int i2 = 3;
        int i3 = 101;
        int i4 = 4;
        int i5 = -93;
        int i6 = -20696;
        int i7 = 6;
        int i8 = -118;
        int i9 = 25946;
        long j = -61015;
        while (i2 < 239) {
            int i10 = i5;
            int i11 = i6;
            int i12 = i7;
            long j2 = j;
            int i13 = 1;
            while (i13 < 106) {
                int iMeth = iMeth(-6L, i13, sFld) * i10;
                int i14 = (int) instanceCount;
                long j3 = 2;
                while (true) {
                    j3--;
                    if (j3 <= 0) {
                        break;
                    }
                    iFld ^= -937115070;
                    long j4 = instanceCount - i2;
                    instanceCount = j4;
                    iMeth = (int) dFld;
                    i11 *= i13;
                    fFld = i11;
                    iFld = iMeth;
                    long j5 = j4 - i14;
                    instanceCount = j5;
                    long j6 = i11;
                    long j7 = j5 - j6;
                    instanceCount = j7;
                    instanceCount = j7 - j6;
                }
                int i15 = 1;
                while (i15 < 2) {
                    iMeth %= byFld | 1;
                    i11 += iFld ^ i15;
                    i15 += 3;
                }
                instanceCount *= fFld;
                i13++;
                i8 = i8;
                i10 = i15;
                i12 = i10;
                i3 = i14;
                j2 = j3;
            }
            int i16 = (int) (i8 + (((float) ((i8 * i2) + j2)) - fFld));
            i3 += i10;
            fArrFld[i2] = fArr[i2] - 9.0f;
            int i17 = 1;
            while (true) {
                i3 = (i3 + i17) * sFld;
                i = i17 + 1;
                if (i >= 106) {
                    break;
                }
                i17 = i;
            }
            i2++;
            i8 = i16;
            i9 = i;
            i4 = i13;
            i5 = i10;
            i6 = i11;
            i7 = i12;
            j = j2;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i3 l1 i26 = " + i5 + "," + j + "," + i6);
        FuzzerUtils.out.println("i27 i28 i29 = " + i7 + "," + i8 + "," + i9);
        FuzzerUtils.out.println("i30 i31 iArr3 = 12196,-7197," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.fFld = " + instanceCount + "," + ((int) byFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.dFld Test.iFld bFld = " + Double.doubleToLongBits(dFld) + "," + iFld + "," + (this.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld Test.fArrFld = " + ((int) sFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
