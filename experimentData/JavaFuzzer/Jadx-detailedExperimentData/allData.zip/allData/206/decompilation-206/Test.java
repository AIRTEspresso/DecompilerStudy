
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/206/original-206/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -46520;
    public static volatile byte byFld = 121;
    public static short sFld = 22404;
    public static float fFld = -24.197f;
    public static long vMeth_check_sum = 0;
    public static long byMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    public static void vMeth1(int i, float f, int i2) {
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init(iArr, 11);
        FuzzerUtils.init((Object[][]) jArr, (Object) 798186012L);
        int i3 = i2;
        int i4 = 1;
        int i5 = 63555;
        int i6 = -994581114;
        while (182 > i4) {
            i6 &= i4;
            i3 >>= i4;
            i5 = i4;
            i4 += 2;
        }
        int i7 = 12;
        int i8 = -5614;
        int i9 = -9;
        double d = -74.81373d;
        double d2 = 55.117826d;
        while (i7 < 392) {
            double d3 = 1.0d;
            double d4 = 1.0d;
            while (d4 < 4.0d) {
                long[] jArr2 = jArr[i7 - 1][i7 + 1];
                jArr2[i7] = jArr2[i7] + i8;
                d4 += 1.0d;
                i3 = i3;
            }
            i3 += i7 * i7;
            byFld = (byte) (byFld + ((byte) (i7 - f)));
            int i10 = 1;
            while (i10 < 4) {
                d2 = d3;
                while (d2 < 2.0d) {
                    i8 = (int) instanceCount;
                    d3 = 1.0d;
                    d2 += 1.0d;
                    i5 = i6;
                }
                i10++;
            }
            i7++;
            i9 = i10;
            d = d4;
        }
        vMeth1_check_sum += ((((((((i6 + Float.floatToIntBits(f)) + i3) + i4) + i5) + i7) + i8) + Double.doubleToLongBits(d)) - 3) + i9 + 7 + Double.doubleToLongBits(d2) + 14 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum((Object[][]) jArr);
    }

    public static byte byMeth(long j, int i, long j2) {
        int[] iArr = new int[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, -23852L);
        FuzzerUtils.init(iArr, 5);
        int i2 = 6;
        int i3 = -16491;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 < 166) {
                vMeth1(i4, 2.422f, i);
                i2 = 1;
                while (i2 < 10) {
                    i2++;
                    i3 = 2;
                }
            } else {
                long floatToIntBits = ((((((i + j) + j2) + i4) + Float.floatToIntBits(2.422f)) + i2) - 2) + i3 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
                byMeth_check_sum += floatToIntBits;
                return (byte) floatToIntBits;
            }
        }
    }

    public static void vMeth(long j, boolean z) {
        double d;
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-55));
        double d2 = 273.0d;
        while (d2 > 16.0d) {
            byMeth(-28650L, -149, instanceCount);
            short s = sFld;
            Double.isNaN(-149);
            double d3 = -2.668f;
            Double.isNaN(d3);
            Double.isNaN(d3);
            sFld = (short) (s + ((short) (((d * d2) + d3) - d3)));
            d2 -= 1.0d;
            int i = (int) d2;
            iArr[(int) d2][i] = iArr[i][i];
        }
        vMeth_check_sum += (((j + (z ? 1L : 0L)) + Double.doubleToLongBits(d2)) - 149) + Float.floatToIntBits(-2.668f) + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        double[] dArr = new double[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(iArr, 60213);
        boolean z = true;
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(jArr, -9L);
        FuzzerUtils.init(dArr, 0.812d);
        int i = 163;
        int i2 = 20472;
        int i3 = -12500;
        long j = 4;
        long j2 = 1618798475;
        double d = 99.117018d;
        int i4 = 3;
        while (i4 < 134) {
            int i5 = i4 + 1;
            int i6 = iArr[i5];
            zArr[i4] = z;
            long j3 = jArr[i5] - 1;
            jArr[i5] = j3;
            vMeth(instanceCount, z);
            int i7 = (int) j3;
            j = 3;
            while (191 > j) {
                double d2 = i4;
                Double.isNaN(d2);
                double d3 = d - d2;
                i7 -= 105;
                i2 = 0;
                instanceCount -= i7;
                j++;
                int i8 = (int) j;
                jArr[i8] = jArr[i8] << (-13);
                i5 = i5;
                d = d3;
            }
            int i9 = i5;
            i = i7;
            i3 = 11;
            while (i3 < 191) {
                int i10 = i2 + i3;
                jArr[i4] = i4 & jArr[i4];
                j2 = 2;
                i = i;
                i2 = i10 >> i10;
                while (j2 > 1) {
                    dArr[i3] = dArr[i3] - d;
                    fFld *= i4;
                    iArr[i9] = i3;
                    i2 = ((int) (j2 + instanceCount)) + 6202;
                    byFld = (byte) (byFld + ((byte) (j2 * j2)));
                    byFld = (byte) -88;
                    j2--;
                    i = 4;
                }
                i3++;
            }
            i4 = i9;
            z = true;
        }
        FuzzerUtils.out.println("i i1 l3 = " + i4 + "," + i + "," + j);
        FuzzerUtils.out.println("i18 d3 i19 = " + i2 + "," + Double.doubleToLongBits(d) + "," + i3);
        FuzzerUtils.out.println("i20 l4 i21 = 35715," + j2 + ",243");
        FuzzerUtils.out.println("b1 iArr bArr = 1," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("lArr dArr = " + FuzzerUtils.checkSum(jArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + instanceCount + "," + ((int) byFld) + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.fFld = " + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
