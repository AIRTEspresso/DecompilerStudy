
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/173/original-173/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long instanceCount = 1723977013;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;
    public byte byFld = 15;
    public volatile float fFld = -93.335f;
    public boolean[][][] bArrFld = (boolean[][][]) Array.newInstance(boolean.class, N, N, N);

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 33391);
    }

    public static int iMeth(int i) {
        long j = i - 1;
        iMeth_check_sum += j;
        return (int) j;
    }

    public static void vMeth2() {
        vMeth2_check_sum += 172;
    }

    public static void vMeth1() {
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) 7937);
        vMeth2();
        int i = ((int) instanceCount) & 53;
        int i2 = -8;
        int i3 = 11268;
        byte b = 36;
        int i4 = 3;
        while (i4 < 226) {
            byte b2 = (byte) (-8681);
            instanceCount += 26;
            i2 = 1;
            do {
                i2++;
            } while (i2 < 7);
            i4++;
            b = b2;
            i3 = 1;
        }
        vMeth1_check_sum += ((i + i4) - 8681) + b + i2 + 0 + i3 + 21390 + FuzzerUtils.checkSum(sArr);
    }

    public static void vMeth(float f) {
        int i = 1;
        while (true) {
            i++;
            if (i >= 224) {
                break;
            }
            vMeth1();
        }
        int i2 = 173;
        int i3 = 64798;
        int i4 = -1;
        short s = -23269;
        while (i2 > 2) {
            long j = instanceCount ^ i2;
            instanceCount = j;
            i3 = i2 * (-110);
            iArrFld[i2] = i2;
            int i5 = (i2 % 2) + 61;
            if (i5 == 61) {
                instanceCount = i;
                try {
                    int i6 = (-10) / (37353 % (i2 % i2));
                } catch (ArithmeticException e) {
                }
                i3 = i2;
            } else if (i5 == 62) {
                s = (short) i4;
                instanceCount = j << i3;
                i4 -= i;
            }
            i2 -= 3;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + i + i2 + i3 + s + i4;
    }

    public void mainTest(String[] strArr) {
        double[] dArr = new double[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, 1447614521L);
        FuzzerUtils.init(dArr, 45.35738d);
        int iMeth = (int) ((-137) * (iMeth(-56875) + 12) * instanceCount);
        int i = 1;
        byte b = (byte) (this.byFld - 1);
        this.byFld = b;
        int i2 = iMeth << (b - 21451);
        vMeth(this.fFld);
        int i3 = (i2 >>> 1) % N;
        jArr[i3] = jArr[i3];
        while (true) {
            int i4 = i + 1;
            dArr[i4] = -126.10907d;
            int i5 = 101;
            while (i5 > 6) {
                boolean[][][] zArr = this.bArrFld;
                int i6 = i5 - 1;
                zArr[i6][i6] = zArr[i5 + 1][i6];
                i2 = 43276;
                this.byFld = (byte) (this.byFld + ((byte) i5));
                i5 -= 2;
            }
            i2 = (int) (i2 + (i ^ instanceCount));
            if (i4 < 248) {
                i = i4;
            } else {
                FuzzerUtils.out.println("i d i13 = " + i2 + "," + Double.doubleToLongBits(0.124347d) + "," + i4);
                FuzzerUtils.out.println("i14 i15 lArr = " + i5 + ",-12281," + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
                FuzzerUtils.out.println("Test.instanceCount byFld fFld = " + instanceCount + "," + ((int) this.byFld) + "," + Float.floatToIntBits(this.fFld));
                FuzzerUtils.out.println("Test.iArrFld bArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum((Object[][]) this.bArrFld));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
