
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/112/original-112/Test.dex */
public class Test {
    public volatile float fFld = 0.247f;
    public long lFld1 = -252;
    public static long instanceCount = -2548559245571105894L;
    public static float fFld1 = 52.1023f;
    public static volatile long lFld = -13;
    public static final int N = 400;
    public static int[][] iArrFld = (int[][]) Array.newInstance(int.class, N, N);
    public static volatile long[][] lArrFld = (long[][]) Array.newInstance(long.class, N, N);
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, -166);
        FuzzerUtils.init(lArrFld, -95L);
    }

    public static int iMeth(int i, boolean z, int i2) {
        int i3 = i2 - 1;
        instanceCount |= Math.abs(i2);
        float f = 292.0f;
        int i4 = 1;
        while (18.0f < f) {
            i4 = 6;
            while (i4 > 1) {
                int[] iArr = iArrFld[(int) (1.0f + f)];
                iArr[i4] = iArr[i4] - ((int) instanceCount);
                i4--;
            }
            f -= 1.0f;
        }
        long floatToIntBits = (((((i + (z ? 1 : 0)) + i3) + Float.floatToIntBits(f)) - 221) + i4) - 50464;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth2(float f, long j) {
        long j2 = j;
        double d = 0.114156d;
        int i = -8861;
        int i2 = -11554;
        int i3 = -11;
        int i4 = -8;
        int i5 = 11;
        int i6 = 5;
        while (i5 < 363) {
            i = (int) d;
            i2 = 1;
            while (true) {
                i3 = 1;
                while (i5 < i3) {
                    int[] iArr = iArrFld[i2 - 1];
                    int i7 = i3 + 1;
                    iArr[i7] = iArr[i7] + 14;
                    i6 = i3;
                    i3 -= 2;
                    i = i6;
                }
                i2++;
                if (i2 >= 5) {
                    break;
                }
            }
            d = j2;
            i6 = (int) (i6 + (i5 | instanceCount));
            i4 = 5;
            while (i4 > 1) {
                j2 -= i;
                i -= (int) f;
                int[] iArr2 = iArrFld[i5 - 1];
                int i8 = i4 - 1;
                iArr2[i8] = iArr2[i8] * i3;
                i4--;
            }
            i5++;
        }
        vMeth2_check_sum += ((((((((((Float.floatToIntBits(f) + j2) + i5) + i) + Double.doubleToLongBits(d)) + i2) + i3) + i6) + 0) + 0) + i4) - 50961;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:63:0x017e  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x015b A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void vMeth1() {
        /*
            Method dump skipped, instructions count: 454
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth1():void");
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(jArr, -138L);
        FuzzerUtils.init(iArr, -9);
        FuzzerUtils.init(zArr, false);
        int i = 11;
        double d = -2.60442d;
        int i2 = 19;
        while (i2 < 335) {
            float f = (float) instanceCount;
            long[] jArr2 = jArr[i2];
            long j = jArr2[i2];
            jArr2[i2] = j - 1;
            int i3 = (int) (f - ((-1.341f) - ((float) j)));
            try {
                int i4 = i2 % i3;
                iArr[i2] = i4 / 1;
                i3 = i4 % i4;
            } catch (ArithmeticException e) {
            }
            long j2 = i2;
            int i5 = i2 + 1;
            iMeth((int) ((instanceCount / (i2 | 1)) + j2), zArr[i5], -i3);
            vMeth1();
            instanceCount *= j2;
            i = 39601;
            double d2 = i2;
            Double.isNaN(d2);
            d += d2;
            i2 = i5;
        }
        int i6 = 50095;
        int i7 = 1;
        while (true) {
            i7 += 2;
            if (i7 < 350) {
                i6 = 1;
                while (i6 < 9) {
                    long j3 = instanceCount - 15974;
                    instanceCount = j3;
                    i = ((i - i6) << ((int) j3)) - ((int) j3);
                    i6++;
                }
            } else {
                vMeth_check_sum += i2 + i + Float.floatToIntBits(-1.341f) + Double.doubleToLongBits(d) + i7 + i6 + 27996 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(zArr);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int i;
        float f;
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, false);
        int i2 = 27922;
        int i3 = -53;
        int i4 = 203;
        int i5 = 5445;
        double d = -2.9433d;
        int i6 = 3;
        int i7 = 0;
        while (true) {
            char c = 1;
            int i8 = 64;
            if (i6 < 381) {
                i2 = 1;
                while (true) {
                    i = 2;
                    if (i2 >= 2) {
                        break;
                    }
                    this.fFld += i2 - this.fFld;
                    this.fFld += (float) (i2 + instanceCount);
                    zArr[i6] = false;
                    i2++;
                }
                vMeth();
                double d2 = d;
                int i9 = i5;
                int i10 = i7;
                int i11 = 1;
                double d3 = d2;
                while (i11 < i) {
                    d3 = i8;
                    this.fFld += i11;
                    int[][] iArr = iArrFld;
                    int[] iArr2 = iArr[0];
                    i11++;
                    iArr2[i11] = iArr2[i11] % (i3 | 1);
                    int i12 = ((i6 % 4) * 5) + 73;
                    if (i12 == 77) {
                        lFld = ((float) lFld) + (((f * fFld1) + i9) - ((float) this.lFld1));
                    } else if (i12 == 81) {
                        int[] iArr3 = iArr[i11];
                        int i13 = i6 + 1;
                        iArr3[i13] = iArr3[i13] ^ i6;
                    } else if (i12 == 84) {
                        i9 <<= (int) instanceCount;
                    } else if (i12 == 92) {
                        i9 >>= 64;
                        int[] iArr4 = iArr[i6 - 1];
                        iArr4[c] = iArr4[c] * 1910181863;
                    } else {
                        i3 = -13347;
                    }
                    i3 += i6;
                    zArr[i11] = false;
                    i9 -= i2;
                    i10 = (int) instanceCount;
                    i = 2;
                    c = 1;
                    i8 = 64;
                }
                fFld1 *= 32.0f;
                i6++;
                i4 = i11;
                i5 = i9;
                double d4 = d3;
                i7 = i10;
                d = d4;
            } else {
                FuzzerUtils.out.println("i i1 i2 = 1," + i6 + "," + i7);
                FuzzerUtils.out.println("i3 i4 b = " + i2 + "," + i3 + ",0");
                FuzzerUtils.out.println("i27 i28 d2 = " + i4 + "," + i5 + "," + Double.doubleToLongBits(d));
                FuzzerUtils.out.println("by s1 bArr = 64,-13347," + FuzzerUtils.checkSum(zArr));
                FuzzerUtils.out.println("Test.instanceCount fFld Test.fFld1 = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Float.floatToIntBits(fFld1));
                FuzzerUtils.out.println("Test.lFld lFld1 Test.iArrFld = " + lFld + "," + this.lFld1 + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
