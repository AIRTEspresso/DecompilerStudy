
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/145/original-145/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[][] fArrFld;
    public int[] iArrFld = new int[N];
    public static volatile long instanceCount = 54321;
    public static int iFld = 57895;
    public static volatile boolean bFld = true;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        float[][] fArr = (float[][]) Array.newInstance(float.class, N, N);
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 0.356f);
    }

    public static int iMeth(long j, float f) {
        int i;
        short[] sArr = new short[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(sArr, (short) 31140);
        FuzzerUtils.init(dArr, -74.19942d);
        int i2 = 231;
        int i3 = 1;
        do {
            j |= -1237057457;
            int i4 = i3 - 1;
            sArr[i4] = (short) (sArr[i4] >> ((short) i3));
            i = 1;
            while (true) {
                i++;
                if (i < 6) {
                    i2 = 1;
                } else {
                    i3++;
                }
            }
        } while (i3 < 254);
        long floatToIntBits = j + Float.floatToIntBits(f) + 0 + i3 + i + i2 + 93 + 0 + 22632 + Double.doubleToLongBits(-2.128752d) + FuzzerUtils.checkSum(sArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1() {
        float[] fArr = new float[N];
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(fArr, 1.596f);
        FuzzerUtils.init(iArr, -46583);
        float f = -3.913f;
        iMeth(-2932141964L, -3.913f);
        int i = 225;
        int i2 = -19169;
        int i3 = 30659;
        int i4 = -13;
        int i5 = 4;
        while (i5 < 318) {
            i = 13038 >> iFld;
            i2 = 1;
            while (i2 < 15) {
                iFld += (int) 90.21355d;
                int i6 = i2 - 1;
                fArr[i6] = fArr[i6] - (-132.0f);
                iArr[i2][i6] = i;
                i2 += 3;
                i3 = i5;
            }
            iFld += i5 * i5;
            int i7 = i5;
            while (i7 < 15) {
                f += i7;
                instanceCount = iFld;
                i7++;
            }
            i5 += 3;
            i4 = i7;
        }
        vMeth1_check_sum += Float.floatToIntBits(f) + i5 + i + i2 + i3 + Double.doubleToLongBits(90.21355d) + i4 + 9 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 1);
        vMeth1();
        iFld = 190;
        int i2 = i | ((int) instanceCount);
        int i3 = 4;
        int i4 = -139;
        int i5 = -55;
        float f = -9.42f;
        int i6 = 14;
        while (i6 < 273) {
            instanceCount -= f;
            instanceCount += 41127;
            i4 = 1;
            while (true) {
                i4++;
                if (i4 < 6) {
                    iFld = -35;
                    i2 += 186;
                    instanceCount += 3880;
                    instanceCount++;
                    f *= 2;
                    i3 = 2;
                    i5 = 2;
                }
            }
            i6++;
        }
        vMeth_check_sum += i2 + i6 + i3 + Float.floatToIntBits(f) + i4 + i5 + 3880 + 2 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        double d;
        int i3;
        int i4;
        float[] fArr;
        long[] jArr = new long[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(jArr, -9L);
        FuzzerUtils.init(zArr, true);
        jArr[151] = this.iArrFld[151];
        vMeth(45102);
        byte b = (byte) 1;
        double d2 = instanceCount;
        Double.isNaN(d2);
        double d3 = 125.45846d - d2;
        jArr[151] = jArr[151] + 45102;
        int i5 = -43;
        int i6 = 45102;
        int i7 = 1;
        while (145 > i7) {
            int i8 = (i7 * i7) + i5;
            try {
                int i9 = iFld / i7;
                i6 = 23869 % i7;
                this.iArrFld[i7 + 1] = this.iArrFld[i7 - 1] / (-9641);
            } catch (ArithmeticException e) {
            }
            i7++;
            i5 = i8;
        }
        int i10 = 16846;
        int i11 = 0;
        int i12 = -63869;
        short s = 9910;
        int i13 = i6;
        long j = 1;
        while (true) {
            short s2 = s;
            int i14 = i13;
            int i15 = 232;
            while (true) {
                i = i12;
                if (i15 <= 4) {
                    break;
                }
                i14 += (int) instanceCount;
                instanceCount *= -19;
                int i16 = (int) 83.183f;
                iFld *= i16;
                i12 = i;
                int i17 = 1;
                while (true) {
                    i2 = i5;
                    if (i17 < 2) {
                        int i18 = (int) j;
                        i12 = (i12 * i18) - 1;
                        iFld ^= i10;
                        int[] iArr = this.iArrFld;
                        int i19 = i17 - 1;
                        iArr[i19] = iArr[i19] - i17;
                        zArr[i15 + 1] = bFld;
                        int i20 = ((i15 % 4) * 5) + 78;
                        int i21 = i10;
                        if (i20 != 82 && i20 != 91) {
                            if (i20 != 97) {
                                i3 = i7;
                                d = d3;
                                if (i20 != 98) {
                                    i5 = i2;
                                    i10 = i21;
                                } else {
                                    i4 = i21;
                                }
                            } else {
                                i3 = i7;
                                fArrFld[(int) (j + 1)][i15] = fArr[i15] - 10.0f;
                                i14 += i16;
                                d = d3;
                                i5 = i2;
                                i10 = i21;
                            }
                            i17++;
                            i7 = i3;
                            d3 = d;
                        } else {
                            i3 = i7;
                            iFld = 188;
                            d = d3;
                            instanceCount += i17;
                            s2 = (short) i17;
                            i4 = 188;
                        }
                        jArr[181] = i12 ^ jArr[181];
                        bFld = bFld;
                        instanceCount >>= -736314550;
                        i10 = i4;
                        i5 = i18;
                        i17++;
                        i7 = i3;
                        d3 = d;
                    }
                }
                i15--;
                i11 = i17;
                i5 = i2;
            }
            int i22 = i7;
            double d4 = d3;
            j += 3;
            if (j >= 325) {
                FuzzerUtils.out.println("i by1 d2 = " + i14 + "," + ((int) b) + "," + Double.doubleToLongBits(d4));
                FuzzerUtils.out.println("i18 i19 i20 = " + i22 + "," + i5 + ",-9641");
                FuzzerUtils.out.println("l1 i21 i22 = " + j + "," + i15 + "," + i10);
                FuzzerUtils.out.println("f3 i23 i24 = " + Float.floatToIntBits(83.183f) + "," + i11 + "," + i);
                FuzzerUtils.out.println("s2 lArr bArr = " + ((int) s2) + "," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(zArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
                FuzzerUtils.out.println("iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
            i12 = i;
            i7 = i22;
            jArr = jArr;
            i13 = i14;
            s = s2;
            d3 = d4;
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
