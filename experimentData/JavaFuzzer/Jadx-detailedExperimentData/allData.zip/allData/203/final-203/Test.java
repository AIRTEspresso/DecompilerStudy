 class Test {
 int N = 400;
long instanceCount;
void vMeth1(int i7 , long l , int i8){
 boolean bArr[][][]= new boolean[N][N][N];
init(bArr , true);
}
 void vMeth(int i1 , int i2 , int i3){
 int i4 , i5 , i6 = 12;
i4 = 1;
do for(i5 = 1;
i5 < 6;
i5 ++)switch(i4){
 case 44 : vMeth1(i3 , instanceCount , 52);
switch(i4){
 case 28 : case 29 : i6 >>>= instanceCount;
case 30 : if(i4 != 0)return;
}
 }
 while(++ i4 < 262);
}
 float fMeth(){
 int i14 = 160;
vMeth(21017 , i14 , i14);
long meth_res = i14;
return meth_res;
}
 void mainTest(String[]strArr1){
 int i = 3;
i += fMeth();
}
 public static void main(String[]strArr){
 try {
 Test _instance = new Test();
_instance.mainTest(strArr);
}
 catch(Exception ex){
 System.out.println(ex);
}
 }
 void init(Object[]a , Object seed){
 for(int j = 0;
;
)a[j]= seed;
}
 }
