/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/198/original-198/Test.dex */
public class Test {
    public static int[] iArrFld;
    public boolean bFld = true;
    public float fFld = -36.1f;
    public static long instanceCount = -5222;
    public static volatile int iFld = 88;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static double[] dArrFld = new double[N];
    public static long vMeth_check_sum = 0;
    public static long fMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -2);
        FuzzerUtils.init(lArrFld, 51240L);
        FuzzerUtils.init(dArrFld, 0.119512d);
    }

    public static void vMeth1(int i, int i2, int i3) {
        double d;
        float f;
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -1.329f);
        fArr[226] = fArr[226] * iFld;
        short s = -16932;
        int i4 = 14;
        while (true) {
            d = 124.113852d;
            f = 0.781f;
            if (265 <= i4) {
                break;
            }
            long j = i4;
            instanceCount = j;
            i = ((int) 124.113852d) + i4;
            iArrFld[i4] = (int) j;
            s = (short) (s + ((short) 0.781f));
            i4++;
        }
        iFld = (int) 0.781f;
        iFld = i;
        int i5 = 320;
        do {
            long j2 = instanceCount;
            instanceCount = j2 * j2;
            double d2 = i;
            Double.isNaN(d2);
            d += d2;
            iFld += i;
            f += i5 + i5;
            iFld = i5;
            i5 -= 2;
        } while (i5 > 0);
        vMeth1_check_sum += i + i2 + i3 + i4 + 135 + Double.doubleToLongBits(d) + s + Float.floatToIntBits(f) + i5 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static float fMeth(int i, float f) {
        vMeth1(i, i, i);
        long floatToIntBits = (i >> i) + Float.floatToIntBits(f);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0041, code lost:
        if (r3 != 125) goto L21;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void vMeth(int r14) {
        /*
            long r0 = defpackage.Test.instanceCount
            int[] r2 = defpackage.Test.iArrFld
            int r3 = r14 >>> 1
            int r3 = r3 % 400
            r3 = r2[r3]
            r4 = -25327(0xffffffffffff9d11, float:NaN)
            int r3 = r3 * (-25327)
            long r5 = (long) r3
            long r5 = r5 * r0
            double r5 = (double) r5
            r7 = 4603121793231995074(0x3fe192e1ef73c0c2, double:0.54918)
            java.lang.Double.isNaN(r5)
            double r7 = r7 - r5
            int r3 = r14 + (-240)
            int r3 = (-14227) - r3
            r5 = 1
            int r3 = r3 >>> r5
            int r3 = r3 % 4
            int r3 = r3 * 5
            int r3 = r3 + 110
            r6 = 113(0x71, float:1.58E-43)
            r9 = -31164(0xffffffffffff8644, float:NaN)
            r10 = -10
            r11 = 54959(0xd6af, float:7.7014E-41)
            if (r3 == r6) goto L67
            r2 = 117(0x75, float:1.64E-43)
            if (r3 == r2) goto L46
            r2 = 121(0x79, float:1.7E-43)
            if (r3 == r2) goto L44
            r0 = 125(0x7d, float:1.75E-43)
            if (r3 == r0) goto L4e
            goto L70
        L44:
            double r7 = (double) r0
            goto L70
        L46:
            int r0 = defpackage.Test.iFld
            r1 = 1064849900(0x3f7851ec, float:0.97)
            fMeth(r0, r1)
        L4e:
            r0 = 7
            r10 = 7
        L50:
            r0 = 175(0xaf, float:2.45E-43)
            if (r10 >= r0) goto L70
            int r0 = r10 % 1
            r1 = 28
            int r0 = r0 + r1
            if (r0 == r1) goto L5d
            int r11 = r11 >> r9
            goto L64
        L5d:
            long r0 = defpackage.Test.instanceCount
            long r2 = (long) r10
            long r0 = r0 + r2
            defpackage.Test.instanceCount = r0
        L64:
            int r10 = r10 + 1
            goto L50
        L67:
            r0 = 97
            r1 = r2[r0]
            int r1 = r1 * (-25327)
            r2[r0] = r1
        L70:
            r0 = 1124052894(0x42ffaf9e, float:127.843)
            long r1 = defpackage.Test.vMeth_check_sum
            long r12 = (long) r14
            long r6 = java.lang.Double.doubleToLongBits(r7)
            long r12 = r12 + r6
            long r3 = (long) r4
            long r12 = r12 + r3
            long r3 = (long) r10
            long r12 = r12 + r3
            long r3 = (long) r11
            long r12 = r12 + r3
            long r3 = (long) r5
            long r12 = r12 + r3
            long r3 = (long) r9
            long r12 = r12 + r3
            int r14 = java.lang.Float.floatToIntBits(r0)
            long r3 = (long) r14
            long r12 = r12 + r3
            long r1 = r1 + r12
            defpackage.Test.vMeth_check_sum = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth(int):void");
    }

    public void mainTest(String[] strArr) {
        int i;
        iFld = (int) (instanceCount * ((iFld % 27) - (iFld - 43)));
        long j = instanceCount;
        int i2 = iFld + iFld;
        iFld = iFld + 1;
        instanceCount = j >>> ((int) ((i2 + i) * 3325148203513961961L));
        byte b = 26;
        int i3 = -201;
        int i4 = -50780;
        int i5 = -13;
        int i6 = -34538;
        int i7 = -107;
        short s = -9896;
        int i8 = 3;
        while (true) {
            double d = -41.74295d;
            if (i8 < 152) {
                vMeth(249);
                iFld -= (int) instanceCount;
                i4 = 6;
                while (i4 < 168) {
                    short s2 = s;
                    int i9 = i7;
                    int i10 = 1;
                    int i11 = i3;
                    byte b2 = b;
                    int i12 = i11;
                    while (i10 < 2) {
                        int i13 = ((i10 % 7) * 5) + 108;
                        if (i13 == 109) {
                            i12 = (int) (i9 + (((i10 * i4) + i5) - instanceCount));
                            this.fFld -= s2;
                        } else if (i13 == 119) {
                            i5 += i10 ^ i8;
                        } else if (i13 == 125) {
                            switch ((i8 % 4) + 90) {
                                case 90:
                                    int i14 = (i10 ^ s2) + i12;
                                    try {
                                        iArrFld[i8 + 1] = (-35219) / i10;
                                        iFld = (-18791) / i9;
                                        iFld = (-257669378) % i9;
                                    } catch (ArithmeticException e) {
                                    }
                                    switch ((i10 % 8) + 21) {
                                        case 21:
                                            instanceCount -= i14;
                                            break;
                                        case 22:
                                        case 23:
                                            long j2 = i4;
                                            instanceCount = j2;
                                            i9 += i8;
                                            int[] iArr = iArrFld;
                                            iArr[i8] = iArr[i8] + ((int) j2);
                                            break;
                                        case 24:
                                            i5 -= iFld;
                                        case 25:
                                            i9 += i10 * i4;
                                            break;
                                        case 26:
                                            i14 += (i10 * i10) + 5118;
                                        case 27:
                                            iArrFld = iArrFld;
                                            break;
                                        case 28:
                                            i14 += i10 ^ i4;
                                            break;
                                    }
                                    i12 = i14;
                                    break;
                                case 91:
                                    if (this.bFld) {
                                        break;
                                    }
                                case 92:
                                    i5 = -8;
                                    break;
                                case 93:
                                    i9 ^= -44;
                                    break;
                                default:
                                    i9 += i10;
                                    break;
                            }
                        } else if (i13 == 132) {
                            i5 = (int) instanceCount;
                            double[] dArr = dArrFld;
                            dArr[i4] = dArr[i4] - d;
                        } else if (i13 == 140) {
                            boolean z = this.bFld;
                            if (!z) {
                                i9 >>>= i4;
                                if (!z) {
                                    iFld *= (int) instanceCount;
                                }
                            }
                        } else if (i13 == 134) {
                            i12 += i5;
                        } else if (i13 == 135) {
                            i9 = (i9 % (iFld | 1)) * ((int) this.fFld);
                            s2 = (short) (s2 + ((short) (iFld * i10)));
                            instanceCount += i10;
                        } else {
                            b2 = (byte) (b2 << ((byte) i5));
                        }
                        i10++;
                        d = -41.74295d;
                    }
                    i4++;
                    i6 = i10;
                    i7 = i9;
                    s = s2;
                    d = -41.74295d;
                    byte b3 = b2;
                    i3 = i12;
                    b = b3;
                }
                i8++;
            } else {
                FuzzerUtils.out.println("by i i1 = " + ((int) b) + "," + i8 + "," + i3);
                FuzzerUtils.out.println("i13 i14 i15 = " + i4 + "," + i5 + "," + i6);
                FuzzerUtils.out.println("i16 s2 d2 = " + i7 + "," + ((int) s) + "," + Double.doubleToLongBits(-41.74295d));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld bFld = " + instanceCount + "," + iFld + "," + (this.bFld ? 1 : 0));
                FuzzerUtils.out.println("fFld Test.iArrFld Test.lArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
                FuzzerUtils.out.println("Test.dArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
