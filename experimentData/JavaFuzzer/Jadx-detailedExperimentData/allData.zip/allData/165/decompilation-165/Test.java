
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/165/original-165/Test.dex */
public class Test {
    public static float[] fArrFld;
    public static long instanceCount = 860701209;
    public static double dFld = 112.82618d;
    public static final int N = 400;
    public static boolean[] bArrFld = new boolean[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public int iFld = -6;
    public boolean bFld = false;
    public float fFld = -2.148f;
    public int iFld1 = 61239;
    public short sFld = -16465;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 2.96f);
        FuzzerUtils.init(bArrFld, false);
    }

    public static int iMeth(long j, short s, byte b) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(iArr, 36361);
        FuzzerUtils.init(fArr, 0.791f);
        FuzzerUtils.init(sArr, (short) -1473);
        int i = 10809;
        float f = -1.877f;
        int i2 = 28;
        int i3 = 20;
        while (i3 < 355) {
            int i4 = i - ((int) f);
            f -= (float) (-1.76724d);
            int i5 = i3 + 1;
            iArr[i5] = iArr[i5] + i4;
            i = i4 << i3;
            i2 = (i2 - ((int) (-1.76724d))) + i3;
            i3 = i5;
        }
        long floatToIntBits = s + j + b + i2 + i3 + i + Float.floatToIntBits(f) + Double.doubleToLongBits(-1.76724d) + Double.doubleToLongBits(-2.18497d) + 45960 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(sArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void vMeth1(int i) {
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) 6L);
        FuzzerUtils.init(iArr, -2);
        int i2 = 17541;
        short s = 21855;
        int i3 = 11;
        while (i3 < 319) {
            i2 = iMeth(-2221516662478642684L, s, (byte) -33);
            this.iFld = i2;
            s = (short) (s - ((short) (-76.726f)));
            i3++;
        }
        long j = instanceCount;
        long j2 = j - j;
        instanceCount = j2;
        instanceCount = j2 * j2;
        long[][] jArr2 = jArr[(this.iFld >>> 1) % N];
        int i4 = (i3 >>> 1) % N;
        long[] jArr3 = jArr2[i4];
        jArr3[i4] = jArr3[i4] - i;
        float[] fArr = fArrFld;
        fArr[i4] = fArr[i4] + i3;
        this.bFld = this.bFld;
        vMeth1_check_sum += (((((i << i3) + i3) + i2) + s) - 33) + Float.floatToIntBits(-76.726f) + FuzzerUtils.checkSum((Object[][]) jArr) + FuzzerUtils.checkSum(iArr);
    }

    public void vMeth(int i, long j, double d) {
        int[] iArr = new int[N];
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        FuzzerUtils.init(dArr, 126.36653d);
        FuzzerUtils.init(iArr, -12577);
        int i2 = i;
        int i3 = -1542;
        short s = 3442;
        int i4 = 16;
        while (i4 < 353) {
            vMeth1(-32056);
            long j2 = i4;
            s = (short) (s + ((short) (j2 - instanceCount)));
            int i5 = this.iFld >> 51;
            this.iFld = i5;
            int i6 = i5 >> i5;
            this.iFld = i6;
            boolean z = this.bFld;
            if (!z) {
                this.iFld = (int) (i6 + (((i4 * i2) + s) - this.fFld));
                if (z) {
                    double[] dArr2 = dArr[i4 + 1];
                    int i7 = i4 - 1;
                    double d2 = dArr2[i7];
                    double d3 = i2;
                    Double.isNaN(d3);
                    dArr2[i7] = d2 + d3;
                } else if (z) {
                    continue;
                } else {
                    i2 -= (int) dFld;
                }
                i3 = 1;
                while (i3 < 5) {
                    this.fFld += (i3 * i3) - 130;
                    if (this.iFld1 != 0) {
                        vMeth_check_sum += ((((i2 + j) + Double.doubleToLongBits(d)) + j2) - 62) + s + i3 + 8 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr);
                        return;
                    } else {
                        iArr[i4 - 1] = i3;
                        i3++;
                    }
                }
                continue;
            }
            i4++;
        }
        vMeth_check_sum += ((((i2 + j) + Double.doubleToLongBits(d)) + i4) - 62) + s + i3 + 8 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -62);
        FuzzerUtils.init(iArr, -23504);
        FuzzerUtils.init(dArr, 2.109179d);
        byte b = bArr[(this.iFld >>> 1) % N];
        this.iFld = b;
        vMeth(b, 4085723069L, dFld);
        for (int i = 0; i < 400; i++) {
            byte b2 = bArr[i];
            instanceCount = -403528749L;
            this.fFld -= this.iFld1;
        }
        iArr[396] = -10;
        instanceCount = this.fFld;
        this.sFld = (short) (this.sFld - ((short) this.iFld1));
        int i2 = 275;
        int i3 = -13;
        int i4 = -40;
        double d = 89.103368d;
        while (true) {
            i2--;
            if (i2 > 0) {
                this.bFld = this.bFld;
                double d2 = 1.0d;
                double d3 = 1.0d;
                while (true) {
                    d3 += d2;
                    if (d3 < 91.0d) {
                        long j = instanceCount;
                        this.iFld = (int) j;
                        float f = this.fFld;
                        double d4 = j;
                        Double.isNaN(d4);
                        double d5 = i2;
                        Double.isNaN(d5);
                        Double.isNaN(d5);
                        this.fFld = f + ((float) (((d4 * d3) + d5) - d5));
                        int i5 = i2;
                        while (i5 < 1) {
                            instanceCount = this.iFld1;
                            i5++;
                        }
                        int i6 = i5;
                        d2 = 1.0d;
                        double[] dArr2 = dArr[(int) (d3 - 1.0d)];
                        int i7 = i2 - 1;
                        double d6 = dArr2[i7];
                        Double.isNaN(d5);
                        dArr2[i7] = d6 + d5;
                        i3 = i6;
                        i4 = 1;
                    }
                }
                d = d3;
            } else {
                FuzzerUtils.out.println("i12 d3 i13 = " + i2 + "," + Double.doubleToLongBits(d) + "," + i3);
                FuzzerUtils.out.println("i14 i15 i16 = -3," + i4 + ",45");
                FuzzerUtils.out.println("byArr iArr3 dArr1 = " + FuzzerUtils.checkSum(bArr) + "," + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
                FuzzerUtils.out.println("Test.instanceCount iFld Test.dFld = " + instanceCount + "," + this.iFld + "," + Double.doubleToLongBits(dFld));
                FuzzerUtils.out.println("bFld fFld iFld1 = " + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(this.fFld) + "," + this.iFld1);
                FuzzerUtils.out.println("sFld Test.fArrFld Test.bArrFld = " + ((int) this.sFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
