
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/207/original-207/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public volatile byte byFld = 68;
    public float fFld = -2.386f;
    public volatile short[] sArrFld = new short[N];
    public static long instanceCount = -3;
    public static long vMeth_check_sum = 0;
    public static long dMeth_check_sum = 0;
    public static long byMeth_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 55.666f);
    }

    public static byte byMeth(long j, long j2, int i) {
        int i2;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 96.95171d);
        int i3 = 235;
        do {
            dArr[i3 + 1] = 24951.0d;
            i2 = 1;
            while (7 > i2) {
                i2++;
            }
            i3--;
        } while (i3 > 0);
        long floatToIntBits = ((((((j + j2) + i) + i3) + i2) + 97) - 252) + 245 + Float.floatToIntBits(-78.772f) + 0 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        byMeth_check_sum += floatToIntBits;
        return (byte) floatToIntBits;
    }

    public static double dMeth(int i, long j) {
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-14));
        FuzzerUtils.init(dArr, 35.20581d);
        int i2 = 8;
        while (i2 < 189) {
            i2++;
        }
        double d = 156.0d;
        int i3 = 25163;
        int i4 = 39624;
        float f = -1.842f;
        while (d > 5.0d) {
            int i5 = (int) (d + 1.0d);
            int i6 = (int) d;
            int[] iArr2 = iArr[i5][i6];
            int i7 = (int) (d - 1.0d);
            int i8 = iArr2[i7];
            iArr2[i7] = i8 + 1;
            double d2 = -i8;
            double d3 = dArr[i6][i5];
            Double.isNaN(d2);
            int i9 = i4 - ((int) (d2 * d3));
            byMeth(instanceCount, j, i9);
            j = -2;
            float[] fArr = fArrFld;
            fArr[i7] = fArr[i7] - 3.54143616E9f;
            i4 = i9 - 115;
            f = 50.0f;
            d -= 2.0d;
            i3 = i;
        }
        int[] iArr3 = iArr[41][(i2 >>> 1) % N];
        iArr3[0] = iArr3[0] + 32168;
        long doubleToLongBits = i + j + i2 + i3 + Double.doubleToLongBits(d) + i4 + Float.floatToIntBits(f) + 62400 + FuzzerUtils.checkSum((Object[][]) iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        dMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public static void vMeth(float f, short s, byte b) {
        short s2;
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -11981);
        FuzzerUtils.init(fArr, 94.829f);
        FuzzerUtils.init(jArr, -2086867153L);
        float f2 = f;
        short s3 = s;
        int i = 15;
        int i2 = 49946;
        int i3 = 13;
        int i4 = 0;
        for (int i5 = N; i4 < i5; i5 = N) {
            int i6 = iArr[i4];
            int i7 = (i6 >>> 1) % i5;
            short s4 = (short) (s3 - 1);
            fArr[i7] = fArr[i7] * s4;
            int reverseBytes = (((Integer.reverseBytes(i6) >>> 1) % 4) * 5) + 120;
            if (reverseBytes != 127) {
                if (reverseBytes == 135) {
                    s2 = s4;
                    int i8 = iArr[57];
                } else if (reverseBytes == 138) {
                    s2 = s4;
                    dMeth(i6, instanceCount);
                    fArr[i7] = fArr[i7] * (-47907.0f);
                    int i9 = i2;
                    int i10 = 1;
                    while (i10 < 4) {
                        instanceCount += i10;
                        float f3 = 125;
                        try {
                            int i11 = iArr[0] / i10;
                            iArr[i10] = 1;
                        } catch (ArithmeticException e) {
                        }
                        i3 = 2;
                        int i12 = i10;
                        i10++;
                        f2 = f3;
                        i9 = i12;
                    }
                    i = i10;
                    i2 = i9;
                } else if (reverseBytes != 139) {
                    s2 = s4;
                } else {
                    s2 = s4;
                }
                i4++;
                s3 = s2;
            } else {
                s2 = s4;
                i2 <<= i3;
            }
            instanceCount = -241;
            i4++;
            s3 = s2;
        }
        vMeth_check_sum += ((((((Float.floatToIntBits(f2) + s3) + b) + i) + i2) + i3) - 241) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr);
    }

    public void mainTest(String[] strArr) {
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) (-13));
        FuzzerUtils.init(jArr, -8L);
        long j = -23635;
        vMeth(0.215f, (short) -21836, (byte) 83);
        int i = (((-23636) - ((int) (j + ((instanceCount + j) - (-23634))))) >>> 1) % N;
        iArr[i][i][i] = -21836;
        int i2 = -4;
        int i3 = 1;
        do {
            i2 &= (int) instanceCount;
            i3 += 3;
        } while (i3 < 132);
        int i4 = 22;
        while (i4 < 389) {
            i4++;
        }
        FuzzerUtils.out.println("i f3 s1 = 51656," + Float.floatToIntBits(0.215f) + ",-21836");
        FuzzerUtils.out.println("i17 i18 i19 = " + i3 + "," + i2 + "," + i4);
        FuzzerUtils.out.println("i20 b1 i21 = 33819,1,-23645");
        FuzzerUtils.out.println("i22 i23 i24 = -175,2688,10");
        FuzzerUtils.out.println("i25 i26 iArr2 = 7,-2," + FuzzerUtils.checkSum((Object[][]) iArr));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount byFld fFld = " + instanceCount + "," + ((int) this.byFld) + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.fArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("byMeth_check_sum: " + byMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
