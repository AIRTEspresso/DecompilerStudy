
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/148/original-148/Test.dex */
public class Test {
    public double dFld = -59.36948d;
    public short sFld = -21197;
    public static long instanceCount = -7;
    public static volatile int iFld = 70;
    public static int iFld1 = 1328;
    public static byte byFld = -5;
    public static float fFld = 1.37f;
    public static int iFld2 = -37124;
    public static final int N = 400;
    public static double[] dArrFld = new double[N];
    public static byte[] byArrFld = new byte[N];
    public static short[] sArrFld = new short[N];
    public static long[][] lArrFld = (long[][]) Array.newInstance(long.class, N, N);
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    static {
        FuzzerUtils.init(dArrFld, 15.99761d);
        FuzzerUtils.init(byArrFld, (byte) -94);
        FuzzerUtils.init(sArrFld, (short) 2505);
        FuzzerUtils.init(lArrFld, -8L);
    }

    public static int iMeth1() {
        iFld += iFld;
        float f = iFld;
        int i = 7813;
        int i2 = 41;
        int i3 = 10;
        int i4 = 42848;
        double d = 0.81882d;
        int i5 = 15;
        while (293 > i5) {
            double[] dArr = dArrFld;
            int i6 = i5 + 1;
            double d2 = dArr[i6];
            double d3 = i5;
            Double.isNaN(d3);
            dArr[i6] = d2 + d3;
            i2 = i5;
            while (i2 < 6) {
                byArrFld[i2] = (byte) iFld;
                i = 13;
                double d4 = -11;
                Double.isNaN(d4);
                d -= d4;
                i4 = -1;
                iFld = (int) instanceCount;
                i2++;
                i3 = 1;
            }
            i5 = i6;
        }
        long floatToIntBits = ((((Float.floatToIntBits(f) + i5) + i) + i2) - 11) + i3 + i4 + Double.doubleToLongBits(d);
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(int i, long j) {
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -16508);
        int i3 = (i >>> 1) % N;
        iArr[i3] = iArr[i3] + ((iMeth1() + i2) - 18514);
        int i4 = (i >> i) << iFld;
        instanceCount *= iFld;
        vMeth_check_sum += i4 + j + 23979 + 0 + 1174 + 135 + Float.floatToIntBits(-30.798f) + 1 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -35082);
        vMeth(9323, 205L);
        int i = 651;
        long j = -4;
        try {
            iArr = FuzzerUtils.int1array(N, -46273);
            iArr[342] = 2625;
            iFld1 = -16070;
            i = 323;
            while (12 < i) {
                i -= 3;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            iFld1 = iFld;
        } catch (NullPointerException e2) {
            j = (-4) >>> iFld;
        }
        long doubleToLongBits = (((Double.doubleToLongBits(-101.18504d) + 0) + i) - 14) + j + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -35);
        double d = this.dFld;
        double iMeth = iMeth();
        double d2 = this.dFld;
        Double.isNaN(iMeth);
        this.dFld = d - (iMeth - d2);
        int i = 325;
        while (i > 17) {
            long j = instanceCount;
            instanceCount = j;
            iFld1 &= 228;
            instanceCount = j + ((long) this.dFld);
            int i2 = i + 1;
            iArr[i2] = iArr[i2] + 2;
            fFld = 0.885f;
            i--;
        }
        FuzzerUtils.out.println("i13 i14 f2 = " + i + ",4," + Float.floatToIntBits(0.885f));
        FuzzerUtils.out.println("i15 i16 i17 = 51409,0,-50894");
        FuzzerUtils.out.println("i18 i19 i20 = 23808,4,12709");
        FuzzerUtils.out.println("i21 iArr2 = 14," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount dFld Test.iFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + iFld);
        FuzzerUtils.out.println("Test.iFld1 Test.byFld Test.fFld = " + iFld1 + "," + ((int) byFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iFld2 sFld Test.dArrFld = " + iFld2 + "," + ((int) this.sFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.byArrFld Test.sArrFld Test.lArrFld = " + FuzzerUtils.checkSum(byArrFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
