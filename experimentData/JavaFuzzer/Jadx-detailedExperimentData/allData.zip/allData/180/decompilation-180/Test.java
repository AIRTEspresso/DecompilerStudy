
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/180/original-180/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long instanceCount = -22450;
    public static short sFld = -5318;
    public static boolean bFld = false;
    public static short sFld1 = -9894;
    public static float fFld = 0.378f;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth2_check_sum = 0;
    public float[] fArrFld = new float[N];
    public double[] dArrFld = new double[N];

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -209);
    }

    public void vMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 3608);
        int i = 0;
        long j = 448096626;
        int i2 = 0;
        int i3 = -10;
        float f = -117.326f;
        double d = 0.74801d;
        int i4 = 7;
        for (int i5 = N; i < i5; i5 = N) {
            int i6 = iArr[i];
            float f2 = f;
            long j2 = j;
            double d2 = d;
            int i7 = i4;
            int i8 = 1;
            while (4 > i8) {
                int i9 = (int) 1;
                iArr[i9] = iArr[i9] >>> i9;
                int[] iArr2 = iArr;
                long reverseBytes = instanceCount + (Short.reverseBytes(sFld) - ((int) instanceCount));
                instanceCount = reverseBytes;
                f2 = (float) reverseBytes;
                int i10 = i2 + ((int) (((float) ((i2 * 1) + sFld)) - f2));
                Math.min(-30843, i8);
                double d3 = i10;
                Double.isNaN(d3);
                d2 *= d3;
                i2 = i10 + 1;
                i7 = 1;
                while (i7 < 2) {
                    float[] fArr = this.fArrFld;
                    this.fArrFld = fArr;
                    this.fArrFld = fArr;
                    long j3 = iArr2[i7];
                    instanceCount = j3;
                    int i11 = i2 % ((int) (j3 | 1));
                    int i12 = i7 + 1;
                    int i13 = iArr2[i12] + 1;
                    iArr2[i12] = i13;
                    i2 = Math.abs(i13) + i7 + i7 + 245 + i8;
                    i7 = i12;
                }
                i8++;
                iArr = iArr2;
                j2 = 2;
            }
            i++;
            i3 = i8;
            i4 = i7;
            d = d2;
            j = j2;
            f = f2;
        }
        vMeth_check_sum += i3 + i2 + Double.doubleToLongBits(d) + j + Float.floatToIntBits(f) + i4 + 156 + 245 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth2(boolean z) {
        int[] iArr = new int[N];
        float[][][] fArr = (float[][][]) Array.newInstance(float.class, N, N, N);
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, -53761);
        FuzzerUtils.init((Object[][]) fArr, (Object) Float.valueOf(90.987f));
        FuzzerUtils.init(dArr, 0.40053d);
        int i = -216;
        int i2 = -13;
        int i3 = 0;
        int i4 = 40089;
        int i5 = 142;
        while (i5 > 7) {
            fArr[i5][i5][i5] = 38.337f;
            i2 = i5;
            while (i2 < 34) {
                dArr[i2 - 1] = 0.804f;
                i3 = 2;
                i = ((int) (i + (i2 + instanceCount))) - 2;
                i2++;
                i4 = 1;
            }
            i5 -= 3;
        }
        vMeth2_check_sum += (((((((((z ? 1 : 0) + i5) + i) + i2) + 27621) + Float.floatToIntBits(0.804f)) + i3) + i4) - 1) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static int iMeth(int i, byte b, float f) {
        int i2;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 5L);
        vMeth2(bFld);
        int i3 = -36931;
        int i4 = 1;
        int i5 = i;
        float f2 = f;
        double d = 117.70311d;
        int i6 = -202;
        int i7 = -65326;
        do {
            i2 = 1;
            while (i2 < 9) {
                switch (((i4 >>> 1) % 10) + 1) {
                    case 1:
                        sFld = (short) (sFld + ((short) (((i2 * i3) + instanceCount) - i5)));
                        i6 = 1;
                        while (i6 < 2) {
                            long j = instanceCount + i2;
                            instanceCount = j;
                            long j2 = j + i6;
                            instanceCount = j2;
                            d = (d + d) - 2.534579257E9d;
                            f2 += i6;
                            i7 = sFld1;
                            i5 = (int) j2;
                            i6++;
                        }
                        i5 += 455988198;
                        break;
                    case 2:
                        iArrFld[i2] = i2;
                        break;
                    case 3:
                        sFld1 = (short) (sFld1 + ((short) instanceCount));
                        break;
                    case 4:
                        jArr[(i2 >>> 1) % N] = i5;
                    case 5:
                        i7 = i2;
                        break;
                    case 6:
                        i5 = (int) instanceCount;
                    case 7:
                        i3 = (int) d;
                        break;
                    case 8:
                        instanceCount = i6;
                        break;
                    case 9:
                        i3 = (int) d;
                    case 10:
                        boolean z = bFld;
                        break;
                    default:
                        int[] iArr = iArrFld;
                        int i8 = i2 + 1;
                        iArr[i8] = iArr[i8] >> (-220);
                        break;
                }
                i2++;
            }
            i4++;
        } while (i4 < 171);
        long floatToIntBits = i5 + b + Float.floatToIntBits(f2) + i4 + i2 + i3 + i6 + i7 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1() {
        long j;
        boolean z = bFld;
        int i = 17;
        int i2 = 243;
        int i3 = -46258;
        int i4 = 2;
        byte b = 119;
        double d = -1.47089d;
        double d2 = 1.45159d;
        if (z) {
            instanceCount = -206L;
            i = 17 + iMeth(17, (byte) 119, fFld);
        } else if (z) {
            d = 1.0d;
            i = 3264;
            while (d < 214.0d) {
                int i5 = (int) d;
                i2 = i5;
                while (22 > i2) {
                    instanceCount = -4L;
                    i += sFld;
                    b = (byte) (b - ((byte) i));
                    iArrFld = iArrFld;
                    i2++;
                }
                iArrFld[i5] = i2;
                d += 3.0d;
            }
            i4 = 286;
            while (7 < i4) {
                long j2 = i3;
                long j3 = instanceCount;
                i3 = (int) (j2 + (((j * j3) - 41456) - j2));
                double d3 = i3;
                Double.isNaN(d3);
                d2 += d3;
                instanceCount = j3 * i4;
                i4--;
                i = i;
            }
        } else if (z) {
            i3 = (-46258) * ((int) fFld);
        }
        vMeth1_check_sum += (((i + b) + Double.doubleToLongBits(d)) - 41456) + i2 + i3 + i4 + 54670 + Double.doubleToLongBits(d2);
    }

    public void mainTest(String[] strArr) {
        int i;
        float f;
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -43);
        vMeth();
        vMeth1();
        int i2 = 6;
        int i3 = -14;
        int i4 = 64503;
        double d = -2.1235d;
        int i5 = 1;
        while (i5 < 339) {
            i3 = 1;
            while (i3 < 74) {
                int i6 = i5 + 1;
                bArr[i6] = (byte) (bArr[i6] - ((byte) i2));
                d = i3;
                int i7 = i3 * i3;
                int i8 = ((i4 + ((int) fFld)) * i5) + i7;
                i2 = (i2 + i8) | i3;
                i4 = i8 + ((int) (i7 + 158868936188254660L));
                i3++;
            }
            double[] dArr = this.dArrFld;
            double d2 = dArr[i5];
            double d3 = i3;
            Double.isNaN(d3);
            dArr[i5] = d2 - d3;
            i5++;
        }
        int i9 = 9;
        int i10 = 7;
        int i11 = 248;
        int i12 = -45417;
        int i13 = -42;
        float f2 = 76.96f;
        while (i9 < 209) {
            int i14 = i2;
            i10 = 1;
            while (true) {
                i4 += i10;
                bFld = true;
                d += 11.0d;
                switch ((i9 % 3) + 118) {
                    case 118:
                        switch ((i9 % 7) + 106) {
                            case 106:
                                i = i3;
                                f = f2;
                                i12 = 1;
                                iArrFld[i9 - 1] = (int) d;
                                break;
                            case 107:
                                i = i3;
                                f = f2;
                                i12 = 1;
                                i11 = -97;
                                break;
                            case 108:
                                i = i3;
                                f = f2;
                                i12 = 1;
                                try {
                                    iArrFld[i9] = (-11713) % i9;
                                    i4 = (-166) / iArrFld[i9 - 1];
                                    i14 = i4 % iArrFld[i10];
                                    break;
                                } catch (ArithmeticException e) {
                                    break;
                                }
                            case 109:
                                f = f2;
                                i12 = 1;
                                i = i3;
                                instanceCount += 1 | i9;
                                break;
                            case 110:
                                f = f2;
                                i12 = 1;
                                i14 >>= -206;
                                i = i3;
                                break;
                            case 111:
                                f = f2;
                                i12 = 1;
                                instanceCount += 1 - 4;
                                float[] fArr = this.fArrFld;
                                fArr[i12] = fArr[i12] + i12;
                                i = i3;
                                break;
                            case 112:
                                f = f2;
                                i12 = 1;
                                float[] fArr2 = this.fArrFld;
                                fArr2[i12] = fArr2[i12] + i12;
                                i = i3;
                                break;
                            default:
                                i = i3;
                                f = f2;
                                i12 = 1;
                                break;
                        }
                        f2 = f;
                        break;
                    case 119:
                        fFld *= i11;
                    case 120:
                        this.fArrFld[(i4 >>> 1) % N] = fFld;
                        i = i3;
                        i12 = 1;
                        break;
                    default:
                        i = i3;
                        i12 = 1;
                        f2 = (float) d;
                        break;
                }
                i13 = 2;
                i10++;
                if (i10 >= 126) {
                    break;
                }
                i3 = i;
            }
            i9++;
            i2 = i14;
            i3 = i;
        }
        FuzzerUtils.out.println("i26 i27 i28 = " + i5 + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i29 d4 i30 = " + i4 + "," + Double.doubleToLongBits(d) + "," + i9);
        FuzzerUtils.out.println("i31 i32 i33 = " + i11 + "," + i10 + "," + i12);
        FuzzerUtils.out.println("i34 by2 i35 = -49716,-97," + i13);
        FuzzerUtils.out.println("f3 byArr = " + Float.floatToIntBits(f2) + "," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + ((int) sFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.sFld1 Test.fFld fArrFld = " + ((int) sFld1) + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("Test.iArrFld dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.dArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
