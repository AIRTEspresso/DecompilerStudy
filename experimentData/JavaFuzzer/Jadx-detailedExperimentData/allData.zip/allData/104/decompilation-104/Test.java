/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/104/original-104/Test.dex */
public class Test {
    public static boolean[] bArrFld;
    public boolean bFld = false;
    public float fFld = 0.737f;
    public static long instanceCount = 46856;
    public static int iFld = 126;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static long bMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        boolean[] zArr = new boolean[N];
        bArrFld = zArr;
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(lArrFld, 6620249178618566476L);
    }

    public static int iMeth(float f, int i) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -10);
        FuzzerUtils.init(jArr, 30797L);
        bArrFld = bArrFld;
        int i2 = 157;
        int i3 = 4;
        int i4 = 10926;
        int i5 = -3;
        int i6 = 13;
        while (i6 < 211) {
            try {
                i = (-49647) % i6;
                i2 = i6 % (-110);
                i = (-116) % i6;
            } catch (ArithmeticException e) {
            }
            i3 = 1;
            while (i3 < 8) {
                iArr[1] = iArr[1] * (-111);
                instanceCount *= f;
                jArr[i6] = 1;
                i4 >>>= -111;
                iArr[i3 - 1] = i4;
                i3++;
                i5 = 1;
            }
            i6++;
        }
        long floatToIntBits = (((((((((Float.floatToIntBits(f) + i) + i6) + i2) + i3) + i4) + i5) - 111) + 1) - 9132390761175264722L) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(int i, short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -3);
        long j = instanceCount;
        vMeth_check_sum += ((((((((((8 + ((short) iMeth(1.823f, i + Integer.reverseBytes((int) ((i * j) - j))))) + Float.floatToIntBits(1.823f)) + 7) + 7) + 1) + 62) + 25090) - 51) + 34) - 13) + FuzzerUtils.checkSum(iArr);
    }

    public boolean bMeth(float f, int i, int i2) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -119);
        FuzzerUtils.init(jArr, 369598138L);
        vMeth(33, (short) 21130);
        iArr[46] = 208;
        int i3 = ((int) instanceCount) - 4;
        int i4 = i;
        int i5 = 46094;
        int i6 = 10;
        int i7 = 130;
        while (i7 > 6) {
            jArr[i7] = jArr[i7] - 21130;
            i5 = i7;
            while (i5 < 37) {
                iArr[i7] = iArr[i7] + iFld;
                i6 <<= i7;
                jArr[i7 - 1] = i7;
                long j = -2;
                i4 = ((int) (j + (((i5 * instanceCount) + i2) - j))) + (i5 ^ i6);
                i5++;
            }
            jArr[i7] = 6;
            i7 -= 3;
        }
        long floatToIntBits = ((((((Float.floatToIntBits(f) + i4) + i2) + 21130) + i3) + i7) - 217) + i5 + i6 + 6 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        bMeth_check_sum += floatToIntBits;
        return floatToIntBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -121.49904d);
        FuzzerUtils.init(iArr, 4);
        float f = this.fFld;
        int i2 = iFld;
        this.bFld = bMeth(f, i2, i2);
        this.fFld %= iFld | 1;
        int i3 = -208;
        int i4 = 2;
        int i5 = 18005;
        float f2 = -119.337f;
        double d = -2.93573d;
        int i6 = 13;
        int i7 = -11;
        while (i6 < 220) {
            i3 -= 4564;
            if (!this.bFld) {
                i = i3;
            } else {
                switch ((i6 % 8) + 80) {
                    case 80:
                        float f3 = i6;
                        while (f3 < 121.0f) {
                            i3 &= 15193;
                            i7 = (i7 + ((int) f3)) - i3;
                            this.bFld = this.bFld;
                            f3 += 1.0f;
                        }
                        int i8 = i6 + 1;
                        dArr[i8] = iFld;
                        i7 += (int) instanceCount;
                        iArr[i8] = iArr[i8] >> i3;
                        f2 = f3;
                        break;
                    case 81:
                        double d2 = 6.0d;
                        while (d2 < 121.0d) {
                            iFld -= 248;
                            d2 += 1.0d;
                        }
                        iArr[i6] = iFld;
                        i4 = i6;
                        while (i4 < 121) {
                            this.fFld = (float) instanceCount;
                            i4++;
                            i5 = 1;
                        }
                        d = d2;
                        i3 = i3;
                        break;
                    case 82:
                        long[] jArr = lArrFld;
                        int i9 = i6 + 1;
                        i = i3;
                        jArr[i9] = jArr[i9] + f2;
                        break;
                    case 83:
                        this.fFld += i6;
                        i = i3;
                        break;
                    case 84:
                        i3 = iFld;
                    case 85:
                        int i10 = i6 + 1;
                        iArr[i10] = iArr[i10] + 6763;
                        break;
                    case 86:
                        iArr[i6 - 1] = (int) this.fFld;
                        i = i3;
                        break;
                    case 87:
                        this.fFld = (float) instanceCount;
                        i = i3;
                        break;
                    default:
                        i = i3;
                        break;
                }
                i6++;
            }
            i3 = i;
            i6++;
        }
        FuzzerUtils.out.println("i19 i20 f3 = " + i6 + "," + i3 + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("i21 d i22 = " + i7 + "," + Double.doubleToLongBits(d) + ",-10");
        FuzzerUtils.out.println("i23 i24 i25 = " + i4 + ",-221," + i5);
        FuzzerUtils.out.println("i26 s2 dArr = -11,-369," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount bFld Test.iFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + iFld);
        FuzzerUtils.out.println("fFld Test.bArrFld Test.lArrFld = " + Float.floatToIntBits(this.fFld) + "," + FuzzerUtils.checkSum(bArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
