
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/128/original-128/Test.dex */
public class Test {
    public boolean bFld = false;
    public float fFld = 118.63f;
    public static volatile long instanceCount = -989642660582499141L;
    public static byte byFld = -4;
    public static final int N = 400;
    public static volatile float[] fArrFld = new float[N];
    public static double[] dArrFld = new double[N];
    public static int[][] iArrFld = (int[][]) Array.newInstance(int.class, N, N);
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;

    static {
        FuzzerUtils.init(fArrFld, 85.12f);
        FuzzerUtils.init(dArrFld, -2.71362d);
        FuzzerUtils.init(iArrFld, 1);
    }

    public static long lMeth(int i, int i2) {
        double d = 2.119435d;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 < 388) {
                d = i3;
                i2 *= (int) 0.994f;
                i = ((int) ((i + (i3 * i3)) + (i3 + instanceCount))) >> 170;
            } else {
                long doubleToLongBits = i + i2 + i3 + Double.doubleToLongBits(d) + Float.floatToIntBits(0.994f);
                lMeth_check_sum += doubleToLongBits;
                return doubleToLongBits;
            }
        }
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -69);
        lMeth(-14, -448);
        int i = 14;
        int i2 = -3;
        int i3 = 72;
        int i4 = -2;
        int i5 = 2;
        double d = 2.55003d;
        float f = -2.149f;
        while (i < 303) {
            float f2 = f;
            double d2 = d;
            int i6 = i5;
            int i7 = i4;
            int i8 = i3;
            int i9 = 6;
            while (i9 > 1) {
                i8 = (int) instanceCount;
                iArr[i9] = iArr[i9] - 1755221272;
                instanceCount -= instanceCount;
                i7 = (int) instanceCount;
                d2 = i7;
                i6 = 1;
                while (i6 < 6) {
                    instanceCount += i6;
                    f2 += 22732.0f;
                    i6++;
                }
                i9 -= 3;
            }
            i++;
            i2 = i9;
            i3 = i8;
            i4 = i7;
            i5 = i6;
            d = d2;
            f = f2;
        }
        vMeth_check_sum += (-448) + i + i3 + i2 + i4 + Double.doubleToLongBits(d) + i5 + 0 + Float.floatToIntBits(f) + 1 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(float f) {
        vMeth();
        int i = 0;
        int i2 = 0;
        int i3 = 186;
        float f2 = f;
        double d = -35.37211d;
        int i4 = 4;
        int i5 = 179;
        int i6 = 2;
        while (i4 < 165) {
            instanceCount -= 7826;
            f2 = i3 * i3 * i4;
            i3 = (int) (50507 + (i4 - instanceCount));
            i = i4;
            while (i < 10) {
                switch ((i4 % 8) + 26) {
                    case 26:
                        d = 5.0d;
                        i6 = 1;
                        break;
                    case 27:
                        i5 += i;
                        break;
                    case 28:
                        i5 *= (int) f2;
                        break;
                    case 29:
                        i3 *= 10;
                    case 30:
                        instanceCount >>>= i6;
                    case 31:
                        i2 += i;
                        break;
                    case 32:
                        f2 += (float) d;
                        break;
                    case 33:
                        instanceCount += ((i * i6) + i2) - i3;
                        break;
                }
                i++;
            }
            i4++;
        }
        long floatToIntBits = (((Float.floatToIntBits(f2) + i4) + i3) - 7826) + i + i5 + Double.doubleToLongBits(d) + i6 + 10 + i2;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr;
        double[] dArr;
        int i2;
        int i3 = N;
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr2, -174);
        int i4 = 37890;
        this.bFld = ((long) (byFld * 37890)) * 3579882441071966691L <= ((long) iMeth(this.fFld));
        int i5 = 54462;
        int i6 = -9;
        int i7 = 10;
        int i8 = 11;
        int i9 = 0;
        while (i9 < i3) {
            int i10 = iArr2[i9];
            int i11 = 1;
            while (true) {
                i = i11 + 1;
                iArr2[i] = i11;
                instanceCount = this.fFld;
                i7 += i7;
                i4 -= (int) (-105.0d);
                int i12 = (i11 % 2) + 85;
                if (i12 != 85 && i12 != 86) {
                    i4 = (int) this.fFld;
                }
                iArr = iArr2;
                instanceCount += ((1 * instanceCount) + 1) - i7;
                float f = this.fFld;
                this.fFld = f;
                this.fFld = f + 12742;
                iArr[0] = iArr[0] - 97;
                dArrFld[i11 - 1] = dArr[i2] - 28675.0d;
                iArrFld = iArrFld;
                if (i >= 63) {
                    break;
                }
                i11 = i;
                iArr2 = iArr;
            }
            i9++;
            i8 = 2;
            i5 = i;
            iArr2 = iArr;
            i3 = N;
            i6 = 1;
        }
        FuzzerUtils.out.println("i i19 i20 = " + i4 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i21 i22 s1 = " + i7 + "," + i8 + ",-12741");
        FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(iArr2));
        FuzzerUtils.out.println("Test.instanceCount bFld Test.byFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + ((int) byFld));
        FuzzerUtils.out.println("fFld Test.fArrFld Test.dArrFld = " + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
