/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/19/original-19/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public double dFld = 126.123539d;
    public volatile short sFld = -19991;
    public static long instanceCount = 2635474643414078350L;
    public static float fFld = 1.194f;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 6);
    }

    public static void vMeth2(int i, int i2, boolean z) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -52078);
        int i3 = 219;
        int i4 = -235;
        int i5 = 8;
        float f = -110.209f;
        int i6 = 1;
        while (true) {
            i6 += 2;
            if (i6 < 229) {
                i3 = 1;
                while (i3 < 14) {
                    iArr[i6] = iArr[i6] + ((int) f);
                    int i7 = i >> (-29305);
                    float f2 = f + 1;
                    f = f2 - f2;
                    long j = -29305;
                    instanceCount = j;
                    instanceCount = j + (((1 * i7) + i7) - j);
                    i4 = i6 + ((i7 - i7) ^ 1);
                    i = -20531;
                    i3++;
                    i2 = i6;
                    i5 = 2;
                }
            } else {
                vMeth2_check_sum += (((((((i + i2) + (z ? 1 : 0)) + i6) + i3) + i4) + Float.floatToIntBits(f)) - 29305) + i5 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vMeth1(long j, short s, int i) {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 105.79999d);
        vMeth2(i, -14, false);
        instanceCount -= i;
        int[] iArr = iArrFld;
        int i2 = (i >>> 1) % N;
        iArr[i2] = iArr[i2] >> (-62707);
        fFld -= -43.12985f;
        int i3 = -129;
        int i4 = 34680;
        int i5 = 2;
        while (i5 < 362) {
            i3 = 1;
            while (i3 < 5) {
                fFld = i;
                i3++;
                i4 = 2;
            }
            i5++;
        }
        vMeth1_check_sum += j + s + i + 0 + i5 + 32747 + i3 + 18080 + i4 + 4 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static void vMeth(double d, float f, long j) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -2.416f);
        vMeth1(instanceCount, (short) 24636, 64611);
        int i = 1;
        do {
            i++;
        } while (i < 398);
        vMeth_check_sum += (((((((Double.doubleToLongBits(d) + Float.floatToIntBits(f)) + j) + 24636) + i) + 1) + 138) - 13) + 36 + 29 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public void mainTest(String[] strArr) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 1.372f);
        int i = 54911;
        int i2 = 107;
        double d = 88.95346d;
        byte b = -67;
        int i3 = 7;
        while (123 > i3) {
            try {
                int i4 = i3 / 7299;
                int i5 = (-339529081) % (64470 % i3);
            } catch (ArithmeticException e) {
            }
            d = 216.0d;
            if (216.0d > i3) {
                double d2 = this.dFld - 1.0d;
                this.dFld = d2;
                vMeth(d2, fFld, 59682L);
                i2 = ((i2 - i2) + (-(i2 - i3))) - i3;
            }
            i = -34816;
            b = (byte) fFld;
            i3++;
        }
        FuzzerUtils.out.println("i i1 d = " + i3 + "," + (i * i3) + "," + Double.doubleToLongBits(d));
        FuzzerUtils.out.println("i2 b3 i19 = " + i2 + ",1,-3");
        FuzzerUtils.out.println("by2 fArr1 = " + ((int) b) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(this.dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("sFld Test.iArrFld = " + ((int) this.sFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
