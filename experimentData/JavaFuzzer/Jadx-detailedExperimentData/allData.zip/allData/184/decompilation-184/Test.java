
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/184/original-184/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public short[] sArrFld = new short[N];
    public static long instanceCount = 268906671;
    public static float fFld = -1.843f;
    public static byte byFld = -67;
    public static int iFld = 48874;
    public static boolean bFld = true;
    public static short sFld = -19932;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 97L);
    }

    public static int iMeth1(long j) {
        int i = -35598;
        int i2 = 13954;
        int i3 = -61852;
        int i4 = 122;
        double d = -112.79484d;
        int i5 = 7;
        while (i5 < 129) {
            double d2 = fFld;
            instanceCount = 1;
            Double.isNaN(d2);
            d = d2 - (-46548.0d);
            i2 = 1;
            while (13 > i2) {
                i2++;
            }
            int i6 = i3 + (i5 * i5);
            int i7 = 1;
            int i8 = 1;
            while (true) {
                i8++;
                if (i8 < 13) {
                    i6 += 20272;
                    float f = fFld;
                    int i9 = (int) f;
                    fFld = f - byFld;
                    i7 = i9 * i9;
                }
            }
            i5++;
            i = i7;
            i3 = i6;
            i4 = i8;
        }
        long doubleToLongBits = j + i5 + i + Double.doubleToLongBits(d) + i2 + i3 + 1 + i4;
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth() {
        long j;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 61524);
        instanceCount = instanceCount + (-Math.max(iMeth1(j), -2));
        iArr[0] = iArr[0] - (-2);
        fFld -= 0;
        vMeth_check_sum += 1 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 6);
        vMeth();
        fFld = iFld;
        int i = -14;
        int i2 = -20634;
        int i3 = -159;
        long j = 20298;
        int i4 = 13;
        while (i4 < 378) {
            i = 1;
            while (i < 5) {
                int i5 = i4 + 1;
                iArr[i5] = iArr[i5] | byFld;
                iArr[i] = iArr[i] ^ 5;
                long j2 = 1;
                while (j2 < 2) {
                    long[] jArr = lArrFld;
                    long j3 = i4;
                    jArr[(int) j2] = j3;
                    j2++;
                    int i6 = (int) j2;
                    jArr[i6] = jArr[i6] * j3;
                    i3 = (i3 + 16616) * ((int) fFld);
                    i2 = 109;
                }
                i++;
                j = j2;
            }
            i4++;
        }
        long checkSum = i4 + 1 + i + i2 + j + i3 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        float f;
        int[] iArr;
        int[] iArr2 = new int[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(iArr2, -14);
        FuzzerUtils.init(jArr, 2641272992L);
        iArr2[69] = iArr2[69] + 163;
        long j = instanceCount;
        instanceCount = j - 1;
        int i = ((int) (11387 - j)) + 1;
        float iMeth = 2.582f - (iMeth() + i);
        iFld += i;
        int i2 = 52;
        int i3 = -151;
        int i4 = 27;
        int i5 = 21111;
        int i6 = 1;
        int i7 = -12;
        while (true) {
            f = iMeth;
            if (151 <= i6) {
                break;
            }
            i3 = 7;
            while (i3 < 167) {
                int i8 = iFld;
                f += i8;
                iArr2[i3] = iArr2[i3] - i8;
                i2 >>= i8;
                i |= (int) instanceCount;
                i4 ^= i;
                i3++;
            }
            iFld *= i2;
            instanceCount = instanceCount;
            if (bFld) {
                iArr = iArr2;
            } else {
                i7 = i6;
                while (i7 < 167) {
                    i4 = (int) instanceCount;
                    i7++;
                }
                long j2 = instanceCount;
                iArr = iArr2;
                long j3 = i6;
                instanceCount = j2 + (((j3 * j2) + 39187) - j3);
                f += 39187;
                int i9 = 4;
                i = i;
                while (i9 < 167) {
                    if (!bFld) {
                        iArr[i9] = iArr[i9] + ((int) 2.5768d);
                        i += ((i9 * 39187) + sFld) - i7;
                        fFld = 0.101f;
                        i4 ^= i6;
                    }
                    i9++;
                }
                i5 = i9;
            }
            iMeth = f;
            i6++;
            iArr2 = iArr;
        }
        int[] iArr3 = iArr2;
        int i10 = 0;
        while (i10 < 400) {
            int i11 = iArr3[i10];
            jArr[(i >>> 1) % N][(i7 >>> 1) % N] = i5;
            fFld = i4;
            this.sArrFld[(iFld >>> 1) % N] = -28362;
            i10++;
            jArr = jArr;
        }
        FuzzerUtils.out.println("i f i12 = " + i + "," + Float.floatToIntBits(f) + "," + i6);
        FuzzerUtils.out.println("i13 i14 i15 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i16 i17 i18 = " + i7 + ",39187," + i5);
        FuzzerUtils.out.println("i19 d1 iArr = -12," + Double.doubleToLongBits(2.5768d) + "," + FuzzerUtils.checkSum(iArr3));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + ((int) byFld));
        FuzzerUtils.out.println("Test.iFld Test.bFld Test.sFld = " + iFld + "," + (bFld ? 1 : 0) + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.lArrFld sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
