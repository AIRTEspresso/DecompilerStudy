
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/175/original-175/Test.dex */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = -162;
    public static volatile int iFld = 27866;
    public static float fFld = 42.615f;
    public static volatile double dFld = -2.7781d;
    public static short sFld = 29534;
    public static boolean bFld = false;
    public static long vMeth_check_sum = 0;
    public static long sMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;

    public static int iMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -64739);
        int i2 = -63977;
        int i3 = -14;
        int i4 = 8;
        int i5 = -25;
        int i6 = 1;
        while (244 > i6) {
            instanceCount += i6 * i6;
            int i7 = 1;
            while (7 > i7) {
                i2 = (int) (i2 + (((i7 * i4) + instanceCount) - 14446));
                instanceCount = i;
                i7++;
            }
            int i8 = 1;
            do {
                i2 += ((i8 * i8) + iFld) - i8;
                instanceCount += ((i8 * 4) + 4) - iFld;
                i8++;
            } while (i8 < 7);
            instanceCount += i;
            i4 = (int) instanceCount;
            iArr[i6 - 1] = (int) fFld;
            i6++;
            i5 = i8;
            i3 = i7;
        }
        int i9 = 13;
        while (i9 < 380) {
            instanceCount = ((float) instanceCount) + i9 + fFld;
            i = (int) dFld;
            i9++;
        }
        long checkSum = i + i6 + i2 + i3 + i4 + 14446 + i5 + i9 + 0 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public static short sMeth(int i) {
        long j;
        byte[][][] bArr = (byte[][][]) Array.newInstance(byte.class, N, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init((Object[][]) bArr, (Object) (byte) -94);
        FuzzerUtils.init(jArr, 11671L);
        int i2 = (i >>> 1) % N;
        byte[] bArr2 = bArr[i2][i2];
        byte b = bArr2[i2];
        instanceCount = iMeth(iFld);
        bArr2[i2] = (byte) (b - ((byte) (j * iFld)));
        double d = 1.0d;
        while (d < 134.0d) {
            i = (i + sFld) * 64078;
            d += 1.0d;
        }
        long j2 = i;
        instanceCount -= j2;
        int i3 = 8;
        int i4 = 42308;
        while (i3 < 171) {
            iFld -= (int) fFld;
            i4 += iFld | i3;
            iFld |= (int) instanceCount;
            instanceCount += ((sFld * i3) + i3) - iFld;
            iFld += (int) instanceCount;
            i3++;
        }
        long doubleToLongBits = j2 + Double.doubleToLongBits(d) + 64078 + i3 + i4 + FuzzerUtils.checkSum((Object[][]) bArr) + FuzzerUtils.checkSum(jArr);
        sMeth_check_sum += doubleToLongBits;
        return (short) doubleToLongBits;
    }

    public static void vMeth(int i, double d) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 58);
        iArr[((sMeth(i) + i) >>> 1) % N] = iFld;
        bFld = bFld;
        int i2 = -2;
        int i3 = 22414;
        int i4 = 72;
        int i5 = 18151;
        int i6 = 1;
        while (true) {
            i6++;
            if (i6 < 215) {
                i2 = 1;
                while (i2 < 7) {
                    if (((i2 % 1) * 5) + 116 != 119) {
                        i3 = i4;
                    } else {
                        fFld = 13.0f;
                        instanceCount += i2 - i3;
                        iFld = i2;
                    }
                    instanceCount += fFld;
                    i4 = ((int) instanceCount) * i3;
                    i5 += 198;
                    i2++;
                }
            } else {
                vMeth_check_sum += i5 + Double.doubleToLongBits(d) + i6 + i2 + i3 + i4 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        long[] jArr;
        int i;
        long j;
        int[] iArr = new int[N];
        float[][][] fArr = (float[][][]) Array.newInstance(float.class, N, N, N);
        byte[] bArr = new byte[N];
        long[] jArr2 = new long[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(jArr2, -177L);
        FuzzerUtils.init(dArr, -88.6756d);
        FuzzerUtils.init((Object[][]) fArr, (Object) Float.valueOf(-21.24f));
        FuzzerUtils.init(iArr, 213);
        FuzzerUtils.init(bArr, (byte) -93);
        int i2 = 1;
        int i3 = -9;
        int i4 = 24196;
        int i5 = 0;
        int i6 = -62266;
        int i7 = 30268;
        int i8 = 241;
        float f = 0.235f;
        int i9 = 1;
        while (true) {
            i9 += i2;
            if (i9 < 166) {
                i3 = 3;
                while (i3 < 151) {
                    long[] jArr3 = jArr2;
                    i5 = 1;
                    while (i5 < 2) {
                        int i10 = i9 - 1;
                        long j2 = jArr3[i10];
                        long j3 = instanceCount + 1;
                        instanceCount = j3;
                        long j4 = j2 - j3;
                        jArr3[i10] = j4;
                        int i11 = i3;
                        jArr3[i5] = jArr3[i5] | ((int) (j4 + i6));
                        int i12 = (i5 >>> 1) % N;
                        jArr3[i12] = jArr3[i12] ^ Long.reverseBytes((f - i5) * ((float) (instanceCount - j)));
                        f *= 267.0f;
                        double d = i11;
                        Double.isNaN(d);
                        long j5 = (((long) ((d - 31.31911d) + 2.65315d)) << ((int) ((instanceCount - 31888) ^ (-62851027)))) / (((i - 1) - (instanceCount - (-80))) | 1);
                        vMeth(i9, dFld);
                        jArr3 = FuzzerUtils.long1array(N, -1768316691L);
                        i6 = ((int) f) * ((int) instanceCount);
                        iFld = i6;
                        i5++;
                        i3 = i11;
                        iArr = iArr;
                        bArr = bArr;
                        dArr = dArr;
                    }
                    int[] iArr2 = iArr;
                    byte[] bArr2 = bArr;
                    double[] dArr2 = dArr;
                    int i13 = i3;
                    switch ((i9 % 9) + 116) {
                        case 116:
                            jArr = jArr3;
                            iFld += i13;
                            i7 = (int) (i7 + (((i13 * (-30)) + instanceCount) - instanceCount));
                            i4 += i13;
                            break;
                        case 117:
                            i6 += (i13 * i13) - 110;
                            f *= i5;
                            int i14 = (i13 % 2) + 36;
                            if (i14 == 36) {
                                i4 = ((int) dFld) - i9;
                                float[] fArr2 = fArr[i13][i9 - 1];
                                int i15 = i9 + 1;
                                jArr = jArr3;
                                fArr2[i15] = fArr2[i15] * ((float) instanceCount);
                                fFld += (float) ((1 + instanceCount) - iFld);
                                int i16 = i13 + 1;
                                iArr2[i16] = iArr2[i16] * ((int) instanceCount);
                                i8 = 2;
                                if (bFld) {
                                    break;
                                }
                            } else if (i14 == 37) {
                                jArr = jArr3;
                            } else {
                                i6 += (int) f;
                                jArr = jArr3;
                                i4 += (int) dFld;
                                break;
                            }
                            if (!bFld) {
                                int i17 = i9 + 1;
                                jArr[i17] = jArr[i17] - i5;
                            }
                            i4 += (int) dFld;
                        case 118:
                            jArr = jArr3;
                            i4 += (int) dFld;
                            break;
                        case 119:
                            i7 += (i13 * i13) + 12;
                            jArr = jArr3;
                            break;
                        case 120:
                            i7 = (int) instanceCount;
                        case 121:
                            int i18 = i9 + 1;
                            bArr2[i18] = (byte) (bArr2[i18] * ((byte) i5));
                            jArr = jArr3;
                            break;
                        case 122:
                            long j6 = i4;
                            i4 = (int) (j6 + (((i13 * instanceCount) + i7) - j6));
                        case 123:
                            try {
                                iFld = i7 % i6;
                                i6 = iArr2[i9] / 168;
                                iFld = (-490270453) / iArr2[i9 - 1];
                                jArr = jArr3;
                                break;
                            } catch (ArithmeticException e) {
                                jArr = jArr3;
                                break;
                            }
                        case 124:
                            fArr[i9 + 1][i13][i13] = i4;
                            jArr = jArr3;
                            sFld = (short) (sFld + ((short) (((i13 * i5) + i9) - i4)));
                            break;
                        default:
                            jArr = jArr3;
                            sFld = (short) (sFld + ((short) (((i13 * i5) + i9) - i4)));
                            break;
                    }
                    iArr = iArr2;
                    bArr = bArr2;
                    dArr = dArr2;
                    long[] jArr4 = jArr;
                    i3 = i13 + 1;
                    jArr2 = jArr4;
                }
                i2 = 1;
            } else {
                FuzzerUtils.out.println("i i1 i2 = " + i9 + "," + i3 + "," + i4);
                FuzzerUtils.out.println("i3 i4 f = " + i5 + "," + i6 + "," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("s i22 by = -31888," + i7 + ",-30");
                FuzzerUtils.out.println("i23 lArr dArr = " + i8 + "," + FuzzerUtils.checkSum(jArr2) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
                FuzzerUtils.out.println("fArr iArr2 byArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr)) + "," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(bArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
                FuzzerUtils.out.println("Test.dFld Test.sFld Test.bFld = " + Double.doubleToLongBits(dFld) + "," + ((int) sFld) + "," + (bFld ? 1 : 0));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
