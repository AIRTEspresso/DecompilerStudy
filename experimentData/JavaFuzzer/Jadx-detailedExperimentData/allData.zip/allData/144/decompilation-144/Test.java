/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/144/original-144/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -1331392317368199387L;
    public static int iFld = 241;
    public static int iFld1 = -1;
    public static long dMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public volatile float fFld = 0.213f;
    public volatile boolean bFld = true;
    public double dFld = -32.37157d;
    public volatile long[] lArrFld = new long[N];
    public int[] iArrFld = new int[N];

    public int iMeth(double d, int i, int i2) {
        int i3 = -55;
        int i4 = -4;
        int i5 = -14;
        int i6 = -68;
        int i7 = 1;
        while (true) {
            i7++;
            if (i7 < 390) {
                instanceCount *= iFld;
                i2 *= i7;
                i3 = 1;
                while (4 > i3) {
                    i5 = 1;
                    while (i5 < 4) {
                        this.fFld -= -46619.0f;
                        iFld += i5 | i7;
                        i6 /= i3 | 1;
                        if (this.bFld) {
                            d -= 19554.0d;
                            i = (int) d;
                            int i8 = iFld;
                            if ((((i8 >>> 1) % 1) * 5) + 67 == 68) {
                                i4 = i * i8;
                                iFld = iFld1;
                                i = i4;
                            }
                        } else {
                            i2 -= i7;
                        }
                        i5++;
                    }
                    i3 += 3;
                }
            } else {
                long doubleToLongBits = Double.doubleToLongBits(d) + i + i2 + i7 + i3 + i4 + i5 + i6;
                iMeth_check_sum += doubleToLongBits;
                return (int) doubleToLongBits;
            }
        }
    }

    public long lMeth(int i) {
        iFld <<= (int) instanceCount;
        int i2 = iFld1;
        double d = -2.56817d;
        int iMeth = iMeth(-2.56817d, i2, i2);
        iFld = iMeth;
        this.iArrFld[(iMeth >>> 1) % N] = (int) instanceCount;
        int i3 = -10;
        int i4 = -212;
        int i5 = 40200;
        int i6 = 8;
        int i7 = 228;
        int i8 = 12;
        while (i7 > 12) {
            i = 6312;
            d -= -166.0d;
            i8 = 1;
            while (i8 < 7) {
                i4 = 2;
                while (i4 > 1) {
                    double d2 = this.fFld;
                    Double.isNaN(d2);
                    d -= d2;
                    iFld1 *= (int) this.fFld;
                    i6 *= 56162;
                    long j = instanceCount;
                    instanceCount = j + j;
                    i5 += i4 | i6;
                    i4--;
                    i3 = 11541;
                }
                i8++;
            }
            i7--;
        }
        long doubleToLongBits = i + Double.doubleToLongBits(d) + i7 + 11541 + i8 + i3 + i4 + i5 + i6;
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public double dMeth() {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -2.32f);
        int i = 61;
        int i2 = 21;
        while (i2 < 349) {
            i *= i;
            fArr[i2 - 1] = (float) ((i - instanceCount) - lMeth(-10053));
            long j = instanceCount;
            int i3 = (int) j;
            iFld = i3;
            iFld1 = i2;
            double d = this.dFld;
            double d2 = j;
            Double.isNaN(d2);
            this.dFld = d + d2;
            iFld = i3 & i;
            i2++;
        }
        byte b = (byte) ((-91) + ((byte) i2));
        int i4 = 12;
        int i5 = 11;
        int i6 = -114;
        while (i4 < 344) {
            int i7 = 1;
            while (true) {
                i7++;
                if (i7 < 5) {
                    iFld &= -10896;
                    this.fFld -= this.fFld;
                    i6 = 1;
                }
            }
            i4++;
            i5 = i7;
        }
        long doubleToLongBits = ((((((((i2 + i) + b) + i4) + 3790) + i5) - 10896) + i6) - 11929) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        dMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        boolean[] zArr;
        int i;
        double[] dArr = new double[N];
        boolean[] zArr2 = new boolean[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(dArr, 65.23246d);
        FuzzerUtils.init(zArr2, true);
        FuzzerUtils.init(fArr, 2.5f);
        long[] jArr = this.lArrFld;
        int i2 = (iFld >>> 1) % N;
        long j = jArr[i2];
        int[] iArr = this.iArrFld;
        double d = iArr[115];
        Double.isNaN(d);
        jArr[i2] = j + ((long) (-(d * 66505.87559d)));
        int length = iArr.length;
        int i3 = -1;
        int i4 = 50158;
        int i5 = 183;
        int i6 = 75;
        byte b = 113;
        int i7 = 0;
        while (i7 < length) {
            int i8 = iArr[i7];
            double abs = Math.abs((-30656) + i4);
            double d2 = dArr[3];
            Double.isNaN(abs);
            iFld = (int) (abs + d2);
            i4 = i4;
            int i9 = 1;
            while (i9 < 2) {
                double[] dArr2 = dArr;
                boolean z = instanceCount > ((long) i8);
                zArr2[4] = z;
                if (z) {
                    zArr = zArr2;
                    i = length;
                } else {
                    i = length;
                    i6--;
                    zArr = zArr2;
                    long[] jArr2 = this.lArrFld;
                    long j2 = jArr2[i9] - 1;
                    jArr2[i9] = j2;
                    iFld -= (int) ((b + (i6 * 5637493953923160993L)) + j2);
                    int i10 = (i9 % 2) + 48;
                    if (i10 == 48) {
                        this.fFld *= b;
                        dMeth();
                        iFld -= i4;
                        b = (byte) (b - 1);
                    } else if (i10 == 49) {
                        instanceCount += i9 * i9;
                        i4 += 12;
                    }
                    instanceCount += i9 * i9;
                }
                i9++;
                length = i;
                dArr = dArr2;
                zArr2 = zArr;
            }
            double[] dArr3 = dArr;
            boolean[] zArr3 = zArr2;
            int i11 = length;
            try {
                try {
                    iFld = this.iArrFld[(iFld1 >>> 1) % N] / 1986380531;
                    i6 = i9 / (-48368);
                    this.iArrFld[3] = 244 / i4;
                } catch (ArithmeticException e) {
                }
            } catch (ArithmeticException e2) {
            }
            instanceCount += 188;
            int i12 = iFld;
            b = (byte) (b + ((byte) (((3 * i4) + i4) - i12)));
            iFld = i12 - ((int) this.dFld);
            i7++;
            i5 = i9;
            length = i11;
            dArr = dArr3;
            zArr2 = zArr3;
            i3 = 3;
        }
        FuzzerUtils.out.println("d i1 i2 = " + Double.doubleToLongBits(3.58387d) + "," + i3 + "," + i4);
        FuzzerUtils.out.println("s i3 i4 = -30656," + i5 + "," + i6);
        FuzzerUtils.out.println("by dArr bArr = " + ((int) b) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + "," + FuzzerUtils.checkSum(zArr2));
        FuzzerUtils.out.println("fArr1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.iFld1 bFld dFld = " + iFld1 + "," + (this.bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("lArrFld iArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
