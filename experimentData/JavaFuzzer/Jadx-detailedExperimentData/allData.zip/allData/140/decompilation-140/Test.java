
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/140/original-140/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long instanceCount = -8;
    public static int iFld = 10;
    public static short sFld = -30775;
    public static float fFld1 = -80.97f;
    public static boolean bFld1 = true;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public float fFld = -116.725f;
    public boolean bFld = false;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 93);
    }

    public static void vMeth1(int i) {
        int[] iArr;
        int i2 = -59205;
        int i3 = 157;
        int i4 = 56578;
        int i5 = 118;
        short s = 29973;
        int i6 = 11;
        while (334 > i6) {
            int i7 = i6 + 1;
            iArrFld[i7] = iArr[i7] - 30561;
            short s2 = s;
            int i8 = i5;
            int i9 = i4;
            int i10 = i3;
            int i11 = 1;
            while (i11 < 5) {
                i9 = 1;
                while (2 > i9) {
                    float f = fFld1 - (-74.0f);
                    fFld1 = f;
                    i8 = ((i8 * i8) >> 1369483419) * (-12757);
                    int i12 = (i6 % 2) + 29;
                    if (i12 == 29) {
                        sFld = (short) (sFld >> ((short) iFld));
                    } else if (i12 == 30) {
                        fFld1 = f + ((i9 * i9) - 48.891f);
                        s2 = (short) (s2 >> ((short) iFld));
                    }
                    int i13 = i10 + i9;
                    i9++;
                    int i14 = i10;
                    i10 = i13;
                    i = i14;
                }
                i += iFld;
                i11++;
            }
            i2 = i11;
            i3 = i10;
            i4 = i9;
            i5 = i8;
            i6 = i7;
            s = s2;
        }
        vMeth1_check_sum += ((i + i6) - 62929) + i2 + i3 + i4 + i5 + s;
    }

    public static void vMeth(float f, int i) {
        float f2 = f;
        int i2 = i;
        long j = -1630227261;
        byte b = -68;
        int i3 = 1;
        double d = -52.25984d;
        int i4 = -6490;
        int i5 = -10;
        while (i3 < 279) {
            double d2 = d - 1.0d;
            double d3 = (f2 - 1.0f) * b;
            Double.isNaN(d3);
            f2 -= (float) ((d - d) + d3);
            int i6 = i3 + 1;
            i4 = Math.max(iArrFld[i6], (int) (-(i4 * instanceCount)));
            i2 += i3;
            vMeth1(i3);
            boolean z = bFld1;
            if (z) {
                int[] iArr = iArrFld;
                iArr[i3] = iArr[i3] + i3;
            } else if (z) {
                long j2 = instanceCount + (((i3 * i4) + i2) - i4);
                instanceCount = j2;
                iArrFld[i3 - 1] = (int) f2;
                instanceCount = j2;
                i4 = 19410;
            } else if (z) {
                i5 = 6;
                while (i5 > 1) {
                    j <<= iFld;
                    b = (byte) (b << 4);
                    i2 >>>= 2637;
                    i5--;
                }
            }
            i3 = i6;
            d = d2;
        }
        vMeth_check_sum += ((((((((Float.floatToIntBits(f2) + i2) + i3) + i4) + Double.doubleToLongBits(d)) + b) + 19410) + i5) - 9) + j;
    }

    public static int iMeth() {
        int i = -9;
        int i2 = -4;
        double d = -2.69176d;
        int i3 = 9;
        int i4 = -12;
        while (213 > i3) {
            try {
                int i5 = i3 - 1;
                iFld = iArrFld[i5] / (-53408);
                i = 1813546770 % i;
                iArrFld[i3 + 1] = iArrFld[i5] % (-8);
            } catch (ArithmeticException e) {
            }
            int i6 = 1;
            while (8 > i6) {
                int[] iArr = iArrFld;
                int i7 = i6 - 1;
                int i8 = iArr[i7] - 1;
                iArr[i7] = i8;
                i2 -= i8 - (Math.abs(-12) + i6);
                vMeth(fFld1, i6);
                float f = fFld1 + i6;
                fFld1 = f;
                iFld = i3;
                long j = f;
                instanceCount = j;
                int i9 = ((i3 % 2) * 5) + 11;
                if (i9 == 12) {
                    instanceCount = j - 16;
                    int[] iArr2 = iArrFld;
                    iArr2[i7] = iArr2[i7] * i2;
                } else if (i9 != 17) {
                    d += 40311.0d;
                    i6++;
                    i = i3;
                }
                i2 = (int) d;
                d += 40311.0d;
                i6++;
                i = i3;
            }
            i3++;
            i4 = i6;
        }
        long doubleToLongBits = i3 + i + i4 + i2 + Double.doubleToLongBits(d);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        double[] dArr = new double[N];
        boolean[] zArr = new boolean[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(dArr, 0.56855d);
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(jArr, -3426413554L);
        int i = iFld;
        long j = instanceCount;
        instanceCount = j - 1;
        iFld = i - ((int) j);
        short s = sFld;
        float f = this.fFld + 1.0f;
        this.fFld = f;
        sFld = (short) (s + ((short) f));
        int i2 = -6;
        int i3 = 116;
        int i4 = 174;
        while (2 < i4) {
            i2 = 1;
            do {
                i2++;
            } while (i2 < 146);
            jArr[i4] = jArr[i4];
            i4--;
            i3 = 1;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i4 + ",-4," + i2);
        FuzzerUtils.out.println("i3 i4 i22 = " + i3 + ",-1,-11");
        FuzzerUtils.out.println("by1 dArr bArr = " + ((int) ((byte) instanceCount)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + "," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        FuzzerUtils.out.println("fFld bFld Test.fFld1 = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld1));
        FuzzerUtils.out.println("Test.bFld1 Test.iArrFld = " + (bFld1 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
