/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/103/original-103/Test.dex */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 119;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public float fFld = 0.86f;
    public volatile double dFld = 1.1487d;
    public byte byFld = -100;
    public int iFld = -12;
    public int[] iArrFld = new int[N];

    public void vMeth1() {
        byte b;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 8L);
        this.iFld = this.iFld;
        int i = 1;
        do {
            this.iFld %= i | 1;
            instanceCount <<= -43505;
            int i2 = this.iFld >>> ((int) instanceCount);
            this.iFld = i2;
            b = (byte) i;
            int i3 = i2 + 54123;
            this.iFld = i3;
            i++;
            jArr[i] = jArr[i] - this.fFld;
            int i4 = i3 >> ((int) instanceCount);
            this.iFld = i4;
            int i5 = i4 - ((int) instanceCount);
            this.iFld = i5;
            instanceCount = i5;
        } while (i < 355);
        int i6 = 375;
        int i7 = -31917;
        int i8 = -13;
        long j = 173;
        while (i6 > 18) {
            long j2 = 1;
            while (j2 < 13) {
                i7 &= (int) j2;
                i8 += 1533772819;
                j2++;
            }
            i6 -= 3;
            j = j2;
        }
        vMeth1_check_sum += i + b + i6 + i7 + j + i8 + FuzzerUtils.checkSum(jArr);
    }

    public int iMeth(float f, int i, int i2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -34428L);
        vMeth1();
        int i3 = i;
        int i4 = i2;
        long j = 20;
        int i5 = 39944;
        int i6 = 166;
        while (j < 357) {
            int[] iArr = this.iArrFld;
            int i7 = (int) (j - 1);
            int i8 = (int) j;
            iArr[i7] = iArr[i7] - i8;
            int i9 = 1;
            while (true) {
                i9++;
                if (i9 < 5) {
                    int[] iArr2 = this.iArrFld;
                    int i10 = i9 - 1;
                    iArr2[i10] = iArr2[i10] - this.iFld;
                    jArr[i8] = i4;
                    i3 *= (int) this.dFld;
                    this.iFld = i5;
                    instanceCount = this.fFld;
                    i4 += i4;
                }
            }
            this.iFld = i8;
            i4 = (int) instanceCount;
            j++;
            i6 = i9;
            i5 = i8;
        }
        this.byFld = (byte) i3;
        long floatToIntBits = Float.floatToIntBits(f) + i3 + i4 + j + i5 + i6 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void vMeth(long j, long j2, int i) {
        int[] iArr = new int[N];
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr, -136);
        FuzzerUtils.init(iArr2, 46784);
        double d = 3.0d;
        while (d < 194.0d) {
            d += 1.0d;
        }
        long j3 = j;
        long j4 = j2;
        int i2 = i;
        int i3 = 12;
        int i4 = -28390;
        int i5 = 27585;
        while (i3 < 365) {
            double d2 = this.dFld;
            int i6 = i3 - 1;
            int i7 = iArr[i6];
            iArr[i6] = i7 - 1;
            int[] iArr3 = iArr;
            double d3 = d;
            double d4 = i7;
            Double.isNaN(d4);
            this.dFld = d2 - d4;
            i5 = 1;
            while (i5 < 5) {
                j4 += ((i4 * i5) + j4) - this.byFld;
                float f = this.fFld;
                long j5 = instanceCount - 1;
                instanceCount = j5;
                float f2 = f * ((float) (j5 + (-iMeth(this.fFld, 8266, i3))));
                this.fFld = f2;
                int i8 = i3 + 1;
                iArr2[i8] = iArr2[i8] << 8266;
                i4 = 10;
                i2 = i2 + (i5 * 104) + ((int) f2);
                this.iFld += i5;
                j3 = 4;
                i5++;
            }
            i3++;
            iArr = iArr3;
            d = d3;
        }
        vMeth_check_sum += j3 + j4 + i2 + Double.doubleToLongBits(d) + i4 + i3 + 4 + i5 + 104 + 8266 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(iArr2);
    }

    public void mainTest(String[] strArr) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 13L);
        vMeth(instanceCount, instanceCount, this.iFld);
        this.fFld *= (float) this.dFld;
        this.fFld = -71.0f;
        instanceCount -= 28707;
        this.iArrFld = this.iArrFld;
        this.dFld -= 0.6660000085830688d;
        int i = this.iFld;
        this.iFld = i * i;
        this.iFld = -3;
        this.iFld = (-3) + 1;
        int i2 = 240;
        int i3 = 0;
        double d = -99.123034d;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 >= 319) {
                break;
            }
            instanceCount *= i4;
            this.fFld = -26960;
            i2 = 1;
            while (true) {
                i2++;
                if (i2 < 79) {
                    this.iFld += i2 + i2;
                }
            }
            instanceCount -= i2;
            d = this.fFld;
            this.iArrFld[i4 + 1] = i2;
            int i5 = this.iFld - i2;
            this.iFld = i5;
            jArr[i4] = 98;
            this.iFld = i5 + (i4 ^ (-26960));
            i3 = 1;
        }
        int i6 = this.iFld;
        this.iFld = i6 * i6;
        int i7 = 1;
        while (true) {
            i7++;
            if (i7 < 167) {
                try {
                    int i8 = 69748159 / this.iArrFld[i7];
                    this.iFld = i8;
                    this.iFld = this.iArrFld[(i8 >>> 1) % N] % (-11);
                    this.iFld = 31025 % i7;
                } catch (ArithmeticException e) {
                }
                this.iFld = this.iFld;
                this.fFld += i4;
                instanceCount -= -82;
                this.iFld -= -36391;
                instanceCount *= this.byFld;
            } else {
                FuzzerUtils.out.println("i15 s i16 = " + i4 + ",-26960," + i2);
                FuzzerUtils.out.println("b d1 i17 = " + i3 + "," + Double.doubleToLongBits(d) + "," + i7);
                FuzzerUtils.out.println("lArr2 = " + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("Test.instanceCount fFld dFld = " + instanceCount + "," + Float.floatToIntBits(this.fFld) + "," + Double.doubleToLongBits(this.dFld));
                FuzzerUtils.out.println("byFld iFld iArrFld = " + ((int) this.byFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(this.iArrFld));
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
