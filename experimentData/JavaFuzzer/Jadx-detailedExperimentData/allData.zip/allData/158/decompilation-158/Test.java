
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/158/original-158/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public int iFld = -60701;
    public int iFld1 = 43182;
    public static long instanceCount = -60;
    public static volatile boolean bFld = true;
    public static double dFld = 53.97498d;
    public static byte byFld = Byte.MAX_VALUE;
    public static boolean bFld1 = false;
    public static long lFld = -212;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long bMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 8673);
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00f3 A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00f5 A[ORIG_RETURN, RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static boolean bMeth(int r20, long r21) {
        /*
            Method dump skipped, instructions count: 247
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.bMeth(int, long):boolean");
    }

    public static void vMeth(float f, int i, double d) {
        double d2;
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 0.4f);
        int i2 = i;
        double d3 = d;
        int i3 = 14;
        int i4 = 56779;
        int i5 = 1;
        do {
            d2 = 1.0d;
            do {
                if (bMeth(i5, instanceCount)) {
                    double d4 = i2;
                    Double.isNaN(d4);
                    i2 = (int) (d4 + (d2 * d2) + 9.0d);
                    int[] iArr = iArrFld;
                    int i6 = i5 + 1;
                    iArr[i6] = iArr[i6] - iArr[i5 - 1];
                } else {
                    i3 = 1;
                }
                i4 *= (int) instanceCount;
                d3 += d3;
                d2 += 1.0d;
            } while (d2 < 6.0d);
            i5++;
        } while (i5 < 263);
        vMeth_check_sum += ((((((((Float.floatToIntBits(f) + i2) + Double.doubleToLongBits(d3)) + i5) + Double.doubleToLongBits(d2)) + 0) + i3) + i4) - 251) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static int iMeth(long j, int i, int i2) {
        boolean[] zArr = new boolean[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(jArr, 6L);
        int i3 = (i >>> 1) % N;
        int i4 = (i2 >>> 1) % N;
        zArr[i3] = zArr[i4];
        int i5 = i2 * ((int) jArr[i4]);
        vMeth(-101.447f, i, dFld);
        int i6 = 11;
        int i7 = 2;
        short s = -10944;
        if (bFld) {
            while (i6 < 180) {
                int i8 = i6 % 1;
                int[] iArr = iArrFld;
                iArr[i6] = iArr[i6] << i6;
                s = (short) (s - ((short) 2));
                i6++;
            }
            int[] iArr2 = iArrFld;
            iArr2[1] = iArr2[1] * (-2);
            i5 -= i6;
            jArr[195] = jArr[195] - instanceCount;
        } else if (bFld) {
            i7 = 2 - ((int) dFld);
        } else {
            byFld = (byte) (byFld * ((byte) dFld));
        }
        byFld = (byte) i7;
        long checkSum = j + i + i5 + i6 + i7 + s + FuzzerUtils.checkSum(zArr) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, 241L);
        int i = -8;
        int i2 = -26279;
        int i3 = -30;
        int i4 = -2;
        int i5 = 30;
        int i6 = 222;
        int i7 = -121;
        float f = 1.1f;
        int i8 = 13;
        while (i8 < 271) {
            iArrFld = FuzzerUtils.int1array(N, -246);
            iMeth(instanceCount, i8, i8);
            int i9 = ((i8 % 2) * 5) + 82;
            if (i9 == 84) {
                if (!bFld) {
                    int i10 = ((i8 % 7) * 5) + 12;
                    int i11 = 1;
                    if (i10 == 18) {
                        double d = dFld;
                        double d2 = byFld | 1;
                        Double.isNaN(d2);
                        dFld = d / d2;
                    } else if (i10 != 28) {
                        if (i10 != 38) {
                            if (i10 != 34) {
                                if (i10 == 35) {
                                    long j = instanceCount & 14;
                                    instanceCount = j;
                                    i <<= -19576;
                                    dFld = j;
                                    i2 = 1;
                                    while (97 > i2) {
                                        long j2 = i4;
                                        instanceCount = j2;
                                        i3 = (int) (i3 + (((i3 * i2) + j2) - (-5632)));
                                        int i12 = 3;
                                        int i13 = i6;
                                        int i14 = 3;
                                        while (i14 > i11) {
                                            i13 >>= i4;
                                            i -= i14;
                                            long j3 = instanceCount << i4;
                                            instanceCount = j3;
                                            instanceCount = j3 + i3;
                                            if (!bFld) {
                                                if (bFld) {
                                                    break;
                                                }
                                                this.iFld += 152;
                                                long j4 = instanceCount - i14;
                                                instanceCount = j4;
                                                jArr[i2][i8] = j4;
                                            }
                                            i14--;
                                        }
                                        this.iFld = i2;
                                        int i15 = 1;
                                        while (true) {
                                            i15 += i11;
                                            if (i15 < i12) {
                                                int i16 = this.iFld1 >> (-21569);
                                                this.iFld1 = i16;
                                                this.iFld = i16;
                                                boolean z = bFld1;
                                                if (z) {
                                                    int[] iArr = iArrFld;
                                                    int i17 = i2 + 1;
                                                    int i18 = iArr[i17];
                                                    long j5 = instanceCount;
                                                    iArr[i17] = i18 - ((int) j5);
                                                    i13 += ((i15 * i2) + i3) - i;
                                                    instanceCount = j5 >> i;
                                                    i14 = i14;
                                                    i12 = 3;
                                                    i11 = 1;
                                                } else {
                                                    int i19 = i14;
                                                    if (z) {
                                                        this.iFld = 139;
                                                        i14 = i19;
                                                        i12 = 3;
                                                        i11 = 1;
                                                    } else {
                                                        i3 += (int) dFld;
                                                        i14 = i19;
                                                        i12 = 3;
                                                        i11 = 1;
                                                    }
                                                }
                                            }
                                        }
                                        int i20 = i14;
                                        i2 += 2;
                                        i6 = i13;
                                        i7 = i15;
                                        i5 = i20;
                                        i11 = 1;
                                    }
                                } else if (i10 == 44) {
                                    i = i7;
                                } else if (i10 == 45) {
                                    i4 *= 135;
                                }
                            }
                        }
                        f = i2;
                    } else {
                        iArrFld[i8 + 1] = (int) instanceCount;
                    }
                    this.iFld -= i;
                }
            } else {
                if (i9 == 87) {
                    f *= (float) lFld;
                }
                iArrFld[i8] = i8;
            }
            i8++;
        }
        FuzzerUtils.out.println("i i1 i20 = " + i8 + "," + i + "," + i2);
        FuzzerUtils.out.println("i21 i22 i23 = " + i3 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i24 i25 f3 = " + i6 + "," + i7 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.byFld iFld iFld1 = " + ((int) byFld) + "," + this.iFld + "," + this.iFld1);
        FuzzerUtils.out.println("Test.bFld1 Test.lFld Test.iArrFld = " + (bFld1 ? 1 : 0) + "," + lFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
