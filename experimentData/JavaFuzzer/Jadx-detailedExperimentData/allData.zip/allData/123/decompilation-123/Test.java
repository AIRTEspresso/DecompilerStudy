
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/123/original-123/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public static long instanceCount = -58487;
    public static short sFld = -24700;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public volatile double[][][] dArrFld = (double[][][]) Array.newInstance(double.class, N, N, N);
    public int[] iArrFld = new int[N];
    public long[][] lArrFld1 = (long[][]) Array.newInstance(long.class, N, N);
    public int[][] iArrFld1 = (int[][]) Array.newInstance(int.class, N, N);

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, -7L);
    }

    public static int iMeth() {
        float f;
        long j;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 57874);
        int i = 10;
        int i2 = -11;
        int i3 = -15555;
        float f2 = -2.34f;
        double d = -96.20907d;
        byte b = 25;
        int i4 = 1;
        do {
            float f3 = i4;
            f = f3;
            while (f < 5.0f) {
                int i5 = (int) f;
                i += i5;
                float f4 = f + 1.0f;
                iArr[(int) f4] = (int) d;
                int i6 = (((i >>> 1) % 2) * 5) + 111;
                if (i6 == 113) {
                    i3 = i5;
                    while (i3 < 1) {
                        instanceCount = i3;
                        b = (byte) (b + ((byte) (((i3 * f) + ((float) j)) - f3)));
                        i3++;
                    }
                    int i7 = (int) (f - 1.0f);
                    iArr[i7] = iArr[i7] >> i4;
                } else if (i6 == 120) {
                    d = 46531.0d;
                    f2 += f3;
                    i2 = 1;
                } else {
                    i = -3;
                }
                f = f4;
            }
            i4++;
        } while (i4 < 341);
        long floatToIntBits = ((((((((i4 + Float.floatToIntBits(f)) + i) + Double.doubleToLongBits(d)) + Float.floatToIntBits(f2)) + i2) + 247) + i3) - 3) + b + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1(int i, int i2) {
        long[] jArr = lArrFld;
        jArr[91] = jArr[91] >> (Math.min(-6357, (int) (66.929f - i)) - (iMeth() - i2));
        vMeth1_check_sum += ((i + i2) - 6437) + Float.floatToIntBits(66.929f);
    }

    public static void vMeth(int i, int i2, long j) {
        int i3;
        int i4;
        int i5;
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        byte[] bArr = new byte[N];
        float[] fArr = new float[N];
        int i6 = 1;
        FuzzerUtils.init(iArr, 1);
        FuzzerUtils.init(fArr, -1.738f);
        FuzzerUtils.init(bArr, (byte) 0);
        int i7 = i;
        int i8 = i2;
        long j2 = j;
        long j3 = 2074981987686830504L;
        double d = 0.1631d;
        int i9 = 268;
        int i10 = 48;
        int i11 = -1;
        int i12 = 26099;
        int i13 = 11588;
        while (true) {
            byte[] bArr2 = bArr;
            double d2 = d;
            if (i9 > 4) {
                switch ((i9 % 9) + 76) {
                    case 76:
                        double d3 = d2;
                        i3 = i7;
                        i6 = 1;
                        while (i6 < 18) {
                            long j4 = 1;
                            j3 = 1;
                            while (2 > j3) {
                                int i14 = i6 + 1;
                                int[] iArr2 = iArr[i14];
                                int i15 = i10;
                                int i16 = i11;
                                int i17 = (int) (j3 - j4);
                                int i18 = iArr2[i17];
                                int[] iArr3 = iArr[i14];
                                int i19 = i9 - 1;
                                int i20 = iArr3[i19];
                                iArr3[i19] = i20 - 1;
                                iArr2[i17] = i18 - ((int) (i20 - lArrFld[i9]));
                                vMeth1(i8, -99);
                                j4 = 1;
                                j3++;
                                i10 = i15;
                                i11 = i16;
                            }
                            int i21 = i10;
                            int i22 = i11;
                            int i23 = i6 + 1;
                            fArr[i23] = i6;
                            int i24 = i9 + 1;
                            try {
                                i3 = iArr[i24][i6] % i8;
                                i4 = (-58704) / i9;
                                try {
                                    i5 = i8 % (-1235870547);
                                } catch (ArithmeticException e) {
                                    i5 = i21;
                                    double d4 = i6;
                                    int[] iArr4 = iArr[i24];
                                    int i25 = i6 - 1;
                                    iArr4[i25] = iArr4[i25] >> i4;
                                    d3 = d4;
                                    i6 = i23;
                                    i11 = i4;
                                    j2 = -3;
                                    i13 = 2;
                                    i10 = i5;
                                }
                            } catch (ArithmeticException e2) {
                                i4 = i22;
                            }
                            double d42 = i6;
                            int[] iArr42 = iArr[i24];
                            int i252 = i6 - 1;
                            iArr42[i252] = iArr42[i252] >> i4;
                            d3 = d42;
                            i6 = i23;
                            i11 = i4;
                            j2 = -3;
                            i13 = 2;
                            i10 = i5;
                        }
                        d = d3;
                        try {
                            int i26 = i9 - 1;
                            i3 = iArr[i9][i9 + 1] % iArr[i26][i26];
                            int i27 = (-20843) % i12;
                            i10 = (-21) % i8;
                            i7 = i3;
                        } catch (ArithmeticException e3) {
                            i7 = i3;
                        }
                        i12 = 104;
                        break;
                    case 77:
                        d = d2;
                        i3 = i7;
                        int i262 = i9 - 1;
                        i3 = iArr[i9][i9 + 1] % iArr[i262][i262];
                        int i272 = (-20843) % i12;
                        i10 = (-21) % i8;
                        i7 = i3;
                        i12 = 104;
                        break;
                    case 78:
                        d = d2;
                        i12 = 104;
                        break;
                    case 79:
                        iArr[i9][i9] = i8;
                    case 80:
                        j2 = i13;
                        d = d2;
                        break;
                    case 81:
                        i10 += ((i9 * i7) + i11) - i13;
                        d = d2;
                        break;
                    case 82:
                        d = d2;
                        i10 = i6;
                        break;
                    case 83:
                        i8 -= i12;
                        d = d2;
                        break;
                    default:
                        d = d2;
                        break;
                }
                i9 -= 3;
                bArr = bArr2;
            } else {
                vMeth_check_sum += i7 + i8 + j2 + i9 + i10 + i6 + i11 + j3 + i12 + Double.doubleToLongBits(d2) + i13 + 104 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(bArr2);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int i;
        double d;
        float f;
        double d2;
        int i2;
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, true);
        int i3 = 11;
        double d3 = 1.65179d;
        int i4 = 10;
        int i5 = 4;
        int i6 = 11;
        int i7 = 18415;
        int i8 = -254;
        int i9 = -156;
        float f2 = -65.49f;
        int i10 = 4;
        double d4 = -1.104601d;
        double d5 = 28.15279d;
        int i11 = 6;
        while (304 > i4) {
            vMeth(i7, i7, instanceCount);
            double d6 = 86.0d;
            while (true) {
                boolean[] zArr2 = zArr;
                double d7 = i4;
                if (d6 > d7) {
                    d6 -= 2.0d;
                    zArr = zArr2;
                    i5 = 1;
                    i9 = 4;
                } else {
                    int i12 = 86;
                    while (true) {
                        double d8 = d7;
                        i = i12 - 3;
                        if (i > 0) {
                            i8 |= i7;
                            int i13 = i5;
                            sFld = (short) (sFld + ((short) (i + i3)));
                            int i14 = i6;
                            long j = instanceCount ^ i4;
                            instanceCount = j;
                            int i15 = ((i % 9) * 5) + 44;
                            int i16 = i7;
                            if (i15 != 54) {
                                if (i15 == 72) {
                                    d = d6;
                                    i6 = i14;
                                    this.iArrFld1 = this.iArrFld1;
                                    i8 = -55;
                                    i11 = (int) (i11 + ((((float) (i * instanceCount)) + f2) - i6));
                                    f = f2;
                                    i7 = (int) f;
                                    f2 = f;
                                    i5 = i13;
                                    d6 = d;
                                    i12 = i;
                                    d7 = d8;
                                } else if (i15 != 75) {
                                    if (i15 == 83) {
                                        d = d6;
                                        i6 = i14;
                                        i8 = -55;
                                        i11 = (int) (i11 + ((((float) (i * instanceCount)) + f2) - i6));
                                        f = f2;
                                        i7 = (int) f;
                                        f2 = f;
                                        i5 = i13;
                                        d6 = d;
                                        i12 = i;
                                        d7 = d8;
                                    } else if (i15 == 79) {
                                        d = d6;
                                        i6 = i14;
                                        i11 = (int) (i11 + ((((float) (i * instanceCount)) + f2) - i6));
                                        f = f2;
                                        i7 = (int) f;
                                        f2 = f;
                                        i5 = i13;
                                        d6 = d;
                                        i12 = i;
                                        d7 = d8;
                                    } else if (i15 != 80) {
                                        switch (i15) {
                                            case 68:
                                                d = d6;
                                                f = f2;
                                                i6 = i14;
                                                i7 = (int) f;
                                                f2 = f;
                                                i5 = i13;
                                                d6 = d;
                                                i12 = i;
                                                d7 = d8;
                                                break;
                                            case 69:
                                            case 70:
                                                instanceCount = j * 3801956899L;
                                                long j2 = instanceCount;
                                                instanceCount = j2 << ((int) j2);
                                                i5 = i13;
                                                i7 = i16;
                                                i6 = i14;
                                                i12 = i;
                                                d7 = d8;
                                                break;
                                            default:
                                                long j22 = instanceCount;
                                                instanceCount = j22 << ((int) j22);
                                                i5 = i13;
                                                i7 = i16;
                                                i6 = i14;
                                                i12 = i;
                                                d7 = d8;
                                                break;
                                        }
                                    } else {
                                        i8 -= 1502486984;
                                        i5 = i13;
                                        i7 = i16;
                                        i6 = i14;
                                        i12 = i;
                                        d7 = d8;
                                    }
                                }
                            }
                            int i17 = i3;
                            double d9 = d8;
                            i6 = i14;
                            while (d9 < 3.0d) {
                                int i18 = (int) (d9 * d9);
                                i6 = i6 + i18 + ((int) d9);
                                switch ((i4 % 7) + 12) {
                                    case 12:
                                        d2 = d6;
                                        i17 += i18;
                                        double d10 = instanceCount;
                                        Double.isNaN(d10);
                                        i6 += (int) (d10 + d9);
                                        break;
                                    case 13:
                                        i17 *= i17;
                                        int[] iArr = this.iArrFld;
                                        int i19 = i + 1;
                                        iArr[i19] = iArr[i19] >> i3;
                                        d2 = d6;
                                        instanceCount += (long) d9;
                                        i6 = i6;
                                        break;
                                    case 14:
                                        f2 += i9;
                                        d2 = d6;
                                        break;
                                    case 15:
                                        d3 -= -12.0d;
                                        d2 = d6;
                                        i6 = i6;
                                        break;
                                    case 16:
                                        long[] jArr = lArrFld;
                                        i2 = i6;
                                        jArr[i4] = jArr[i4] << ((int) instanceCount);
                                        d2 = d6;
                                        i6 = i2;
                                        break;
                                    case 17:
                                        this.lArrFld1 = FuzzerUtils.long2array(N, -127L);
                                        d2 = d6;
                                        break;
                                    case 18:
                                        d2 = d6;
                                        break;
                                    default:
                                        i2 = i6;
                                        d2 = d6;
                                        i6 = i2;
                                        break;
                                }
                                d9 += 1.0d;
                                d6 = d2;
                            }
                            d = d6;
                            i3 = i17;
                            d4 = d9;
                            this.iArrFld1 = this.iArrFld1;
                            i8 = -55;
                            i11 = (int) (i11 + ((((float) (i * instanceCount)) + f2) - i6));
                            f = f2;
                            i7 = (int) f;
                            f2 = f;
                            i5 = i13;
                            d6 = d;
                            i12 = i;
                            d7 = d8;
                        }
                    }
                    i4++;
                    i5 = i5;
                    zArr = zArr2;
                    i7 = i7;
                    i6 = i6;
                    d5 = d6;
                    i10 = i;
                }
            }
        }
        FuzzerUtils.out.println("i i1 b = " + i4 + "," + i7 + ",0");
        FuzzerUtils.out.println("d2 i18 i19 = " + Double.doubleToLongBits(d5) + "," + i3 + "," + i5);
        FuzzerUtils.out.println("i20 i21 i22 = " + i8 + "," + i9 + "," + i10);
        FuzzerUtils.out.println("d3 i23 i24 = " + Double.doubleToLongBits(d4) + "," + i11 + "," + i6);
        FuzzerUtils.out.println("f3 d4 bArr = " + Float.floatToIntBits(f2) + "," + Double.doubleToLongBits(d3) + "," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.lArrFld = " + instanceCount + "," + ((int) sFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("dArrFld iArrFld lArrFld1 = " + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) this.dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld1));
        FuzzerUtils.out.println("iArrFld1 = " + FuzzerUtils.checkSum(this.iArrFld1));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
