/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/122/original-122/Test.dex */
public class Test {
    public static final int N = 400;
    public static short[] sArrFld;
    public float fFld = 0.99f;
    public static long instanceCount = 2852157046L;
    public static int iFld = 11;
    public static long vSmallMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        short[] sArr = new short[N];
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) 19782);
    }

    public static void vMeth1(int i, int i2, int i3) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -24056);
        FuzzerUtils.init(jArr, 2513115404534364896L);
        int i4 = iFld;
        long j = instanceCount;
        int i5 = i4 & ((int) j);
        iFld = i5;
        iArr[(i5 >>> 1) % N] = (int) j;
        int i6 = i;
        int i7 = i2;
        int i8 = -63634;
        int i9 = 26;
        int i10 = -46396;
        float f = -44.323f;
        byte b = -51;
        int i11 = 2;
        for (int i12 = 0; i12 < 400; i12++) {
            long j2 = jArr[i12];
            i8 = 1;
            while (i8 < 4) {
                i10 = 1;
                while (2 > i10) {
                    i9 -= i9;
                    iArr[i8] = iArr[i8] & i7;
                    i6 = (int) f;
                    i10++;
                    iArr[i10] = iArr[i10] + iFld;
                    f -= i6;
                    b = (byte) (b + ((byte) i9));
                    i7 *= -4;
                }
                i11 -= 267;
                i8++;
            }
        }
        vMeth1_check_sum += ((((((((i6 + i7) + i3) + i8) + i9) + i10) + i11) + Float.floatToIntBits(f)) - 267) + b + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i) {
        int i2;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -8L);
        long j = 349;
        do {
            i2 = i;
            vMeth1(i2, -153, iFld);
            iFld += (int) (j * j);
            j--;
        } while (j > 0);
        double d = 1.0d;
        double d2 = 98.79058d;
        double d3 = 1.0d;
        while (true) {
            d3 += d;
            int i3 = 5623;
            float f = 1.64f;
            if (d3 < 187.0d) {
                long j2 = instanceCount;
                double d4 = i2;
                Double.isNaN(d4);
                double d5 = j;
                Double.isNaN(d5);
                Double.isNaN(d4);
                instanceCount = j2 + ((long) (((d3 * d4) + d5) - d4));
                instanceCount = -5L;
                instanceCount = -182;
                i2 = -182;
                d2 = 1.0d;
                while (9.0d > d2) {
                    int i4 = iFld;
                    double d6 = 12;
                    Double.isNaN(d6);
                    double d7 = i4;
                    Double.isNaN(d7);
                    double d8 = (d6 * d2) + d7;
                    double d9 = i3;
                    Double.isNaN(d9);
                    int i5 = i4 + ((int) (d8 - d9));
                    iFld = i5;
                    long j3 = instanceCount - 86;
                    instanceCount = j3;
                    int i6 = (int) j;
                    iFld = i5 * ((int) f);
                    int i7 = (int) d3;
                    jArr[i7] = jArr[i7] + i6;
                    instanceCount = j3 + ((long) d2);
                    d2 += 2.0d;
                    i2 = i6;
                    i3 = 5623;
                    f = 1.64f;
                }
                d = 1.0d;
            } else {
                vMeth_check_sum += i2 + j + Double.doubleToLongBits(d3) + Double.doubleToLongBits(d2) + 12 + 5623 + Float.floatToIntBits(1.64f) + FuzzerUtils.checkSum(jArr);
                return;
            }
        }
    }

    public static void vSmallMeth(long j, int i) {
        vMeth(5835);
        iFld /= i | 1;
        vSmallMeth_check_sum += j + i;
    }

    public void mainTest(String[] strArr) {
        float[] fArr;
        FuzzerUtils.init(new float[N], 1.382f);
        short[] sArr = sArrFld;
        int i = iFld;
        int i2 = (i >>> 1) % N;
        int i3 = ((int) ((instanceCount * 180) ^ (-1))) & i;
        iFld = i3;
        sArr[i2] = (short) i3;
        float f = this.fFld - 1.0f;
        this.fFld = f;
        int i4 = (int) ((f + 16415) - 358191715);
        int i5 = -59418;
        int i6 = 290;
        while (i6 > 2) {
            long j = instanceCount;
            instanceCount = 1 + j;
            i5 = (int) (((float) j) + this.fFld);
            i6--;
        }
        for (int i7 = 0; i7 < 282; i7++) {
            vSmallMeth(instanceCount, i5);
        }
        int i8 = i5 + i4;
        int i9 = 7;
        while (i9 < 137) {
            i4 >>= i9;
            i9++;
        }
        FuzzerUtils.out.println("i s i1 = " + i4 + ",-5406," + i6);
        FuzzerUtils.out.println("i2 i14 i15 = " + i8 + "," + i9 + ",15");
        FuzzerUtils.out.println("fArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
