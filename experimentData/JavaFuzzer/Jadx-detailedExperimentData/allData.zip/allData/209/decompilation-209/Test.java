
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/209/original-209/Test.dex */
public class Test {
    public static int[] iArrFld;
    public static long instanceCount = 30605;
    public static short sFld = 2324;
    public static int iFld1 = 8;
    public static boolean bFld = false;
    public static final int N = 400;
    public static double[] dArrFld = new double[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public int iFld = -38635;
    public boolean bFld1 = false;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -216);
        FuzzerUtils.init(dArrFld, -116.86471d);
    }

    public static void vMeth(float f) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 2648983453L);
        int i = 41;
        int i2 = 104;
        int i3 = 2222;
        int i4 = 343;
        while (7 < i4) {
            i3 -= (int) instanceCount;
            int[] iArr = iArrFld;
            int i5 = i4 + 1;
            iArr[i5] = iArr[i5] >> 54;
            iArr[i4] = iArr[i4] + ((int) f);
            iArrFld = iArr;
            i = 1;
            while (i < 9) {
                double[] dArr = dArrFld;
                double d = dArr[i4];
                double d2 = i;
                Double.isNaN(d2);
                dArr[i4] = d * d2;
                i++;
            }
            instanceCount -= 2471792388101766201L;
            jArr[i5] = jArr[i5] - i2;
            f *= -135.0f;
            i2 -= (int) 1.8612d;
            i4 -= 2;
        }
        long j = instanceCount >> 57233;
        instanceCount = j;
        instanceCount = j + i;
        vMeth_check_sum += Float.floatToIntBits(f) + i3 + i4 + 54 + i + i2 + Double.doubleToLongBits(1.8612d) + FuzzerUtils.checkSum(jArr);
    }

    public static int iMeth1() {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -3134388285L);
        long j = jArr[42];
        vMeth(2.307f);
        int i = 10;
        int i2 = -12985;
        int i3 = 4;
        int i4 = -14;
        int i5 = 141;
        int i6 = 45291;
        int i7 = 13;
        while (i7 < 290) {
            i3 = 1;
            while (i3 < 6) {
                instanceCount += sFld * i3;
                i5 = 1;
                while (i5 < 3) {
                    i5++;
                }
                int i8 = ((i7 % 2) * 5) + 16;
                if (i8 == 22) {
                    i2 += i3 ^ i2;
                    i += i3;
                } else if (i8 == 23) {
                    instanceCount += i2;
                    i6 += i3;
                } else {
                    i4 += 10;
                }
                i3 += 2;
            }
            i7++;
        }
        long floatToIntBits = i6 + Float.floatToIntBits(2.307f) + i7 + i2 + i3 + i4 + i5 + i + 1 + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static int iMeth(int i, int i2, float f) {
        int i3;
        boolean[] zArr = new boolean[N];
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init((Object[][]) jArr, (Object) (-2765748243573170087L));
        int i4 = i;
        float f2 = f;
        double d = -6.6663d;
        int i5 = 10;
        int i6 = 24893;
        int i7 = 4;
        int i8 = -190;
        byte b = -21;
        int i9 = 196;
        while (true) {
            boolean z = true;
            if (7 < i9) {
                i5 = i9;
                while (24 > i5) {
                    i5++;
                    iArrFld[i5] = i7;
                    b = (byte) (b * ((byte) i7));
                    i7++;
                }
                d = 1.0d;
                while (d < 24.0d) {
                    zArr[i9] = z;
                    double d2 = instanceCount;
                    Double.isNaN(d2);
                    int i10 = i8;
                    byte b2 = b;
                    double d3 = i2;
                    Double.isNaN(d3);
                    Double.isNaN(d3);
                    f2 += (float) (((d2 * d) + d3) - d3);
                    int i11 = i6 - 1;
                    i4 >>= i6 >> iMeth1();
                    iFld1 = i9;
                    int[] iArr = iArrFld;
                    int i12 = i9 - 1;
                    iArr[i12] = iArr[i12] * ((int) f2);
                    switch ((i9 % 8) + 46) {
                        case 46:
                            f2 += (float) d;
                            i8 = 1;
                            while (i8 < 2) {
                                long j = instanceCount;
                                long j2 = j + j;
                                instanceCount = j2;
                                instanceCount = j2 << i5;
                                i8++;
                            }
                            i6 = i11;
                            break;
                        case 47:
                            i8 = i10;
                            i4 = i11;
                            i6 = i4;
                            break;
                        case 48:
                            i3 = i11;
                            long[] jArr2 = jArr[i9 + 1][(int) d];
                            int i13 = (int) (d + 1.0d);
                            jArr2[i13] = jArr2[i13] + 7;
                            i8 = i10;
                            i6 = i3;
                            break;
                        case 49:
                            i6 = i10;
                            i8 = i6;
                            break;
                        case 50:
                            i3 = i11;
                            instanceCount = instanceCount;
                            i8 = i10;
                            i6 = i3;
                            break;
                        case 51:
                            i3 = i11;
                            instanceCount = i7 & instanceCount;
                            iArrFld[i9] = (int) instanceCount;
                            i8 = i10;
                            i6 = i3;
                            break;
                        case 52:
                            i3 = i11;
                            iArrFld[i9] = (int) instanceCount;
                            i8 = i10;
                            i6 = i3;
                            break;
                        default:
                            i3 = i11;
                            i8 = i10;
                            i6 = i3;
                            break;
                    }
                    d += 1.0d;
                    b = b2;
                    z = true;
                }
                i9 -= 3;
            } else {
                long floatToIntBits = ((((((((((i4 + i2) + Float.floatToIntBits(f2)) + i9) + 33) + i5) + i6) + i7) + b) + Double.doubleToLongBits(d)) - 5) + 1 + i8 + 9 + 7 + FuzzerUtils.checkSum(zArr) + FuzzerUtils.checkSum((Object[][]) jArr);
                iMeth_check_sum += floatToIntBits;
                return (int) floatToIntBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        long[] jArr;
        int i = N;
        long[] jArr2 = new long[N];
        FuzzerUtils.init(jArr2, -3L);
        long j = instanceCount & (-6);
        instanceCount = j;
        int i2 = this.iFld;
        float f = 110.93f;
        int iMeth = i2 >> ((int) ((((-7) - iArrFld[(i2 >>> 1) % N]) + (j + i2)) + iMeth(i2, iFld1, 110.93f)));
        this.iFld = iMeth;
        instanceCount -= iMeth;
        int i3 = iFld1;
        int i4 = (i3 >>> 1) % N;
        jArr2[i4] = jArr2[i4] >> i3;
        iFld1 = i3;
        int i5 = 1;
        int i6 = 30670;
        int i7 = -24787;
        int i8 = -4;
        int i9 = 174;
        double d = -116.124496d;
        int i10 = 1;
        while (true) {
            i10 += i5;
            if (i10 < 323) {
                int i11 = this.iFld;
                switch (((i11 >>> 1) % 10) + 74) {
                    case 74:
                        jArr = jArr2;
                        int i12 = i11 + 13;
                        this.iFld = i12;
                        this.iFld = i12 * (-3);
                        double d2 = instanceCount;
                        Double.isNaN(d2);
                        d += d2;
                        break;
                    case 75:
                        this.iFld = (int) f;
                        if (bFld) {
                            try {
                                this.iFld = iArrFld[i10 - 1] / (-119);
                                int i13 = iArrFld[i10] / iFld1;
                                iFld1 = i13;
                                iFld1 = i10 % i13;
                            } catch (ArithmeticException e) {
                            }
                        }
                    case 76:
                        i6 = i10;
                        while (i6 < 78) {
                            double d3 = i10;
                            Double.isNaN(d3);
                            d -= d3;
                            f += i10;
                            long j2 = instanceCount;
                            long[] jArr3 = jArr2;
                            long j3 = j2 + (((i6 * j2) + iFld1) - j2);
                            instanceCount = j3;
                            jArr3[i10] = jArr3[i10] + j3;
                            i6++;
                            jArr2 = jArr3;
                        }
                        jArr = jArr2;
                        break;
                    case 77:
                        jArr = jArr2;
                        i8 = -12;
                        break;
                    case 78:
                        i8 >>>= i10;
                    case 79:
                        iFld1 += 13;
                        jArr = jArr2;
                        break;
                    case 80:
                        i9 -= 24120;
                        jArr = jArr2;
                        break;
                    case 81:
                        instanceCount >>= -65003;
                        jArr = jArr2;
                        break;
                    case 82:
                        dArrFld = FuzzerUtils.double1array(i, 2.75698d);
                    case 83:
                        jArr = jArr2;
                        i7 = (int) d;
                        break;
                    default:
                        jArr = jArr2;
                        break;
                }
                jArr2 = jArr;
                i = N;
                i5 = 1;
            } else {
                FuzzerUtils.out.println("f3 i23 d2 = " + Float.floatToIntBits(f) + "," + i10 + "," + Double.doubleToLongBits(d));
                FuzzerUtils.out.println("i24 i25 i26 = " + i6 + "," + i7 + ",61226");
                FuzzerUtils.out.println("i27 i28 i29 = " + i8 + ",11,-12");
                FuzzerUtils.out.println("by1 i30 lArr3 = 92," + i9 + "," + FuzzerUtils.checkSum(jArr2));
                FuzzerUtils.out.println("Test.instanceCount iFld Test.sFld = " + instanceCount + "," + this.iFld + "," + ((int) sFld));
                FuzzerUtils.out.println("Test.iFld1 Test.bFld bFld1 = " + iFld1 + "," + (bFld ? 1 : 0) + "," + (this.bFld1 ? 1 : 0));
                FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
