
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/102/original-102/Test.dex */
public class Test {
    public static final int N = 400;
    public boolean bFld = true;
    public static long instanceCount = 2;
    public static double dFld = -1.43384d;
    public static byte byFld = 18;
    public static long vSmallMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    public static void vMeth1() {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(jArr, 2555038843L);
        FuzzerUtils.init(iArr, -21805);
        FuzzerUtils.init(bArr, (byte) 88);
        int i = -36503;
        int i2 = -192;
        int i3 = 26016;
        float f = 1.23f;
        int i4 = 266;
        while (i4 > 9) {
            jArr[i4 - 1] = i4;
            long j = instanceCount;
            instanceCount = j >> ((int) j);
            i = 6;
            while (i > 1) {
                iArr[i4] = iArr[i4] + 38549;
                i2 += i3;
                f += (i * i) + 21722;
                dFld = -7560;
                i--;
            }
            instanceCount += (i4 * i4) + 69;
            i3 >>>= i2;
            i4--;
        }
        vMeth1_check_sum += ((((((i4 + 63745) + i) + i2) + i3) + Float.floatToIntBits(f)) - 7560) + 44635 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(bArr);
    }

    public static void vMeth(boolean z, int i, int i2) {
        vMeth1();
        int i3 = 1;
        while (i3 < 13) {
            instanceCount = instanceCount;
            instanceCount = i;
            i3++;
        }
        vMeth_check_sum += (((((z ? 1 : 0) + i) + i2) + 6) - 210) + i3 + 12 + Float.floatToIntBits(-115.688f);
    }

    public static void vSmallMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -8);
        vMeth(false, -242, -242);
        iArr[10] = 96;
        vSmallMeth_check_sum += (-242) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        double[][][] dArr;
        Test test = this;
        int[] iArr = new int[N];
        double[][][] dArr2 = (double[][][]) Array.newInstance(double.class, N, N, N);
        FuzzerUtils.init(iArr, 73);
        FuzzerUtils.init((Object[][]) dArr2, (Object) Double.valueOf(36.7684d));
        for (int i2 = 0; i2 < 675; i2++) {
            vSmallMeth();
        }
        int i3 = 20767;
        instanceCount = 20767;
        float f = 172.0f;
        int i4 = -171;
        int i5 = 53658;
        int i6 = -63109;
        int i7 = -14385;
        int i8 = 3691;
        int i9 = -14208;
        int i10 = 8;
        float f2 = -53.762f;
        float f3 = 47.1005f;
        short s = -15362;
        int i11 = 4;
        while (true) {
            f -= 2.0f;
            if (f > 0.0f) {
                f2 = f;
                while (f2 < 291.0f) {
                    dFld -= -4.0d;
                    instanceCount -= 14;
                    instanceCount = -38L;
                    f2 += 2.0f;
                    i3 = i4;
                }
                int i12 = i3 + ((int) instanceCount);
                i9 = i9;
                i10 = i10;
                i5 = 4;
                while (true) {
                    i = i12;
                    if (i5 < 291) {
                        i7 = 1;
                        while (true) {
                            int i13 = 2;
                            if (i7 < 2) {
                                dFld = i6;
                                i4 &= i7;
                                s = (short) (s + 15259);
                                i7++;
                                f = f;
                            } else {
                                float f4 = f;
                                i12 = i;
                                int i14 = 1;
                                while (i13 > i14) {
                                    i8 *= i5;
                                    if (test.bFld) {
                                        i6 = (int) instanceCount;
                                        i10 += i14;
                                        dArr = dArr2;
                                        i4 = s;
                                    } else {
                                        int i15 = i10;
                                        int i16 = i11;
                                        long j = i14;
                                        dArr = dArr2;
                                        long j2 = instanceCount;
                                        int i17 = (int) (i12 + (j - j2));
                                        i8 += (int) j2;
                                        int i18 = (int) (f4 + 1.0f);
                                        iArr[i18] = iArr[i18] + 10;
                                        switch (((i8 >>> 1) % 10) + 127) {
                                            case 127:
                                                dArr[i5 - 1][(int) (f4 - 1.0f)][i14 - 1] = i8;
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 128:
                                                double d = dFld;
                                                double d2 = i14;
                                                Double.isNaN(d2);
                                                dFld = d + d2;
                                                i6 += i14;
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 129:
                                                i6 += (i14 * i14) - 192;
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 130:
                                                i15 -= i7;
                                            case 131:
                                                iArr[i5] = iArr[i5] + i7;
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 132:
                                                f3 += (float) j2;
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 133:
                                                i8 = ((int) j2) ^ i8;
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 134:
                                                i12 = byFld;
                                                i4 = s;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            case 135:
                                                instanceCount = j2 + i17;
                                            case 136:
                                                i4 = s ^ i5;
                                                i12 = i17;
                                                i10 = i15;
                                                i11 = i16;
                                                break;
                                            default:
                                                i11 = (int) (i16 + ((((float) (j * j2)) + f2) - ((float) j2)));
                                                i12 = i17;
                                                i4 = s;
                                                i10 = i15;
                                                break;
                                        }
                                    }
                                    i14++;
                                    i13 = 2;
                                    test = this;
                                    dArr2 = dArr;
                                }
                                i5++;
                                i9 = i14;
                                f = f4;
                                test = this;
                            }
                        }
                    }
                }
                test = this;
                i3 = i;
            } else {
                FuzzerUtils.out.println("i12 f2 f3 = " + i3 + "," + Float.floatToIntBits(f) + "," + Float.floatToIntBits(f2));
                FuzzerUtils.out.println("i13 i14 i15 = " + i4 + "," + i5 + "," + i6);
                FuzzerUtils.out.println("i16 i17 s1 = " + i7 + "," + i8 + "," + ((int) s));
                FuzzerUtils.out.println("i18 i19 f4 = " + i9 + "," + i10 + "," + Float.floatToIntBits(f3));
                FuzzerUtils.out.println("i20 iArr2 dArr = " + i11 + "," + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) dArr2)));
                FuzzerUtils.out.println("Test.instanceCount Test.dFld bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (this.bFld ? 1 : 0));
                FuzzerUtils.out.println("Test.byFld = " + ((int) byFld));
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
