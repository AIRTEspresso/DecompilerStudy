/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/168/original-168/Test.dex */
public class Test {
    public static float[] fArrFld;
    public static volatile long instanceCount = -8;
    public static short sFld = 20299;
    public static volatile float fFld = 42.963f;
    public static double dFld = 0.87786d;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static int[] iArrFld1 = new int[N];
    public static long[] lArrFld = new long[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, -60.656f);
        FuzzerUtils.init(iArrFld, -6);
        FuzzerUtils.init(iArrFld1, -10);
        FuzzerUtils.init(lArrFld, -13L);
    }

    public static int iMeth(long j) {
        int i = 196;
        float f = -73.448f;
        double d = 0.36287d;
        int i2 = 0;
        int i3 = 7;
        while (i3 < 126) {
            i2 += i2;
            i = 13;
            while (i > 1) {
                float[] fArr = fArrFld;
                int i4 = i3 + 1;
                fArr[i4] = fArr[i4] - sFld;
                int i5 = i2 * ((int) f);
                f = i;
                i2 = i5 + (i | 103);
                double d2 = instanceCount;
                Double.isNaN(d2);
                d += d2;
                i--;
            }
            fFld /= i3 | 1;
            i3++;
        }
        long floatToIntBits = (((j + i2) + i3) - 8) + i + 103 + Float.floatToIntBits(f) + 1 + Double.doubleToLongBits(d);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1() {
        double d;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 60L);
        FuzzerUtils.init(iArr, 10);
        int i = 0;
        jArr[369] = 0;
        int i2 = -157;
        double d2 = 1.102163d;
        int i3 = 6;
        while (i3 < 233) {
            short s = sFld;
            Double.isNaN(iMeth(instanceCount));
            sFld = (short) (s + ((short) (d * (-99.7755d))));
            double d3 = i3;
            Double.isNaN(d3);
            d2 -= d3;
            i2 = -31029;
            fFld += i3 - 31029;
            fFld = -31029;
            i3++;
        }
        int i4 = 25151;
        int i5 = -47664;
        int i6 = 52921;
        for (int i7 = N; i < i7; i7 = N) {
            int i8 = iArr[i];
            int i9 = 1;
            while (i9 < 4) {
                fFld = fFld;
                i9++;
            }
            int i10 = i9;
            instanceCount += i4;
            i6 = 1;
            while (i6 < 4) {
                i2 = (int) (i2 + (i6 - instanceCount));
                i6++;
                iArr = iArr;
            }
            i4 += i8;
            i++;
            i5 = i10;
        }
        vMeth1_check_sum += (((((i2 + i3) + i4) + Double.doubleToLongBits(d2)) + i5) - 92) + i6 + 3 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
    }

    public void vMeth(int i, int i2, int i3) {
        int i4;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 209);
        int i5 = i2;
        int i6 = -13;
        int i7 = 238;
        while (true) {
            i7 -= 3;
            if (i7 <= 0) {
                break;
            }
            i5 += i7 * i3;
            i6 = (i6 + (((i7 * i) + i6) - 17553)) >>> (i3 * (-6956));
        }
        vMeth1();
        long j = 9;
        int i8 = -14;
        int i9 = -60287;
        int i10 = 203;
        int i11 = i3;
        int i12 = i;
        while (j < 178) {
            i8 = (int) j;
            while (true) {
                if (i8 >= 27) {
                    break;
                }
                iArr[i8] = iArr[i8] + ((int) instanceCount);
                i9 += 35767;
                i11 ^= 17553;
                i8++;
            }
            int i13 = 1;
            int i14 = (i7 >>> 1) % 1;
            dFld = i12;
            for (i4 = 27; i13 < i4; i4 = 27) {
                instanceCount *= i7;
                i12 += i13 ^ 35767;
                i13++;
            }
            j += 3;
            i10 = i13;
        }
        vMeth_check_sum += i12 + i5 + i11 + i7 + i6 + 17553 + j + 35767 + i8 + i9 + i10 + 0 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        vMeth(14, 14, 14);
        int i2 = 20808;
        int i3 = -182;
        int i4 = -248;
        int i5 = 56853;
        int i6 = -19775;
        int i7 = -63336;
        int i8 = -14;
        int i9 = 107;
        int i10 = 4691;
        int i11 = 244;
        int i12 = 14 - ((int) instanceCount);
        int i13 = 14;
        while (i13 < 235) {
            int i14 = i2 + i2;
            i12 = i2;
            int i15 = 114;
            while (i15 > 7) {
                i4 *= i12;
                i5 = 2;
                while (i5 > 1) {
                    i5--;
                }
                int i16 = i12 - ((int) fFld);
                try {
                    i4 = iArrFld[i15 + 1] / iArrFld1[i13 - 1];
                    iArrFld1[i15] = iArrFld1[i15] / 2135;
                    i4 = i14 / 1430829216;
                } catch (ArithmeticException e) {
                }
                instanceCount = i16;
                long[] jArr = lArrFld;
                jArr[i13] = jArr[i13] - 1;
                i6 += i6;
                i12 = i16 + i15;
                i15--;
                i7 = 2;
            }
            int i17 = 4;
            for (int i18 = 114; i17 < i18; i18 = 114) {
                int i19 = i17;
                instanceCount ^= i13;
                switch ((i13 % 4) + 19) {
                    case 19:
                        i4 >>= 9157;
                        i = i19;
                        break;
                    case 20:
                    case 21:
                        i9 -= i15;
                        int[] iArr = iArrFld;
                        iArr[i19] = iArr[i19] % (sFld | 1);
                        i = i19;
                        break;
                    case 22:
                        i6 = (int) instanceCount;
                        instanceCount = i7;
                        i = i19;
                        break;
                    default:
                        i10 = 1;
                        while (i10 < 2) {
                            i11 *= i4;
                            i10++;
                        }
                        i = i19;
                        instanceCount += i;
                        i9 = i9;
                        break;
                }
                i17 = i + 1;
            }
            i13++;
            i8 = i17;
            i3 = i15;
            i2 = i14;
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + i12 + "," + i13 + "," + i2);
        FuzzerUtils.out.println("i26 i27 i28 = " + i3 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i29 b1 i30 = " + i6 + ",0," + i7);
        FuzzerUtils.out.println("i31 i32 i33 = " + i8 + "," + i9 + "," + i10);
        FuzzerUtils.out.println("i34 = " + i11);
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + ((int) sFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.dFld Test.fArrFld Test.iArrFld = " + Double.doubleToLongBits(dFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.iArrFld1 Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld1) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
