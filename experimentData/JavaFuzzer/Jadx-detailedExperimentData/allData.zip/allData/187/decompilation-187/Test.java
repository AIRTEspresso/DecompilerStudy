
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/187/original-187/Test.dex */
public class Test {
    public static final int N = 400;
    public static short[] sArrFld;
    public int[] iArrFld = new int[N];
    public long[][][] lArrFld = (long[][][]) Array.newInstance(long.class, N, N, N);
    public long[] lArrFld1 = new long[N];
    public static long instanceCount = -62556;
    public static volatile double dFld = -2.82475d;
    public static byte byFld = 11;
    public static float fFld = -124.883f;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        short[] sArr = new short[N];
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) -12561);
    }

    public static void vMeth(int i, float f) {
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, -130L);
        double d = dFld;
        double d2 = instanceCount;
        Double.isNaN(d2);
        dFld = d - d2;
        byFld = (byte) (byFld + ((byte) dFld));
        int i2 = i + i;
        int i3 = 1;
        while (181 > i3) {
            double d3 = dFld;
            double d4 = instanceCount;
            Double.isNaN(d4);
            dFld = d3 + d4;
            i3++;
        }
        vMeth_check_sum += (((((((((i2 + Float.floatToIntBits(f)) + i3) + 141) + 1) + 34626) + 5878) - 15212) - 1) - 11268) + FuzzerUtils.checkSum(jArr);
    }

    public static int iMeth1(boolean z, int i, int i2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 12);
        vMeth(i, fFld);
        int i3 = (i >>> 1) % N;
        iArr[i3] = iArr[i3] + i2;
        long checkSum = (z ? 1 : 0) + (i - 11) + i2 + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += checkSum;
        return (int) checkSum;
    }

    public static int iMeth(byte b) {
        int i;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -8);
        FuzzerUtils.init(jArr, 7L);
        int i2 = -102;
        int i3 = 49280;
        int i4 = 91;
        int i5 = -149;
        float f = 79.444f;
        int i6 = 10;
        while (352 > i6) {
            int i7 = i6 - 1;
            int i8 = i6 + 1;
            iArr[i7] = iArr[i7] - iArr[i8];
            float f2 = f;
            int i9 = i5;
            int i10 = i4;
            int i11 = 5;
            int i12 = i8;
            while (i11 > 1) {
                int i13 = i12;
                instanceCount += i11 * i11;
                iArr[i11] = iArr[i11] - 1;
                int i14 = i11 - 1;
                float f3 = f2;
                int max = (i11 ^ i6) + ((int) (i2 + i11 + i + Math.max(jArr[i14], b + f2)));
                int i15 = iArr[i7] - 1;
                iArr[i7] = i15;
                i10 -= i15;
                try {
                    i10 = 2 / iArr[i11 + 1];
                    max = 570083180 % i11;
                } catch (ArithmeticException e) {
                }
                int i16 = ((i11 % 2) * 5) + 99;
                if (i16 == 105) {
                    f2 = (float) instanceCount;
                    i2 = max;
                } else if (i16 == 107) {
                    iArr[i14] = iArr[i14] - i10;
                    i2 = i11 & i6;
                    f2 = f3;
                } else {
                    f2 = 2;
                    i2 = max;
                }
                i11--;
                i12 = i13;
                i9 = 2;
            }
            i3 = i11;
            i4 = i10;
            i5 = i9;
            i6 = i12;
            f = f2;
        }
        long floatToIntBits = (((((((b + i6) + i2) + i3) + i4) + Float.floatToIntBits(f)) + i5) - 31119) + 0 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -21.37566d);
        int i2 = -54651;
        int i3 = 6;
        int i4 = -11716;
        int i5 = -32187;
        int i6 = -12;
        int i7 = 243;
        long j = 3654779942L;
        int i8 = 0;
        for (int i9 = N; i8 < i9; i9 = N) {
            double d = dArr[i8];
            i2 += iMeth(byFld) * i2;
            i3 = 3;
            while (63 > i3) {
                int[] iArr = this.iArrFld;
                int i10 = i3 + 1;
                iArr[i10] = iArr[i10] + 219;
                i4 >>= byFld;
                instanceCount += i3;
                i3 = i10;
                dArr = dArr;
            }
            double[] dArr2 = dArr;
            long j2 = 3;
            j = 3;
            while (j < 63) {
                long j3 = i4;
                instanceCount -= j3;
                i6 = (int) fFld;
                int i11 = (int) (((j % j2) * 5) + 24);
                if (i11 == 27) {
                    i6 += 64048;
                    i = 2;
                } else if (i11 != 29) {
                    i = i11 != 31 ? 2 : -26734;
                } else {
                    i = 2;
                    i5 = 1;
                    for (int i12 = 2; i5 < i12; i12 = 2) {
                        i = (int) (i + (((i5 * j) + j3) - instanceCount));
                        i6 += i5;
                        byFld = (byte) (byFld | 12);
                        i7 = i5;
                        i5++;
                    }
                }
                i7 &= 2;
                long j4 = 1 + j;
                long[] jArr = this.lArrFld[(int) (j - 1)][(int) j4];
                int i13 = (int) j;
                jArr[i13] = jArr[i13] << i;
                j = j4;
                i2 = i6;
                j2 = 3;
            }
            i8++;
            dArr = dArr2;
        }
        dFld = fFld;
        FuzzerUtils.out.println("i i15 i16 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("b3 l i17 = 0," + j + "," + ((int) j));
        FuzzerUtils.out.println("i18 i19 i20 = " + i5 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("s2 dArr = -26734," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.byFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + ((int) byFld));
        FuzzerUtils.out.println("Test.fFld Test.sArrFld iArrFld = " + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("lArrFld lArrFld1 = " + FuzzerUtils.checkSum((Object[][]) this.lArrFld) + "," + FuzzerUtils.checkSum(this.lArrFld1));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
