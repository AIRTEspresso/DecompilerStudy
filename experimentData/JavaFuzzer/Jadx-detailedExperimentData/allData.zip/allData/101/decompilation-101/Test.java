
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/101/original-101/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public static long instanceCount = -73;
    public static volatile int iFld = -39797;
    public static boolean bFld = true;
    public static double dFld = 3.15632d;
    public static float fFld = -2.177f;
    public static byte byFld = 55;
    public static short sFld = -7885;
    public static boolean bFld1 = true;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;
    public int iFld1 = 8;
    public double[][][] dArrFld = (double[][][]) Array.newInstance(double.class, N, N, N);
    public int[] iArrFld = new int[N];

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 6L);
    }

    public static void vMeth2(double d) {
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(iArr, -198);
        int i = 136;
        int i2 = 130;
        int i3 = -8;
        int i4 = -43993;
        double d2 = -41.96886d;
        int i5 = 13;
        while (268 > i5) {
            d2 = 6.0d;
            while (d2 > 1.0d) {
                i *= -29920;
                d2 -= 1.0d;
            }
            i2 = 1;
            while (i2 < 6) {
                zArr[i2] = bFld;
                iFld = (int) (iFld + (i2 ^ instanceCount));
                instanceCount %= i5 | 1;
                i4 = 2;
                while (true) {
                    if (1 < i4) {
                        int i6 = i5 - 1;
                        iArr[i6] = iArr[i6] + i;
                        instanceCount *= -10;
                        long[] jArr = lArrFld;
                        int i7 = i5 + 1;
                        jArr[i7] = jArr[i7] >> i5;
                        i3 -= iFld;
                        if (bFld) {
                            i = i2;
                            break;
                        } else {
                            i4 -= 3;
                            i = i5;
                        }
                    }
                }
                i2++;
            }
            i5++;
        }
        vMeth2_check_sum += ((((((((Double.doubleToLongBits(d) + i5) - 10) + Double.doubleToLongBits(d2)) + i) + i2) + i3) + i4) - 6) + FuzzerUtils.checkSum(zArr) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth1(int i) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -2.782f);
        vMeth2(dFld);
        int i2 = 51840;
        int i3 = -9;
        int i4 = -7;
        int i5 = 51;
        int i6 = 11;
        while (i6 < 282) {
            int i7 = i5;
            int i8 = i4;
            int i9 = 1;
            while (i9 < 17) {
                int i10 = (i6 >>> 1) % N;
                fArr[i10] = fArr[i10] + i9;
                boolean z = bFld;
                if (!z) {
                    if (z) {
                        fFld = i2;
                    } else {
                        i8 = 1;
                        while (i8 < 2) {
                            long[] jArr = lArrFld;
                            int i11 = i9 + 1;
                            float f = fFld;
                            jArr[i11] = f;
                            iFld = (int) f;
                            lArrFld[i11] = i2;
                            i8++;
                        }
                        int i12 = 1;
                        while (true) {
                            if (i12 >= 2) {
                                i7 = i12;
                                break;
                            }
                            float f2 = i2;
                            i2 = (int) (f2 + (((i12 * fFld) + f2) - ((float) instanceCount)));
                            iFld = 58440;
                            if (bFld) {
                                i7 = i12;
                                break;
                            }
                            i12++;
                        }
                    }
                }
                i9++;
            }
            i6 += 3;
            i3 = i9;
            i4 = i8;
            i5 = i7;
        }
        vMeth1_check_sum += ((((((i + i6) + i2) + i3) + 21085) + i4) - 12) + i5 + 5 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public void vMeth(int i, long j, long j2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 4);
        int i2 = iFld * i;
        vMeth1(iFld);
        int i3 = -12;
        if (bFld) {
            iFld *= iFld;
        } else {
            i3 = (-12) * ((int) fFld);
            iArr[9] = -89;
        }
        vMeth_check_sum += i2 + j + j2 + 10 + i3 + Double.doubleToLongBits(101.56145d) + 11 + 64 + 20639 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = -5;
        int i3 = 371;
        while (true) {
            i3--;
            if (i3 <= 0) {
                break;
            }
            int i4 = iFld - 1;
            iFld = i4;
            i2 <<= i4 + i2;
            vMeth(i3, -49L, instanceCount);
            double[][][] dArr = this.dArrFld;
            int i5 = i3 + 1;
            double[] dArr2 = dArr[i5][i3];
            double d = dArr2[i5];
            double d2 = instanceCount;
            Double.isNaN(d2);
            dArr2[i5] = d + d2;
            dArr[i5][i5][i5] = i3;
            if (bFld) {
                break;
            }
            this.iArrFld[i3] = iFld;
            fFld += i3;
            iFld = 30403;
        }
        int i6 = 6;
        int i7 = -9;
        if (bFld1) {
            i = 223;
            while (i > 9) {
                i6 -= (int) instanceCount;
                i -= 3;
            }
        } else {
            i7 = (-9) - ((int) dFld);
            i = 10;
        }
        FuzzerUtils.out.println("i i1 i24 = " + i3 + "," + i2 + "," + i);
        FuzzerUtils.out.println("i25 i26 i27 = 0,-13," + i6);
        FuzzerUtils.out.println("i28 i29 f = 64474,10," + Float.floatToIntBits(4.56f));
        FuzzerUtils.out.println("i30 = " + i7);
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.bFld = " + instanceCount + "," + iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.dFld Test.fFld Test.byFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + ((int) byFld));
        FuzzerUtils.out.println("iFld1 Test.sFld Test.bFld1 = " + this.iFld1 + "," + ((int) sFld) + "," + (bFld1 ? 1 : 0));
        FuzzerUtils.out.println("Test.lArrFld dArrFld iArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) this.dArrFld)) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
