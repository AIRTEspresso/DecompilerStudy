
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/196/original-196/Test.dex */
public class Test {
    public static long instanceCount = 31;
    public static short sFld = 24809;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static volatile byte[] byArrFld = new byte[N];
    public static long[][] lArrFld = (long[][]) Array.newInstance(long.class, N, N);
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public volatile byte byFld = -90;
    public boolean bFld = true;
    public float[] fArrFld = new float[N];

    static {
        FuzzerUtils.init(iArrFld, -33534);
        FuzzerUtils.init(byArrFld, (byte) -3);
        FuzzerUtils.init(lArrFld, -54089L);
    }

    public static void vMeth1() {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 0.116437d);
        int i = -1;
        float f = 39.809f;
        int i2 = 1;
        int i3 = 1;
        while (true) {
            i2++;
            if (i2 < 248) {
                i3 = 1;
                while (i3 < 7) {
                    int i4 = i2 + 1;
                    double d = dArr[i4];
                    long j = instanceCount;
                    double d2 = j;
                    Double.isNaN(d2);
                    dArr[i4] = d * d2;
                    iArrFld[i2] = (int) j;
                    byArrFld[i2] = (byte) i2;
                    i *= (int) f;
                    f -= i3;
                    i3++;
                }
            } else {
                vMeth1_check_sum += i2 + i3 + i + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                return;
            }
        }
    }

    public static void vMeth(int i) {
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(fArr, 0.426f);
        FuzzerUtils.init(jArr, 5058943701552193298L);
        int min = i << ((int) Math.min(fArr[(i >>> 1) % N] * (i - 135), 25240 - (i + i)));
        vMeth1();
        int[] iArr = iArrFld;
        int length = iArr.length;
        int i2 = 0;
        int i3 = 0;
        int i4 = 89;
        int i5 = -53907;
        float f = 14.461f;
        while (true) {
            int i6 = -2102;
            if (i2 < length) {
                int i7 = iArr[i2];
                float f2 = f;
                int i8 = i5;
                int i9 = 1;
                while (4 > i9) {
                    f2 += 135;
                    i3 = 1;
                    while (i3 < 2) {
                        iArrFld = iArrFld;
                        instanceCount = -20L;
                        float f3 = f2 * i6;
                        jArr[i9] = i9;
                        long j = (-20) << i3;
                        instanceCount = j;
                        min += (int) j;
                        iArrFld = FuzzerUtils.int1array(N, 30646);
                        i8 += 135;
                        i3++;
                        f2 = f3;
                        i6 = -2102;
                    }
                    i9++;
                    i6 = -2102;
                }
                i2++;
                i4 = i9;
                i5 = i8;
                f = f2;
            } else {
                vMeth_check_sum += ((((((min + 135) + i4) + i5) + Float.floatToIntBits(f)) + i3) - 2102) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr);
                return;
            }
        }
    }

    public static float fMeth(long j) {
        int i = 10;
        int i2 = -7;
        int i3 = -214;
        int i4 = -28916;
        int i5 = 6;
        while (i5 < 317) {
            vMeth(i5);
            i = i5;
            while (i < 5) {
                try {
                    iArrFld[i5 + 1] = i3 % 704792885;
                    i3 = (-64980) / iArrFld[i5 - 1];
                } catch (ArithmeticException e) {
                }
                i3 = (sFld | i3) + 127;
                i4 = i5;
                while (i4 < 1) {
                    j = (long) 94.20718d;
                    i4++;
                }
                i += 3;
                i2 = 104;
            }
            i5++;
        }
        long doubleToLongBits = ((((((((j + i5) + 104) + i) + i2) + i3) - 127) + i4) - 79) + 1 + 0 + Double.doubleToLongBits(94.20718d);
        fMeth_check_sum += doubleToLongBits;
        return (float) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        float f;
        int i;
        long j = instanceCount;
        instanceCount = j - 1;
        int i2 = (int) j;
        int i3 = -161;
        int i4 = -9;
        int i5 = 192;
        float f2 = 12.179f;
        int i6 = 123;
        while (i6 > 6) {
            byte b = this.byFld;
            long j2 = instanceCount + 1;
            instanceCount = j2;
            this.byFld = (byte) (b << ((byte) j2));
            i3 *= (int) fMeth(instanceCount);
            long j3 = i3;
            instanceCount = j3;
            instanceCount = j3 * i2;
            i4 = 5;
            while (214 > i4) {
                short s = sFld;
                sFld = (short) (s >> s);
                long j4 = instanceCount + (((this.byFld * 1) + i6) - i2);
                instanceCount = j4;
                this.bFld = this.bFld;
                instanceCount = j4 | 43494;
                i3 += 1 | i2;
                this.fArrFld[0] = i4;
                f2++;
                this.byFld = (byte) (this.byFld + ((byte) (f * f2)));
                if (((i4 >>> 1) % 1) + 12 == 12) {
                    if (!this.bFld) {
                        instanceCount = 69L;
                        i3 -= i6;
                        i2++;
                    } else {
                        i5 = 3;
                        i4++;
                    }
                }
                if (this.bFld) {
                    long j5 = instanceCount + 1;
                    instanceCount = j5;
                    iArrFld = iArrFld;
                    lArrFld[0][i4] = j5;
                    i = i2 << 1;
                } else {
                    i = i2 << 212;
                }
                i2 = i - 1112228430;
                i5 = 3;
                i4++;
            }
            i6--;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i2 + "," + i6 + "," + i3);
        FuzzerUtils.out.println("i21 i22 i23 = " + i4 + ",-3," + i5);
        FuzzerUtils.out.println("f2 = " + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("Test.instanceCount byFld Test.sFld = " + instanceCount + "," + ((int) this.byFld) + "," + ((int) sFld));
        FuzzerUtils.out.println("bFld Test.iArrFld Test.byArrFld = " + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("Test.lArrFld fArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
