
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/106/original-106/Test.dex */
public class Test {
    public static final int N = 400;
    public static short[] sArrFld;
    public static long instanceCount = 5;
    public static int iFld = 55569;
    public static long bMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public double dFld = 106.59753d;
    public float fFld = -1.409f;
    public boolean bFld = false;
    public int[] iArrFld = new int[N];

    static {
        short[] sArr = new short[N];
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) -25998);
    }

    public static void vMeth1(int i, int i2, long j) {
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(fArr, 0.497f);
        FuzzerUtils.init(jArr, -2444275299L);
        FuzzerUtils.init(dArr, -2.116215d);
        float f = 8.263f;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 < 269) {
                int i4 = ((i3 % 7) * 5) + 32;
                if (i4 == 40) {
                    i2 += (int) f;
                    long j2 = instanceCount * i;
                    instanceCount = j2;
                    j += ((i3 * j2) + j) - i2;
                    i |= iFld;
                } else if (i4 == 42) {
                    i2 += ((i3 * i) + i) - i2;
                } else if (i4 == 51) {
                    int i5 = i3 - 1;
                    jArr[i5] = jArr[i5] - 97;
                } else {
                    if (i4 == 55) {
                        i += i3 * i3;
                        int i6 = i3 + 1;
                        double d = dArr[i6];
                        double d2 = j;
                        Double.isNaN(d2);
                        dArr[i6] = d * d2;
                        f = i3;
                    } else if (i4 == 60) {
                        i = i3;
                    } else if (i4 != 63 && i4 == 65) {
                    }
                    i2 = i;
                }
            } else {
                vMeth1_check_sum += i + i2 + j + i3 + Float.floatToIntBits(f) + 1 + 10972 + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                return;
            }
        }
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        float[][] fArr = (float[][]) Array.newInstance(float.class, N, N);
        FuzzerUtils.init(iArr, 9375);
        FuzzerUtils.init(fArr, 2.21f);
        int i = iFld;
        iFld = i;
        vMeth1(i, i, instanceCount);
        int i2 = iFld;
        int i3 = i2 * i2;
        iFld = i3;
        iArr[45] = iArr[45] * i3;
        iFld = i3;
        iFld = i3;
        int i4 = -10;
        float f = 0.268f;
        int i5 = 10;
        while (i5 < 207) {
            int i6 = 1;
            while (true) {
                i6++;
                if (i6 < 8) {
                    instanceCount -= i5;
                    f = 1.0f;
                }
            }
            i5++;
            i4 = i6;
        }
        vMeth_check_sum += i5 + 8 + i4 + Float.floatToIntBits(f) + 54853 + Double.doubleToLongBits(-108.109856d) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static boolean bMeth(int i, short s, int i2) {
        float f;
        byte b;
        double[] dArr = new double[N];
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(iArr, 78);
        FuzzerUtils.init(dArr, 83.2875d);
        FuzzerUtils.init(bArr, (byte) 58);
        int i3 = i2 - iArr[(i2 >>> 1) % N];
        vMeth();
        long j = instanceCount + i;
        instanceCount = j;
        iArr[69] = iArr[69] * ((int) j);
        int i4 = iFld * (-294958096);
        iFld = i4;
        int i5 = (i3 >>> 1) % N;
        double d = dArr[i5];
        double d2 = i4;
        Double.isNaN(d2);
        dArr[i5] = d * d2;
        for (int i6 = 0; i6 < 400; i6++) {
            byte b2 = bArr[i6];
            i3 -= (int) (-115.88184d);
            i -= i3;
        }
        int i7 = 1;
        do {
            f = (float) instanceCount;
            instanceCount = 1L;
            b = (byte) i;
            i7++;
            sArrFld[i7] = (short) i;
        } while (i7 < 350);
        long doubleToLongBits = i + s + i3 + Double.doubleToLongBits(-115.88184d) + i7 + Float.floatToIntBits(f) + b + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(bArr);
        bMeth_check_sum += doubleToLongBits;
        return doubleToLongBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        long[][] jArr;
        int[] iArr;
        int i;
        int i2 = 2;
        long[][] jArr2 = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr2, -544060613407401985L);
        int[] iArr2 = this.iArrFld;
        int length = iArr2.length;
        int i3 = -48;
        int i4 = -161;
        int i5 = 134;
        int i6 = 238;
        int i7 = 0;
        while (i7 < length) {
            int i8 = iArr2[i7];
            bMeth(i8, (short) 21006, iFld);
            int[] iArr3 = this.iArrFld;
            iArr3[(i8 >>> 1) % N] = (int) this.dFld;
            this.iArrFld = iArr3;
            int i9 = i8 * ((int) instanceCount);
            int i10 = 3;
            while (true) {
                int i11 = 1;
                if (i10 < 63) {
                    i5 = 1;
                    while (i5 < i2) {
                        int i12 = ((i10 % 2) * 5) + 103;
                        if (i12 != 105) {
                            if (i12 != 109) {
                                i = i9;
                                jArr = jArr2;
                            } else {
                                int i13 = iFld + 7137;
                                iFld = i13;
                                long[] jArr3 = jArr2[i10];
                                int i14 = i5 + 1;
                                jArr = jArr2;
                                jArr3[i14] = i4 & jArr3[i14];
                                int i15 = i10 % 1;
                                if (i15 + 1 == i11) {
                                    i6 *= i13;
                                    iFld = (int) instanceCount;
                                    sArrFld = sArrFld;
                                    int[] iArr4 = this.iArrFld;
                                    iArr4[i14] = iArr4[i14] + 13;
                                } else if (i15 + 71 == 71) {
                                    i9 += i5;
                                    i4 = (int) instanceCount;
                                }
                                i4 >>= i4;
                                i = i9;
                            }
                            this.fFld += i5;
                            this.fFld = (float) instanceCount;
                            try {
                                iFld = i6 / i;
                                iFld = this.iArrFld[i10] / (-3633);
                                iFld = (-30624) / i6;
                            } catch (ArithmeticException e) {
                            }
                            long j = instanceCount;
                            iArr = iArr2;
                            iFld = (int) (iFld + (((i5 * j) + j) - i10));
                            i9 = i;
                        } else {
                            jArr = jArr2;
                            iArr = iArr2;
                        }
                        i5++;
                        iArr2 = iArr;
                        jArr2 = jArr;
                        i2 = 2;
                        i11 = 1;
                    }
                    int i16 = iFld;
                    iFld = i16 + (((i10 * i6) + i16) - i5);
                    i10++;
                    jArr2 = jArr2;
                    i2 = 2;
                }
            }
            long[][] jArr4 = jArr2;
            jArr4[(i5 >>> 1) % N][(iFld >>> 1) % N] = (long) this.dFld;
            int[] iArr5 = this.iArrFld;
            int i17 = (i6 >>> 1) % N;
            iArr5[i17] = iArr5[i17] << i5;
            i7++;
            i3 = i10;
            iArr2 = iArr2;
            jArr2 = jArr4;
            i2 = 2;
        }
        this.bFld = this.bFld;
        FuzzerUtils.out.println("i12 i13 i14 = " + i3 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i15 lArr1 = " + i6 + "," + FuzzerUtils.checkSum(jArr2));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("fFld bFld iArrFld = " + Float.floatToIntBits(this.fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
