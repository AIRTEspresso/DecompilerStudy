
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/109/original-109/Test.dex */
public class Test {
    public static int[][] iArrFld;
    public byte byFld = -23;
    public static long instanceCount = -2045395048;
    public static int iFld = 49267;
    public static volatile int iFld1 = 36669;
    public static short sFld = 27557;
    public static volatile float fFld = 1.39f;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -140);
        FuzzerUtils.init(fArrFld, -2.671f);
        FuzzerUtils.init(lArrFld, -9098027689776070920L);
    }

    public static void vMeth(double d) {
        int[][] iArr = iArrFld;
        int i = iFld;
        iArr[(i >>> 1) % N][(i >>> 1) % N] = i;
        vMeth_check_sum += Double.doubleToLongBits(d);
    }

    public static int iMeth1(byte b, int i) {
        int i2;
        vMeth(0.6885d);
        int i3 = -169;
        int i4 = 49957;
        int i5 = 39110;
        int i6 = 3;
        int i7 = 149;
        while (i6 < 149) {
            i7 = 11;
            while (true) {
                i2 = 1;
                if (1 >= i7) {
                    break;
                }
                i3 >>>= 31927;
                int[][] iArr = iArrFld;
                iArr[i6] = iArr[i6 + 1];
                lArrFld = lArrFld;
                instanceCount = instanceCount;
                int[] iArr2 = iArr[i7 - 1];
                int i8 = i6 - 1;
                iArr2[i8] = iArr2[i8] & 31927;
                i7 -= 2;
            }
            i += i6;
            while (i2 < 11) {
                iArrFld[i6][i6 + 1] = i6;
                instanceCount <<= iFld1;
                i5 -= 122;
                int[] iArr3 = iArrFld[i2 - 1];
                iArr3[i2] = iArr3[i2] + 21208;
                i2++;
            }
            i6++;
            i4 = i2;
        }
        long doubleToLongBits = b + i + Double.doubleToLongBits(0.6885d) + i6 + i3 + i7 + 31927 + 0 + i4 + i5;
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static int iMeth(int i, int i2) {
        int[] iArr;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 236L);
        float[] fArr = fArrFld;
        int i3 = (i2 >>> 1) % N;
        int i4 = i2 - 1;
        fArr[i3] = fArr[i3] + ((-87) - i2);
        int i5 = (i >>> 1) % N;
        jArr[i5] = jArr[i5] * (i4 + (((float) instanceCount) - 95.459f)) * iMeth1((byte) 47, iFld1);
        int i6 = i * ((int) (-95.459f));
        int i7 = -125;
        int i8 = -3;
        byte b = -72;
        int i9 = 17;
        while (i9 < 293) {
            i7 >>= -14;
            sFld = (short) (sFld - ((short) instanceCount));
            b = (byte) instanceCount;
            i8 = 6;
            while (1 < i8) {
                i7 = iFld;
                iArrFld[i8 - 1][i9] = iArr[i9] - 983216869;
                iFld = i7 - ((int) instanceCount);
                i8 -= 2;
            }
            i9++;
        }
        long floatToIntBits = i6 + i4 + Float.floatToIntBits(-95.459f) + i9 + i7 + b + i8 + 76 + 1 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int[] iArr;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 0.111897d);
        int i2 = 9;
        int i3 = -3;
        int i4 = 29847;
        int i5 = -224;
        int i6 = -216;
        int i7 = -37466;
        long j = -6;
        float f = -118.151f;
        int i8 = 325;
        int i9 = 9;
        while (i8 > 19) {
            j = i8;
            while (164 > j) {
                i3 += ((-iArrFld[(int) j][(int) (j - 1)]) - (this.byFld - 32130)) - (iMeth(iFld, 11) * i8);
                sFld = (short) (sFld + ((short) (j * j)));
                j++;
            }
            i4 = 1;
            while (i4 < 164) {
                int[][] iArr2 = iArrFld;
                int i10 = i8 + 1;
                iArr2[i8] = iArr2[i10];
                int i11 = i8 - 1;
                int[] iArr3 = iArr2[i11];
                iArr3[i8] = iArr3[i8] + ((int) j);
                int i12 = i3 + i4;
                int i13 = (((iFld1 >>> 1) % i2) * 5) + 35;
                if (i13 != 41) {
                    if (i13 != 42) {
                        if (i13 == 46) {
                            i = i4;
                            instanceCount += i4 * i4;
                            try {
                                iArrFld[i11][i - 1] = i8 % (-100);
                                iArrFld[i][i10] = 2123209591 / iFld;
                                i5 = iArrFld[i10][i8] / 695888026;
                            } catch (ArithmeticException e) {
                            }
                        } else if (i13 != 52) {
                            if (i13 == 55) {
                                lArrFld[i4 - 1] = instanceCount;
                            } else if (i13 != 63) {
                                if (i13 != 70) {
                                    if (i13 == 73) {
                                        i = i4;
                                    } else if (i13 == 78) {
                                        i = i4;
                                        i9 = i7;
                                        i3 = i12;
                                        i4 = i + 1;
                                        i2 = 9;
                                    }
                                }
                            }
                            i = i4;
                            i3 = i12;
                            i4 = i + 1;
                            i2 = 9;
                        } else {
                            i7 -= i5;
                            i = i4;
                        }
                        f = 2.0f;
                        while (f > 1.0f) {
                            int i14 = (int) f;
                            double d = dArr[i14];
                            double d2 = 11;
                            Double.isNaN(d2);
                            dArr[i14] = d - d2;
                            int i15 = ((i % 2) * 5) + 124;
                            if (i15 != 132) {
                                if (i15 != 134) {
                                    i12 = (int) instanceCount;
                                    long j2 = f;
                                    i5 = ((int) (j2 ^ j2)) - 12;
                                    f -= 1.0f;
                                } else {
                                    int[][] iArr4 = iArrFld;
                                    int i16 = i - 1;
                                    iArr4[(int) (f + 1.0f)][i16] = i8;
                                    iArr4[i16] = iArr4[i16];
                                }
                            }
                            fFld = (float) instanceCount;
                            i12 = (int) instanceCount;
                            long j22 = f;
                            i5 = ((int) (j22 ^ j22)) - 12;
                            f -= 1.0f;
                        }
                        i3 = i12;
                        i4 = i + 1;
                        i2 = 9;
                    } else {
                        i = i4;
                    }
                    instanceCount <<= i5;
                    i3 = i12;
                    i4 = i + 1;
                    i2 = 9;
                }
                i = i4;
                instanceCount *= j;
                i6 = 1;
                while (i6 < 2) {
                    long[] jArr = lArrFld;
                    jArr[i8] = jArr[i8] ^ 7;
                    instanceCount += (i6 * i6) - 50642;
                    iArrFld[i - 1][i6] = iArr[i6] - 36247;
                    i12 >>= i5;
                    i6++;
                }
                i3 = i12;
                i4 = i + 1;
                i2 = 9;
            }
            i8 -= 2;
            i2 = 9;
        }
        FuzzerUtils.out.println("i i1 l = " + i8 + "," + i3 + "," + j);
        FuzzerUtils.out.println("i2 i16 i17 = 11," + i4 + "," + i5);
        FuzzerUtils.out.println("i18 i19 f1 = " + i6 + "," + i7 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i20 b2 dArr = " + i9 + ",1," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount byFld Test.iFld = " + instanceCount + "," + ((int) this.byFld) + "," + iFld);
        FuzzerUtils.out.println("Test.iFld1 Test.sFld Test.fFld = " + iFld1 + "," + ((int) sFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.iArrFld Test.fArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
