
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/181/original-181/Test.dex */
public class Test {
    public static long instanceCount = 65317;
    public static double dFld = 1.31994d;
    public static boolean bFld = true;
    public static float fFld = 0.377f;
    public static int iFld = -33496;
    public static int iFld1 = 250;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static byte[][] byArrFld = (byte[][]) Array.newInstance(byte.class, N, N);
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public byte byFld = -122;
    public boolean bFld1 = true;

    static {
        FuzzerUtils.init(iArrFld, 194);
        FuzzerUtils.init(byArrFld, (byte) 6);
    }

    public static int iMeth() {
        long[] jArr = new long[N];
        boolean[] zArr = new boolean[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, 8407702357601404726L);
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(fArr, 1.184f);
        int i = iFld;
        fFld = i;
        iFld = i << (-128);
        int i2 = -84;
        int i3 = -122;
        int i4 = -61610;
        int i5 = 391;
        while (i5 > 11) {
            iFld = iFld;
            iFld = 1;
            i4 = 1;
            while (i4 < 4) {
                jArr = FuzzerUtils.long1array(N, -7L);
                zArr[i5] = bFld;
                i4++;
            }
            i5--;
            i2 = -8246;
            i3 = 4;
        }
        long checkSum = (((((i5 + i2) + i3) + i4) - 8246) - 52) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(zArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public static long lMeth(int i) {
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(iArr, -227);
        FuzzerUtils.init(bArr, (byte) -1);
        int i2 = i & i;
        int i3 = -5;
        int i4 = 5896;
        int i5 = -21814;
        float f = -10.491f;
        byte b = 69;
        int i6 = 4;
        while (356 > i6) {
            i3 += i6 * i6;
            f = 5.0f;
            while (f > 1.0f) {
                int i7 = (int) f;
                instanceCount = (Math.min(i6, i6) / (iArr[i6 + 1] | 1)) * bArr[i7];
                if (bFld) {
                    i2 -= i4;
                    i5 = i7;
                    while (i5 < 2) {
                        if (bFld == (i3 == iMeth())) {
                            long j = instanceCount;
                            long j2 = 1 + j;
                            instanceCount = j2;
                            double d = j;
                            double d2 = j2;
                            double d3 = dFld;
                            Double.isNaN(d2);
                            Double.isNaN(d);
                            i4 |= (int) (-(d - (d2 * d3)));
                        } else {
                            iArr[(int) (f - 1.0f)] = iFld;
                        }
                        long j3 = instanceCount;
                        b = (byte) (b + ((byte) j3));
                        instanceCount = j3 * iFld;
                        i4 += i5 * i5;
                        i5++;
                    }
                }
                f -= 1.0f;
            }
            i6++;
        }
        long floatToIntBits = i2 + i6 + i3 + Float.floatToIntBits(f) + i4 + i5 + 213 + b + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(bArr);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth(byte b, byte b2) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, -11101);
        lMeth(iFld);
        iFld = (int) instanceCount;
        dFld *= -30.0d;
        int i = 40641;
        int i2 = 97;
        double d = -16.17851d;
        int i3 = 1;
        while (i3 < 173) {
            i2 = 1;
            while (true) {
                i2++;
                if (i2 < 9) {
                    int i4 = iFld >> (-3);
                    iFld = i4;
                    int[] iArr2 = iArrFld;
                    int i5 = (int) 0.0d;
                    iArr2[i5] = iArr2[i5] >> i4;
                    iFld = i;
                    d = 2.0d;
                    iArr[i3 + 1] = FuzzerUtils.int1array(N, 4);
                    instanceCount *= (long) dFld;
                    fFld *= i;
                    i += ((iFld * i2) + b) - i2;
                }
            }
            byArrFld = byArrFld;
            i3++;
        }
        vMeth_check_sum += b + b2 + i3 + i + i2 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        boolean[][] zArr = (boolean[][]) Array.newInstance(boolean.class, N, N);
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(jArr, -60058L);
        byte b = this.byFld;
        vMeth(b, b);
        fFld -= iFld;
        int i = 61;
        int i2 = 61;
        int i3 = 6;
        int i4 = 0;
        int i5 = 3;
        while (i5 < 275) {
            boolean z = bFld;
            if (z) {
                zArr[i5][i5 - 1] = z;
                long[] jArr2 = jArr[i5];
                jArr2[i5] = jArr2[i5] + fFld;
            } else if (z) {
                int i6 = iFld1;
                int i7 = i & i6;
                jArr[i5][i5] = i6;
                int i8 = 92;
                do {
                    iFld = i8;
                    iFld1 += (int) fFld;
                    byte[] bArr = byArrFld[i5];
                    int i9 = i5 + 1;
                    bArr[i9] = (byte) (bArr[i9] << ((byte) i5));
                    int[] iArr = iArrFld;
                    iArr[i8] = iArr[i8] << ((int) instanceCount);
                    int i10 = i8 - 1;
                    iArr[i10] = iArr[i10] * 7;
                    i8--;
                } while (i8 > 0);
                i2 = i8;
                i = i7;
            } else if (z) {
                bFld = z;
            }
            iFld += (int) dFld;
            if (bFld) {
                break;
            }
            long j = instanceCount;
            i -= (int) j;
            instanceCount = j - 191;
            i3 = 5;
            while (i3 < 92) {
                i3++;
            }
            i5++;
            i4 = i;
        }
        FuzzerUtils.out.println("i14 i15 i16 = " + i5 + "," + i + "," + i2);
        FuzzerUtils.out.println("i17 i18 i19 = " + i3 + ",18687,12");
        FuzzerUtils.out.println("i20 i21 i22 = -14,-228," + i4);
        FuzzerUtils.out.println("bArr1 lArr1 = " + FuzzerUtils.checkSum(zArr) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld Test.iFld byFld = " + Float.floatToIntBits(fFld) + "," + iFld + "," + ((int) this.byFld));
        FuzzerUtils.out.println("Test.iFld1 bFld1 Test.iArrFld = " + iFld1 + "," + (this.bFld1 ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.byArrFld = " + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
