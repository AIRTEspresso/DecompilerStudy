/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/188/original-188/Test.dex */
public class Test {
    public static int[] iArrFld;
    public static long instanceCount = 3260064452L;
    public static volatile boolean bFld = true;
    public static float fFld = 0.42f;
    public static byte byFld = -85;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public volatile int iFld = -42144;
    public double dFld = -1.40777d;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -129);
        FuzzerUtils.init(lArrFld, 1461668461105384269L);
    }

    public static void vMeth1() {
        int i;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, 0.2025d);
        int i2 = 199;
        int i3 = 22154;
        float f = 33.128f;
        int i4 = 4850;
        int i5 = 1;
        while (true) {
            i5++;
            if (i5 < 127) {
                i2 = 1;
                while (i2 < 12) {
                    int i6 = i5 + 1;
                    double d = dArr[i6];
                    double d2 = i5;
                    Double.isNaN(d2);
                    dArr[i6] = d * d2;
                    if (((int) 7590) != 0) {
                        vMeth1_check_sum += (((((i + Float.floatToIntBits(f)) + 0) + i5) + i2) - 4) + 7590 + i3 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                        return;
                    }
                    f++;
                    i3 = 2;
                    i4 = -52591;
                    i2++;
                }
            } else {
                vMeth1_check_sum += (((((i4 + Float.floatToIntBits(f)) + 0) + i5) + i2) - 4) + 7590 + i3 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                return;
            }
        }
    }

    public static void vMeth(int i) {
        vMeth1();
        vMeth_check_sum += (((((((i << (-10421)) + 4) - 42547) + Double.doubleToLongBits(1.0d)) - 10421) - 63) - 168) + Float.floatToIntBits(-32.553f);
    }

    public static int iMeth() {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -1.23681d);
        vMeth(-30984);
        int i = 1;
        while (true) {
            i++;
            if (i >= 294) {
                break;
            }
            instanceCount = instanceCount;
        }
        int i2 = -29776;
        bFld = bFld;
        int i3 = 10;
        while (175 > i3) {
            i2 >>>= -9;
            int[] iArr = iArrFld;
            int i4 = i3 + 1;
            iArr[i4] = i3;
            fFld *= i2;
            iArr[i4] = iArr[i4] - i2;
            i3 += 3;
        }
        fFld -= 0.177f;
        dArr[(i3 >>> 1) % N] = i2;
        long doubleToLongBits = (((i2 + 60544) + i) - 22207) + i3 + 32361 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i = 0;
        int i2 = (this.iFld > this.iFld ? 1 : 0) & 1;
        if (iMeth() != 78.393f) {
            i = 1;
        }
        int i3 = i2 | i;
        this.dFld = 3.0d;
        this.iFld = (int) 78.393f;
        short s = (short) (-11000);
        this.iFld -= this.iFld;
        instanceCount = this.iFld;
        int i4 = 1;
        do {
            instanceCount += this.iFld;
            i4 += 2;
        } while (i4 < 255);
        this.iFld = -84;
        iArrFld[(i4 >>> 1) % N] = i4;
        short s2 = (short) (s << ((short) this.iFld));
        this.iFld *= i4;
        int i5 = 380;
        int i6 = 15;
        int i7 = -14;
        int i8 = -5;
        while (true) {
            i5 -= 3;
            if (i5 > 0) {
                i6 = 1;
                while (true) {
                    i6++;
                    if (i6 >= 197) {
                        break;
                    }
                    instanceCount += i6 - i6;
                    this.iFld += i6 * i6;
                    fFld += byFld;
                }
                int i9 = (i5 % 2) + 9;
                if (i9 == 9) {
                    lArrFld[i5 + 1] = 78.393f;
                    i7 = i5;
                    while (i7 < 197) {
                        i7++;
                        i8 = 1;
                    }
                } else if (i9 == 10) {
                    iArrFld[i5 - 1] = i5;
                }
            } else {
                FuzzerUtils.out.println("b f2 s1 = " + i3 + "," + Float.floatToIntBits(78.393f) + "," + ((int) s2));
                FuzzerUtils.out.println("i16 i17 i18 = " + i4 + "," + i5 + "," + i6);
                FuzzerUtils.out.println("i19 i20 i21 = " + i7 + ",-80," + i8);
                FuzzerUtils.out.println("i22 = 12");
                FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
                FuzzerUtils.out.println("Test.fFld dFld Test.byFld = " + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld) + "," + ((int) byFld));
                FuzzerUtils.out.println("Test.iArrFld Test.lArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
