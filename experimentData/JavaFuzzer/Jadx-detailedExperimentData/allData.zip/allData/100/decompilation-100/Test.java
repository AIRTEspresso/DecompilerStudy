
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/100/original-100/Test.dex */
public class Test {
    public static int[] iArrFld;
    public boolean bFld = true;
    public byte[] byArrFld = new byte[N];
    public static long instanceCount = -164;
    public static int iFld = -191;
    public static short sFld = 9040;
    public static float fFld = 6.937f;
    public static final int N = 400;
    public static short[] sArrFld = new short[N];
    public static long[] lArrFld = new long[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 41383);
        FuzzerUtils.init(sArrFld, (short) 16014);
        FuzzerUtils.init(lArrFld, -2009317289L);
    }

    public static void vMeth2(int i, int i2) {
        long j;
        int i3;
        int i4;
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -26343);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-43));
        sArr[45] = (short) (sArr[45] >> 5587);
        int i5 = -12;
        int i6 = -100;
        int i7 = 61712;
        int i8 = 2;
        float f = -1.207f;
        int i9 = 5;
        while (i9 < 232) {
            instanceCount += i9 | i9;
            int i10 = 1;
            do {
                j = instanceCount;
                i3 = (int) j;
                f -= -15259;
                i10++;
            } while (i10 < 7);
            iFld = iFld;
            iFld = i10;
            i5 = (int) j;
            int i11 = i9;
            while (i11 < 7) {
                int i12 = i9 + 1;
                int[] iArr2 = iArr[i9][i12];
                int i13 = iFld;
                iArr2[i12] = i13;
                i8 = -9;
                try {
                    iArr[i9 - 1][(i13 >>> 1) % N][i9] = (-28) / i13;
                    i5 = i13 / 120;
                    i4 = i13 % i5;
                } catch (ArithmeticException e) {
                    i4 = i5;
                }
                i5 = i4 + 167;
                i11++;
                i3 = i2;
            }
            i9++;
            int i14 = i11;
            i6 = i10;
            i = i3;
            i7 = i14;
        }
        vMeth2_check_sum += ((((((i + i2) + i9) + i5) + i6) + Float.floatToIntBits(f)) - 15259) + i7 + i8 + FuzzerUtils.checkSum(sArr) + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public static void vMeth1(int i) {
        int i2;
        long[] jArr = new long[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(jArr, -6530L);
        int i3 = 1;
        FuzzerUtils.init(zArr, true);
        int i4 = i;
        vMeth2(i4, iFld);
        int i5 = 14;
        int i6 = -144;
        int i7 = 55921;
        int i8 = 10;
        float f = 93.277f;
        double d = 122.97533d;
        int i9 = 1;
        while (true) {
            i9 += i3;
            if (i9 < 332) {
                i5 = 1;
                while (5 > i5) {
                    int[] iArr = iArrFld;
                    int i10 = i9 - 1;
                    iArr[i10] = iArr[i10] + i4;
                    i6 = sFld;
                    switch ((i5 % 5) + 124) {
                        case 124:
                            i2 = i5;
                            i7 = 2;
                            while (i7 > 1) {
                                int i11 = iFld;
                                i4 += i7 * i11;
                                int i12 = i2;
                                i6 = (int) (i6 + (((i7 * f) + i12) - i8));
                                switch ((i12 % 9) + 54) {
                                    case 54:
                                        i2 = i12;
                                        i4 += (i7 * i7) - 10;
                                        f += i9;
                                        sFld = (short) (sFld - ((short) i7));
                                        double d2 = i6;
                                        Double.isNaN(d2);
                                        d += d2;
                                        break;
                                    case 55:
                                        i2 = i12;
                                        double d22 = i6;
                                        Double.isNaN(d22);
                                        d += d22;
                                        break;
                                    case 56:
                                    default:
                                        i2 = i12;
                                        break;
                                    case 57:
                                        i2 = i12;
                                        i8 += ((i7 * i4) + sFld) - i9;
                                        break;
                                    case 58:
                                        i2 = i12;
                                        i8 = i9;
                                        break;
                                    case 59:
                                        i2 = i12;
                                        iFld = i4;
                                        break;
                                    case 60:
                                        int i13 = i7 + 1;
                                        i2 = i12;
                                        jArr[i13] = i11 & jArr[i13];
                                        break;
                                    case 61:
                                        zArr[i12 - 1] = true;
                                        i2 = i12;
                                        break;
                                    case 62:
                                        instanceCount += i7 | i4;
                                        i2 = i12;
                                        break;
                                }
                                i7 -= 3;
                            }
                            break;
                        case 125:
                        case 126:
                            long j = instanceCount;
                            i2 = i5;
                            instanceCount = j + (((i5 * i9) + j) - i4);
                            break;
                        case 127:
                            iFld = 30724;
                        case 128:
                            jArr[i9] = jArr[i9] + instanceCount;
                            i2 = i5;
                            break;
                        default:
                            i2 = i5;
                            break;
                    }
                    i5 = i2 + 1;
                }
                i3 = 1;
            } else {
                vMeth1_check_sum += i4 + i9 + i5 + i6 + i7 + i8 + Float.floatToIntBits(f) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(zArr);
                return;
            }
        }
    }

    public static void vMeth(int i, int i2) {
        int i3 = -21348;
        int i4 = 18502;
        int i5 = -12;
        int i6 = -37552;
        int i7 = 6;
        while (i7 < 344) {
            vMeth1(i);
            int i8 = i6;
            int i9 = i5;
            int i10 = i4;
            int i11 = i7;
            while (i11 < 5) {
                i10 = 105465785;
                i11++;
                i9 = 1;
                i8 = 1;
            }
            i7++;
            i3 = i11;
            i4 = i10;
            i5 = i9;
            i6 = i8;
        }
        vMeth_check_sum += (((((((((i + i2) + i7) + 4341) + i3) + i4) + i5) - 5) + Double.doubleToLongBits(10.11893d)) + i6) - 9;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 25274);
        int i3 = iFld;
        vMeth(i3, i3);
        int i4 = -56;
        int i5 = -143;
        int i6 = -15659;
        int i7 = -214;
        int i8 = -59920;
        int i9 = 14;
        int i10 = 40380;
        long j = 12;
        double d = 0.22206d;
        int i11 = 9;
        while (i11 < 163) {
            i5 = i11;
            while (i5 < 163) {
                int[] iArr2 = iArrFld;
                int i12 = i11 + 1;
                iArr2[i12] = iArr2[i12] * i4;
                j = 2;
                i5++;
            }
            int i13 = 2;
            double d2 = d;
            int i14 = i10;
            int i15 = i9;
            int i16 = i8;
            int i17 = 9;
            while (i17 < 163) {
                float f = fFld;
                int i18 = (int) f;
                d2 = 37426.0d;
                int i19 = (int) j;
                iArr[i17] = iArr[i17] + i19;
                iFld = (int) f;
                i6 -= i5;
                i16 += (int) instanceCount;
                int i20 = i17;
                while (i20 < i13) {
                    int i21 = i6 - 144;
                    iArrFld = iArrFld;
                    i6 = i21 - i21;
                    instanceCount += i6;
                    i20++;
                    i17 = i17;
                    i13 = 2;
                }
                int i22 = i17;
                int[] iArr3 = iArrFld;
                iArr3[i22] = iArr3[i22] * iFld;
                int i23 = i11 - 1;
                iArr3[i23] = iArr3[i23] << i19;
                instanceCount <<= -144;
                int i24 = i18 + 1;
                if (this.bFld) {
                    i2 = i24;
                    i = i5;
                } else {
                    instanceCount = i24;
                    long[] jArr = lArrFld;
                    i2 = i24;
                    i = i5;
                    jArr[i22] = jArr[i22] - i11;
                }
                iFld >>>= i20;
                i15 = i20;
                i5 = i;
                i13 = 2;
                i14 = 2;
                int i25 = i2;
                i17 = i22 + 1;
                i4 = i25;
            }
            int i26 = i17;
            this.byArrFld = this.byArrFld;
            i11++;
            i8 = i16;
            i9 = i15;
            i10 = i14;
            d = d2;
            i7 = i26;
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + i11 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i26 l i27 = " + i6 + "," + j + "," + i7);
        FuzzerUtils.out.println("i28 d2 i29 = " + i8 + "," + Double.doubleToLongBits(d) + "," + i9);
        FuzzerUtils.out.println("i30 i31 iArr1 = -144," + i10 + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.fFld bFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + (this.bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.sArrFld Test.lArrFld byArrFld = " + FuzzerUtils.checkSum(sArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
