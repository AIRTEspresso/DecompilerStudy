
import java.io.PrintStream;
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/183/original-183/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public static long instanceCount = -694741276;
    public static long lFld = 0;
    public static double dFld = -2.653d;
    public static float fFld = -95.279f;
    public static long bMeth_check_sum = 0;
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public short sFld = -16283;
    public int[][] iArrFld = (int[][]) Array.newInstance(int.class, N, N);
    public float[] fArrFld = new float[N];

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 45L);
    }

    public static void vMeth(int i, int i2, int i3) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -18228);
        int i4 = i - i2;
        int i5 = 47618;
        int i6 = 7;
        int i7 = 9;
        while (i6 < 140) {
            int i8 = 1;
            while (true) {
                i8++;
                if (i8 < 12) {
                    i3 += 14;
                    i5 = 1;
                }
            }
            i6++;
            i7 = i8;
        }
        int i9 = 16;
        while (i9 < 385) {
            instanceCount = lFld;
            iArr[i9] = iArr[i9] + i5;
            i9++;
        }
        vMeth_check_sum += (((((((((i4 + i2) + i3) + i6) + 7) + i7) + i5) - 214) + i9) - 14341) + 9 + FuzzerUtils.checkSum(iArr);
    }

    public static float fMeth() {
        int[] iArr = new int[N];
        short[][][] sArr = (short[][][]) Array.newInstance(short.class, N, N, N);
        FuzzerUtils.init(iArr, -18037);
        FuzzerUtils.init((Object[][]) sArr, (Object) (short) -17943);
        long j = lFld;
        lFld = j + 1;
        float f = (float) j;
        double reverseBytes = Short.reverseBytes((short) 9910) - 9;
        dFld = reverseBytes;
        int i = ((int) reverseBytes) * 8;
        vMeth(i, i, -2923);
        long[] jArr = lArrFld;
        int i2 = (i >>> 1) % N;
        jArr[i2] = jArr[i2] << ((int) instanceCount);
        lFld = i;
        int i3 = -5;
        int i4 = -110;
        int i5 = 4;
        double d = 0.94521d;
        int i6 = 14;
        while (313 > i6) {
            i3 /= (int) (fFld | 1);
            d = i6;
            while (d < 6.0d) {
                iArr[i6 + 1] = i4;
                i4 += i4;
                iArr[1] = iArr[1] - i4;
                i5 = 2;
                short[] sArr2 = sArr[2][0];
                d += 1.0d;
                int i7 = (int) d;
                sArr2[i7] = (short) (sArr2[i7] * ((short) fFld));
                f = -7.0f;
            }
            i6++;
        }
        long floatToIntBits = Float.floatToIntBits(f) + i + i6 + i3 + 0 + Double.doubleToLongBits(d) + i4 + i5 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum((Object[][]) sArr);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public static boolean bMeth(float f) {
        long j;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -32364);
        long[] jArr = lArrFld;
        jArr[30] = jArr[30] << ((int) (-(instanceCount + lFld)));
        int i = 3;
        while (i < 146) {
            iArr[i] = (int) instanceCount;
            if ((i % 1) + 119 == 119) {
                instanceCount = ((lFld << 11418) << ((int) (11418 + 0.82f))) - (-11478);
            }
            i++;
        }
        instanceCount = instanceCount - 1;
        iArr[108] = i;
        fFld *= -248.0f;
        long floatToIntBits = Float.floatToIntBits(f) + 1 + ((int) (((float) j) + ((-fMeth()) - 52843.0f))) + i + 11417 + FuzzerUtils.checkSum(iArr);
        bMeth_check_sum += floatToIntBits;
        return floatToIntBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = 22319;
        int i3 = -34790;
        int i4 = -4;
        int i5 = -7;
        int i6 = -222;
        boolean z = false;
        float f = -41.53f;
        int i7 = 5;
        while (298 > i7 && !(z = bMeth(fFld))) {
            long j = lFld;
            lFld = j + (((i7 * (-60)) + i7) - j);
            if (z) {
                break;
            }
            fFld *= i2;
            this.sFld = (short) i2;
            i3 = 5;
            while (i3 < 86) {
                i4 += i3 ^ i3;
                i5 = 2;
                while (i5 > 1) {
                    long j2 = instanceCount;
                    instanceCount = j2 - j2;
                    try {
                        i2 = 26462 % i4;
                        this.iArrFld[i5 + 1][i5] = 15502 % i4;
                        i = (-178) % this.iArrFld[i3][i7 - 1];
                    } catch (ArithmeticException e) {
                        i = i2;
                    }
                    lFld += 50;
                    this.iArrFld[(i6 >>> 1) % N] = FuzzerUtils.int1array(N, 12);
                    int[] iArr = this.iArrFld[i7 + 1];
                    iArr[i3] = iArr[i3] | i5;
                    if (z) {
                        i += i5 ^ i3;
                    }
                    int i8 = ((i3 % 3) * 5) + 73;
                    if (i8 == 74) {
                        i2 = this.sFld;
                        float[] fArr = this.fArrFld;
                        fArr[i5] = fArr[i5] + i7;
                        lFld += i2;
                        i6 = -60;
                    } else if (i8 == 75) {
                        f -= 60;
                        i6 = (-60) + i5;
                        i2 = i;
                    } else {
                        if (i8 == 78) {
                            instanceCount += ((i5 * i3) + i3) - (-60);
                        }
                        i2 = i;
                        i6 = -60;
                    }
                    f *= -60;
                    i5--;
                    i4 = -60;
                }
                i2 = (i2 + 107) - i3;
                dFld = lFld;
                i3++;
            }
            i7++;
        }
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder append = new StringBuilder().append("i i1 b = ").append(i7).append(",").append(i2).append(",");
        int i9 = z ? 1 : 0;
        int i10 = z ? 1 : 0;
        printStream.println(append.append(i9).toString());
        FuzzerUtils.out.println("by i21 i22 = -60," + i3 + "," + i4);
        FuzzerUtils.out.println("i23 i24 f2 = " + i5 + "," + i6 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("Test.instanceCount Test.lFld Test.dFld = " + instanceCount + "," + lFld + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.fFld sFld Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + ((int) this.sFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iArrFld fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
