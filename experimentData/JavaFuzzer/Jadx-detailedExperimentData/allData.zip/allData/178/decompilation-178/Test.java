
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/178/original-178/Test.dex */
public class Test {
    public volatile short sFld = -18905;
    public static long instanceCount = -8876196576951346957L;
    public static int iFld = 2;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static double[][] dArrFld = (double[][]) Array.newInstance(double.class, N, N);
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, 4);
        FuzzerUtils.init(dArrFld, -92.19358d);
    }

    public static long lMeth(int i) {
        int i2;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -32478);
        FuzzerUtils.init(jArr, 12L);
        int i3 = i << i;
        iArr[43] = iArr[43] | 30755;
        int i4 = 20340;
        int i5 = -4;
        int i6 = -41;
        byte b = -43396;
        float f = 1.639f;
        byte b2 = 32;
        double d = -64.88658d;
        int i7 = 3;
        while (i7 < 376) {
            int i8 = 1;
            double d2 = d;
            byte b3 = b2;
            float f2 = f;
            byte b4 = b;
            int i9 = i6;
            int i10 = 1;
            while (i10 < 5) {
                f2 = i3;
                switch (((i7 >>> 1) % 7) + 29) {
                    case 29:
                        int i11 = i10 * i10;
                        int i12 = iFld + ((i11 + i4) - i7);
                        iFld = i12;
                        b3 = (byte) (b3 + 8);
                        switch (((i12 >>> i8) % 6) + 111) {
                            case 111:
                                b4 = 1;
                                while (b4 < 2) {
                                    i4 += b4 - i10;
                                    int i13 = b4 + 1;
                                    iArr[i13] = iArr[i13] + i3;
                                    f2 += ((b4 * b3) + f2) - ((float) instanceCount);
                                    b4 = i13;
                                    i10 = i10;
                                }
                                i2 = i10;
                                i3 = (int) instanceCount;
                                i4 += i11;
                                break;
                            case 112:
                                b3 = (byte) (b3 * b3);
                            case 113:
                                double d3 = i10;
                                Double.isNaN(d3);
                                d2 += d3;
                                i2 = i10;
                                break;
                            case 114:
                                i3 -= (int) instanceCount;
                                i2 = i10;
                                break;
                            case 115:
                                i2 = i10;
                                break;
                            case 116:
                                f2 = b4;
                                i2 = i10;
                                break;
                            default:
                                i2 = i10;
                                break;
                        }
                    case 30:
                    default:
                        i2 = i10;
                        break;
                    case 31:
                        instanceCount = b3;
                        i2 = i10;
                        break;
                    case 32:
                        jArr[i7] = jArr[i7] + 491920893359087281L;
                        i2 = i10;
                        break;
                    case 33:
                        instanceCount >>= i9;
                    case 34:
                        i9 = (int) instanceCount;
                        i2 = i10;
                        break;
                    case 35:
                        f2 -= f2;
                        i2 = i10;
                        break;
                }
                i10 = i2 + 1;
                i8 = 1;
            }
            int i14 = i10;
            i7++;
            i6 = i9;
            b = b4;
            f = f2;
            b2 = b3;
            d = d2;
            i5 = i14;
        }
        long floatToIntBits = i3 + 30755 + i7 + i4 + i5 + i6 + Float.floatToIntBits(f) + b2 + b + 40167 + Double.doubleToLongBits(d) + 0 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth(long j, int i) {
        long lMeth = j >> ((int) ((i - lMeth(iFld)) << ((int) instanceCount)));
        iFld = -5931;
        instanceCount = lMeth;
        int[] iArr = iArrFld;
        int i2 = ((-5931) >>> 1) % N;
        iArr[i2] = iArr[i2] % ((-5931) | 1);
        iArrFld = iArr;
        int i3 = -28099;
        int i4 = 1;
        do {
            i4++;
            if (i4 < 287) {
                instanceCount = lMeth;
                i3 = iFld;
            } else {
                iArrFld = iArrFld;
                iFld += i4;
                int i5 = 1;
                while (true) {
                    i5++;
                    if (i5 < 239) {
                        i3 *= i5;
                    } else {
                        vMeth_check_sum += lMeth + i3 + i4 + i5;
                        return;
                    }
                }
            }
        } while (i3 == 0);
        vMeth_check_sum += lMeth + i3 + i4 + 24241;
    }

    public static float fMeth(int i, float f) {
        vMeth(594L, i);
        int i2 = -9;
        int i3 = 9748;
        int i4 = 15;
        while (316 > i4) {
            instanceCount += i4;
            int i5 = 5;
            int i6 = 5;
            while (true) {
                i6--;
                if (i6 > 0) {
                    iArrFld = iArrFld;
                    long j = instanceCount & (-7885);
                    instanceCount = j;
                    double[] dArr = dArrFld[i4];
                    int i7 = i6 + 1;
                    double d = dArr[i7];
                    double d2 = j;
                    Double.isNaN(d2);
                    dArr[i7] = d * d2;
                    f += (i6 * i6) - 63590;
                    i = (int) (i + (i6 ^ f));
                }
            }
            while (i5 > 1) {
                iFld <<= -13;
                i5--;
            }
            i4++;
            i3 = i5;
            i2 = i6;
        }
        long floatToIntBits = (((i + Float.floatToIntBits(f)) + i4) - 13) + i2 + i3 + 11 + 1;
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        boolean[] zArr = new boolean[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(zArr, false);
        FuzzerUtils.init(sArr, (short) -12352);
        int i3 = 179;
        int i4 = 62480;
        int i5 = -54;
        int i6 = -37874;
        float f = 53.326f;
        int i7 = 3;
        while (true) {
            int i8 = -215;
            int i9 = 1;
            int i10 = i3;
            if (i7 < 224) {
                int i11 = 114;
                while (true) {
                    if ((i7 % 1) + 19 == 19) {
                        f += fMeth(2, 0.999f) + i7;
                    }
                    i = i6;
                    i2 = i11;
                    while (i2 < i9) {
                        int i12 = ((i11 % 5) * 5) + 57;
                        if (i12 != 59) {
                            if (i12 == 61) {
                                i += (i2 * i2) - 66;
                            } else if (i12 == 68) {
                                iFld = i8;
                                int[] iArr = iArrFld;
                                iArr[i11] = -88;
                                int i13 = i11 + 1;
                                iArr[i13] = iArr[i13] * 2;
                                int i14 = ((int) (-2.26581d)) * i8;
                                iFld = i14;
                                instanceCount += (long) (-2.26581d);
                                iFld = i14 + (((this.sFld * i2) + 2) - i7);
                            } else if (i12 == 63) {
                                instanceCount += i2;
                            } else if (i12 != 64) {
                            }
                            i2++;
                            i8 = -215;
                            i9 = 1;
                        }
                        int i15 = i2 - 1;
                        sArr[i15] = (short) (sArr[i15] | ((short) 147));
                        i2++;
                        i8 = -215;
                        i9 = 1;
                    }
                    i11--;
                    if (i11 <= 0) {
                        break;
                    }
                    i6 = i;
                    i8 = -215;
                    i9 = 1;
                }
                i7++;
                i3 = i11;
                i5 = i2;
                i6 = i;
                i4 = 2;
            } else {
                FuzzerUtils.out.println("i i1 i2 = " + i7 + ",147," + i10);
                FuzzerUtils.out.println("i3 b f = " + i4 + ",0," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("i20 i21 d1 = " + i5 + ",-215," + Double.doubleToLongBits(-2.26581d));
                FuzzerUtils.out.println("i22 by1 b3 = " + i6 + ",-60,1");
                FuzzerUtils.out.println("bArr sArr = " + FuzzerUtils.checkSum(zArr) + "," + FuzzerUtils.checkSum(sArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + ((int) this.sFld));
                FuzzerUtils.out.println("Test.iArrFld Test.dArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
