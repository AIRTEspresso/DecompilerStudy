/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/16/original-16/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public int[] iArrFld = new int[N];
    public static long instanceCount = 743154865;
    public static int iFld = 48177;
    public static byte byFld = -86;
    public static short sFld = -21802;
    public static boolean bFld = true;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 2.25f);
    }

    public static void vMeth1(long j, long j2, int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -105);
        int i2 = (i >>> 1) % N;
        iArr[i2] = iArr[i2] >>> 32737;
        vMeth1_check_sum += j + j2 + i + FuzzerUtils.checkSum(iArr);
    }

    public static long lMeth(long j) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -162);
        vMeth1(j, instanceCount, iFld);
        int i = -9;
        int i2 = -217;
        int i3 = -14;
        int i4 = 11;
        float f = 7.0f;
        while (true) {
            int i5 = 1;
            if (f < 122.0f) {
                i2 = 1;
                while (i2 < 14) {
                    iArr[i2] = 0;
                    iFld += ((byFld * i2) + i2) - sFld;
                    i2++;
                }
                i += 36124;
                while (i5 < 14) {
                    i5++;
                }
                float f2 = i;
                i3 += (int) (((i3 * f) + f2) - f2);
                f += 1.0f;
                i4 = i5;
            } else {
                long floatToIntBits = ((((((j + Float.floatToIntBits(f)) + (i >>> (-229))) + i2) + i3) + i4) - 229) + 1 + Float.floatToIntBits(2.176f) + FuzzerUtils.checkSum(iArr);
                lMeth_check_sum += floatToIntBits;
                return floatToIntBits;
            }
        }
    }

    public void vMeth(int i) {
        int i2;
        int i3 = i;
        long j = 6;
        int i4 = -130;
        int i5 = 7;
        int i6 = 40732;
        int i7 = 19417;
        int i8 = 34;
        double d = 2.8014d;
        float f = -28.436f;
        while (true) {
            if (j >= 150) {
                i2 = i6;
                break;
            }
            int i9 = 1;
            int i10 = 1;
            while (true) {
                i10 += i9;
                if (i10 >= 11) {
                    break;
                }
                i4 |= (int) (instanceCount * (lMeth(j) - iFld));
                i6 = i6;
                i9 = 1;
            }
            i2 = i6;
            if (bFld) {
                i5 = i10;
                break;
            }
            i3 = (i3 - i10) + ((int) (j * j));
            f = (float) (-103.87417d);
            double d2 = 1.0d;
            int i11 = i8;
            int i12 = i7;
            int i13 = i2;
            while (11.0d > d2) {
                int i14 = (int) ((d2 % 4.0d) + 2.0d);
                int i15 = 2;
                if (i14 == 2) {
                    instanceCount >>= iFld;
                    int i16 = i3;
                    int i17 = 1;
                    while (i17 < i15) {
                        sFld = (short) i13;
                        int[] iArr = this.iArrFld;
                        int i18 = (int) d2;
                        iArr[i18] = iArr[i18] + i18;
                        iArr[i18] = (int) j;
                        i15 = 2;
                        i16 = i17;
                        i17++;
                    }
                    int i19 = i16;
                    i12 = i17;
                    i3 = i19;
                } else if (i14 != 3) {
                    if (i14 != 4) {
                        if (i14 == 5) {
                            i11 >>= i11;
                        } else {
                            double d3 = i13;
                            Double.isNaN(d3);
                            i13 = (int) (d3 + (d2 * d2) + 35.0d);
                        }
                        d2 += 1.0d;
                    } else {
                        iFld <<= i12;
                        d2 += 1.0d;
                    }
                }
                i11 += (int) f;
                iFld <<= i12;
                d2 += 1.0d;
            }
            j++;
            i6 = i13;
            i7 = i12;
            i8 = i11;
            i5 = i10;
            d = d2;
        }
        vMeth_check_sum += i3 + j + i4 + i5 + Float.floatToIntBits(f) + Double.doubleToLongBits(-103.87417d) + Double.doubleToLongBits(d) + i2 + i7 + i8;
    }

    public void mainTest(String[] strArr) {
        double d;
        double d2;
        int i;
        int i2;
        boolean[] zArr = new boolean[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(zArr, true);
        FuzzerUtils.init(jArr, 18827L);
        int i3 = 142;
        vMeth(142);
        int i4 = -228;
        int i5 = 33520;
        int i6 = 13;
        while (true) {
            d = -123.3001d;
            if (i6 >= 358) {
                break;
            }
            int i7 = (int) (-123.3001d);
            int i8 = iFld + i7;
            iFld = i8;
            long j = instanceCount;
            iFld = i8 + ((int) j);
            instanceCount = j - i5;
            i4 *= -29991;
            i3 += i6;
            i6++;
            i5 = i7;
        }
        int i9 = i4 + 152;
        int i10 = 168;
        int i11 = -8;
        int i12 = 59824;
        int i13 = 210;
        float f = -1.274f;
        while (i10 > 8) {
            int i14 = 129;
            while (true) {
                d2 = instanceCount;
                i5 <<= i5;
                i14--;
                if (i14 <= 0) {
                    break;
                }
            }
            i12 = 17;
            while (true) {
                if (344 <= i12) {
                    i = i3;
                    i2 = i14;
                    break;
                }
                i13 = i10;
                while (i13 < 2) {
                    this.iArrFld[i12] = i9;
                    float[] fArr = fArrFld;
                    i13++;
                    float f2 = fArr[i13];
                    int i15 = i3;
                    long j2 = instanceCount;
                    int i16 = i14;
                    fArr[i13] = f2 * ((float) j2);
                    long j3 = j2 >> (-34714);
                    instanceCount = j3;
                    if (!bFld) {
                        i9 *= (int) (-88.276f);
                        byFld = (byte) (byFld - ((byte) j3));
                    }
                    i3 = i15;
                    i14 = i16;
                }
                i = i3;
                i2 = i14;
                int[] iArr = this.iArrFld;
                int i17 = i12 + 1;
                iArr[i17] = iArr[i17] * ((int) d2);
                f *= i6;
                zArr[i12] = true;
                boolean z = bFld;
                bFld = z;
                jArr[i12] = jArr[i12] - (-1);
                i5 += i12;
                if (z) {
                    break;
                }
                i12 = i17;
                i3 = i;
                i14 = i2;
            }
            i10 -= 3;
            d = d2;
            i3 = i;
            i11 = i2;
        }
        FuzzerUtils.out.println("i i13 i14 = " + i3 + "," + i6 + "," + i9);
        FuzzerUtils.out.println("d2 i15 i16 = " + Double.doubleToLongBits(d) + "," + i5 + "," + i10);
        FuzzerUtils.out.println("i17 i18 i19 = 40904," + i11 + "," + i12);
        FuzzerUtils.out.println("i20 i21 i22 = -34714," + i13 + ",185");
        FuzzerUtils.out.println("f4 bArr lArr = " + Float.floatToIntBits(f) + "," + FuzzerUtils.checkSum(zArr) + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.byFld = " + instanceCount + "," + iFld + "," + ((int) byFld));
        FuzzerUtils.out.println("Test.sFld Test.bFld iArrFld = " + ((int) sFld) + "," + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
