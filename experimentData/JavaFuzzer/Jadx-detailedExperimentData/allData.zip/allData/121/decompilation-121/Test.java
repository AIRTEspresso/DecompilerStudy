
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/121/original-121/Test.dex */
public class Test {
    public static short[] sArrFld;
    public static long instanceCount = 31948;
    public static volatile boolean bFld = true;
    public static int iFld = 59888;
    public static short sFld = 3058;
    public static double dFld = -90.111661d;
    public static final int N = 400;
    public static byte[] byArrFld = new byte[N];
    public static long lMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long dMeth_check_sum = 0;

    static {
        short[] sArr = new short[N];
        sArrFld = sArr;
        FuzzerUtils.init(sArr, (short) -24248);
        FuzzerUtils.init(byArrFld, (byte) 90);
    }

    public static double dMeth() {
        int i;
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -77.101621d);
        int i2 = -6;
        float f = 41.916f;
        double d = 126.78193d;
        double d2 = 0.108195d;
        int i3 = 11;
        while (i3 < 355) {
            f -= f;
            d = 1.0d;
            do {
                long j = instanceCount;
                long j2 = j + j;
                instanceCount = j2;
                long j3 = i3;
                int i4 = i2 + ((int) (((long) 1.0d) ^ j3));
                long j4 = j2 + j3;
                instanceCount = j4;
                instanceCount = j4;
                f = (f + ((float) d)) - (-8989.0f);
                long j5 = j4 - i4;
                instanceCount = j5;
                i2 = i4 - ((int) j5);
                i = i3 + 1;
                dArr[i] = 8;
                d += 1.0d;
            } while (d < 5.0d);
            i3 = i;
            d2 = 2.0d;
        }
        long floatToIntBits = i3 + i2 + Float.floatToIntBits(f) + Double.doubleToLongBits(d) + Double.doubleToLongBits(d2) + 8 + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        dMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static int iMeth(long j, int i, int i2) {
        int i3;
        double d;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(jArr, 3903266759103189862L);
        FuzzerUtils.init(iArr, 14);
        FuzzerUtils.init(bArr, (byte) -103);
        float f = 1.0f;
        int i4 = i2;
        int i5 = 12;
        int i6 = 8537;
        int i7 = -17190;
        float f2 = 1.0f;
        do {
            int i8 = (int) f2;
            i3 = i8;
            while (i3 < 7) {
                int i9 = (int) (f2 + f);
                long j2 = jArr[i9];
                int i10 = i4 - 1;
                double abs = Math.abs(dMeth());
                Double.isNaN(i10 * 11 * i);
                jArr[i9] = j2 << ((int) (d + abs));
                bFld = true;
                int i11 = ((i3 >>> 1) % 5) + 2;
                if (i11 == 2) {
                    i6 = 1;
                } else if (i11 == 3) {
                    i5 = (int) instanceCount;
                } else if (i11 == 4) {
                    i5 += 111;
                } else if (i11 == 5) {
                    i5 += i3 - i3;
                } else if (i11 == 6) {
                    i7 = i8;
                }
                i3 += 3;
                i4 = i10;
                f = 1.0f;
            }
            f = 1.0f;
            f2 += 1.0f;
        } while (f2 < 235.0f);
        long floatToIntBits = ((((((((j + i) + i4) + Float.floatToIntBits(f2)) + i3) + i5) + i6) + i7) - 3793330418L) + Float.floatToIntBits(-123.208f) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(bArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static long lMeth() {
        int i = 156;
        byte b = 5;
        int iMeth = (((iMeth(instanceCount, iFld, 156) >>> 1) % 4) * 5) + 60;
        int i2 = -100;
        int i3 = 16;
        int i4 = -30874;
        int i5 = 41;
        int i6 = -47;
        int i7 = -25;
        int i8 = -89;
        float f = 21.808f;
        if (iMeth != 67) {
            if (iMeth == 70) {
                int i9 = 306;
                while (i9 > 2) {
                    iFld <<= i9;
                    instanceCount += i9 + 156;
                    sArrFld = FuzzerUtils.short1array(N, (short) -7719);
                    i9--;
                }
                int i10 = 1;
                byte b2 = 5;
                do {
                    i5 = 1;
                    while (5 > i5) {
                        int i11 = iFld;
                        int i12 = i11 + (((i5 * i3) + i3) - i11);
                        iFld = i12;
                        i -= b2;
                        iFld = i12 >> i3;
                        i7 = 1;
                        while (i7 < 2) {
                            i3 = 174;
                            sFld = (short) (sFld - ((short) dFld));
                            i8 -= iFld;
                            b2 = (byte) (b2 + ((byte) i9));
                            i7++;
                        }
                        i5++;
                    }
                    i10++;
                } while (i10 < 329);
                b = b2;
                i4 = i10;
                i2 = i9;
            } else if (iMeth != 72) {
                if (iMeth == 74) {
                    f = (float) instanceCount;
                } else {
                    i6 = -100;
                }
            }
            long floatToIntBits = i + i2 + i3 + i4 + i5 + i6 + b + i7 + i8 + Float.floatToIntBits(f);
            lMeth_check_sum += floatToIntBits;
            return floatToIntBits;
        }
        f -= 41;
        long floatToIntBits2 = i + i2 + i3 + i4 + i5 + i6 + b + i7 + i8 + Float.floatToIntBits(f);
        lMeth_check_sum += floatToIntBits2;
        return floatToIntBits2;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        int i4;
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init((Object[][]) iArr, (Object) (-50323));
        FuzzerUtils.init(jArr, 8757L);
        long j = instanceCount - 1;
        instanceCount = j;
        int reverseBytes = Integer.reverseBytes((int) (0 + j));
        int lMeth = reverseBytes - ((int) (lMeth() * reverseBytes));
        int i5 = iFld;
        int[] iArr2 = iArr[(i5 >>> 1) % N][(i5 >>> 1) % N];
        int i6 = (i5 >>> 1) % N;
        iArr2[i6] = iArr2[i6] & ((int) instanceCount);
        int i7 = -204;
        int i8 = -949;
        int i9 = -4751;
        int i10 = 69;
        int i11 = 21208;
        float f = -119.498f;
        float f2 = 46.82f;
        int i12 = 5;
        while (true) {
            int i13 = -29;
            if (i12 < 180) {
                int i14 = i12 + 1;
                iArr[i14][i14][i12] = lMeth;
                int i15 = iFld - i12;
                iFld = i15;
                iFld = i15 >>> i12;
                sFld = (short) (sFld + ((short) dFld));
                float f3 = 8.0f;
                lMeth = lMeth;
                while (true) {
                    if (f3 >= 143.0f) {
                        i = i11;
                        break;
                    }
                    double d = dFld;
                    double d2 = i12;
                    Double.isNaN(d2);
                    dFld = d + d2;
                    i10 = i10;
                    i9 = 1;
                    int i16 = lMeth;
                    int i17 = i7;
                    int i18 = i16;
                    while (true) {
                        i9++;
                        if (i9 >= 4) {
                            break;
                        }
                        i8 -= i18;
                        int[] iArr3 = iArr[i9 + 1][i12];
                        int i19 = i9 - 1;
                        iArr3[i19] = iArr3[i19] | sFld;
                        int i20 = (i9 | i8) + i18;
                        f2 -= i13;
                        int i21 = i11;
                        instanceCount += ((i9 * i8) + 970) - i17;
                        bFld = bFld;
                        try {
                            i4 = 25 / i9;
                            iFld = i4;
                        } catch (ArithmeticException e) {
                        }
                        try {
                            i18 = i4 / 47;
                            i11 = i21;
                            i17 = 0;
                        } catch (ArithmeticException e2) {
                            i17 = 0;
                            i18 = i20;
                            i11 = i21;
                            i10 = 970;
                        }
                        i10 = 970;
                    }
                    i = i11;
                    if (bFld) {
                        if (bFld) {
                            int i22 = i17;
                            lMeth = i18;
                            i7 = i22;
                            break;
                        }
                        i11 = 1;
                        for (i2 = 4; i11 < i2; i2 = 4) {
                            int i23 = i10;
                            f2 -= (float) instanceCount;
                            instanceCount = sFld;
                            int i24 = (int) f3;
                            int[] iArr4 = iArr[i12][i24];
                            int i25 = i11 + 1;
                            iArr4[i25] = iArr4[i25] + i24;
                            iFld += i11 * i11;
                            i18 = i8;
                            i11 = i25;
                            i10 = i23;
                        }
                        i3 = i10;
                    } else {
                        i3 = i10;
                        if (bFld) {
                            f2 += f3 * f3;
                            i11 = i;
                        } else {
                            byte[] bArr = byArrFld;
                            int i26 = (int) (1.0f + f3);
                            bArr[i26] = (byte) (bArr[i26] / ((byte) (iFld | 1)));
                            i11 = i;
                        }
                    }
                    f3 += 3.0f;
                    i10 = i3;
                    i13 = -29;
                    int i27 = i17;
                    lMeth = i18;
                    i7 = i27;
                }
                i12 = i14;
                i11 = i;
                f = f3;
            } else {
                FuzzerUtils.out.println("i i18 i19 = " + lMeth + "," + i12 + "," + i7);
                FuzzerUtils.out.println("f4 i20 i21 = " + Float.floatToIntBits(f) + "," + i8 + "," + i9);
                FuzzerUtils.out.println("i22 f5 by1 = " + i10 + "," + Float.floatToIntBits(f2) + ",-29");
                FuzzerUtils.out.println("i23 i24 iArr1 = " + i11 + ",0," + FuzzerUtils.checkSum((Object[][]) iArr));
                FuzzerUtils.out.println("lArr1 = " + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + iFld);
                FuzzerUtils.out.println("Test.sFld Test.dFld Test.sArrFld = " + ((int) sFld) + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(sArrFld));
                FuzzerUtils.out.println("Test.byArrFld = " + FuzzerUtils.checkSum(byArrFld));
                FuzzerUtils.out.println("dMeth_check_sum: " + dMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
