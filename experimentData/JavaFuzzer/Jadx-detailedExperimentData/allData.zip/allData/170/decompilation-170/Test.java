/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/170/original-170/Test.dex */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 3032226234022873105L;
    public static float fFld = 1.207f;
    public static double dFld = 0.4622d;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;
    public int iFld = -49138;
    public int iFld1 = 14;
    public int[] iArrFld = new int[N];
    public volatile long[] lArrFld = new long[N];

    public static void vMeth2(double d) {
        double[] dArr = new double[N];
        FuzzerUtils.init(dArr, -32.3747d);
        int i = -4;
        int i2 = 32;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 >= 177) {
                break;
            }
            int i4 = i3 - 1;
            double d2 = dArr[i4];
            double d3 = i3;
            Double.isNaN(d3);
            dArr[i4] = d2 - d3;
            i = 1;
            do {
                fFld -= i;
                i++;
            } while (i < 9);
            i2 = 1;
        }
        int i5 = 6;
        int i6 = 179;
        short s = 9273;
        while (i5 < 189) {
            instanceCount *= (long) d;
            i6 = 1;
            while (i6 < 9) {
                s = (short) instanceCount;
                instanceCount = instanceCount;
                i6++;
            }
            i5++;
        }
        vMeth2_check_sum += ((((((((Double.doubleToLongBits(d) + i3) + i) + i2) - 7) + 103) + 1) + i5) - 145) + i6 + 110 + s + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    }

    public static void vMeth1(int i) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, 197);
        FuzzerUtils.init(fArr, 4.473f);
        int i2 = -4;
        int i3 = 96;
        int i4 = 32;
        int i5 = 24;
        int i6 = i;
        double d = -2.94347d;
        int i7 = 1;
        float f = -122.842f;
        while (i7 < 180) {
            i3 = 1;
            while (i3 < 9) {
                i4 /= (int) (instanceCount | 1);
                instanceCount = ((-16757) / (i4 | 1)) + (-f);
                long j = i3 % (((long) d) | 1);
                vMeth2(119.124321d);
                d = i6;
                i3++;
                f = 1.0f + f;
            }
            int i8 = 1;
            while (9 > i8) {
                instanceCount = instanceCount;
                i6 += i8;
                i8++;
            }
            instanceCount += ((i7 * (-248)) - 248) - i7;
            fArr[i7 - 1] = i4;
            fFld -= i8;
            i7++;
            iArr[i7] = (int) d;
            i2 = 90;
            i6 = i6;
            i5 = i8;
        }
        vMeth1_check_sum += (((((((((i6 + i7) + i2) + i3) + i4) + Float.floatToIntBits(f)) + Double.doubleToLongBits(d)) + 31877) + i5) - 248) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vMeth(short s, int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 1);
        vMeth1(i);
        float f = fFld;
        fFld = f * f;
        int i2 = 14;
        int i3 = 14;
        int i4 = 11869;
        int i5 = -28666;
        int i6 = -207;
        float f2 = 4.0f;
        while (f2 < 197.0f) {
            i4--;
            int i7 = (int) f2;
            short s2 = (short) (s + ((short) i7));
            int i8 = 8;
            do {
                i4 *= i7;
                i8 -= 2;
            } while (i8 > 0);
            switch ((int) ((f2 % 4.0f) + 35.0f)) {
                case 35:
                case 36:
                    int i9 = i7;
                    while (i9 < 8) {
                        iArr[i9] = iArr[i9] - i;
                        i4 += i7;
                        instanceCount = -42617L;
                        i9++;
                        i5 = 1;
                    }
                    i3 = i9;
                    continue;
                    f2 += 1.0f;
                    i2 = i8;
                    s = s2;
                case 37:
                    i = 1;
                    continue;
                    f2 += 1.0f;
                    i2 = i8;
                    s = s2;
                case 38:
                    i6 *= (int) fFld;
                    break;
            }
            iArr[i7] = iArr[i7] + i5;
            f2 += 1.0f;
            i2 = i8;
            s = s2;
        }
        vMeth_check_sum += ((((((s + i) + Float.floatToIntBits(f2)) + i4) + i2) + i3) - 32022) + i5 + i6 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, -2.482f);
        vMeth((short) 24513, -139);
        FuzzerUtils.out.println("i22 i23 i24 = -139,11,75");
        FuzzerUtils.out.println("i25 i26 i27 = -211,152,53797");
        FuzzerUtils.out.println("i28 by1 i29 = -131,-18,185");
        FuzzerUtils.out.println("i30 i31 i32 = -35606,220,24813");
        FuzzerUtils.out.println("s3 i33 i34 = -6786,-144,105");
        FuzzerUtils.out.println("b1 fArr1 = 0," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("iFld iFld1 iArrFld = " + this.iFld + "," + this.iFld1 + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
