
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/124/original-124/Test.dex */
public class Test {
    public static long instanceCount = 4278281980L;
    public static short sFld = -24456;
    public static boolean bFld = false;
    public static float fFld = 2.386f;
    public static final int N = 400;
    public static volatile float[] fArrFld = new float[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public volatile byte byFld = 2;
    public long[] lArrFld = new long[N];
    public byte[] byArrFld = new byte[N];

    static {
        FuzzerUtils.init(fArrFld, 0.988f);
    }

    public static long lMeth(int i, boolean z, int i2) {
        double[] dArr = new double[N];
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 14L);
        FuzzerUtils.init(dArr, -68.84704d);
        FuzzerUtils.init(iArr, 4332);
        double d = instanceCount;
        Double.isNaN(d);
        double d2 = d * 3.84741d;
        int i3 = i2;
        int i4 = 6;
        while (i4 < 138) {
            i4++;
            jArr[i4] = jArr[i4] - 241;
            instanceCount -= i3;
            i3 = (int) d2;
            instanceCount = fFld;
        }
        int i5 = i;
        int i6 = 4;
        int i7 = -241;
        while (i6 < 373) {
            i5 = -91;
            i7 += i4;
            i6++;
        }
        double d3 = dArr[51];
        double d4 = i7;
        Double.isNaN(d4);
        dArr[51] = d3 - d4;
        iArr[(i6 >>> 1) % N][(i4 >>> 1) % N] = 102;
        instanceCount -= i7;
        long doubleToLongBits = (((((((((i5 * (-105)) + (z ? 1 : 0)) + i3) + Double.doubleToLongBits(d2)) + i4) + (i7 + 306195405)) + i6) + 102) - 105) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public static void vMeth1() {
        int i;
        double d;
        float f;
        double d2;
        double d3;
        int i2;
        int i3;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 11);
        int i4 = -14;
        double d4 = 290.0d;
        while (d4 > 9.0d) {
            float f2 = i4;
            sFld = (short) (sFld * ((short) (f2 - (((-1.194f) + f2) + f2))));
            long reverseBytes = instanceCount + ((i4 & i4) - Integer.reverseBytes(i4)) + i4;
            instanceCount = reverseBytes;
            instanceCount = reverseBytes & i4;
            d4 -= 1.0d;
            i4--;
        }
        int i5 = (i4 >>> 1) % N;
        int i6 = iArr[i5];
        long j = instanceCount;
        int i7 = iArr[2] + 1;
        iArr[2] = i7;
        iArr[i5] = i6 - ((int) (((i4 * 83) - (i4 - i4)) - (j * i7)));
        int i8 = 168;
        int i9 = i4;
        double d5 = -2.76994d;
        int i10 = 4;
        int i11 = 168;
        int i12 = -1;
        int i13 = -21357;
        int i14 = -4;
        int i15 = -8673;
        float f3 = 2.133f;
        while (i10 < 334) {
            float f4 = f3 - 1.0f;
            bFld = ((float) (((long) (i13 - i10)) - instanceCount)) < Math.abs(f3);
            int i16 = i9;
            int i17 = i11;
            int i18 = 1;
            while (i18 < 5) {
                int i19 = i18;
                double d6 = d5;
                int i20 = (int) (((float) ((i13 % (instanceCount | 1)) - (i19 + i13))) * f4);
                int i21 = ((i19 % 2) * 5) + 86;
                if (i21 == 91) {
                    d5 = d6;
                    i14 = 1;
                    while (i14 < 2) {
                        float f5 = f4;
                        long j2 = instanceCount;
                        iArr[i10] = -671314614;
                        short s = (short) (sFld - 1);
                        sFld = s;
                        double d7 = d4;
                        Double.isNaN(s);
                        instanceCount = (((-671314614) << ((int) j2)) >> ((int) (d2 - (-d3)))) & j2;
                        int i22 = i14 - 1;
                        iArr[i22] = iArr[i22] * i16;
                        i13 = (int) (((i13 + 1) - ((-3335545688L) - (s + i2))) / (Math.max(i15, i3 + 153) | 1));
                        i12 += i14 * i15;
                        i14++;
                        i16--;
                        f4 = f5;
                        d5 += 1.0d;
                        d4 = d7;
                        i20 = i20;
                    }
                    d = d4;
                    i = i20;
                    f = f4;
                } else if (i21 == 92) {
                    try {
                        i15 = 2834 / i15;
                        int i23 = i19 - 1;
                        i13 = iArr[i23] / (-163);
                        iArr[i23] = 53557 % iArr[i10 + 1];
                        d = d4;
                        i = i20;
                        f = f4;
                        d5 = d6;
                    } catch (ArithmeticException e) {
                        d = d4;
                        i = i20;
                        f = f4;
                        d5 = d6;
                    }
                } else {
                    i16 = (int) (Math.max(-70, i10) + lMeth(3, bFld, i15));
                    i12 += i16;
                    d = d4;
                    i = i20;
                    f = f4;
                    d5 = d6;
                }
                i18 = i19 + 1;
                f4 = f;
                d4 = d;
                i17 = i;
            }
            int i24 = i18;
            i10++;
            i11 = i17;
            i9 = i16;
            i8 = i24;
            f3 = f4;
            d4 = d4;
        }
        vMeth1_check_sum += Double.doubleToLongBits(d4) + i9 + 83 + i10 + i13 + Float.floatToIntBits(f3) + i8 + i11 + i14 + i15 + Double.doubleToLongBits(d5) + i12 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(byte b) {
        int i;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 9);
        FuzzerUtils.init(jArr, -54925L);
        instanceCount++;
        try {
            iArr[22] = -57773684;
            i = 21;
        } catch (ArithmeticException e) {
            i = -10;
        }
        vMeth_check_sum += ((((((((b + 21) + i) + 1) - 10) + 2) + Float.floatToIntBits(106.101f)) + Double.doubleToLongBits(-79.96836d)) - 161) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
    }

    public void mainTest(String[] strArr) {
        int[][] iArr;
        int i;
        double[] dArr;
        int[][] iArr2 = (int[][]) Array.newInstance(int.class, N, N);
        double[] dArr2 = new double[N];
        FuzzerUtils.init(dArr2, -2.49867d);
        FuzzerUtils.init(iArr2, -67);
        vMeth(this.byFld);
        int i2 = 62066;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 >= 331) {
                break;
            }
            i2 = -99;
        }
        int i4 = 0;
        int i5 = 20;
        int i6 = 54258;
        int i7 = 51192;
        int i8 = -5393;
        long j = -6984477168613311786L;
        for (int i9 = N; i4 < i9; i9 = N) {
            double d = dArr2[i4];
            float[] fArr = fArrFld;
            int i10 = (i3 >>> 1) % i9;
            fArr[i10] = fArr[i10] + sFld;
            i5 = 3;
            while (i5 < 63) {
                if (bFld) {
                    iArr = iArr2;
                    i = i2;
                    i6 = i3;
                    dArr = dArr2;
                } else {
                    long j2 = 1;
                    j = 1;
                    while (true) {
                        if (j >= 2) {
                            i = i2;
                            dArr = dArr2;
                            break;
                        }
                        i = i2;
                        dArr = dArr2;
                        long j3 = j + j2;
                        iArr2[(int) (j - j2)][(int) j3] = (int) j;
                        short s = sFld;
                        long j4 = instanceCount;
                        sFld = (short) (s + ((short) j4));
                        boolean z = bFld;
                        if (z) {
                            this.lArrFld = this.lArrFld;
                            if (z) {
                                break;
                            }
                        } else {
                            long j5 = j4 - j4;
                            instanceCount = j5;
                            instanceCount = j5 >>> i3;
                        }
                        j = j3;
                        dArr2 = dArr;
                        i2 = i;
                        j2 = 1;
                    }
                    fFld += i5 + 10;
                    int i11 = this.byFld + i3;
                    i7 = 1;
                    while (2 > i7) {
                        int i12 = i7 + 1;
                        iArr2[i7 - 1][i12] = i11;
                        long j6 = i7 * i7;
                        long j7 = instanceCount + j6;
                        instanceCount = j7;
                        int i13 = i11;
                        int[][] iArr3 = iArr2;
                        fFld %= (float) (j | 1);
                        short s2 = (short) i7;
                        sFld = s2;
                        long j8 = j7 + (j6 - 4256195689L);
                        instanceCount = j8;
                        instanceCount = j8 + s2;
                        byte[] bArr = this.byArrFld;
                        int i14 = i5 - 1;
                        bArr[i14] = (byte) (bArr[i14] & ((byte) i5));
                        i7 = i12;
                        iArr2 = iArr3;
                        i11 = i13;
                        i8 = i11;
                    }
                    iArr = iArr2;
                    i8 -= i7;
                    i6 = i11;
                }
                i5++;
                dArr2 = dArr;
                i2 = i;
                iArr2 = iArr;
            }
            i4++;
            i2 = i2;
        }
        FuzzerUtils.out.println("i i22 i23 = " + i2 + "," + i3 + "," + i5);
        FuzzerUtils.out.println("i24 l i25 = " + i6 + "," + j + ",10");
        FuzzerUtils.out.println("i26 i27 dArr1 = " + i7 + "," + i8 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr2)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(iArr2));
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + ((int) sFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.fFld byFld Test.fArrFld = " + Float.floatToIntBits(fFld) + "," + ((int) this.byFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lArrFld byArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(this.byArrFld));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
