
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/134/original-134/Test.dex */
public class Test {
    public static long instanceCount = 1450631406;
    public static double dFld = 119.83042d;
    public static boolean bFld = false;
    public static volatile byte byFld = 103;
    public static final int N = 400;
    public static volatile long[] lArrFld = new long[N];
    public static int[] iArrFld = new int[N];
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        FuzzerUtils.init(lArrFld, 180L);
        FuzzerUtils.init(iArrFld, -2);
    }

    public static void vMeth1() {
        int i = 137;
        int i2 = -204;
        int i3 = -12;
        int i4 = -13;
        double d = 0.67195d;
        int i5 = 9;
        while (i5 < 333) {
            i += 0;
            int i6 = 1;
            int i7 = 1;
            while (true) {
                i7++;
                if (i7 >= 5) {
                    break;
                }
                d = 1.0d;
            }
            if (!bFld) {
                i -= 223;
                int i8 = (int) instanceCount;
                while (i6 < 5) {
                    instanceCount = i6;
                    i6++;
                }
                i3 = i8 + (((i5 * i7) - 937) - (-937));
                i4 = i6;
            }
            i5++;
            i2 = i7;
        }
        double d2 = dFld;
        double d3 = instanceCount;
        Double.isNaN(d3);
        dFld = d2 + d3;
        vMeth1_check_sum += ((((((0 + i5) + i) + i2) + Double.doubleToLongBits(d)) + i3) + i4) - 937;
    }

    public static int iMeth(long j, int i) {
        int i2 = -8163;
        int i3 = -19863;
        float f = 51.948f;
        int i4 = 9;
        while (214 > i4) {
            f *= (float) ((((i4 + 11005) * 91) - 80) * 14106);
            int i5 = 1;
            while (true) {
                i5++;
                if (i5 < 8) {
                    vMeth1();
                    i3 = 1;
                }
            }
            i4++;
            i2 = i5;
        }
        long floatToIntBits = (((((((j + i) + i4) - 80) + Float.floatToIntBits(f)) + 11005) + i2) + i3) - 160;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(long j, int i, long j2) {
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        float[][][] fArr = (float[][][]) Array.newInstance(float.class, N, N, N);
        FuzzerUtils.init(iArr, -51910);
        FuzzerUtils.init((Object[][]) fArr, (Object) Float.valueOf(51.22f));
        FuzzerUtils.init(zArr, false);
        double d = 8074;
        double d2 = i;
        double d3 = dFld;
        Double.isNaN(d2);
        Double.isNaN(d);
        int i2 = iArr[4];
        iArr[4] = i2 - 1;
        double d4 = i2;
        Double.isNaN(d4);
        int i3 = i - ((int) ((d + (d2 * d3)) - d4));
        int i4 = 4;
        while (i4 < 190) {
            i4++;
        }
        vMeth_check_sum += (((((((((((i3 + j) + j2) + 8074) + i4) + 22163) + 0) - 21607) + 4) - 109) + 5) - 11307) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr)) + FuzzerUtils.checkSum(zArr);
    }

    public void mainTest(String[] strArr) {
        int i = ((int) lArrFld[340]) ^ (-216);
        int i2 = -131;
        int i3 = 146;
        int i4 = 10;
        int i5 = 245;
        while (15 < i5) {
            long j = instanceCount;
            int i6 = (int) j;
            vMeth(j, i6, j);
            if (bFld) {
                i2 = i6;
            } else {
                int i7 = (int) 1.48f;
                instanceCount = (long) dFld;
                byFld = (byte) (byFld + ((byte) i7));
                int i8 = 1;
                do {
                    instanceCount += 52563;
                    i8++;
                } while (i8 < 109);
                i3 = i8;
                i2 = i7;
                i4 = 1;
            }
            i5--;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i + "," + i5 + "," + i2);
        FuzzerUtils.out.println("i23 i24 s2 = 72,217,1373");
        FuzzerUtils.out.println("i25 i26 i27 = 41262,52563," + i3);
        FuzzerUtils.out.println("i28 i29 = " + i4 + ",-41757");
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.bFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.byFld Test.lArrFld Test.iArrFld = " + ((int) byFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
