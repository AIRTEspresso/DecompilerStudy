/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/186/original-186/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public boolean bFld = false;
    public static long instanceCount = -20946;
    public static int iFld = 3;
    public static long lFld = 125;
    public static long lMeth_check_sum = 0;
    public static long bMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -36523);
    }

    public static long lMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 182);
        iArr[67] = iArr[67] >> ((int) instanceCount);
        long checkSum = i + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += checkSum;
        return checkSum;
    }

    public static void vMeth1(int i, int i2) {
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(iArr, -12);
        FuzzerUtils.init(sArr, (short) 15552);
        int i3 = i;
        int i4 = i2;
        long j = 0;
        int i5 = -3;
        int i6 = -40438;
        float f = -127.634f;
        int i7 = 10;
        int i8 = 1;
        while (i7 < 179) {
            j = i7;
            while (9 > j) {
                f = i7;
                j++;
            }
            i8 = 1;
            while (i8 < 9) {
                int i9 = i7 - 1;
                int i10 = (int) j;
                sArr[i9] = (short) (sArr[i9] * ((short) i10));
                i4 *= 2548;
                iArr[i9] = iArr[i9] * i10;
                i8++;
                i3 = -216;
                i5 = 2;
                i6 = 2;
            }
            i7++;
        }
        vMeth1_check_sum += ((((((((i3 + i4) + i7) + 2) + j) - 4) + Float.floatToIntBits(f)) + i8) - 150) + i5 + Double.doubleToLongBits(0.2123d) + i6 + 2548 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(sArr);
    }

    public static void vMeth(int i, int i2, int i3) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -190);
        vMeth1(iFld, i2);
        int i4 = 214;
        int i5 = 0;
        int i6 = -7;
        int i7 = 1;
        while (true) {
            i7++;
            if (i7 < 352) {
                i4 = 1;
                while (i4 < 5) {
                    iArr[1] = iArr[1] - ((int) instanceCount);
                    i6 += ((1 * i7) + 1) - i6;
                    i5 = 2;
                    i4++;
                }
            } else {
                vMeth_check_sum += (((((i2 + i3) + i3) + i7) + i4) - 54274) + i5 + i6 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static boolean bMeth(int i, long j, long j2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 83L);
        int i2 = -14;
        float f = 0.373f;
        int i3 = 1;
        do {
            vMeth(iFld, 179, 125);
            try {
                int i4 = (-45456) / i;
                i = i3 / 11925;
                iFld = 195 % iFld;
            } catch (ArithmeticException e) {
            }
            i /= (int) (f | 1);
            f += i2;
            iFld %= -23543;
            i2 *= -38507;
            i3++;
        } while (i3 < 137);
        long floatToIntBits = ((((((((i + j) + j2) + i3) + Float.floatToIntBits(f)) + 1) - 38507) + i2) - 23543) + FuzzerUtils.checkSum(jArr);
        bMeth_check_sum += floatToIntBits;
        return floatToIntBits % 2 > 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0067, code lost:
        r7 = defpackage.Test.iFld / 55378;
        defpackage.Test.iFld = 240 / r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0077, code lost:
        r7 = (-1105412431) / r7;
     */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00a8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void mainTest(java.lang.String[] r17) {
        /*
            Method dump skipped, instructions count: 583
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.mainTest(java.lang.String[]):void");
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
