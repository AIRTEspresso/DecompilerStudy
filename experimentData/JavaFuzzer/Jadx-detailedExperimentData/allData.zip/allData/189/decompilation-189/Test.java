
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/189/original-189/Test.dex */
public class Test {
    public static double[] dArrFld;
    public short sFld = 30223;
    public static long instanceCount = -6003932471390524530L;
    public static volatile int iFld = 24387;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    static {
        double[] dArr = new double[N];
        dArrFld = dArr;
        FuzzerUtils.init(dArr, 0.82587d);
        FuzzerUtils.init(iArrFld, -144);
        FuzzerUtils.init(lArrFld, -4183428435L);
    }

    /* JADX WARN: Removed duplicated region for block: B:121:0x068c A[LOOP:1: B:4:0x007e->B:121:0x068c, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:135:0x061f A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static int iMeth1(int r28, int r29, long r30) {
        /*
            Method dump skipped, instructions count: 1988
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.iMeth1(int, int, long):int");
    }

    public static void vMeth(float f) {
        int i = 10;
        int i2 = 5;
        while (129 > i2) {
            i = ((int) (iMeth1(36255, iFld, instanceCount) - instanceCount)) + iFld;
            iArrFld = FuzzerUtils.int1array(N, -17150);
            f += f;
            i2++;
        }
        vMeth_check_sum += Float.floatToIntBits(f) + i + i2 + 36255;
    }

    public static int iMeth() {
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, -467464507L);
        int i = 12;
        int i2 = 63689;
        int i3 = -24749;
        int i4 = -201;
        int i5 = -11;
        int i6 = 10;
        while (i6 < 314) {
            vMeth(109.885f);
            int i7 = i2;
            int i8 = 1;
            while (i8 < 5) {
                i7 += (i8 * i8) - 49100;
                iFld -= i8;
                iFld += i8;
                instanceCount >>= iFld;
                i8++;
            }
            int i9 = i5;
            int i10 = i4;
            int i11 = 1;
            while (i11 < 5) {
                i9 = 2;
                while (i9 > 1) {
                    iFld += i9;
                    long[] jArr2 = jArr[i11];
                    jArr2[i11] = jArr2[i11] - ((long) (-6.56664d));
                    i10 = (int) instanceCount;
                    i9--;
                }
                i11++;
            }
            i6++;
            i = i8;
            i2 = i7;
            i3 = i11;
            i4 = i10;
            i5 = i9;
        }
        long floatToIntBits = ((((((((i6 + 45735) + Float.floatToIntBits(109.885f)) + i) + i2) + i3) + i4) + i5) - 4) + Double.doubleToLongBits(-6.56664d) + 0 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        float[] fArr;
        FuzzerUtils.init(new float[N], 58.1f);
        int i = -26;
        int i2 = -9;
        int i3 = 245;
        float f = -1.847f;
        int i4 = 6;
        while (i4 < 274) {
            int i5 = ((i4 % 3) * 5) + 34;
            if (i5 == 36) {
                f = i3;
            } else if (i5 == 40) {
                i2 = 4;
                while (i2 < 94) {
                    i += iMeth();
                    lArrFld[i4 + 1] = 108;
                    f -= 5.0f;
                    instanceCount = instanceCount;
                    i3 = 2;
                    i2++;
                }
            }
            i4++;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i4 + "," + i + "," + i2);
        FuzzerUtils.out.println("i3 by2 f5 = 143,108," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i23 i24 i25 = " + i3 + ",222,8128");
        FuzzerUtils.out.println("b2 fArr1 = 1," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld sFld = " + instanceCount + "," + iFld + "," + ((int) this.sFld));
        FuzzerUtils.out.println("Test.dArrFld Test.iArrFld Test.lArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
