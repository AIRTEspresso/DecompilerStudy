
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/20/original-20/Test.dex */
public class Test {
    public static final int N = 400;
    public volatile double dFld = 1.45337d;
    public static long instanceCount = 199;
    public static boolean bFld = true;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long bMeth_check_sum = 0;

    public static boolean bMeth(int i, int i2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 39814);
        double d = -35481;
        Double.isNaN(d);
        double d2 = (-2.119147d) - d;
        bFld = bFld;
        double d3 = 1;
        Double.isNaN(d3);
        return ((int) (((((((((((long) (i + i2)) + 5) + ((long) (-13))) + ((long) 1)) + ((long) (-35481))) + Double.doubleToLongBits(d2 * d3)) + ((long) 53675)) + ((long) (-8))) + ((long) 26720)) + FuzzerUtils.checkSum(iArr))) % 2 > 0;
    }

    public static void vMeth(int i, long j, int i2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -11668);
        bFld = bMeth(i, i);
        int i3 = 127;
        int i4 = 11;
        double d = -9.95535d;
        int i5 = 3;
        while (149 > i5) {
            int i6 = i5 - 1;
            iArr[i6] = iArr[i6] * i3;
            d = i5;
            while (d < 11.0d) {
                i3 += (int) d;
                d += 1.0d;
                i4 = 1;
            }
            i5++;
        }
        vMeth_check_sum += i + j + i + i5 + i3 + Double.doubleToLongBits(d) + 44526 + i4 + 40730 + 97 + ((short) 265) + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(long j, short s) {
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        int i = -126;
        FuzzerUtils.init(iArr, -126);
        FuzzerUtils.init((Object[][]) jArr, (Object) (-100L));
        long j2 = j << 9;
        vMeth(61572, instanceCount, 61572);
        int i2 = 0;
        double d = 0;
        int i3 = 61250;
        int i4 = 13;
        while (338 > i4) {
            int i5 = i2;
            i3 = i5;
            int i6 = i4;
            while (i6 < 5) {
                try {
                    i3 = i6 / 92;
                    int i7 = 92 / i4;
                    int i8 = iArr[i6] / (-17);
                } catch (ArithmeticException e) {
                }
                bFld = bFld;
                i6++;
                long[] jArr2 = jArr[i4][i6];
                jArr2[i4] = jArr2[i4] - s;
                i5 = 233;
                iArr = iArr;
                jArr = jArr;
            }
            i4++;
            int i9 = i6;
            i2 = i5;
            i = i9;
        }
        long doubleToLongBits = j2 + s + i2 + Double.doubleToLongBits(d) + i4 + i3 + i + 92 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum((Object[][]) jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        float f;
        int i2;
        int i3;
        long j;
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(fArr, 0.899f);
        FuzzerUtils.init(jArr, -969976997L);
        FuzzerUtils.init(iArr, 116);
        int i4 = 11;
        while (true) {
            i = -12710;
            if (i4 >= 290) {
                break;
            }
            instanceCount += ((i4 * (-12710)) + i4) - (-12710);
            i4++;
        }
        int i5 = 212;
        int i6 = 61882;
        int i7 = -12;
        int i8 = -13792;
        float f2 = -2.53f;
        while (true) {
            int i9 = 1;
            short s = 7816;
            if (i5 <= 8) {
                break;
            }
            i6--;
            f2 += 1.0f;
            bFld = ((float) i6) <= ((-2.0f) + f2) * ((float) i4);
            i7 = 1;
            while (true) {
                i7 += i9;
                if (i7 >= 368) {
                    break;
                }
                instanceCount = instanceCount * iMeth(j, s) * i;
                i9 = 1;
                s = 7816;
            }
            int i10 = 1;
            while (true) {
                i10++;
                if (i10 < 368) {
                    fArr[17] = fArr[17] - i5;
                    instanceCount = 174L;
                    instanceCount = ((float) 174) + (i10 * f2);
                }
            }
            i |= i6;
            i5 -= 3;
            i8 = i10;
        }
        long j2 = 2;
        int i11 = 5;
        int i12 = -119;
        byte b = -117;
        while (j2 < 165) {
            int i13 = 1;
            while (true) {
                float f3 = i13 * f2;
                float f4 = i5;
                int i14 = (int) (i6 + ((f3 + f4) - f4));
                bFld = bFld;
                f = i14;
                int i15 = i14 | ((int) instanceCount);
                b = (byte) (b >> ((byte) i15));
                this.dFld = j2;
                i2 = i15 >> i15;
                i13 += 2;
                if (i13 >= 154) {
                    break;
                }
                f2 = f;
                i6 = 1;
            }
            jArr[(int) j2] = jArr[i3] - 37944;
            instanceCount >>>= b;
            j2++;
            i12 = i13;
            i = i2;
            f2 = f;
            i11 = 7816;
            i6 = i5;
        }
        double d = this.dFld;
        int i16 = i12;
        double d2 = j2;
        Double.isNaN(d2);
        this.dFld = d * d2;
        FuzzerUtils.out.println("i i1 i2 = " + i4 + "," + i + "," + i5);
        FuzzerUtils.out.println("i3 f i4 = " + (i6 + i6) + "," + Float.floatToIntBits(f2) + "," + i7);
        FuzzerUtils.out.println("s2 i25 l3 = 7816," + i8 + "," + j2);
        FuzzerUtils.out.println("i26 i27 by1 = " + i11 + "," + i16 + "," + ((int) b));
        FuzzerUtils.out.println("fArr lArr1 iArr3 = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + "," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
