 class Test {
 long instanceCount = - 222L;
int iFld = 31231;
double dFld = - 25.42777;
void vMeth1(){
 int i13;
iFld -= iFld;
for(i13 = 3;
i13 < 157;
++ i13)instanceCount += i13;
}
 void vMeth(short s){
 int i4 = 11;
long l = 92L;
double d = 1.51951;
while(++ i4 < 384){
 instanceCount ^= l;
l =(int)(iFld - d);
}
 vMeth1();
}
 void mainTest(String[]strArr1){
 float f = 28.479F;
int i , i1 = 24419 , i2 , i19 = 6;
long l1;
iFld =(int)(-(iFld * iFld)* dFld);
for(i = 5;
136 > i;
++ i){
 byte by = - 49;
f += i * instanceCount - f;
i1 +=(int)((f -(- 159 + i1 * instanceCount))-(f +(i - by)));
for(i2 = 8;
i2 < 191;
++ i2){
 vMeth((short)655);
switch(iFld){
 case 115 : dFld += 0.835F;
case 117 : for(l1 = 1;
l1 < 2;
++ l1)i19 = i19;
case 116 : i19 += i2;
}
 }
 }
 System.out.println("f i i1 = " + Float.floatToIntBits(f)+ "," + i + "," + i1);
}
 public static void main(String[]strArr){
 try {
 Test _instance = new Test();
_instance.mainTest(strArr);
}
 catch(Exception ex){
 System.out.println(ex);
}
 }
 }
