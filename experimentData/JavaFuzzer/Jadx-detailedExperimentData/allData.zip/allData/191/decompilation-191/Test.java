
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/191/original-191/Test.dex */
public class Test {
    public double dFld = 1.68015d;
    public short[] sArrFld = new short[N];
    public static long instanceCount = 62;
    public static short sFld = -32176;
    public static float fFld = 0.12f;
    public static boolean bFld = true;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static long[] lArrFld = new long[N];
    public static long[][] lArrFld1 = (long[][]) Array.newInstance(long.class, N, N);
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, 5678);
        FuzzerUtils.init(lArrFld, 7L);
        FuzzerUtils.init(lArrFld1, 18881L);
    }

    public static void vMeth2() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -13464);
        int i2 = 9497;
        int i3 = 20114;
        int i4 = -126;
        double d = 2.51093d;
        int i5 = 264;
        while (i5 > 1) {
            d = 6.0d;
            while (d > 1.0d) {
                i4 = 2;
                instanceCount += ((long) d) | i3;
                d -= 1.0d;
            }
            i3 *= i3;
            i2 /= (int) (instanceCount | 1);
            i5--;
        }
        int i6 = 18;
        int i7 = -8374;
        float f = 17.197f;
        int i8 = -3;
        while (i6 < 289) {
            switch ((i6 % 6) + 75) {
                case 75:
                    i8 = 1;
                    while (i8 < 6) {
                        instanceCount += i8;
                        i7 = (int) d;
                        i2 >>= i2;
                        i8++;
                    }
                    continue;
                    i6++;
                case 76:
                    i = i7;
                    int i9 = i6 + 1;
                    iArr[i9] = iArr[i9] & (-3);
                    break;
                case 77:
                    f += i6;
                    continue;
                    i6++;
                case 78:
                case 79:
                    i = i7;
                    instanceCount *= i2;
                    break;
                case 80:
                    i = i7;
                    break;
                default:
                    i = i7;
                    break;
            }
            i7 = i;
            i6++;
        }
        vMeth2_check_sum += i5 + i2 + Double.doubleToLongBits(d) + i3 + i4 + i6 + i7 + i8 + 14 + Float.floatToIntBits(f) + 1 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth1() {
        vMeth2();
        int i = 4;
        int i2 = -12;
        double d = 14.114085d;
        int i3 = 144;
        while (true) {
            i3 -= 2;
            if (i3 > 0) {
                double d2 = 1.0d;
                while (21.0d > d2) {
                    short s = sFld;
                    iArrFld[(int) (d2 - 1.0d)] = s;
                    int i4 = i * s;
                    i2 = 1;
                    while (i2 < 2) {
                        long[] jArr = lArrFld;
                        int i5 = i3 + 1;
                        jArr[i5] = jArr[i5] * i3;
                        i4 *= i2;
                        i2++;
                    }
                    sFld = (short) (sFld << 0);
                    i = (i4 % ((int) (fFld | 1))) - i3;
                    long[] jArr2 = lArrFld;
                    jArr2[i3 + 1] = -52298;
                    int i6 = i3 - 1;
                    jArr2[i6] = jArr2[i6] - (-1);
                    bFld = bFld;
                    d2 += 1.0d;
                }
                d = d2;
            } else {
                vMeth1_check_sum += ((((i3 + Double.doubleToLongBits(d)) + i) + i2) - 9) - 52298;
                return;
            }
        }
    }

    public static void vMeth(long j) {
        vMeth1();
        iArrFld[365] = 1;
        lArrFld1 = lArrFld1;
        int i = 207;
        int i2 = 0;
        int i3 = 4;
        int i4 = 1;
        while (i3 < 174) {
            iArrFld[i3] = (int) j;
            int i5 = 1;
            do {
                i4 -= i4;
                if ((i5 % 1) + 91 == 91) {
                    switch (((i4 >>> 1) % 10) + 18) {
                        case 18:
                            long j2 = instanceCount + i5 + i3;
                            instanceCount = j2;
                            if ((i3 % 1) + 53 == 53) {
                                if (!bFld) {
                                    instanceCount = j2 >> i5;
                                }
                            } else {
                                fFld += i5 * i;
                            }
                            break;
                        case 19:
                            i4 += 5990;
                            break;
                        case 20:
                            instanceCount &= -894;
                            break;
                        case 21:
                            i -= 22;
                            break;
                        case 22:
                            i = i3;
                            break;
                        case 23:
                            i >>= 9;
                            break;
                        case 24:
                            i -= (int) (-69);
                            break;
                        case 25:
                            i -= i5;
                            break;
                        case 26:
                            i += i5 * i5;
                            break;
                        case 27:
                            long[] jArr = lArrFld1[i3];
                            jArr[i3] = jArr[i3] - i;
                            break;
                    }
                }
                i5++;
            } while (i5 < 9);
            i3++;
            i2 = i5;
            j = -69;
        }
        vMeth_check_sum += j + i4 + i3 + i + i2;
    }

    public void mainTest(String[] strArr) {
        int i = -3;
        int i2 = 35;
        int i3 = 58518;
        int i4 = -197;
        int i5 = 12;
        int i6 = 119;
        int i7 = -5;
        int i8 = 18457;
        int i9 = 7;
        while (124 > i9) {
            vMeth(instanceCount);
            long j = instanceCount;
            i *= (int) j;
            instanceCount = j << ((int) j);
            int i10 = i8;
            int i11 = i7;
            int i12 = i6;
            int i13 = i5;
            int i14 = i4;
            int i15 = i3;
            int i16 = 1;
            while (214 > i16) {
                fFld += i16;
                switch ((i16 % 9) + 84) {
                    case 84:
                        i += ((i16 * i15) + i9) - i16;
                        i14 = i9;
                        while (2 > i14) {
                            i15 = -107;
                            fFld -= (float) instanceCount;
                            i13 *= -10106;
                            int i17 = i14 + 1;
                            lArrFld1[i17][i14] = 170;
                            try {
                                iArrFld[i14] = 17819 % i;
                                i13 = i9 % (-151);
                                i12 = (-4555) % i16;
                            } catch (ArithmeticException e) {
                            }
                            i14 = i17;
                        }
                        int i18 = 1;
                        while (i18 < 2) {
                            i15 *= i14;
                            i13 = (int) instanceCount;
                            i18++;
                        }
                        int i19 = (i9 % 2) + 20;
                        if (i19 == 20) {
                            boolean z = bFld;
                        } else if (i19 == 21) {
                            i10 = 2;
                        }
                        i11 = i18;
                        break;
                    case 85:
                        iArrFld[i9] = i16;
                        break;
                    case 86:
                    case 87:
                        int[] iArr = iArrFld;
                        iArr[i16] = iArr[i16] + ((int) instanceCount);
                        break;
                    case 88:
                        i += 1671591720;
                        break;
                    case 89:
                    case 90:
                        i13 = (int) instanceCount;
                        break;
                    case 91:
                        i -= i14;
                        break;
                    case 92:
                        i *= (int) instanceCount;
                        break;
                }
                i16++;
            }
            i9++;
            i2 = i16;
            i3 = i15;
            i4 = i14;
            i5 = i13;
            i6 = i12;
            i7 = i11;
            i8 = i10;
        }
        FuzzerUtils.out.println("i i1 i19 = " + i9 + "," + i + "," + i2);
        FuzzerUtils.out.println("i20 i21 i22 = " + i3 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("i23 i24 i25 = " + i6 + "," + i7 + ",135");
        FuzzerUtils.out.println("i26 = " + i8);
        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.fFld = " + instanceCount + "," + ((int) sFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld dFld Test.iArrFld = " + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(this.dFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.lArrFld Test.lArrFld1 sArrFld = " + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(lArrFld1) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
