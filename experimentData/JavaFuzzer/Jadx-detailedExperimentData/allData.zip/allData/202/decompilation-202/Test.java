
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/202/original-202/Test.dex */
public class Test {
    public static long instanceCount = 2413526288303012764L;
    public static final int N = 400;
    public static volatile short[] sArrFld = new short[N];
    public static long iMeth_check_sum = 0;
    public static long sMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        FuzzerUtils.init(sArrFld, (short) 9289);
    }

    public static void vMeth(float f, long j, long j2) {
        double d;
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -64);
        FuzzerUtils.init(fArr, 1.897f);
        long j3 = j;
        int i = -34456;
        int i2 = -5;
        int i3 = 21;
        while (i3 < 351) {
            i <<= (int) j3;
            i2 = 1;
            while (true) {
                i2++;
                if (i2 < 5) {
                    i += i2 * i2;
                    iArr[i2] = iArr[i2] - 1;
                    j3 += i2;
                }
            }
            i3++;
        }
        int i4 = i;
        double d2 = 21.102981d;
        int i5 = -7;
        int i6 = 34833;
        double d3 = 9.0d;
        long j4 = j3;
        float f2 = f;
        long j5 = j2;
        while (d3 < 289.0d) {
            long j6 = i3;
            double d4 = j5;
            i5 = 1;
            while (6 > i5) {
                fArr[(int) (d3 + 1.0d)] = 10;
                j5 = j5;
                i6 = 2;
                while (true) {
                    d = d4;
                    if (i6 > d3) {
                        j5 *= 1983042612573643745L;
                        i6--;
                        d4 = d;
                    }
                }
                f2 += 0.668f;
                i5++;
                d4 = d;
            }
            d3 += 1.0d;
            i4 = i3;
            j4 = j6;
            d2 = d4;
        }
        vMeth_check_sum += ((((((((((((Float.floatToIntBits(f2) + j4) + j5) + i3) + i4) + i2) + Double.doubleToLongBits(d3)) + 10) + Double.doubleToLongBits(d2)) + i5) + 1) + i6) - 59) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static short sMeth(float f, float f2, int i) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 13L);
        FuzzerUtils.init(iArr, 38707);
        long j = instanceCount;
        vMeth(f, j, j);
        double d = 75.0d;
        int i2 = (int) 75.0d;
        int i3 = 55611;
        int i4 = 23807;
        int i5 = -44272;
        int i6 = 4;
        while (i6 < 235) {
            i4 = i6;
            while (i4 < 7) {
                i4++;
            }
            i5 = -20321;
            int i7 = i6 - 1;
            long j2 = instanceCount;
            iArr[i7] = (int) j2;
            i3 = (int) j2;
            jArr[i7] = jArr[i7] - i2;
            i6++;
            d = 138.0d;
        }
        long floatToIntBits = (((((((Float.floatToIntBits(f) + Float.floatToIntBits(f2)) + i2) + Double.doubleToLongBits(d)) + i6) + i3) + i4) - 21662) + i5 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        sMeth_check_sum += floatToIntBits;
        return (short) floatToIntBits;
    }

    public static int iMeth(long j) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 6);
        double d = 7.0d;
        long j2 = j;
        while (248.0d > d) {
            sArrFld[(int) (1.0d + d)] = (short) j2;
            d += 3.0d;
            j2 = 1 + j2;
        }
        long j3 = 36;
        int i = 36 << ((int) (-(j3 - (instanceCount - j3))));
        short sMeth = (short) (i - (sArrFld[(i >>> 1) % N] * sMeth(-11.79f, -11.79f, i)));
        int i2 = i - i;
        int i3 = i2 + i2;
        int i4 = 14;
        int i5 = -60753;
        int i6 = -109;
        int i7 = -31278;
        while (i4 < 350) {
            int i8 = i4 * i4;
            i5 = i5 + i4 + i8;
            sMeth = (short) (sMeth << (-6));
            int i9 = 5;
            while (i9 > 1) {
                i5 -= i9;
                i9--;
                i7 = i4;
            }
            instanceCount += i8;
            i4++;
            i6 = i9;
        }
        iArr[119] = iArr[119] >> sMeth;
        long doubleToLongBits = j2 + Double.doubleToLongBits(d) + i3 + sMeth + Float.floatToIntBits(-11.79f) + i4 + i5 + i6 + i7 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        float f;
        double d;
        double d2;
        int i2;
        int[] iArr;
        int i3;
        int i4 = 3;
        int[][][] iArr2 = (int[][][]) Array.newInstance(int.class, N, N, N);
        short[][][] sArr = (short[][][]) Array.newInstance(short.class, N, N, N);
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        long[] jArr = new long[N];
        int i5 = -4;
        FuzzerUtils.init((Object[][]) iArr2, (Object) (-4));
        FuzzerUtils.init(jArr, 1L);
        FuzzerUtils.init((Object[][]) sArr, (Object) (short) -5904);
        FuzzerUtils.init(dArr, 2.125263d);
        int i6 = -9;
        int i7 = -504;
        float f2 = 1.269f;
        double d3 = 1.25554d;
        double d4 = -114.77433d;
        int i8 = 2;
        while (i8 < 247) {
            long[] jArr2 = jArr;
            int i9 = 1;
            int i10 = i6;
            int i11 = i5;
            int i12 = i10;
            while (true) {
                i = i9 + 1;
                if (i < 103) {
                    float iMeth = f2 + iMeth(instanceCount);
                    int i13 = i11;
                    long j = instanceCount + (i * i);
                    instanceCount = j;
                    double d5 = i;
                    Double.isNaN(d5);
                    d3 += d5;
                    long j2 = j >>> i;
                    instanceCount = j2;
                    int[][][] iArr3 = iArr2;
                    switch ((i8 % 6) + i4) {
                        case 3:
                            f = iMeth;
                            d2 = d3;
                            try {
                                iArr3[i][i - 1][144] = i8 % i;
                                d = 2.0d;
                                int i14 = (int) 2.0d;
                                try {
                                    int i15 = (int) 1.0d;
                                    iArr3[i14][i][i8] = iArr3[i][i][i15] / iArr3[i15][i14][i8 + 1];
                                } catch (ArithmeticException e) {
                                }
                            } catch (ArithmeticException e2) {
                                d = 2.0d;
                            }
                            i2 = i8 * 8144;
                            jArr2[i] = jArr2[i] << i2;
                            int i16 = (int) 1.0d;
                            i12 = (i2 * i16) + i8;
                            iArr3[(int) 0.0d][i16][i16] = iArr[i16] - 30008;
                            d3 = d2;
                            break;
                        case 4:
                            f = iMeth;
                            d2 = d3;
                            i2 = 16288;
                            d = 2.0d;
                            jArr2[i] = jArr2[i] << i2;
                            int i162 = (int) 1.0d;
                            i12 = (i2 * i162) + i8;
                            iArr3[(int) 0.0d][i162][i162] = iArr[i162] - 30008;
                            d3 = d2;
                            break;
                        case 5:
                            f = iMeth;
                            d2 = d3;
                            i2 = 16288;
                            d = 2.0d;
                            int i1622 = (int) 1.0d;
                            i12 = (i2 * i1622) + i8;
                            iArr3[(int) 0.0d][i1622][i1622] = iArr[i1622] - 30008;
                            d3 = d2;
                            break;
                        case 6:
                            f = iMeth;
                            int i17 = (int) 2.0d;
                            int i18 = i8 + 1;
                            iArr3[i - 1][i17] = iArr3[(i8 >>> 1) % N][i18];
                            int i19 = (int) 68.0d;
                            if (i19 == 71) {
                                double d6 = j2;
                                Double.isNaN(d6);
                                d3 += d6;
                                i3 = i13;
                                i12 = 16288;
                            } else if (i19 == 75) {
                                i12 = 16288 - ((int) j2);
                                i3 = i13;
                                d3 = d3;
                            } else if (i19 == 89) {
                                double d7 = j2;
                                Double.isNaN(d7);
                                double d8 = 1.0d * d7;
                                double d9 = 16288;
                                Double.isNaN(d9);
                                double d10 = j2;
                                Double.isNaN(d10);
                                i3 = i13 + ((int) ((d8 + d9) - d10));
                                d3 = d3;
                                i12 = 16288;
                            } else {
                                if (i19 != 92) {
                                    if (i19 != 94) {
                                        if (i19 != 96) {
                                            if (i19 != 98) {
                                                if (i19 == 103) {
                                                    double[] dArr2 = dArr[i18];
                                                    int i20 = i8 - 1;
                                                    double d11 = dArr2[i20];
                                                    double d12 = i8;
                                                    Double.isNaN(d12);
                                                    dArr2[i20] = d11 * d12;
                                                } else {
                                                    i3 = i13;
                                                    d3 = d3;
                                                    i12 = 16288;
                                                }
                                            } else if (((int) 1.0d) == 2) {
                                                float f3 = i * f;
                                                int i21 = 0 << i;
                                                i12 = (i21 - i21) + ((int) f3);
                                                f = f3;
                                                i3 = i13;
                                                d3 = d3;
                                            } else {
                                                i12 = -8144;
                                                i3 = i13;
                                                d3 = d3;
                                            }
                                        }
                                        instanceCount = 45127L;
                                        i3 = i13;
                                        d3 = d3;
                                        i12 = 16288;
                                    } else {
                                        instanceCount = j2 + ((long) 1.0d);
                                    }
                                }
                                int i22 = (int) 1.0d;
                                iArr3[i8][i22] = iArr3[i22][i17];
                                i3 = i13;
                                d3 = d3;
                                i12 = 16288;
                            }
                            i13 = i3;
                            d = 2.0d;
                            break;
                        case 7:
                            instanceCount = -46915L;
                            f = iMeth;
                            i12 = 16288;
                            d = 2.0d;
                            break;
                        case 8:
                            f = iMeth * (-22060);
                            i12 = 16288;
                            d = 2.0d;
                            break;
                        default:
                            d = 2.0d;
                            f = iMeth - iMeth;
                            d3 = d3;
                            i12 = 16288;
                            break;
                    }
                    f2 = f;
                    iArr2 = iArr3;
                    i4 = 3;
                    d4 = d;
                    i11 = i13;
                    i9 = i;
                }
            }
            int i23 = i11;
            i8++;
            i6 = i12;
            jArr = jArr2;
            i7 = i;
            i5 = i23;
            iArr2 = iArr2;
            i4 = 3;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i8 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("f s1 d4 = " + Float.floatToIntBits(f2) + ",8144," + Double.doubleToLongBits(d3));
        FuzzerUtils.out.println("d5 i22 i23 = " + Double.doubleToLongBits(d4) + "," + i5 + ",-22060");
        FuzzerUtils.out.println("iArr3 lArr1 sArr = " + FuzzerUtils.checkSum((Object[][]) iArr2) + "," + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum((Object[][]) sArr));
        FuzzerUtils.out.println("dArr = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.sArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("sMeth_check_sum: " + sMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
