
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/143/original-143/Test.dex */
public class Test {
    public double dFld = -2.91153d;
    public static long instanceCount = 7709079513175631415L;
    public static int iFld = -22204;
    public static float fFld = -1.24f;
    public static byte byFld = -34;
    public static double dFld1 = 100.68138d;
    public static volatile boolean bFld = false;
    public static final int N = 400;
    public static byte[] byArrFld = new byte[N];
    public static volatile double[] dArrFld = new double[N];
    public static float[] fArrFld = new float[N];
    public static long bMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        FuzzerUtils.init(byArrFld, (byte) 103);
        FuzzerUtils.init(dArrFld, 2.44158d);
        FuzzerUtils.init(fArrFld, 1.69f);
    }

    public static void vMeth() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 12);
        iFld = -252;
        int i2 = 2;
        while (true) {
            i = 7398;
            if (i2 >= 272) {
                break;
            }
            int i3 = iFld + i2;
            iFld = i3;
            iFld = i3 + 7398;
            i2++;
        }
        int i4 = 7;
        while (387 > i4) {
            fFld += 7398;
            i4++;
        }
        int i5 = 13;
        int i6 = -56;
        int i7 = -11;
        int i8 = -110;
        int i9 = -1;
        double d = 33.110441d;
        while (i5 < 297) {
            switch ((i5 % 6) + 43) {
                case 43:
                    i -= 31184;
                    i8 = 1;
                    while (6 > i8) {
                        d = -126;
                        int i10 = i5 - 1;
                        iArr[i10] = iArr[i10] + i5;
                        byte[] bArr = byArrFld;
                        bArr[i10] = (byte) (bArr[i10] >> ((byte) i5));
                        try {
                            i6 = i8 / i6;
                            iArr[i8] = i2 / i5;
                            iArr[i8] = iArr[i8 + 1] / iFld;
                        } catch (ArithmeticException e) {
                        }
                        i8++;
                    }
                    break;
                case 44:
                    break;
                case 45:
                    iFld += i2;
                    continue;
                    i5++;
                    i7 = 31184;
                case 46:
                    iArr[i5 + 1] = i5;
                    continue;
                    i5++;
                    i7 = 31184;
                case 47:
                    i6 = 9;
                    continue;
                    i5++;
                    i7 = 31184;
                case 48:
                    i9 = (int) instanceCount;
                    continue;
                    i5++;
                    i7 = 31184;
                default:
                    i5++;
                    i7 = 31184;
            }
            i6 += i5;
            i5++;
            i7 = 31184;
        }
        vMeth_check_sum += ((((((((((i2 + i) + i4) + i6) + i5) + i7) + 31184) + i8) + i9) + Double.doubleToLongBits(d)) - 126) + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(int i, int i2, int i3) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        int[] iArr2 = new int[N];
        FuzzerUtils.init(iArr, 137);
        FuzzerUtils.init(iArr2, 10);
        int i4 = i2;
        int i5 = -2;
        int i6 = -56755;
        short s = 17743;
        int i7 = 3;
        while (i7 < 360) {
            int abs = (int) Math.abs(i3 + instanceCount);
            iFld = abs;
            vMeth();
            int i8 = 1;
            do {
                s = (short) (s - 56);
                i8++;
            } while (i8 < 5);
            int i9 = (int) (abs + (((i7 * fFld) + ((float) instanceCount)) - 2));
            i7++;
            i6 = 2;
            i5 = i8;
            i4 = i9;
        }
        int[] iArr3 = iArr[(i6 >>> 1) % N];
        int i10 = (i7 >>> 1) % N;
        iArr3[i10] = iArr3[i10] - byFld;
        int i11 = i4;
        int i12 = 0;
        int i13 = -7;
        for (int i14 = 0; i14 < 400; i14++) {
            int i15 = iArr2[i14];
            i13 = 1;
            while (i13 < 4) {
                i11 -= (int) dFld1;
                iArr2[i13] = iArr2[i13] - ((int) fFld);
                i13++;
                i12 = 1;
            }
        }
        long checkSum = ((((i + i11) + i3) + i7) - 88) + i5 + i6 + s + i13 + 63264 + i12 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(iArr2);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public static boolean bMeth(int i, int i2) {
        int i3;
        int[] iArr = new int[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        long[] jArr2 = new long[N];
        FuzzerUtils.init(iArr, -191);
        FuzzerUtils.init(jArr, -2006617079L);
        FuzzerUtils.init(jArr2, 1644995907L);
        int i4 = (i2 >>> 1) % N;
        iArr[i4] = iArr[i4] & 36213;
        int i5 = -94;
        long j = -37580;
        if (bFld) {
            int i6 = iFld;
            i = (int) (iMeth(i6, i6, 49048) - 149430473);
            i3 = 9;
            while (195 > i3) {
                long[] jArr3 = jArr[i3 - 1];
                int i7 = i3 + 1;
                jArr3[i7] = jArr3[i7] - (-15871);
                long j2 = 1;
                do {
                    j2++;
                } while (j2 < 9);
                j = j2;
                i3 = i7;
                i5 = 1;
            }
        } else {
            if (bFld) {
                bFld = bFld;
            }
            i3 = -7;
        }
        long checkSum = ((((((i + i2) + i3) + 58) + j) + i5) - 9) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(jArr2);
        bMeth_check_sum += checkSum;
        return checkSum % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        long[][][] jArr;
        double d;
        int i;
        int i2;
        int[] iArr = new int[N];
        long[][][] jArr2 = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr2, (Object) (-2L));
        FuzzerUtils.init(iArr, 77);
        byte[] bArr = byArrFld;
        int i3 = iFld;
        bArr[82] = (byte) i3;
        long j = instanceCount;
        double d2 = this.dFld;
        double d3 = j;
        Double.isNaN(d3);
        long[] jArr3 = jArr2[69][(i3 >>> 1) % N];
        int[] iArr2 = iArr;
        long j2 = jArr3[324] - i3;
        jArr3[324] = j2;
        instanceCount = j + (i3 - (((long) (d2 + d3)) >> ((int) j2)));
        int i4 = -193;
        float f = 29.446f;
        double d4 = -1.126296d;
        int i5 = 10;
        int i6 = 3;
        while (208 > i5) {
            if (!bMeth(iFld, i5)) {
                f = 4.0f;
                while (f < 127.0f) {
                    i4 = 1;
                    while (2 > i4 && !bFld) {
                        i4++;
                    }
                    f += 1.0f;
                }
                int i7 = i6 + ((int) instanceCount);
                i6 = i7 + i7;
                fFld += i5 - iFld;
                d4 = 6.0d;
                while (d4 < 127.0d) {
                    int i8 = iFld;
                    double d5 = instanceCount;
                    Double.isNaN(d5);
                    iFld = i8 + ((int) (d5 * d4));
                    fFld += i6;
                    d4 += 1.0d;
                }
                long j3 = instanceCount % (-111);
                instanceCount = j3;
                instanceCount = j3 + i5;
            }
            i5++;
        }
        int i9 = 6;
        int i10 = 14;
        int i11 = -143;
        int i12 = -17035;
        int i13 = -229;
        int i14 = 115;
        while (true) {
            int i15 = -10674;
            if (i9 < 214) {
                i12 = 121;
                while (7 < i12) {
                    int i16 = 3;
                    while (true) {
                        float f2 = fFld - i15;
                        fFld = f2;
                        int i17 = i12 - 1;
                        long[] jArr4 = jArr2[i12][i17];
                        jArr = jArr2;
                        long j4 = instanceCount;
                        jArr4[i16] = j4;
                        d = d4;
                        i = i12;
                        i13 = (int) (i13 + (((i16 * (-112)) + i16) - j4));
                        iArr2[i17] = iArr2[i17] - i4;
                        i2 = i4 * (-112);
                        int i18 = (i9 % 2) + 107;
                        if (i18 == 107) {
                            int[] int1array = FuzzerUtils.int1array(N, 43629);
                            double[] dArr = dArrFld;
                            double d6 = dArr[i17];
                            double d7 = i2;
                            Double.isNaN(d7);
                            dArr[i17] = d6 + d7;
                            iFld += i16 | i2;
                            iArr2 = int1array;
                            i10 = i2;
                        } else if (i18 == 108) {
                            i6 <<= 60;
                        } else {
                            fFld = f2 + ((float) j4);
                        }
                        i16--;
                        if (i16 <= 0) {
                            break;
                        }
                        i12 = i;
                        jArr2 = jArr;
                        d4 = d;
                        i15 = -10674;
                    }
                    i12 = i - 2;
                    i14 = i16;
                    jArr2 = jArr;
                    i15 = -10674;
                    i11 = i2;
                    d4 = d;
                }
                i9++;
            } else {
                FuzzerUtils.out.println("i i1 f = " + i5 + "," + i6 + "," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("i26 i27 i28 = 23," + i4 + "," + i10);
                FuzzerUtils.out.println("d1 i29 i30 = " + Double.doubleToLongBits(d4) + ",-112," + i9);
                FuzzerUtils.out.println("i31 i32 i33 = " + i11 + "," + i12 + "," + i13);
                FuzzerUtils.out.println("i34 s2 lArr = " + i14 + ",-10674," + FuzzerUtils.checkSum((Object[][]) jArr2));
                FuzzerUtils.out.println("iArr4 = " + FuzzerUtils.checkSum(iArr2));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
                FuzzerUtils.out.println("Test.fFld Test.byFld Test.dFld1 = " + Float.floatToIntBits(fFld) + "," + ((int) byFld) + "," + Double.doubleToLongBits(dFld1));
                FuzzerUtils.out.println("Test.bFld Test.byArrFld Test.dArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(byArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
                FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
