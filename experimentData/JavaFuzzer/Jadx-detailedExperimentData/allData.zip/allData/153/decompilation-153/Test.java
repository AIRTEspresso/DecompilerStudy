/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/153/original-153/Test.dex */
public class Test {
    public static volatile long instanceCount = 6951135113443121899L;
    public static float fFld = -1.63f;
    public static double dFld = 26.112492d;
    public static boolean bFld = true;
    public static final int N = 400;
    public static volatile long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        FuzzerUtils.init(lArrFld, -29681L);
    }

    public static void vMeth1(int i, int i2) {
        int i3;
        int i4;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 39179);
        int i5 = i2 * i2;
        int i6 = -52;
        int i7 = 15;
        float f = -55.706f;
        long j = -29882;
        int i8 = 178;
        int i9 = 1;
        while (true) {
            iArr[i9] = iArr[i9] - ((int) f);
            double d = 1.0d;
            while (true) {
                i3 = i6;
                if (d >= 8.0d) {
                    break;
                }
                int i10 = i9 + 1;
                iArr[i10] = (int) d;
                int i11 = i9 - 1;
                iArr[i11] = iArr[i11] + ((int) instanceCount);
                long j2 = (long) d;
                float f2 = f;
                long j3 = j2;
                int i12 = i7;
                int i13 = i3;
                while (j3 < 2) {
                    instanceCount -= j2;
                    f2 -= (float) d;
                    try {
                        i13 = 198 % iArr[i10];
                        i4 = i8 / i8;
                        try {
                            i13 = 80 / i12;
                        } catch (ArithmeticException e) {
                        }
                    } catch (ArithmeticException e2) {
                        i4 = i8;
                    }
                    i12 = (int) 0;
                    j3++;
                    i5 = i8;
                    i8 = i4;
                }
                d += 1.0d;
                i6 = i13;
                i7 = i12;
                f = f2;
                j = j3;
            }
            i9++;
            if (i9 < 208) {
                i6 = i3;
            } else {
                vMeth1_check_sum += i8 + i5 + 1 + i9 + Float.floatToIntBits(f) + Double.doubleToLongBits(d) + i3 + j + i7 + 0 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static void vMeth(double d, byte b) {
        int i = -13;
        vMeth1(-13, -13);
        int i2 = -4;
        int i3 = -10;
        int i4 = 9;
        while (i4 < 184) {
            fFld -= i4;
            i3 = 9;
            do {
                i2 += (int) instanceCount;
                i3--;
            } while (i3 > 0);
            int i5 = (int) (i + (((i4 * i3) + instanceCount) - instanceCount));
            i = i5 | i5;
            instanceCount = instanceCount;
            i2 += ((i4 * i4) + i3) - i;
            i4++;
        }
        long j = i3;
        instanceCount -= j;
        vMeth_check_sum += Double.doubleToLongBits(d) + b + i + i4 + i2 + j + 0 + ((int) d) + 27020 + 27020;
    }

    public int iMeth(int i, float f, int i2) {
        int i3 = 10;
        while (i3 < 174) {
            vMeth(dFld, (byte) 39);
            double d = dFld;
            double d2 = 4;
            Double.isNaN(d2);
            dFld = d - d2;
            i3++;
        }
        long floatToIntBits = ((((((((i + Float.floatToIntBits(f)) + i2) + i3) + 4) + 39) - 8) - 5) - 31319) + 4 + 0;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        double d;
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 20056);
        FuzzerUtils.init(sArr, (short) 13116);
        FuzzerUtils.init(jArr, 61L);
        int i = 34913;
        int i2 = 129;
        int i3 = 9;
        int i4 = -3;
        int i5 = -5;
        short s = 19104;
        byte b = -82;
        int i6 = 15;
        while (i6 < 392) {
            int i7 = iArr[i6] + 1;
            iArr[i6] = i7;
            double iMeth = iMeth(i, 2.6f, i);
            double d2 = dFld;
            Double.isNaN(iMeth);
            Double.isNaN(i7);
            s = (short) (s - ((short) (d + (iMeth * d2))));
            if (!bFld) {
                int i8 = i - 147;
                int i9 = i6;
                while (i9 < 67) {
                    int i10 = ((i9 % 2) * 5) + 17;
                    if (i10 == 18) {
                        iArr[i6] = (int) instanceCount;
                        instanceCount -= 14;
                        b = (byte) (b + ((byte) i9));
                        i3 = i3;
                        i4 = 1;
                    } else if (i10 == 26) {
                        int i11 = i3;
                        lArrFld = jArr;
                        try {
                            int i12 = i9 % i8;
                            i8 = i6 % 14;
                            i3 = i6 / iArr[i9 - 1];
                        } catch (ArithmeticException e) {
                            i3 = i11;
                        }
                        i5 = 1;
                    } else {
                        instanceCount += (i9 * i9) - 230;
                        i8 ^= 14;
                        i3 = i3;
                    }
                    i9++;
                }
                i = (i8 - 26551) >> 14;
                i2 = i9;
                i3 = i3;
            }
            i6++;
        }
        FuzzerUtils.out.println("i i1 s = " + i6 + "," + i + "," + ((int) s));
        FuzzerUtils.out.println("i20 i21 by2 = " + i2 + "," + i3 + "," + ((int) b));
        FuzzerUtils.out.println("i22 i23 i24 = " + i4 + ",14," + i5);
        FuzzerUtils.out.println("i25 iArr sArr = 17884," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(sArr));
        FuzzerUtils.out.println("lArr = " + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.bFld Test.lArrFld = " + (bFld ? 1 : 0) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
