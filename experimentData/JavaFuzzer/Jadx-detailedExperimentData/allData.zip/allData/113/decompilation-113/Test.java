
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/113/original-113/Test.dex */
public class Test {
    public static final int N = 400;
    public static double[][] dArrFld;
    public static long instanceCount = 827199520796677453L;
    public static int iFld = -56638;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        dArrFld = dArr;
        FuzzerUtils.init(dArr, -49.68167d);
    }

    public static void vMeth1(int i, float f, boolean z) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -225);
        FuzzerUtils.init(fArr, -22.102f);
        int i2 = -175;
        int i3 = 222;
        int i4 = 44;
        int i5 = 1;
        while (true) {
            i5++;
            if (i5 < 350) {
                int i6 = (i5 % 2) + 45;
                if (i6 == 45) {
                    iFld += i;
                    try {
                        int i7 = i5 % 4694;
                        iFld = i7;
                        i = i5 / i5;
                        iArr[i5 + 1] = i7 / i;
                    } catch (ArithmeticException e) {
                    }
                } else if (i6 != 46) {
                }
                if (z) {
                    fArr[i5 - 1] = i;
                } else {
                    switch ((i5 % 3) + 10) {
                        case 10:
                        case 11:
                            i2 = i5;
                            while (i2 < 5) {
                                long j = instanceCount;
                                int i8 = iFld;
                                instanceCount = j + (((i2 * i8) + i3) - i8);
                                int i9 = i5 % 1;
                                iFld = i8 - i2;
                                i2++;
                                i4 = 2;
                            }
                            iArr[i5] = iArr[i5] * i3;
                            break;
                        case 12:
                            iArr[i5] = iArr[i5] * i3;
                            break;
                        default:
                            i3 += i3;
                            break;
                    }
                }
            } else {
                vMeth1_check_sum += i + Float.floatToIntBits(f) + (z ? 1 : 0) + i5 + i2 + i3 + i4 + Double.doubleToLongBits(-1.58659d) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
                return;
            }
        }
    }

    public static void vMeth(int i) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 74L);
        short s = (short) 18469;
        double d = s;
        int i2 = 4;
        int i3 = -9;
        int i4 = 140;
        float f = -9.649f;
        int i5 = 121;
        int i6 = i;
        while (i5 > 7) {
            vMeth1(i6, 0.676f, true);
            long[] jArr2 = jArr;
            short s2 = s;
            i6 = (int) (i6 + (f ^ i5));
            switch ((i5 % 4) + 12) {
                case 12:
                    double d2 = i3;
                    Double.isNaN(d2);
                    d += d2;
                    i3 += i5;
                    break;
                case 13:
                    f -= 5.0f;
                    break;
                case 14:
                    instanceCount = 13L;
                    int i7 = 1;
                    do {
                        i7++;
                    } while (i7 < 14);
                    i4 = i7;
                    i2 = 1;
                    break;
                case 15:
                    instanceCount += iFld * i5;
                    break;
            }
            i5--;
            jArr = jArr2;
            s = s2;
        }
        vMeth_check_sum += (((((((((i6 + Double.doubleToLongBits(d)) + s) + i5) + i3) + 1) + Float.floatToIntBits(f)) + i4) + i2) - 144) + FuzzerUtils.checkSum(jArr);
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -8L);
        FuzzerUtils.init(iArr, 146);
        vMeth(iFld);
        dArrFld = dArrFld;
        long doubleToLongBits = (Double.doubleToLongBits(10.0d) - 184) + 1 + Float.floatToIntBits(0.816f) + 2 + 14778 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -63462);
        iArr[329] = iArr[329] ^ iMeth();
        FuzzerUtils.out.println("i iArr = -238," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.dArrFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
