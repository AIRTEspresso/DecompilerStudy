
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/15/original-15/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 34275;
    public static float fFld = -56.119f;
    public static long lFld = 2012182374;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    public static void vMeth2(int i, int i2, float f) {
        int i3;
        int[] iArr = new int[N];
        FuzzerUtils.init((long[][]) Array.newInstance(long.class, N, N), -66L);
        FuzzerUtils.init(iArr, 7);
        int i4 = 373;
        while (true) {
            i3 = 3923;
            if (i4 <= 18) {
                break;
            }
            instanceCount = 3923;
            i4 -= 3;
        }
        long[][] long2array = FuzzerUtils.long2array(N, 2863929807L);
        long[] jArr = long2array[8];
        int i5 = (i4 >>> 1) % N;
        jArr[i5] = jArr[i5] | instanceCount;
        int i6 = 1;
        do {
            i3 += (int) fFld;
            i6++;
        } while (i6 < 360);
        float f2 = (float) instanceCount;
        double d = -2.18765d;
        int i7 = i6;
        long j = 1;
        while (j < 221) {
            double d2 = 2;
            Double.isNaN(d2);
            d *= d2;
            i7 = (i7 * ((int) f2)) >> i;
            int i8 = (int) j;
            iArr[i8] = iArr[i8] * 1816082270;
            j++;
        }
        vMeth2_check_sum += i + (i7 % 12210) + Float.floatToIntBits(f2) + i4 + i3 + i6 + j + 2 + Double.doubleToLongBits(d) + 1 + FuzzerUtils.checkSum(long2array) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth1() {
        long j = 6;
        int i = (int) (j + 12 + instanceCount + j);
        vMeth2(-3, -30, fFld);
        vMeth1_check_sum += i;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static void vMeth(int i, short s) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 5);
        int i2 = -3;
        int i3 = -154;
        int i4 = 69;
        int i5 = 248;
        double d = -112.3736d;
        byte b = -18;
        int i6 = 291;
        while (i6 > 10) {
            long j = instanceCount + i2;
            instanceCount = j;
            int i7 = i6 - 1;
            int i8 = iArr[i7];
            iArr[i7] = i8 + 1;
            double d2 = i8;
            float f = fFld + 1.0f;
            fFld = f;
            double d3 = f;
            instanceCount = j + 1;
            double d4 = j | 1;
            Double.isNaN(d4);
            Double.isNaN(d3);
            Double.isNaN(d2);
            i2 = (int) (d2 + (d3 - ((-15.49521d) % d4)));
            d = 11.0d;
            while (d > 1.0d) {
                i3 += (int) (d * d);
                long j2 = instanceCount;
                byte b2 = b;
                int i9 = i6;
                switch (((((int) ((-j2) * (-77))) >>> 1) % 10) + 90) {
                    case 90:
                        i3++;
                        vMeth1();
                        lFld = i3;
                        b = b2;
                        break;
                    case 91:
                        fFld = i;
                        b = b2;
                        break;
                    case 92:
                        b = b2;
                        i4 = 1;
                        while (i4 < 2) {
                            b = (byte) (b + ((byte) i4));
                            int i10 = i4;
                            i4++;
                            i3 = i10;
                        }
                        break;
                    case 93:
                        i3 += (int) j2;
                        b = b2;
                        break;
                    case 94:
                        i2 <<= i5;
                        b = b2;
                        break;
                    case 95:
                        lFld += (long) d;
                        b = b2;
                        break;
                    case 96:
                        i3 = -173;
                        b = b2;
                        break;
                    case 97:
                        i3 = 3182;
                        i5 += (int) d;
                        b = b2;
                        break;
                    case 98:
                        i5 += (int) d;
                        b = b2;
                        break;
                    case 99:
                        b = b2;
                        break;
                    default:
                        i5 = i;
                        b = b2;
                        break;
                }
                d -= 1.0d;
                i6 = i9;
            }
            i6 -= 2;
        }
        vMeth_check_sum += i + s + i6 + 3 + i2 + Double.doubleToLongBits(d) + i3 + i4 + i5 + b + 0 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        short s;
        int i2;
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, -24385);
        float reverseBytes = ((float) Long.reverseBytes(54588)) * 0.175f;
        int i3 = -54588;
        vMeth(-54588, (short) -9733);
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 >= 316) {
                break;
            }
            fFld -= -54588;
        }
        short s2 = (short) ((-8487) + ((short) (-54588)));
        instanceCount = i4;
        int i5 = -4;
        int i6 = -7;
        int i7 = -199;
        int i8 = 11;
        double d = -68.91371d;
        int i9 = 1;
        while (true) {
            double d2 = d;
            int i10 = i9;
            int i11 = i8;
            int i12 = i7;
            int i13 = i6;
            int i14 = i5;
            int i15 = i3 + i9;
            float f = reverseBytes;
            while (i10 < 481) {
                try {
                    switch ((i9 % 7) + 53) {
                        case 53:
                        case 54:
                            i = i4;
                            s = s2;
                            instanceCount %= i9 | 1;
                            break;
                        case 55:
                            i = i4;
                            try {
                                i15 = 0 >>> ((int) lFld);
                                i13 = 1;
                                i15 += i10 * i10;
                            } catch (ArrayIndexOutOfBoundsException e) {
                                s = s2;
                                i2 = 1;
                                i15 = 0;
                                iArr[5] = iArr[366];
                                i13 = i2;
                                FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(f) + "," + i15 + ",-9733");
                                FuzzerUtils.out.println("i15 s2 i16 = " + i + "," + ((int) s) + "," + i9);
                                FuzzerUtils.out.println("i17 i18 d2 = " + i10 + "," + i14 + "," + Double.doubleToLongBits(2.25882d));
                                FuzzerUtils.out.println("i19 i20 d3 = " + i13 + "," + i12 + "," + Double.doubleToLongBits(d2));
                                FuzzerUtils.out.println("i21 iArr2 = " + i11 + "," + FuzzerUtils.checkSum(iArr));
                                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
                                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                                return;
                            }
                            try {
                                iArr[i9 - 1][i9] = i15;
                                iArr[i10] = iArr[i10 - 1];
                                s = s2;
                                break;
                            } catch (ArrayIndexOutOfBoundsException e2) {
                                s = s2;
                                i2 = i13;
                                iArr[5] = iArr[366];
                                i13 = i2;
                                FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(f) + "," + i15 + ",-9733");
                                FuzzerUtils.out.println("i15 s2 i16 = " + i + "," + ((int) s) + "," + i9);
                                FuzzerUtils.out.println("i17 i18 d2 = " + i10 + "," + i14 + "," + Double.doubleToLongBits(2.25882d));
                                FuzzerUtils.out.println("i19 i20 d3 = " + i13 + "," + i12 + "," + Double.doubleToLongBits(d2));
                                FuzzerUtils.out.println("i21 iArr2 = " + i11 + "," + FuzzerUtils.checkSum(iArr));
                                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
                                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                                return;
                            }
                        case 56:
                            i = i4;
                            i15 += i10 * i10;
                            iArr[i9 - 1][i9] = i15;
                            iArr[i10] = iArr[i10 - 1];
                            s = s2;
                            break;
                        case 57:
                            double d3 = 1.0d;
                            while (d3 < 401.0d) {
                                d3 += 1.0d;
                                i11 = i9;
                            }
                            f -= 5.0f;
                            d2 = d3;
                        case 58:
                            f *= -2.0f;
                        case 59:
                            try {
                                i = i4;
                                try {
                                    instanceCount += i15;
                                    i12 -= i11;
                                    s = s2;
                                    i14 = i10;
                                    break;
                                } catch (ArrayIndexOutOfBoundsException e3) {
                                    s = s2;
                                    i2 = i13;
                                    i14 = i10;
                                    iArr[5] = iArr[366];
                                    i13 = i2;
                                    FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(f) + "," + i15 + ",-9733");
                                    FuzzerUtils.out.println("i15 s2 i16 = " + i + "," + ((int) s) + "," + i9);
                                    FuzzerUtils.out.println("i17 i18 d2 = " + i10 + "," + i14 + "," + Double.doubleToLongBits(2.25882d));
                                    FuzzerUtils.out.println("i19 i20 d3 = " + i13 + "," + i12 + "," + Double.doubleToLongBits(d2));
                                    FuzzerUtils.out.println("i21 iArr2 = " + i11 + "," + FuzzerUtils.checkSum(iArr));
                                    FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
                                    FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                                    FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                                    FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                                    return;
                                }
                            } catch (ArrayIndexOutOfBoundsException e4) {
                                i = i4;
                            }
                        default:
                            i = i4;
                            s = s2;
                            try {
                                lFld -= 39;
                                break;
                            } catch (ArrayIndexOutOfBoundsException e5) {
                                i2 = i13;
                                iArr[5] = iArr[366];
                                i13 = i2;
                                FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(f) + "," + i15 + ",-9733");
                                FuzzerUtils.out.println("i15 s2 i16 = " + i + "," + ((int) s) + "," + i9);
                                FuzzerUtils.out.println("i17 i18 d2 = " + i10 + "," + i14 + "," + Double.doubleToLongBits(2.25882d));
                                FuzzerUtils.out.println("i19 i20 d3 = " + i13 + "," + i12 + "," + Double.doubleToLongBits(d2));
                                FuzzerUtils.out.println("i21 iArr2 = " + i11 + "," + FuzzerUtils.checkSum(iArr));
                                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
                                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                                return;
                            }
                    }
                    instanceCount -= lFld;
                    i10++;
                    s2 = s;
                    i4 = i;
                } catch (ArrayIndexOutOfBoundsException e6) {
                    i = i4;
                }
            }
            i = i4;
            s = s2;
            i9++;
            if (i9 < 311) {
                s2 = s;
                i4 = i;
                reverseBytes = f;
                i3 = i15;
                i5 = i14;
                i6 = i13;
                i7 = i12;
                i8 = i11;
                d = d2;
            } else {
                FuzzerUtils.out.println("f i s1 = " + Float.floatToIntBits(f) + "," + i15 + ",-9733");
                FuzzerUtils.out.println("i15 s2 i16 = " + i + "," + ((int) s) + "," + i9);
                FuzzerUtils.out.println("i17 i18 d2 = " + i10 + "," + i14 + "," + Double.doubleToLongBits(2.25882d));
                FuzzerUtils.out.println("i19 i20 d3 = " + i13 + "," + i12 + "," + Double.doubleToLongBits(d2));
                FuzzerUtils.out.println("i21 iArr2 = " + i11 + "," + FuzzerUtils.checkSum(iArr));
                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + lFld);
                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
