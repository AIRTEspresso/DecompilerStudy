public class Test {
    int N = 400;
    long instanceCount = 6410838818528573617L;
    int iFld;
        void vMeth1(){
        iFld =(int)instanceCount;
    }
    void vMeth(int i3 , int i4 , float f2){
        int i11 , i13;
        vMeth1();
        for(i11 = 11; 327 > i11; i11 ++)
            for(i13 = 1; i13 < 5; i13 ++)switch(i11 % 2){
                case 56 : instanceCount -= 0;
                case 58 : instanceCount += i11;
            }
    }
    boolean bMeth(int i){
        float f1;
        i =(int)instanceCount;
        f1 = 1;
        while(++ f1 < 391)vMeth(98 , i , f1);
        instanceCount = - 4982;
        long meth_res = i + Float.floatToIntBits(f1);
        return meth_res > 0;
    }
    void mainTest(String[]strArr1){
        float f;
        int i19 , i21 , i23 , iArr1[]= new int[N], iArr2[]= new int[N];
        byte by1 = 96;
        boolean bArr[]= new boolean[N];
        init(bArr , false);
        init(iArr1 , -40735);
        init(iArr2 , 41);
        f = 311;
        while((f -= 3)> 0)bArr[(int)f]= bMeth(iFld);
               System.out.println("iFld = " + iFld);
        System.out.println("instanceCount = " + instanceCount);
        instanceCount=-4982;
        for(i19 = 21; i19 < 363; i19 ++){
            instanceCount += - 27196;
            instanceCount &= 32499;
            for(i21 = 2; i21 < 74; i21 ++){
                i23 = 1;
                instanceCount += i23 - by1;
                iFld >>>= i19;

                iArr2[i19]=(int)instanceCount;
                instanceCount -= iFld;
                iArr2[i19]-= 9;
                iFld |= instanceCount;
            }
        }
        System.out.println("iArr2 = " + checkSum(iArr2));
    }
    public static void main(String[]strArr){
        Test _instance = new Test();
        _instance.mainTest(strArr);
    }
    void init(boolean[]a , boolean seed){
        for(int j = 0; j < a.length; j ++)a[j]= j % 2 == 0 ? seed : j % 3 == 0;
    }
    void init(int[]a , int seed){
        for(int j = 0; j < a.length; j ++)a[j]= j % 2 == 0 ? seed + j : seed - j;
    }
    long checkSum(boolean[]a){
        long sum = 0;
        for(int j = 0; j < a.length; j ++)sum += a[j]? j + 1 : 0;
        return sum;
    }
    long checkSum(int[]a){
        long sum = 0;
        for(int j = 0; j < a.length; j ++)sum += a[j]/(j + 1)+ a[j]%(j + 1);
        return sum;
    }
}

