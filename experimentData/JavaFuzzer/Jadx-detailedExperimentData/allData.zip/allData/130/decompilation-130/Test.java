
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/130/original-130/Test.dex */
public class Test {
    public boolean bFld = false;
    public int iFld1 = 391;
    public static long instanceCount = 31092;
    public static float fFld = 2.355f;
    public static int iFld = -14;
    public static double dFld = 0.9752d;
    public static short sFld = 3781;
    public static final int N = 400;
    public static double[] dArrFld = new double[N];
    public static volatile float[] fArrFld = new float[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        FuzzerUtils.init(dArrFld, 1.37436d);
        FuzzerUtils.init(fArrFld, -87.315f);
    }

    public static void vMeth2(long j, byte b) {
        int i = 2;
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, 99);
        long j2 = j;
        int i2 = 37992;
        int i3 = -7;
        int i4 = 254;
        float f = -2.32f;
        int i5 = 8;
        while (197 > i5) {
            i3 = 8;
            while (i3 > 1) {
                i3--;
            }
            f += i5;
            i4 = 19178 - ((int) f);
            j2 = (j2 + (i5 ^ f)) * i3;
            i5++;
            i2 = 11932;
        }
        while (i < 304) {
            int[] iArr2 = iArr[i];
            iArr2[i] = iArr2[i] + 4;
            instanceCount += i ^ i3;
            i2 -= i2;
            i++;
        }
        vMeth2_check_sum += j2 + b + i5 + i2 + i3 + i4 + Float.floatToIntBits(f) + 11932 + i + 4 + FuzzerUtils.checkSum(iArr);
    }

    public void vMeth1(float f) {
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 0L);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-13));
        vMeth2(instanceCount, (byte) 113);
        instanceCount -= 9;
        int i = 53410;
        int i2 = -118;
        int i3 = -5944;
        int i4 = 12;
        while (i4 < 244) {
            i += i4 - i;
            if (!this.bFld) {
                instanceCount = i;
                i2 = i4;
                while (i2 < 7) {
                    try {
                        i3 = 139 / (i2 % i3);
                        iArr[i2][i4 - 1][i4 + 1] = i3 / (-21);
                    } catch (ArithmeticException e) {
                    }
                    iArr[i4][i4] = FuzzerUtils.int1array(N, 9);
                    jArr[i4] = jArr[i4] + i4;
                    if (this.bFld) {
                        i3 = 1;
                    } else {
                        i += (int) (-1.10406d);
                    }
                    i2++;
                }
            }
            i4++;
        }
        vMeth1_check_sum += Float.floatToIntBits(f) + i4 + i + i2 + i3 + 60 + Double.doubleToLongBits(-1.10406d) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum((Object[][]) iArr);
    }

    public void vMeth(int i) {
        int i2 = N;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -4);
        vMeth1(fFld);
        long j = instanceCount + i;
        instanceCount = j;
        int i3 = i / (i | 1);
        iFld = (int) j;
        int i4 = -1;
        int i5 = 54;
        int i6 = 37188;
        int i7 = 2;
        while (149 > i7) {
            float[] fArr = fArrFld;
            fArr[i7] = fArr[i7] - iFld;
            int[] iArr2 = iArr;
            int i8 = 11;
            while (i8 > 1) {
                int i9 = i7 - 1;
                iArr2[i9] = iArr2[i9] - (-34288);
                iArr2 = FuzzerUtils.int1array(i2, -12);
                i8--;
            }
            int i10 = 1;
            while (true) {
                double d = dFld;
                double d2 = -3;
                Double.isNaN(d2);
                dFld = d + d2;
                i10++;
                if (i10 >= 11) {
                    break;
                }
            }
            i5 += i5;
            fFld -= i8;
            i7++;
            i4 = i10;
            iArr = iArr2;
            i6 = i8;
            i2 = N;
        }
        vMeth_check_sum += ((((i3 + i7) + (i5 + sFld)) + i6) - 3) + i4 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(bArr, (byte) 14);
        FuzzerUtils.init(iArr, -55);
        int i = 1;
        FuzzerUtils.init(zArr, true);
        int i2 = -((-Math.max(33, 33)) * 33);
        int i3 = -45;
        int i4 = -9;
        int i5 = 6;
        int i6 = 11;
        int i7 = -2;
        byte b = 70;
        int i8 = 1;
        while (true) {
            i8 += 2;
            if (i8 < 237) {
                vMeth(0);
                b = (byte) (b + ((byte) i2));
                i3 = 212;
                while (i < i3) {
                    i4 = (i4 - ((int) fFld)) + i3;
                    int i9 = (((i4 >>> 1) % 2) * 5) + 110;
                    if (i9 == 116) {
                        long j = i5 ^ instanceCount;
                        instanceCount = j;
                        instanceCount = j << iFld;
                        iFld = 52943;
                        iArr = iArr;
                        i2 = i5;
                    } else if (i9 == 119) {
                        int i10 = (i3 % 2) + 124;
                        if (i10 == 124) {
                            i5 += i3 * i3;
                            i6 = i3;
                            while (i6 < 2) {
                                int i11 = (i6 % 2) + 109;
                                if (i11 == 109) {
                                    int i12 = i6 - 1;
                                    bArr[i12] = (byte) (bArr[i12] * 13);
                                    b = (byte) (b + ((byte) i6));
                                    long j2 = instanceCount;
                                    instanceCount = j2 + j2;
                                } else if (i11 == 110) {
                                    b = (byte) (b - ((byte) 4));
                                    i7 = (i7 - 3) * i5;
                                } else {
                                    i5 -= i4;
                                    instanceCount -= 8;
                                }
                                i2 = (int) (i2 + (((i6 * i3) + 4) - fFld));
                                iArr = FuzzerUtils.int1array(N, 4639);
                                long j3 = instanceCount;
                                instanceCount = j3 - j3;
                                fFld -= i4;
                                this.iFld1 -= 114;
                                i6++;
                                i4 = i7;
                            }
                        } else if (i10 != 125) {
                        }
                        zArr[i8] = true;
                    } else {
                        long j4 = instanceCount;
                        instanceCount = j4 + j4;
                    }
                    i3--;
                    i = 1;
                }
                i = 1;
            } else {
                FuzzerUtils.out.println("i i1 by2 = " + i2 + "," + i8 + "," + ((int) b));
                FuzzerUtils.out.println("i18 i19 i20 = " + i3 + "," + i4 + "," + i5);
                FuzzerUtils.out.println("i21 i22 i23 = 4," + i6 + "," + i7);
                FuzzerUtils.out.println("byArr iArr3 bArr = " + FuzzerUtils.checkSum(bArr) + "," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(zArr));
                FuzzerUtils.out.println("Test.instanceCount bFld Test.fFld = " + instanceCount + "," + (this.bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
                FuzzerUtils.out.println("Test.iFld Test.dFld Test.sFld = " + iFld + "," + Double.doubleToLongBits(dFld) + "," + ((int) sFld));
                FuzzerUtils.out.println("iFld1 Test.dArrFld Test.fArrFld = " + this.iFld1 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
