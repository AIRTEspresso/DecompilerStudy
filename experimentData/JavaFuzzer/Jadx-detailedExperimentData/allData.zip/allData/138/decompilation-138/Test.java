
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/138/original-138/Test.dex */
public class Test {
    public static final int N = 400;
    public static byte[] byArrFld;
    public int iFld = -244;
    public short sFld = 32045;
    public static long instanceCount = -27;
    public static float fFld = 88.972f;
    public static boolean bFld = false;
    public static long fMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        byte[] bArr = new byte[N];
        byArrFld = bArr;
        FuzzerUtils.init(bArr, (byte) 20);
    }

    public static void vMeth() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -55);
        iArr[80] = 161;
        int i = -168;
        int i2 = 27239;
        short s = -24569;
        int i3 = 4;
        while (i3 < 129) {
            fFld *= 10.0f;
            i = 37;
            while (i > 2) {
                s = (short) (s + 24015);
                i--;
                i2 = 2;
            }
            i3 += 3;
        }
        vMeth_check_sum += ((161 + i3) - 32838) + i + 6 + i2 + s + Double.doubleToLongBits(2.99229d) + 0 + 0 + 27002 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(long j, int i) {
        int[] iArr = new int[N];
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        FuzzerUtils.init(iArr, 196);
        FuzzerUtils.init(dArr, -8.9381d);
        vMeth();
        byArrFld = byArrFld;
        int i2 = 1;
        int i3 = 21628;
        double d = -2.4667d;
        while (327 > i2) {
            float f = fFld;
            iArr[i2 + 1] = (int) f;
            double[] dArr2 = dArr[i2 - 1];
            dArr2[i2] = dArr2[i2] + 27891.0d;
            int i4 = (i % ((int) (f | 1))) + ((int) d);
            d = 17596.0d;
            fFld = f + i2;
            instanceCount += j;
            i2 += 3;
            i3 = i;
            i = i4;
        }
        int i5 = (i3 >>> 1) % N;
        iArr[i5] = iArr[i5] ^ 34668;
        long doubleToLongBits = (j - 61) + i2 + i3 + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static float fMeth(long j) {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 40504);
        int i2 = 174;
        iArr[87] = iArr[87] >> ((int) ((174 - Math.min(174, 13)) - (((float) (174 + instanceCount)) + (174 - (-1.278f)))));
        long j2 = j - 1;
        float f = ((float) j2) - 1.278f;
        int i3 = 1;
        while (true) {
            i3++;
            if (i3 >= 227) {
                break;
            }
            long j3 = instanceCount;
            long j4 = j3 - 1;
            instanceCount = j4;
            j2 <<= (int) (j3 + ((i2 - i3) - i));
            long j5 = j4 - 1;
            instanceCount = j5;
            int i4 = (int) j5;
            iMeth(j5, i4);
            i2 = (i4 % 3941) + (i3 * i3);
        }
        instanceCount = 1L;
        float f2 = 3.0f;
        int i5 = -14;
        while (f2 < 208.0f) {
            i5 = (int) instanceCount;
            f2 += 1.0f;
        }
        long j6 = i3;
        long floatToIntBits = j2 + j6 + Float.floatToIntBits(f) + j6 + 3940 + Float.floatToIntBits(f2) + (i5 - i3) + FuzzerUtils.checkSum(iArr);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        double d;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(jArr, -1L);
        FuzzerUtils.init(fArr, -90.698f);
        FuzzerUtils.init(iArr, -10);
        jArr[74] = jArr[74] * (((float) (Math.abs(this.iFld) + Math.min(instanceCount, -1279146865349914639L))) - ((this.iFld + 140) * fMeth(instanceCount)));
        int i = 64808;
        int i2 = 12;
        int i3 = -221;
        int i4 = 11;
        int i5 = -11;
        double d2 = 0.51427d;
        int i6 = 13;
        while (304 > i6) {
            d2 = 86.0d;
            while (d2 > 3.0d) {
                i3 = 2;
                while (i3 > d2) {
                    switch ((int) ((d2 % 10.0d) + 42.0d)) {
                        case 42:
                            d = d2;
                            int i7 = i3 - 1;
                            fArr[i7] = fArr[i7] - (-1.12304f);
                            byArrFld[(int) (d + 1.0d)] = (byte) i6;
                            i = i4;
                            break;
                        case 43:
                            d = d2;
                            long j = instanceCount;
                            instanceCount = j - j;
                            boolean z = bFld;
                            i = i4;
                            break;
                        case 44:
                            d = d2;
                            instanceCount <<= i3;
                            instanceCount = instanceCount;
                            i = i6;
                            break;
                        case 45:
                            d = d2;
                            instanceCount = instanceCount;
                            i = i6;
                            break;
                        case 46:
                            d = d2;
                            int i8 = ((i6 % 2) * 5) + 89;
                            if (i8 == 92) {
                                jArr[i3 + 1] = i6;
                                iArr[i6 + 1] = 13;
                                this.iFld = this.iFld;
                                i = i4;
                                i4 -= i2;
                                break;
                            } else if (i8 == 99) {
                                i5 -= 16890;
                                i2 = i4;
                                i4 -= (int) fFld;
                                i = -14;
                                break;
                            } else {
                                int i9 = i6 + 1;
                                iArr[i9] = iArr[i9] + i2;
                                int i10 = (int) instanceCount;
                                instanceCount = -10L;
                                if (!bFld) {
                                    i2 = i10;
                                    i = i4;
                                    break;
                                } else {
                                    long j2 = (-10) - (-10);
                                    instanceCount = j2;
                                    iArr[i6] = iArr[i6] * ((int) fFld);
                                    long j3 = j2 % (i6 | 1);
                                    instanceCount = j3;
                                    i2 = i10;
                                    i = i4;
                                    i4 = (int) j3;
                                    break;
                                }
                            }
                        case 47:
                            long j4 = instanceCount;
                            long j5 = i3;
                            d = d2;
                            instanceCount = j4 + (((j5 * j4) + i2) - j5);
                            i = i4;
                            break;
                        case 48:
                            fFld += i4;
                            d = d2;
                            i = i4;
                            break;
                        case 49:
                        case 50:
                            i = i4 - ((int) fFld);
                            d = d2;
                            break;
                        case 51:
                            this.iFld = this.sFld;
                            d = d2;
                            i = i4;
                            break;
                        default:
                            d = d2;
                            i = this.sFld * i4;
                            break;
                    }
                    i3--;
                    d2 = d;
                }
                d2 -= 1.0d;
            }
            i6++;
        }
        FuzzerUtils.out.println("i14 i15 d2 = " + i6 + "," + i + "," + Double.doubleToLongBits(d2));
        FuzzerUtils.out.println("i16 i17 i18 = " + i2 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i19 lArr fArr = " + i5 + "," + FuzzerUtils.checkSum(jArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("iArr3 = " + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld sFld Test.byArrFld = " + (bFld ? 1 : 0) + "," + ((int) this.sFld) + "," + FuzzerUtils.checkSum(byArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
