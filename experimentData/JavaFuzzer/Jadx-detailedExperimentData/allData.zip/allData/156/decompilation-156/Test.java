
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/156/original-156/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public double dFld = -1.11906d;
    public static long instanceCount = 58788;
    public static int iFld = 23969;
    public static long lMeth_check_sum = 0;
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, -173L);
    }

    public static void vMeth(double d, int i) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, 40743);
        int i2 = 203;
        while (i2 > 1) {
            long[] jArr = lArrFld;
            int i3 = i2 - 1;
            jArr[i3] = jArr[i3] / 2379255939094521235L;
            iArr[i2][i2 + 1] = (int) instanceCount;
            i2--;
        }
        double d2 = 3.0d;
        int i4 = -149;
        int i5 = -247;
        int i6 = 11;
        int i7 = 38;
        while (229.0d > d2) {
            iArr[(int) (d2 - 1.0d)] = iArr[(int) d2];
            i6 = 1;
            while (i6 < 7) {
                i5 <<= 14;
                i7 += i7;
                i6++;
            }
            long j = instanceCount - (-13);
            instanceCount = j;
            i7 *= i5;
            instanceCount = j << i7;
            d2 += 1.0d;
            i4 = i7;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + i + i2 + i4 + Double.doubleToLongBits(d2) + i5 + i6 + i7 + FuzzerUtils.checkSum(iArr);
    }

    public static float fMeth(float f, int i, int i2) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -14);
        int i3 = i2 - 1;
        float f2 = i3;
        int i4 = i3 + 1;
        float f3 = f2 + i4;
        int i5 = 292;
        do {
            vMeth(-1.128013d, 52466);
            i >>= i4;
            long j = instanceCount;
            instanceCount = j | j;
            i5 -= 2;
        } while (i5 > 0);
        int i6 = 48908;
        long j2 = 0;
        for (int i7 = 0; i7 < 400; i7++) {
            int i8 = iArr[i7];
            i6 = 4;
            while (i6 > 1) {
                int i9 = i4 + i6;
                long j3 = 1;
                while (true) {
                    j3++;
                    if (j3 < 4) {
                        i9 -= (int) j3;
                    }
                }
                i4 = i9 + 12;
                instanceCount = j3;
                long[] jArr = lArrFld;
                jArr[i6] = jArr[i6] + j3;
                i6 -= 3;
                j2 = j3;
            }
        }
        long floatToIntBits = (((((Float.floatToIntBits(f3) + i) + i4) + i5) + i6) - 122) + j2 + FuzzerUtils.checkSum(iArr);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public long lMeth(boolean z, long j, byte b) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -133);
        boolean z2 = z;
        long j2 = 164;
        int i = -2;
        int i2 = 44914;
        int i3 = 305;
        double d = -48.1605d;
        double d2 = -11.55899d;
        int i4 = -5;
        while (true) {
            i3 -= 3;
            float f = -42.821f;
            if (i3 > 0) {
                if (z2 != z2) {
                    long j3 = j2;
                    double d3 = d;
                    double d4 = 1.0d;
                    while (d4 < 15.0d) {
                        long j4 = j3 * i2;
                        double reverseBytes = Integer.reverseBytes((int) (42406 * j4));
                        Double.isNaN(reverseBytes);
                        double d5 = d3 - reverseBytes;
                        int i5 = (int) (-((i2 - i2) * (i2 - f)));
                        long j5 = instanceCount;
                        double d6 = j;
                        Double.isNaN(d6);
                        double d7 = i5;
                        Double.isNaN(d7);
                        double d8 = (d6 * d4) + d7;
                        double d9 = -42.821f;
                        Double.isNaN(d9);
                        long j6 = j5 + ((long) (d8 - d9));
                        instanceCount = j6;
                        int i6 = (int) (-(j6 | (i5 - 21103)));
                        int i7 = (int) d4;
                        iArr[i7] = iArr[i7] + ((int) ((-42.821f) + (i6 - i3) + i6));
                        i2 = i6;
                        d3 = d5;
                        i4 = 2;
                        int i8 = i;
                        boolean z3 = z2 ? 1 : 0;
                        Object[] objArr = z2 ? 1 : 0;
                        Object[] objArr2 = z2 ? 1 : 0;
                        Object[] objArr3 = z2 ? 1 : 0;
                        boolean z4 = z3;
                        int i9 = i8;
                        while (true) {
                            boolean z5 = true;
                            if (1 < i4) {
                                long[] jArr = lArrFld;
                                long j7 = jArr[i3] - 1;
                                jArr[i3] = j7;
                                int i10 = ((int) j7) * i9;
                                try {
                                    int i11 = i10 / i2;
                                    i10 = i3 / 211;
                                    i2 = i4 % i2;
                                } catch (ArithmeticException e) {
                                }
                                i9 = i10;
                                if (((i3 % 1) * 5) + 98 == 101) {
                                    d3 = lArrFld[(int) (d4 - 1.0d)];
                                    if (!z4 && !z4) {
                                        z5 = false;
                                    }
                                    z4 = z5;
                                }
                                i4 -= 2;
                            }
                        }
                        d4 += 1.0d;
                        j3 = j4;
                        f = -42.821f;
                        boolean z6 = z4;
                        i = (int) fMeth(-25.313f, i2, i3);
                        z2 = z6;
                    }
                    d2 = d4;
                    d = d3;
                    j2 = j3;
                }
            } else {
                long doubleToLongBits = (z2 ? 1L : 0L) + j + b + i3 + Double.doubleToLongBits(d2) + i2 + Double.doubleToLongBits(d) + j2 + Float.floatToIntBits(-42.821f) + i4 + i + FuzzerUtils.checkSum(iArr);
                lMeth_check_sum += doubleToLongBits;
                return doubleToLongBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(iArr, -209);
        FuzzerUtils.init(dArr, 1.48625d);
        iArr[41] = (int) (((float) lMeth(false, -96L, (byte) 38)) + 1.584f);
        iArr[41] = iArr[41] + 9880;
        int i = 6;
        int i2 = 6;
        int i3 = -1;
        int i4 = -14;
        int i5 = -3304;
        int i6 = -122;
        int i7 = -58655;
        int i8 = 178;
        short s = -29242;
        int i9 = 17;
        while (i9 < 318) {
            instanceCount = instanceCount;
            int i10 = 1;
            short s2 = s;
            int i11 = i8;
            int i12 = i7;
            int i13 = i6;
            int i14 = i5;
            int i15 = i4;
            int i16 = 1;
            while (i16 < 84) {
                i12 = 2;
                while (i12 > i10) {
                    int i17 = i9 - 1;
                    double d = dArr[i17];
                    double d2 = i11;
                    Double.isNaN(d2);
                    dArr[i17] = d - d2;
                    i12--;
                    i10 = 1;
                }
                short s3 = (short) instanceCount;
                long j = i16;
                instanceCount = j;
                i11 = i14 + 1;
                i13++;
                iArr[i9] = i13;
                int i18 = iFld;
                int i19 = ((int) j) >>> i18;
                i14 += i16 * i16;
                iFld = i18 * ((int) this.dFld);
                instanceCount = i13;
                int i20 = i16;
                while (i20 < 2) {
                    this.dFld = 53.0d;
                    int i21 = iFld * i19;
                    iFld = i21;
                    iFld = i21 + (i20 * i20);
                    instanceCount = 87;
                    i20++;
                    i13 = 3;
                }
                i16++;
                s2 = s3;
                i = 2;
                i10 = 1;
                int i22 = i20;
                i15 = i19;
                i2 = i22;
            }
            i9++;
            i3 = i16;
            i4 = i15;
            i5 = i14;
            i6 = i13;
            i7 = i12;
            i8 = i11;
            s = s2;
        }
        FuzzerUtils.out.println("i i17 i18 = " + i4 + "," + i9 + "," + i5);
        FuzzerUtils.out.println("i19 i20 i21 = " + i3 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("i22 i23 s = " + i8 + "," + i + "," + ((int) s));
        FuzzerUtils.out.println("i24 i25 by1 = " + i2 + ",3,87");
        FuzzerUtils.out.println("iArr dArr = " + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.lArrFld = " + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
