package defpackage;

import java.io.PrintStream;
import java.lang.reflect.Array;
import java.util.Random;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/strange_ones/156/reduced-156/tmp/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public double dFld = -1.11906d;
    public static long instanceCount = 58788;
    public static int iFld = 23969;
    public static long lMeth_check_sum = 0;
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static PrintStream out = System.out;
    public static Random random = new Random(1);
    public static long seed = 1;
    public static int UnknownZero = 0;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        init(jArr, -173L);
    }

    public static void vMeth(double d, int i) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        init(iArr, 40743);
        int i2 = 203;
        while (i2 > 1) {
            long[] jArr = lArrFld;
            int i3 = i2 - 1;
            jArr[i3] = jArr[i3] / 2379255939094521235L;
            iArr[i2][i2 + 1] = (int) instanceCount;
            i2--;
        }
        double d2 = 3.0d;
        int i4 = -149;
        int i5 = -247;
        int i6 = 11;
        int i7 = 38;
        while (229.0d > d2) {
            iArr[(int) (d2 - 1.0d)] = iArr[(int) d2];
            i6 = 1;
            while (i6 < 7) {
                i5 <<= 14;
                i7 += i7;
                i6++;
            }
            long j = instanceCount - (-13);
            instanceCount = j;
            i7 *= i5;
            instanceCount = j << i7;
            d2 += 1.0d;
            i4 = i7;
        }
        vMeth_check_sum += Double.doubleToLongBits(d) + i + i2 + i4 + Double.doubleToLongBits(d2) + i5 + i6 + i7 + checkSum(iArr);
    }

    public static float fMeth(float f, int i, int i2) {
        int[] iArr = new int[N];
        init(iArr, -14);
        int i3 = i2 - 1;
        float f2 = i3;
        int i4 = i3 + 1;
        float f3 = f2 + i4;
        int i5 = 292;
        do {
            vMeth(-1.128013d, 52466);
            i >>= i4;
            long j = instanceCount;
            instanceCount = j | j;
            i5 -= 2;
        } while (i5 > 0);
        int i6 = 48908;
        long j2 = 0;
        for (int i7 = 0; i7 < 400; i7++) {
            int i8 = iArr[i7];
            i6 = 4;
            while (i6 > 1) {
                int i9 = i4 + i6;
                long j3 = 1;
                while (true) {
                    j3++;
                    if (j3 < 4) {
                        i9 -= (int) j3;
                    }
                }
                i4 = i9 + 12;
                instanceCount = j3;
                long[] jArr = lArrFld;
                jArr[i6] = jArr[i6] + j3;
                i6 -= 3;
                j2 = j3;
            }
        }
        long floatToIntBits = (((((Float.floatToIntBits(f3) + i) + i4) + i5) + i6) - 122) + j2 + checkSum(iArr);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public long lMeth(boolean z, long j, byte b) {
        int[] iArr = new int[N];
        init(iArr, -133);
        boolean z2 = z;
        long j2 = 164;
        int i = -2;
        int i2 = 44914;
        int i3 = 305;
        double d = -48.1605d;
        double d2 = -11.55899d;
        int i4 = -5;
        while (true) {
            i3 -= 3;
            float f = -42.821f;
            if (i3 > 0) {
                if (z2 != z2) {
                    long j3 = j2;
                    double d3 = d;
                    double d4 = 1.0d;
                    while (d4 < 15.0d) {
                        long j4 = j3 * i2;
                        double reverseBytes = Integer.reverseBytes((int) (42406 * j4));
                        Double.isNaN(reverseBytes);
                        double d5 = d3 - reverseBytes;
                        int i5 = (int) (-((i2 - i2) * (i2 - f)));
                        long j5 = instanceCount;
                        double d6 = j;
                        Double.isNaN(d6);
                        double d7 = i5;
                        Double.isNaN(d7);
                        double d8 = (d6 * d4) + d7;
                        double d9 = -42.821f;
                        Double.isNaN(d9);
                        long j6 = j5 + ((long) (d8 - d9));
                        instanceCount = j6;
                        int i6 = (int) (-(j6 | (i5 - 21103)));
                        int i7 = (int) d4;
                        iArr[i7] = iArr[i7] + ((int) ((-42.821f) + (i6 - i3) + i6));
                        i2 = i6;
                        d3 = d5;
                        i4 = 2;
                        int i8 = i;
                        boolean z3 = z2 ? 1 : 0;
                        Object[] objArr = z2 ? 1 : 0;
                        Object[] objArr2 = z2 ? 1 : 0;
                        Object[] objArr3 = z2 ? 1 : 0;
                        boolean z4 = z3;
                        int i9 = i8;
                        while (true) {
                            boolean z5 = true;
                            if (1 < i4) {
                                long[] jArr = lArrFld;
                                long j7 = jArr[i3] - 1;
                                jArr[i3] = j7;
                                int i10 = ((int) j7) * i9;
                                try {
                                    int i11 = i10 / i2;
                                    i10 = i3 / 211;
                                    i2 = i4 % i2;
                                    i9 = i10;
                                } catch (ArithmeticException e) {
                                    i9 = i10;
                                }
                                if (((i3 % 1) * 5) + 98 == 101) {
                                    d3 = lArrFld[(int) (d4 - 1.0d)];
                                    if (!z4 && !z4) {
                                        z5 = false;
                                    }
                                    z4 = z5;
                                }
                                i4 -= 2;
                            }
                        }
                        d4 += 1.0d;
                        j3 = j4;
                        f = -42.821f;
                        boolean z6 = z4;
                        i = (int) fMeth(-25.313f, i2, i3);
                        z2 = z6;
                    }
                    d2 = d4;
                    d = d3;
                    j2 = j3;
                }
            } else {
                long doubleToLongBits = (z2 ? 1L : 0L) + j + b + i3 + Double.doubleToLongBits(d2) + i2 + Double.doubleToLongBits(d) + j2 + Float.floatToIntBits(-42.821f) + i4 + i + checkSum(iArr);
                lMeth_check_sum += doubleToLongBits;
                return doubleToLongBits;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        double[] dArr = new double[N];
        init(iArr, -209);
        init(dArr, 1.48625d);
        iArr[41] = (int) (((float) lMeth(false, -96L, (byte) 38)) + 1.584f);
        iArr[41] = iArr[41] + 9880;
        int i = 6;
        int i2 = 6;
        int i3 = -1;
        int i4 = -14;
        int i5 = -3304;
        int i6 = -122;
        int i7 = -58655;
        int i8 = 178;
        short s = -29242;
        int i9 = 17;
        while (i9 < 318) {
            instanceCount = instanceCount;
            int i10 = 1;
            short s2 = s;
            int i11 = i8;
            int i12 = i7;
            int i13 = i6;
            int i14 = i5;
            int i15 = i4;
            int i16 = 1;
            while (i16 < 84) {
                i12 = 2;
                while (i12 > i10) {
                    int i17 = i9 - 1;
                    double d = dArr[i17];
                    double d2 = i11;
                    Double.isNaN(d2);
                    dArr[i17] = d - d2;
                    i12--;
                    i10 = 1;
                }
                short s3 = (short) instanceCount;
                long j = i16;
                instanceCount = j;
                i11 = i14 + 1;
                i13++;
                iArr[i9] = i13;
                int i18 = iFld;
                int i19 = ((int) j) >>> i18;
                i14 += i16 * i16;
                iFld = i18 * ((int) this.dFld);
                instanceCount = i13;
                int i20 = i16;
                while (i20 < 2) {
                    this.dFld = 53.0d;
                    int i21 = iFld * i19;
                    iFld = i21;
                    iFld = i21 + (i20 * i20);
                    instanceCount = 87;
                    i20++;
                    i13 = 3;
                }
                i16++;
                s2 = s3;
                i = 2;
                i10 = 1;
                int i22 = i20;
                i15 = i19;
                i2 = i22;
            }
            i9++;
            i3 = i16;
            i4 = i15;
            i5 = i14;
            i6 = i13;
            i7 = i12;
            i8 = i11;
            s = s2;
        }
        System.out.println("i i17 i18 = " + i4 + "," + i9 + "," + i5);
        System.out.println("i19 i20 i21 = " + i3 + "," + i6 + "," + i7);
        System.out.println("i22 i23 s = " + i8 + "," + i + "," + ((int) s));
        System.out.println("i24 i25 by1 = " + i2 + ",3,87");
        System.out.println("iArr dArr = " + checkSum(iArr) + "," + Double.doubleToLongBits(checkSum(dArr)));
        System.out.println("Test.instanceCount Test.iFld dFld = " + instanceCount + "," + iFld + "," + Double.doubleToLongBits(this.dFld));
        PrintStream printStream = System.out;
        long checkSum = checkSum(lArrFld);
        StringBuilder sb = new StringBuilder();
        sb.append("Test.lArrFld = ");
        sb.append(checkSum);
        printStream.println(sb.toString());
        System.out.println("vMeth_check_sum: " + vMeth_check_sum);
        System.out.println("fMeth_check_sum: " + fMeth_check_sum);
        System.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            new Test().mainTest(strArr);
        } catch (Exception e) {
            System.out.println(e.getClass().getCanonicalName());
        }
    }

    public static int nextInt() {
        return random.nextInt();
    }

    public static long nextLong() {
        return random.nextLong();
    }

    public static float nextFloat() {
        return random.nextFloat();
    }

    public static double nextDouble() {
        return random.nextDouble();
    }

    public static boolean nextBoolean() {
        return random.nextBoolean();
    }

    public static byte nextByte() {
        return (byte) random.nextInt();
    }

    public static short nextShort() {
        return (short) random.nextInt();
    }

    public static char nextChar() {
        return (char) random.nextInt();
    }

    public static void init(boolean[] zArr, boolean z) {
        for (int i = 0; i < zArr.length; i++) {
            zArr[i] = i % 2 == 0 ? z : i % 3 == 0;
        }
    }

    public static void init(boolean[][] zArr, boolean z) {
        for (boolean[] zArr2 : zArr) {
            init(zArr2, z);
        }
    }

    public static void init(long[] jArr, long j) {
        for (int i = 0; i < jArr.length; i++) {
            jArr[i] = i % 2 == 0 ? i + j : j - i;
        }
    }

    public static void init(long[][] jArr, long j) {
        for (long[] jArr2 : jArr) {
            init(jArr2, j);
        }
    }

    public static void init(int[] iArr, int i) {
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr[i2] = i2 % 2 == 0 ? i + i2 : i - i2;
        }
    }

    public static void init(int[][] iArr, int i) {
        for (int[] iArr2 : iArr) {
            init(iArr2, i);
        }
    }

    public static void init(short[] sArr, short s) {
        for (int i = 0; i < sArr.length; i++) {
            sArr[i] = (short) (i % 2 == 0 ? s + i : s - i);
        }
    }

    public static void init(short[][] sArr, short s) {
        for (short[] sArr2 : sArr) {
            init(sArr2, s);
        }
    }

    public static void init(char[] cArr, char c) {
        for (int i = 0; i < cArr.length; i++) {
            cArr[i] = (char) (i % 2 == 0 ? c + i : c - i);
        }
    }

    public static void init(char[][] cArr, char c) {
        for (char[] cArr2 : cArr) {
            init(cArr2, c);
        }
    }

    public static void init(byte[] bArr, byte b) {
        for (int i = 0; i < bArr.length; i++) {
            bArr[i] = (byte) (i % 2 == 0 ? b + i : b - i);
        }
    }

    public static void init(byte[][] bArr, byte b) {
        for (byte[] bArr2 : bArr) {
            init(bArr2, b);
        }
    }

    public static void init(double[] dArr, double d) {
        double d2;
        for (int i = 0; i < dArr.length; i++) {
            if (i % 2 == 0) {
                double d3 = i;
                Double.isNaN(d3);
                d2 = d3 + d;
            } else {
                double d4 = i;
                Double.isNaN(d4);
                d2 = d - d4;
            }
            dArr[i] = d2;
        }
    }

    public static void init(double[][] dArr, double d) {
        for (double[] dArr2 : dArr) {
            init(dArr2, d);
        }
    }

    public static void init(float[] fArr, float f) {
        for (int i = 0; i < fArr.length; i++) {
            fArr[i] = i % 2 == 0 ? i + f : f - i;
        }
    }

    public static void init(float[][] fArr, float f) {
        for (float[] fArr2 : fArr) {
            init(fArr2, f);
        }
    }

    public static void init(Object[][] objArr, Object obj) {
        for (Object[] objArr2 : objArr) {
            init(objArr2, obj);
        }
    }

    public static void init(Object[] objArr, Object obj) {
        for (int i = 0; i < objArr.length; i++) {
            try {
                objArr[i] = obj.getClass().newInstance();
            } catch (Exception e) {
                objArr[i] = obj;
            }
        }
    }

    public static long checkSum(boolean[] zArr) {
        long j = 0;
        for (int i = 0; i < zArr.length; i++) {
            j += zArr[i] ? i + 1 : 0;
        }
        return j;
    }

    public static long checkSum(boolean[][] zArr) {
        long j = 0;
        for (boolean[] zArr2 : zArr) {
            j += checkSum(zArr2);
        }
        return j;
    }

    public static long checkSum(long[] jArr) {
        long j = 0;
        int i = 0;
        while (i < jArr.length) {
            int i2 = i + 1;
            long j2 = i2;
            j += (jArr[i] / j2) + (jArr[i] % j2);
            i = i2;
        }
        return j;
    }

    public static long checkSum(long[][] jArr) {
        long j = 0;
        for (long[] jArr2 : jArr) {
            j += checkSum(jArr2);
        }
        return j;
    }

    public static long checkSum(int[] iArr) {
        long j = 0;
        int i = 0;
        while (i < iArr.length) {
            int i2 = i + 1;
            j += (iArr[i] / i2) + (iArr[i] % i2);
            i = i2;
        }
        return j;
    }

    public static long checkSum(int[][] iArr) {
        long j = 0;
        for (int[] iArr2 : iArr) {
            j += checkSum(iArr2);
        }
        return j;
    }

    public static long checkSum(short[] sArr) {
        long j = 0;
        int i = 0;
        while (i < sArr.length) {
            int i2 = i + 1;
            j += (short) ((sArr[i] / i2) + (sArr[i] % i2));
            i = i2;
        }
        return j;
    }

    public static long checkSum(short[][] sArr) {
        long j = 0;
        for (short[] sArr2 : sArr) {
            j += checkSum(sArr2);
        }
        return j;
    }

    public static long checkSum(char[] cArr) {
        long j = 0;
        int i = 0;
        while (i < cArr.length) {
            int i2 = i + 1;
            j += (char) ((cArr[i] / i2) + (cArr[i] % i2));
            i = i2;
        }
        return j;
    }

    public static long checkSum(char[][] cArr) {
        long j = 0;
        for (char[] cArr2 : cArr) {
            j += checkSum(cArr2);
        }
        return j;
    }

    public static long checkSum(byte[] bArr) {
        long j = 0;
        int i = 0;
        while (i < bArr.length) {
            int i2 = i + 1;
            j += (byte) ((bArr[i] / i2) + (bArr[i] % i2));
            i = i2;
        }
        return j;
    }

    public static long checkSum(byte[][] bArr) {
        long j = 0;
        for (byte[] bArr2 : bArr) {
            j += checkSum(bArr2);
        }
        return j;
    }

    public static double checkSum(double[] dArr) {
        double d = 0.0d;
        int i = 0;
        while (i < dArr.length) {
            double d2 = dArr[i];
            int i2 = i + 1;
            double d3 = i2;
            Double.isNaN(d3);
            double d4 = dArr[i];
            Double.isNaN(d3);
            d += (d2 / d3) + (d4 % d3);
            i = i2;
        }
        return d;
    }

    public static double checkSum(double[][] dArr) {
        double d = 0.0d;
        for (double[] dArr2 : dArr) {
            d += checkSum(dArr2);
        }
        return d;
    }

    public static double checkSum(float[] fArr) {
        double d = 0.0d;
        int i = 0;
        while (i < fArr.length) {
            int i2 = i + 1;
            float f = i2;
            double d2 = (fArr[i] / f) + (fArr[i] % f);
            Double.isNaN(d2);
            d += d2;
            i = i2;
        }
        return d;
    }

    public static double checkSum(float[][] fArr) {
        double d = 0.0d;
        for (float[] fArr2 : fArr) {
            d += checkSum(fArr2);
        }
        return d;
    }

    public static long checkSum(Object[][] objArr) {
        long j = 0;
        for (Object[] objArr2 : objArr) {
            j += checkSum(objArr2);
        }
        return j;
    }

    public static long checkSum(Object[] objArr) {
        long j = 0;
        for (int i = 0; i < objArr.length; i++) {
            double d = j;
            double checkSum = checkSum(objArr[i]);
            double pow = Math.pow(2.0d, i);
            Double.isNaN(checkSum);
            Double.isNaN(d);
            j = (long) (d + (checkSum * pow));
        }
        return j;
    }

    public static long checkSum(Object obj) {
        if (obj == null) {
            return 0L;
        }
        return obj.getClass().getCanonicalName().length();
    }

    public static byte[] byte1array(int i, byte b) {
        byte[] bArr = new byte[i];
        init(bArr, b);
        return bArr;
    }

    public static byte[][] byte2array(int i, byte b) {
        byte[][] bArr = (byte[][]) Array.newInstance(byte.class, i, i);
        init(bArr, b);
        return bArr;
    }

    public static short[] short1array(int i, short s) {
        short[] sArr = new short[i];
        init(sArr, s);
        return sArr;
    }

    public static short[][] short2array(int i, short s) {
        short[][] sArr = (short[][]) Array.newInstance(short.class, i, i);
        init(sArr, s);
        return sArr;
    }

    public static int[] int1array(int i, int i2) {
        int[] iArr = new int[i];
        init(iArr, i2);
        return iArr;
    }

    public static int[][] int2array(int i, int i2) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, i, i);
        init(iArr, i2);
        return iArr;
    }

    public static long[] long1array(int i, long j) {
        long[] jArr = new long[i];
        init(jArr, j);
        return jArr;
    }

    public static long[][] long2array(int i, long j) {
        long[][] jArr = (long[][]) Array.newInstance(long.class, i, i);
        init(jArr, j);
        return jArr;
    }

    public static float[] float1array(int i, float f) {
        float[] fArr = new float[i];
        init(fArr, f);
        return fArr;
    }

    public static float[][] float2array(int i, float f) {
        float[][] fArr = (float[][]) Array.newInstance(float.class, i, i);
        init(fArr, f);
        return fArr;
    }

    public static double[] double1array(int i, double d) {
        double[] dArr = new double[i];
        init(dArr, d);
        return dArr;
    }

    public static double[][] double2array(int i, double d) {
        double[][] dArr = (double[][]) Array.newInstance(double.class, i, i);
        init(dArr, d);
        return dArr;
    }

    public static char[] char1array(int i, char c) {
        char[] cArr = new char[i];
        init(cArr, c);
        return cArr;
    }

    public static char[][] char2array(int i, char c) {
        char[][] cArr = (char[][]) Array.newInstance(char.class, i, i);
        init(cArr, c);
        return cArr;
    }

    public static Object[] Object1array(int i, Object obj) {
        Object[] objArr = new Object[i];
        init(objArr, obj);
        return objArr;
    }

    public static Object[][] Object2array(int i, Object obj) {
        Object[][] objArr = (Object[][]) Array.newInstance(Object.class, i, i);
        init(objArr, obj);
        return objArr;
    }

    public static boolean[] boolean1array(int i, boolean z) {
        boolean[] zArr = new boolean[i];
        init(zArr, z);
        return zArr;
    }

    public static boolean[][] boolean2array(int i, boolean z) {
        boolean[][] zArr = (boolean[][]) Array.newInstance(boolean.class, i, i);
        init(zArr, z);
        return zArr;
    }
}
