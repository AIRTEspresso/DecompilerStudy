
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/214/original-214/Test.dex */
public class Test {
    public static final int N = 400;
    public static volatile long instanceCount = 4;
    public static double dFld = -1.116122d;
    public static float fFld = -24.797f;
    public static short sFld = -3192;
    public static boolean bFld = false;
    public static volatile byte byFld = 101;
    public static long iMeth_check_sum = 0;
    public static long fMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    /* JADX WARN: Can't wrap try/catch for region: R(12:8|28|9|12|(2:32|13)|16|(1:35)(5:(2:19|(4:38|21|40|39)(1:37))|30|23|41|39)|22|30|23|41|39) */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void vMeth() {
        /*
            Method dump skipped, instructions count: 172
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.Test.vMeth():void");
    }

    public static float fMeth(long j) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 0.269f);
        FuzzerUtils.init(iArr, 199);
        vMeth();
        int i = -166;
        int i2 = 3;
        while (189 > i2) {
            i += i2 - i;
            fArr[i2 - 1] = i;
            i2++;
        }
        float f = 1.0f;
        do {
            double d = dFld;
            double d2 = i2;
            Double.isNaN(d2);
            dFld = d + d2;
            float f2 = i;
            fFld = f2;
            int i3 = ((((i << 60455486) + ((int) (f | f2))) + i2) - i2) - i2;
            i = i3 * i3;
            sFld = (short) (sFld << ((short) i2));
            f += 1.0f;
        } while (f < 304.0f);
        long floatToIntBits = j + i2 + i + Float.floatToIntBits(f) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr);
        fMeth_check_sum += floatToIntBits;
        return (float) floatToIntBits;
    }

    public static int iMeth(int i) {
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -36);
        FuzzerUtils.init(jArr, 1290L);
        FuzzerUtils.init(sArr, (short) 22764);
        int i2 = 36820;
        int i3 = 234;
        int i4 = 0;
        while (i4 < 400) {
            int i5 = iArr[i4];
            int i6 = (i5 >>> 1) % N;
            int i7 = iArr[i6];
            iArr[i6] = i7 + 1;
            i >>= i7;
            instanceCount = Math.max(fMeth(instanceCount) + i, instanceCount);
            int i8 = 1;
            while (i8 < 4) {
                i3 += (int) instanceCount;
                i <<= i5;
                sFld = (short) -33;
                i8++;
            }
            instanceCount = instanceCount;
            instanceCount |= instanceCount;
            boolean z = bFld;
            i4++;
            i2 = i8;
        }
        int i9 = 2;
        while (237 > i9) {
            i3 = (int) (i3 + i9 + fFld);
            sArr[i9] = (short) (sArr[i9] & 6559);
            i9++;
        }
        long checkSum = ((((i + i2) + i3) + i9) - 13) + 6559 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(sArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        long j;
        int i4;
        long j2;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19 = N;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        boolean[][] zArr = (boolean[][]) Array.newInstance(boolean.class, N, N);
        FuzzerUtils.init(jArr, -19L);
        FuzzerUtils.init(iArr, 0);
        FuzzerUtils.init(zArr, true);
        iMeth(6);
        int i20 = 11;
        int i21 = -23733;
        int i22 = -250;
        int i23 = 89;
        int i24 = 55;
        long j3 = -3198898865L;
        int i25 = 6;
        int i26 = -14;
        int i27 = 0;
        while (i27 < i19) {
            long j4 = jArr[i27];
            i21 = 2;
            while (i21 < 63) {
                int i28 = (i25 >>> 1) % i19;
                boolean[][] zArr2 = zArr;
                jArr[i28] = jArr[i28] - i25;
                int i29 = (int) instanceCount;
                if (((i21 % 2) * 5) + 62 != 64) {
                    int i30 = i21 + 1;
                    iArr[i30] = iArr[i30] + ((int) instanceCount);
                    float f = fFld - (-4.0f);
                    fFld = f;
                    i = (int) f;
                } else {
                    i = i26 / 11;
                }
                iArr[i21] = i21;
                i26 = i + (sFld | i21);
                i22 = 57696;
                i23 = 1;
                int i31 = i29;
                long j5 = j4;
                int[] iArr2 = iArr;
                long j6 = j5;
                while (i23 < 2) {
                    switch (i23 + 122) {
                        case 122:
                            i2 = i27;
                            i3 = i21;
                            float f2 = fFld;
                            i31 = (int) f2;
                            int i32 = i3 - 1;
                            iArr2[i32] = iArr2[i32] >>> i24;
                            double d = dFld;
                            double d2 = i24;
                            Double.isNaN(d2);
                            dFld = d - d2;
                            j6 = ((float) j6) + (((i23 * i26) + i26) - f2);
                            i20 = i20;
                            break;
                        case 123:
                            i2 = i27;
                            i3 = i21;
                            i26 += i23 * i3;
                            i31 &= (int) instanceCount;
                            i20 = i20;
                            break;
                        case 124:
                            i2 = i27;
                            i5 = i20;
                            i3 = i21;
                            j2 = j3;
                            switch (((i26 >>> 1) % 10) + 52) {
                                case 52:
                                    iArr2[i3] = i3;
                                    i22 = 178;
                                    i31 -= 72;
                                    j6 *= fFld;
                                    break;
                                case 53:
                                    i31 %= (int) (instanceCount | 1);
                                    break;
                                case 54:
                                case 55:
                                    i24 = (int) (i24 + (i23 - instanceCount));
                                    break;
                                case 56:
                                    int i33 = i23 - 1;
                                    iArr2[i33] = iArr2[i33] + ((int) dFld);
                                case 57:
                                    i24 += i23 + i23;
                                    break;
                                case 58:
                                    fFld *= i26;
                                    break;
                                case 59:
                                    instanceCount = (long) dFld;
                                    break;
                                case 60:
                                    double d3 = dFld;
                                    double d4 = i26;
                                    Double.isNaN(d4);
                                    dFld = d3 + d4;
                                    break;
                                case 61:
                                    instanceCount += i23 + i24;
                                    break;
                            }
                            iArr2[i23] = iArr2[i23] | i31;
                            i20 = i5;
                            j3 = j2;
                            break;
                        case 125:
                            i2 = i27;
                            i5 = i20;
                            i3 = i21;
                            j2 = j3;
                            iArr2[i23] = iArr2[i23] | i31;
                            i20 = i5;
                            j3 = j2;
                            break;
                        case 126:
                            i2 = i27;
                            i3 = i21;
                            iArr2[i23] = -14;
                            bFld = bFld;
                            i26 = (int) (i26 + (((i23 * i3) + j6) - i31));
                            i20 = i20;
                            j3 = j3;
                            break;
                        case 127:
                            i2 = i27;
                            i3 = i21;
                            bFld = bFld;
                            i26 = (int) (i26 + (((i23 * i3) + j6) - i31));
                            i20 = i20;
                            j3 = j3;
                            break;
                        case 128:
                            i2 = i27;
                            i3 = i21;
                            i26 = (int) (i26 + (((i23 * i3) + j6) - i31));
                            i20 = i20;
                            j3 = j3;
                            break;
                        case 129:
                            i2 = i27;
                            i3 = i21;
                            i31 += ((i23 * i31) + i20) - i20;
                            break;
                        case 130:
                            i2 = i27;
                            i3 = i21;
                            try {
                                int i34 = i31 % i23;
                                i26 /= i3;
                                i20 = iArr2[i3 + 1] / i3;
                                break;
                            } catch (ArithmeticException e) {
                                break;
                            }
                        case 131:
                            i2 = i27;
                            i3 = i21;
                            break;
                        case 132:
                            i6 = i26;
                            i2 = i27;
                            i3 = i21;
                            i31 += i23;
                            i26 = i6;
                            j3 = i26;
                            break;
                        case 133:
                            i6 = i26;
                            i2 = i27;
                            i3 = i21;
                            i26 = i6;
                            j3 = i26;
                            break;
                        case 134:
                            i2 = i27;
                            i3 = i21;
                            jArr[i23] = jArr[i23] - fFld;
                            i4 = i20;
                            j = j3;
                            i26 = i26;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 135:
                            i2 = i27;
                            i3 = i21;
                            dFld = fFld;
                            i4 = i20;
                            j = j3;
                            i26 = i26;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 136:
                            i2 = i27;
                            i3 = i21;
                            jArr[i3] = jArr[i3] * (-74);
                            i4 = i20;
                            j = j3;
                            i26 = i26;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 137:
                            i2 = i27;
                            i3 = i21;
                            dFld = i24;
                            i4 = i20;
                            j = j3;
                            i26 = i26;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 138:
                            i7 = i26;
                            i2 = i27;
                            i3 = i21;
                            i31 <<= i31;
                            i26 = i7 + 99;
                            break;
                        case 139:
                            i7 = i26;
                            i2 = i27;
                            i3 = i21;
                            i26 = i7 + 99;
                            break;
                        case 140:
                            i8 = i26;
                            i2 = i27;
                            i3 = i21;
                            j3 += i23 | i3;
                            jArr[i23] = jArr[i23] & j6;
                            i26 = i8;
                            break;
                        case 141:
                            i8 = i26;
                            i2 = i27;
                            i3 = i21;
                            jArr[i23] = jArr[i23] & j6;
                            i26 = i8;
                            break;
                        case 142:
                            i9 = i26;
                            i2 = i27;
                            i3 = i21;
                            i31 = i3;
                            i20 >>= 69;
                            i26 = i9;
                            break;
                        case 143:
                            i9 = i26;
                            i2 = i27;
                            i3 = i21;
                            i20 >>= 69;
                            i26 = i9;
                            break;
                        case 144:
                            i2 = i27;
                            i3 = i21;
                            i26 = 60370;
                            break;
                        case 145:
                        case 146:
                            i10 = i26;
                            i2 = i27;
                            i3 = i21;
                            sFld = (short) (sFld + ((short) instanceCount));
                            sFld = (short) (sFld & (-1));
                            i4 = i20;
                            j = j3;
                            i26 = i10;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 147:
                            i10 = i26;
                            i2 = i27;
                            i3 = i21;
                            sFld = (short) (sFld & (-1));
                            i4 = i20;
                            j = j3;
                            i26 = i10;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 148:
                            i2 = i27;
                            i3 = i21;
                            j6 >>= i24;
                            break;
                        case 149:
                            i2 = i27;
                            i3 = i21;
                            fFld -= (float) j3;
                            i4 = i20;
                            j = j3;
                            i26 = i26;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 150:
                            i2 = i27;
                            i3 = i21;
                            i20 = i23;
                            break;
                        case 151:
                            int i35 = i26;
                            i3 = i21;
                            double d5 = dFld;
                            i2 = i27;
                            double d6 = j6;
                            Double.isNaN(d6);
                            dFld = d5 * d6;
                            i4 = i20;
                            j = j3;
                            i26 = i35;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 152:
                            i3 = i21;
                            fFld *= i20;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i26 = i26;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 153:
                            i3 = i21;
                            i24 += i31;
                            i2 = i27;
                            break;
                        case 154:
                            i3 = i21;
                            i22 += (int) j6;
                            i2 = i27;
                            break;
                        case 155:
                            i3 = i21;
                            instanceCount -= 6161;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 156:
                            i11 = i26;
                            i3 = i21;
                            instanceCount <<= -12972;
                            fFld += ((i23 * i11) + i24) - i24;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i26 = i11;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 157:
                            i11 = i26;
                            i3 = i21;
                            fFld += ((i23 * i11) + i24) - i24;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i26 = i11;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 158:
                            i12 = i26;
                            i3 = i21;
                            zArr2[i3][i3 + 1] = bFld;
                            i22 -= i23;
                            i2 = i27;
                            i26 = i12;
                            break;
                        case 159:
                            i12 = i26;
                            i3 = i21;
                            i22 -= i23;
                            i2 = i27;
                            i26 = i12;
                            break;
                        case 160:
                            i3 = i21;
                            iArr2[i23] = (int) j3;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 161:
                            i3 = i21;
                            i22 -= (int) j3;
                            i2 = i27;
                            break;
                        case 162:
                            i3 = i21;
                            i26 += (int) ((i23 * i23) - 1.329f);
                            i2 = i27;
                            break;
                        case 163:
                            i3 = i21;
                            i2 = i27;
                            i22 = 5;
                            break;
                        case 164:
                            i3 = i21;
                            i31 -= 50415;
                            i2 = i27;
                            break;
                        case 165:
                            i3 = i21;
                            j6 += 1583;
                            i2 = i27;
                            break;
                        case 166:
                            i3 = i21;
                            sFld = (short) i31;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 167:
                            i13 = i26;
                            i3 = i21;
                            j3 = -236;
                            i20 += i23 - i20;
                            i2 = i27;
                            i26 = i13;
                            break;
                        case 168:
                            i13 = i26;
                            i3 = i21;
                            i20 += i23 - i20;
                            i2 = i27;
                            i26 = i13;
                            break;
                        case 169:
                            i3 = i21;
                            sFld = (short) (sFld + 18698);
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 170:
                            i3 = i21;
                            i22 = 195304623;
                            i2 = i27;
                            break;
                        case 171:
                            i3 = i21;
                            jArr[i3] = i3;
                            i2 = i27;
                            i4 = i20;
                            j = j3;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 172:
                            i24 += (int) ((i23 * i23) + 105);
                            i3 = i21;
                            i26 = i26;
                            i2 = i27;
                            break;
                        case 173:
                            fFld *= i26;
                            i4 = i20;
                            j = j3;
                            i3 = i21;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 174:
                            i14 = i21;
                            i26 -= i22;
                            i24 = i26;
                            i24 += i23 * i23;
                            i3 = i14;
                            i2 = i27;
                            break;
                        case 175:
                            i14 = i21;
                            i24 = i26;
                            i24 += i23 * i23;
                            i3 = i14;
                            i2 = i27;
                            break;
                        case 176:
                            i14 = i21;
                            i24 += i23 * i23;
                            i3 = i14;
                            i2 = i27;
                            break;
                        case 177:
                            j6 += byFld;
                            i3 = i21;
                            i2 = i27;
                            break;
                        case 178:
                            i15 = i21;
                            i20 <<= i15;
                            i31 -= i20;
                            i3 = i15;
                            i2 = i27;
                            break;
                        case 179:
                            i15 = i21;
                            i31 -= i20;
                            i3 = i15;
                            i2 = i27;
                            break;
                        case 180:
                            int i36 = i21;
                            jArr[i36] = i31;
                            i4 = i20;
                            j = j3;
                            i3 = i36;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 181:
                            i20 ^= i23;
                            i3 = i21;
                            i2 = i27;
                            break;
                        case 182:
                            int i37 = i21;
                            iArr2[i37 + 1] = 208;
                            i4 = i20;
                            j = j3;
                            i3 = i37;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 183:
                            int i38 = i21;
                            jArr[i38] = 10;
                            i4 = i20;
                            j = j3;
                            i3 = i38;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 184:
                            i16 = i21;
                            int i39 = i16 + 1;
                            iArr2[i39] = iArr2[i39] * i20;
                            sFld = (short) (sFld << (-4623));
                            i4 = i20;
                            j = j3;
                            i3 = i16;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 185:
                            i16 = i21;
                            sFld = (short) (sFld << (-4623));
                            i4 = i20;
                            j = j3;
                            i3 = i16;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 186:
                            bFld = bFld;
                            i4 = i20;
                            j = j3;
                            i3 = i21;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 187:
                            i17 = i21;
                            if (bFld) {
                                i4 = i20;
                                j = j3;
                                i3 = i17;
                                i2 = i27;
                                i20 = i4;
                                j3 = j;
                                break;
                            }
                            int i40 = i23 - 1;
                            jArr[i40] = jArr[i40] - 178;
                            i4 = i20;
                            j = j3;
                            i3 = i17;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                        case 188:
                            i17 = i21;
                            int i402 = i23 - 1;
                            jArr[i402] = jArr[i402] - 178;
                            i4 = i20;
                            j = j3;
                            i3 = i17;
                            i2 = i27;
                            i20 = i4;
                            j3 = j;
                            break;
                        case 189:
                            i18 = i21;
                            dFld = i22;
                            j6 -= i26;
                            fFld += (float) (i23 - j6);
                            i3 = i18;
                            i2 = i27;
                            break;
                        case 190:
                            i18 = i21;
                            j6 -= i26;
                            fFld += (float) (i23 - j6);
                            i3 = i18;
                            i2 = i27;
                            break;
                        case 191:
                            i18 = i21;
                            fFld += (float) (i23 - j6);
                            i3 = i18;
                            i2 = i27;
                            break;
                        default:
                            i2 = i27;
                            i4 = i20;
                            i3 = i21;
                            j = j3;
                            i20 = i4;
                            j3 = j;
                            break;
                    }
                    i23++;
                    i21 = i3;
                    i27 = i2;
                }
                i21++;
                i25 = i31;
                zArr = zArr2;
                iArr = iArr2;
                j4 = j6;
                i19 = N;
            }
            i27++;
            zArr = zArr;
            i19 = N;
        }
        FuzzerUtils.out.println("i11 i12 i13 = " + i25 + "," + i21 + "," + i22);
        FuzzerUtils.out.println("i14 i15 i16 = " + i26 + "," + i23 + "," + i24);
        FuzzerUtils.out.println("i17 l2 lArr2 = " + i20 + "," + j3 + "," + FuzzerUtils.checkSum(jArr));
        FuzzerUtils.out.println("iArr3 bArr1 = " + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.sFld Test.bFld Test.byFld = " + ((int) sFld) + "," + (bFld ? 1 : 0) + "," + ((int) byFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
