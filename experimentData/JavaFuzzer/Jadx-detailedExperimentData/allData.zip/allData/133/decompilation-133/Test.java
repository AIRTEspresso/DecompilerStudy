
import java.io.PrintStream;
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/133/original-133/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -3;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public short sFld = 4906;
    public volatile boolean[] bArrFld = new boolean[N];
    public boolean[] bArrFld1 = new boolean[N];
    public volatile int[] iArrFld = new int[N];

    public static void vMeth1(long j) {
        int i;
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, -23420);
        int i2 = -40535;
        float f = 1.0f;
        do {
            i = 1;
            while (true) {
                i++;
                if (i < 7) {
                    i2 = 1;
                } else {
                    f += 1.0f;
                }
            }
        } while (f < 232.0f);
        vMeth1_check_sum += ((j - 100) - 100) + Float.floatToIntBits(f) + i + i2 + 52359 + 1 + Float.floatToIntBits(1.285f) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 0);
        vMeth1(instanceCount);
        int i2 = -8759;
        int i3 = 7;
        int i4 = 48;
        int i5 = -203;
        int i6 = 8;
        float f = 97.63f;
        int i7 = 13;
        while (i7 < 388) {
            long j = i7;
            instanceCount = j;
            int i8 = i2;
            int i9 = i4;
            int i10 = i7;
            while (true) {
                i = 5;
                if (i10 >= 5) {
                    break;
                }
                i9 = ((int) instanceCount) + i10;
                i10++;
                i8 = i7;
            }
            instanceCount += j;
            iArr[i7] = iArr[i7] | i10;
            do {
                f += i * i;
                i6 += i - i10;
                i -= 3;
            } while (i > 0);
            i7++;
            i5 = i;
            i2 = i8;
            i3 = i10;
            i4 = i9;
        }
        vMeth_check_sum += ((((((i7 + i2) + i3) + i4) + i5) + Float.floatToIntBits(f)) - 39454) + i6 + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(int i) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -37605);
        int i2 = (i * ((int) (i + ((-0.0f) + iArr[(i >>> 1) % N])))) - 1;
        int reverseBytes = Integer.reverseBytes(i2) / (Math.min((int) ((i2 - instanceCount) + 31086), i2) | 1);
        int i3 = -7;
        int i4 = -71;
        int i5 = 230;
        int i6 = -38420;
        int i7 = 5;
        while (i7 < 162) {
            i3 = i7;
            while (i3 < 10) {
                long j = instanceCount;
                instanceCount = j - 1;
                i4 >>= (int) j;
                int i8 = i7 - 1;
                reverseBytes--;
                iArr[i8] = iArr[i8] + (((-11936) - Math.min(i3, -11936)) * Math.abs(reverseBytes));
                i5 = 2;
                vMeth();
                i3++;
                i6 = 1;
            }
            i7++;
        }
        long floatToIntBits = (((((((reverseBytes + Float.floatToIntBits(-1.169f)) + i7) - 11936) + i3) + i4) + i5) - 59) + 0 + i6 + 228 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = 13;
        int i3 = -34574;
        int i4 = -36;
        int i5 = -180;
        byte b = 12;
        double d = 10.0d;
        int i6 = 1;
        boolean z = false;
        while (185.0d > d) {
            int i7 = -73.358f >= ((float) this.sFld) ? 1 : 0;
            int i8 = i6 == 1 ? 1 : 0;
            boolean z2 = i6 == 1 ? 1 : 0;
            boolean z3 = i6 == 1 ? 1 : 0;
            boolean z4 = i6 == 1 ? 1 : 0;
            boolean z5 = (i7 == (i8 ^ i6) ? 1 : 0) != ((i6 | i6) | ((instanceCount > 200L ? 1 : (instanceCount == 200L ? 0 : -1)) > 0 ? (char) 1 : (char) 0));
            double d2 = 1.0d + d;
            int i9 = (int) d2;
            this.bArrFld[i9] = z;
            int iMeth = iMeth(i2);
            long j = instanceCount;
            float f = (float) j;
            if (z5) {
                i = iMeth + ((int) f);
            } else {
                i = (int) j;
            }
            i2 = i + b;
            i3 = 8;
            while (i3 < 143) {
                b = (byte) (b >> ((byte) instanceCount));
                i5 = (int) d;
                while (2 > i5) {
                    this.bArrFld1[(i4 >>> 1) % N] = z5;
                    int i10 = (i4 + (i5 * i5)) >> 11;
                    int[] iArr = this.iArrFld;
                    iArr[i5] = iArr[i5] & i2;
                    this.iArrFld[i9] = -187;
                    i4 = (i5 % 1) + 106 != 106 ? i10 : i2;
                    i5++;
                }
                i3++;
                boolean z6 = z5 ? 1 : 0;
                boolean z7 = z5 ? 1 : 0;
                boolean z8 = z5 ? 1 : 0;
                boolean z9 = z5 ? 1 : 0;
                z = z6;
            }
            d = d2;
            i6 = z5;
        }
        PrintStream printStream = FuzzerUtils.out;
        StringBuilder append = new StringBuilder().append("d i b = ").append(Double.doubleToLongBits(d)).append(",").append(i2).append(",");
        int i11 = i6 == 1 ? 1 : 0;
        int i12 = i6 == 1 ? 1 : 0;
        int i13 = i6 == 1 ? 1 : 0;
        int i14 = i6 == 1 ? 1 : 0;
        printStream.println(append.append(i11).toString());
        PrintStream printStream2 = FuzzerUtils.out;
        StringBuilder append2 = new StringBuilder().append("b1 by2 i20 = ");
        int i15 = z ? 1 : 0;
        int i16 = z ? 1 : 0;
        int i17 = z ? 1 : 0;
        int i18 = z ? 1 : 0;
        printStream2.println(append2.append(i15).append(",").append((int) b).append(",").append(i3).toString());
        FuzzerUtils.out.println("i21 i22 i23 = " + i4 + "," + i5 + ",-187");
        FuzzerUtils.out.println("b4 = 0");
        FuzzerUtils.out.println("Test.instanceCount sFld bArrFld = " + instanceCount + "," + ((int) this.sFld) + "," + FuzzerUtils.checkSum(this.bArrFld));
        FuzzerUtils.out.println("bArrFld1 iArrFld = " + FuzzerUtils.checkSum(this.bArrFld1) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
