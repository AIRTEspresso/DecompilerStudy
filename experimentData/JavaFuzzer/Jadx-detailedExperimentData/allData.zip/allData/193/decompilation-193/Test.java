/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/193/original-193/Test.dex */
public class Test {
    public static int[] iArrFld;
    public static long instanceCount = 3;
    public static boolean bFld = false;
    public static double dFld = -30.90614d;
    public static short sFld = 7699;
    public static byte byFld = 41;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long lMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 47);
        FuzzerUtils.init(fArrFld, 0.836f);
    }

    public static long lMeth(int i) {
        float[] fArr;
        int i2;
        boolean z = bFld;
        int i3 = 5;
        int i4 = 1;
        int i5 = 1313;
        float f = -91.337f;
        if (z) {
            int i6 = 1;
            while (true) {
                i6++;
                if (i6 >= 308) {
                    break;
                }
                instanceCount += 89;
            }
            i >>= (int) instanceCount;
            i4 = i6;
        } else if (z) {
            int i7 = i - 12;
            i5 = 5;
            while (i5 < 291) {
                iArrFld[i5] = i7;
                f = 1;
                i5++;
                i7 = 1;
            }
            i = i7 << ((int) instanceCount);
            fArrFld[(i >>> 1) % N] = fArr[i2] - 238.0f;
        } else {
            i3 = 11;
            while (i3 < 239) {
                long j = instanceCount + ((i3 * i3) - 404788774760728131L);
                instanceCount = j;
                instanceCount = j - 44109;
                if (bFld) {
                    break;
                }
                i3++;
            }
        }
        long floatToIntBits = (((((i + i4) + i5) - 9) + Float.floatToIntBits(f)) + i3) - 44109;
        lMeth_check_sum += floatToIntBits;
        return floatToIntBits;
    }

    public static void vMeth1(float f) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 2L);
        int i = 2;
        int i2 = 1;
        while (i < 254) {
            long j = instanceCount - 1;
            instanceCount = j;
            int i3 = (i2 + i) * ((int) j);
            lMeth(i3);
            i2 = i3 + i;
            i++;
        }
        int i4 = i2 * 14;
        int i5 = 20;
        int i6 = 11810;
        int i7 = 63351;
        int i8 = -7;
        while (i5 < 386) {
            i7 = 1;
            while (true) {
                i7++;
                if (i7 < 5) {
                    int[] iArr = iArrFld;
                    iArr[i7] = i;
                    float[] fArr = fArrFld;
                    int i9 = i5 + 1;
                    fArr[i9] = fArr[i9] - i7;
                    int i10 = ((i7 % 10) * 5) + 100;
                    if (i10 == 104) {
                        iArr[i7] = -6;
                    } else if (i10 != 107) {
                        if (i10 != 113) {
                            if (i10 == 128) {
                                i4 = sFld;
                            } else if (i10 == 130) {
                                i4 -= i8;
                            } else if (i10 == 138) {
                                i4 >>= (int) instanceCount;
                            } else if (i10 == 150) {
                                i4 += 2;
                                dFld = f;
                                i8 = 2;
                            } else {
                                switch (i10) {
                                    case 119:
                                        iArr[i9] = iArr[i9] - 104;
                                        break;
                                    case 120:
                                        i6 += (i7 * i7) + 96;
                                        break;
                                    case 121:
                                        jArr[i7 + 1] = i;
                                        break;
                                    default:
                                        i6 = -2;
                                        break;
                                }
                            }
                        }
                        i4 -= -6;
                        i4 >>= (int) instanceCount;
                    }
                }
            }
            i5++;
        }
        vMeth1_check_sum += (((((((Float.floatToIntBits(f) + i) + i4) + i5) + i6) + i7) + i8) - 6) + FuzzerUtils.checkSum(jArr);
    }

    public static void vMeth(int i) {
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, true);
        int i2 = -42;
        int i3 = -29446;
        int i4 = -10;
        int i5 = 220;
        int i6 = 8;
        while (i6 < 227) {
            i2 = 1;
            while (i2 < 7) {
                vMeth1(-126.363f);
                i3 -= (int) instanceCount;
                i2++;
            }
            int[] iArr = iArrFld;
            int i7 = i6 + 1;
            iArr[i7] = iArr[i7] * i;
            while (i6 < 7) {
                int[] iArr2 = iArrFld;
                iArr2[i7] = i3;
                i6++;
                iArr2[i6] = 8;
                i3 = -11;
                iArr2[i6] = iArr2[i6] + ((int) instanceCount);
                i5 = 1;
            }
            i4 = i6;
            i6 = i7;
        }
        vMeth_check_sum += (((((((((i + i6) + 12314) + i2) + i3) + i4) + 8) + i5) - 7) - 77) + FuzzerUtils.checkSum(zArr);
    }

    public void mainTest(String[] strArr) {
        int i = 10761;
        vMeth(10761);
        int i2 = 8;
        int i3 = 8168;
        int i4 = -3;
        int i5 = 203;
        int i6 = 112;
        int i7 = 59433;
        int i8 = -60872;
        float f = -1.493f;
        int i9 = 7;
        while (i2 < 346) {
            i *= 14;
            if (!bFld) {
                iArrFld[i2 - 1] = (int) instanceCount;
                int i10 = i9;
                float f2 = f;
                int i11 = i8;
                int i12 = i7;
                int i13 = i6;
                int i14 = i5;
                int i15 = 74;
                while (i15 > 4) {
                    instanceCount *= 65280;
                    i3 -= i2;
                    i14 = i15;
                    while (true) {
                        i13 = 2;
                        if (i14 < 2) {
                            instanceCount >>= i14;
                            i14++;
                        }
                    }
                    while (i13 > 1) {
                        bFld = false;
                        double d = i2;
                        dFld = d;
                        Double.isNaN(d);
                        Double.isNaN(d);
                        double d2 = d - d;
                        dFld = d2;
                        switch ((i13 % 8) + 37) {
                            case 37:
                                i10 *= (int) instanceCount;
                                if (0 == 0) {
                                    long j = i13;
                                    instanceCount = j;
                                    instanceCount = j & 1036;
                                    break;
                                } else {
                                    break;
                                }
                            case 38:
                                i10 = 74;
                                break;
                            case 39:
                                int i16 = i13 * i13;
                                switch (((i13 >>> 1) % 7) + 104) {
                                    case 104:
                                        iArrFld[i13] = byFld;
                                        f2 = (float) d2;
                                        i3 = i2;
                                        break;
                                    case 105:
                                        instanceCount += i13;
                                        i3 = i2;
                                        break;
                                    case 106:
                                        iArrFld = iArrFld;
                                        instanceCount += byFld;
                                        i11 += i16;
                                        i3 = i2;
                                        break;
                                    case 107:
                                        i12 = -8372;
                                    case 108:
                                        instanceCount &= i11;
                                        i3 = i2;
                                        break;
                                    case 109:
                                        iArrFld[i13] = 52327;
                                        i3 = i2;
                                        break;
                                    case 110:
                                        instanceCount += (long) d2;
                                        i3 = i2;
                                        break;
                                    default:
                                        i10 -= i15;
                                        i3 = i2;
                                        break;
                                }
                            case 40:
                                f2 = (float) d2;
                                break;
                            case 41:
                                i -= (int) d2;
                                break;
                            case 42:
                                int[] iArr = iArrFld;
                                iArr[i2] = iArr[i2] - i2;
                                break;
                            case 43:
                                int[] iArr2 = iArrFld;
                                int i17 = i15 + 1;
                                iArr2[i17] = iArr2[i17] / (i2 | 1);
                            case 44:
                                fArrFld = FuzzerUtils.float1array(N, -113.619f);
                                break;
                        }
                        i13--;
                    }
                    i15--;
                }
                i2++;
                i4 = i15;
                i5 = i14;
                i6 = i13;
                i7 = i12;
                i8 = i11;
                f = f2;
                i9 = i10;
            } else {
                FuzzerUtils.out.println("i23 i24 i25 = " + i + "," + i2 + "," + i3);
                FuzzerUtils.out.println("i26 i27 i28 = " + i4 + ",10," + i5);
                FuzzerUtils.out.println("i29 i30 i31 = " + i9 + "," + i6 + "," + i7);
                FuzzerUtils.out.println("f3 i32 = " + Float.floatToIntBits(f) + "," + i8);
                FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
                FuzzerUtils.out.println("Test.sFld Test.byFld Test.iArrFld = " + ((int) sFld) + "," + ((int) byFld) + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
            }
        }
        FuzzerUtils.out.println("i23 i24 i25 = " + i + "," + i2 + "," + i3);
        FuzzerUtils.out.println("i26 i27 i28 = " + i4 + ",10," + i5);
        FuzzerUtils.out.println("i29 i30 i31 = " + i9 + "," + i6 + "," + i7);
        FuzzerUtils.out.println("f3 i32 = " + Float.floatToIntBits(f) + "," + i8);
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.dFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.sFld Test.byFld Test.iArrFld = " + ((int) sFld) + "," + ((int) byFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
