
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/14/original-14/Test.dex */
public class Test {
    public double dFld = 1.58438d;
    public static volatile long instanceCount = 156;
    public static float fFld = 19.722f;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static volatile long[] lArrFld = new long[N];
    public static float[] fArrFld = new float[N];
    public static long bMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        FuzzerUtils.init(iArrFld, -182);
        FuzzerUtils.init(lArrFld, -6087713711903524745L);
        FuzzerUtils.init(fArrFld, -4.232f);
    }

    public static void vMeth1(short s, int i) {
        boolean[][] zArr = (boolean[][]) Array.newInstance(boolean.class, N, N);
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 128);
        FuzzerUtils.init(zArr, true);
        for (int i2 = 0; i2 < 400; i2++) {
            zArr[(i >>> 1) % N][(iArr[i2] >>> 1) % N] = false;
        }
        vMeth1_check_sum += (((((((s + i) + 0) - 2) - 51889) + Float.floatToIntBits(124.502f)) + Double.doubleToLongBits(1.117647d)) - 90) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(zArr);
    }

    public static void vMeth() {
        short[] sArr = new short[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(fArr, 89.208f);
        FuzzerUtils.init(sArr, (short) 656);
        vMeth1((short) -19244, 61579);
        int i = 7;
        while (i < 138) {
            i++;
        }
        vMeth_check_sum += ((((((((-19389) + i) + 188) + 0) + 8) - 9114) - 6) - 37628) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(sArr);
    }

    public static boolean bMeth(int i, float f, short s) {
        vMeth();
        int[] iArr = iArrFld;
        int i2 = (i >>> 1) % N;
        iArr[i2] = iArr[i2] >> ((int) instanceCount);
        instanceCount = i;
        iArrFld[i2] = i;
        int i3 = 103;
        int i4 = 12;
        while (i4 < 292) {
            lArrFld[i4] = -5;
            i3 = (-5) - ((int) instanceCount);
            i4++;
        }
        float[] fArr = fArrFld;
        fArr[i2] = fArr[i2] + 0.994f;
        int i5 = 14;
        while (i5 < 312) {
            instanceCount <<= i5;
            i5++;
        }
        int[] iArr2 = iArrFld;
        iArr2[i2] = iArr2[i2] + i4;
        int i6 = 6;
        while (380 > i6) {
            iArrFld = iArrFld;
            i6 += 2;
        }
        long floatToIntBits = ((((((((i + Float.floatToIntBits(f)) + s) + i4) + i3) + i5) + 36447) + i6) - 140) + 0;
        bMeth_check_sum += floatToIntBits;
        return floatToIntBits % 2 > 0;
    }

    public void mainTest(String[] strArr) {
        int i = 13;
        int i2 = -197;
        int i3 = 211;
        int i4 = 9;
        while (222 > i4) {
            i2 = 5;
            while (i2 < 118) {
                bMeth(i2, fFld, (short) 18242);
                i2 += 2;
            }
            i3 += i4 - i3;
            i += (int) fFld;
            i4++;
        }
        fFld += i2;
        int i5 = 18;
        while (i5 < 291) {
            if (((i2 >>> 1) % 1) + 97 == 97) {
                i += i4;
            }
            i5++;
            lArrFld[i5] = i;
            i ^= i3;
        }
        double d = this.dFld;
        double d2 = i2;
        Double.isNaN(d2);
        this.dFld = d * d2;
        FuzzerUtils.out.println("i i1 i2 = " + i4 + "," + i + "," + i2);
        FuzzerUtils.out.println("i3 s3 i22 = " + (18242 - i5) + ",18242," + i5);
        FuzzerUtils.out.println("i23 = -108");
        FuzzerUtils.out.println("Test.instanceCount Test.fFld dFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("Test.iArrFld Test.lArrFld Test.fArrFld = " + FuzzerUtils.checkSum(iArrFld) + "," + FuzzerUtils.checkSum(lArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
