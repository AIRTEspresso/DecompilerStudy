
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/204/original-204/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long instanceCount = -3981599709L;
    public static int iFld = -11;
    public static double dFld = -94.5653d;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public byte byFld = -35;
    public short sFld = 18050;
    public int[] iArrFld1 = new int[N];
    public float[] fArrFld = new float[N];

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 34598);
    }

    public static long lMeth(int i, int i2, int i3) {
        float[] fArr;
        int i4;
        int i5;
        int i6 = i;
        float[] fArr2 = new float[N];
        float[] fArr3 = new float[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(fArr2, -40.14f);
        FuzzerUtils.init(fArr3, -2.17f);
        FuzzerUtils.init(dArr, 0.54139d);
        int i7 = i3 >>> 1;
        int i8 = ((i7 % 9) * 5) + 51;
        int i9 = -13;
        int i10 = -219;
        int i11 = -31463;
        int i12 = -45;
        double d = 62.6696d;
        if (i8 != 53) {
            if (i8 != 63) {
                if (i8 == 72) {
                    fArr = fArr2;
                    iArrFld[338] = -31463;
                    i5 = i2;
                    i4 = i3;
                    long floatToIntBits = i6 + i5 + i4 + i9 + Float.floatToIntBits(89.338f) + i10 + i11 + i12 + 58 + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr3)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                    lMeth_check_sum += floatToIntBits;
                    return floatToIntBits;
                }
                if (i8 == 75) {
                    fArr = fArr2;
                    double d2 = i6;
                    Double.isNaN(d2);
                    d = 62.6696d + d2;
                    i5 = i2;
                    i4 = i3;
                } else if (i8 == 79) {
                    int i13 = 1;
                    i4 = i3;
                    int i14 = 1;
                    while (true) {
                        i14 += i13;
                        fArr2[i14] = 89.338f;
                        i10 = 1;
                        while (i10 < 12) {
                            i4 >>= i6;
                            instanceCount -= i6;
                            i12 = 2;
                            i10++;
                            fArr2 = fArr2;
                        }
                        fArr = fArr2;
                        if (i14 >= 131) {
                            break;
                        }
                        fArr2 = fArr;
                        i13 = 1;
                    }
                    i5 = i2;
                    i9 = i14;
                } else if (i8 == 86) {
                    int i15 = i7 % N;
                    fArr3[i15] = fArr3[i15] + ((float) instanceCount);
                    fArr = fArr2;
                } else if (i8 == 89) {
                    i5 = i2 - i6;
                    i4 = i3;
                    fArr = fArr2;
                } else if (i8 == 93) {
                    i5 = i2;
                    i4 = i3;
                    fArr = fArr2;
                    i11 = 58;
                } else if (i8 != 96) {
                    fArr = fArr2;
                } else {
                    i5 = i2 >> (-219);
                    i4 = i3;
                    fArr = fArr2;
                }
                long floatToIntBits2 = i6 + i5 + i4 + i9 + Float.floatToIntBits(89.338f) + i10 + i11 + i12 + 58 + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr3)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
                lMeth_check_sum += floatToIntBits2;
                return floatToIntBits2;
            }
            fArr = fArr2;
            iArrFld[45] = 69954769;
            i5 = i2;
            i4 = i3;
            long floatToIntBits22 = i6 + i5 + i4 + i9 + Float.floatToIntBits(89.338f) + i10 + i11 + i12 + 58 + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr3)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
            lMeth_check_sum += floatToIntBits22;
            return floatToIntBits22;
        }
        fArr = fArr2;
        i6 = -13;
        iArrFld[316] = -20974;
        i5 = i2;
        i4 = i3;
        long floatToIntBits222 = i6 + i5 + i4 + i9 + Float.floatToIntBits(89.338f) + i10 + i11 + i12 + 58 + Double.doubleToLongBits(d) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr3)) + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
        lMeth_check_sum += floatToIntBits222;
        return floatToIntBits222;
    }

    public static void vMeth(float f) {
        int[] iArr = iArrFld;
        int i = iFld;
        iArr[(i >>> 1) % N] = (int) lMeth(i, i, i);
        vMeth_check_sum += Float.floatToIntBits(f);
    }

    public static int iMeth(long j, long j2, int i) {
        int i2 = iFld + 1;
        iFld = i2;
        int i3 = i - ((int) (i2 * ((i * j) - 15174)));
        long j3 = instanceCount;
        int[] iArr = iArrFld;
        int i4 = (i2 >>> 1) % N;
        int i5 = iArr[i4] + 1;
        iArr[i4] = i5;
        instanceCount = j3 << i5;
        int i6 = (i2 >>> 1) % N;
        iArr[i6] = iArr[i6] << 16986;
        long floatToIntBits = ((((j + j2) + i3) + Float.floatToIntBits(-2.233f)) + 1) - 100;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr;
        int i;
        int[][] iArr2 = (int[][]) Array.newInstance(int.class, N, N);
        double[] dArr = new double[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr2, 1);
        FuzzerUtils.init(dArr, 113.58021d);
        FuzzerUtils.init(jArr, 698108647L);
        int i2 = iFld;
        byte b = this.byFld;
        this.byFld = (byte) (b - 1);
        int i3 = i2 - b;
        iFld = i3;
        iFld = i3;
        int iMeth = iMeth(4445328316377560012L, instanceCount, -50883);
        iFld = iMeth;
        instanceCount *= iMeth;
        iFld = iMeth;
        float f = iMeth - 2.135f;
        this.iArrFld1[(iMeth >>> 1) % N] = iArr[i] - 906;
        this.fArrFld = this.fArrFld;
        int i4 = 6;
        while (i4 < 347) {
            instanceCount -= 41868;
            iFld += (i4 * i4) - 248;
            i4++;
        }
        this.sFld = (short) (this.sFld + ((short) iFld));
        int i5 = 185;
        int i6 = -51621;
        int i7 = 1;
        while (true) {
            i7++;
            if (i7 < 226) {
                int i8 = iFld;
                dArr[i7 + 1] = i8;
                int i9 = (i7 % 2) + 33;
                if (i9 == 33) {
                    i5 = 3;
                    i6 = 8;
                    int[] iArr3 = iArrFld;
                    int i10 = i7 - 1;
                    iArr3[i10] = iArr3[i10] - 1613785836;
                    iFld = i8 * i4;
                } else if (i9 == 34) {
                    jArr[i7 - 1] = 2081;
                }
            } else {
                FuzzerUtils.out.println("f3 i9 i10 = " + Float.floatToIntBits(f) + "," + i4 + ",-41868");
                FuzzerUtils.out.println("i11 b1 i12 = " + i7 + ",1," + i5);
                FuzzerUtils.out.println("i13 i14 i15 = " + i6 + ",226,2081");
                FuzzerUtils.out.println("iArr1 dArr1 lArr = " + FuzzerUtils.checkSum(iArr2) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + "," + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld byFld = " + instanceCount + "," + iFld + "," + ((int) this.byFld));
                FuzzerUtils.out.println("Test.dFld sFld Test.iArrFld = " + Double.doubleToLongBits(dFld) + "," + ((int) this.sFld) + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("iArrFld1 fArrFld = " + FuzzerUtils.checkSum(this.iArrFld1) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
