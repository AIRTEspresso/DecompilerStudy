/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/190/original-190/Test.dex */
public class Test {
    public static long[] lArrFld;
    public volatile int[] iArrFld = new int[N];
    public static long instanceCount = -57488;
    public static final int N = 400;
    public static float[] fArrFld = new float[N];
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 2368852000L);
        FuzzerUtils.init(fArrFld, 125.129f);
    }

    public static void vMeth2() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 175);
        int i = -14;
        int i2 = -14;
        int i3 = 12;
        int i4 = 15;
        while (i4 < 306) {
            i3 = 6;
            while (i3 > i4) {
                try {
                    int i5 = iArr[i3] % i3;
                    int i6 = i3 / (-46140);
                    i2 = 0;
                } catch (ArithmeticException e) {
                }
                i3--;
            }
            i = (i - i4) + ((i4 * i4) - 102);
            i4++;
            iArr[i4] = iArr[i4] * (-243);
            instanceCount -= (long) (-55.90724d);
        }
        vMeth2_check_sum += ((((i + i4) + i2) + i3) - 7) + 6 + 1 + Double.doubleToLongBits(-55.90724d) + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth1(long j) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -22546);
        vMeth2();
        int i = 13;
        int i2 = -4;
        int i3 = 58;
        long j2 = -218;
        byte b = 84;
        short s = -20484;
        int i4 = 389;
        while (18 < i4) {
            instanceCount -= -108;
            int[] iArr2 = iArr;
            long j3 = 1;
            byte b2 = b;
            int i5 = 123;
            while (j3 < 5) {
                instanceCount = instanceCount;
                iArr2 = FuzzerUtils.int1array(N, -7896);
                i5 = 2;
                j3++;
                b2 = (byte) (((byte) j) * b2);
            }
            int i6 = 1;
            do {
                s = (short) (s >>> ((short) i5));
                i2 = (i2 >> ((int) instanceCount)) << 6;
                i6++;
            } while (i6 < 5);
            i4--;
            i3 = i6;
            iArr = iArr2;
            i = i5;
            j2 = j3;
            b = b2;
        }
        vMeth1_check_sum += j + i4 + i + j2 + i2 + b + i3 + s + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth(long j, byte b, long j2) {
        int[] iArr = new int[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(iArr, -9);
        FuzzerUtils.init(sArr, (short) 17566);
        int i = -35923;
        int i2 = 158;
        int i3 = -104;
        int i4 = -929;
        long j3 = 7;
        int i5 = 267;
        while (true) {
            i5--;
            if (i5 > 0) {
                i += i5;
                vMeth1(j2);
                i4 = -5;
                i2 = 6;
                while (i2 > 1) {
                    j3 = 2;
                    while (j3 > i2) {
                        int i6 = i2 + 1;
                        iArr[i6] = iArr[i6] + i5;
                        j3--;
                    }
                    i3 = 1;
                    while (i3 < 2) {
                        int i7 = ((i2 >>> 1) % 2) + 120;
                        if (i7 == 120 || i7 == 121) {
                            instanceCount = -14L;
                        } else {
                            float[] fArr = fArrFld;
                            int i8 = i5 - 1;
                            fArr[i8] = fArr[i8] * 61261;
                        }
                        int i9 = i2 + 1;
                        iArr[i9] = iArr[i9] | ((int) j3);
                        sArr[i9] = (short) (sArr[i9] >> ((short) 11679));
                        i3 += 2;
                    }
                    i2--;
                }
            } else {
                vMeth_check_sum += j + b + j2 + i5 + i + i4 + i2 + 24892 + j3 + 61261 + i3 + 11679 + 0 + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(sArr);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr;
        long j;
        byte[] bArr = new byte[N];
        double[] dArr = new double[N];
        FuzzerUtils.init(bArr, (byte) -108);
        FuzzerUtils.init(dArr, 2.67153d);
        long j2 = instanceCount;
        long j3 = j2 + 1;
        instanceCount = j3;
        instanceCount = j2 + j3;
        int i = 104;
        byte b = -33;
        float f = -80.438f;
        long j4 = 6;
        while (j4 < 340) {
            long[] jArr = lArrFld;
            int i2 = (int) (j4 - 1);
            jArr[i2] = jArr[i2] + 1;
            int i3 = i + i;
            int i4 = i - 1;
            byte b2 = (byte) (b * ((byte) (j * (i3 % (i4 | 1)))));
            int i5 = b2 + i4;
            i = i4 - 1;
            this.iArrFld[i2] = i5 ^ i;
            long j5 = instanceCount;
            int[] iArr2 = this.iArrFld;
            int i6 = (int) j4;
            int i7 = iArr2[i6];
            iArr2[i6] = i7 + 1;
            instanceCount = j5 + i7;
            int[] iArr3 = this.iArrFld;
            iArr3[i2] = iArr3[i2] ^ i6;
            this.iArrFld[i6] = 77;
            f = i;
            j4++;
            b = (byte) (b2 - 1);
        }
        int i8 = 254;
        int i9 = -29459;
        int i10 = -4;
        int i11 = 10;
        while (i8 > 1) {
            lArrFld[i8] = i;
            i10 = 12;
            while (199 > i10) {
                lArrFld[i8 + 1] = -14;
                if (((i8 % 1) * 5) + 1 == 2) {
                    long j6 = instanceCount << i9;
                    instanceCount = j6;
                    i9 += i10;
                    i11 *= (int) j6;
                }
                this.iArrFld[i10] = iArr[i10] - 9;
                int[] iArr4 = this.iArrFld;
                iArr4[i8] = iArr4[i8] << (-14);
                f = i10;
                i10++;
            }
            i8 -= 2;
        }
        FuzzerUtils.out.println("l i by = " + j4 + "," + i + "," + ((int) b));
        FuzzerUtils.out.println("b2 f1 i17 = 0," + Float.floatToIntBits(f) + "," + i8);
        FuzzerUtils.out.println("i18 i19 i20 = " + i9 + "," + i10 + "," + i11);
        FuzzerUtils.out.println("byArr dArr = " + FuzzerUtils.checkSum(bArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)));
        FuzzerUtils.out.println("Test.instanceCount Test.lArrFld iArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
