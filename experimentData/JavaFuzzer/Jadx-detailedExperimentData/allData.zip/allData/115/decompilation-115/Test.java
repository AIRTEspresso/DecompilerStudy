
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/115/original-115/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = 8059626202638698049L;
    public static int iFld = -8;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    public static void vMeth() {
        int[] iArr = new int[N];
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        int i = 2;
        float[][] fArr = (float[][]) Array.newInstance(float.class, N, N);
        FuzzerUtils.init(iArr, 52023);
        FuzzerUtils.init((Object[][]) jArr, (Object) (-13L));
        FuzzerUtils.init(fArr, 80.593f);
        int i2 = 187;
        int i3 = 30724;
        int i4 = -132;
        double d = 1.3044d;
        long j = 143;
        byte b = 31;
        int i5 = 16;
        while (i5 < 396) {
            double d2 = i5 | 1;
            Double.isNaN(d2);
            d /= d2;
            j = 1;
            while (j < 4) {
                int i6 = i2 + i2 + ((int) (i5 + j));
                i3 = i6 + i6;
                int[] iArr2 = iArr;
                double d3 = j;
                Double.isNaN(d3);
                d *= d3;
                b = (byte) (b + ((byte) (j * j)));
                i4 = i5;
                while (i4 < i) {
                    long[][][] jArr2 = jArr;
                    long[] jArr3 = jArr[(iFld >>> 1) % N][(int) (j - 1)];
                    int i7 = i5 - 1;
                    jArr3[i7] = jArr3[i7] >>> i5;
                    int i8 = i4 + 1;
                    float[] fArr2 = fArr[i8];
                    fArr2[i7] = fArr2[i7] - (-84);
                    if (i3 == 0) {
                        i4 = i8;
                        jArr = jArr2;
                        i = 2;
                    } else {
                        vMeth_check_sum += ((((((((i5 + i3) + Double.doubleToLongBits(d)) + j) + i3) + 0) + b) + i4) - 84) + FuzzerUtils.checkSum(iArr2) + FuzzerUtils.checkSum((Object[][]) jArr2) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
                        return;
                    }
                }
                j++;
                i2 = i3;
                jArr = jArr;
                iArr = iArr2;
                i = 2;
            }
            i5++;
            i = 2;
        }
        vMeth_check_sum += ((((((((i5 + i2) + Double.doubleToLongBits(d)) + j) + i3) + 0) + b) + i4) - 84) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum((Object[][]) jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static int iMeth1(int i, float f, int i2) {
        long j;
        double d;
        int i3;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, 185);
        FuzzerUtils.init(jArr, -13937L);
        int i4 = -4;
        int i5 = 135;
        int i6 = 34616;
        int i7 = 3;
        double d2 = -40.90322d;
        int i8 = 10;
        while (i8 < 385) {
            instanceCount += i8 * i8;
            vMeth();
            i5 = i8;
            while (i5 < 5) {
                int i9 = (((i >>> 1) % 6) * 5) + 39;
                if (i9 == 52) {
                    double d3 = d2;
                    i7 = (int) ((i7 >> ((int) j)) + (instanceCount ^ i5));
                    d2 = d3;
                    i6 = 1;
                } else if (i9 != 56) {
                    if (i9 == 62) {
                        d = d2;
                        instanceCount = i8;
                    } else if (i9 == 65) {
                        i4 <<= i5;
                    } else if (i9 == 68) {
                        d = d2;
                        iFld = (int) (iFld + (((i3 * i5) + instanceCount) - i4));
                    } else if (i9 == 69) {
                        i7 += i5 * i5;
                    } else {
                        iArr[i8 - 1] = (int) d2;
                        d = d2;
                    }
                    d2 = d;
                } else {
                    d2 = i7;
                }
                i5++;
            }
            i8++;
        }
        long floatToIntBits = ((((((i + Float.floatToIntBits(f)) + i2) + i8) + i4) + i5) - 4340) + i6 + i7 + 1 + 123 + Double.doubleToLongBits(d2) + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr);
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static int iMeth() {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, -215);
        long j = instanceCount + 1;
        instanceCount = j;
        iFld = (int) j;
        int i = 141;
        while (i > 4) {
            int i2 = iFld;
            iFld = i2 >> (Integer.reverseBytes(iMeth1(i, -93.958f, i2)) / 1);
            i--;
        }
        int i3 = 7;
        int i4 = 8;
        while (i3 < 267) {
            i4 = 27;
            i3++;
        }
        int i5 = 17;
        int i6 = -63465;
        double d = 1.107505d;
        while (i5 < 320) {
            iFld = i4;
            instanceCount -= 110.576f;
            d = i5;
            while (d < 5.0d) {
                instanceCount = 15723L;
                int i7 = iFld + ((int) (d * d));
                iFld = i7;
                int[] iArr2 = iArr[i5];
                int i8 = i5 - 1;
                iArr2[i8] = iArr2[i8] * i5;
                instanceCount = i7;
                i6 += i7;
                d += 1.0d;
            }
            i5++;
        }
        long floatToIntBits = ((((((((i + i4) + i3) + i6) + i5) - 141) + Float.floatToIntBits(110.576f)) + Double.doubleToLongBits(d)) - 5) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public void mainTest(String[] strArr) {
        double d;
        double d2;
        int i;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(iArr, -7);
        FuzzerUtils.init(jArr, -955183947397554756L);
        int i2 = 60363;
        int i3 = 228;
        int i4 = 18823;
        int i5 = 9;
        while (true) {
            float f = 1.475f;
            int i6 = -31;
            if (201 > i5) {
                int i7 = 1;
                while (true) {
                    i7++;
                    if (i7 < 131) {
                        int i8 = (int) f;
                        iArr[i5] = i8;
                        Double.isNaN(i8);
                        Double.isNaN(i6);
                        int i9 = iFld;
                        iFld = i9 + i9;
                        long j = instanceCount;
                        i2 = (int) (((int) (d + (d2 - (-113.96414999999999d)))) + (((i * i7) + j) - 1));
                        iArr[i5] = iArr[i5] * ((int) j);
                        i4 = 1;
                        f = 1.475f;
                        i6 = -31;
                    }
                }
                i5++;
                i3 = i7;
            } else {
                FuzzerUtils.out.println("i i1 i2 = " + i5 + "," + i2 + "," + i3);
                FuzzerUtils.out.println("by f d = -31," + Float.floatToIntBits(1.475f) + "," + Double.doubleToLongBits(-102.797d));
                FuzzerUtils.out.println("i3 i4 i25 = " + i4 + ",-231,24658");
                FuzzerUtils.out.println("b2 iArr lArr2 = 0," + FuzzerUtils.checkSum(iArr) + "," + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("Test.instanceCount Test.iFld = " + instanceCount + "," + iFld);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
