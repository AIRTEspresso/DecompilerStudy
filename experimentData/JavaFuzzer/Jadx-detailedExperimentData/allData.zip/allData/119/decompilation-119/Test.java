
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/119/original-119/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public float fFld = -2.494f;
    public static long instanceCount = -5;
    public static double dFld = 0.1188d;
    public static short sFld = -20974;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 1.94f);
    }

    public static int iMeth1(int i, int i2, int i3) {
        long j;
        int i4;
        long j2;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 28981L);
        FuzzerUtils.init(iArr, 3);
        int i5 = -12;
        int i6 = -17978;
        float f = 2.226f;
        int i7 = 4;
        while (i7 < 388) {
            jArr[i7 - 1] = -316845889;
            i5 = 4;
            do {
                i3 += i5 * i5;
                double d = dFld;
                i2 *= (int) d;
                double d2 = i5;
                Double.isNaN(d2);
                dFld = d + d2;
                i4 = i7 + 1;
                iArr[i4] = i5;
                j2 = instanceCount;
                f = (float) j2;
                i5--;
            } while (i5 > 0);
            instanceCount = j2 + i7 + i3;
            int i8 = 1;
            do {
                i3 += i5;
                i8++;
            } while (i8 < 4);
            i7 = i4;
            i6 = i8;
        }
        instanceCount = i3;
        long floatToIntBits = i + (i2 * ((int) j)) + i3 + i7 + 185 + Float.floatToIntBits(f) + i5 + 11360 + i6 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static int iMeth() {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(iArr, -56399);
        FuzzerUtils.init(jArr, -13L);
        FuzzerUtils.init(fArr, 1.1f);
        int i = 8207;
        int i2 = 192;
        float f = 116.944f;
        byte b = 13;
        int i3 = 5;
        int i4 = 1;
        int i5 = 1;
        while (i3 < 175) {
            int i6 = i2;
            int i7 = 1;
            while (i7 < 9) {
                long j = i4;
                int i8 = i7;
                long j2 = instanceCount;
                long j3 = -(((float) (j - j2)) + ((((float) j2) + 20.329f) * (-220.0f)));
                instanceCount = j3;
                long[] jArr2 = jArr[i8];
                int i9 = i8 - 1;
                long j4 = jArr2[i9];
                jArr2[i9] = j4 + 1;
                long j5 = j3 / (j4 | 1);
                instanceCount = j5;
                switch ((i3 % 3) + 12) {
                    case 12:
                        iArr[i3] = (i6 + i8 + iMeth1(i3, i3, i6)) * i6;
                        f = 1.0f;
                        int i10 = i6;
                        i6++;
                        while (f < 2.0f) {
                            b = (byte) (b + ((byte) (f * f)));
                            float f2 = i10;
                            int i11 = ((int) (((f * f2) + i3) - f2)) + i6 + ((int) (f | 20.329f));
                            try {
                                i10 = i11 % 27714;
                                iArr[i8] = (-63375) % i8;
                                i10 = i11 / i8;
                            } catch (ArithmeticException e) {
                            }
                            f += 1.0f;
                            i6 = i11;
                        }
                        i4 = (int) (i10 + (((i8 * i6) + i10) - 20.329f));
                        break;
                    case 13:
                        long[] jArr3 = jArr[i8 + 1];
                        int i12 = i3 - 1;
                        jArr3[i12] = jArr3[i12] - j;
                        break;
                    case 14:
                        fArr[i3] = (float) j5;
                        break;
                    default:
                        i5 = 86;
                        break;
                }
                i7 = i8 + 1;
            }
            int i13 = i7;
            i3++;
            i2 = i6;
            i = i13;
        }
        long floatToIntBits = i3 + i4 + i + i2 + Float.floatToIntBits(20.329f) + Float.floatToIntBits(f) + i5 + b + FuzzerUtils.checkSum(iArr) + FuzzerUtils.checkSum(jArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth(int i, int i2) {
        iMeth();
        instanceCount = i;
        vMeth_check_sum += i + i2 + ((short) (-18385));
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        boolean[][][] zArr = (boolean[][][]) Array.newInstance(boolean.class, N, N, N);
        FuzzerUtils.init(jArr, 3L);
        FuzzerUtils.init(iArr, -52838);
        FuzzerUtils.init((Object[][]) zArr, (Object) false);
        vMeth(19, 19);
        double d = dFld;
        double d2 = 19;
        Double.isNaN(d2);
        dFld = d + d2;
        int i3 = 8654;
        int i4 = -8;
        int i5 = -2241;
        int i6 = 19;
        short s = 14;
        int i7 = 8;
        while (true) {
            int i8 = 1;
            int i9 = -28321;
            if (197 <= i7) {
                break;
            }
            jArr[i7] = 1;
            try {
                i6 %= 1405380339;
                iArr[i7 + 1] = i7 % 155;
                s = i6 % i6;
            } catch (ArithmeticException e) {
            }
            i5 = i7;
            while (133 > i5) {
                i3 -= s;
                i4 = i7;
                while (i4 < i8) {
                    float[] fArr = fArrFld;
                    fArr[i4] = fArr[i4] + i6;
                    zArr[i4][i5 + 1] = zArr[i7 - 1][i5];
                    this.fFld *= i9;
                    float f = i4;
                    this.fFld = f;
                    dFld = i7;
                    short s2 = sFld;
                    long j = instanceCount;
                    sFld = (short) (s2 + ((short) (((i4 * (-28321)) + j) - i5)));
                    instanceCount = j >> i5;
                    this.fFld = f - i3;
                    jArr[i5] = -26;
                    i4++;
                    i6 = i5;
                    iArr = iArr;
                    i8 = 1;
                    i9 = -28321;
                }
                int[] iArr2 = iArr;
                int i10 = i7 + 1;
                int i11 = iArr2[i10];
                long j2 = instanceCount;
                iArr2[i10] = i11 >> ((int) j2);
                instanceCount = j2;
                i5++;
                iArr = iArr2;
                i8 = 1;
                i9 = -28321;
            }
            i7++;
        }
        int[] iArr3 = iArr;
        int i12 = (s >> sFld) - i6;
        instanceCount = i6;
        zArr[(i3 >>> 1) % N][(i7 >>> 1) % N][(i12 >>> 1) % N] = false;
        int i13 = 9;
        int i14 = 2;
        int i15 = 8;
        while (i13 < 385) {
            int i16 = 1;
            while (true) {
                i = 1;
                while (i < 4) {
                    instanceCount = ((float) instanceCount) + (((sFld * i) + i5) - this.fFld);
                    int i17 = i16 + 1;
                    jArr[i17] = jArr[i17] + i;
                    i3 = 5;
                    i += 2;
                    i4 = i4;
                }
                i2 = i4;
                i16 += 3;
                if (i16 >= 67) {
                    break;
                }
                i4 = i2;
            }
            i13++;
            i4 = i2;
            int i18 = i;
            i15 = i16;
            i14 = i18;
        }
        FuzzerUtils.out.println("i14 i15 i16 = " + i6 + "," + i7 + "," + i12);
        FuzzerUtils.out.println("i17 i18 i19 = " + i5 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("i20 i21 i22 = -28321," + i13 + ",53858");
        FuzzerUtils.out.println("i23 i24 i25 = " + i15 + "," + i14 + ",-37154");
        FuzzerUtils.out.println("lArr2 iArr2 bArr = " + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(iArr3) + "," + FuzzerUtils.checkSum((Object[][]) zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.dFld fFld = " + instanceCount + "," + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(this.fFld));
        FuzzerUtils.out.println("Test.sFld Test.fArrFld = " + ((int) sFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
