
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/131/original-131/Test.dex */
public class Test {
    public static double[] dArrFld;
    public byte byFld = -123;
    public static long instanceCount = 7;
    public static volatile int iFld = 7957;
    public static volatile double dFld = -65.26047d;
    public static volatile float fFld = 0.954f;
    public static boolean bFld = true;
    public static short sFld = -12381;
    public static final int N = 400;
    public static int[] iArrFld = new int[N];
    public static float[] fArrFld = new float[N];
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;

    static {
        double[] dArr = new double[N];
        dArrFld = dArr;
        FuzzerUtils.init(dArr, 2.93474d);
        FuzzerUtils.init(iArrFld, 61183);
        FuzzerUtils.init(fArrFld, -127.946f);
    }

    public static long lMeth(int i, long j, int i2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -4L);
        long j2 = j;
        int i3 = 2;
        while (i3 < 355) {
            j2 -= -12;
            i3 += 3;
        }
        int i4 = 1;
        int i5 = i;
        int i6 = i2;
        int i7 = 31316;
        int i8 = 6;
        int i9 = 31185;
        int i10 = 1;
        while (true) {
            i10 += i4;
            if (i10 < 333) {
                int i11 = i8;
                int i12 = 5;
                while (i12 > i4) {
                    i11 *= i10;
                    double[] dArr = dArrFld;
                    double d = dArr[i10];
                    double d2 = iFld;
                    Double.isNaN(d2);
                    dArr[i10] = d - d2;
                    int[] iArr = iArrFld;
                    int i13 = i10 + 1;
                    iArr[i13] = iArr[i13] * ((int) j2);
                    jArr[i10 - 1] = (long) dFld;
                    i12--;
                    i5 = -46;
                    i6 = -46;
                }
                int[] iArr2 = iArrFld;
                int i14 = i10 - 1;
                iArr2[i14] = iArr2[i14] - i6;
                int i15 = 1;
                while (i15 < 5) {
                    long j3 = instanceCount - 11;
                    instanceCount = j3;
                    i11 ^= (int) j3;
                    i15++;
                    i5 = i5;
                }
                i7 = i12;
                i8 = i11;
                i9 = i15;
                i4 = 1;
            } else {
                long checkSum = ((((((((((i5 + j2) + i6) + i3) - 46) + i10) + i7) + i8) + 0) + i9) - 11) + FuzzerUtils.checkSum(jArr);
                lMeth_check_sum += checkSum;
                return checkSum;
            }
        }
    }

    public static int iMeth(double d, long j, int i) {
        int i2 = -11;
        int i3 = -6215;
        byte b = -72;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 < 341) {
                if (bFld) {
                    lMeth(i, instanceCount, iFld);
                    int[] iArr = iArrFld;
                    iArr[i4] = iArr[i4] - ((int) fFld);
                }
                i2 = 1;
                while (i2 < 5) {
                    i3 = i2;
                    while (i3 < 2) {
                        int[] iArr2 = iArrFld;
                        int i5 = i2 + 1;
                        iArr2[i5] = iArr2[i5] << (-3294);
                        b = (byte) (b + ((byte) 4));
                        if (bFld) {
                            int i6 = ((i >>> 1) % 2) + 118;
                            if (i6 == 118) {
                                iFld += (int) instanceCount;
                                fFld += i3 * i2;
                            } else if (i6 == 119) {
                                fFld = 4;
                                fArrFld[i4 - 1] = (float) dFld;
                                iFld += i3;
                            } else {
                                instanceCount = (long) d;
                            }
                        } else {
                            double d2 = -3294;
                            Double.isNaN(d2);
                            d -= d2;
                        }
                        i3++;
                    }
                    i2++;
                }
            } else {
                long doubleToLongBits = (((((Double.doubleToLongBits(d) + j) + i) + i4) + i2) - 3294) + i3 + 4 + b;
                iMeth_check_sum += doubleToLongBits;
                return (int) doubleToLongBits;
            }
        }
    }

    public static void vMeth(int i, int i2, float f) {
        byte iMeth;
        boolean[][][] zArr = (boolean[][][]) Array.newInstance(boolean.class, N, N, N);
        FuzzerUtils.init((Object[][]) zArr, (Object) true);
        double d = dArrFld[2];
        double d2 = -66;
        Double.isNaN(d2);
        int i3 = i - ((int) (d * d2));
        int i4 = 1;
        do {
            iMeth = (byte) iMeth(-1.90511d, instanceCount, iFld);
            long j = i4;
            f += (float) (j ^ j);
            i4++;
        } while (i4 < 228);
        iFld <<= i2;
        int i5 = 14;
        int i6 = -13950;
        double d3 = -34.9041d;
        while (i5 < 224) {
            double d4 = dFld;
            double d5 = iFld;
            Double.isNaN(d5);
            dFld = d4 + d5;
            instanceCount = -1L;
            double d6 = 1.0d;
            do {
                d6 += 1.0d;
            } while (d6 < 8.0d);
            i5++;
            d3 = d6;
            i6 = 1;
        }
        vMeth_check_sum += ((((((i3 + i2) + Float.floatToIntBits(f)) + iMeth) + i4) + i5) - 36219) + Double.doubleToLongBits(d3) + i6 + 32 + FuzzerUtils.checkSum((Object[][]) zArr);
    }

    public void mainTest(String[] strArr) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -2L);
        int i = -17202;
        int i2 = -11;
        int i3 = -12903;
        int i4 = 7;
        int i5 = 198;
        int i6 = -8;
        int i7 = 1;
        while (true) {
            i7++;
            if (i7 < 264) {
                byte b = (byte) (this.byFld - ((byte) (i7 * 19819)));
                this.byFld = b;
                long j = instanceCount;
                switch (((((int) (j - i7)) >>> 1) % 9) + 54) {
                    case 54:
                        vMeth(-39985, -172, fFld);
                        iFld += i7;
                        continue;
                    case 55:
                        instanceCount = b;
                        continue;
                    case 56:
                        iFld <<= i7;
                        i = 5;
                        while (i < 95) {
                            i3 = 1;
                            while (3 > i3) {
                                int i8 = (i2 - ((int) fFld)) + this.byFld;
                                dFld = i7;
                                i4 = this.byFld;
                                i2 = i8 << i7;
                                instanceCount = instanceCount;
                                iFld += (i3 * i3) - 95;
                                this.byFld = (byte) i;
                                i3++;
                            }
                            instanceCount = sFld;
                            int i9 = i6;
                            int i10 = 1;
                            while (i10 < 3) {
                                i2 >>= (int) instanceCount;
                                dFld = iFld;
                                i9 -= i3;
                                iArrFld[i - 1] = (int) dFld;
                                int i11 = i7 + 1;
                                jArr[i11] = jArr[i11] + instanceCount;
                                i10++;
                            }
                            i4 -= (int) instanceCount;
                            i2 -= i4;
                            int[] iArr = iArrFld;
                            iArr[i] = iArr[i] * i3;
                            fArrFld[i7 - 1] = i;
                            i += 2;
                            i5 = i10;
                            i6 = i9;
                        }
                        continue;
                    case 57:
                        float[] fArr = fArrFld;
                        fArr[i7] = fArr[i7] * b;
                        continue;
                    case 58:
                    case 59:
                        fFld -= i6;
                        i4 += i7 * i5;
                        break;
                    case 60:
                        i4 += i7 * i5;
                        break;
                    case 61:
                        break;
                    case 62:
                        i4 -= (int) j;
                        continue;
                    default:
                        fFld -= i4;
                        continue;
                }
                iArrFld = FuzzerUtils.int1array(N, 10);
            } else {
                FuzzerUtils.out.println("i i23 i24 = " + i7 + "," + i + "," + i2);
                FuzzerUtils.out.println("i25 i26 i27 = " + i3 + "," + i4 + "," + i5);
                FuzzerUtils.out.println("i28 lArr1 = " + i6 + "," + FuzzerUtils.checkSum(jArr));
                FuzzerUtils.out.println("Test.instanceCount byFld Test.iFld = " + instanceCount + "," + ((int) this.byFld) + "," + iFld);
                FuzzerUtils.out.println("Test.dFld Test.fFld Test.bFld = " + Double.doubleToLongBits(dFld) + "," + Float.floatToIntBits(fFld) + "," + (bFld ? 1 : 0));
                FuzzerUtils.out.println("Test.sFld Test.dArrFld Test.iArrFld = " + ((int) sFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + FuzzerUtils.checkSum(iArrFld));
                FuzzerUtils.out.println("Test.fArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
