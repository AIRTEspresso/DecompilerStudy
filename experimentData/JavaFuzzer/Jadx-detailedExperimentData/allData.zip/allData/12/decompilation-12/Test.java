/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/12/original-12/Test.dex */
public class Test {
    public static final int N = 400;
    public static float[] fArrFld;
    public volatile int[] iArrFld = new int[N];
    public static long instanceCount = 1065939410768721658L;
    public static short sFld = -17924;
    public static boolean bFld = true;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 0.235f);
    }

    public static int iMeth(byte b, int i, int i2) {
        int i3 = -182;
        int i4 = -98;
        int i5 = 12;
        double d = 2.7693d;
        int i6 = 389038952;
        int i7 = 5;
        while (i7 < 163) {
            i3 += (int) instanceCount;
            i4 = i7;
            while (i4 < 10) {
                i5 += i4 * i4;
                d -= 12.0d;
                i4++;
            }
            try {
                i = (-664335621) / i7;
                int i8 = (-12) % i5;
                i6 = i4 % 110;
            } catch (ArithmeticException e) {
            }
            long j = instanceCount;
            instanceCount = j + (((i7 * j) + i) - sFld);
            i7++;
        }
        int i9 = 1;
        do {
            i5 += i9 * i9;
            long j2 = instanceCount;
            i3 <<= (int) j2;
            instanceCount = j2 - i5;
            i *= -24630;
            double d2 = i3;
            Double.isNaN(d2);
            d += d2;
            i9 += 3;
        } while (i9 < 330);
        long floatToIntBits = b + i + i6 + i7 + i3 + Float.floatToIntBits(2.118f) + i4 + i5 + Double.doubleToLongBits(d) + i9;
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1(int i, int i2, int i3) {
        int iMeth = i ^ iMeth((byte) 108, i, -59014);
        float f = 92.659f;
        int i4 = 1;
        while (true) {
            i4++;
            if (i4 < 381) {
                int i5 = (i4 % 2) + 126;
                if (i5 == 126) {
                    f += i4 + 80;
                } else if (i5 != 127) {
                }
                i3 += 793010601;
            } else {
                vMeth1_check_sum += (((((iMeth + i2) + i3) + 108) + i4) - 248) + 11 + 149 + 80 + 7156431638399464735L + Double.doubleToLongBits(2.37983d) + Float.floatToIntBits(f) + 0;
                return;
            }
        }
    }

    public static void vMeth(int i) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 902049967L);
        FuzzerUtils.init(iArr, -185);
        int i2 = 10;
        double d = -2.47648d;
        int i3 = 10;
        int i4 = -168;
        int i5 = 1808;
        float f = -1.305f;
        while (i2 < 337) {
            i4 = i2;
            while (i4 < 5) {
                vMeth1(i3, i, i5);
                i4++;
            }
            d = f;
            jArr[i2 - 1] = 83;
            short s = sFld;
            i3 += s;
            f += s;
            i2++;
            i5 = i4;
        }
        int i6 = i;
        int i7 = 1;
        int i8 = 55450;
        int i9 = 1;
        while (true) {
            i9 += 3;
            if (i9 < 275) {
                int i10 = 17;
                while (i10 > i7) {
                    jArr[i9 + 1] = i2;
                    iArr[i10] = iArr[i10] - (-165);
                    bFld = bFld;
                    i6 <<= i3;
                    i10--;
                }
                instanceCount -= -165;
                i8 = i10;
                i7 = 1;
            } else {
                vMeth_check_sum += (((((((((i6 + i2) + i3) + i4) + i5) + Double.doubleToLongBits(d)) + Float.floatToIntBits(f)) + i9) + i8) - 165) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -3);
        vMeth(-3);
        int i = -56907;
        int i2 = -38985;
        int i3 = 221;
        int i4 = -4528;
        float f = -77.26f;
        int i5 = 1;
        while (true) {
            i5++;
            if (i5 < 290) {
                i = i5;
                while (i < 87) {
                    i3 = i;
                    while (i3 < 1) {
                        f = (float) instanceCount;
                        i4 = 14809;
                        i3++;
                    }
                    i4 = (int) (i4 + (((i * instanceCount) + sFld) - i5));
                    i++;
                    i2 = 0;
                }
            } else {
                FuzzerUtils.out.println("i23 i24 i25 = " + i5 + "," + i + ",0");
                FuzzerUtils.out.println("i26 d3 f3 = " + i2 + "," + Double.doubleToLongBits(-2.26414d) + "," + Float.floatToIntBits(f));
                FuzzerUtils.out.println("by2 i27 i28 = -56," + i3 + "," + i4);
                FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(iArr));
                FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + instanceCount + "," + ((int) sFld) + "," + (bFld ? 1 : 0));
                FuzzerUtils.out.println("iArrFld Test.fArrFld = " + FuzzerUtils.checkSum(this.iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
