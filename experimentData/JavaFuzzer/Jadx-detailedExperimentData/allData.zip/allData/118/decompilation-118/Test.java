/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/118/original-118/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public int iFld = -8;
    public long[] lArrFld = new long[N];
    public static long instanceCount = 21295;
    public static boolean bFld = true;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long bMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 8);
    }

    public boolean bMeth() {
        long floatToIntBits = Float.floatToIntBits(8895.508f);
        bMeth_check_sum += floatToIntBits;
        return floatToIntBits % 2 > 0;
    }

    public void vMeth1() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -189);
        boolean bMeth = bMeth();
        int i = -46;
        double d = 0.127445d;
        int i2 = 1;
        while (i2 < 247) {
            instanceCount = -234;
            i = 1;
            while (i < 7) {
                long[] jArr = this.lArrFld;
                i++;
                jArr[i] = jArr[i] - (-234);
                iArr[(i2 >>> 1) % N] = i2;
                d = 2.0d;
            }
            i2++;
        }
        vMeth1_check_sum += (((bMeth ? 1 : 0) + i2) - 234) + i + 14 + Double.doubleToLongBits(d) + Float.floatToIntBits(63.29f) + FuzzerUtils.checkSum(iArr);
    }

    public void vMeth(int i, int i2) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, 3);
        FuzzerUtils.init(fArr, 2.564f);
        iArr[(i2 >>> 1) % N] = i;
        int i3 = i;
        double d = 2.82964d;
        int i4 = 10;
        int i5 = -1406;
        int i6 = 48;
        int i7 = 7;
        int i8 = -21450;
        int i9 = 213;
        while (i4 < 215) {
            long[] jArr = this.lArrFld;
            long j = jArr[i4];
            float f = fArr[47];
            float[] fArr2 = fArr;
            int i10 = iArr[i4] + 1;
            iArr[i4] = i10;
            float f2 = f + i10;
            int i11 = i8;
            int i12 = i9;
            jArr[i4] = j - f2;
            vMeth1();
            instanceCount += i4;
            switch ((i4 % 10) + 45) {
                case 45:
                    i8 = i11;
                    int i13 = i4;
                    i9 = i12;
                    while (i13 < 8) {
                        double d2 = i5 | 1;
                        Double.isNaN(d2);
                        d %= d2;
                        if ((((i7 >>> 1) % 1) * 5) + 58 == 60) {
                            this.lArrFld[i4] = -82;
                            i3 += i13;
                            i9 &= -92;
                        } else {
                            i7 = i2;
                        }
                        i13++;
                        i8 = 1;
                    }
                    i6 = i13;
                    break;
                case 46:
                    i7 += i4 * 32613;
                case 47:
                    i5 += 61659;
                case 48:
                    i7 &= (int) instanceCount;
                    i8 = i11;
                    i9 = i12;
                    break;
                case 49:
                    i5 += this.iFld ^ i4;
                    i8 = i11;
                    i9 = i12;
                    break;
                case 50:
                    iArr[i4] = i5;
                    i8 = i11;
                    i9 = i12;
                    break;
                case 51:
                    int i14 = i4 + 1;
                    iArr[i14] = iArr[i14] + 11099;
                case 52:
                    instanceCount = this.iFld;
                    i8 = i11;
                    i9 = i12;
                    break;
                case 53:
                    i3 += i4;
                    i8 = i11;
                    i9 = i12;
                    break;
                case 54:
                    i7 += i5;
                    i8 = i11;
                    i9 = i12;
                    break;
                default:
                    iArr[i4] = i2;
                    i8 = i11;
                    i9 = i12;
                    break;
            }
            i4++;
            fArr = fArr2;
        }
        vMeth_check_sum += (((((((((i3 + i2) + i4) + i5) + i6) + i7) + Double.doubleToLongBits(d)) + i8) + i9) - 92) + 32613 + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public void mainTest(String[] strArr) {
        vMeth(-36, -33116);
        int i = 10;
        int i2 = 6;
        int i3 = 44982;
        float f = -103.643f;
        float f2 = -88.139f;
        int i4 = 21;
        while (i4 < 397) {
            try {
                int i5 = this.iFld % (this.iFld / 117);
                this.iFld = i5;
                i2 = i4 / i5;
            } catch (ArithmeticException e) {
            }
            int i6 = ((i4 % 10) * 5) + 30;
            int i7 = 1;
            if (i6 != 34) {
                if (i6 != 39) {
                    if (i6 != 62) {
                        if (i6 == 65) {
                            instanceCount = i4;
                        } else if (i6 == 73) {
                            int[] iArr = iArrFld;
                            iArr[i4] = iArr[i4] >> i;
                        } else if (i6 != 76) {
                            if (i6 != 51) {
                                if (i6 != 52) {
                                    if (i6 == 67) {
                                        while (i7 < 67) {
                                            f -= 55.0f;
                                            long[] jArr = this.lArrFld;
                                            jArr[i7 - 1] = i4;
                                            iArrFld[i7] = 5;
                                            if (bFld) {
                                                int i8 = i4 - 1;
                                                jArr[i8] = jArr[i8] * instanceCount;
                                                i3 += 1604715977;
                                            } else {
                                                i2 = (i2 * 2) + (((i7 * i3) + this.iFld) - i7);
                                                f2 = 2.0f;
                                            }
                                            long j = instanceCount + i7;
                                            instanceCount = j;
                                            i2 = (i2 - this.iFld) * ((int) j);
                                            if (bFld) {
                                                break;
                                            }
                                            i7++;
                                        }
                                        int[] iArr2 = iArrFld;
                                        int i9 = i4 - 1;
                                        iArr2[i9] = iArr2[i9] + 63;
                                        i = i7;
                                    } else if (i6 == 68) {
                                        i3 -= 20050;
                                    } else {
                                        instanceCount = -90L;
                                    }
                                }
                            }
                            this.iFld = (int) (this.iFld + i4 + instanceCount);
                        }
                    }
                    long j2 = this.iFld;
                    instanceCount = j2;
                    instanceCount = j2 + (((i4 * i4) + j2) - i4);
                } else {
                    this.iFld >>>= -83;
                }
                i2 += (int) instanceCount;
            } else {
                int[] iArr3 = iArrFld;
                int i10 = i4 - 1;
                iArr3[i10] = iArr3[i10] >>> 1;
            }
            i4++;
        }
        FuzzerUtils.out.println("i12 i13 i14 = " + i4 + "," + i2 + "," + i);
        FuzzerUtils.out.println("i15 f3 f4 = " + i3 + "," + Float.floatToIntBits(f) + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("s1 = -20050");
        FuzzerUtils.out.println("Test.instanceCount iFld Test.bFld = " + instanceCount + "," + this.iFld + "," + (bFld ? 1 : 0));
        FuzzerUtils.out.println("lArrFld Test.iArrFld = " + FuzzerUtils.checkSum(this.lArrFld) + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("bMeth_check_sum: " + bMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
