
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/137/original-137/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long instanceCount = 50760;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 178);
    }

    public static void vMeth1(int i, int i2) {
        float f;
        float f2;
        int[] iArr;
        int i3;
        long j = instanceCount;
        instanceCount = j;
        int i4 = (int) j;
        int i5 = 1;
        byte b = 122;
        double d = -2.12627d;
        do {
            f = i2;
            long j2 = instanceCount;
            i4 = i4 + i5 + i5;
            b = (byte) (((byte) (b + ((byte) j2))) >>> ((byte) j2));
            i2 = (i2 + 9) >> 12;
            f2 = 6.0f;
            while (1.0f < f2) {
                d = i4;
                i4 += (int) (f2 * f2);
                f2 -= 1.0f;
                iArrFld[(int) f2] = iArr[i3] - 196;
            }
            i5++;
        } while (i5 < 257);
        vMeth1_check_sum += (((((((i4 + i2) + i5) + Float.floatToIntBits(f)) + b) + 0) + Float.floatToIntBits(f2)) - 91) + Double.doubleToLongBits(d);
    }

    public static void vMeth() {
        float f;
        short[] sArr = new short[N];
        float[] fArr = new float[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(sArr, (short) -16151);
        FuzzerUtils.init(fArr, 4.417f);
        FuzzerUtils.init(jArr, 33896L);
        int i = 1;
        int i2 = 233;
        short s = -24032;
        float f2 = -75.288f;
        long j = 77;
        while (true) {
            try {
                i2 = ((-12447) / (iArrFld[i + 1] % (-2083200514))) % (-470138837);
            } catch (ArithmeticException e) {
            }
            short s2 = (short) (s - 1);
            instanceCount = s;
            short[] short1array = FuzzerUtils.short1array(N, (short) 8297);
            int i3 = i - 1;
            float f3 = fArr[i3];
            fArr[i3] = f3 - 1.0f;
            int i4 = i2 + ((int) f3);
            float abs = Math.abs(i) - (f2 - 1.0f);
            int i5 = i4 - 1;
            float f4 = abs + i4;
            int[] iArr = iArrFld;
            iArr[i] = iArr[i] + ((int) jArr[i]);
            int i6 = 13;
            while (true) {
                i6--;
                if (i6 <= 0) {
                    break;
                }
                instanceCount += f4 + f;
                i5 = i6 * ((i - i) + i5 + i);
                vMeth1(i6, -64);
                instanceCount -= 12;
                j = 1;
                f4 -= 1.0f;
            }
            i++;
            if (i < 123) {
                i2 = i5;
                s = s2;
                f2 = f4;
            } else {
                vMeth_check_sum += i + i5 + s2 + Float.floatToIntBits(f4) + i6 + j + 50204 + FuzzerUtils.checkSum(short1array) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(jArr);
                return;
            }
        }
    }

    public static int iMeth(int i, long j) {
        long[][][] jArr = (long[][][]) Array.newInstance(long.class, N, N, N);
        FuzzerUtils.init((Object[][]) jArr, (Object) (-12L));
        double d = 1.0d;
        while (true) {
            d += 1.0d;
            if (d >= 361.0d) {
                break;
            }
            int[] iArr = iArrFld;
            int i2 = (int) (d + 1.0d);
            iArr[i2] = iArr[i2] + 1;
            vMeth();
        }
        instanceCount <<= 11096;
        long[][] jArr2 = jArr[42];
        int i3 = (i >>> 1) % N;
        jArr2[61] = jArr[i3][i3];
        float f = 236.0f;
        int i4 = 8280;
        while (f > 3.0f) {
            int i5 = (int) f;
            int i6 = ((int) (i4 + ((f * f) - 20827.0f))) - i5;
            i += i5;
            int[] iArr2 = iArrFld;
            iArr2[i5] = iArr2[i5] + i;
            float f2 = f - 1.0f;
            int i7 = (int) f2;
            iArr2[i7] = iArr2[i7] * ((int) j);
            i4 = i6 + ((int) (f + ((float) instanceCount)));
            f = f2;
        }
        long doubleToLongBits = i + j + Double.doubleToLongBits(d) + 4 + Float.floatToIntBits(f) + i4 + FuzzerUtils.checkSum((Object[][]) jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        long j = instanceCount;
        int iMeth = (int) ((5 - (6 + j)) + 6 + iMeth(6, j));
        instanceCount = 0L;
        FuzzerUtils.out.println("i = " + (iMeth ^ iMeth));
        FuzzerUtils.out.println("Test.instanceCount Test.iArrFld = " + instanceCount + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
