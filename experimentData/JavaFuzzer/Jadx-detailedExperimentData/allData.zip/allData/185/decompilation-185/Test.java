
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/185/original-185/Test.dex */
public class Test {
    public static float[] fArrFld;
    public int[] iArrFld = new int[N];
    public volatile short[][] sArrFld = (short[][]) Array.newInstance(short.class, N, N);
    public static long instanceCount = -7508667705143825334L;
    public static boolean bFld = false;
    public static float fFld = 0.493f;
    public static byte byFld = 122;
    public static volatile double dFld = -111.16741d;
    public static final int N = 400;
    public static long[] lArrFld = new long[N];
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long fMeth_check_sum = 0;

    static {
        float[] fArr = new float[N];
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 111.209f);
        FuzzerUtils.init(lArrFld, -293861417053480438L);
    }

    public static float fMeth(long j, int i) {
        int i2 = (int) j;
        short s = 24803;
        double d = -2266.8347d;
        int i3 = 10;
        int i4 = i2;
        int i5 = 1;
        int i6 = 5;
        while (i3 < 331) {
            i4 *= i4;
            s = (short) i2;
            lArrFld[i3] = i3;
            i5 *= i5;
            if (!bFld) {
                i6 = 1;
                while (i6 < 5) {
                    i6++;
                }
                float f = fFld - byFld;
                fFld = f;
                i5 = (int) f;
                d = 11;
            }
            i3++;
        }
        bFld = bFld;
        long doubleToLongBits = j + i4 + Double.doubleToLongBits(d) + i3 + i5 + s + i6 + 11;
        fMeth_check_sum += doubleToLongBits;
        return (float) doubleToLongBits;
    }

    public static void vMeth(int i) {
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(zArr, false);
        float f = fArrFld[(i >>> 1) % N];
        long j = instanceCount;
        int fMeth = (int) (f + ((float) (j * j)) + fMeth(114L, i));
        int i2 = -19049;
        int i3 = 38056;
        int i4 = 3;
        int i5 = -11;
        int i6 = 7;
        while (i6 < 321) {
            i2 = i6;
            while (i2 < 5) {
                i3 *= i2;
                float[] fArr = fArrFld;
                int i7 = i6 - 1;
                fArr[i7] = fArr[i7] - (-3.26008576E9f);
                i2++;
            }
            float[] fArr2 = fArrFld;
            int i8 = i6 - 1;
            fArr2[i8] = fArr2[i8] * i2;
            byFld = (byte) (byFld + ((byte) (((i6 * fMeth) + instanceCount) - i2)));
            int i9 = 1;
            while (i9 < 5) {
                i5 = 2;
                i9++;
            }
            i6++;
            i4 = i9;
        }
        vMeth_check_sum += ((((((fMeth + i6) + 53006) + i2) + i3) + i4) - 60282) + i5 + 17629 + FuzzerUtils.checkSum(zArr);
    }

    public static int iMeth(boolean z, int i, int i2) {
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) (-51563));
        vMeth(i);
        float[] fArr = fArrFld;
        int length = fArr.length;
        int i3 = 0;
        while (i3 < length) {
            float f = fArr[i3];
            dFld = instanceCount;
            fFld -= i2;
            long j = instanceCount;
            instanceCount = j - j;
            i3++;
            i2 = 0;
        }
        int i4 = -132;
        int i5 = 4;
        while (i5 < 392) {
            i4 = 4;
            while (true) {
                i4--;
                if (i4 > 0) {
                    int i6 = i5 - 1;
                    iArr[i6][i6][i4] = (int) instanceCount;
                }
            }
            i5++;
        }
        long checkSum = (((((((z ? 1 : 0) + i) + i2) + i5) + 4) + i4) - 1407) + FuzzerUtils.checkSum((Object[][]) iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        long[] jArr;
        int[] iArr;
        int i;
        int i2;
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -101);
        int[] iArr2 = this.iArrFld;
        iArr2[43] = iArr2[43] >> iMeth(bFld, -6, -6);
        lArrFld[5] = jArr[5] - 6;
        int[] iArr3 = this.iArrFld;
        int length = iArr3.length;
        int i3 = -2;
        int i4 = 9;
        int i5 = 251;
        int i6 = -4;
        float f = 0.16f;
        long j = -3;
        int i7 = -12;
        int i8 = 0;
        while (i8 < length) {
            int i9 = i7;
            long j2 = j;
            float f2 = f;
            int i10 = i6;
            int i11 = i5;
            int i12 = iArr3[i8];
            i4 = 63;
            while (i4 > 1) {
                i12 = (i12 % (i12 | 1)) - 82;
                int i13 = i4 + 1;
                bArr[i13] = (byte) (bArr[i13] - byFld);
                instanceCount *= i11;
                int i14 = i3;
                float f3 = 1.0f;
                while (f3 < 3.0f) {
                    i12 *= i14;
                    i14 -= i4;
                    f3 += 1.0f;
                }
                long j3 = 1;
                while (true) {
                    iArr = iArr3;
                    i = length;
                    int i15 = (int) (((j3 % 4) * 5) + 71);
                    if (i15 == 82) {
                        i2 = i8;
                        i12 *= i10;
                        instanceCount = i14;
                        fFld = -37624.0f;
                    } else if (i15 == 89) {
                        i2 = i8;
                        i9 += (int) (j3 * j3);
                        int[] iArr4 = this.iArrFld;
                        int i16 = (int) (j3 - 1);
                        iArr4[i16] = iArr4[i16] >>> ((int) j3);
                        int i17 = i4 - 1;
                        iArr4[i17] = iArr4[i17] + i14;
                    } else if (i15 == 84) {
                        i2 = i8;
                        if (bFld) {
                            int i18 = (int) j3;
                            short[] sArr = this.sArrFld[(int) (j3 + 1)];
                            sArr[i4] = (short) (sArr[i4] * ((short) i4));
                            i9 = i9 + i18 + i18;
                        }
                        long[] jArr2 = lArrFld;
                        int i19 = (int) j3;
                        jArr2[i19] = jArr2[i19] + i4;
                        i11 -= i4;
                        i10 = -191;
                    } else if (i15 == 85) {
                        i2 = i8;
                        fFld += (float) j3;
                    } else {
                        i2 = i8;
                        instanceCount *= i4;
                    }
                    j3++;
                    if (j3 >= 3) {
                        break;
                    }
                    iArr3 = iArr;
                    i8 = i2;
                    length = i;
                }
                i4 -= 2;
                iArr3 = iArr;
                j2 = j3;
                f2 = f3;
                i3 = i14;
                i8 = i2;
                length = i;
            }
            i8++;
            i5 = i11;
            i6 = i10;
            f = f2;
            j = j2;
            i7 = i9;
        }
        FuzzerUtils.out.println("i20 i22 i23 = " + i7 + "," + i4 + "," + i5);
        FuzzerUtils.out.println("f1 i24 l1 = " + Float.floatToIntBits(f) + "," + i3 + "," + j);
        FuzzerUtils.out.println("i25 byArr = " + i6 + "," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.fFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.byFld Test.dFld iArrFld = " + ((int) byFld) + "," + Double.doubleToLongBits(dFld) + "," + FuzzerUtils.checkSum(this.iArrFld));
        FuzzerUtils.out.println("Test.fArrFld Test.lArrFld sArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(this.sArrFld));
        FuzzerUtils.out.println("fMeth_check_sum: " + fMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
