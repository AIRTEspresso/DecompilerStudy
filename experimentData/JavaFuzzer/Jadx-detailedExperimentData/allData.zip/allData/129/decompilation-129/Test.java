/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/129/original-129/Test.dex */
public class Test {
    public static final int N = 400;
    public double dFld = -15.3741d;
    public static long instanceCount = -9197421431258648103L;
    public static float fFld = -2.584f;
    public static int iFld = 5;
    public static boolean bFld = true;
    public static volatile int iFld1 = 38602;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;

    public static long lMeth(boolean z, byte b, long j) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -29303);
        int i = -46813;
        int i2 = -9;
        int i3 = -13;
        short s = -17359;
        long j2 = 1;
        while (134 > j2) {
            i2 = 1;
            while (i2 < 12) {
                i3 |= i3;
                s = b;
                i = i + i2 + ((i2 * i2) - 14) + i3;
                i2++;
            }
            int i4 = (int) (((j2 % 3) * 5) + 66);
            if (i4 == 71) {
                fFld -= 10301.0f;
                int i5 = (int) (j2 + 1);
                iArr[i5] = iArr[i5] + ((int) instanceCount);
                i += i3;
            } else if (i4 == 72) {
                i3 /= i3 | 1;
            } else if (i4 != 74) {
            }
            j2++;
        }
        long checkSum = (((((((((b + (z ? 1 : 0)) + j) + j2) + i) + i2) + i3) + s) - 6) - 35261) + 1 + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += checkSum;
        return checkSum;
    }

    public static void vMeth(long j) {
        int i;
        int i2;
        double d;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 4);
        double d2 = 1.0d;
        byte b = 111;
        int i3 = -20569;
        int i4 = -4;
        int i5 = 33738;
        long j2 = 227;
        double d3 = 1.0d;
        while (true) {
            double d4 = d3 + d2;
            int abs = (Math.abs(203) - iArr[(int) d4]) - ((b + 203) - 203);
            int i6 = 1;
            while (true) {
                int i7 = 6;
                if (i6 >= 5) {
                    break;
                }
                int i8 = 1;
                while (true) {
                    i = 2;
                    if (i8 >= 2) {
                        break;
                    }
                    i3 = (int) (i3 + (i8 ^ instanceCount));
                    i8++;
                    b = b;
                }
                i5 = 1;
                while (true) {
                    if (i5 >= i) {
                        i2 = i8;
                        d = d3;
                        break;
                    }
                    int i9 = i3 + i5;
                    b = (byte) (((byte) (58.0f - ((fFld - 2.864f) + i9))) | b);
                    int i10 = iArr[i5];
                    double d5 = i6 * 6;
                    i2 = i8;
                    double d6 = i7;
                    Double.isNaN(d6);
                    Double.isNaN(d5);
                    double d7 = d5 + (d3 - d6);
                    long j3 = instanceCount + 1;
                    instanceCount = j3;
                    d = d3;
                    double d8 = j3 - (-(30233 - (i5 + i5)));
                    Double.isNaN(d8);
                    iArr[i5] = i10 * ((int) (d7 * d8));
                    abs %= (int) (lMeth(bFld, b, 12L) | 1);
                    if (bFld) {
                        i3 = i9;
                        break;
                    }
                    iFld += 142;
                    i5++;
                    i8 = i2;
                    i3 = i9;
                    d3 = d;
                    i = 2;
                    i7 = 6;
                }
                j2 = 1;
                while (j2 < 2) {
                    i3 += 77;
                    fFld += (float) (((iFld * j2) + instanceCount) - (-177));
                    j2++;
                    i2 = i2;
                    b = b;
                }
                i6++;
                i4 = i2;
                d3 = d;
            }
            byte b2 = b;
            if (d4 < 323.0d) {
                b = b2;
                d3 = d4;
                d2 = 1.0d;
            } else {
                vMeth_check_sum += ((((((j + Double.doubleToLongBits(d4)) + b2) + i6) + i3) + i4) - 177) + i5 + 6 + j2 + 77 + FuzzerUtils.checkSum(iArr);
                return;
            }
        }
    }

    public static int iMeth(long j, int i) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -6L);
        FuzzerUtils.init(iArr, -29624);
        vMeth(instanceCount);
        jArr[0] = instanceCount;
        iArr[356] = iArr[356] - i;
        short s = (short) ((-5847) - ((short) i));
        byte b = 117;
        int i2 = 12;
        while (i2 < 283) {
            instanceCount = -177L;
            b = (byte) (b * 108);
            jArr[i2] = fFld;
            i = -10;
            i2++;
        }
        iFld = -123;
        int i3 = 13;
        while (i3 < 389) {
            j <<= 2781;
            iFld = i;
            fFld *= -8.0f;
            i3++;
        }
        long checkSum = j + i + s + i2 + 2781 + b + i3 + 45708 + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -141);
        int i = -130;
        float f = 0.48f;
        byte b = 74;
        short s = -2402;
        int i2 = 1;
        while (true) {
            int i3 = i + 1;
            f *= i - iArr[i2];
            iArr[i2] = iArr[i2] * (Math.max(i3, (int) (instanceCount * i3)) + Math.min(i2, iMeth(instanceCount, i3) * (-34466)));
            b = (byte) (b + 118);
            int i4 = i2 + 1;
            iArr[i4] = iFld;
            iFld = i2;
            int i5 = 5;
            while (i5 < 186) {
                i3 += i5 | 51760;
                int i6 = iFld1;
                iFld = i6;
                iFld = i6 + iFld1;
                iArr[i5] = iArr[i5] - i3;
                s = (short) (s << (-30424));
                i5++;
            }
            iFld += i5;
            int i7 = 1;
            do {
                f += f;
                i7++;
            } while (i7 < 186);
            if (i4 < 135) {
                i2 = i4;
                i = i3;
            } else {
                FuzzerUtils.out.println("i f i1 = " + i4 + "," + Float.floatToIntBits(f) + "," + i3);
                FuzzerUtils.out.println("by3 i20 i21 = " + ((int) b) + "," + i5 + ",51760");
                FuzzerUtils.out.println("s2 i22 i23 = " + ((int) s) + "," + i7 + ",1");
                FuzzerUtils.out.println("i24 i25 i26 = -14,1,-15920");
                FuzzerUtils.out.println("iArr = " + FuzzerUtils.checkSum(iArr));
                FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.iFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + iFld);
                FuzzerUtils.out.println("Test.bFld Test.iFld1 dFld = " + (bFld ? 1 : 0) + "," + iFld1 + "," + Double.doubleToLongBits(this.dFld));
                FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
