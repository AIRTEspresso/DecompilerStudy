
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/13/original-13/Test.dex */
public class Test {
    public static final int N = 400;
    public static long[] lArrFld;
    public static volatile long instanceCount = -216;
    public static float fFld = -61.376f;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        long[] jArr = new long[N];
        lArrFld = jArr;
        FuzzerUtils.init(jArr, 210L);
    }

    public static int iMeth(int i) {
        int i2;
        int i3;
        int[] iArr = new int[N];
        byte[] bArr = new byte[N];
        FuzzerUtils.init(bArr, (byte) -111);
        FuzzerUtils.init(iArr, -5993);
        int i4 = -7;
        int i5 = 32523;
        float f = 0.224f;
        int i6 = 1;
        do {
            i2 = i6;
            while (8 > i2) {
                i2++;
                bArr[i2] = (byte) fFld;
                f = 1.0f;
            }
            i3 = 1;
            while (8 > i3) {
                i3++;
                iArr[i3] = i;
                i4 = -2;
                i5 = (i5 * ((int) (-100.122643d))) - ((int) fFld);
            }
            i6++;
        } while (i6 < 212);
        long floatToIntBits = i + i6 + i2 + i4 + Float.floatToIntBits(f) + i5 + 24645 + i3 + 237 + Double.doubleToLongBits(-100.122643d) + FuzzerUtils.checkSum(bArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += floatToIntBits;
        return (int) floatToIntBits;
    }

    public static void vMeth1(double d) {
        int[] iArr = new int[N];
        float[] fArr = new float[N];
        FuzzerUtils.init(iArr, -30115);
        FuzzerUtils.init(fArr, -93.2f);
        double d2 = d;
        int i = 0;
        int i2 = -51287;
        int i3 = 24534;
        int i4 = -36668;
        byte b = 99;
        for (int i5 = N; i < i5; i5 = N) {
            int i6 = iArr[i];
            double d3 = (fFld + 199.0f) * ((float) (instanceCount + i6));
            double d4 = i6 + 1;
            Double.isNaN(d4);
            Double.isNaN(d4);
            Double.isNaN(d3);
            int i7 = (int) (d3 - (d4 + (d2 * d4)));
            byte b2 = b;
            int i8 = i4;
            int i9 = i3;
            int i10 = i7;
            i2 = 1;
            while (i2 < 4) {
                d2 = i9;
                i9--;
                Double.isNaN(d2);
                Double.isNaN(d2);
                long[] jArr = lArrFld;
                int[] iArr2 = iArr;
                long j = jArr[i2] - 1;
                jArr[i2] = j;
                double d5 = j;
                Double.isNaN(d5);
                i10 += (int) ((d2 - d2) + d5);
                iArr2[i2] = iArr2[i2] >> iMeth(i10);
                i8 = 1;
                while (i8 < 2) {
                    d2 = instanceCount;
                    long j2 = i8;
                    b2 = (byte) (b2 + ((byte) (((instanceCount * j2) + b2) - j2)));
                    i10 -= i8;
                    i8++;
                }
                i2++;
                iArr = iArr2;
            }
            int[] iArr3 = iArr;
            fFld = -8;
            int i11 = i10 << (-8);
            i3 = i9 >> 0;
            iArr3[(i11 >>> 1) % N] = (int) instanceCount;
            instanceCount *= i3;
            int i12 = (i8 >>> 1) % N;
            fArr[i12] = fArr[i12] - i8;
            i++;
            i4 = i8;
            b = b2;
            iArr = iArr3;
        }
        vMeth1_check_sum += ((((Double.doubleToLongBits(d2) + i2) + i3) + i4) - 8) + b + FuzzerUtils.checkSum(iArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vMeth(int i, int i2, int i3) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 60);
        vMeth1(1.23456d);
        vMeth_check_sum += ((((((i + i2) + i3) + Double.doubleToLongBits(1.23456d)) + 157) + 9) - 10) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(iArr, 85);
        FuzzerUtils.init(zArr, false);
        int i = iArr[46][46] - 89672;
        vMeth(i, i, i);
        instanceCount += fFld;
        int[] iArr2 = iArr[(i >>> 1) % N];
        iArr2[1] = iArr2[1] - i;
        long j = (-14) - i;
        int i2 = 9;
        while (i2 < 268) {
            zArr[i2] = false;
            i2++;
        }
        FuzzerUtils.out.println("i s l = " + i + ",22418," + j);
        FuzzerUtils.out.println("i20 i21 b = " + i2 + ",40601,0");
        FuzzerUtils.out.println("f1 i22 by1 = " + Float.floatToIntBits(61.641f) + ",119,-67");
        FuzzerUtils.out.println("i23 d3 iArr = 31," + Double.doubleToLongBits(-2.117728d) + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("bArr = " + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.lArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + FuzzerUtils.checkSum(lArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
