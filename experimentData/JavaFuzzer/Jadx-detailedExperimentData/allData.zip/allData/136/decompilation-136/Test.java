
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/136/original-136/Test.dex */
public class Test {
    public byte byFld = 97;
    public volatile int iFld1 = 95;
    public static long instanceCount = -252;
    public static int iFld = 205;
    public static short sFld = 32195;
    public static float fFld = -65.822f;
    public static final int N = 400;
    public static double[] dArrFld = new double[N];
    public static float[][] fArrFld = (float[][]) Array.newInstance(float.class, N, N);
    public static boolean[] bArrFld = new boolean[N];
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long iMeth2_check_sum = 0;

    static {
        FuzzerUtils.init(dArrFld, 0.93006d);
        FuzzerUtils.init(fArrFld, 2.57f);
        FuzzerUtils.init(bArrFld, true);
    }

    public static int iMeth2() {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -26657);
        double d = iFld;
        int i = 87;
        long j = -3484110969561352279L;
        float f = 119.386f;
        int i2 = 10;
        while (i2 < 252) {
            int i3 = i2 - 1;
            iArr[i3] = iArr[i3] + sFld;
            int i4 = iFld;
            iFld = i4 - i4;
            long j2 = 1;
            do {
                f += (float) j2;
                int i5 = (int) j2;
                iFld = i5;
                dArrFld[i5] = i2;
                j2++;
            } while (j2 < 7);
            f /= (float) (1 | f);
            i2++;
            j = j2;
            i = -27680;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + i2 + i + j + Float.floatToIntBits(f) + 1 + FuzzerUtils.checkSum(iArr);
        iMeth2_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static int iMeth1(float f) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -10);
        iFld = iMeth2();
        int i = -67;
        int i2 = -2;
        int i3 = 64287;
        int i4 = -59583;
        int i5 = 7;
        int i6 = 4;
        while (true) {
            int i7 = 1;
            if (i6 < 375) {
                i2 = 1;
                while (i2 < 5) {
                    i -= i2;
                    int i8 = i3 + i2;
                    instanceCount *= i8;
                    i3 = (int) (i8 + (i2 - f));
                    i2++;
                }
                iFld += 115;
                while (i7 < 5) {
                    instanceCount = i;
                    i7++;
                    i5 = 115;
                }
                iArr[i6 - 1] = (int) 0.64899d;
                i6++;
                i4 = i7;
            } else {
                long floatToIntBits = Float.floatToIntBits(f) + i6 + i + i2 + i3 + 1 + 115 + i4 + i5 + FuzzerUtils.checkSum(iArr);
                iMeth1_check_sum += floatToIntBits;
                return (int) floatToIntBits;
            }
        }
    }

    public static int iMeth(long j) {
        int[] iArr = new int[N];
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -50L);
        FuzzerUtils.init(iArr, -3);
        int i = 1;
        while (true) {
            i++;
            if (i >= 221) {
                break;
            }
            long j2 = jArr[i];
            int i2 = iFld;
            iFld = i2 - 1;
            jArr[i] = j2 >> i2;
            sFld = (short) (sFld + ((short) (i * i)));
        }
        iMeth1(124.606f);
        iFld += (int) instanceCount;
        int i3 = 18;
        int i4 = 14;
        double d = -1.7973d;
        while (i3 < 302) {
            i4 = 1;
            while (i4 < 6) {
                double d2 = -8726;
                Double.isNaN(d2);
                d += d2;
                instanceCount <<= -8726;
                i4++;
            }
            iArr[i3] = iArr[i3] - 12;
            i3++;
        }
        iArr[(i >>> 1) % N] = i3;
        fFld -= (float) j;
        long doubleToLongBits = (((j + i) + i3) - 8726) + i4 + (44889 - i) + Double.doubleToLongBits(d) + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -11);
        int i = iFld;
        int i2 = (i >>> 1) % N;
        int i3 = iArr[i2];
        double max = Math.max(i, i);
        Double.isNaN(max);
        double iMeth = iMeth(instanceCount);
        Double.isNaN(iMeth);
        iArr[i2] = i3 >> ((int) ((max + 1.97296d) + iMeth));
        int i4 = 41;
        int i5 = 20;
        int i6 = -4;
        int i7 = -56;
        int i8 = -620;
        int i9 = 4;
        long j = -8632283117275854122L;
        int i10 = 2;
        while (i10 < 179) {
            long j2 = instanceCount;
            instanceCount = j2;
            iFld = (int) j2;
            i5 = 2;
            while (i5 < 142) {
                sFld = (short) (sFld + ((short) i5));
                fArrFld[i5][i5] = i6;
                j = i5;
                while (j < 2) {
                    this.byFld = (byte) (this.byFld << ((byte) this.iFld1));
                    j++;
                }
                long j3 = instanceCount - fFld;
                instanceCount = j3;
                int i11 = i5 - 1;
                int i12 = (int) j;
                iArr[i11] = iArr[i11] - i12;
                i4 -= i12;
                instanceCount = j3 - (-7);
                i5++;
            }
            i6 <<= 159;
            instanceCount = instanceCount;
            int i13 = i9;
            int i14 = 2;
            while (i14 < 142) {
                i7 = 803;
                i14++;
                i13 = 2;
            }
            i10++;
            i8 = i14;
            i9 = i13;
        }
        FuzzerUtils.out.println("d i13 i14 = " + Double.doubleToLongBits(2.97296d) + "," + i10 + "," + i4);
        FuzzerUtils.out.println("i15 i16 l2 = " + i5 + "," + i6 + "," + j);
        FuzzerUtils.out.println("i17 b2 i18 = " + i7 + ",1," + i8);
        FuzzerUtils.out.println("i19 i20 iArr = -45478," + i9 + "," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.sFld = " + instanceCount + "," + iFld + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.fFld byFld iFld1 = " + Float.floatToIntBits(fFld) + "," + ((int) this.byFld) + "," + this.iFld1);
        FuzzerUtils.out.println("Test.dArrFld Test.fArrFld Test.bArrFld = " + Double.doubleToLongBits(FuzzerUtils.checkSum(dArrFld)) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)) + "," + FuzzerUtils.checkSum(bArrFld));
        FuzzerUtils.out.println("iMeth2_check_sum: " + iMeth2_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
