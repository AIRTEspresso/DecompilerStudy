
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/141/original-141/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public volatile int iFld = 13;
    public static long instanceCount = -9019415368366877483L;
    public static volatile boolean bFld = false;
    public static short sFld = 10356;
    public static volatile float fFld = 62.337f;
    public static long vSmallMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, -131);
    }

    public static int iMeth() {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 0L);
        int[] iArr = iArrFld;
        int length = iArr.length;
        int i = 0;
        int i2 = 0;
        int i3 = -141;
        int i4 = -16415;
        float f = -38.11f;
        while (i2 < length) {
            int i5 = iArr[i2] * (-1);
            i3 -= (int) instanceCount;
            i = 1;
            while (4 > i) {
                int i6 = i - 1;
                jArr[i6] = jArr[i6] - i4;
                i4 -= (int) (-77.115893d);
                int[] iArr2 = iArrFld;
                int i7 = i + 1;
                iArr2[i7] = 10;
                i3 >>= i4;
                f += i;
                try {
                    i4 = i / i5;
                    i3 = (iArr2[i] % i) % 37622;
                } catch (ArithmeticException e) {
                }
                i = i7;
            }
            int[] iArr3 = iArrFld;
            int i8 = (i5 >>> 1) % N;
            iArr3[i8] = iArr3[i8] + 5;
            i2++;
            i4 = i5;
        }
        int i9 = 21;
        int i10 = -40727;
        while (i9 < 351) {
            i3 >>= -64364;
            i10 -= i;
            i9++;
        }
        long doubleToLongBits = i3 + i + i4 + Double.doubleToLongBits(-77.115893d) + Float.floatToIntBits(f) + i9 + i10 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static void vMeth() {
        int i;
        int[][][] iArr = (int[][][]) Array.newInstance(int.class, N, N, N);
        int[][] iArr2 = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init((Object[][]) iArr, (Object) 9);
        FuzzerUtils.init(iArr2, 5);
        int i2 = -4;
        float f = 61.757f;
        int i3 = 294;
        while (i3 > 10) {
            int[] iArr3 = iArr[i3][i3 - 1];
            int i4 = i3 + 1;
            iArr3[i4] = iArr3[i4] - 1;
            instanceCount = Math.abs(i);
            double d = i3;
            double d2 = f;
            Double.isNaN(d2);
            Double.isNaN(d);
            instanceCount = (long) (d * (2.0d - (-(d2 - 42.8349d))));
            iArr2 = FuzzerUtils.int2array(N, -54362);
            i2 = iMeth();
            f *= f;
            i3--;
        }
        double d3 = 6.0d;
        int i5 = -197;
        while (334.0d > d3) {
            i5 *= 5;
            f -= (float) 42.8349d;
            d3 += 1.0d;
        }
        iArr2[(i5 >>> 1) % N][(i3 >>> 1) % N] = i2;
        int i6 = (int) instanceCount;
        int i7 = 13;
        while (i7 < 269) {
            f = i5;
            i7++;
        }
        vMeth_check_sum += (((((((i3 + i6) + Float.floatToIntBits(f % 83.0f)) + Double.doubleToLongBits(42.8349d)) + Double.doubleToLongBits(d3)) + i5) + i7) - 10711) + FuzzerUtils.checkSum((Object[][]) iArr) + FuzzerUtils.checkSum(iArr2);
    }

    public static void vSmallMeth(int i) {
        vMeth();
        vSmallMeth_check_sum += i;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = 2;
        double[][] dArr = (double[][]) Array.newInstance(double.class, N, N);
        byte[] bArr = new byte[N];
        FuzzerUtils.init(dArr, -5.52689d);
        FuzzerUtils.init(bArr, (byte) -42);
        int i3 = 0;
        while (true) {
            i = -6997;
            if (i3 >= 173) {
                break;
            }
            vSmallMeth(-6997);
            i3++;
        }
        double[] dArr2 = dArr[149];
        double d = dArr2[359];
        double d2 = -6997;
        Double.isNaN(d2);
        dArr2[359] = d * d2;
        int i4 = 61748;
        int i5 = 53900;
        int i6 = 199;
        int i7 = -209;
        int i8 = 20174;
        int i9 = -32;
        double d3 = -1.5458d;
        int i10 = 10;
        int i11 = 9;
        while (i11 < 147) {
            i4 = 1;
            while (true) {
                if (182 > i4) {
                    instanceCount -= -17;
                    int i12 = i10;
                    i6 = 1;
                    while (i6 < i2) {
                        i7 -= 11199;
                        bFld = false;
                        try {
                            i12 = 176 % i12;
                            int i13 = (-105) % i11;
                            i8 = i11 / (-72);
                        } catch (ArithmeticException e) {
                            i8 = i12;
                        }
                        int[] iArr = iArrFld;
                        int i14 = i11 + 1;
                        iArr[i14] = iArr[i14] + i5;
                        i6++;
                        i = i5;
                        i12 = i8;
                        i5 = (i6 - sFld) + i5;
                    }
                    if (bFld) {
                        i10 = i12;
                        break;
                    }
                    int[] iArr2 = iArrFld;
                    int i15 = i11 + 1;
                    iArr2[i15] = iArr2[i15] - i12;
                    bArr[i15] = (byte) (bArr[i15] + ((byte) i));
                    i5 = ((int) fFld) + i4;
                    i4++;
                    i10 = i12;
                    d3 = i11;
                    i2 = 2;
                    i9 = 2;
                }
            }
            fFld += i4;
            bFld = bFld;
            i11++;
            i2 = 2;
        }
        int[] iArr3 = iArrFld;
        int i16 = (this.iFld >>> 1) % N;
        iArr3[i16] = iArr3[i16] * i6;
        int i17 = 145;
        int i18 = 10857;
        int i19 = 0;
        while (2 < i17) {
            i18 = i17;
            while (175 > i18) {
                i18++;
                i19 = 1;
            }
            i17--;
        }
        FuzzerUtils.out.println("i12 i13 i14 = " + i + "," + i11 + "," + i10);
        FuzzerUtils.out.println("i15 i16 i17 = " + i4 + "," + i5 + "," + i6);
        FuzzerUtils.out.println("i18 i19 d3 = " + i7 + "," + i8 + "," + Double.doubleToLongBits(d3));
        FuzzerUtils.out.println("i20 i21 i22 = " + i9 + "," + i17 + ",44839");
        FuzzerUtils.out.println("i23 i24 i25 = " + i18 + ",1," + i19);
        FuzzerUtils.out.println("i26 dArr byArr = -49854," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr)) + "," + FuzzerUtils.checkSum(bArr));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.sFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + ((int) sFld));
        FuzzerUtils.out.println("Test.fFld iFld Test.iArrFld = " + Float.floatToIntBits(fFld) + "," + this.iFld + "," + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
