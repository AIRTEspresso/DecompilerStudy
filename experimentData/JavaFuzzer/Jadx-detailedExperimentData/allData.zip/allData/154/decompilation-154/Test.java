
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/154/original-154/Test.dex */
public class Test {
    public static final int N = 400;
    public short sFld = -23480;
    public short sFld1 = -16171;
    public static long instanceCount = 5588716753445120000L;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;

    public static int iMeth1(int i) {
        int[][] iArr = (int[][]) Array.newInstance(int.class, N, N);
        FuzzerUtils.init(iArr, -48);
        int i2 = -10;
        int i3 = -8;
        int i4 = 235;
        while (i4 > 9) {
            try {
                i2 = 14 / i;
                i = iArr[i4 + 1][i4] % i4;
                i3 = i2 / 653800839;
            } catch (ArithmeticException e) {
            }
            i4--;
        }
        long checkSum = i + i4 + 20702 + i2 + i3 + FuzzerUtils.checkSum(iArr);
        iMeth1_check_sum += checkSum;
        return (int) checkSum;
    }

    public static void vMeth(int i, double d, boolean z) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -1);
        double d2 = -iMeth1(i);
        Double.isNaN(d2);
        int i2 = (int) (d2 * d);
        int i3 = -46256;
        int i4 = 42621;
        float f = -67.183f;
        int i5 = 2;
        int i6 = -3;
        while (347 > i5) {
            int i7 = 1;
            while (true) {
                i7++;
                if (i7 >= 5) {
                    break;
                }
                instanceCount = i7;
                i2 = (i7 * i7) + 13 + i7;
            }
            if (((i5 % 1) * 5) + 58 == 61) {
                instanceCount -= -191;
                if (z) {
                    i5++;
                    i4 = i7;
                }
            }
            i2 >>= i5;
            if (z) {
                i6 = 1;
                while (i6 < 5) {
                    int i8 = (i7 >>> 1) % N;
                    iArr[i8] = iArr[i8] ^ ((int) instanceCount);
                    f += i3;
                    i3 *= -32;
                    i6++;
                }
            } else if (z) {
            }
            i5++;
            i4 = i7;
        }
        vMeth_check_sum += (((((((i2 + Double.doubleToLongBits(d)) + (z ? 1L : 0L)) + i5) + i3) + i4) + i6) - 3) + Float.floatToIntBits(f) + FuzzerUtils.checkSum(iArr);
    }

    public static int iMeth(double d) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 101);
        int i = 7;
        int i2 = 7;
        int i3 = -38228;
        float f = 85.897f;
        while (i < 379) {
            iArr[i] = i;
            vMeth(38805, d, false);
            f = -8.7536821E18f;
            instanceCount -= i2;
            int i4 = i2 + i;
            i2 = i4 + (i ^ i4);
            i3 /= i | 1;
            i++;
        }
        long doubleToLongBits = Double.doubleToLongBits(d) + i + i2 + 0 + Float.floatToIntBits(f) + i3 + FuzzerUtils.checkSum(iArr);
        iMeth_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public void mainTest(String[] strArr) {
        Test test = this;
        int[] iArr = new int[N];
        float[][][] fArr = (float[][][]) Array.newInstance(float.class, N, N, N);
        FuzzerUtils.init(iArr, 7439);
        FuzzerUtils.init((Object[][]) fArr, (Object) Float.valueOf(108.203f));
        int i = 1;
        int i2 = iMeth(0.89714d) > test.sFld ? 1 : 0;
        int i3 = 4;
        int i4 = 4;
        while (i4 < 396) {
            test.sFld1 = (short) (test.sFld1 + ((short) (i4 + i3)));
            i3 -= (int) instanceCount;
            if (i2 != 0) {
                break;
            }
            i4++;
        }
        instanceCount *= -10;
        float f = i3;
        int i5 = i3;
        long j = 1;
        while (j < 272) {
            i5 *= 36541;
            j++;
        }
        double d = 0.22961d;
        int i6 = -231;
        int i7 = -69;
        int i8 = 99;
        int i9 = 32;
        double d2 = 0.89714d;
        int i10 = -480;
        while (true) {
            int i11 = i9;
            double d3 = d;
            if (i < 163) {
                int i12 = i7;
                i9 = i11;
                int i13 = 4;
                while (i13 < 155) {
                    long j2 = j;
                    int i14 = i9;
                    int i15 = i4;
                    test.sFld = (short) (test.sFld + ((short) (((i13 * i5) + instanceCount) - i12)));
                    double d4 = i8;
                    d3 = 1.0d;
                    int i16 = i8;
                    int i17 = i12;
                    int i18 = i16;
                    while (d3 < 2.0d) {
                        i14 <<= (int) instanceCount;
                        int i19 = i18 + i;
                        try {
                            iArr[i] = i19 / iArr[i13];
                            i18 = (-35716) % iArr[i + 1];
                            i17 = -8;
                        } catch (ArithmeticException e) {
                            i18 = i19;
                        }
                        d3 += 2.0d;
                    }
                    if (i2 != 0) {
                        i17 = (int) f;
                    }
                    instanceCount -= 10;
                    i10 = 2;
                    iArr[2] = iArr[2] + 92;
                    float[] fArr2 = fArr[i][2];
                    fArr2[i] = fArr2[i] + 92;
                    iArr[i] = iArr[i] << i5;
                    i13++;
                    test = this;
                    d2 = d4;
                    i4 = i15;
                    i9 = i14 + ((int) d4);
                    i12 = i17;
                    j = j2;
                    i8 = 92;
                }
                i++;
                test = this;
                d = d3;
                int i20 = i13;
                i7 = i12;
                i6 = i20;
            } else {
                FuzzerUtils.out.println("b d2 i14 = " + i2 + "," + Double.doubleToLongBits(d2) + "," + i7);
                FuzzerUtils.out.println("by i15 i16 = -69," + i4 + "," + i5);
                FuzzerUtils.out.println("f2 l i17 = " + Float.floatToIntBits(f) + "," + j + ",10");
                FuzzerUtils.out.println("i18 i19 i20 = " + i + ",-29," + i6);
                FuzzerUtils.out.println("i21 d3 i22 = " + i8 + "," + Double.doubleToLongBits(d3) + "," + i11);
                FuzzerUtils.out.println("i23 iArr3 fArr = " + i10 + "," + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum((Object[][]) fArr)));
                FuzzerUtils.out.println("Test.instanceCount sFld sFld1 = " + instanceCount + "," + ((int) this.sFld) + "," + ((int) this.sFld1));
                FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
                FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
                FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
                return;
            }
        }
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
