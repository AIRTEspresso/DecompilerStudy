package defpackage;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/error_ones/164/final-164/tmp/Test.dex */
class Test {
    long instanceCount;

    Test() {
        this.instanceCount &= 50.231f;
    }
}
