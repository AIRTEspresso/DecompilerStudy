/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/105/original-105/Test.dex */
public class Test {
    public static final int N = 400;
    public static long instanceCount = -2384593840L;
    public static float fFld = -1.614f;
    public static boolean bFld = true;
    public static short sFld = 17155;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;
    public int iFld = 5;
    public double dFld = 22.101494d;
    public int iFld1 = -57;
    public long[] lArrFld = new long[N];

    public static void vMeth2() {
        vMeth2_check_sum += 10748 + Double.doubleToLongBits(-61.91178d);
    }

    public static void vMeth1(long j) {
        int i;
        int i2;
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -1223);
        fFld = (float) (-2613817603206054323L);
        int i3 = 9;
        int i4 = -229;
        int i5 = -64427;
        long j2 = 2;
        while (j2 < 343) {
            vMeth2();
            i3 = (int) (i3 + ((j2 * j2) - 54));
            i4 = 1;
            while (i4 < 5) {
                float f = fFld;
                bFld = bFld;
                int i6 = ((int) f) * (-2);
                sArr[(int) (1 + j2)] = (short) (sArr[i] - 17462);
                int i7 = ((i5 - 1602019451) << (-48160)) >>> i6;
                i3 = (int) ((i6 >> i6) + (((i4 * i2) + i2) - f));
                i5 = i7 % (-40);
                i4++;
            }
            j2++;
        }
        vMeth1_check_sum += (j - 2613817603206054322L) + j2 + i3 + i4 + i5 + FuzzerUtils.checkSum(sArr);
    }

    public static void vMeth() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, 1);
        int i2 = -40901;
        int i3 = 1;
        do {
            i = 14;
            while (i > 1) {
                vMeth1(instanceCount);
                float f = fFld;
                long j = instanceCount;
                long j2 = i3;
                fFld = f + ((float) (((i * j) + j) - j2));
                i2 = ((((i2 * 85) + i) + ((int) j)) - 85) + i;
                instanceCount = j2;
                i--;
            }
            instanceCount += (i3 * i3) - 211;
            iArr[i3] = iArr[i3] * sFld;
            i2 *= 32427;
            i3 += 2;
        } while (i3 < 216);
        vMeth_check_sum += i3 + i + i2 + 85 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        long[] jArr;
        int i;
        int i2;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -112);
        this.iFld += 19;
        int i3 = -56001;
        int i4 = 0;
        int i5 = -14;
        int i6 = 379;
        while (true) {
            i6--;
            if (i6 <= 0) {
                break;
            }
            i3 = i6;
            while (i3 < 66) {
                long[] jArr2 = this.lArrFld;
                jArr2[i6] = jArr2[i6] >> i3;
                vMeth();
                int i7 = this.iFld * ((int) fFld);
                this.iFld = i7;
                double d = this.dFld;
                iArr[2] = (int) d;
                long j = instanceCount;
                this.iFld = i7;
                i5 = 4;
                bFld = true;
                i4 = ((int) j) * ((int) j);
                double d2 = i6;
                Double.isNaN(d2);
                this.dFld = d - d2;
                i3++;
            }
        }
        this.lArrFld[(i6 >>> 1) % N] = jArr[i] - 188;
        int i8 = this.iFld;
        long j2 = instanceCount;
        int i9 = i8 << ((int) j2);
        this.iFld = i9;
        int i10 = i4 - i4;
        instanceCount = j2 + i9;
        int i11 = 1;
        while (true) {
            i11++;
            i2 = -4;
            if (i11 >= 285) {
                break;
            }
            i10 = (i10 + i11) << (-4);
        }
        float f = 3.0f;
        int i12 = 15540;
        while (f < 188.0f) {
            i10 <<= -30083;
            i12 = (int) f;
            while (i12 < 136) {
                i2 += i2;
                try {
                    this.iFld1 = (int) (this.iFld1 + i12 + fFld);
                    i12++;
                } catch (ArithmeticException e) {
                    i2 <<= 7;
                }
            }
            f += 1.0f;
        }
        FuzzerUtils.out.println("i i1 i2 = " + i6 + "," + i3 + "," + i10);
        FuzzerUtils.out.println("i15 i16 f1 = " + i5 + "," + i11 + "," + Float.floatToIntBits(f));
        FuzzerUtils.out.println("i17 i18 i19 = 133," + i12 + "," + i2);
        FuzzerUtils.out.println("iArr1 = " + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount iFld Test.fFld = " + instanceCount + "," + this.iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.bFld Test.sFld dFld = " + (bFld ? 1 : 0) + "," + ((int) sFld) + "," + Double.doubleToLongBits(this.dFld));
        FuzzerUtils.out.println("iFld1 lArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
