/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/200/original-200/Test.dex */
public class Test {
    public static long instanceCount = 3677;
    public static volatile boolean bFld = false;
    public static int iFld = 37466;
    public static final int N = 400;
    public static volatile int[] iArrFld = new int[N];
    public static long vSmallMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public int iFld1 = 39050;
    public float[] fArrFld = new float[N];
    public volatile long[] lArrFld = new long[N];

    static {
        FuzzerUtils.init(iArrFld, -6);
    }

    public static void vMeth1(int i) {
        int i2;
        int i3;
        float[] fArr = new float[N];
        short[] sArr = new short[N];
        FuzzerUtils.init(sArr, (short) -7701);
        FuzzerUtils.init(fArr, 0.4f);
        int i4 = -28;
        int i5 = -121;
        int i6 = -67;
        int i7 = 7;
        int i8 = -31039;
        if (bFld) {
            int[] iArr = iArrFld;
            int length = iArr.length;
            double d = 2.6701d;
            int i9 = 0;
            int i10 = i - 2;
            while (i9 < length) {
                int i11 = iArr[i9];
                int i12 = i6;
                double d2 = i4;
                Double.isNaN(d2);
                d -= d2;
                try {
                    i10 %= i11;
                    int i13 = 89 / (i11 / i10);
                } catch (ArithmeticException e) {
                }
                i6 = i12;
                i5 = 1;
                while (i5 < 4) {
                    if (!bFld) {
                        switch (((i10 >>> 1) % 3) + 79) {
                            case 79:
                                i10 = (int) instanceCount;
                            case 80:
                                i6 = i5;
                                while (i6 < 2) {
                                    int i14 = i5;
                                    long j = ((float) instanceCount) + (((i6 * 0.524f) + i8) - i10);
                                    instanceCount = j;
                                    instanceCount = j * 0.524f;
                                    int i15 = i14 + 1;
                                    iArrFld[i15] = (int) instanceCount;
                                    sArr[i15] = (short) (sArr[i15] - ((short) 7));
                                    int[] iArr2 = iArrFld;
                                    int i16 = i14 - 1;
                                    iArr2[i16] = iArr2[i16] + ((int) 0.524f);
                                    i6++;
                                    i5 = i14;
                                    i10 = i10;
                                    length = length;
                                    i8 = -31039;
                                }
                                i3 = i5;
                                i2 = length;
                                break;
                            case 81:
                                i3 = i5;
                                i2 = length;
                                break;
                            default:
                                i3 = i5;
                                i2 = length;
                                instanceCount = 450198295L;
                                break;
                        }
                    } else {
                        i3 = i5;
                        i2 = length;
                    }
                    i5 = i3 + 1;
                    length = i2;
                    i8 = -31039;
                }
                i9++;
                i4 = -28;
                i8 = -31039;
            }
            vMeth1_check_sum += ((((((((i10 + Double.doubleToLongBits(d)) - 28) + i5) + 124) + i6) + 7) + Float.floatToIntBits(0.524f)) - 31039) + FuzzerUtils.checkSum(sArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
            return;
        }
        if (bFld) {
            int[] iArr3 = iArrFld;
            iArr3[257] = iArr3[257] + 1;
        } else {
            i7 = 131;
        }
        vMeth1_check_sum += ((((((((i + Double.doubleToLongBits(2.6701d)) - 28) - 121) + 124) - 67) + i7) + Float.floatToIntBits(0.524f)) - 31039) + FuzzerUtils.checkSum(sArr) + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
    }

    public static void vMeth(int i, int i2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 244L);
        vMeth1(i2);
        long j = instanceCount;
        long j2 = j - j;
        instanceCount = j2;
        int i3 = (i >>> 1) % N;
        jArr[i3] = jArr[i3] + i2;
        jArr[(i2 >>> 1) % N] = j2;
        vMeth_check_sum += i + i2 + FuzzerUtils.checkSum(jArr);
    }

    public static void vSmallMeth(int i, int i2, short s) {
        vMeth(i2, -52028);
        vSmallMeth_check_sum += (i >>> i2) + i2 + s;
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2 = 0;
        while (true) {
            i = -35318;
            if (i2 >= 158) {
                break;
            }
            vSmallMeth(-35318, -35318, (short) -30473);
            i2++;
        }
        instanceCount = -35318;
        int i3 = -9;
        int i4 = 159;
        int i5 = 4;
        int i6 = -8;
        double d = -2.117285d;
        float f = -82.563f;
        long j = 10;
        int i7 = 46;
        int i8 = 13;
        while (i8 < 248) {
            int i9 = i7 / (i7 | 1);
            int i10 = 3;
            while (i10 < 107) {
                if (((i7 >>> 1) % 1) + 41 == 41) {
                    i9 += i10;
                } else {
                    this.fArrFld[i10] = i10;
                    f += ((i10 * i4) + i7) - i4;
                }
                int i11 = i9 << (-59098);
                i5 = 1;
                while (i5 < 2) {
                    j += instanceCount;
                    d = i8;
                    bFld = true;
                    f = i8;
                    i6 -= i11;
                    int i12 = i10;
                    instanceCount = i6 & instanceCount;
                    try {
                        i4 = iArrFld[i8 - 1] % (-36362);
                        iFld = (-8115) / i8;
                        i4 = (-1) % i8;
                    } catch (ArithmeticException e) {
                    }
                    i5++;
                    i10 = i12;
                }
                int i13 = i10;
                i9 = 57453;
                long[] jArr = this.lArrFld;
                jArr[i13] = jArr[i13] * i8;
                i4 += (int) j;
                i10 = i13 + 1;
                i7 = i8;
            }
            int[] iArr = iArrFld;
            int i14 = i8 + 1;
            iArr[i14] = iArr[i14] & i4;
            instanceCount >>= 14;
            j += i8 | i9;
            i7 = 63470 * i9;
            i8 = i14;
            i = i4;
            i3 = i10;
        }
        FuzzerUtils.out.println("i10 s2 i11 = " + i + ",-30473," + i8);
        FuzzerUtils.out.println("i12 i13 i14 = " + i7 + "," + i3 + "," + i4);
        FuzzerUtils.out.println("d1 f2 i15 = " + Double.doubleToLongBits(d) + "," + Float.floatToIntBits(f) + "," + i5);
        FuzzerUtils.out.println("i16 l = " + i6 + "," + (j ^ i7));
        FuzzerUtils.out.println("Test.instanceCount Test.bFld Test.iFld = " + instanceCount + "," + (bFld ? 1 : 0) + "," + iFld);
        FuzzerUtils.out.println("iFld1 Test.iArrFld fArrFld = " + this.iFld1 + "," + FuzzerUtils.checkSum(iArrFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(this.fArrFld)));
        FuzzerUtils.out.println("lArrFld = " + FuzzerUtils.checkSum(this.lArrFld));
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
