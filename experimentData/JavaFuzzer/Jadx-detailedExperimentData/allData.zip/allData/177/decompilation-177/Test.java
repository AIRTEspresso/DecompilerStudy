
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/177/original-177/Test.dex */
public class Test {
    public static final int N = 400;
    public static int[] iArrFld;
    public static long instanceCount = -1550508883;
    public static int iFld = 2578;
    public static float fFld = 95.1016f;
    public static byte byFld = -52;
    public static boolean bFld = false;
    public static double dFld = -1.121504d;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long vMeth_check_sum = 0;

    static {
        int[] iArr = new int[N];
        iArrFld = iArr;
        FuzzerUtils.init(iArr, 4);
    }

    public static void vMeth(int i, int i2) {
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, -38418L);
        int i3 = 8;
        int i4 = -105;
        int i5 = -7;
        int i6 = 43281;
        int i7 = -54161;
        while (i3 < 150) {
            iFld += (i3 * i3) + 60898;
            i2 += i3;
            long j = jArr[i3];
            long j2 = instanceCount;
            jArr[i3] = j + j2;
            fFld = (float) j2;
            i5 = 1;
            while (i5 < 22) {
                i7 = 3;
                long j3 = instanceCount;
                iFld = (int) j3;
                instanceCount = j3 + i5;
                i6 = i6 + (i5 | i2) + 0;
                int[] iArr = iArrFld;
                iArr[i5] = iArr[i5] * i2;
                i5++;
            }
            i4 = i3;
            i3 += 2;
        }
        vMeth_check_sum += i + i2 + i3 + i4 + i5 + i6 + i7 + FuzzerUtils.checkSum(jArr);
    }

    public static int iMeth1(int i, long j, long j2) {
        int i2 = -35;
        int i3 = 27130;
        int i4 = -105;
        int i5 = 7;
        while (i5 < 326) {
            vMeth(146, i5);
            fFld *= (float) 114.112392d;
            i *= (int) j2;
            byFld = (byte) instanceCount;
            i2 = (i2 + ((i5 * i5) + 159)) ^ (-38819);
            try {
                iFld %= i;
                iFld = 42692 % i;
                iArrFld[i5] = i2 % 37900;
            } catch (ArithmeticException e) {
            }
            i3 = i5;
            while (i3 < 5) {
                int[] iArr = iArrFld;
                int i6 = i5 - 1;
                iArr[i6] = iArr[i6] << i;
                j -= 153;
                fFld *= (float) j;
                i4 = (i4 - i3) * i3;
                i3++;
            }
            i5++;
        }
        long doubleToLongBits = i + j + j2 + i5 + i2 + Double.doubleToLongBits(114.112392d) + i3 + i4;
        iMeth1_check_sum += doubleToLongBits;
        return (int) doubleToLongBits;
    }

    public static int iMeth() {
        int i;
        int i2;
        long[] jArr = new long[N];
        FuzzerUtils.init(jArr, 3659750234294669490L);
        iFld = iFld - 1;
        instanceCount = Math.abs(i);
        int abs = Math.abs((int) ((-15099) * 2476092117L)) * (iMeth1(-58494, -6L, instanceCount) - 15099) * (-47621);
        int i3 = iFld;
        iFld = i3 - i3;
        int i4 = (abs >>> 1) % N;
        jArr[i4] = jArr[i4] - 40156;
        bFld = bFld;
        int i5 = 27100;
        int i6 = 53740;
        int i7 = 266;
        do {
            instanceCount = i7;
            byFld = (byte) (byFld - ((byte) dFld));
            i2 = 6;
            while (1 < i2) {
                i5 = 1;
                while (i5 < 2) {
                    i6 = (int) fFld;
                    i5++;
                }
                iFld <<= i7;
                instanceCount += abs;
                abs = (abs >> i7) + (i2 ^ i2);
                i2--;
            }
            i7--;
        } while (i7 > 0);
        long checkSum = (abs - 15099) + i7 + i2 + 241 + i5 + i6 + FuzzerUtils.checkSum(jArr);
        iMeth_check_sum += checkSum;
        return (int) checkSum;
    }

    public void mainTest(String[] strArr) {
        int[] iArr = new int[N];
        float[][] fArr = (float[][]) Array.newInstance(float.class, N, N);
        long[] jArr = new long[N];
        boolean[] zArr = new boolean[N];
        FuzzerUtils.init(iArr, 32892);
        FuzzerUtils.init(fArr, -60.598f);
        FuzzerUtils.init(jArr, -2099759609912039697L);
        FuzzerUtils.init(zArr, true);
        int i = 364;
        while (true) {
            i--;
            if (i <= 0) {
                break;
            }
            iArr[i] = iArr[i] - 1;
        }
        int iMeth = iMeth();
        instanceCount >>= iMeth;
        int i2 = 17;
        int i3 = -28969;
        while (i2 < 304) {
            iFld = -1818386673;
            i3 = 4;
            while (i3 < 88) {
                instanceCount = fFld;
                iFld += i3;
                i3++;
            }
            if (bFld) {
                break;
            }
            i2++;
        }
        FuzzerUtils.out.println("i i1 i21 = " + i + "," + iMeth + "," + i2);
        FuzzerUtils.out.println("i22 i23 i24 = 14028," + i3 + ",8132");
        FuzzerUtils.out.println("i25 i26 i27 = -8,214,4");
        FuzzerUtils.out.println("i28 i29 i30 = 253,45857,160");
        FuzzerUtils.out.println("i31 iArr fArr = 0," + FuzzerUtils.checkSum(iArr) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)));
        FuzzerUtils.out.println("lArr2 bArr = " + FuzzerUtils.checkSum(jArr) + "," + FuzzerUtils.checkSum(zArr));
        FuzzerUtils.out.println("Test.instanceCount Test.iFld Test.fFld = " + instanceCount + "," + iFld + "," + Float.floatToIntBits(fFld));
        FuzzerUtils.out.println("Test.byFld Test.bFld Test.dFld = " + ((int) byFld) + "," + (bFld ? 1 : 0) + "," + Double.doubleToLongBits(dFld));
        FuzzerUtils.out.println("Test.iArrFld = " + FuzzerUtils.checkSum(iArrFld));
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
