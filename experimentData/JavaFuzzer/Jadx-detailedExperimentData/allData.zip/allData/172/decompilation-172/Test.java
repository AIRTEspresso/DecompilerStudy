
import java.lang.reflect.Array;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome/eposide-1/172/original-172/Test.dex */
public class Test {
    public static float[][] fArrFld;
    public static long instanceCount = -32298;
    public static float fFld = 1.78f;
    public static final int N = 400;
    public static short[] sArrFld = new short[N];
    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long lMeth1_check_sum = 0;

    static {
        float[][] fArr = (float[][]) Array.newInstance(float.class, N, N);
        fArrFld = fArr;
        FuzzerUtils.init(fArr, 1.816f);
        FuzzerUtils.init(sArrFld, (short) 18506);
    }

    public static long lMeth1(int i) {
        int[] iArr = new int[N];
        boolean[] zArr = new boolean[N];
        long[][] jArr = (long[][]) Array.newInstance(long.class, N, N);
        FuzzerUtils.init(jArr, 1178025789L);
        FuzzerUtils.init(iArr, -40446);
        FuzzerUtils.init(zArr, true);
        int[] iArr2 = iArr;
        double d = 382.0d;
        int i2 = -4;
        int i3 = 1665;
        int i4 = 29681;
        short s = -9717;
        int i5 = i;
        while (d > 8.0d) {
            jArr[(int) d][(int) (d + 1.0d)] = i5;
            instanceCount -= 8173192795504588315L;
            i5 -= 2;
            i2 -= i5;
            iArr2 = FuzzerUtils.int1array(N, 62);
            i3 = 1;
            while (i3 < 9) {
                zArr[(int) (d + 1.0d)] = true;
                int i6 = (int) (((d % 8.0d) * 5.0d) + 39.0d);
                if (i6 != 44) {
                    if (i6 == 45 || i6 == 56) {
                        s = (short) (s + 16667);
                    } else if (i6 == 67) {
                        i5 += 174;
                    } else if (i6 != 75) {
                        switch (i6) {
                            case 50:
                                i4 = (int) d;
                                break;
                            case 51:
                                i5 <<= (int) instanceCount;
                                break;
                        }
                    } else {
                        long j = instanceCount;
                        instanceCount = j - j;
                    }
                    i3++;
                } else {
                    i4 = (int) (i4 + (((i4 * i3) + fFld) - i3));
                }
                iArr2[i3] = (int) instanceCount;
                i3++;
            }
            d -= 2.0d;
        }
        long doubleToLongBits = i5 + Double.doubleToLongBits(d) + i2 + 1 + i3 + i4 + s + FuzzerUtils.checkSum(jArr) + FuzzerUtils.checkSum(iArr2) + FuzzerUtils.checkSum(zArr);
        lMeth1_check_sum += doubleToLongBits;
        return doubleToLongBits;
    }

    public static long lMeth() {
        int i;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -13);
        int i2 = -104;
        byte b = -91;
        int i3 = 1;
        int i4 = 1;
        do {
            i = 1;
            while (i < 7) {
                short[] sArr = sArrFld;
                sArr[i3] = (short) (sArr[i3] + ((short) instanceCount));
                i4 = 1;
                while (2 > i4) {
                    int i5 = (int) instanceCount;
                    b = (byte) (b + ((byte) (((i4 * i3) + i5) - i2)));
                    instanceCount = i;
                    i4++;
                    i2 = i5;
                }
                iArr[i3] = i4;
                i++;
            }
            i3++;
        } while (i3 < 221);
        long checkSum = (((((((i3 + i) + i2) + i4) - 7) + b) + 1) - 7) + FuzzerUtils.checkSum(iArr);
        lMeth_check_sum += checkSum;
        return checkSum;
    }

    public static void vMeth(int i, int i2, double d) {
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -179);
        int i3 = i << ((int) (-(Math.abs(instanceCount) + (lMeth() * (-8)))));
        vMeth_check_sum += (((((((-2083620938) + i3) + Double.doubleToLongBits(d)) + 248) + i3) + 1) - 108) + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr) {
        int i;
        int i2;
        int i3;
        int i4;
        short s;
        int i5;
        int[] iArr = new int[N];
        FuzzerUtils.init(iArr, -14);
        int i6 = iArr[359];
        long j = (long) 2.6943389704935E8d;
        instanceCount = j;
        iArr[359] = i6 + ((int) j);
        int i7 = (((((int) (j - 11000)) >>> 1) % 2) * 5) + 43;
        int i8 = 0;
        int i9 = -178;
        int i10 = 212;
        short s2 = 7489;
        if (i7 == 48) {
            int i11 = (-178) >> ((int) j);
            float[] fArr = fArrFld[(i11 >>> 1) % N];
            float f = fArr[0] + 1.0f;
            fArr[0] = f;
            int i12 = i11 << ((int) (f + ((float) (j - (i11 + 1)))));
            vMeth(i12, i12, 0.10765d);
            i9 = i12;
            i4 = 35940;
            i3 = 60665;
            i2 = 11;
            i = -31163;
            for (int i13 = N; i8 < i13; i13 = N) {
                int i14 = iArr[i8];
                instanceCount -= -154;
                int i15 = 3;
                while (true) {
                    if (i15 >= 63) {
                        break;
                    }
                    long j2 = instanceCount + (i15 * i15);
                    instanceCount = j2;
                    iArr[i15] = iArr[i15] >> ((int) j2);
                    float f2 = fFld;
                    fFld = f2 + (((i9 * i15) + f2) - i15);
                    i = 53684 << ((int) j2);
                    i15++;
                    s2 = (short) (s2 << ((short) i14));
                    i9 = (int) 0.10765d;
                }
                iArr[(i15 >>> 1) % i13] = i15;
                i10 = 3;
                for (i5 = 63; i10 < i5; i5 = 63) {
                    i14 -= 41705;
                    i += i10 + i;
                    i3 = i10;
                    while (i3 < 2) {
                        i9++;
                        fFld = i14;
                        int i16 = ((i10 % 2) * 5) + 98;
                        if (i16 == 101 || i16 == 102) {
                            i14 += i3 ^ i14;
                            i2 = i9;
                        } else {
                            i2 = 35;
                        }
                        iArr[i10] = iArr[i10] << ((int) (-241));
                        i3++;
                    }
                    i10++;
                }
                i8++;
                i4 = i15;
            }
            s = s2;
            i8 = -41705;
        } else if (i7 == 50) {
            s = 7489;
            i4 = 35940;
            i8 = -41705;
            i3 = 60665;
            i2 = 11;
            i = -31163;
        } else {
            s = 7489;
            i4 = 35940;
            i3 = 60665;
            i2 = 11;
            i = -31163;
        }
        FuzzerUtils.out.println("i d i16 = " + i9 + "," + Double.doubleToLongBits(0.10765d) + "," + i4);
        FuzzerUtils.out.println("i17 s1 i18 = " + i + "," + ((int) s) + "," + i10);
        FuzzerUtils.out.println("i19 i20 i21 = " + i8 + "," + i3 + "," + i2);
        FuzzerUtils.out.println("l iArr = -241," + FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.fArrFld = " + instanceCount + "," + Float.floatToIntBits(fFld) + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(fArrFld)));
        FuzzerUtils.out.println("Test.sArrFld = " + FuzzerUtils.checkSum(sArrFld));
        FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(String[] strArr) {
        try {
            Test test = new Test();
            for (int i = 0; i < 10; i++) {
                test.mainTest(strArr);
            }
        } catch (Exception e) {
            FuzzerUtils.out.println(e.getClass().getCanonicalName());
        }
    }
}
