class Test {
    int N = 400;
    long instanceCount = 2184208139L;
    float fFld;
    void mainTest(String[]strArr1){
        double d3;
        int i17 = 4042 , i18 , i19 = 236 , i20 = 13 , i21 = 69 , i22 , i23 = 58610 , i24 = 17695 , i27 , iArr3[][]= new int[N][N];
        instanceCount -= - 81;
        d3 = instanceCount;
        for(i18 = 17; i18 < 292; ++ i18){
            for(; i20 < 91; ++ i20)instanceCount = instanceCount;
            for(i22 = 3; i22 < 91; i22 ++){
                iArr3[8][i22 - 1]-= i24;
                i19 = i24;
                iArr3[1][i18]*= 132;
                switch(i22){
                    case 19 : i17 = i21 / 598520166;
                    case 20 : i21 += i22;
                    case 21 : for(i27 = 1; i27 < 2; ++ i27)fFld -= i23;
                    case 24 : i23 = 65;
                }
            }
        }
        System.out.println("d3 i17 i18 = " + Double.doubleToLongBits(d3)+ "," + i17 + "," + i18);
        System.out.println(i19);
    }
    public static void main(String[]strArr){
        try {
            Test _instance = new Test();
            _instance.mainTest(strArr);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
