class Test {
    final int N = 400;
    static long instanceCount;
    short sFld = - 53;
    int iArrFld[]= new int[N];
    void mainTest(String[]strArr1){
        int i = 19681 , i1 = 51019 , i2 , i14 , i16 , i17 = 10 , i18 = 7 , i19 = 10;
        byte by = - 11;
        float f = 65.63F;
        long lArr[]= new long[N];
        i2 = 1;
        do {
            double d = 18.102586;
            f *= i2;
            if((i <<=(int)d)< by)continue;
        }
        while(++ i2 < 133);
        System.out.println(i);
        System.out.println(i2);
        for(i14 = 12; i14 < 212; ++ i14){
            iArrFld[i14 + 1]&= i1;
            for(i16 = 7; i16 < 126; i16 ++){
                i1 = sFld;
                i1 += i16 | instanceCount;
                i += i16;
                i18 = 1;
                lArr[i18]-= instanceCount;
            }
            lArr[i2 % N]= instanceCount;
            instanceCount = i;
            do i17 -= i14;
            while(++ i19 < 126);
        }
        System.out.println("i i1 by = " + i + "," + i1 + "," + by);
        System.out.println("i2 f i14 = " + f + i14);
        System.out.println(i18);
    }
    public static void main(String[]strArr){
        Test _instance = new Test();
        _instance.mainTest(strArr);
    }
}
