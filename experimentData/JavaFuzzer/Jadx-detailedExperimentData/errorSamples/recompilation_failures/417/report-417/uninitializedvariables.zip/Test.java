class Test {
    long vMeth_check_sum;
    void vMeth(int i3 , int i4){
        switch(-- i4 % 1){
        }
        vMeth_check_sum += i3 + i4;
    }
}
