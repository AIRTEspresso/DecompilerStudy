package defpackage;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/error_ones/417/final-417/tmp/Test.dex */
class Test {
    long vMeth_check_sum;

    Test() {
    }

    void vMeth(int i, int i2) {
        int i3;
        int i4 = (i2 - 1) % 1;
        this.vMeth_check_sum += i + i3;
    }
}
