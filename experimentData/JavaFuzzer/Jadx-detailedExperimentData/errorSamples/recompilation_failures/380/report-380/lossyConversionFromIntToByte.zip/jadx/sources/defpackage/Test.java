package defpackage;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/error_ones/380/final-380/tmp/Test.dex */
class Test {
    byte byFld;

    Test() {
        byte b = 208;
        while (true) {
            int i = b - this.byFld;
            b = b != 89 ? i : i + 99;
        }
    }
}
