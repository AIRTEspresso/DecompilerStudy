package defpackage;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/error_ones/recompilation_failures/44/report-44/tmp/Test.dex */
class Test {
    int iFld;
    long instanceCount;

    Test() {
        this.instanceCount = 6202473916003642764L;
        this.instanceCount = 6202473916003642764 >>> this.iFld;
    }
}
