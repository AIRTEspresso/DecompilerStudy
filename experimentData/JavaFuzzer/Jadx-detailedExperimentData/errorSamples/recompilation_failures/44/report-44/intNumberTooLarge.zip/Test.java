class Test {
    long instanceCount;
    int iFld;
    {
        instanceCount = 6202473916003642764L;
        instanceCount >>>= iFld;
    }
}
