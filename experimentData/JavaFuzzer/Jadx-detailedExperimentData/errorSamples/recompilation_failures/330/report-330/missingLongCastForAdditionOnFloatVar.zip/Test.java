class Test {
    int N;
    {
        int i1 = 4;
        float f1 = 0.275F;
        long lArr1[]= new long[N];
        lArr1[i1]+= f1;
    }
}
