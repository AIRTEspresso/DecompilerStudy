package defpackage;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/error_ones/recompilation_failures/330/report-330/tmp/Test.dex */
class Test {
    int N;

    Test() {
        long[] jArr = new long[this.N];
        jArr[4] = ((float) jArr[4]) + 0.275f;
    }
}
