class Test {
    long instanceCount;
    void vMeth(long l , int i2 , long l1){
    }
    long lMeth(int i){
        int i1 = 5;
        vMeth(Math.min(instanceCount ,(long)(i1 - 1.472F)<< 45840), i1 , 0L);
        long meth_res = i;
        return meth_res;
    }
}
