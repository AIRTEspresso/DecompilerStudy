package defpackage;
/* renamed from: Test */
/* loaded from: /root/DecompilerTester/testhome-save-jadx-2022.8.9/error_ones/652/final-652/tmp/Test.dex */
class Test {
    long instanceCount;

    Test() {
    }

    void vMeth(long j, int i, long j2) {
    }

    long lMeth(int i) {
        vMeth(Math.min(this.instanceCount, (5 - 1.472f) << 45840), 5, 0L);
        return i;
    }
}
