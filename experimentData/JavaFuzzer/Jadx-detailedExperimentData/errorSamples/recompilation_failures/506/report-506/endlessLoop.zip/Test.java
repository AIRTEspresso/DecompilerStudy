class Test {
    int N;
    long instanceCount;
    {
        int i4 = 64061 , iArr[]= new int[N];
        long l1 = 7049337105499461961L;
        for(int i5 : iArr){
            while(++ l1 < 4)instanceCount = i5;
            iArr[i5]<<= i4;
        }
    }
}
