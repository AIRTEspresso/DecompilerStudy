class Test {
    int N = 400;
    long instanceCount;
    void vMeth1(int i7 , long l , int i8){

    }
    void vMeth(int i1 , int i2 , int i3){
        int i4 , i5 , i6 = 12;
        i4 = 1;
        do for(i5 = 1; i5 < 6; i5 ++)
            switch(i4){
                case 44 : vMeth1(i3 , instanceCount , 52);
                    switch(i4){
                        case 28 : case 29 : i6 >>>= instanceCount;
                        case 30 : if(i4 != 0)return;
                    }
            }
        while(++ i4 < 262);
    }

    void mainTest(String[]strArr1){
        vMeth(21017 , 160 , 160);
    }
    public static void main(String[]strArr){
        try {
            Test _instance = new Test();
            _instance.mainTest(strArr);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
