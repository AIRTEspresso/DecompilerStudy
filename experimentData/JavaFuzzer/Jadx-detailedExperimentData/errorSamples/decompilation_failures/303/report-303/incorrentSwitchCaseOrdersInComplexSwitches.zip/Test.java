class Test {
    int N = 400;
    long instanceCount;
    float fFld;
    double dFld;
    int iArrFld[]= new int[N];
    void vMeth(int i3 , long l , int i4){
    }
    void mainTest(String[]strArr1){
        int i , i1 = 2 , i2 = 107 , i16 = 34934 , i17 = 3 , i18 = 71 , i19;
        long lArr[]= new long[N];
        for(i = 191; i > 3; -- i){
            i1 = iArrFld[i];
            switch(i % 9 + 41){
                case 41 : i2 = 133;
                    do lArr[i2 - 1]>>>= instanceCount -= i2;
                    while(-- i2 > 0);
                    vMeth(i1 , instanceCount , i1);
                    while(-- i16 > 0)i1 *= i1;
                    break;
                case 43 : case 44 : iArrFld[i]= i18;
                    break;
                case 46 : for(i19 = 6; i19 < 133; ++ i19)
                            try {
                                i18 = 229;
                                i = i17 % i2;
                            }
                            catch(ArithmeticException a_e){
                            }
                case 47 : fFld =(float)dFld;
            }
        }
        System.out.println("i i1 i2 = " + i + "," + i1 + "," + i2);
    }
    public static void main(String[]strArr){
        try {
            Test _instance = new Test();
            _instance.mainTest(strArr);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
