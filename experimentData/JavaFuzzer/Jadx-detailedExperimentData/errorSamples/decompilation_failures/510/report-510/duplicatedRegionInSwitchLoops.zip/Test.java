class Test {
    int iFld;
    void mainTest(String[]strArr1){
        long l;
        byte by2 = - 55;
        int i10 , i14 , i15 = 125;
        l = 1;
        do by2 += l;
        while(++ l < 282);
        for(i10 = 2; 365 > i10; i10 ++)
            switch(i10 % 2){
            case 102 : iFld += 156;
            case 95 : by2 =(byte)iFld;
            default : for(i14 = 1; i14 < 2; i14 ++)i15 -= i14;
        }
        System.out.println("l by2 i10 = " + l + "," + by2 + "," + i10);
    }
    public static void main(String[]strArr){
        try {
            Test _instance = new Test();
            _instance.mainTest(strArr);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
