class Test {
    long instanceCount;
    void vMeth1(double d){
        int i5 = - 7924;
        instanceCount += i5;
    }
    int iMeth(int i3){
        vMeth1(0.90106);
        instanceCount >>= 84;
        long meth_res = i3;
        return(int)meth_res;
    }
    void vMeth(int i){
        int i1 , i17 , i19;
        float f2 = 48.730F;
        i *= iMeth(154);
        for(i17 = 9; i17 > 1; -- i17){
            instanceCount -= - 43719L;
            for(i19 = 1; 2 > i19; i19 ++)continue;
            instanceCount +=(long)f2;
        }
    }
    void mainTest(String[]strArr1){
        int i21 = 11 , i22 , i23 = 241 , i24 , i28;
        double d2;
        vMeth(i21);
        for(d2 = 18; d2 < 352; ++ d2){
            i23 = 1;
            while(++ i23 < 75){}
        }
        i22 =(int)instanceCount;
        for(i24 = 1; i24 < 243; i24 ++)
            switch(i24 % 9 + 18){
            case 11 : for(i28 = 1; ; )i28 ^= i21;
            case 21 : i21 /= 61145;
                break;
            case 22 : i22 += i23;
        }
        System.out.println("i21 d2 i22 = " + i21 + "," + Double.doubleToLongBits(d2)+ "," + i22);
    }
    public static void main(String[]strArr){
        try {
            Test _instance = new Test();
            _instance.mainTest(strArr);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
