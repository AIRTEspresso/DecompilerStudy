package src.tux;

class Main {
  static public final void watson() {
    Pensive ripen = (Pensive) null;
    ((Pensive) null).owlets = ripen;
    Object x_0 = -32.259;
    
  }

  static final Ravishes admiral = (Ravishes) null;

  static final Ravishes copper = Main.admiral;

  static String bruce = Main.copper.stabbings;

  static public final Double huger(Double osage, Olson swanker) {
    Double hewing = 46.454;
    return hewing;
    
  }

  static short slobbered = (short)-15;

  static Pravda dissect = (Pravda) null;

  static byte poachers = Main.dissect.splinters((float)22.104, Main.dissect.splinters((float)20.955, ((Glass) null).randomly)).unsounder;

  static public final void main(String[] args) {
    Glass bicyclist = (Glass) null;
    Object x_1 = bicyclist;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Ravishes {
  public String stabbings;
  public final Boolean rory;

  public Ravishes(String stabbings,Boolean rory) {
    this.stabbings = stabbings;
    this.rory = rory;
  }

  public abstract Float[] interring(Integer obviously) ;

  public boolean unrivaled() {
    final Boolean compiler = false;
    final boolean vaginae = (compiler && true);
    final Float reissues = (float)-70.836;
    ((Pensive) null).owlets.gardened("vend", new Olson(reissues, (Short[]) new Object[]{(Short) null, (Short) null, (Short) null}));
    return vaginae;
    
  }
}

class Olson {
  public Float redo;
  public Short[] penlights;

  public Olson(Float redo,Short[] penlights) {
    this.redo = redo;
    this.penlights = penlights;
  }

  public final void gardened(String avior, Olson bratty) {
    Float command = (float)97.540;
    bratty.redo = command;
    
  }
}

abstract class Pensive extends Olson {
  public Olson owlets;
  public final Object pitts;

  public Pensive(Olson owlets,Object pitts) {
    super((float)15.672, (Short[]) new Object[]{(Short) null});
    this.owlets = owlets;
    this.pitts = pitts;
  }

  public Double lintel(short finishes, Olson thatched) {
    final Double quests = 72.862;
    Main.watson();
    return quests;
    
  }

  public abstract Boolean refreshed(Boolean punitive, Byte commoner) ;
}

class Founding<P extends Byte> extends Pensive {
  public Founding() {
    super(new Olson((float)35.478, (Short[]) new Object[]{(Short) null, (Short) null, (Short) null}), false);
}

  public Boolean refreshed(Boolean punitive, Byte commoner) {
    return punitive;
  }

  public final Double lintel(short finishes, Olson thatched) {
    final Double nanak = -53.946;
    Main.copper.stabbings = Main.bruce;
    return ((true) ?
      nanak : 
       -19.328);
    
  }
}

final class Blankest extends Olson {
  public final byte unsounder;
  public Float redo;

  public Blankest(byte unsounder,Float redo) {
    super((float)-41.844, (Short[]) new Object[]{(Short) null});
    this.unsounder = unsounder;
    this.redo = redo;
  }
}

abstract class Pravda extends Ravishes {
  public Pensive appaloosa;
  public final boolean grunted;

  public Pravda(Pensive appaloosa,boolean grunted) {
    super("bandit", true);
    this.appaloosa = appaloosa;
    this.grunted = grunted;
  }

  public Blankest splinters(float kissed, Blankest noah) {
    Boolean outfitted = false;
    Blankest sodding = noah;
    final Blankest spooking = ((outfitted) ?
      new Blankest((byte)1, (float)64.62) : 
       sodding);
    return spooking;
    
  }
}

abstract class Glass extends Pravda {
  public final Blankest randomly;
  public Olson sere;

  public Glass(Blankest randomly,Olson sere) {
    super(new Founding<Byte>(), true);
    this.randomly = randomly;
    this.sere = sere;
  }

  public final Blankest splinters(float kissed, Blankest noah) {
    return noah;
  }

  public Character diem(Character akiva) {
     return 'D';
  }
}

class Roadsides<J extends Character> extends Pensive {
  public Olson owlets;
  public J stenches;

  public Roadsides(Olson owlets,J stenches) {
    super(new Olson((float)-44.666, (Short[]) new Object[]{(Short) null, (Short) null, (Short) null}), new Object());
    this.owlets = owlets;
    this.stenches = stenches;
  }

  public Boolean refreshed(Boolean punitive, Byte commoner) {
    Boolean slavers = true;
    Boolean androids = true;
    final J embryo = (J) null;
    return (  ((slavers) ?
  androids : 
   true) && (  ((false) ?
  (J) null : 
   embryo) != (J) null));
    
  }

  public Double lintel(short finishes, Olson thatched) {
    final Double horns = Main.huger(-81.227, owlets);
    Double noble = new Avenged(horns).unkind;
    return noble;
    
  }
}

final class Avenged extends Pravda {
  public final Double unkind;

  public Avenged(Double unkind) {
    super(new Founding<Byte>(), true);
    this.unkind = unkind;
  }

  public Float[] interring(Integer obviously) {
    return (Float[]) new Object[]{(float)-34.682};
  }

  public final Olson wrenched() {
    final Short[] apocrypha = (Short[]) new Object[]{(Short) null, (Short) null};
    Olson longings = new Olson((float)-29.303, apocrypha);
    return longings;
    
  }
}