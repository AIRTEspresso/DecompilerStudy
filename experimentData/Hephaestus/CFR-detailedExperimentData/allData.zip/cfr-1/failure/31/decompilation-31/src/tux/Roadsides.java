/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Avenged;
import src.tux.Main;
import src.tux.Olson;
import src.tux.Pensive;

class Roadsides<J extends Character>
extends Pensive {
    public Olson owlets;
    public J stenches;

    public Roadsides(Olson olson, J j) {
        super(new Olson(Float.valueOf(-44.666f), (Short[])new Object[]{null, null, null}), new Object());
        this.owlets = olson;
        this.stenches = j;
    }

    @Override
    public Boolean refreshed(Boolean bl, Byte by) {
        Boolean bl2 = true;
        Boolean bl3 = true;
        Character c = null;
        return (bl2 == false || bl3 != false) && c != (Character)null;
    }

    @Override
    public Double lintel(short s, Olson olson) {
        Double d = Main.huger(-81.227, this.owlets);
        Double d2 = new Avenged((Double)d).unkind;
        return d2;
    }
}

