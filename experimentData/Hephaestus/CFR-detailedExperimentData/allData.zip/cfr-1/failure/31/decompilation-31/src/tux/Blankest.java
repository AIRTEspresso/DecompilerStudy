/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Olson;

final class Blankest
extends Olson {
    public final byte unsounder;
    public Float redo;

    public Blankest(byte by, Float f) {
        super(Float.valueOf(-41.844f), (Short[])new Object[]{null});
        this.unsounder = by;
        this.redo = f;
    }
}

