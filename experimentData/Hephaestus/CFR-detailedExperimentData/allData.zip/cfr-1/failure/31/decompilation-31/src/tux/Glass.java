/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Blankest;
import src.tux.Founding;
import src.tux.Olson;
import src.tux.Pravda;

abstract class Glass
extends Pravda {
    public final Blankest randomly;
    public Olson sere;

    public Glass(Blankest blankest, Olson olson) {
        super(new Founding(), true);
        this.randomly = blankest;
        this.sere = olson;
    }

    @Override
    public final Blankest splinters(float f, Blankest blankest) {
        return blankest;
    }

    public Character diem(Character c) {
        return Character.valueOf('D');
    }
}

