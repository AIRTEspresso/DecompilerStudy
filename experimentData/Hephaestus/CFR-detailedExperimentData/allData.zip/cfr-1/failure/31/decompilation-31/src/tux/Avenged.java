/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Founding;
import src.tux.Olson;
import src.tux.Pravda;

final class Avenged
extends Pravda {
    public final Double unkind;

    public Avenged(Double d) {
        super(new Founding(), true);
        this.unkind = d;
    }

    @Override
    public Float[] interring(Integer n) {
        return (Float[])new Object[]{Float.valueOf(-34.682f)};
    }

    public final Olson wrenched() {
        Short[] shortArray = (Short[])new Object[]{null, null};
        Olson olson = new Olson(Float.valueOf(-29.303f), shortArray);
        return olson;
    }
}

