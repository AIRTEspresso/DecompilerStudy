/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Olson;
import src.tux.Pensive;

abstract class Ravishes {
    public String stabbings;
    public final Boolean rory;

    public Ravishes(String string, Boolean bl) {
        this.stabbings = string;
        this.rory = bl;
    }

    public abstract Float[] interring(Integer var1);

    public boolean unrivaled() {
        Boolean bl = false;
        boolean bl2 = bl != false;
        Float f = Float.valueOf(-70.836f);
        ((Pensive)null).owlets.gardened("vend", new Olson(f, (Short[])new Object[]{null, null, null}));
        return bl2;
    }
}

