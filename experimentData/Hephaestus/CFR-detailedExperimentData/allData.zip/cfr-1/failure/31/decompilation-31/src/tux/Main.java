/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Blankest;
import src.tux.Glass;
import src.tux.Olson;
import src.tux.Pensive;
import src.tux.Pravda;
import src.tux.Ravishes;

class Main {
    static final Ravishes admiral;
    static final Ravishes copper;
    static String bruce;
    static short slobbered;
    static Pravda dissect;
    static byte poachers;

    Main() {
    }

    public static final void watson() {
        Pensive pensive = null;
        ((Pensive)null).owlets = pensive;
        Double d = -32.259;
    }

    public static final Double huger(Double d, Olson olson) {
        Double d2 = 46.454;
        return d2;
    }

    public static final void main(String[] stringArray) {
        Glass glass;
        Glass glass2 = glass = (Glass)null;
    }

    static {
        copper = admiral = (Ravishes)null;
        bruce = Main.copper.stabbings;
        slobbered = (short)-15;
        dissect = null;
        poachers = Main.dissect.splinters((float)22.104f, (Blankest)Main.dissect.splinters((float)20.955f, (Blankest)((Glass)null).randomly)).unsounder;
    }
}

