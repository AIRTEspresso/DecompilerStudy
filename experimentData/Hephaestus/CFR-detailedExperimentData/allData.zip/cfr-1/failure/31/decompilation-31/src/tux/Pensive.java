/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Main;
import src.tux.Olson;

abstract class Pensive
extends Olson {
    public Olson owlets;
    public final Object pitts;

    public Pensive(Olson olson, Object object) {
        super(Float.valueOf(15.672f), (Short[])new Object[]{null});
        this.owlets = olson;
        this.pitts = object;
    }

    public Double lintel(short s, Olson olson) {
        Double d = 72.862;
        Main.watson();
        return d;
    }

    public abstract Boolean refreshed(Boolean var1, Byte var2);
}

