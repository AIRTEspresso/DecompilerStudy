/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Main;
import src.tux.Olson;
import src.tux.Pensive;

class Founding<P extends Byte>
extends Pensive {
    public Founding() {
        super(new Olson(Float.valueOf(35.478f), (Short[])new Object[]{null, null, null}), false);
    }

    @Override
    public Boolean refreshed(Boolean bl, Byte by) {
        return bl;
    }

    @Override
    public final Double lintel(short s, Olson olson) {
        Double d = -53.946;
        Main.copper.stabbings = Main.bruce;
        return (double)d;
    }
}

