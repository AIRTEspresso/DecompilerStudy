/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

class Olson {
    public Float redo;
    public Short[] penlights;

    public Olson(Float f, Short[] shortArray) {
        this.redo = f;
        this.penlights = shortArray;
    }

    public final void gardened(String string, Olson olson) {
        Float f;
        olson.redo = f = Float.valueOf(97.54f);
    }
}

