/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tux;

import src.tux.Blankest;
import src.tux.Pensive;
import src.tux.Ravishes;

abstract class Pravda
extends Ravishes {
    public Pensive appaloosa;
    public final boolean grunted;

    public Pravda(Pensive pensive, boolean bl) {
        super("bandit", true);
        this.appaloosa = pensive;
        this.grunted = bl;
    }

    public Blankest splinters(float f, Blankest blankest) {
        Boolean bl = false;
        Blankest blankest2 = blankest;
        Blankest blankest3 = bl != false ? new Blankest(1, Float.valueOf(64.62f)) : blankest2;
        return blankest3;
    }
}

