package src.icily;

class Main {
  static Boolean[] mishandle = new Boolean[0];

  static Boolean[] warheads = (Boolean[]) new Object[]{true, true, false};

  static final Boolean[] peep = ((true) ?
  Main.mishandle : 
   Main.warheads);

  static Boolean[] bulkhead = Main.peep;

  static final Masseuses urged = new Shipping(  ((false) ?
  new Prove<Character>(new Shipping((float)83.788, (long)-93), new Chaise<Long>((long)-66, (float)-15.909)) : 
   new Prove<Character>(new Shipping((float)87.250, (long)-36), new Chaise<Long>((long)-70, (float)-70.602))).breezes.barclay,   ((false) ?
  (long)-98 : 
   (long)45));

  static public final <F_L, F_T extends F_L> F_T discuss(F_L shasta, F_L netting) {
    final Byte lemming = (byte)-36;
    Byte scorches = (byte)48;
    F_T palatial = (F_T) null;
    Main.warheads =   ((new Sciatica((float)-27.136, (long)43).farrell((long)97).festooned((long)-24)) ?
  Main.peep : 
   (Boolean[]) new Object[]{new Prove<F_T>(new Shipping((float)-18.393, (long)5), new Chaise<Long>((long)25, (float)-76.820)).festooned((long)84)});
    return (((lemming < scorches)) ?
      palatial : 
       new Frivolous<F_T, F_T>(new Chaise<Short>((long)47, (float)-61.452), (F_T) null).waggish);
    
  }

  static public final long dado() {
    final long crayoning = (long)23;
    return crayoning;
    
  }

  static final short shrove = ((false) ?
  new Swindlers<Sciatica, Long, Byte>((Arneb<Float, Sciatica>) null, (short)-94) : 
   new Swindlers<Sciatica, Long, Byte>((Arneb<Float, Sciatica>) null, (short)-5)).stone;

  static Arneb<? super Float, Byte> weepier = (((false || true)) ?
  ((true) ?
    (Arneb<Float, Byte>) null : 
     (Arneb<Float, Byte>) null) : 
   ((true) ?
    (Arneb<Float, Byte>) null : 
     (Arneb<Float, Byte>) null));

  static public final void main(String[] args) {
    Mush frugality = (Mush) null;
    long induing = frugality.lyell;
    Saran<Masseuses> revered = frugality.shaula(induing, 41.715);
    Object x_7 = revered.ferber.stone;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Masseuses {
  public final float latonya;
  public final long lyell;

  public Masseuses(float latonya,long lyell) {
    this.latonya = latonya;
    this.lyell = lyell;
  }
}

final class Shipping extends Masseuses {
  public float barclay;
  public final Long ballasts;

  public Shipping(float barclay,Long ballasts) {
    super((float)81.435, (long)28);
    this.barclay = barclay;
    this.ballasts = ballasts;
  }

  public final <F_N, F_X extends Character> F_N haiti(int remands, F_X staleness) {
    final long upturned = (long)76;
    float culottes = (float)16.528;
    long argo = (long)-7;
      ((false) ?
  (Dusting<F_X, F_N, Shipping>) null : 
   (Dusting<F_X, F_N, Shipping>) null).battery.aqueducts();
      return ((false) ?
  new Housetops<F_X, F_N>(new Chaise<F_N>(upturned, culottes), new Float[0]) : 
   new Housetops<F_X, F_N>(new Chaise<F_N>(argo, (float)57.665), (Float[]) new Object[]{(float)97.713})).entirety.thine(false,   ((true) ?
  "craziest" : 
   "deon"));
    
  }
}

class Chaise<Q> extends Masseuses {
  public final long lyell;
  public final float latonya;

  public Chaise(long lyell,float latonya) {
    super((float)-70.882, (long)27);
    this.lyell = lyell;
    this.latonya = latonya;
  }

  public Q thine(Boolean giveaways, String bikes) {
    Q parkman = (Q) null;
    return parkman;
    
  }

  public Float mannerly(byte decays, Short forayed) {
    final byte strange = (byte)79;
    final Short nth = (short)-10;
    final Float dowagers = mannerly(strange, nth);
      ((true) ?
  (Glaser) null : 
   (Glaser) null).insulator((byte)-91);
    return dowagers;
    
  }
}

interface Glaser {
  public abstract void insulator(Byte media) ;
}

class Housetops<T, Z> implements Glaser {
  public final Chaise<Z> entirety;
  public Float[] garaged;

  public Housetops(Chaise<Z> entirety,Float[] garaged) {
    super();
    this.entirety = entirety;
    this.garaged = garaged;
  }

  public void insulator(Byte media) {
    Integer staircase = 58;
    Object x_0 = staircase;
    
  }

  public T festooned(Z strait) {
    return (T) null;
  }
}

abstract class Arneb<K extends Float, G> implements Glaser {
  public final Number heat;

  public Arneb(Number heat) {
    super();
    this.heat = heat;
  }

  public void aqueducts() {
    Function1<K, K> narwhals = (naps) -> {
      return (K) null;
    };
    final K fire = narwhals.apply((K) null);
    Boolean quenches = true;
    Boolean shiner = true;
    Main.bulkhead =   ((true) ?
  (Boolean[]) new Object[]{quenches} : 
   (Boolean[]) new Object[]{shiner, true});
    Object x_1 = fire;
    
  }

  public void insulator(Byte media) {
    final Arneb<? super Float, ? extends G> dishpans = (Arneb<Float, G>) null;
    final Short twa = (short)-88;
    Swindlers<G, Long, G> galleries = new Swindlers<G, Long, G>(dishpans, twa);
    ((Johnathon<Integer, Double, Integer>) null).wacker();
    Object x_2 = galleries.accesses;
    
  }
}

class Swindlers<G, C extends Long, E> implements Glaser {
  public final Arneb<? super Float, ? extends G> accesses;
  public final Short stone;

  public Swindlers(Arneb<? super Float, ? extends G> accesses,Short stone) {
    super();
    this.accesses = accesses;
    this.stone = stone;
  }

  public void insulator(Byte media) {
    final long rapping = (long)68;
    Chaise<E> virginal = new Chaise<E>(rapping, (float)-82.43);
    final Float beckons = (float)-30.836;
    Object x_3 = new Housetops<C, E>(virginal, (Float[]) new Object[]{beckons, (float)-77.547});
    
  }

  public long glumly() {
    return (long)-100;
  }
}

abstract class Johnathon<W, T, B> extends Housetops<Integer, Long> {
  public final Chaise<Long> entirety;

  public Johnathon(Chaise<Long> entirety) {
    super(new Chaise<Long>((long)13, (float)25.711), new Float[0]);
    this.entirety = entirety;
  }

  public void wacker() {
    Chaise<Short> virginia = new Chaise<Short>((long)-61, (float)-55.792);
    final Chaise<Short> jerking = virginia;
    Frivolous<T, W> nadir = new Frivolous<T, W>(jerking, (T) null);
    nadir.rigors((W) null, null);
    Object x_4 = (B) null;
    
  }
}

class Frivolous<Q, I> extends Housetops<Float, Short> {
  public final Chaise<Short> entirety;
  public Q waggish;

  public Frivolous(Chaise<Short> entirety,Q waggish) {
    super(new Chaise<Short>((long)13, (float)-14.411), (Float[]) new Object[]{(float)32.629});
    this.entirety = entirety;
    this.waggish = waggish;
  }

  public final <F_R> void rigors(F_R scion, Frivolous<? super Q, ? extends Q> crated) {
    Object x_5 = (long)-75;
    
  }
}

abstract class Dusting<D, B, I extends Shipping> extends Frivolous<Double, Double> {
  public final Arneb<Float, Float> battery;
  public final Chaise<Short> entirety;

  public Dusting(Arneb<Float, Float> battery,Chaise<Short> entirety) {
    super(new Chaise<Short>((long)41, (float)51.621), 14.993);
    this.battery = battery;
    this.entirety = entirety;
  }

  public Object repulsive() {
    return new Object();
  }

  public abstract float tissue() ;
}

final class Prove<F> extends Housetops<Boolean, Long> {
  public Shipping breezes;
  public final Chaise<Long> entirety;

  public Prove(Shipping breezes,Chaise<Long> entirety) {
    super(new Chaise<Long>((long)-74, (float)34.960), (Float[]) new Object[]{(float)-1.557, (float)-29.181});
    this.breezes = breezes;
    this.entirety = entirety;
  }

  public final Boolean festooned(Long strait) {
    return false;
  }

  public final void insulator(Byte media) {
    final Arneb<? super Float, ? extends Masseuses> nike = (Arneb<Float, Masseuses>) null;
    final Arneb<? super Float, ? extends Masseuses> cones = nike;
    Object x_6 = new Swindlers<Masseuses, Long, Shipping>(cones, (short)-76);
    
  }
}

class Sciatica extends Masseuses {
  public final float latonya;
  public final long lyell;

  public Sciatica(float latonya,long lyell) {
    super((float)-12.261, (long)12);
    this.latonya = latonya;
    this.lyell = lyell;
  }

  public Prove<? super Shipping> farrell(Long unfolded) {
    final Long artifacts = (long)-67;
    final Shipping trochees = new Shipping((float)32.154, artifacts);
    final Shipping pucks = trochees;
    return new Prove<Shipping>(pucks, new Chaise<Long>((long)-37, (float)80.155));
    
  }

  public final short arranges(short slimness) {
    final short tidies = (short)-17;
    return tidies;
    
  }
}

abstract class Saran<R> extends Arneb<Float, Character> {
  public Swindlers<? extends Long, Long, ? super Number> ferber;
  public final Number heat;

  public Saran(Swindlers<? extends Long, Long, ? super Number> ferber,Number heat) {
    super((Number) new Long(-89));
    this.ferber = ferber;
    this.heat = heat;
  }

  public final void insulator(Byte media) {
    final long leftists = (long)-19;
    Object x_8 = new Masseuses((float)76.22, leftists);
    
  }

  public void aqueducts() {
    final R baptism = (R) null;
    Object x_9 = baptism;
    
  }
}

abstract class Mush extends Chaise<Glaser> {
  public final Boolean invoices;

  public Mush(Boolean invoices) {
    super((long)36, (float)26.800);
    this.invoices = invoices;
  }

  public Saran<Masseuses> shaula(long nonexempt, Double rundown) {
    return (Saran<Masseuses>) null;
  }
}