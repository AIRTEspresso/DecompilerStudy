/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Arneb;
import src.icily.Chaise;
import src.icily.Glaser;
import src.icily.Housetops;

class Swindlers<G, C extends Long, E>
implements Glaser {
    public final Arneb<? super Float, ? extends G> accesses;
    public final Short stone;

    public Swindlers(Arneb<? super Float, ? extends G> arneb, Short s) {
        this.accesses = arneb;
        this.stone = s;
    }

    @Override
    public void insulator(Byte by) {
        Chaise chaise = new Chaise(68L, -82.43f);
        Float f = Float.valueOf(-30.836f);
        Housetops housetops = new Housetops(chaise, (Float[])new Object[]{f, Float.valueOf(-77.547f)});
    }

    public long glumly() {
        return -100L;
    }
}

