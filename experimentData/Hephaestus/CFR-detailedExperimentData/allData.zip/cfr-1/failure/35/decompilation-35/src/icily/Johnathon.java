/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Chaise;
import src.icily.Frivolous;
import src.icily.Housetops;

abstract class Johnathon<W, T, B>
extends Housetops<Integer, Long> {
    public final Chaise<Long> entirety;

    public Johnathon(Chaise<Long> chaise) {
        super(new Chaise(13L, 25.711f), new Float[0]);
        this.entirety = chaise;
    }

    public void wacker() {
        Chaise<Short> chaise;
        Chaise<Short> chaise2 = chaise = new Chaise<Short>(-61L, -55.792f);
        Frivolous frivolous = new Frivolous(chaise2, null);
        frivolous.rigors(null, null);
        Object var4_4 = null;
    }
}

