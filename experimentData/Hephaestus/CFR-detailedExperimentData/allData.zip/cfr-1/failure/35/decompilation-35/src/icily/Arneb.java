/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Function1;
import src.icily.Glaser;
import src.icily.Johnathon;
import src.icily.Main;
import src.icily.Swindlers;

abstract class Arneb<K extends Float, G>
implements Glaser {
    public final Number heat;

    public Arneb(Number number) {
        this.heat = number;
    }

    public void aqueducts() {
        Function1<Float, Float> function1 = f -> null;
        Float f2 = function1.apply(null);
        Boolean bl = true;
        Boolean bl2 = true;
        Main.bulkhead = (Boolean[])new Object[]{bl};
        Float f3 = f2;
    }

    @Override
    public void insulator(Byte by) {
        Arneb arneb = null;
        Short s = -88;
        Swindlers swindlers = new Swindlers(arneb, s);
        ((Johnathon)null).wacker();
        Arneb arneb2 = swindlers.accesses;
    }
}

