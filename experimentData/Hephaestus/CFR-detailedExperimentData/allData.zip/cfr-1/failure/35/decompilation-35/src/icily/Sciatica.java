/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Chaise;
import src.icily.Masseuses;
import src.icily.Prove;
import src.icily.Shipping;

class Sciatica
extends Masseuses {
    public final float latonya;
    public final long lyell;

    public Sciatica(float f, long l) {
        super(-12.261f, 12L);
        this.latonya = f;
        this.lyell = l;
    }

    public Prove<? super Shipping> farrell(Long l) {
        Shipping shipping;
        Long l2 = -67L;
        Shipping shipping2 = shipping = new Shipping(32.154f, l2);
        return new Prove(shipping2, new Chaise<Long>(-37L, 80.155f));
    }

    public final short arranges(short s) {
        return -17;
    }
}

