/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Chaise;
import src.icily.Glaser;
import src.icily.Masseuses;
import src.icily.Saran;

abstract class Mush
extends Chaise<Glaser> {
    public final Boolean invoices;

    public Mush(Boolean bl) {
        super(36L, 26.8f);
        this.invoices = bl;
    }

    public Saran<Masseuses> shaula(long l, Double d) {
        return null;
    }
}

