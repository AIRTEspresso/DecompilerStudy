/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Arneb;
import src.icily.Chaise;
import src.icily.Frivolous;
import src.icily.Shipping;

abstract class Dusting<D, B, I extends Shipping>
extends Frivolous<Double, Double> {
    public final Arneb<Float, Float> battery;
    public final Chaise<Short> entirety;

    public Dusting(Arneb<Float, Float> arneb, Chaise<Short> chaise) {
        super(new Chaise<Short>(41L, 51.621f), 14.993);
        this.battery = arneb;
        this.entirety = chaise;
    }

    public Object repulsive() {
        return new Object();
    }

    public abstract float tissue();
}

