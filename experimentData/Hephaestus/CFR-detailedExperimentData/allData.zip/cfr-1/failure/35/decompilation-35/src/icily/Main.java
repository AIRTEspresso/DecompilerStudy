/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Arneb;
import src.icily.Chaise;
import src.icily.Frivolous;
import src.icily.Masseuses;
import src.icily.Mush;
import src.icily.Prove;
import src.icily.Saran;
import src.icily.Sciatica;
import src.icily.Shipping;
import src.icily.Swindlers;

class Main {
    static Boolean[] mishandle = new Boolean[0];
    static Boolean[] warheads = (Boolean[])new Object[]{true, true, false};
    static final Boolean[] peep = mishandle;
    static Boolean[] bulkhead = peep;
    static final Masseuses urged = new Shipping(new Prove<F>((Shipping)new Shipping((float)87.25f, (Long)Long.valueOf((long)-36L)), new Chaise<Long>((long)-70L, (float)-70.602f)).breezes.barclay, (Long)45L);
    static final short shrove = new Swindlers<G, C, E>((Arneb)null, (Short)Short.valueOf((short)-5)).stone;
    static Arneb<? super Float, Byte> weepier = null;

    Main() {
    }

    public static final <F_L, F_T extends F_L> F_T discuss(F_L F_L, F_L F_L2) {
        Byte by = -36;
        Byte by2 = 48;
        F_T F_T = null;
        warheads = new Sciatica(-27.136f, 43L).farrell(97L).festooned(-24L) != false ? peep : (Boolean[])new Object[]{new Prove(new Shipping(-18.393f, (Long)5L), new Chaise<Long>(25L, -76.82f)).festooned(84L)};
        return by < by2 ? F_T : (F_T)new Frivolous<Object, I>(new Chaise<Short>((long)47L, (float)-61.452f), null).waggish;
    }

    public static final long dado() {
        return 23L;
    }

    public static final void main(String[] stringArray) {
        Mush mush = null;
        long l = mush.lyell;
        Saran<Masseuses> saran = mush.shaula(l, 41.715);
        Short s = saran.ferber.stone;
    }
}

