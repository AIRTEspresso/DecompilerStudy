/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Arneb;
import src.icily.Chaise;
import src.icily.Housetops;
import src.icily.Shipping;
import src.icily.Swindlers;

final class Prove<F>
extends Housetops<Boolean, Long> {
    public Shipping breezes;
    public final Chaise<Long> entirety;

    public Prove(Shipping shipping, Chaise<Long> chaise) {
        super(new Chaise(-74L, 34.96f), (Float[])new Object[]{Float.valueOf(-1.557f), Float.valueOf(-29.181f)});
        this.breezes = shipping;
        this.entirety = chaise;
    }

    @Override
    public final Boolean festooned(Long l) {
        return false;
    }

    @Override
    public final void insulator(Byte by) {
        Arneb arneb;
        Arneb arneb2 = arneb = (Arneb)null;
        Swindlers swindlers = new Swindlers(arneb2, (short)-76);
    }
}

