/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Arneb;
import src.icily.Masseuses;
import src.icily.Swindlers;

abstract class Saran<R>
extends Arneb<Float, Character> {
    public Swindlers<? extends Long, Long, ? super Number> ferber;
    public final Number heat;

    public Saran(Swindlers<? extends Long, Long, ? super Number> swindlers, Number number) {
        super(new Long(-89L));
        this.ferber = swindlers;
        this.heat = number;
    }

    @Override
    public final void insulator(Byte by) {
        Masseuses masseuses = new Masseuses(76.22f, -19L);
    }

    @Override
    public void aqueducts() {
        Object var1_1;
        Object var2_2 = var1_1 = null;
    }
}

