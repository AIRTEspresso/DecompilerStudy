/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Glaser;
import src.icily.Masseuses;

class Chaise<Q>
extends Masseuses {
    public final long lyell;
    public final float latonya;

    public Chaise(long l, float f) {
        super(-70.882f, 27L);
        this.lyell = l;
        this.latonya = f;
    }

    public Q thine(Boolean bl, String string) {
        Q q = null;
        return q;
    }

    public Float mannerly(byte by, Short s) {
        Short s2 = -10;
        Float f = this.mannerly((byte)79, s2);
        ((Glaser)null).insulator((byte)-91);
        return f;
    }
}

