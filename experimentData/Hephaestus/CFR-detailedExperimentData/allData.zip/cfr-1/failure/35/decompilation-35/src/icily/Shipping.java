/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Chaise;
import src.icily.Dusting;
import src.icily.Housetops;
import src.icily.Masseuses;

final class Shipping
extends Masseuses {
    public float barclay;
    public final Long ballasts;

    public Shipping(float f, Long l) {
        super(81.435f, 28L);
        this.barclay = f;
        this.ballasts = l;
    }

    public final <F_N, F_X extends Character> F_N haiti(int n, F_X F_X) {
        float f = 16.528f;
        long l = -7L;
        ((Dusting)null).battery.aqueducts();
        return (F_N)new Housetops<T, Q>(new Chaise<Q>((long)l, (float)57.665f), (Float[])((Float[])new Object[]{Float.valueOf((float)97.713f)})).entirety.thine(false, "craziest");
    }
}

