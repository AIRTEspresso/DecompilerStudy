/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.icily;

import src.icily.Chaise;
import src.icily.Glaser;

class Housetops<T, Z>
implements Glaser {
    public final Chaise<Z> entirety;
    public Float[] garaged;

    public Housetops(Chaise<Z> chaise, Float[] floatArray) {
        this.entirety = chaise;
        this.garaged = floatArray;
    }

    @Override
    public void insulator(Byte by) {
        Integer n;
        Integer n2 = n = Integer.valueOf(58);
    }

    public T festooned(Z z) {
        return null;
    }
}

