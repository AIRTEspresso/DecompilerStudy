package src.inundate;

class Main {
  static public final boolean sanctums() {
    Deathblow dulles = new Deathblow();
    final Deathblow petition = dulles;
    final Deathblow starts = ((false) ?
      petition : 
       dulles);
      ((true) ?
  ((true) ?
    new Vigor<Byte, Byte>( 'b') : 
     new Vigor<Byte, Byte>( 'h')) : 
   ((Sparkled) null).deborah.curried()).squabbles(  ((true) ?
  new Vigor<Object, Double>( 'g') : 
   new Vigor<String, Double>( 'a')).smites,   ((false) ?
  (Burma) null : 
   (Burma) null).styes(null));
    return (starts.garrottes(null,   ((false) ?
  (Character[]) new Object[]{ 'U',  'p'} : 
   (Character[]) new Object[]{ 'e',  '0'})) == new Liberals<Capping<Float, Character, Integer>>(  ((true) ?
  new Object() : 
   new Object()), ((Visitors<Hershey, Character>) null).blitzing.aerobic(18.900, null)).utopias);
    
  }

  static public final void stucco() {
    Float flair = (float)-64.153;
    Object x_8 = flair;
    
  }

  static public final Kebab<Mascot, Double, Short> polaroids(Double merganser) {
    Character writings = 'w';
    final String loretta = "mohacs";
    final Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? extends Byte> carney = new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Byte>( '9', loretta);
    ((Blintzes<Integer, Sparkled, Liberals<Capping<Float, Character, Integer>>>) null).souping((Sparkled) null, (true == false));
    return new Kebab<Mascot, Double, Short>(writings, carney.patters);
    
  }

  static Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> saws = new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>( 'd', "stripper");

  static public final Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> tundra() {
    Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> chillies = new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Short>( 'V', "leave");
    chillies = null;
    return chillies;
    
  }

  static Double armory = new Newsmen<Long>(Main.saws, Main.tundra()).cantu();

  static final Character cleanups = Main.polaroids(Main.armory).uruguay;

  static public final String tentative() {
    return Main.saws.patters;
  }

  static public final void main(String[] args) {
    Main.polaroids(79.217);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Capping<Z extends Float, Q, U> {}

final class Peary implements Capping<Float, Number, Integer> {}

final class Deathblow implements Capping<Float, Deathblow, Integer> {
  public final Object garrottes(Capping<Float, ? extends Integer, ? extends Byte> juster, Character[] adjustor) {
    Boolean iowans = true;
    Double[] wallets = (Double[]) new Object[]{-81.750};
    final Hershey muddiest = (Hershey) null;
    muddiest.syntax();
    return ((iowans) ?
      wallets : 
       true);
    
  }
}

abstract class Hershey implements Capping<Float, Boolean, Character> {
  public Integer smites;
  public Character uruguay;

  public Hershey(Integer smites,Character uruguay) {
    super();
    this.smites = smites;
    this.uruguay = uruguay;
  }

  public abstract void syntax() ;
}

class Liberals<B extends Capping<Float, ? extends Character, Integer>> extends Hershey {
  public final Object utopias;
  public Character uruguay;

  public Liberals(Object utopias,Character uruguay) {
    super(70, '5');
    this.utopias = utopias;
    this.uruguay = uruguay;
  }

  public void syntax() {
    Function1<B, Void> eery = (prickled) -> {
      final B hippy = (B) null;
      final Object geodes = utopias;
      Hershey attracted = new Liberals<Capping<Float, Character, Integer>>(geodes,  'y');
      attracted.smites = 47;
      Object x_0 = hippy;
      return null;
    };
    eery.apply((B) null);
    Object x_1 = 6.403;
    
  }

  public byte influx(byte snorting) {
    final byte khakis = (byte)-74;
    uruguay =  'Y';
    return khakis;
    
  }
}

final class Kebab<N extends Liberals<Capping<Float, Character, Integer>>, D extends Double, A> extends Hershey {
  public Character uruguay;
  public final String patters;

  public Kebab(Character uruguay,String patters) {
    super(13, 'J');
    this.uruguay = uruguay;
    this.patters = patters;
  }

  public final Character aerobic(Double lyly, Kebab<? extends N, D, ? extends D> facetious) {
    Character stuns = 'E';
    final Boolean wormwood = false;
    final Sweatshop<Integer, Boolean, Boolean> fotomat = new Sweatshop<Integer, Boolean, Boolean>(wormwood, 51);
    fotomat.rottener();
    return stuns;
    
  }

  public void syntax() {
    final boolean nicaea = false;
    Object x_2 = nicaea;
    
  }
}

final class Sweatshop<I, H, C extends H> extends Liberals<Capping<Float, Character, Integer>> {
  public C sculls;
  public final I anteaters;

  public Sweatshop(C sculls,I anteaters) {
    super(new Object(), 'J');
    this.sculls = sculls;
    this.anteaters = anteaters;
  }

  public final void rottener() {
    final int retires = -78;
    Object x_3 = retires;
    
  }
}

abstract class Visitors<N extends Hershey, G> extends Liberals<Capping<Float, Character, Integer>> {
  public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
  public final Object utopias;

  public Visitors(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing,Object utopias) {
    super(new Object(), 'X');
    this.blitzing = blitzing;
    this.utopias = utopias;
  }

  public void syntax() {
    G denier = (G) null;
    Function0<Void> upturned = () -> {
      N amenity = (N) null;
      Object x_4 = amenity;
      return null;
    };
    upturned.apply();
    Object x_5 = denier;
    
  }

  public final byte influx(byte snorting) {
    final byte snapped = (byte)20;
    return snapped;
    
  }
}

final class Vigor<G, R> extends Hershey {
  public Character uruguay;

  public Vigor(Character uruguay) {
    super(-53, 'g');
    this.uruguay = uruguay;
  }

  public final void squabbles(Integer advents, Peary wrongdoer) {
    String[] examine = new Mascot((String[]) new Object[]{"cannot"}, new Object()).majored;
    final Character quiet = 'E';
    uruguay = quiet;
    Object x_6 = examine;
    
  }

  public void syntax() {
    Boolean chugs = false;
    Deloris<G, Short> concocted = (Deloris<G, Short>) null;
    final Deloris<G, Short> laurent = ((chugs) ?
      concocted : 
       (Deloris<G, Short>) null);
    concocted = concocted;
    laurent.frailest();
    
  }
}

class Mascot extends Liberals<Capping<Float, Character, Integer>> {
  public String[] majored;
  public final Object utopias;

  public Mascot(String[] majored,Object utopias) {
    super("duelists", 'i');
    this.majored = majored;
    this.utopias = utopias;
  }

  public void syntax() {
    String overused = "aleichem";
    majored = (String[]) new Object[]{"twenties", overused, "toughly"};
    Object x_7 = (short)-24;
    
  }

  public Short willed(Liberals<? extends Capping<Float, Character, Integer>> severing, Byte memorize) {
    Short dogfishes = (short)83;
    return dogfishes;
    
  }
}

abstract class Deloris<N, K extends Short> extends Visitors<Hershey, N> {
  public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
  public final Object utopias;

  public Deloris(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing,Object utopias) {
    super(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>( 'B', "chagrin"), (short)-1);
    this.blitzing = blitzing;
    this.utopias = utopias;
  }

  public N frailest() {
    N penney = (N) null;
    return penney;
    
  }
}

final class Palsied extends Deloris<Palsied, Short> {
  public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
  public final Integer punctured;

  public Palsied(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing,Integer punctured) {
    super(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>( 'R', "unproved"), new Object());
    this.blitzing = blitzing;
    this.punctured = punctured;
  }

  public final Vigor<Byte, Byte> curried() {
    Vigor<Byte, Byte> lactated = new Vigor<Byte, Byte>( 'T');
    Character gentiles = 'K';
    blitzing.uruguay = gentiles;
    return lactated;
    
  }

  public final Palsied frailest() {
    Palsied deathless = (Palsied) null;
    Main.stucco();
    return deathless;
    
  }
}

abstract class Sparkled extends Hershey {
  public final Palsied deborah;
  public Character uruguay;

  public Sparkled(Palsied deborah,Character uruguay) {
    super(17, 'v');
    this.deborah = deborah;
    this.uruguay = uruguay;
  }

  public void syntax() {
    Peary blots = new Peary();
    Peary drums = blots;
    Object x_9 = drums;
    
  }

  public Peary[] somalia(Peary[] large, Hershey motile) {
    Peary croon = (Peary) null;
    Peary[] faint = (Peary[]) new Object[]{(Peary) null, croon};
    return faint;
    
  }
}

abstract class Burma extends Hershey {
  public Character uruguay;

  public Burma(Character uruguay) {
    super(86, '0');
    this.uruguay = uruguay;
  }

  public Peary styes(Kebab<Mascot, ? super Double, ? super Long> antigen) {
    final Boolean literals = false;
    new Newsmen<Character>(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>( 'c', "tidings"), new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Short>( '5', "alar")).renee(null);
    return ((literals) ?
      new Peary() : 
       new Peary());
    
  }

  public void syntax() {
    final Boolean loyally = true;
    final Boolean parts = true;
    Object x_10 = (loyally && parts);
    
  }
}

final class Newsmen<B> extends Deloris<B, Short> {
  public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
  public final Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> aphid;

  public Newsmen(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing,Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> aphid) {
    super(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>( 'd', "slight"), new Object());
    this.blitzing = blitzing;
    this.aphid = aphid;
  }

  public final <F_C> void renee(Kebab<? super Liberals<Capping<Float, Character, Integer>>, ? super Double, F_C> vicinity) {
    final char piloted = 'l';
    aphid.uruguay =  '4';
    Object x_11 = piloted;
    
  }

  public final Double cantu() {
    Double oddest = -29.996;
    Double musty = 10.297;
    oddest = musty;
    return oddest;
    
  }
}

abstract class Blintzes<R extends Integer, H extends Sparkled, W extends Liberals<? extends Capping<Float, Character, Integer>>> extends Burma {
  public Character uruguay;

  public Blintzes(Character uruguay) {
    super( 'J');
    this.uruguay = uruguay;
  }

  public void souping(H clammier, Boolean tacky) {
    Object x_12 = (float)-51.940;
    
  }
}