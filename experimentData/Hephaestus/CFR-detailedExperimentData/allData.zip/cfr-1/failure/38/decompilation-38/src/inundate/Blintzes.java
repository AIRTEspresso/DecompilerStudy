/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Burma;
import src.inundate.Capping;
import src.inundate.Liberals;
import src.inundate.Sparkled;

abstract class Blintzes<R extends Integer, H extends Sparkled, W extends Liberals<? extends Capping<Float, Character, Integer>>>
extends Burma {
    public Character uruguay;

    public Blintzes(Character c) {
        super(Character.valueOf('J'));
        this.uruguay = c;
    }

    public void souping(H h, Boolean bl) {
        Float f = Float.valueOf(-51.94f);
    }
}

