/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Function1;
import src.inundate.Hershey;

class Liberals<B extends Capping<Float, ? extends Character, Integer>>
extends Hershey {
    public final Object utopias;
    public Character uruguay;

    public Liberals(Object object, Character c) {
        super(70, Character.valueOf('5'));
        this.utopias = object;
        this.uruguay = c;
    }

    @Override
    public void syntax() {
        Function1<Capping, Void> function1 = capping -> {
            Capping capping2 = null;
            Object object = this.utopias;
            Liberals<B> liberals = new Liberals<B>(object, Character.valueOf('y'));
            liberals.smites = 47;
            Capping capping3 = capping2;
            return null;
        };
        function1.apply(null);
        Double d = 6.403;
    }

    public byte influx(byte by) {
        this.uruguay = Character.valueOf('Y');
        return -74;
    }
}

