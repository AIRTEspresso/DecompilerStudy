/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Liberals;

class Mascot
extends Liberals<Capping<Float, Character, Integer>> {
    public String[] majored;
    public final Object utopias;

    public Mascot(String[] stringArray, Object object) {
        super("duelists", Character.valueOf('i'));
        this.majored = stringArray;
        this.utopias = object;
    }

    @Override
    public void syntax() {
        String string = "aleichem";
        this.majored = (String[])new Object[]{"twenties", string, "toughly"};
        Short s = -24;
    }

    public Short willed(Liberals<? extends Capping<Float, Character, Integer>> liberals, Byte by) {
        Short s = 83;
        return s;
    }
}

