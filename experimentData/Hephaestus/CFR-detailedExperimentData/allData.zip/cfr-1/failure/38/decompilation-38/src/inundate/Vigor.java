/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Deloris;
import src.inundate.Hershey;
import src.inundate.Mascot;
import src.inundate.Peary;

final class Vigor<G, R>
extends Hershey {
    public Character uruguay;

    public Vigor(Character c) {
        super(-53, Character.valueOf('g'));
        this.uruguay = c;
    }

    public final void squabbles(Integer n, Peary peary) {
        Character c;
        String[] stringArray = new Mascot((String[])((String[])new Object[]{"cannot"}), (Object)new Object()).majored;
        this.uruguay = c = Character.valueOf('E');
        String[] stringArray2 = stringArray;
    }

    @Override
    public void syntax() {
        Boolean bl = false;
        Deloris deloris = null;
        Deloris deloris2 = bl != false ? deloris : (Deloris)null;
        deloris2.frailest();
    }
}

