/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Liberals;

final class Sweatshop<I, H, C extends H>
extends Liberals<Capping<Float, Character, Integer>> {
    public C sculls;
    public final I anteaters;

    public Sweatshop(C c, I i) {
        super(new Object(), Character.valueOf('J'));
        this.sculls = c;
        this.anteaters = i;
    }

    public final void rottener() {
        Integer n = -78;
    }
}

