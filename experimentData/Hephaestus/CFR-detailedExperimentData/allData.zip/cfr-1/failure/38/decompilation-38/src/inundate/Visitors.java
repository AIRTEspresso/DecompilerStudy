/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Function0;
import src.inundate.Hershey;
import src.inundate.Kebab;
import src.inundate.Liberals;

abstract class Visitors<N extends Hershey, G>
extends Liberals<Capping<Float, Character, Integer>> {
    public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
    public final Object utopias;

    public Visitors(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> kebab, Object object) {
        super(new Object(), Character.valueOf('X'));
        this.blitzing = kebab;
        this.utopias = object;
    }

    @Override
    public void syntax() {
        Object var1_1 = null;
        Function0<Void> function0 = () -> {
            Hershey hershey;
            Hershey hershey2 = hershey = (Hershey)null;
            return null;
        };
        function0.apply();
        Object var3_3 = var1_1;
    }

    @Override
    public final byte influx(byte by) {
        return 20;
    }
}

