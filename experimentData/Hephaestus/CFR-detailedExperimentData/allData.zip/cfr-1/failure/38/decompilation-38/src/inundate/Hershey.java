/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;

abstract class Hershey
implements Capping<Float, Boolean, Character> {
    public Integer smites;
    public Character uruguay;

    public Hershey(Integer n, Character c) {
        this.smites = n;
        this.uruguay = c;
    }

    public abstract void syntax();
}

