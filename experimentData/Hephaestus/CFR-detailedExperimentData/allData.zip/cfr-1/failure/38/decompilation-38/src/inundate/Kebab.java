/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Hershey;
import src.inundate.Liberals;
import src.inundate.Sweatshop;

final class Kebab<N extends Liberals<Capping<Float, Character, Integer>>, D extends Double, A>
extends Hershey {
    public Character uruguay;
    public final String patters;

    public Kebab(Character c, String string) {
        super(13, Character.valueOf('J'));
        this.uruguay = c;
        this.patters = string;
    }

    public final Character aerobic(Double d, Kebab<? extends N, D, ? extends D> kebab) {
        Character c = Character.valueOf('E');
        Boolean bl = false;
        Sweatshop sweatshop = new Sweatshop(bl, 51);
        sweatshop.rottener();
        return c;
    }

    @Override
    public void syntax() {
        Boolean bl = false;
    }
}

