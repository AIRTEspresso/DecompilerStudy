/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Deloris;
import src.inundate.Kebab;
import src.inundate.Liberals;

final class Newsmen<B>
extends Deloris<B, Short> {
    public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
    public final Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> aphid;

    public Newsmen(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> kebab, Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> kebab2) {
        super(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>(Character.valueOf('d'), "slight"), new Object());
        this.blitzing = kebab;
        this.aphid = kebab2;
    }

    public final <F_C> void renee(Kebab<? super Liberals<Capping<Float, Character, Integer>>, ? super Double, F_C> kebab) {
        this.aphid.uruguay = Character.valueOf('4');
        Character c = Character.valueOf('l');
    }

    public final Double cantu() {
        Double d;
        Double d2 = -29.996;
        d2 = d = Double.valueOf(10.297);
        return d2;
    }
}

