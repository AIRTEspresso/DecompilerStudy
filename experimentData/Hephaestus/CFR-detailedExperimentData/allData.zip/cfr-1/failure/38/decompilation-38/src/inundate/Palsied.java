/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Deloris;
import src.inundate.Kebab;
import src.inundate.Liberals;
import src.inundate.Main;
import src.inundate.Vigor;

final class Palsied
extends Deloris<Palsied, Short> {
    public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
    public final Integer punctured;

    public Palsied(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> kebab, Integer n) {
        super(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>(Character.valueOf('R'), "unproved"), new Object());
        this.blitzing = kebab;
        this.punctured = n;
    }

    public final Vigor<Byte, Byte> curried() {
        Character c;
        Vigor<Byte, Byte> vigor = new Vigor<Byte, Byte>(Character.valueOf('T'));
        this.blitzing.uruguay = c = Character.valueOf('K');
        return vigor;
    }

    @Override
    public final Palsied frailest() {
        Palsied palsied = null;
        Main.stucco();
        return palsied;
    }
}

