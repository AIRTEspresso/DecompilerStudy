/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Blintzes;
import src.inundate.Burma;
import src.inundate.Capping;
import src.inundate.Deathblow;
import src.inundate.Kebab;
import src.inundate.Liberals;
import src.inundate.Mascot;
import src.inundate.Newsmen;
import src.inundate.Vigor;
import src.inundate.Visitors;

class Main {
    static Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> saws = new Kebab(Character.valueOf('d'), "stripper");
    static Double armory = new Newsmen(saws, Main.tundra()).cantu();
    static final Character cleanups = Main.polaroids((Double)Main.armory).uruguay;

    Main() {
    }

    public static final boolean sanctums() {
        Deathblow deathblow;
        Deathblow deathblow2 = deathblow = new Deathblow();
        Deathblow deathblow3 = deathblow;
        new Vigor(Character.valueOf('b')).squabbles(new Vigor<G, R>((Character)Character.valueOf((char)'g')).smites, ((Burma)null).styes(null));
        return deathblow3.garrottes(null, (Character[])new Object[]{Character.valueOf('e'), Character.valueOf('0')}) == new Liberals<B>((Object)new Object(), (Character)((Visitors)null).blitzing.aerobic((Double)Double.valueOf((double)18.9), null)).utopias;
    }

    public static final void stucco() {
        Float f;
        Float f2 = f = Float.valueOf(-64.153f);
    }

    public static final Kebab<Mascot, Double, Short> polaroids(Double d) {
        Character c = Character.valueOf('w');
        Kebab kebab = new Kebab(Character.valueOf('9'), "mohacs");
        ((Blintzes)null).souping(null, false);
        return new Kebab<Mascot, Double, Short>(c, kebab.patters);
    }

    public static final Kebab<Liberals<Capping<Float, Character, Integer>>, ? extends Double, ? super Short> tundra() {
        Kebab kebab = new Kebab(Character.valueOf('V'), "leave");
        kebab = null;
        return kebab;
    }

    public static final String tentative() {
        return Main.saws.patters;
    }

    public static final void main(String[] stringArray) {
        Main.polaroids(79.217);
    }
}

