/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Hershey;
import src.inundate.Kebab;
import src.inundate.Liberals;
import src.inundate.Mascot;
import src.inundate.Newsmen;
import src.inundate.Peary;

abstract class Burma
extends Hershey {
    public Character uruguay;

    public Burma(Character c) {
        super(86, Character.valueOf('0'));
        this.uruguay = c;
    }

    public Peary styes(Kebab<Mascot, ? super Double, ? super Long> kebab) {
        Boolean bl = false;
        new Newsmen(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>(Character.valueOf('c'), "tidings"), new Kebab(Character.valueOf('5'), "alar")).renee(null);
        return bl != false ? new Peary() : new Peary();
    }

    @Override
    public void syntax() {
        Boolean bl = true;
        Boolean bl2 = true;
        Boolean bl3 = bl != false && bl2 != false;
    }
}

