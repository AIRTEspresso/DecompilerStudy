/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Hershey;
import src.inundate.Kebab;
import src.inundate.Liberals;
import src.inundate.Visitors;

abstract class Deloris<N, K extends Short>
extends Visitors<Hershey, N> {
    public final Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> blitzing;
    public final Object utopias;

    public Deloris(Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character> kebab, Object object) {
        super(new Kebab<Liberals<Capping<Float, Character, Integer>>, Double, Character>(Character.valueOf('B'), "chagrin"), (short)-1);
        this.blitzing = kebab;
        this.utopias = object;
    }

    public N frailest() {
        N n = null;
        return n;
    }
}

