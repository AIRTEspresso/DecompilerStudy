/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Hershey;
import src.inundate.Palsied;
import src.inundate.Peary;

abstract class Sparkled
extends Hershey {
    public final Palsied deborah;
    public Character uruguay;

    public Sparkled(Palsied palsied, Character c) {
        super(17, Character.valueOf('v'));
        this.deborah = palsied;
        this.uruguay = c;
    }

    @Override
    public void syntax() {
        Peary peary;
        Peary peary2;
        Peary peary3 = peary2 = (peary = new Peary());
    }

    public Peary[] somalia(Peary[] pearyArray, Hershey hershey) {
        Peary peary = null;
        Peary[] pearyArray2 = (Peary[])new Object[]{null, peary};
        return pearyArray2;
    }
}

