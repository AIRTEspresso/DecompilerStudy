/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;
import src.inundate.Hershey;

final class Deathblow
implements Capping<Float, Deathblow, Integer> {
    Deathblow() {
    }

    public final Object garrottes(Capping<Float, ? extends Integer, ? extends Byte> capping, Character[] characterArray) {
        Boolean bl = true;
        Double[] doubleArray = (Double[])new Object[]{-81.75};
        Hershey hershey = null;
        hershey.syntax();
        return bl != false ? doubleArray : Boolean.valueOf(true);
    }
}

