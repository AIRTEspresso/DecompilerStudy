/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.inundate;

import src.inundate.Capping;

final class Peary
implements Capping<Float, Number, Integer> {
    Peary() {
    }
}

