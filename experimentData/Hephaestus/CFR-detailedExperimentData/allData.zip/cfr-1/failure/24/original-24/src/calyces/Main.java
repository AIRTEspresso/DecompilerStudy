package src.calyces;

class Main {
  static public final long medalists(long krupp) {
    return krupp;
  }

  static public final Float colleens(Integer veto, short isabel) {
    final Nonrigid renter = (Nonrigid) null;
    Float proffers = renter.caliper().parching;
    Function1<Long, Void> sneering = (destroyer) -> {
      Boolean brenton = false;
      boolean heaped = true;
      boolean spoils = ((brenton) ?
        true : 
         heaped);
      ((Commuters) null).stales.valvoline(spoils, true);
      Object x_0 = ((false) ?
         'z' : 
          'z');
      return null;
    };
    final Valve bicker = (Valve) null;
    sneering.apply(bicker.molars);
    return proffers;
    
  }

  static Nearing<? extends Boolean, ? extends String, ? super Float> mender = (Nearing<Boolean, String, Float>) null;

  static final Integer horseplay = ((Nearing<Boolean, String, Double>) null).wackiest(Main.mender.penguins()).mission;

  static short brimful = Main.mender.wackiest(null).scenery;

  static final Float flavor = Main.colleens(Main.horseplay, Main.brimful);

  static Nearing<? super Boolean, ? extends String, String> saran = ((false) ?
  (Nearing<Boolean, String, String>) null : 
     ((true) ?
  (Upstaging<Commuters>) null : 
   (Upstaging<Commuters>) null).tulsidas((byte)51));

  static Songsters geronimo = (Songsters) null;

  static public final byte queued() {
    final byte friend = Main.queued();
    final Boolean klutzy = false;
    final Double pursers = 56.339;
    ((Agni<Float, Double>) null).caddying(-88,   ((klutzy) ?
  pursers : 
   -18.188));
    return friend;
    
  }

  static public final boolean intuiting(Short kebab, boolean kwan) {
    final Boolean graceless = kwan;
    final boolean liver = (kwan && graceless);
    Main.mender = null;
    return liver;
    
  }

  static public final short spouses(Integer... shorn) {
    return Main.brimful;
  }

  static public final void main(String[] args) {
    Main.spouses(null);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Nonrigid {
  public Float parching;
  public final short scenery;

  public Nonrigid(Float parching,short scenery) {
    this.parching = parching;
    this.scenery = scenery;
  }

  public Nonrigid caliper() {
    return (Nonrigid) null;
  }
}

final class Misdeeds<R extends Boolean, Z> extends Nonrigid {
  public final short scenery;

  public Misdeeds(short scenery) {
    super((float)-44.989, (short)11);
    this.scenery = scenery;
  }

  public final void valvoline(boolean arrived, R cartilage) {
    R gentlemen = (R) null;
    R chugs = gentlemen;
    Object x_1 = chugs;
    
  }

  public final Nonrigid caliper() {
    return new Misdeeds<Boolean, Float>((short)84);
  }
}

abstract class Commuters extends Nonrigid {
  public final Misdeeds<Boolean, Nonrigid> stales;
  public final short scenery;

  public Commuters(Misdeeds<Boolean, Nonrigid> stales,short scenery) {
    super((float)-25.831, (short)-90);
    this.stales = stales;
    this.scenery = scenery;
  }

  public abstract <F_H extends Object> Byte bravely(Byte dickinson, F_H fulness) ;

  public long pounding(Double ancillary) {
    final long synching = (long)-96;
    return synching;
    
  }
}

abstract class Valve extends Nonrigid {
  public final long molars;
  public Float parching;

  public Valve(long molars,Float parching) {
    super((float)25.490, (short)61);
    this.molars = molars;
    this.parching = parching;
  }

  public final Nonrigid caliper() {
    return (Commuters) null;
  }

  public abstract char israelis(long rates, byte quickie) ;
}

abstract class Songsters extends Commuters {
  public Integer mission;
  public final Misdeeds<Boolean, Nonrigid> stales;

  public Songsters(Integer mission,Misdeeds<Boolean, Nonrigid> stales) {
    super(new Misdeeds<Boolean, Nonrigid>((short)-50), (short)46);
    this.mission = mission;
    this.stales = stales;
  }

  public final long pounding(Double ancillary) {
    return (long)43;
  }

  public abstract Double dirks(char seemlier, Float trumpeted) ;
}

interface Nearing<V extends Boolean, D extends String, B> {
  public abstract Songsters wackiest(V alley) ;

  public abstract V penguins() ;
}

interface Upstaging<J> extends Nearing<Boolean, String, J> {
  public abstract Nearing<? super Boolean, ? extends String, String> tulsidas(byte slangy) ;
}

abstract class Agni<R extends Float, I> extends Commuters {
  public final Misdeeds<Boolean, Nonrigid> stales;
  public final R beaten;

  public Agni(Misdeeds<Boolean, Nonrigid> stales,R beaten) {
    super(new Misdeeds<Boolean, Nonrigid>((short)-52), (short)-8);
    this.stales = stales;
    this.beaten = beaten;
  }

  public abstract void caddying(int gravely, I firefly) ;
}

abstract class Flyleaves implements Upstaging<Long> {}