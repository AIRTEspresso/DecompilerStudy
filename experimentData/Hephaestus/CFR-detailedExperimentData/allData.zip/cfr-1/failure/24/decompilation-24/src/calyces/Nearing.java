/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Songsters;

interface Nearing<V extends Boolean, D extends String, B> {
    public Songsters wackiest(V var1);

    public V penguins();
}

