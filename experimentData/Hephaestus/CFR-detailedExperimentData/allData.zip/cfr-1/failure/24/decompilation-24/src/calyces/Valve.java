/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Nonrigid;

abstract class Valve
extends Nonrigid {
    public final long molars;
    public Float parching;

    public Valve(long l, Float f) {
        super(Float.valueOf(25.49f), (short)61);
        this.molars = l;
        this.parching = f;
    }

    @Override
    public final Nonrigid caliper() {
        return null;
    }

    public abstract char israelis(long var1, byte var3);
}

