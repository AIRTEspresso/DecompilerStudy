/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Nonrigid;

final class Misdeeds<R extends Boolean, Z>
extends Nonrigid {
    public final short scenery;

    public Misdeeds(short s) {
        super(Float.valueOf(-44.989f), (short)11);
        this.scenery = s;
    }

    public final void valvoline(boolean bl, R r) {
        Boolean bl2;
        Boolean bl3;
        Boolean bl4 = bl3 = (bl2 = (Boolean)null);
    }

    @Override
    public final Nonrigid caliper() {
        return new Misdeeds<R, Z>(84);
    }
}

