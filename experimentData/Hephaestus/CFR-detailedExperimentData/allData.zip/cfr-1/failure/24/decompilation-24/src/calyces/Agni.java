/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Commuters;
import src.calyces.Misdeeds;
import src.calyces.Nonrigid;

abstract class Agni<R extends Float, I>
extends Commuters {
    public final Misdeeds<Boolean, Nonrigid> stales;
    public final R beaten;

    public Agni(Misdeeds<Boolean, Nonrigid> misdeeds, R r) {
        super(new Misdeeds<Boolean, Nonrigid>(-52), (short)-8);
        this.stales = misdeeds;
        this.beaten = r;
    }

    public abstract void caddying(int var1, I var2);
}

