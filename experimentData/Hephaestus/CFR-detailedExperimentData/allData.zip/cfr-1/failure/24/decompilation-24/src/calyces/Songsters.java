/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Commuters;
import src.calyces.Misdeeds;
import src.calyces.Nonrigid;

abstract class Songsters
extends Commuters {
    public Integer mission;
    public final Misdeeds<Boolean, Nonrigid> stales;

    public Songsters(Integer n, Misdeeds<Boolean, Nonrigid> misdeeds) {
        super(new Misdeeds<Boolean, Nonrigid>(-50), (short)46);
        this.mission = n;
        this.stales = misdeeds;
    }

    @Override
    public final long pounding(Double d) {
        return 43L;
    }

    public abstract Double dirks(char var1, Float var2);
}

