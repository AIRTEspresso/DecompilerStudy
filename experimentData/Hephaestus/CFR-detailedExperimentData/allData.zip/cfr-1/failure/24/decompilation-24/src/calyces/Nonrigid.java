/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

abstract class Nonrigid {
    public Float parching;
    public final short scenery;

    public Nonrigid(Float f, short s) {
        this.parching = f;
        this.scenery = s;
    }

    public Nonrigid caliper() {
        return null;
    }
}

