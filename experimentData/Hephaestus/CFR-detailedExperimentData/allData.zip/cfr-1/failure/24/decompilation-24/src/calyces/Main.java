/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Agni;
import src.calyces.Commuters;
import src.calyces.Function1;
import src.calyces.Nearing;
import src.calyces.Nonrigid;
import src.calyces.Songsters;
import src.calyces.Upstaging;
import src.calyces.Valve;

class Main {
    static Nearing<? extends Boolean, ? extends String, ? super Float> mender = null;
    static final Integer horseplay = ((Nearing)null).wackiest(Main.mender.penguins()).mission;
    static short brimful = Main.mender.wackiest(null).scenery;
    static final Float flavor = Main.colleens(horseplay, brimful);
    static Nearing<? super Boolean, ? extends String, String> saran = ((Upstaging)null).tulsidas((byte)51);
    static Songsters geronimo = null;

    Main() {
    }

    public static final long medalists(long l) {
        return l;
    }

    public static final Float colleens(Integer n, short s) {
        Nonrigid nonrigid = null;
        Float f = nonrigid.caliper().parching;
        Function1<Long, Void> function1 = l -> {
            Boolean bl = false;
            boolean bl2 = true;
            boolean bl3 = bl != false ? true : bl2;
            ((Commuters)null).stales.valvoline(bl3, true);
            Character c = Character.valueOf('z');
            return null;
        };
        Valve valve = null;
        function1.apply(valve.molars);
        return f;
    }

    public static final byte queued() {
        byte by = Main.queued();
        Boolean bl = false;
        Double d = 56.339;
        ((Agni)null).caddying(-88, bl != false ? d : -18.188);
        return by;
    }

    public static final boolean intuiting(Short s, boolean bl) {
        Boolean bl2 = bl;
        boolean bl3 = bl && bl2 != false;
        mender = null;
        return bl3;
    }

    public static final short spouses(Integer ... integerArray) {
        return brimful;
    }

    public static final void main(String[] stringArray) {
        Main.spouses(null);
    }
}

