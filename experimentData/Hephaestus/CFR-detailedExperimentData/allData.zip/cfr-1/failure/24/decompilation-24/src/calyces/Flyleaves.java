/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Upstaging;

abstract class Flyleaves
implements Upstaging<Long> {
    Flyleaves() {
    }
}

