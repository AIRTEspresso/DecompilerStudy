/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.calyces;

import src.calyces.Misdeeds;
import src.calyces.Nonrigid;

abstract class Commuters
extends Nonrigid {
    public final Misdeeds<Boolean, Nonrigid> stales;
    public final short scenery;

    public Commuters(Misdeeds<Boolean, Nonrigid> misdeeds, short s) {
        super(Float.valueOf(-25.831f), (short)-90);
        this.stales = misdeeds;
        this.scenery = s;
    }

    public abstract <F_H> Byte bravely(Byte var1, F_H var2);

    public long pounding(Double d) {
        return -96L;
    }
}

