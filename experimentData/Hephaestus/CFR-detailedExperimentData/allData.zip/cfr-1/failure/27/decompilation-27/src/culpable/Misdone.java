/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.culpable;

abstract class Misdone<B extends Byte> {
    public final Short populist;

    public Misdone(Short s) {
        this.populist = s;
    }
}

