/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.culpable;

import src.culpable.Misdone;

abstract class Motility
extends Misdone<Byte> {
    public final Short populist;

    public Motility(Short s) {
        super((short)59);
        this.populist = s;
    }

    public abstract void pageantry();
}

