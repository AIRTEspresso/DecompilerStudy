/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.culpable;

import src.culpable.Misdone;

abstract class Educators<F, X, N extends X>
extends Misdone<Byte> {
    public Educators() {
        super((short)59);
    }

    public String feud(long l) {
        return "ululated";
    }
}

