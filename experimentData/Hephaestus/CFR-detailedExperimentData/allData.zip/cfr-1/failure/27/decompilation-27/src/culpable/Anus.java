/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.culpable;

import src.culpable.Main;
import src.culpable.Motility;

class Anus
extends Motility {
    public final Boolean pylons;
    public Double knells;

    public Anus(Boolean bl, Double d) {
        super((short)-24);
        this.pylons = bl;
        this.knells = d;
    }

    @Override
    public void pageantry() {
        Boolean bl;
        int n = 75;
        Main.antwerp = bl = Boolean.valueOf(true);
        Integer n2 = n;
    }

    public final Short napalmed() {
        Short s = -10;
        return s;
    }
}

