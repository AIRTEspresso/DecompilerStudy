/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.culpable;

import src.culpable.Anus;
import src.culpable.Educators;
import src.culpable.Misdone;
import src.culpable.Motility;
import src.culpable.Successor;

class Main {
    static Double domestic = -13.13;
    static Boolean antwerp = domestic < 23.0;
    static Educators<Boolean, Object, Object> protein = Main.armory(new Long(0L));
    static Object handrails = antwerp != false ? protein.feud(68L) : protein.feud(-46L);

    Main() {
    }

    public static final float lucifer(float f) {
        float f2 = f;
        return f2;
    }

    public static final Number baskets() {
        return (short)-1;
    }

    public static final Object hydras(Object object) {
        return new Object();
    }

    public static final byte pocked(byte by) {
        return Main.pocked((byte)-69);
    }

    public static final Short milked(Short s, Integer n) {
        Integer n2 = -14;
        Short s2 = Main.milked(((Misdone)null).populist, n2);
        n2 = 29;
        return s2;
    }

    public static final Educators<Boolean, Object, Object> armory(Number number) {
        Educators educators = null;
        Motility motility = null;
        motility.pageantry();
        return educators;
    }

    public static final void main(String[] stringArray) {
        Boolean bl = true;
        Double d = 23.43;
        Float f = Float.valueOf(20.29f);
        Float f2 = Float.valueOf(new Anus((Boolean)bl, (Double)d).pylons != false ? 39.736f : new Successor<Y, U>((Float)f, (Boolean)Boolean.valueOf((boolean)false)).farmhands.floatValue());
    }
}

