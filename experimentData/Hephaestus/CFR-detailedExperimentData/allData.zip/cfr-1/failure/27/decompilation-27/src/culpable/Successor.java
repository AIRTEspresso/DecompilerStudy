/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.culpable;

import src.culpable.Anus;

class Successor<Y, U>
extends Anus {
    public final Float farmhands;
    public final Boolean pylons;

    public Successor(Float f, Boolean bl) {
        super(false, 74.845);
        this.farmhands = f;
        this.pylons = bl;
    }

    @Override
    public void pageantry() {
        Object var1_1;
        Object var2_2;
        Object var3_3 = var2_2 = (var1_1 = null);
    }

    public Y needle(U u) {
        return null;
    }
}

