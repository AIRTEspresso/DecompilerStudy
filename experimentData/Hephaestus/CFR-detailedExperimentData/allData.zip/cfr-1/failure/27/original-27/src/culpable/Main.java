package src.culpable;

class Main {
  static public final float lucifer(float washtubs) {
    final float stiffest = washtubs;
    return stiffest;
    
  }

  static public final Number baskets() {
    return (short)-1;
  }

  static public final Object hydras(Object smithies) {
    return new Object();
  }

  static public final byte pocked(byte sketches) {
    final byte wheeler = (byte)-69;
    return Main.pocked(wheeler);
    
  }

  static public final Short milked(Short coven, Integer rosette) {
    Integer carved = -14;
    final Short compress = Main.milked(((Misdone<Byte>) null).populist, carved);
    carved = 29;
    return compress;
    
  }

  static Double domestic = -13.13;

  static Boolean antwerp = (Main.domestic < (byte)23);

  static public final Educators<Boolean, Object, Object> armory(Number fillmore) {
    Educators<Boolean, Object, Object> chartres = (Educators<Boolean, Object, Object>) null;
    Motility galapagos = (Motility) null;
    galapagos.pageantry();
    return chartres;
    
  }

  static Educators<Boolean, Object, Object> protein = Main.armory((Number) new Long(0));

  static Object handrails = ((Main.antwerp) ?
  Main.protein.feud((long)68) : 
   Main.protein.feud((long)-46));

  static public final void main(String[] args) {
    Boolean appraiser = true;
    Double educated = 23.430;
    final Float rheostat = (float)20.29;
    Object x_0 = ((new Anus(appraiser, educated).pylons) ?
      (float)39.736 : 
       new Successor<Byte, Integer>(rheostat, false).farmhands);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Misdone<B extends Byte> {
  public final Short populist;

  public Misdone(Short populist) {
    this.populist = populist;
  }
}

abstract class Educators<F, X, N extends X> extends Misdone<Byte> {
  public Educators() {
    super((short)59);
}

  public String feud(long arising) {
    final String disembark = "ululated";
    return disembark;
    
  }
}

abstract class Motility extends Misdone<Byte> {
  public final Short populist;

  public Motility(Short populist) {
    super((short)59);
    this.populist = populist;
  }

  public abstract void pageantry() ;
}

class Anus extends Motility {
  public final Boolean pylons;
  public Double knells;

  public Anus(Boolean pylons,Double knells) {
    super((short)-24);
    this.pylons = pylons;
    this.knells = knells;
  }

  public void pageantry() {
    int truckers = 75;
    final Boolean tiredness = true;
    Main.antwerp = tiredness;
    Object x_1 = truckers;
    
  }

  public final Short napalmed() {
    Short afternoon = (short)-10;
    return afternoon;
    
  }
}

class Successor<Y, U> extends Anus {
  public final Float farmhands;
  public final Boolean pylons;

  public Successor(Float farmhands,Boolean pylons) {
    super(false, 74.845);
    this.farmhands = farmhands;
    this.pylons = pylons;
  }

  public void pageantry() {
    final U cancans = (U) null;
    U testimony = cancans;
    Object x_2 = testimony;
    
  }

  public Y needle(U unties) {
    return (Y) null;
  }
}