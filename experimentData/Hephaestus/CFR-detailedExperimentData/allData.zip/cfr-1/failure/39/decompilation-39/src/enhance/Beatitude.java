/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.enhance;

import src.enhance.Rajahs;
import src.enhance.Sketches;

abstract class Beatitude<L, H>
extends Sketches {
    public final Rajahs apogee;

    public Beatitude(Rajahs rajahs) {
        super((byte)65);
        this.apogee = rajahs;
    }
}

