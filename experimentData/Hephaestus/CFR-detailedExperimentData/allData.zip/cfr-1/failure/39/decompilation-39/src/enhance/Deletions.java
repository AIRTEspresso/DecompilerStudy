/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.enhance;

import src.enhance.Beatitude;
import src.enhance.Grackles;
import src.enhance.Naming;
import src.enhance.Rajahs;
import src.enhance.Sketches;

class Deletions<Q>
implements Grackles<Long> {
    public final Q foolproof;
    public final char tumbled;

    public Deletions(Q q, char c) {
        this.foolproof = q;
        this.tumbled = c;
    }

    @Override
    public Boolean rooked(float f, Long l) {
        Rajahs rajahs;
        Beatitude beatitude = null;
        Rajahs rajahs2 = rajahs = beatitude.apogee;
        return this.rooked(rajahs2.lanterns, l);
    }

    public final Sketches slime(Q q) {
        Boolean bl = true;
        Q q2 = q;
        Naming naming = new Naming(null);
        return this.slime((bl.booleanValue() ? new Naming(q2) : naming).horsewhip);
    }
}

