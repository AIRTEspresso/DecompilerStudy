/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Rudyard;

abstract class Intrigued<O extends Long>
extends Rudyard {
    public Apertures loewe;
    public Apertures aussies;

    public Intrigued(Apertures apertures, Apertures apertures2) {
        super(-47.111, new Long(-32L));
        this.loewe = apertures;
        this.aussies = apertures2;
    }
}

