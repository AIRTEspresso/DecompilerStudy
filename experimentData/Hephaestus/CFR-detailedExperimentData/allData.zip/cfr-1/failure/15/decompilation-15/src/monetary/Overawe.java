/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Cardozo;
import src.monetary.Intrigued;
import src.monetary.Main;

final class Overawe<P, V, R extends Apertures>
extends Intrigued<Long> {
    public Apertures loewe;

    public Overawe(Apertures apertures) {
        super(new Apertures(new Cardozo(38, 41L), -23L), new Apertures(new Cardozo(33, -16L), 10L));
        this.loewe = apertures;
    }

    public final Intrigued<Long> orchid() {
        Boolean bl;
        Apertures apertures = this.loewe;
        Overawe<P, V, R> overawe = new Overawe<P, V, R>(apertures);
        Main.retrace = bl = Boolean.valueOf(false);
        return overawe;
    }

    public final <F_M extends Apertures> F_M annoyed() {
        return (F_M)((Apertures)null);
    }
}

