/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Clarifies;

abstract class Bullpen<A extends Double, V extends Apertures>
implements Clarifies<V> {
    Bullpen() {
    }

    public A axial() {
        return (A)((Double)null);
    }
}

