/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Boleros;
import src.monetary.Cardozo;
import src.monetary.Main;
import src.monetary.Overawe;

final class Boom
extends Boleros<Character, Integer> {
    public Character assuaging;
    public final Integer printable;

    public Boom(Character c, Integer n) {
        super(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo(-89, 60L), -45L)), Character.valueOf('G'));
        this.assuaging = c;
        this.printable = n;
    }

    @Override
    public final short varicose(Character c, Integer n) {
        Character c2 = Character.valueOf('b');
        Main.snapping();
        return this.varicose(c2, n);
    }
}

