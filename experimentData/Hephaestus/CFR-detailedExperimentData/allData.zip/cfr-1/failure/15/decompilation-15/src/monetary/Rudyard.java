/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

class Rudyard {
    public final double duration;
    public final Number cilia;

    public Rudyard(double d, Number number) {
        this.duration = d;
        this.cilia = number;
    }

    public final String topmasts(Character c) {
        String string = this.topmasts(c);
        return string;
    }
}

