/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Boleros;
import src.monetary.Bullpen;
import src.monetary.Clarifies;
import src.monetary.Rudyard;

final class Bovary<C extends Rudyard, T extends Double>
implements Clarifies<C> {
    public final Bullpen<T, ? super Apertures> obsoleted;
    public Boleros<? extends Character, Integer> profit;

    public Bovary(Bullpen<T, ? super Apertures> bullpen, Boleros<? extends Character, Integer> boleros) {
        this.obsoleted = bullpen;
        this.profit = boleros;
    }
}

