/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Bounciest;
import src.monetary.Tinctures;

class Blockades<R, E>
extends Tinctures<E> {
    public R ululated;
    public final Bounciest blamed;

    public Blockades(R r, Bounciest bounciest) {
        super(null, null);
        this.ululated = r;
        this.blamed = bounciest;
    }

    @Override
    public E rummy() {
        E e = null;
        return e;
    }
}

