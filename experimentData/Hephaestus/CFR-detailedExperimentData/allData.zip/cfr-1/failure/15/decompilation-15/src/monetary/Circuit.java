/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Boleros;
import src.monetary.Bovary;
import src.monetary.Cardozo;
import src.monetary.Main;
import src.monetary.Overawe;
import src.monetary.Rudyard;
import src.monetary.Upstaging;

abstract class Circuit<O extends Double>
extends Rudyard {
    public Circuit() {
        super(1.232, new Long(-45L));
    }

    public <F_Q extends Double> Upstaging<Boolean, Long> tam(O o, F_Q F_Q) {
        Upstaging upstaging = null;
        Character c = Character.valueOf('5');
        Main.aymara = new Boleros<Character, Object>(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo(5, 61L), 27L)), Character.valueOf('x')).varicose(c, null);
        return upstaging;
    }

    public O shriller(O o) {
        Bovary bovary = new Bovary(null, new Boleros<Character, Integer>(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo(-8, -40L), 41L)), Character.valueOf('s')));
        return (O)bovary.obsoleted.axial();
    }
}

