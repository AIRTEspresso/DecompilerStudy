/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Clarifies;
import src.monetary.Overawe;

class Boleros<I extends Character, V extends Integer>
implements Clarifies<V> {
    public final Overawe<Double, Byte, Apertures> archibald;
    public I assuaging;

    public Boleros(Overawe<Double, Byte, Apertures> overawe, I i) {
        this.archibald = overawe;
        this.assuaging = i;
    }

    public final I sell(short s, Object object) {
        Character c = null;
        Character c2 = null;
        this.assuaging = c2;
        return (I)c;
    }

    public short varicose(I i, V v) {
        return 64;
    }
}

