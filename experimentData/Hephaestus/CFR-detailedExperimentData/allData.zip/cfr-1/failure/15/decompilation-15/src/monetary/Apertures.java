/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Cardozo;
import src.monetary.Rudyard;

final class Apertures
extends Rudyard {
    public final Cardozo whiz;
    public Long acrobat;

    public Apertures(Cardozo cardozo, Long l) {
        super(-20.668, new Long(25L));
        this.whiz = cardozo;
        this.acrobat = l;
    }

    public final short swigged() {
        return 66;
    }
}

