/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Bounciest;
import src.monetary.Bullpen;

abstract class Tinctures<R>
extends Bullpen<Double, Apertures> {
    public final Bounciest blamed;
    public R someones;

    public Tinctures(Bounciest bounciest, R r) {
        this.blamed = bounciest;
        this.someones = r;
    }

    public abstract R rummy();
}

