/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Boleros;
import src.monetary.Cardozo;
import src.monetary.Circuit;
import src.monetary.Main;
import src.monetary.Overawe;

abstract class Bounciest
extends Boleros<Character, Integer> {
    public final Circuit<Double> incessant;
    public Character assuaging;

    public Bounciest(Circuit<Double> circuit, Character c) {
        super(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo(35, 20L), -76L)), Character.valueOf('m'));
        this.incessant = circuit;
        this.assuaging = c;
    }

    @Override
    public final short varicose(Character c, Integer n) {
        return Main.aymara;
    }
}

