/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Boleros;
import src.monetary.Cardozo;
import src.monetary.Chancel;
import src.monetary.Circuit;
import src.monetary.Function0;
import src.monetary.Function1;
import src.monetary.Gielgud;
import src.monetary.Intrigued;
import src.monetary.Overawe;
import src.monetary.Pigtail;
import src.monetary.Rudyard;
import src.monetary.Tinctures;
import src.monetary.Viscid;

class Main {
    static Boolean retrace = true;
    static final Character fancied = Character.valueOf('8');
    static final Character chiseling = Character.valueOf(retrace != false ? (char)fancied.charValue() : (char)'n');
    static final String itchiest = new Rudyard(-44.993, new Long(93L)).topmasts(chiseling);
    static short aymara = (short)-66;
    static Number dirks = new Cardozo((short)-57, (long)60L).juts;

    Main() {
    }

    public static final byte mellowest(long l) {
        Apertures apertures = ((Intrigued)null).loewe;
        Cardozo cardozo = apertures.whiz;
        Main.smugglers(Main.qualms(cardozo));
        return -62;
    }

    public static final void smugglers(Object object) {
        Double d = 57.275;
        Main.nonwhites(d);
        Long l = 65L;
    }

    public static final void nonwhites(Double d) {
        Double d2;
        Double d3 = d2 = Double.valueOf(-39.49);
    }

    public static final Integer qualms(Rudyard rudyard) {
        return 17;
    }

    public static final Long continues(Long l, Long l2) {
        Intrigued<Long> intrigued = new Boleros<Character, V>(new Overawe<Double, Byte, Apertures>((Apertures)new Apertures((Cardozo)new Cardozo((short)-49, (long)-82L), (Long)Long.valueOf((long)-20L))), Character.valueOf((char)'8')).archibald.orchid();
        Apertures apertures = intrigued.loewe;
        Chancel chancel = null;
        chancel.bernoulli().incessant.tam(-81.882, -31.225).thereof();
        return apertures.acrobat;
    }

    public static final <F_F> F_F hepatitis(F_F F_F, F_F F_F2) {
        F_F F_F3 = F_F2;
        Object var3_3 = null;
        Object var4_4 = null;
        Function0<Void> function0 = () -> {
            Function1<Object, Object> function1 = object -> null;
            Gielgud gielgud = null;
            Object r = gielgud.driven.ululated;
            function1.apply(r);
            return null;
        };
        function0.apply();
        return F_F3;
    }

    public static final void snapping() {
        Viscid viscid = null;
        Pigtail pigtail = viscid.hoodie;
        Tinctures<? extends Character> tinctures = pigtail.passively(null);
        dirks = ((Circuit)null).cilia;
        Tinctures<? extends Character> tinctures2 = tinctures;
    }

    public static final void main(String[] stringArray) {
        Float[] floatArray = (Float[])new Object[]{Float.valueOf(96.316f), Float.valueOf(-99.447f)};
    }
}

