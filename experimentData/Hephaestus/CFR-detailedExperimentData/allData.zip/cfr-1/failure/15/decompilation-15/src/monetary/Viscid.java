/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Boleros;
import src.monetary.Cardozo;
import src.monetary.Overawe;
import src.monetary.Pigtail;

abstract class Viscid<L, Y>
extends Boleros<Character, Integer> {
    public final Pigtail hoodie;

    public Viscid(Pigtail pigtail) {
        super(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo(-28, 17L), -88L)), Character.valueOf('z'));
        this.hoodie = pigtail;
    }

    @Override
    public short varicose(Character c, Integer n) {
        return 96;
    }

    public abstract Long gilded(Long var1);
}

