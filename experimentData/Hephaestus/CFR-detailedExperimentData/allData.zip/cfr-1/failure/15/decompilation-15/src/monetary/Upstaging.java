/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Clarifies;

interface Upstaging<A, Q>
extends Clarifies<Boolean> {
    public void thereof();
}

