/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Bounciest;
import src.monetary.Bullpen;
import src.monetary.Cardozo;
import src.monetary.Tinctures;

abstract class Chancel<J extends Integer, C extends J>
extends Bullpen<Double, Apertures> {
    public Bounciest bernoulli() {
        return ((Tinctures)null).blamed;
    }

    @Override
    public final Double axial() {
        Cardozo cardozo;
        Cardozo cardozo2 = cardozo = new Cardozo(86, -2L);
        return cardozo2.duration;
    }
}

