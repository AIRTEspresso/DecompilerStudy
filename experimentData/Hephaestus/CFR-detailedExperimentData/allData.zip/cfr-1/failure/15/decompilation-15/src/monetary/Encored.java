/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Bounciest;
import src.monetary.Chancel;
import src.monetary.Clarifies;
import src.monetary.Upstaging;

interface Encored
extends Upstaging<Float, Double> {
    public Object erosion(Chancel<Integer, ? extends Integer> var1, Float var2);

    public Bounciest alfonzo(Clarifies<Bounciest> var1);
}

