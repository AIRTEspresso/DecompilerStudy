/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Bounciest;
import src.monetary.Chancel;
import src.monetary.Main;
import src.monetary.Tinctures;

class Pigtail
extends Chancel<Integer, Integer> {
    public final Tinctures<? extends Character> passively(Chancel<? super Integer, Integer> chancel) {
        Tinctures tinctures = null;
        int n = 61;
        Main.aymara = (short)n;
        return tinctures;
    }

    @Override
    public Bounciest bernoulli() {
        return null;
    }
}

