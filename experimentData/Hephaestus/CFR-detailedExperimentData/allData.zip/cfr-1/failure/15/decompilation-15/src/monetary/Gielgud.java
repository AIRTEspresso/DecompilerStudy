/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Apertures;
import src.monetary.Blockades;
import src.monetary.Cardozo;
import src.monetary.Intrigued;
import src.monetary.Overawe;
import src.monetary.Tinctures;

abstract class Gielgud<U, H, Q extends H>
extends Tinctures<Q> {
    public final Blockades<U, ? extends U> driven;
    public Intrigued<Long> strife;

    public Gielgud(Blockades<U, ? extends U> blockades, Intrigued<Long> intrigued) {
        super(null, null);
        this.driven = blockades;
        this.strife = intrigued;
    }

    @Override
    public Q rummy() {
        Q q = null;
        this.strife = new Overawe(new Apertures(new Cardozo(3, 47L), 16L));
        return q;
    }

    public abstract Q ills(Q var1, H var2);
}

