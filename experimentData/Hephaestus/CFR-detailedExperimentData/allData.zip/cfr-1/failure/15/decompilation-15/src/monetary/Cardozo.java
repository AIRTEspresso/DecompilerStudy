/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.monetary;

import src.monetary.Rudyard;

final class Cardozo
extends Rudyard {
    public final short recruiter;
    public long juts;

    public Cardozo(short s, long l) {
        super(-48.653, new Long(-69L));
        this.recruiter = s;
        this.juts = l;
    }

    public final Long rearward() {
        long l;
        Long l2 = this.juts;
        this.juts = l = 71L;
        return l2;
    }
}

