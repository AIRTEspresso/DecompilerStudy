package src.monetary;

class Main {
  static Boolean retrace = true;

  static final Character fancied = '8';

  static final Character chiseling = ((Main.retrace) ?
  Main.fancied : 
    'n');

  static final String itchiest = new Rudyard(-44.993, (Number) new Long(93)).topmasts(Main.chiseling);

  static short aymara = (short)-66;

  static public final byte mellowest(long clarissa) {
    final byte obscures = (byte)-62;
    Apertures royal = ((Intrigued<Long>) null).loewe;
    Cardozo troikas = royal.whiz;
    Main.smugglers(Main.qualms(troikas));
    return obscures;
    
  }

  static public final void smugglers(Object janitor) {
    Double radar = 57.275;
    Main.nonwhites(radar);
    Object x_0 = (long)65;
    
  }

  static public final void nonwhites(Double dredged) {
    Double fascist = ((true) ?
      -39.49 : 
       -49.552);
    Object x_1 = fascist;
    
  }

  static public final Integer qualms(Rudyard definers) {
    return 17;
  }

  static public final Long continues(Long elnath, Long honda) {
    Intrigued<Long> exciting = new Boleros<Character, Integer>(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo((short)-49, (long)-82), (long)-20)),  '8').archibald.orchid();
    final Apertures cackling = exciting.loewe;
    Chancel<Integer, Integer> tiredness = (Chancel<Integer, Integer>) null;
    tiredness.bernoulli().incessant.tam(-81.882,   ((true) ?
  -31.225 : 
   93.439)).thereof();
    return cackling.acrobat;
    
  }

  static public final <F_F> F_F hepatitis(F_F barrett, F_F actives) {
    F_F outsider = actives;
    final F_F declaimed = (F_F) null;
    F_F respites = (F_F) null;
    Function0<Void> ointments = () -> {
      Function1<F_F, F_F> divines = (encrypt) -> {
        return (F_F) null;
      };
      Gielgud<F_F, F_F, F_F> atoll = (Gielgud<F_F, F_F, F_F>) null;
      final F_F incited = atoll.driven.ululated;
      divines.apply(incited);
      return null;
    };
    ointments.apply();
    return ((true) ?
      outsider : 
       Main.hepatitis(declaimed, respites));
    
  }

  static Number dirks = new Cardozo((short)-57, (long)60).juts;

  static public final void snapping() {
    final Viscid<Apertures, Character> envies = ((false) ?
      (Viscid<Apertures, Character>) null : 
       (Viscid<Apertures, Character>) null);
    Pigtail junks = envies.hoodie;
    final Tinctures<? extends Character> susan = junks.passively(null);
    Main.dirks = ((Circuit<Double>) null).cilia;
    Object x_2 = susan;
    
  }

  static public final void main(String[] args) {
    Object x_3 = (Float[]) new Object[]{(float)96.316, (float)-99.447};
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Rudyard {
  public final double duration;
  public final Number cilia;

  public Rudyard(double duration,Number cilia) {
    this.duration = duration;
    this.cilia = cilia;
  }

  public final String topmasts(Character descanted) {
    final String sodas = topmasts(descanted);
    return sodas;
    
  }
}

final class Cardozo extends Rudyard {
  public final short recruiter;
  public long juts;

  public Cardozo(short recruiter,long juts) {
    super(-48.653, (Number) new Long(-69));
    this.recruiter = recruiter;
    this.juts = juts;
  }

  public final Long rearward() {
    Long gael = juts;
    long capsized = (long)71;
    juts =   ((true) ?
  capsized : 
   (long)8);
    return gael;
    
  }
}

interface Clarifies<J> {}

final class Apertures extends Rudyard {
  public final Cardozo whiz;
  public Long acrobat;

  public Apertures(Cardozo whiz,Long acrobat) {
    super(-20.668, (Number) new Long(25));
    this.whiz = whiz;
    this.acrobat = acrobat;
  }

  public final short swigged() {
    return (short)66;
  }
}

abstract class Intrigued<O extends Long> extends Rudyard {
  public Apertures loewe;
  public Apertures aussies;

  public Intrigued(Apertures loewe,Apertures aussies) {
    super(-47.111, (Number) new Long(-32));
    this.loewe = loewe;
    this.aussies = aussies;
  }
}

final class Overawe<P, V, R extends Apertures> extends Intrigued<Long> {
  public Apertures loewe;

  public Overawe(Apertures loewe) {
    super(new Apertures(new Cardozo((short)38, (long)41), (long)-23), new Apertures(new Cardozo((short)33, (long)-16), (long)10));
    this.loewe = loewe;
  }

  public final Intrigued<Long> orchid() {
    Apertures shavian = loewe;
    Intrigued<Long> sundering = new Overawe<R, P, R>(shavian);
    Boolean scornful = false;
    Main.retrace = scornful;
    return sundering;
    
  }

  public final <F_M extends Apertures> F_M annoyed() {
    return (F_M) null;
  }
}

class Boleros<I extends Character, V extends Integer> implements Clarifies<V> {
  public final Overawe<Double, Byte, Apertures> archibald;
  public I assuaging;

  public Boleros(Overawe<Double, Byte, Apertures> archibald,I assuaging) {
    super();
    this.archibald = archibald;
    this.assuaging = assuaging;
  }

  public final I sell(short sidesteps, Object hazy) {
    final I levitate = (I) null;
    I narrowing = (I) null;
    assuaging = narrowing;
    return levitate;
    
  }

  public short varicose(I micron, V staking) {
    return (short)64;
  }
}

interface Upstaging<A, Q> extends Clarifies<Boolean> {
  public abstract void thereof() ;
}

abstract class Circuit<O extends Double> extends Rudyard {
  public Circuit() {
    super(1.232, (Number) new Long(-45));
}

  public <F_Q extends Double> Upstaging<Boolean, Long> tam(O grated, F_Q start) {
    Upstaging<Boolean, Long> filipino = (Upstaging<Boolean, Long>) null;
    final Character parboiled = '5';
    Main.aymara = new Boleros<Character, Integer>(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo((short)5, (long)61), (long)27)),  'x').varicose(parboiled, null);
    return filipino;
    
  }

  public O shriller(O peonies) {
    final Bovary<Rudyard, O> politer = new Bovary<Rudyard, O>((Bullpen<O, Apertures>) null, new Boleros<Character, Integer>(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo((short)-8, (long)-40), (long)41)),  's'));
    return politer.obsoleted.axial();
    
  }
}

abstract class Bullpen<A extends Double, V extends Apertures> implements Clarifies<V> {
  public A axial() {
    return (A) null;
  }
}

final class Bovary<C extends Rudyard, T extends Double> implements Clarifies<C> {
  public final Bullpen<T, ? super Apertures> obsoleted;
  public Boleros<? extends Character, Integer> profit;

  public Bovary(Bullpen<T, ? super Apertures> obsoleted,Boleros<? extends Character, Integer> profit) {
    super();
    this.obsoleted = obsoleted;
    this.profit = profit;
  }
}

abstract class Bounciest extends Boleros<Character, Integer> {
  public final Circuit<Double> incessant;
  public Character assuaging;

  public Bounciest(Circuit<Double> incessant,Character assuaging) {
    super(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo((short)35, (long)20), (long)-76)), 'm');
    this.incessant = incessant;
    this.assuaging = assuaging;
  }

  public final short varicose(Character micron, Integer staking) {
    return Main.aymara;
  }
}

abstract class Chancel<J extends Integer, C extends J> extends Bullpen<Double, Apertures> {
  public Chancel() {
    super();
}

  public Bounciest bernoulli() {
    return ((Tinctures<C>) null).blamed;
  }

  public final Double axial() {
    final long expiation = (long)-2;
    Cardozo local = new Cardozo((short)86, expiation);
    final Cardozo fender = local;
    return fender.duration;
    
  }
}

abstract class Tinctures<R> extends Bullpen<Double, Apertures> {
  public final Bounciest blamed;
  public R someones;

  public Tinctures(Bounciest blamed,R someones) {
    super();
    this.blamed = blamed;
    this.someones = someones;
  }

  public abstract R rummy() ;
}

class Blockades<R, E> extends Tinctures<E> {
  public R ululated;
  public final Bounciest blamed;

  public Blockades(R ululated,Bounciest blamed) {
    super((Bounciest) null, (E) null);
    this.ululated = ululated;
    this.blamed = blamed;
  }

  public E rummy() {
    final E sunblocks = (E) null;
    return sunblocks;
    
  }
}

abstract class Gielgud<U, H, Q extends H> extends Tinctures<Q> {
  public final Blockades<U, ? extends U> driven;
  public Intrigued<Long> strife;

  public Gielgud(Blockades<U, ? extends U> driven,Intrigued<Long> strife) {
    super((Bounciest) null, (Q) null);
    this.driven = driven;
    this.strife = strife;
  }

  public Q rummy() {
    final Q teeing = (Q) null;
    final short ismail = (short)3;
    final long fogeys = (long)47;
    strife = new Overawe<Rudyard, Integer, Apertures>(new Apertures(new Cardozo(ismail, fogeys), (long)16));
    return teeing;
    
  }

  public abstract Q ills(Q trimness, H interpret) ;
}

interface Encored extends Upstaging<Float, Double> {
  public abstract Object erosion(Chancel<Integer, ? extends Integer> aggie, Float dramatic) ;

  public abstract Bounciest alfonzo(Clarifies<Bounciest> piing) ;
}

final class Boom extends Boleros<Character, Integer> {
  public Character assuaging;
  public final Integer printable;

  public Boom(Character assuaging,Integer printable) {
    super(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo((short)-89, (long)60), (long)-45)), 'G');
    this.assuaging = assuaging;
    this.printable = printable;
  }

  public final short varicose(Character micron, Integer staking) {
    final Character contour = 'b';
    Main.snapping();
    return varicose(contour, staking);
    
  }
}

class Pigtail extends Chancel<Integer, Integer> {
  public Pigtail() {
    super();
}

  public final Tinctures<? extends Character> passively(Chancel<? super Integer, Integer> wretch) {
    final Tinctures<? extends Character> foremast = (Tinctures<Character>) null;
    short uranus = (short)61;
    Main.aymara = uranus;
    return foremast;
    
  }

  public Bounciest bernoulli() {
    return (Bounciest) null;
  }
}

abstract class Viscid<L, Y> extends Boleros<Character, Integer> {
  public final Pigtail hoodie;

  public Viscid(Pigtail hoodie) {
    super(new Overawe<Double, Byte, Apertures>(new Apertures(new Cardozo((short)-28, (long)17), (long)-88)), 'z');
    this.hoodie = hoodie;
  }

  public short varicose(Character micron, Integer staking) {
    return (short)96;
  }

  public abstract Long gilded(Long kilobyte) ;
}