/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Channeled;
import src.urology.Main;
import src.urology.Manuel;

class Torpedo<N extends Manuel, P>
implements Manuel {
    public Boolean bearable;
    public final Short bulkiest;

    public Torpedo(Boolean bl, Short s) {
        this.bearable = bl;
        this.bulkiest = s;
    }

    @Override
    public Boolean thermal(Boolean bl) {
        Boolean bl2 = false;
        return bl2;
    }

    @Override
    public void sprawled(Double d, float f) {
        Channeled channeled;
        Object var3_3 = null;
        Main.ladybug = channeled = (Channeled)null;
        Object var5_5 = var3_3;
    }
}

