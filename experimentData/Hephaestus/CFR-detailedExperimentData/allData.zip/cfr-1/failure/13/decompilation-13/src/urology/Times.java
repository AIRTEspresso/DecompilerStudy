/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Main;
import src.urology.Manuel;
import src.urology.Torpedo;

class Times
implements Manuel {
    Times() {
    }

    public final float abbasid(Double d, int n) {
        Main.anton();
        return 63.63f;
    }

    @Override
    public Boolean thermal(Boolean bl) {
        Torpedo torpedo = new Torpedo(false, (short)-17);
        Boolean bl2 = torpedo.bearable;
        return bl2;
    }

    @Override
    public void sprawled(Double d, float f) {
        Character c = Character.valueOf('A');
    }
}

