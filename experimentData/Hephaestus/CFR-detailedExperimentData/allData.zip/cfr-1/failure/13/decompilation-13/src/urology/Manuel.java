/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

interface Manuel {
    public void sprawled(Double var1, float var2);

    public Boolean thermal(Boolean var1);
}

