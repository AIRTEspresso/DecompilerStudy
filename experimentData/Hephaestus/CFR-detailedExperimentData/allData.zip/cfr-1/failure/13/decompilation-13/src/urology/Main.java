/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Calm;
import src.urology.Channeled;
import src.urology.Colognes;
import src.urology.Flatfoots;
import src.urology.Function0;
import src.urology.Manuel;
import src.urology.Recompile;
import src.urology.Spoor;
import src.urology.Temp;
import src.urology.Times;

class Main {
    static Long discus = -72L;
    static Channeled<Byte, Integer, Byte> ladybug = null;
    static Long hostilely;
    static final Long decompose;
    static long strumpets;
    static Double suffering;

    Main() {
    }

    public static final Number respected(Short s, Boolean bl) {
        Double d;
        Long l = discus;
        Function0<Double> function0 = () -> -58.479;
        Double d2 = d = function0.apply();
        ((Manuel)null).sprawled(d2, new Times().abbasid(((Spoor)null).flaxen, -56));
        return l;
    }

    public static final void anton() {
        Byte by = -35;
    }

    public static final char shields(Boolean bl, Number number) {
        Boolean bl2 = false;
        Short s = -77;
        char c = Main.shields(false, s);
        return bl2 != false ? c : c;
    }

    public static final int fezzes(int n) {
        Boolean bl = false;
        Recompile recompile = new Recompile(87);
        int n2 = (bl.booleanValue() ? recompile : recompile).alumnus;
        return n2;
    }

    public static final Integer linger(Integer n) {
        Boolean bl = true;
        Integer n2 = bl != false ? new Recompile<M>((int)-76).alumnus : n;
        return n2;
    }

    public static final void main(String[] stringArray) {
        Boolean bl = true;
        Calm calm = new Calm();
        Temp temp = new Temp(calm);
        Long l = bl != false ? new Flatfoots((Temp)temp, (Short)Short.valueOf((short)-29)).reforming.storing(null, new Object()) : discus.longValue();
    }

    static {
        decompose = hostilely = discus;
        strumpets = hostilely;
        suffering = ((Colognes)null).revisits();
    }
}

