/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Calm;
import src.urology.Dissolve;
import src.urology.Manuel;
import src.urology.Spoor;
import src.urology.Torpedo;

final class Temp
extends Spoor<Float> {
    public final Calm<? super Integer, Integer> scalpels;

    public Temp(Calm<? super Integer, Integer> calm) {
        super(-11.967);
        this.scalpels = calm;
    }

    public final long storing(Torpedo<Manuel, ? extends Long> torpedo, Object object) {
        long l = 49L;
        Character c = Character.valueOf('y');
        Dissolve dissolve = new Dissolve(c);
        dissolve.venue();
        return l;
    }
}

