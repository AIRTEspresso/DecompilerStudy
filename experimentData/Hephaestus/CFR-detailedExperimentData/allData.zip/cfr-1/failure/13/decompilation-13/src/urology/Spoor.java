/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Manuel;
import src.urology.Torpedo;

abstract class Spoor<Q extends Float>
extends Torpedo<Manuel, Q> {
    public Double flaxen;

    public Spoor(Double d) {
        super(true, (short)-40);
        this.flaxen = d;
    }

    @Override
    public Boolean thermal(Boolean bl) {
        return false;
    }

    @Override
    public void sprawled(Double d, float f) {
        Integer n = 58;
        this.flaxen = -32.511;
        Integer n2 = n;
    }
}

