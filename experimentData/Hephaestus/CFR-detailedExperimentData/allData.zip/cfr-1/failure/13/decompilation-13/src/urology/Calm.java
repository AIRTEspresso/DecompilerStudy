/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Times;

final class Calm<A, E extends A>
extends Times {
    @Override
    public final Boolean thermal(Boolean bl) {
        Boolean bl2 = false;
        Boolean bl3 = false;
        Boolean bl4 = bl2 != false ? bl3 : true;
        bl4 = true;
        return bl4;
    }

    @Override
    public final void sprawled(Double d, float f) {
        Object var3_3;
        Object var4_4 = var3_3 = null;
    }
}

