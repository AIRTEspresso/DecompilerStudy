/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Channeled;
import src.urology.Times;

abstract class Jiggled
extends Times {
    public final double trochees;

    public Jiggled(double d) {
        this.trochees = d;
    }

    public void effigies(Channeled<? super Byte, ? extends Byte, ? extends Byte> channeled, byte by) {
        Short s = -31;
    }
}

