/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Main;
import src.urology.Manuel;
import src.urology.Spoor;

abstract class Tensed<M extends Manuel>
extends Spoor<Float> {
    public Double flaxen;
    public final M exampling;

    public Tensed(Double d, M m) {
        super(-10.44);
        this.flaxen = d;
        this.exampling = m;
    }

    @Override
    public final void sprawled(Double d, float f) {
        Main.hostilely = -16L;
        Long l = new Long(-20L);
    }

    public abstract M stinted(M var1, M var2);
}

