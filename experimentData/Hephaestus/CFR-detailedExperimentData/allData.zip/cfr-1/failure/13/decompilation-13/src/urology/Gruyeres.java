/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Channeled;
import src.urology.Colognes;

final class Gruyeres<V extends Colognes, I, M>
extends Channeled<Byte, I, V> {
    public final Long setbacks;
    public final double spigots;

    public Gruyeres(Long l, double d) {
        super(-94L);
        this.setbacks = l;
        this.spigots = d;
    }

    @Override
    public Character kirinyaga() {
        Boolean bl = true;
        Character c = Character.valueOf('l');
        return Character.valueOf(bl != false ? (char)c.charValue() : (char)'A');
    }

    public final int olden(int n, M m) {
        M m2 = null;
        return this.olden(n, m2);
    }
}

