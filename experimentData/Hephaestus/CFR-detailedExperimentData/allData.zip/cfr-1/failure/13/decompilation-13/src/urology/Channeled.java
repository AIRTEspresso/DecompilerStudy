/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

abstract class Channeled<Y extends Byte, R, I> {
    public final Long setbacks;

    public Channeled(Long l) {
        this.setbacks = l;
    }

    public abstract Character kirinyaga();
}

