/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Spoor;
import src.urology.Sunlit;

class Dissolve<P, N extends P, T extends Spoor<? extends Float>>
extends Sunlit {
    public Character puts;

    public Dissolve(Character c) {
        super(Character.valueOf('8'));
        this.puts = c;
    }

    public void venue() {
        Long l = 40L;
    }

    @Override
    public Spoor<? extends Float> darryl(Spoor<? extends Float> spoor, Double d) {
        return spoor;
    }

    @Override
    public Boolean thermal(Boolean bl) {
        Boolean bl2 = true;
        return bl2;
    }
}

