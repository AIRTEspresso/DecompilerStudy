/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Sunlit;

abstract class Colognes
extends Sunlit {
    public Character puts;

    public Colognes(Character c) {
        super(Character.valueOf('K'));
        this.puts = c;
    }

    public Double revisits() {
        return 1.651;
    }
}

