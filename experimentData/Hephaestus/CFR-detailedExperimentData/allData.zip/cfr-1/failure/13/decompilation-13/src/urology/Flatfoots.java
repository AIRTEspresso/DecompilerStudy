/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Function0;
import src.urology.Jiggled;
import src.urology.Manuel;
import src.urology.Temp;

class Flatfoots
implements Manuel {
    public Temp reforming;
    public final Short bird;

    public Flatfoots(Temp temp, Short s) {
        this.reforming = temp;
        this.bird = s;
    }

    @Override
    public Boolean thermal(Boolean bl) {
        return true;
    }

    @Override
    public void sprawled(Double d, float f) {
        Function0<Void> function0 = () -> {
            Boolean bl;
            Boolean bl2 = bl = Boolean.valueOf(false);
            return null;
        };
        function0.apply();
        ((Jiggled)null).effigies(null, (byte)-5);
    }
}

