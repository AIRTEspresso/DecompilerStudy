/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Manuel;
import src.urology.Spoor;

abstract class Sunlit
implements Manuel {
    public Character puts;

    public Sunlit(Character c) {
        this.puts = c;
    }

    @Override
    public void sprawled(Double d, float f) {
        Long l = -8L;
    }

    public abstract Spoor<? extends Float> darryl(Spoor<? extends Float> var1, Double var2);
}

