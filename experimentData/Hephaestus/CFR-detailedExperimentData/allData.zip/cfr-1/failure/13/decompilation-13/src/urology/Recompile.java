/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.urology;

import src.urology.Channeled;
import src.urology.Sunlit;

class Recompile<M>
extends Channeled<Byte, M, M> {
    public final int alumnus;

    public Recompile(int n) {
        super(-72L);
        this.alumnus = n;
    }

    @Override
    public Character kirinyaga() {
        Sunlit sunlit = null;
        return sunlit.puts;
    }
}

