package src.urology;

class Main {
  static Long discus = (long)-72;

  static Channeled<Byte, Integer, Byte> ladybug = (Channeled<Byte, Integer, Byte>) null;

  static Long hostilely = ((true) ?
  Main.discus : 
   Main.ladybug.setbacks);

  static final Long decompose = Main.hostilely;

  static public final Number respected(Short alma, Boolean aortae) {
    final Number glottis = Main.discus;
    Function0<Double> glycerol = () -> {
      return -58.479;
    };
    Double gifts = glycerol.apply();
    final Double paddled = gifts;
    ((Manuel) null).sprawled(paddled, new Times().abbasid(((Spoor<Float>) null).flaxen,   ((false) ?
  -86 : 
   -56)));
    return glottis;
    
  }

  static public final void anton() {
    Object x_1 = (byte)-35;
    
  }

  static long strumpets = Main.hostilely;

  static public final char shields(Boolean befriends, Number enmesh) {
    Boolean cleaning = (false && false);
    Short chaotic = (short)-77;
    char swayed = Main.shields(false, chaotic);
    return ((cleaning) ?
      swayed : 
       swayed);
    
  }

  static public final int fezzes(int disguised) {
    final Boolean muslim = false;
    final Recompile<String> poohs = new Recompile<String>(87);
    final int sir = ((muslim) ?
  poohs : 
   poohs).alumnus;
    return sir;
    
  }

  static Double suffering = ((Colognes) null).revisits();

  static public final Integer linger(Integer axing) {
    Boolean nagy = ((byte)-67 > -95.727);
    final Integer bailout = ((nagy) ?
      new Recompile<Long>(-76).alumnus : 
       axing);
    return bailout;
    
  }

  static public final void main(String[] args) {
    Boolean crueler = true;
    Calm<? super Integer, Integer> closeout = new Calm<Integer, Integer>();
    final Temp saddened = new Temp(closeout);
    Object x_7 = (((crueler != false)) ?
      new Flatfoots(saddened, (short)-29).reforming.storing(null, new Object()) : 
       Main.discus);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Channeled<Y extends Byte, R, I> {
  public final Long setbacks;

  public Channeled(Long setbacks) {
    this.setbacks = setbacks;
  }

  public abstract Character kirinyaga() ;
}

interface Manuel {
  public abstract void sprawled(Double oath, float cheesing) ;

  public abstract Boolean thermal(Boolean embeds) ;
}

class Times implements Manuel {
  public final float abbasid(Double toms, int vidal) {
    final float decoys = (float)63.630;
    Main.anton();
    return decoys;
    
  }

  public Boolean thermal(Boolean embeds) {
    Torpedo<Manuel, Times> misused = new Torpedo<Manuel, Times>(false, (short)-17);
    Boolean elisha = misused.bearable;
    return elisha;
    
  }

  public void sprawled(Double oath, float cheesing) {
    final char ike = 'A';
    final char continua = ((false) ?
       's' : 
       ike);
    Object x_0 = continua;
    
  }
}

class Torpedo<N extends Manuel, P> implements Manuel {
  public Boolean bearable;
  public final Short bulkiest;

  public Torpedo(Boolean bearable,Short bulkiest) {
    super();
    this.bearable = bearable;
    this.bulkiest = bulkiest;
  }

  public Boolean thermal(Boolean embeds) {
    final Boolean children = false;
    return children;
    
  }

  public void sprawled(Double oath, float cheesing) {
    P crumbles = (P) null;
    final Channeled<Byte, Integer, Byte> shillong = (Channeled<Byte, Integer, Byte>) null;
    Main.ladybug = shillong;
    Object x_2 = crumbles;
    
  }
}

abstract class Spoor<Q extends Float> extends Torpedo<Manuel, Q> {
  public Double flaxen;

  public Spoor(Double flaxen) {
    super(true, (short)-40);
    this.flaxen = flaxen;
  }

  public Boolean thermal(Boolean embeds) {
    return false;
  }

  public void sprawled(Double oath, float cheesing) {
    Integer tuareg = 58;
    flaxen = -32.511;
    Object x_3 = tuareg;
    
  }
}

class Recompile<M> extends Channeled<Byte, M, M> {
  public final int alumnus;

  public Recompile(int alumnus) {
    super((long)-72);
    this.alumnus = alumnus;
  }

  public Character kirinyaga() {
    Sunlit racy = (Sunlit) null;
    return racy.puts;
    
  }
}

abstract class Sunlit implements Manuel {
  public Character puts;

  public Sunlit(Character puts) {
    super();
    this.puts = puts;
  }

  public void sprawled(Double oath, float cheesing) {
    final long goose = (long)-8;
    Object x_4 = goose;
    
  }

  public abstract Spoor<? extends Float> darryl(Spoor<? extends Float> knob, Double weevil) ;
}

abstract class Colognes extends Sunlit {
  public Character puts;

  public Colognes(Character puts) {
    super( 'K');
    this.puts = puts;
  }

  public Double revisits() {
    return 1.651;
  }
}

abstract class Tensed<M extends Manuel> extends Spoor<Float> {
  public Double flaxen;
  public final M exampling;

  public Tensed(Double flaxen,M exampling) {
    super(-10.440);
    this.flaxen = flaxen;
    this.exampling = exampling;
  }

  public final void sprawled(Double oath, float cheesing) {
    Main.hostilely = (long)-16;
    Object x_5 = (Number) new Long(-20);
    
  }

  public abstract M stinted(M mires, M detention) ;
}

final class Gruyeres<V extends Colognes, I, M> extends Channeled<Byte, I, V> {
  public final Long setbacks;
  public final double spigots;

  public Gruyeres(Long setbacks,double spigots) {
    super((long)-94);
    this.setbacks = setbacks;
    this.spigots = spigots;
  }

  public Character kirinyaga() {
    Boolean bohemians = true;
    final Character bullocks = 'l';
    Main.discus = Main.discus;
    return ((bohemians) ?
      bullocks : 
        'A');
    
  }

  public final int olden(int sandals, M wander) {
    final M feebler = (M) null;
    return olden(sandals, feebler);
    
  }
}

final class Calm<A, E extends A> extends Times {
  public Calm() {
    super();
}

  public final Boolean thermal(Boolean embeds) {
    Boolean expanding = false;
    Boolean mobilized = false;
    Boolean authors = ((expanding) ?
      mobilized : 
       true);
    authors = true;
    return authors;
    
  }

  public final void sprawled(Double oath, float cheesing) {
    final A tapering = (A) null;
    Object x_6 = tapering;
    
  }
}

final class Temp extends Spoor<Float> {
  public final Calm<? super Integer, Integer> scalpels;

  public Temp(Calm<? super Integer, Integer> scalpels) {
    super(-11.967);
    this.scalpels = scalpels;
  }

  public final long storing(Torpedo<Manuel, ? extends Long> penalizes, Object bundling) {
    long phantasm = (long)49;
    final Character guesser = 'y';
    Dissolve<Float, Float, Temp> anecdote = new Dissolve<Float, Float, Temp>(guesser);
    anecdote.venue();
    return phantasm;
    
  }
}

class Dissolve<P, N extends P, T extends Spoor<? extends Float>> extends Sunlit {
  public Character puts;

  public Dissolve(Character puts) {
    super( '8');
    this.puts = puts;
  }

  public void venue() {
    final long matron = (long)40;
    Object x_8 = matron;
    
  }

  public Spoor<? extends Float> darryl(Spoor<? extends Float> knob, Double weevil) {
    return knob;
  }

  public Boolean thermal(Boolean embeds) {
    Boolean educators = true;
    return educators;
    
  }
}

class Flatfoots implements Manuel {
  public Temp reforming;
  public final Short bird;

  public Flatfoots(Temp reforming,Short bird) {
    super();
    this.reforming = reforming;
    this.bird = bird;
  }

  public Boolean thermal(Boolean embeds) {
    return true;
  }

  public void sprawled(Double oath, float cheesing) {
    Function0<Void> nash = () -> {
      Boolean saturdays = false;
      Object x_9 = saturdays;
      return null;
    };
    nash.apply();
    ((Jiggled) null).effigies(null, (byte)-5);
    
  }
}

abstract class Jiggled extends Times {
  public final double trochees;

  public Jiggled(double trochees) {
    super();
    this.trochees = trochees;
  }

  public void effigies(Channeled<? super Byte, ? extends Byte, ? extends Byte> toiled, byte yessing) {
    Object x_10 = (short)-31;
    
  }
}