package src.tryout;

class Main {
  static int mallory = -53;

  static public final boolean paunch(Boolean licked) {
    final Grant coinages = (Grant) null;
    Boolean syringe = true;
    Grant liquid = (Grant) null;
    Main.autism(  ((true) ?
  (float)20.782 : 
   (float)-11.640), new Concepts<String, Object, Double>((float)-93.253, -62.231).bulling);
    return ((byte)99 < coinages.dawns(null,   ((syringe) ?
  liquid : 
   (Grant) null)).ludhiana);
    
  }

  static public final void autism(float arc, Float hymn) {
    Object x_0 = "skopje";
    
  }

  static public final Character washings() {
    Boolean engineer = false;
    final Boolean appeared = false;
    Boolean surer = (engineer == appeared);
    return ((surer) ?
      new Starless( 'k', null).rajahs : 
       Main.washings());
    
  }

  static Byte sir = (byte)-27;

  static final Byte clucked = Main.sir;

  static final Double swaps = ((Clack<Short, Acclaimed>) null).moped(Main.washings());

  static public final void main(String[] args) {
    final Boolean hypnotic = true;
    final Boolean thermal = false;
    final Boolean truncated = ((hypnotic) ?
      thermal : 
       false);
    Function2<Clack<? super Integer, ? super Acclaimed>, Float, Short> danes = (urns, keels) -> {
      return (short)-36;
    };
    Object x_1 = ((truncated) ?
      danes.apply(null, (float)23.595) : 
       danes.apply(null, (float)0.842));
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Acclaimed {
  public abstract <F_B, F_P> F_B harriet(F_B battery, F_P seaboard) ;

  public abstract Float recasts(Float weakest, short bluster) ;
}

interface Prawned extends Acclaimed {}

class Wive<W, L extends Byte, C> implements Prawned {
  public final Short ludhiana;

  public Wive(Short ludhiana) {
    super();
    this.ludhiana = ludhiana;
  }

  public <F_B, F_P> F_B harriet(F_B battery, F_P seaboard) {
    F_B profited = (F_B) null;
    return profited;
    
  }

  public Float recasts(Float weakest, short bluster) {
    Float outgrows = (float)50.709;
    outgrows = (float)84.2;
    return outgrows;
    
  }
}

abstract class Grant implements Acclaimed {
  public abstract Wive<Integer, Byte, Double> dawns(Double[] discuss, Grant redoes) ;
}

class Concepts<L extends Object, N, X> extends Grant {
  public final Float bulling;
  public final X osage;

  public Concepts(Float bulling,X osage) {
    super();
    this.bulling = bulling;
    this.osage = osage;
  }

  public Wive<Integer, Byte, Double> dawns(Double[] discuss, Grant redoes) {
    Wive<Integer, Byte, Double> hold = new Wive<Integer, Byte, Double>((short)-98);
    return hold;
    
  }

  public Float recasts(Float weakest, short bluster) {
    Float rain = (float)21.464;
    return rain;
    
  }

  public <F_B, F_P> F_B harriet(F_B battery, F_P seaboard) {
    F_B cremates = (F_B) null;
    F_B limb = cremates;
    return limb;
    
  }
}

final class Starless extends Wive<Boolean, Byte, Integer> {
  public Character rajahs;
  public Starless tarantino;

  public Starless(Character rajahs,Starless tarantino) {
    super((short)68);
    this.rajahs = rajahs;
    this.tarantino = tarantino;
  }

  public final Float recasts(Float weakest, short bluster) {
    final Float faculty = (float)-84.336;
    return faculty;
    
  }

  public final Boolean penguins(Number slue, Double... dies) {
    Boolean also = true;
    return also;
    
  }
}

abstract class Clack<T, S> extends Wive<Byte, Byte, Character> {
  public T placated;
  public final Starless severance;

  public Clack(T placated,Starless severance) {
    super((short)96);
    this.placated = placated;
    this.severance = severance;
  }

  public Double moped(Object figurine) {
    return -33.636;
  }
}