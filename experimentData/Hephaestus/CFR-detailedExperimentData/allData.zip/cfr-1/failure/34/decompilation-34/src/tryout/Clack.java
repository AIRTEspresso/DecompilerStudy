/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Starless;
import src.tryout.Wive;

abstract class Clack<T, S>
extends Wive<Byte, Byte, Character> {
    public T placated;
    public final Starless severance;

    public Clack(T t, Starless starless) {
        super((short)96);
        this.placated = t;
        this.severance = starless;
    }

    public Double moped(Object object) {
        return -33.636;
    }
}

