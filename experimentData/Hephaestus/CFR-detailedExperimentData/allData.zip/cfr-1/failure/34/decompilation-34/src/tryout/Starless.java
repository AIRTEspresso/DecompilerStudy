/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Wive;

final class Starless
extends Wive<Boolean, Byte, Integer> {
    public Character rajahs;
    public Starless tarantino;

    public Starless(Character c, Starless starless) {
        super((short)68);
        this.rajahs = c;
        this.tarantino = starless;
    }

    @Override
    public final Float recasts(Float f, short s) {
        Float f2 = Float.valueOf(-84.336f);
        return f2;
    }

    public final Boolean penguins(Number number, Double ... doubleArray) {
        Boolean bl = true;
        return bl;
    }
}

