/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Grant;
import src.tryout.Wive;

class Concepts<L, N, X>
extends Grant {
    public final Float bulling;
    public final X osage;

    public Concepts(Float f, X x) {
        this.bulling = f;
        this.osage = x;
    }

    @Override
    public Wive<Integer, Byte, Double> dawns(Double[] doubleArray, Grant grant) {
        Wive<Integer, Byte, Double> wive = new Wive<Integer, Byte, Double>((short)-98);
        return wive;
    }

    @Override
    public Float recasts(Float f, short s) {
        Float f2 = Float.valueOf(21.464f);
        return f2;
    }

    @Override
    public <F_B, F_P> F_B harriet(F_B F_B, F_P F_P) {
        F_B F_B2;
        F_B F_B3 = F_B2 = null;
        return F_B3;
    }
}

