/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

interface Acclaimed {
    public <F_B, F_P> F_B harriet(F_B var1, F_P var2);

    public Float recasts(Float var1, short var2);
}

