/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Prawned;

class Wive<W, L extends Byte, C>
implements Prawned {
    public final Short ludhiana;

    public Wive(Short s) {
        this.ludhiana = s;
    }

    @Override
    public <F_B, F_P> F_B harriet(F_B F_B, F_P F_P) {
        F_B F_B2 = null;
        return F_B2;
    }

    @Override
    public Float recasts(Float f, short s) {
        Float f2 = Float.valueOf(50.709f);
        f2 = Float.valueOf(84.2f);
        return f2;
    }
}

