/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Acclaimed;

interface Prawned
extends Acclaimed {
}

