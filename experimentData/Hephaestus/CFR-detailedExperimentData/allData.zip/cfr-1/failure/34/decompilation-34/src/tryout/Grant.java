/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Acclaimed;
import src.tryout.Wive;

abstract class Grant
implements Acclaimed {
    Grant() {
    }

    public abstract Wive<Integer, Byte, Double> dawns(Double[] var1, Grant var2);
}

