/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tryout;

import src.tryout.Clack;
import src.tryout.Concepts;
import src.tryout.Function2;
import src.tryout.Grant;
import src.tryout.Starless;

class Main {
    static int mallory = -53;
    static Byte sir;
    static final Byte clucked;
    static final Double swaps;

    Main() {
    }

    public static final boolean paunch(Boolean bl) {
        Grant grant = null;
        Boolean bl2 = true;
        Grant grant2 = null;
        Main.autism(20.782f, new Concepts<L, N, Double>((Float)Float.valueOf((float)-93.253f), Double.valueOf((double)-62.231)).bulling);
        return 99 < grant.dawns(null, (Grant)(bl2.booleanValue() ? grant2 : (Grant)null)).ludhiana;
    }

    public static final void autism(float f, Float f2) {
        String string = "skopje";
    }

    public static final Character washings() {
        Boolean bl;
        Boolean bl2 = false;
        Boolean bl3 = bl2 == (bl = Boolean.valueOf(false));
        return bl3 != false ? new Starless((Character)Character.valueOf((char)'k'), null).rajahs : Main.washings();
    }

    public static final void main(String[] stringArray) {
        Boolean bl = true;
        Boolean bl2 = false;
        Boolean bl3 = bl != false ? bl2 : false;
        Function2<Clack, Float, Short> function2 = (clack, f) -> (short)-36;
        Short s = bl3 != false ? function2.apply(null, Float.valueOf(23.595f)) : function2.apply(null, Float.valueOf(0.842f));
    }

    static {
        clucked = sir = Byte.valueOf((byte)-27);
        swaps = ((Clack)null).moped(Main.washings());
    }
}

