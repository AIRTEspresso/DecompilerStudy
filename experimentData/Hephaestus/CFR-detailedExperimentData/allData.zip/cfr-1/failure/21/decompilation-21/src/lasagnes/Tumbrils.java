/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Mohacs;

abstract class Tumbrils<U extends Long>
extends Mohacs<Double> {
    public double nits;

    public Tumbrils(double d) {
        this.nits = d;
    }

    @Override
    public String huh(Short s, Double d) {
        double d2;
        Boolean bl = false;
        String string = bl != false ? "frostier" : "civility";
        this.nits = d2 = this.nits;
        return string;
    }
}

