/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

abstract class Marin {
    public Boolean underbid;

    public Marin(Boolean bl) {
        this.underbid = bl;
    }

    public abstract <F_O> Double cleaned(F_O var1);
}

