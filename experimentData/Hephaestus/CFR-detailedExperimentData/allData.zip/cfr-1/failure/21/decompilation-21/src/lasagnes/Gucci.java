/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Lags;
import src.lasagnes.Main;
import src.lasagnes.Villainy;

final class Gucci<A extends Double, C extends Boolean, R extends Float>
extends Villainy<Character, Character, Character> {
    public final Character overdraws;

    public Gucci(Character c) {
        super(Character.valueOf('M'));
        this.overdraws = c;
    }

    public final A fryers(A a) {
        Boolean bl;
        Double d = null;
        Main.susan = bl = Boolean.valueOf(true);
        return (A)d;
    }

    @Override
    public void zucchinis() {
        Boolean bl;
        Boolean bl2 = bl = (Boolean)null;
        new Lags(-28, 14).reproved(null, -70L);
        Boolean bl3 = bl2;
    }
}

