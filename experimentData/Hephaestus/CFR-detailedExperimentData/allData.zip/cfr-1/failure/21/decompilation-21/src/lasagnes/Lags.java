/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Brooded;
import src.lasagnes.Gucci;
import src.lasagnes.Mohacs;

final class Lags
extends Brooded {
    public final int attracted;
    public final short disobey;

    public Lags(int n, short s) {
        super((short)87);
        this.attracted = n;
        this.disobey = s;
    }

    public final void reproved(Mohacs<Double> mohacs, Long l) {
        Gucci gucci;
        Character c = Character.valueOf('9');
        Gucci gucci2 = gucci = new Gucci(c);
    }
}

