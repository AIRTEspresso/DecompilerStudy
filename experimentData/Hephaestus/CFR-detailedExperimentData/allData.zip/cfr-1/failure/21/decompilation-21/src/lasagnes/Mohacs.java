/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Avionics;
import src.lasagnes.Brooded;
import src.lasagnes.Collaring;
import src.lasagnes.Function0;
import src.lasagnes.Function1;
import src.lasagnes.Sweltered;
import src.lasagnes.Villainy;

class Mohacs<R extends Double>
implements Avionics {
    Mohacs() {
    }

    public String huh(Short s, R r) {
        Brooded brooded = null;
        Short s2 = brooded.libidos;
        String string = this.huh(s2, null);
        Function1<Double, Void> function1 = d -> {
            Function0<Double> function0 = () -> {
                Object d = null;
                ((Villainy)null).zucchinis();
                return d;
            };
            Double d2 = function0.apply();
            Brooded brooded = null;
            Double d3 = d2;
            brooded.underbid = d3 == (Double)null;
            Double d4 = d2;
            return null;
        };
        function1.apply(((Sweltered)null).grimness(null, null).feedback((byte)79, new Collaring(Character.valueOf('w'))).fryers(null));
        return string;
    }

    public final R ponytail(R r, R r2) {
        return (R)((Double)null);
    }
}

