/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Avionics;
import src.lasagnes.Sweltered;

final class Hum
implements Avionics {
    public final Sweltered<? super Double> slat;

    public Hum(Sweltered<? super Double> sweltered) {
        this.slat = sweltered;
    }
}

