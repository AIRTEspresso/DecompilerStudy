/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Marin;

abstract class Brooded
extends Marin {
    public Short libidos;

    public Brooded(Short s) {
        super(true);
        this.libidos = s;
    }

    @Override
    public <F_O> Double cleaned(F_O F_O) {
        Double d = 21.688;
        return d;
    }

    public float workweeks() {
        return -16.456f;
    }
}

