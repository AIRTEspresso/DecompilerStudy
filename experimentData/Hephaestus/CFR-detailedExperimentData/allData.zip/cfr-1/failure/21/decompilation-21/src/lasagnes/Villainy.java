/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Avionics;

abstract class Villainy<F extends Character, Z extends F, G extends Z>
implements Avionics {
    public final G overdraws;

    public Villainy(G g) {
        this.overdraws = g;
    }

    public abstract void zucchinis();
}

