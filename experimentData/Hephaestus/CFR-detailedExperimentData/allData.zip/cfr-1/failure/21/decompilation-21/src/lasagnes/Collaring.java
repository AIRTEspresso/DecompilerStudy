/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Avionics;
import src.lasagnes.Gucci;
import src.lasagnes.Villainy;

class Collaring<W, I extends Short, O extends Double>
extends Villainy<Character, Character, Character> {
    public final Character overdraws;

    public Collaring(Character c) {
        super(Character.valueOf('c'));
        this.overdraws = c;
    }

    public Gucci<O, Boolean, Float> feedback(Number number, Avionics avionics) {
        Gucci gucci = new Gucci(Character.valueOf('P'));
        return gucci;
    }

    @Override
    public void zucchinis() {
        Double d;
        Double d2 = d = (Double)null;
    }
}

