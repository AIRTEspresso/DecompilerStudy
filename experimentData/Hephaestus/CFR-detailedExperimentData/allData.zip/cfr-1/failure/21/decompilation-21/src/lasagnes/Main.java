/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Function2;
import src.lasagnes.Gucci;
import src.lasagnes.Hum;
import src.lasagnes.Marin;
import src.lasagnes.Mohacs;
import src.lasagnes.Sweltered;
import src.lasagnes.Tumbrils;
import src.lasagnes.Villainy;

class Main {
    static Boolean susan;
    static Boolean iterator;
    static final Boolean gwendolyn;
    static char demeaning;
    static String eurydice;
    static final Tumbrils<? super Long> tenth;
    static Boolean nobility;
    static Gucci<? extends Double, ? extends Boolean, ? extends Float> lusting;

    Main() {
    }

    public static final Short afresh() {
        return (short)71;
    }

    public static final double soundings(double d) {
        double d2 = ((Tumbrils)null).nits;
        return d2;
    }

    public static final void main(String[] stringArray) {
        Sweltered<? super Double> sweltered = new Hum((Sweltered<? super Double>)((Sweltered)null)).slat;
        Function2<Villainy, Short, Sweltered> function2 = (villainy, s) -> null;
        Short s2 = Main.afresh();
        Sweltered sweltered2 = function2.apply(null, s2);
        Boolean bl = sweltered == sweltered2;
    }

    static {
        iterator = susan = ((Marin)null).underbid;
        gwendolyn = true;
        demeaning = (char)(iterator.booleanValue() ? (gwendolyn.booleanValue() ? 111 : 110) : 56);
        eurydice = new Mohacs<Double>().huh(Main.afresh(), -38.1);
        tenth = null;
        nobility = false;
        lusting = new Gucci(Character.valueOf('1')) != new Gucci(Character.valueOf('Q')) ? new Gucci(Character.valueOf('F')) : new Gucci(Character.valueOf('Q'));
    }
}

