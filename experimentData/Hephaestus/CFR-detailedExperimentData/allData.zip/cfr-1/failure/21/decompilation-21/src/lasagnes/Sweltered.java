/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.lasagnes;

import src.lasagnes.Avionics;
import src.lasagnes.Collaring;
import src.lasagnes.Mohacs;

interface Sweltered<Y extends Double>
extends Avionics {
    public Collaring<Y, Short, Y> grimness(Y var1, Mohacs<? extends Double> var2);
}

