/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Aventine;
import src.charmed.Banished;
import src.charmed.Heifer;
import src.charmed.Mcdowell;

final class Shredders<F, Z extends F>
extends Banished<Short> {
    public final F xenon;
    public F murmurs;

    public Shredders(F f, F f2) {
        super(Float.valueOf(-43.536f));
        this.xenon = f;
        this.murmurs = f2;
    }

    public final Mcdowell<Integer, Integer> sad() {
        Boolean bl = true;
        Integer n = -81;
        return bl != false ? new Mcdowell<Integer, Integer>("link", n) : new Mcdowell("falsehood", -51);
    }

    public final Aventine<? extends Float, ? super Double> funeral(Aventine<? extends Float, ? super Double> aventine, Z z) {
        Heifer heifer = new Heifer();
        return heifer;
    }
}

