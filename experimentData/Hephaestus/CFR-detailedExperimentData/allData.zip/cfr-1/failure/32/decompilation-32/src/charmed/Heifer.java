/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Banished;

final class Heifer
extends Banished<Short> {
    public Heifer() {
        super(Float.valueOf(9.125f));
    }

    public final Double tillable(long l, Integer n) {
        Boolean bl = false;
        Double d = bl != false ? -22.999 : -27.264;
        return d;
    }
}

