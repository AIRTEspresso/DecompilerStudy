/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Aventine;

interface Convey<J, R>
extends Aventine<Float, Double> {
    public R typhoons();
}

