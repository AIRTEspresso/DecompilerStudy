/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Aventine;

class Banished<T extends Short>
implements Aventine<Float, Double> {
    public final Float soupiest;

    public Banished(Float f) {
        this.soupiest = f;
    }

    public final short plateau(short s) {
        return -41;
    }
}

