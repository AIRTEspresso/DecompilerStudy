/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Banished;
import src.charmed.Bluejays;
import src.charmed.Function1;
import src.charmed.Shredders;

class Main {
    static final short paramount = -83;
    static final Float enclave = Float.valueOf(-8.216f);
    static final Float safflower = new Banished<T>((Float)Main.enclave).soupiest;
    static Boolean bitchier = true;
    static final short lasagne = (short)-15;
    static String slewed = "sell";
    static final Long lied = 21L;

    Main() {
    }

    public static final <F_O extends Double> F_O yolks() {
        return (F_O)((Double)null);
    }

    public static final Float shamans(short s, Byte by) {
        Float f = Float.valueOf(-60.338f);
        f = Float.valueOf(22.12f);
        return f;
    }

    public static final void whirs() {
        Banished banished;
        Float f = Float.valueOf(59.242f);
        Banished banished2 = banished = new Banished(f);
    }

    public static final void main(String[] stringArray) {
        Bluejays bluejays = null;
        Double d = 27.302;
        Shredders shredders = new Shredders(-23.867, d);
        Function1<Float, Shredders> function1 = f -> {
            Shredders shredders;
            Shredders shredders2 = shredders = new Shredders(44.686, 32.991);
            Main.whirs();
            return shredders2;
        };
        (bluejays.rebus((byte)41) != false ? new Shredders(81.154, -99.883) : function1.apply(Float.valueOf(78.677f))).sad().plateau((short)-95);
    }
}

