/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Convey;

interface Bluejays
extends Convey<Long, Boolean> {
    public Boolean rebus(Byte var1);
}

