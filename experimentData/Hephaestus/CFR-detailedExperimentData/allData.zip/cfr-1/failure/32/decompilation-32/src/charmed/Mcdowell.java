/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.charmed;

import src.charmed.Banished;

final class Mcdowell<X, P extends X>
extends Banished<Short> {
    public String tasselled;
    public P whiners;

    public Mcdowell(String string, P p) {
        super(Float.valueOf(47.704f));
        this.tasselled = string;
        this.whiners = p;
    }
}

