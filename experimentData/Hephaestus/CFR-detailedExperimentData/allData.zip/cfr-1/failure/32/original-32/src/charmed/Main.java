package src.charmed;

class Main {
  static public final <F_O extends Double> F_O yolks() {
    return (F_O) null;
  }

  static public final Float shamans(short avis, Byte diastolic) {
    Float mischief = (float)-60.338;
    mischief = (float)22.120;
    return mischief;
    
  }

  static final short paramount = (short)-83;

  static final Float enclave = (float)-8.216;

  static final Float safflower = (((false && false)) ?
  Main.shamans(Main.paramount, (byte)-5) : 
   new Banished<Short>(Main.enclave).soupiest);

  static Boolean bitchier = true;

  static final short lasagne = ((false) ?
  ((Main.bitchier) ?
    (short)3 : 
     (short)-2) : 
   (short)-15);

  static String slewed = (((false || false)) ?
  new Mcdowell<Short, Short>("reaming", (short)25).tasselled : 
   "sell");

  static final Long lied = (long)21;

  static public final void whirs() {
    final Float grackles = (float)59.242;
    Banished<Short> thaws = new Banished<Short>(grackles);
    Object x_0 = thaws;
    
  }

  static public final void main(String[] args) {
    final Bluejays leeriest = (Bluejays) null;
    final Double wedge = 27.302;
    Shredders<Double, Double> sidewalls = new Shredders<Double, Double>(-23.867, wedge);
    Function1<Float, Shredders<Double, Double>> conduce = (jute) -> {
      final Shredders<Double, Double> minutiae = new Shredders<Double, Double>(44.686, 32.991);
      final Shredders<Double, Double> lab = minutiae;
      Main.whirs();
      return lab;
      
    };
      ((leeriest.rebus((byte)41)) ?
  ((false) ?
    sidewalls : 
     new Shredders<Double, Double>(81.154, -99.883)) : 
   conduce.apply((float)78.677)).sad().plateau((short)-95);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Aventine<H extends Float, E extends Double> {}

class Banished<T extends Short> implements Aventine<Float, Double> {
  public final Float soupiest;

  public Banished(Float soupiest) {
    super();
    this.soupiest = soupiest;
  }

  public final short plateau(short witnesses) {
    return (short)-41;
  }
}

final class Mcdowell<X, P extends X> extends Banished<Short> {
  public String tasselled;
  public P whiners;

  public Mcdowell(String tasselled,P whiners) {
    super((float)47.704);
    this.tasselled = tasselled;
    this.whiners = whiners;
  }
}

interface Convey<J, R> extends Aventine<Float, Double> {
  public abstract R typhoons() ;
}

final class Heifer extends Banished<Short> {
  public Heifer() {
    super((float)9.125);
}

  public final Double tillable(long wobbled, Integer wises) {
    Boolean piaget = false;
    Double hidebound = ((piaget) ?
      -22.999 : 
       -27.264);
    return hidebound;
    
  }
}

final class Shredders<F, Z extends F> extends Banished<Short> {
  public final F xenon;
  public F murmurs;

  public Shredders(F xenon,F murmurs) {
    super((float)-43.536);
    this.xenon = xenon;
    this.murmurs = murmurs;
  }

  public final Mcdowell<Integer, Integer> sad() {
    final Boolean glass = true;
    Integer boxes = -81;
    final String acquiring = "falsehood";
    return ((glass) ?
      new Mcdowell<Integer, Integer>("link", boxes) : 
       new Mcdowell<Integer, Integer>(acquiring, -51));
    
  }

  public final Aventine<? extends Float, ? super Double> funeral(Aventine<? extends Float, ? super Double> hurler, Z abelard) {
    final Aventine<? extends Float, ? super Double> insect = new Heifer();
    return insect;
    
  }
}

interface Bluejays extends Convey<Long, Boolean> {
  public abstract Boolean rebus(Byte nautical) ;
}