/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.manured;

import src.manured.Floozie;

abstract class Ahead<F extends Double, I>
extends Floozie<Double, Boolean> {
    public Float meuse;
    public final Boolean slashing;

    public Ahead(Float f, Boolean bl) {
        super(false);
        this.meuse = f;
        this.slashing = bl;
    }

    @Override
    public final Double latino(short s, Double d) {
        Double d2 = 17.265;
        return d2;
    }
}

