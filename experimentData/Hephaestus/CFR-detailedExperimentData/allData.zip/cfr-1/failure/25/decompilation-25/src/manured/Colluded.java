/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.manured;

interface Colluded<Q> {
    public Q latino(short var1, Q var2);
}

