/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.manured;

import src.manured.Ahead;
import src.manured.Colluded;
import src.manured.Edna;

abstract class Downbeats
implements Colluded<Float> {
    public final int rue;
    public byte insulator;

    public Downbeats(int n, byte by) {
        this.rue = n;
        this.insulator = by;
    }

    @Override
    public Float latino(short s, Float f) {
        Ahead<Double, Number> ahead = ((Edna)null).chorus;
        return ahead.meuse;
    }
}

