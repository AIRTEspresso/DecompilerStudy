/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.manured;

import src.manured.Floozie;

class Main {
    static Character protein = Character.valueOf('o');
    static final Character poppycock;
    static Boolean musty;
    static Boolean crush;
    static final Double toboggans;
    static final Long tongued;

    Main() {
    }

    public static final Double thongs(Integer n, long l) {
        return 25.844;
    }

    public static final void main(String[] stringArray) {
        Integer n;
        Integer n2 = n = Integer.valueOf(19);
    }

    static {
        musty = protein != (poppycock = Character.valueOf('6'));
        crush = new Floozie<T, Q>((Boolean)Main.musty).slashing != false;
        toboggans = 74.598;
        tongued = 49L;
    }
}

