/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.manured;

import src.manured.Ahead;
import src.manured.Floozie;

abstract class Edna<D, X extends D, Q>
extends Floozie<Boolean, Integer> {
    public Ahead<Double, Number> chorus;
    public final Boolean slashing;

    public Edna(Ahead<Double, Number> ahead, Boolean bl) {
        super(false);
        this.chorus = ahead;
        this.slashing = bl;
    }

    public abstract X potholes(X var1);

    public abstract short plate(Q var1);
}

