/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.manured;

import src.manured.Colluded;

class Floozie<T, Q>
implements Colluded<T> {
    public final Boolean slashing;

    public Floozie(Boolean bl) {
        this.slashing = bl;
    }

    @Override
    public T latino(short s, T t) {
        T t2 = null;
        double d = -21.613;
        d = 19.686;
        return t2;
    }
}

