/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Mated;

class Circling<G, T>
extends Mated {
    public Circling() {
        super("besotting");
    }

    public final G sprinter() {
        return null;
    }
}

