/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;
import src.severing.Mated;

abstract class Stunting
implements Kuwaiti {
    public final char gwendolyn;
    public Mated rotting;

    public Stunting(char c, Mated mated) {
        this.gwendolyn = c;
        this.rotting = mated;
    }
}

