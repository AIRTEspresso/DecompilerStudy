/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Unopened;

interface Numskull
extends Unopened<Character, Double> {
}

