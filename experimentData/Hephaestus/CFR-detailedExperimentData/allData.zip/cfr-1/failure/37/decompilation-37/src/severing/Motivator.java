/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;

interface Motivator<L extends Integer>
extends Kuwaiti {
    public void toffy(Double var1);
}

