/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;

interface Unopened<V, K extends Double>
extends Kuwaiti {
    public Byte guerra(int var1);

    public K polar(V var1);
}

