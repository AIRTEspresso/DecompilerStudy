/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;

interface Ignacio<R extends String, U, E>
extends Kuwaiti {
    public R casuistry(float var1, R var2);
}

