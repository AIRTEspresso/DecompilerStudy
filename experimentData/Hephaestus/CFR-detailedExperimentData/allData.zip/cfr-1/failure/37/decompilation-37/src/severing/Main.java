/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Circling;
import src.severing.Gesturing;
import src.severing.Gutters;
import src.severing.Housetops;
import src.severing.Numskull;
import src.severing.Plectrums;
import src.severing.Swerve;
import src.severing.Weddell;

class Main {
    static final Boolean mordred = true;
    static Boolean grandson = true;
    static final Integer commodity = -6;
    static Integer damien = mordred == false || grandson != false ? -52 : commodity;
    static final int shamans = new Weddell<Z, Double, Y>((int)-85, Double.valueOf((double)18.514)).fetching;
    static Object mealy = (byte)49;

    Main() {
    }

    public static final Weddell<Float, ? super Float, ? super Byte> communes() {
        Weddell weddell = new Weddell(-14, Float.valueOf(79.68f));
        return weddell;
    }

    public static final Housetops flexed(short s, Boolean bl) {
        Housetops housetops = null;
        return housetops;
    }

    public static final Numskull enduring(Gutters gutters) {
        Gutters gutters2 = gutters;
        Boolean bl = true;
        new Plectrums(null, 24).gary("ezekiel", (bl.booleanValue() ? new Circling<G, T>() : new Circling<G, T>()).bandages);
        return new Swerve<E, X, N>((Gutters)gutters2).ramp;
    }

    public static final void main(String[] stringArray) {
        Housetops housetops = null;
        Gesturing gesturing = new Gesturing(91L);
        long l = gesturing.crooking;
        housetops.hoods(l);
    }
}

