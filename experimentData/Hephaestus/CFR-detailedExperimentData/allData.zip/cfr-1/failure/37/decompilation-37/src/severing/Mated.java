/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Function1;
import src.severing.Function2;
import src.severing.Gutters;
import src.severing.Main;
import src.severing.Motivator;
import src.severing.Numskull;
import src.severing.Ridges;
import src.severing.Sicken;
import src.severing.Stunting;
import src.severing.Unopened;

class Mated
implements Unopened<Double, Double> {
    public String bandages;

    public Mated(String string) {
        this.bandages = string;
    }

    @Override
    public Double polar(Double d) {
        return d;
    }

    @Override
    public Byte guerra(int n2) {
        Ridges ridges;
        Function1<Integer, Ridges> function1 = n -> new Ridges((byte)71, null);
        Ridges ridges2 = ridges = function1.apply(65);
        Function2<Float, Numskull, Void> function2 = (f, numskull) -> {
            Stunting stunting;
            Stunting stunting2 = stunting = (Stunting)null;
            Long[] longArray = ((Gutters)null).wine(stunting2.gwendolyn);
            ((Motivator)null).toffy(-90.14);
            Long[] longArray2 = longArray;
            return null;
        };
        function2.apply(Float.valueOf(((Sicken)null).pensions), Main.flexed((short)-66, (Boolean)Boolean.valueOf((boolean)true)).ensigns);
        return ridges2.daley;
    }
}

