/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Circling;
import src.severing.Housetops;
import src.severing.Motivator;
import src.severing.Weddell;

class Gesturing<X extends Motivator<? extends Integer>, D extends X, N>
extends Circling<X, D> {
    public long crooking;

    public Gesturing(long l) {
        this.crooking = l;
    }

    public X parisian(Housetops housetops, Weddell<? super X, ? extends N, ? extends Byte> weddell) {
        Motivator motivator = null;
        return (X)motivator;
    }

    public final X derby(X x) {
        Motivator motivator = null;
        return (X)motivator;
    }
}

