/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Circling;
import src.severing.Gutters;
import src.severing.Ridges;

class Plunge<F>
extends Gutters {
    public Circling<F, F> topmasts;
    public final Ridges unpinned;

    public Plunge(Circling<F, F> circling, Ridges ridges) {
        super(new Ridges((byte)-81, null));
        this.topmasts = circling;
        this.unpinned = ridges;
    }

    @Override
    public Byte guerra(int n) {
        return (byte)-4;
    }

    @Override
    public Double polar(Character c) {
        return -69.964;
    }
}

