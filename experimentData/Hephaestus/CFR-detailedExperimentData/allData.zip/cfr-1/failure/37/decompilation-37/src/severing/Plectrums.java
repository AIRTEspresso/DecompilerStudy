/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Circling;
import src.severing.Gutters;
import src.severing.Housetops;
import src.severing.Ignacio;
import src.severing.Main;
import src.severing.Plunge;
import src.severing.Ridges;
import src.severing.Swerve;

class Plectrums<W extends String, R extends W>
extends Swerve<Housetops, W, W> {
    public final Gutters ramp;
    public Integer rallied;

    public Plectrums(Gutters gutters, Integer n) {
        super(new Plunge(new Circling(), new Ridges((byte)-64, null)));
        this.ramp = gutters;
        this.rallied = n;
    }

    public void gary(String string, R r) {
        this.rallied = Main.shamans;
        Character c = Character.valueOf('u');
    }

    @Override
    public final void toffy(Double d) {
        Ignacio ignacio = null;
        String string = null;
        string = null;
        ignacio.casuistry(-91.924f, string);
    }
}

