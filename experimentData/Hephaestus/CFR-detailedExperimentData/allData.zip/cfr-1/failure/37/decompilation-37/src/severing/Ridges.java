/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;

final class Ridges
implements Kuwaiti {
    public final Byte daley;
    public Kuwaiti prickled;

    public Ridges(Byte by, Kuwaiti kuwaiti) {
        this.daley = by;
        this.prickled = kuwaiti;
    }

    public final Boolean ambled(Double d, Character c) {
        Boolean bl = false;
        return bl;
    }
}

