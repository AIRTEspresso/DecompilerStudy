/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;

final class Weddell<Z, X, Y extends Byte>
implements Kuwaiti {
    public int fetching;
    public final X fine;

    public Weddell(int n, X x) {
        this.fetching = n;
        this.fine = x;
    }
}

