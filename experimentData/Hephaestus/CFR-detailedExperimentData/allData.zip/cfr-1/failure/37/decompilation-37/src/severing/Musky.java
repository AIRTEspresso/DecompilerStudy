/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Kuwaiti;
import src.severing.Ridges;
import src.severing.Unopened;

abstract class Musky<A extends Character, O extends A, Y>
implements Unopened<Y, Double> {
    Musky() {
    }

    @Override
    public Byte guerra(int n) {
        return new Ridges((Byte)Byte.valueOf((byte)47), (Kuwaiti)((Kuwaiti)null)).daley;
    }

    public abstract A oxidize(short var1, A var2);
}

