/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Mated;
import src.severing.Stunting;
import src.severing.Unopened;

abstract class Sicken<P extends Stunting>
implements Unopened<Mated, Double> {
    public final float pensions;
    public P hindemith;

    public Sicken(float f, P p) {
        this.pensions = f;
        this.hindemith = p;
    }

    @Override
    public Double polar(Mated mated) {
        return -52.513;
    }

    @Override
    public Byte guerra(int n) {
        Byte by = 2;
        return by;
    }
}

