/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Numskull;

abstract class Housetops
implements Numskull {
    public Numskull ensigns;

    public Housetops(Numskull numskull) {
        this.ensigns = numskull;
    }

    public abstract short whacked();

    public long hoods(long l) {
        long l2 = 65L;
        return l2;
    }
}

