/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Circling;
import src.severing.Gutters;
import src.severing.Housetops;
import src.severing.Kuwaiti;
import src.severing.Main;
import src.severing.Motivator;
import src.severing.Musky;
import src.severing.Plunge;
import src.severing.Ridges;

class Swerve<E extends Housetops, X, N>
implements Motivator<Integer> {
    public final Gutters ramp;

    public Swerve(Gutters gutters) {
        this.ramp = gutters;
    }

    @Override
    public void toffy(Double d) {
        Musky musky;
        Boolean bl = true;
        Musky musky2 = musky = (Musky)null;
        Main.mealy = new Object();
        Musky musky3 = bl != false ? musky : musky2;
    }

    public final X lolita() {
        Circling circling = new Circling();
        Byte by = -21;
        Kuwaiti kuwaiti = null;
        Main.grandson = false;
        return (X)new Plunge<G>(circling, (Ridges)new Ridges((Byte)by, (Kuwaiti)kuwaiti)).topmasts.sprinter();
    }
}

