/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.severing;

import src.severing.Numskull;
import src.severing.Ridges;

abstract class Gutters
implements Numskull {
    public final Ridges unpinned;

    public Gutters(Ridges ridges) {
        this.unpinned = ridges;
    }

    public Long[] wine(char c) {
        Long l = -9L;
        Long l2 = 60L;
        Long[] longArray = (Long[])new Object[]{-84L, l, l2};
        return longArray;
    }
}

