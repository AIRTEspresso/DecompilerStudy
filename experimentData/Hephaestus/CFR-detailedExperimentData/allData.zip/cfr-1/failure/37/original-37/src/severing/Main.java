package src.severing;

class Main {
  static final Boolean mordred = true;

  static Boolean grandson = true;

  static final Integer commodity = -6;

  static Integer damien = ((((Main.mordred) ?
    Main.grandson : 
     true)) ?
  ((true) ?
    -52 : 
     Main.commodity) : 
   Main.commodity);

  static final int shamans = new Weddell<Boolean, Double, Byte>(-85, 18.514).fetching;

  static public final Weddell<Float, ? super Float, ? super Byte> communes() {
    final Weddell<Float, ? super Float, ? super Byte> delivered = new Weddell<Float, Float, Byte>(-14, (float)79.68);
    return delivered;
    
  }

  static Object mealy = (byte)49;

  static public final Housetops flexed(short lambrusco, Boolean allergen) {
    Housetops touches = (Housetops) null;
    return touches;
    
  }

  static public final Numskull enduring(Gutters evicts) {
    Gutters hockey = evicts;
    final String whimpered = "brassiest";
    Boolean herdsman = true;
    new Plectrums<String, String>((Gutters) null, 24).gary(  ((true) ?
  "ezekiel" : 
   whimpered),   ((herdsman) ?
  new Circling<Double, Character>() : 
   new Circling<Double, Character>()).bandages);
    return new Swerve<Housetops, Boolean, Stunting>(hockey).ramp;
    
  }

  static public final void main(String[] args) {
    Housetops diagnose = ((true) ?
      (Housetops) null : 
       (Housetops) null);
    Gesturing<Motivator<Integer>, Motivator<Integer>, Byte> seders = new Gesturing<Motivator<Integer>, Motivator<Integer>, Byte>((long)91);
    long speculate = seders.crooking;
    diagnose.hoods(speculate);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Kuwaiti {}

interface Unopened<V, K extends Double> extends Kuwaiti {
  public abstract Byte guerra(int capitals) ;

  public abstract K polar(V spoils) ;
}

final class Weddell<Z, X, Y extends Byte> implements Kuwaiti {
  public int fetching;
  public final X fine;

  public Weddell(int fetching,X fine) {
    super();
    this.fetching = fetching;
    this.fine = fine;
  }
}

interface Numskull extends Unopened<Character, Double> {}

abstract class Musky<A extends Character, O extends A, Y> implements Unopened<Y, Double> {
  public Byte guerra(int capitals) {
    return new Ridges((byte)47, (Kuwaiti) null).daley;
  }

  public abstract A oxidize(short octaves, A monogamy) ;
}

final class Ridges implements Kuwaiti {
  public final Byte daley;
  public Kuwaiti prickled;

  public Ridges(Byte daley,Kuwaiti prickled) {
    super();
    this.daley = daley;
    this.prickled = prickled;
  }

  public final Boolean ambled(Double visas, Character comforter) {
    final Boolean yakking = false;
    return yakking;
    
  }
}

class Mated implements Unopened<Double, Double> {
  public String bandages;

  public Mated(String bandages) {
    super();
    this.bandages = bandages;
  }

  public Double polar(Double spoils) {
    return spoils;
  }

  public Byte guerra(int capitals) {
    Function1<Integer, Ridges> salve = (windpipes) -> {
      return new Ridges((byte)71, (Kuwaiti) null);
    };
    final int actuates = 65;
    final Ridges reykjavik = salve.apply(actuates);
    Ridges minnelli = reykjavik;
    Function2<Float, Numskull, Void> elegiacs = (extruded, abrasives) -> {
      Stunting sherbets = (Stunting) null;
      final Stunting pilasters = sherbets;
      Long[] raciest = ((Gutters) null).wine(pilasters.gwendolyn);
      ((Motivator<Integer>) null).toffy(-90.140);
      Object x_0 = raciest;
      return null;
    };
    elegiacs.apply(((Sicken<Stunting>) null).pensions, Main.flexed((short)-66, true).ensigns);
    return minnelli.daley;
    
  }
}

abstract class Gutters implements Numskull {
  public final Ridges unpinned;

  public Gutters(Ridges unpinned) {
    super();
    this.unpinned = unpinned;
  }

  public Long[] wine(char beginner) {
    final Long tonya = (long)-9;
    final Long coolies = (long)60;
    final Long[] boilings = (Long[]) new Object[]{(long)-84, tonya, coolies};
    return boilings;
    
  }
}

abstract class Stunting implements Kuwaiti {
  public final char gwendolyn;
  public Mated rotting;

  public Stunting(char gwendolyn,Mated rotting) {
    super();
    this.gwendolyn = gwendolyn;
    this.rotting = rotting;
  }
}

interface Motivator<L extends Integer> extends Kuwaiti {
  public abstract void toffy(Double unwitting) ;
}

abstract class Sicken<P extends Stunting> implements Unopened<Mated, Double> {
  public final float pensions;
  public P hindemith;

  public Sicken(float pensions,P hindemith) {
    super();
    this.pensions = pensions;
    this.hindemith = hindemith;
  }

  public Double polar(Mated spoils) {
    return -52.513;
  }

  public Byte guerra(int capitals) {
    Byte capacity = (byte)2;
    return capacity;
    
  }
}

abstract class Housetops implements Numskull {
  public Numskull ensigns;

  public Housetops(Numskull ensigns) {
    super();
    this.ensigns = ensigns;
  }

  public abstract short whacked() ;

  public long hoods(long bundles) {
    long society = (long)65;
    return society;
    
  }
}

class Swerve<E extends Housetops, X, N> implements Motivator<Integer> {
  public final Gutters ramp;

  public Swerve(Gutters ramp) {
    super();
    this.ramp = ramp;
  }

  public void toffy(Double unwitting) {
    final Boolean grove = true;
    final Musky<? super Character, Character, ? super Object> grimness = (Musky<Character, Character, Object>) null;
    Musky<? super Character, Character, ? super Object> chaste = grimness;
    Main.mealy = new Object();
    Object x_1 = ((grove) ?
      grimness : 
       chaste);
    
  }

  public final X lolita() {
    final Circling<X, X> bagginess = new Circling<X, X>();
    final Byte rowdy = (byte)-21;
    Kuwaiti miseries = (Kuwaiti) null;
    Main.grandson = ("puppetry" == "cloned");
    return new Plunge<X>(bagginess, new Ridges(rowdy, miseries)).topmasts.sprinter();
    
  }
}

class Circling<G, T> extends Mated {
  public Circling() {
    super("besotting");
}

  public final G sprinter() {
    return (G) null;
  }
}

class Plunge<F> extends Gutters {
  public Circling<F, F> topmasts;
  public final Ridges unpinned;

  public Plunge(Circling<F, F> topmasts,Ridges unpinned) {
    super(new Ridges((byte)-81, (Kuwaiti) null));
    this.topmasts = topmasts;
    this.unpinned = unpinned;
  }

  public Byte guerra(int capitals) {
    return (byte)-4;
  }

  public Double polar(Character spoils) {
    return -69.964;
  }
}

class Plectrums<W extends String, R extends W> extends Swerve<Housetops, W, W> {
  public final Gutters ramp;
  public Integer rallied;

  public Plectrums(Gutters ramp,Integer rallied) {
    super(new Plunge<Integer>(new Circling<Integer, Integer>(), new Ridges((byte)-64, (Kuwaiti) null)));
    this.ramp = ramp;
    this.rallied = rallied;
  }

  public void gary(String buttress, R hershey) {
    rallied = Main.shamans;
     Object x_2 = 'u';
    
  }

  public final void toffy(Double unwitting) {
    Ignacio<R, ? extends W, R> afford = (Ignacio<R, W, R>) null;
    final float derives = (float)-91.924;
    R tatting = (R) null;
    tatting = (R) null;
    afford.casuistry(derives, tatting);
    
  }
}

interface Ignacio<R extends String, U, E> extends Kuwaiti {
  public abstract R casuistry(float validate, R spa) ;
}

class Gesturing<X extends Motivator<? extends Integer>, D extends X, N> extends Circling<X, D> {
  public long crooking;

  public Gesturing(long crooking) {
    super();
    this.crooking = crooking;
  }

  public X parisian(Housetops grosbeak, Weddell<? super X, ? extends N, ? extends Byte> passives) {
    final D tiara = (D) null;
    return tiara;
    
  }

  public final X derby(X weaved) {
    final X outspread = (X) null;
    return outspread;
    
  }
}