/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.spoke;

import src.spoke.Slime;

final class Punic<P extends Long> {
    Punic() {
    }

    public final boolean sacred(P p, boolean bl) {
        Long l = null;
        P p2 = p;
        Long l2 = -20L;
        return this.sacred(l, this.sacred(new Slime<Long, I>(p2, (Long)null).tip, (float)l2.longValue() > 35.322f));
    }

    public final Integer instagram() {
        Integer n = 52;
        return n;
    }
}

