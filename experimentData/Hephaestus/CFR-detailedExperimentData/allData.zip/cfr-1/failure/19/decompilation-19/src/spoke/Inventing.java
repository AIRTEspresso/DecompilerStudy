/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.spoke;

import src.spoke.Staking;

interface Inventing<X, U extends Double, K>
extends Staking<Character> {
    public X finessing();

    public Object yankee();
}

