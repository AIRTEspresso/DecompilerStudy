/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.spoke;

final class Slime<Z extends Long, I extends Z> {
    public Z tip;
    public final Z smile;

    public Slime(Z z, Z z2) {
        this.tip = z;
        this.smile = z2;
    }
}

