/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.spoke;

import src.spoke.Slime;

class Main {
    static Integer antigens = -89;

    Main() {
    }

    public static final Slime<Long, Long> reindeer(Slime<Long, Long> slime) {
        Boolean bl = true;
        Long l = 24L;
        Slime<Long, Long> slime2 = new Slime<Long, Long>(56L, bl != false ? l : 56L);
        return slime2;
    }

    public static final Float gimmickry(Float f, Double d) {
        return f;
    }

    public static final void main(String[] stringArray) {
        Integer n;
        Integer n2 = n = antigens;
    }
}

