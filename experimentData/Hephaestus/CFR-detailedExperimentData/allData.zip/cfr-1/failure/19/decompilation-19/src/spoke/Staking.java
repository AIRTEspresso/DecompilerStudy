/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.spoke;

import src.spoke.Punic;

interface Staking<C extends Character> {
    public C zooming(Short var1, Punic<? super Long> var2);
}

