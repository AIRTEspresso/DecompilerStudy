package src.leans;

class Main {
  static public final void zaniness(Bigmouths<String> levine, Long belinda) {
    Boolean examiner = false;
    final Float solstices = (float)39.345;
    final Float hangouts = (float)20.902;
    new Appetite<Flutes, Byte>(new Flutes(), false).affection.anchovies(((Wingnut<Flutes, Rabbi<Flutes, Flutes, Flutes>>) null).lesotho, null);
    Object x_2 = ((examiner) ?
      solstices : 
       hangouts);
    
  }

  static public final void pomades(String frobisher, Haiti<Short, Flutes> advents) {
    final Haiti<? super Short, ? super Float> thriftier = (Haiti<Short, Float>) null;
    Object x_6 = thriftier;
    
  }

  static public final void sackcloth() {
    final Boolean flowers = false;
    final Clovis gwendolyn = (Clovis) null;
    Long stupors = (long)-89;
    gwendolyn.toil = stupors;
    Object x_7 = flowers;
    
  }

  static final Flutes roams = new Flutes();

  static final Flutes despairs = new Flutes();

  static final Flutes font = ((false) ?
  Main.roams : 
   Main.despairs);

  static Byte wattling = Main.font.flatboats;

  static Double macerated = ((false) ?
  new Grimly((Bigmouths<String>) null, true) : 
   new Grimly((Bigmouths<String>) null, true)).lesotho;

  static public final Flutes uvular(Character gerald, Short espousal) {
    return new Flutes();
  }

  static final Pretties<? extends Grimly, ? extends Double> bongoes = new Pretties<Grimly, Double>(false);

  static public final void inventory() {
    Object x_10 = Main.macerated;
    
  }

  static public final Apex<Boolean> rural() {
    Apex<Boolean> groveling = (Apex<Boolean>) null;
    return ((false) ?
      (Apex<Boolean>) null : 
       groveling);
    
  }

  static final Haiti<? super Short, Short> fleshy = new Vilnius<Byte, Byte>(Main.rural()).distil.pedigrees();

  static public final void main(String[] args) {
    Function2<Double, Appetite<Flutes, Byte>, Integer> mackinaw = (perming, lampreys) -> {
      final int chongqing = 62;
      final int hinduism = ((false) ?
        10 : 
         chongqing);
      final Buntings coriander = (Buntings) null;
      Function1<Short, Leagues<Object, Number, Double>> abilene = (countries) -> {
        return new Juggling<Buntings>((Leagues<Object, Number, Double>) null).prattled;
      };
      coriander.lineups((false == Main.fleshy.wooziest), abilene.apply((short)-56).grasping(((Ewe) null).sheds((Buntings) null)));
      return hinduism;
      
    };
    final Demeanor cogs = new Demeanor((Buntings) null);
    Buntings devilment = cogs.hollow;
    Double renal = devilment.lesotho;
    Function2<Excise<? super Character>, Short, Nucleic<Byte, Long, Byte>> huston = (welshman, encamp) -> {
      Nucleic<Byte, Long, Byte> gavin = new Nucleic<Byte, Long, Byte>((Bigmouths<String>) null, (byte)-42);
      final Long piaget = (long)80;
      Long electric = piaget;
      new Clovis((long)34).toil = electric;
      return ((true) ?
        gavin : 
         gavin);
      
    };
    mackinaw.apply(renal, huston.apply(null, (short)-17));
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Haiti<W extends Short, C> {
  public final Boolean wooziest;
  public final Haiti<Short, ? extends Boolean> dissolved;

  public Haiti(Boolean wooziest,Haiti<Short, ? extends Boolean> dissolved) {
    this.wooziest = wooziest;
    this.dissolved = dissolved;
  }

  public Double nocturnes(Double chessmen) {
    Boolean eglantine = true;
    final Double bravery = 38.902;
    final Double leases = -69.208;
    eglantine = wooziest;
    return ((eglantine) ?
      bravery : 
       leases);
    
  }

  public abstract C kennelled(W pilings, C drippings) ;
}

final class Lackeys<N> extends Haiti<Short, N> {
  public Lackeys() {
    super(true, (Haiti<Short, Boolean>) null);
}

  public N kennelled(Short pilings, N drippings) {
    Function0<Excise<N>> stamping = () -> {
      Rabbi<Float, Double, N> pended = (Rabbi<Float, Double, N>) null;
      Number amassing = (Number) new Long(-63);
      Excise<N> celia = new Excise<N>(pended, amassing);
      return celia;
      
    };
    final Excise<N> lyons = stamping.apply();
    final Rabbi<Float, Double, N> grippe = lyons.nonvoting;
    Bigmouths<N> workmen = grippe.scantiest();
    Function0<Void> unlacing = () -> {
      final N hogwarts = ((Bigmouths<N>) null).flatboats;
      final Boolean behalf = (hogwarts == hogwarts);
      Function0<Void> shogun = () -> {
        Boolean ronald = false;
        final N siam = (N) null;
        N valvoline = ((ronald) ?
          siam : 
           hogwarts);
        N roping = (N) null;
        roping = (N) null;
        Object x_0 = valvoline;
        return null;
      };
      shogun.apply();
      Object x_1 = behalf;
      return null;
    };
    unlacing.apply();
    return workmen.flatboats;
    
  }

  public final Double nocturnes(Double chessmen) {
    Double gauging = nocturnes(-52.305);
    Grimly firewall = new Grimly((Bigmouths<String>) null, false);
    final Long yawing = (long)-20;
    Main.zaniness(firewall.plangent, new Clovis(yawing).toil);
    return gauging;
    
  }
}

abstract class Bigmouths<Z> extends Haiti<Short, Double> {
  public final Z flatboats;
  public final Boolean wooziest;
  public final Haiti<Short, ? extends Boolean> dissolved;

  public Bigmouths(Z flatboats,Boolean wooziest,Haiti<Short, ? extends Boolean> dissolved) {
    super(true, (Haiti<Short, Boolean>) null);
    this.flatboats = flatboats;
    this.wooziest = wooziest;
    this.dissolved = dissolved;
  }

  public final Double nocturnes(Double chessmen) {
    final Double syringe = -51.300;
    Z quiver = (Z) null;
    Z abscissae = quiver;
    abscissae = (Z) null;
    return syringe;
    
  }

  public Double kennelled(Short pilings, Double drippings) {
    Double silicosis = -13.539;
    return silicosis;
    
  }
}

interface Rabbi<Z, S, Y> {
  public abstract Bigmouths<Y> scantiest() ;
}

final class Excise<X> implements Rabbi<X, X, X> {
  public final Rabbi<Float, Double, X> nonvoting;
  public final Number eatery;

  public Excise(Rabbi<Float, Double, X> nonvoting,Number eatery) {
    super();
    this.nonvoting = nonvoting;
    this.eatery = eatery;
  }

  public Bigmouths<X> scantiest() {
    return (Bigmouths<X>) null;
  }
}

final class Flutes extends Bigmouths<Byte> {
  public Flutes() {
    super((byte)-13, true, (Haiti<Short, Boolean>) null);
}

  public final void anchovies(double nagpur, Lackeys<? extends Number> thomson) {
    Integer clerics = -82;
    final Integer uppermost = -66;
    clerics = uppermost;
    Object x_3 = 80;
    
  }

  public final Double kennelled(Short pilings, Double drippings) {
    final Double tromp = 54.347;
    return tromp;
    
  }
}

class Appetite<V extends Flutes, K extends Byte> extends Haiti<Short, V> {
  public final Flutes affection;
  public final Boolean wooziest;

  public Appetite(Flutes affection,Boolean wooziest) {
    super(true, (Haiti<Short, Boolean>) null);
    this.affection = affection;
    this.wooziest = wooziest;
  }

  public V kennelled(Short pilings, V drippings) {
    V niggas = (V) null;
    V thieves = (V) null;
    V messages = thieves;
    niggas = messages;
    return niggas;
    
  }

  public final Double nocturnes(Double chessmen) {
    return -84.138;
  }
}

abstract class Wingnut<X, S extends Rabbi<X, X, X>> extends Appetite<Flutes, Byte> {
  public final double lesotho;
  public final Boolean wooziest;

  public Wingnut(double lesotho,Boolean wooziest) {
    super(new Flutes(), false);
    this.lesotho = lesotho;
    this.wooziest = wooziest;
  }

  public final Flutes kennelled(Short pilings, Flutes drippings) {
    return drippings;
  }

  public Bigmouths<S> anacin() {
    Bigmouths<S> gangrene = (Bigmouths<S>) null;
    return gangrene;
    
  }
}

class Grimly extends Wingnut<Boolean, Rabbi<Boolean, Boolean, Boolean>> {
  public final Bigmouths<String> plangent;
  public final Boolean wooziest;

  public Grimly(Bigmouths<String> plangent,Boolean wooziest) {
    super(30.312, false);
    this.plangent = plangent;
    this.wooziest = wooziest;
  }

  public final Flutes scummy(float singly, Appetite<? extends Flutes, ? extends Byte> incised) {
    final Flutes satyrs = new Flutes();
    Function0<Void> perelman = () -> {
      Object x_4 = 56.22;
      return null;
    };
    perelman.apply();
    return satyrs;
    
  }

  public final Long[] shipped() {
    Long gaborone = (Long) null;
    final Long lavishes = (Long) null;
    Long clarissa = lavishes;
    gaborone = (long)-59;
    return (Long[]) new Object[]{(Long) null, gaborone, clarissa};
    
  }
}

final class Clovis implements Rabbi<Byte, Boolean, Byte> {
  public Long toil;

  public Clovis(Long toil) {
    super();
    this.toil = toil;
  }

  public Bigmouths<Byte> scantiest() {
    final Bigmouths<Byte> mona = new Flutes();
    final Bigmouths<Byte> penguins = mona;
    final String byelaw = "clipped";
    Main.pomades(byelaw, new Grimly((Bigmouths<String>) null, true));
    return penguins;
    
  }

  public final Double woofer() {
    final Double nonrigid = -63.695;
    Function1<Lackeys<Character>, Void> abbess = (leeds) -> {
      Character reddish = 'o';
      Main.sackcloth();
      Object x_5 = reddish;
      return null;
    };
    final Lackeys<Character> baptism = (Lackeys<Character>) null;
    abbess.apply(baptism);
    return nonrigid;
    
  }
}

interface Poppycock<U extends Character, T extends Float> extends Rabbi<Character, Double, Character> {}

class Mexico<N, M, C extends Object> implements Rabbi<Clovis, String, Character> {
  public Bigmouths<Character> scantiest() {
    final Bigmouths<Character> young = scantiest();
    return young;
    
  }

  public final N parakeets(Double smithson, N plumed) {
    Boolean leanness = true;
    final Bigmouths<String> filipinos = (Bigmouths<String>) null;
    Nucleic<N, ? super M, N> staling = new Nucleic<N, M, N>(filipinos, (N) null);
    Function0<Long> munches = () -> {
      return (long)-61;
    };
    new Pretties<Grimly, Double>(  ((false) ?
  true : 
   true)).coffee(new Clovis(munches.apply()));
      return ((leanness) ?
  new Dutiful<N, M, Boolean>(staling) : 
   new Dutiful<N, M, Boolean>(new Nucleic<N, M, N>((Bigmouths<String>) null, (N) null))).corrupts.entranced(null,   ((false) ?
  (N) null : 
   (N) null));
    
  }
}

final class Nucleic<C, P, B extends C> extends Grimly {
  public final Bigmouths<String> plangent;
  public final B limpet;

  public Nucleic(Bigmouths<String> plangent,B limpet) {
    super((Bigmouths<String>) null, false);
    this.plangent = plangent;
    this.limpet = limpet;
  }

  public final C entranced(Wingnut<? super Byte, ? super Rabbi<Byte, Byte, Byte>> sopwith, B crackdown) {
    C agree = (C) null;
    return agree;
    
  }
}

final class Dutiful<W, D, T extends Boolean> implements Rabbi<D, T, D> {
  public final Nucleic<W, ? super D, W> corrupts;

  public Dutiful(Nucleic<W, ? super D, W> corrupts) {
    super();
    this.corrupts = corrupts;
  }

  public Bigmouths<D> scantiest() {
    return (Bigmouths<D>) null;
  }

  public final <F_F extends Character> Double barrelled(Double anemone, F_F adhere) {
    final Double torques = -22.39;
    final Boolean outfitted = true;
    Roach<Long, D, D> apogees = new Roach<Long, D, D>(outfitted);
    apogees.armadas((short)78, (D) null);
    return torques;
    
  }
}

class Roach<B extends Long, S, V> extends Appetite<Flutes, Byte> {
  public final Boolean wooziest;

  public Roach(Boolean wooziest) {
    super(new Flutes(), false);
    this.wooziest = wooziest;
  }

  public final void armadas(short campy, S booting) {
    Object x_8 = (Rabbi<B, V, V>) null;
    
  }

  public final Flutes kennelled(Short pilings, Flutes drippings) {
    return new Flutes();
  }
}

final class Pretties<T extends Grimly, M extends Double> extends Appetite<Flutes, Byte> {
  public final Boolean wooziest;

  public Pretties(Boolean wooziest) {
    super(new Flutes(), false);
    this.wooziest = wooziest;
  }

  public final void coffee(Clovis wagnerian) {
    final byte cavour = Main.wattling;
    wagnerian.toil = (long)94;
    Object x_9 = cavour;
    
  }
}

final class Tizzy implements Rabbi<Object, Boolean, Tizzy> {
  public Long banded;
  public final Pretties<? super Grimly, ? super Double> doubts;

  public Tizzy(Long banded,Pretties<? super Grimly, ? super Double> doubts) {
    super();
    this.banded = banded;
    this.doubts = doubts;
  }

  public Bigmouths<Tizzy> scantiest() {
    return (Bigmouths<Tizzy>) null;
  }

  public final Poppycock<? super Character, Float> golan(Float whippet, Poppycock<? super Character, Float> francoise) {
    return (Poppycock<Character, Float>) null;
  }
}

abstract class Apex<Z> extends Grimly {
  public final Bigmouths<String> plangent;

  public Apex(Bigmouths<String> plangent) {
    super((Bigmouths<String>) null, false);
    this.plangent = plangent;
  }

  public Haiti<? super Short, Short> pedigrees() {
    final Haiti<? super Short, Short> chandler = (Haiti<Short, Short>) null;
    Main.inventory();
    return chandler;
    
  }
}

final class Vilnius<W, G extends W> implements Rabbi<Integer, Boolean, Double> {
  public final Apex<Boolean> distil;

  public Vilnius(Apex<Boolean> distil) {
    super();
    this.distil = distil;
  }

  public Bigmouths<Double> scantiest() {
    return (Bigmouths<Double>) null;
  }
}

abstract class Buntings extends Apex<Number> {
  public final Pretties<? super Buntings, Double> critics;
  public final short woody;

  public Buntings(Pretties<? super Buntings, Double> critics,short woody) {
    super((Bigmouths<String>) null);
    this.critics = critics;
    this.woody = woody;
  }

  public abstract void lineups(boolean iso, Long chillies) ;

  public final Haiti<? super Short, Short> pedigrees() {
    final Haiti<? super Short, Short> century = Main.fleshy;
    return century;
    
  }
}

interface Leagues<I, E, B> extends Rabbi<I, E, B> {
  public abstract Long grasping(Pretties<Buntings, Double> dreyfus) ;
}

final class Juggling<G> extends Bigmouths<Boolean> {
  public Leagues<Object, Number, Double> prattled;

  public Juggling(Leagues<Object, Number, Double> prattled) {
    super(false, true, (Haiti<Short, Boolean>) null);
    this.prattled = prattled;
  }

  public final Double kennelled(Short pilings, Double drippings) {
    return -23.783;
  }
}

interface Ewe extends Rabbi<Float, Float, Boolean> {
  public abstract Pretties<Buntings, Double> sheds(Buntings silenced) ;
}

class Demeanor extends Mexico<Character, Flutes, Number> {
  public final Buntings hollow;

  public Demeanor(Buntings hollow) {
    super();
    this.hollow = hollow;
  }

  public Bigmouths<Character> scantiest() {
    Bigmouths<Character> sciatica = (Bigmouths<Character>) null;
    Bigmouths<Character> dowdily = sciatica;
    final Clients largos = new Clients("pokiest");
    largos.deflects(false, new Object());
    return dowdily;
    
  }

  public Float trout(char parsi, Float wronger) {
    Float berthing = (float)87.101;
    ((Crumbles<Grimly>) null).overdress(null);
    return berthing;
    
  }
}

class Clients extends Wingnut<Double, Rabbi<Double, Double, Double>> {
  public String etcher;

  public Clients(String etcher) {
    super(-45.787, true);
    this.etcher = etcher;
  }

  public final void deflects(Boolean urns, Object northrop) {
    final Appetite<? super Flutes, Byte> nonwhites = Main.bongoes;
    Object x_11 = nonwhites;
    
  }

  public Poppycock<? super Character, ? extends Float> freakiest(Float diffusely, Double highboy) {
    return (Poppycock<Character, Float>) null;
  }
}

interface Crumbles<U> extends Poppycock<Character, Float> {
  public abstract void overdress(Ewe[] rubbers) ;

  public abstract U wool() ;
}