/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Grimly;
import src.leans.Rabbi;
import src.leans.Wingnut;

final class Nucleic<C, P, B extends C>
extends Grimly {
    public final Bigmouths<String> plangent;
    public final B limpet;

    public Nucleic(Bigmouths<String> bigmouths, B b) {
        super((Bigmouths<String>)null, (Boolean)false);
        this.plangent = bigmouths;
        this.limpet = b;
    }

    public final C entranced(Wingnut<? super Byte, ? super Rabbi<Byte, Byte, Byte>> wingnut, B b) {
        C c = null;
        return c;
    }
}

