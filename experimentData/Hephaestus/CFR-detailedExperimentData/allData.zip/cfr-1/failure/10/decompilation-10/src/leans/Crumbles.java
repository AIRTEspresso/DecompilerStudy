/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Ewe;
import src.leans.Poppycock;

interface Crumbles<U>
extends Poppycock<Character, Float> {
    public void overdress(Ewe[] var1);

    public U wool();
}

