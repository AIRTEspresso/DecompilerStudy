/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Buntings;
import src.leans.Pretties;
import src.leans.Rabbi;

interface Ewe
extends Rabbi<Float, Float, Boolean> {
    public Pretties<Buntings, Double> sheds(Buntings var1);
}

