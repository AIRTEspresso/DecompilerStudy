/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Clovis;
import src.leans.Dutiful;
import src.leans.Function0;
import src.leans.Nucleic;
import src.leans.Pretties;
import src.leans.Rabbi;

class Mexico<N, M, C>
implements Rabbi<Clovis, String, Character> {
    Mexico() {
    }

    @Override
    public Bigmouths<Character> scantiest() {
        Bigmouths<Character> bigmouths = this.scantiest();
        return bigmouths;
    }

    public final N parakeets(Double d, N n) {
        Boolean bl = true;
        Bigmouths bigmouths = null;
        Nucleic nucleic = new Nucleic((Bigmouths<String>)bigmouths, null);
        Function0<Long> function0 = () -> -61L;
        new Pretties(true).coffee(new Clovis(function0.apply()));
        return (N)(bl.booleanValue() ? new Dutiful<Object, P, T>(nucleic) : new Dutiful<Object, P, T>(new Nucleic<C, P, Object>((Bigmouths<String>)((Bigmouths)null), null))).corrupts.entranced(null, null);
    }
}

