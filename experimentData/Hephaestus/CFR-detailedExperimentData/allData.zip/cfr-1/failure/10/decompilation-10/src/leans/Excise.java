/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Rabbi;

final class Excise<X>
implements Rabbi<X, X, X> {
    public final Rabbi<Float, Double, X> nonvoting;
    public final Number eatery;

    public Excise(Rabbi<Float, Double, X> rabbi, Number number) {
        this.nonvoting = rabbi;
        this.eatery = number;
    }

    @Override
    public Bigmouths<X> scantiest() {
        return null;
    }
}

