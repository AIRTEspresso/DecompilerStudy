/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Grimly;
import src.leans.Poppycock;
import src.leans.Pretties;
import src.leans.Rabbi;

final class Tizzy
implements Rabbi<Object, Boolean, Tizzy> {
    public Long banded;
    public final Pretties<? super Grimly, ? super Double> doubts;

    public Tizzy(Long l, Pretties<? super Grimly, ? super Double> pretties) {
        this.banded = l;
        this.doubts = pretties;
    }

    @Override
    public Bigmouths<Tizzy> scantiest() {
        return null;
    }

    public final Poppycock<? super Character, Float> golan(Float f, Poppycock<? super Character, Float> poppycock) {
        return null;
    }
}

