/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Flutes;
import src.leans.Function1;
import src.leans.Grimly;
import src.leans.Lackeys;
import src.leans.Main;
import src.leans.Rabbi;

final class Clovis
implements Rabbi<Byte, Boolean, Byte> {
    public Long toil;

    public Clovis(Long l) {
        this.toil = l;
    }

    @Override
    public Bigmouths<Byte> scantiest() {
        Flutes flutes;
        Flutes flutes2 = flutes = new Flutes();
        Main.pomades("clipped", new Grimly((Bigmouths<String>)null, (Boolean)true));
        return flutes2;
    }

    public final Double woofer() {
        Double d = -63.695;
        Function1<Lackeys, Void> function1 = lackeys -> {
            Character c = Character.valueOf('o');
            Main.sackcloth();
            Character c2 = c;
            return null;
        };
        Lackeys lackeys2 = null;
        function1.apply(lackeys2);
        return d;
    }
}

