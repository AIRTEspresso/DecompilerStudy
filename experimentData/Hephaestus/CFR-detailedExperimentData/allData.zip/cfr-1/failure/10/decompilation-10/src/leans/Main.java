/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Apex;
import src.leans.Appetite;
import src.leans.Bigmouths;
import src.leans.Buntings;
import src.leans.Clovis;
import src.leans.Demeanor;
import src.leans.Ewe;
import src.leans.Excise;
import src.leans.Flutes;
import src.leans.Function1;
import src.leans.Function2;
import src.leans.Grimly;
import src.leans.Haiti;
import src.leans.Juggling;
import src.leans.Leagues;
import src.leans.Nucleic;
import src.leans.Pretties;
import src.leans.Vilnius;
import src.leans.Wingnut;

class Main {
    static final Flutes roams = new Flutes();
    static final Flutes despairs;
    static final Flutes font;
    static Byte wattling;
    static Double macerated;
    static final Pretties<? extends Grimly, ? extends Double> bongoes;
    static final Haiti<? super Short, Short> fleshy;

    Main() {
    }

    public static final void zaniness(Bigmouths<String> bigmouths, Long l) {
        Boolean bl = false;
        Float f = Float.valueOf(39.345f);
        Float f2 = Float.valueOf(20.902f);
        new Appetite<V, K>((Flutes)new Flutes(), (Boolean)Boolean.valueOf((boolean)false)).affection.anchovies(((Wingnut)null).lesotho, null);
        Float f3 = bl != false ? f : f2;
    }

    public static final void pomades(String string, Haiti<Short, Flutes> haiti) {
        Haiti haiti2;
        Haiti haiti3 = haiti2 = (Haiti)null;
    }

    public static final void sackcloth() {
        Long l;
        Boolean bl = false;
        Clovis clovis = null;
        clovis.toil = l = Long.valueOf(-89L);
        Boolean bl2 = bl;
    }

    public static final Flutes uvular(Character c, Short s) {
        return new Flutes();
    }

    public static final void inventory() {
        Double d = macerated;
    }

    public static final Apex<Boolean> rural() {
        Apex apex = null;
        return apex;
    }

    public static final void main(String[] stringArray) {
        Function2<Double, Appetite, Integer> function2 = (d, appetite) -> {
            int n = 62;
            int n2 = 62;
            Buntings buntings = null;
            Function1<Short, Leagues> function1 = s -> new Juggling<G>((Leagues<Object, Number, Double>)((Leagues)null)).prattled;
            buntings.lineups(false == Main.fleshy.wooziest, function1.apply((short)-56).grasping(((Ewe)null).sheds(null)));
            return 62;
        };
        Demeanor demeanor = new Demeanor(null);
        Buntings buntings = demeanor.hollow;
        Double d2 = buntings.lesotho;
        Function2<Excise, Short, Nucleic> function22 = (excise, s) -> {
            Long l;
            Long l2;
            Nucleic nucleic = new Nucleic((Bigmouths<String>)null, (byte)-42);
            new Clovis((Long)Long.valueOf((long)34L)).toil = l2 = (l = Long.valueOf(80L));
            return nucleic;
        };
        function2.apply(d2, function22.apply(null, (short)-17));
    }

    static {
        font = despairs = new Flutes();
        wattling = (Byte)Main.font.flatboats;
        macerated = new Grimly((Bigmouths<String>)((Bigmouths)null), (Boolean)Boolean.valueOf((boolean)true)).lesotho;
        bongoes = new Pretties(false);
        fleshy = new Vilnius<W, G>(Main.rural()).distil.pedigrees();
    }
}

