/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Apex;
import src.leans.Haiti;
import src.leans.Main;
import src.leans.Pretties;

abstract class Buntings
extends Apex<Number> {
    public final Pretties<? super Buntings, Double> critics;
    public final short woody;

    public Buntings(Pretties<? super Buntings, Double> pretties, short s) {
        super(null);
        this.critics = pretties;
        this.woody = s;
    }

    public abstract void lineups(boolean var1, Long var2);

    @Override
    public final Haiti<? super Short, Short> pedigrees() {
        Haiti<? super Short, Short> haiti = Main.fleshy;
        return haiti;
    }
}

