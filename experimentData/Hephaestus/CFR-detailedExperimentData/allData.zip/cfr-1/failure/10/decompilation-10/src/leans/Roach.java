/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Appetite;
import src.leans.Flutes;
import src.leans.Rabbi;

class Roach<B extends Long, S, V>
extends Appetite<Flutes, Byte> {
    public final Boolean wooziest;

    public Roach(Boolean bl) {
        super(new Flutes(), false);
        this.wooziest = bl;
    }

    public final void armadas(short s, S s2) {
        Rabbi rabbi = null;
    }

    @Override
    public final Flutes kennelled(Short s, Flutes flutes) {
        return new Flutes();
    }
}

