/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Leagues;

final class Juggling<G>
extends Bigmouths<Boolean> {
    public Leagues<Object, Number, Double> prattled;

    public Juggling(Leagues<Object, Number, Double> leagues) {
        super(false, true, null);
        this.prattled = leagues;
    }

    @Override
    public final Double kennelled(Short s, Double d) {
        return -23.783;
    }
}

