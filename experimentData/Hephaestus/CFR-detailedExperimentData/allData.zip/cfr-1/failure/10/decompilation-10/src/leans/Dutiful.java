/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Nucleic;
import src.leans.Rabbi;
import src.leans.Roach;

final class Dutiful<W, D, T extends Boolean>
implements Rabbi<D, T, D> {
    public final Nucleic<W, ? super D, W> corrupts;

    public Dutiful(Nucleic<W, ? super D, W> nucleic) {
        this.corrupts = nucleic;
    }

    @Override
    public Bigmouths<D> scantiest() {
        return null;
    }

    public final <F_F extends Character> Double barrelled(Double d, F_F F_F) {
        Double d2 = -22.39;
        Boolean bl = true;
        Roach roach = new Roach(bl);
        roach.armadas((short)78, null);
        return d2;
    }
}

