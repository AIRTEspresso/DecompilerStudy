/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Appetite;
import src.leans.Clovis;
import src.leans.Flutes;
import src.leans.Grimly;
import src.leans.Main;

final class Pretties<T extends Grimly, M extends Double>
extends Appetite<Flutes, Byte> {
    public final Boolean wooziest;

    public Pretties(Boolean bl) {
        super(new Flutes(), false);
        this.wooziest = bl;
    }

    public final void coffee(Clovis clovis) {
        byte by = Main.wattling;
        clovis.toil = 94L;
        Byte by2 = by;
    }
}

