/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Apex;
import src.leans.Bigmouths;
import src.leans.Rabbi;

final class Vilnius<W, G extends W>
implements Rabbi<Integer, Boolean, Double> {
    public final Apex<Boolean> distil;

    public Vilnius(Apex<Boolean> apex) {
        this.distil = apex;
    }

    @Override
    public Bigmouths<Double> scantiest() {
        return null;
    }
}

