/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Buntings;
import src.leans.Clients;
import src.leans.Crumbles;
import src.leans.Flutes;
import src.leans.Mexico;

class Demeanor
extends Mexico<Character, Flutes, Number> {
    public final Buntings hollow;

    public Demeanor(Buntings buntings) {
        this.hollow = buntings;
    }

    @Override
    public Bigmouths<Character> scantiest() {
        Bigmouths bigmouths;
        Bigmouths bigmouths2 = bigmouths = (Bigmouths)null;
        Clients clients = new Clients("pokiest");
        clients.deflects(false, new Object());
        return bigmouths2;
    }

    public Float trout(char c, Float f) {
        Float f2 = Float.valueOf(87.101f);
        ((Crumbles)null).overdress(null);
        return f2;
    }
}

