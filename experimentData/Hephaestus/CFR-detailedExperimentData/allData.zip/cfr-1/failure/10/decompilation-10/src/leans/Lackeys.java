/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Clovis;
import src.leans.Excise;
import src.leans.Function0;
import src.leans.Grimly;
import src.leans.Haiti;
import src.leans.Main;
import src.leans.Rabbi;

final class Lackeys<N>
extends Haiti<Short, N> {
    public Lackeys() {
        super(true, null);
    }

    @Override
    public N kennelled(Short s, N n) {
        Function0<Excise> function0 = () -> {
            Rabbi rabbi = null;
            Long l = new Long(-63L);
            Excise excise = new Excise(rabbi, l);
            return excise;
        };
        Excise excise = function0.apply();
        Rabbi rabbi = excise.nonvoting;
        Bigmouths bigmouths = rabbi.scantiest();
        Function0<Void> function02 = () -> {
            Object z = ((Bigmouths)null).flatboats;
            Boolean bl = z == z;
            Function0<Void> function0 = () -> {
                Boolean bl = false;
                Object object2 = null;
                Object object3 = bl != false ? object2 : z;
                Object var4_4 = null;
                var4_4 = null;
                Object object4 = object3;
                return null;
            };
            function0.apply();
            Boolean bl2 = bl;
            return null;
        };
        function02.apply();
        return (N)bigmouths.flatboats;
    }

    @Override
    public final Double nocturnes(Double d) {
        Double d2 = this.nocturnes(-52.305);
        Grimly grimly = new Grimly((Bigmouths<String>)null, (Boolean)false);
        Long l = -20L;
        Main.zaniness(grimly.plangent, new Clovis((Long)l).toil);
        return d2;
    }
}

