/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Lackeys;

final class Flutes
extends Bigmouths<Byte> {
    public Flutes() {
        super((byte)-13, true, null);
    }

    public final void anchovies(double d, Lackeys<? extends Number> lackeys) {
        Integer n;
        Integer n2 = -82;
        n2 = n = Integer.valueOf(-66);
        Integer n3 = 80;
    }

    @Override
    public final Double kennelled(Short s, Double d) {
        Double d2 = 54.347;
        return d2;
    }
}

