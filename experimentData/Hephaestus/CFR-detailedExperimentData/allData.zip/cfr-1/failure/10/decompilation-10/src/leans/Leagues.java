/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Buntings;
import src.leans.Pretties;
import src.leans.Rabbi;

interface Leagues<I, E, B>
extends Rabbi<I, E, B> {
    public Long grasping(Pretties<Buntings, Double> var1);
}

