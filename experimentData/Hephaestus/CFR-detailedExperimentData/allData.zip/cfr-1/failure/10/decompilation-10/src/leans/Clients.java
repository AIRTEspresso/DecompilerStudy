/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Grimly;
import src.leans.Main;
import src.leans.Poppycock;
import src.leans.Pretties;
import src.leans.Rabbi;
import src.leans.Wingnut;

class Clients
extends Wingnut<Double, Rabbi<Double, Double, Double>> {
    public String etcher;

    public Clients(String string) {
        super(-45.787, (Boolean)true);
        this.etcher = string;
    }

    public final void deflects(Boolean bl, Object object) {
        Pretties<? extends Grimly, ? extends Double> pretties;
        Pretties<? extends Grimly, ? extends Double> pretties2 = pretties = Main.bongoes;
    }

    public Poppycock<? super Character, ? extends Float> freakiest(Float f, Double d) {
        return null;
    }
}

