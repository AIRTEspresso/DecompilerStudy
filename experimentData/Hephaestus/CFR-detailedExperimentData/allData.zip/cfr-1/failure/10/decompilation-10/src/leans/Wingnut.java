/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Appetite;
import src.leans.Bigmouths;
import src.leans.Flutes;
import src.leans.Rabbi;

abstract class Wingnut<X, S extends Rabbi<X, X, X>>
extends Appetite<Flutes, Byte> {
    public final double lesotho;
    public final Boolean wooziest;

    public Wingnut(double d, Boolean bl) {
        super(new Flutes(), false);
        this.lesotho = d;
        this.wooziest = bl;
    }

    @Override
    public final Flutes kennelled(Short s, Flutes flutes) {
        return flutes;
    }

    public Bigmouths<S> anacin() {
        Bigmouths bigmouths = null;
        return bigmouths;
    }
}

