/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Haiti;

abstract class Bigmouths<Z>
extends Haiti<Short, Double> {
    public final Z flatboats;
    public final Boolean wooziest;
    public final Haiti<Short, ? extends Boolean> dissolved;

    public Bigmouths(Z z, Boolean bl, Haiti<Short, ? extends Boolean> haiti) {
        super(true, null);
        this.flatboats = z;
        this.wooziest = bl;
        this.dissolved = haiti;
    }

    @Override
    public final Double nocturnes(Double d) {
        Object var3_3;
        Double d2 = -51.3;
        Object var4_4 = var3_3 = null;
        var4_4 = null;
        return d2;
    }

    @Override
    public Double kennelled(Short s, Double d) {
        Double d2 = -13.539;
        return d2;
    }
}

