/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Flutes;
import src.leans.Haiti;

class Appetite<V extends Flutes, K extends Byte>
extends Haiti<Short, V> {
    public final Flutes affection;
    public final Boolean wooziest;

    public Appetite(Flutes flutes, Boolean bl) {
        super(true, null);
        this.affection = flutes;
        this.wooziest = bl;
    }

    @Override
    public V kennelled(Short s, V v) {
        Flutes flutes;
        Flutes flutes2;
        Flutes flutes3 = null;
        flutes3 = flutes2 = (flutes = (Flutes)null);
        return (V)flutes3;
    }

    @Override
    public final Double nocturnes(Double d) {
        return -84.138;
    }
}

