/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Rabbi;

interface Poppycock<U extends Character, T extends Float>
extends Rabbi<Character, Double, Character> {
}

