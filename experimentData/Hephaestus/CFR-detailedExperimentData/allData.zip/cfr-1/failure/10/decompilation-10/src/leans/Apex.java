/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Bigmouths;
import src.leans.Grimly;
import src.leans.Haiti;
import src.leans.Main;

abstract class Apex<Z>
extends Grimly {
    public final Bigmouths<String> plangent;

    public Apex(Bigmouths<String> bigmouths) {
        super((Bigmouths<String>)null, (Boolean)false);
        this.plangent = bigmouths;
    }

    public Haiti<? super Short, Short> pedigrees() {
        Haiti haiti = null;
        Main.inventory();
        return haiti;
    }
}

