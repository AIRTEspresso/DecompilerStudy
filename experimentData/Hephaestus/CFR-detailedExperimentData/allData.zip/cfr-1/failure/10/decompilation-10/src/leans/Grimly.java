/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

import src.leans.Appetite;
import src.leans.Bigmouths;
import src.leans.Flutes;
import src.leans.Function0;
import src.leans.Rabbi;
import src.leans.Wingnut;

class Grimly
extends Wingnut<Boolean, Rabbi<Boolean, Boolean, Boolean>> {
    public final Bigmouths<String> plangent;
    public final Boolean wooziest;

    public Grimly(Bigmouths<String> bigmouths, Boolean bl) {
        super(30.312, (Boolean)false);
        this.plangent = bigmouths;
        this.wooziest = bl;
    }

    public final Flutes scummy(float f, Appetite<? extends Flutes, ? extends Byte> appetite) {
        Flutes flutes = new Flutes();
        Function0<Void> function0 = () -> {
            Double d = 56.22;
            return null;
        };
        function0.apply();
        return flutes;
    }

    public final Long[] shipped() {
        Long l;
        Long l2 = null;
        Long l3 = l = (Long)null;
        l2 = -59L;
        return (Long[])new Object[]{null, l2, l3};
    }
}

