/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.leans;

abstract class Haiti<W extends Short, C> {
    public final Boolean wooziest;
    public final Haiti<Short, ? extends Boolean> dissolved;

    public Haiti(Boolean bl, Haiti<Short, ? extends Boolean> haiti) {
        this.wooziest = bl;
        this.dissolved = haiti;
    }

    public Double nocturnes(Double d) {
        Boolean bl = true;
        Double d2 = 38.902;
        Double d3 = -69.208;
        bl = this.wooziest;
        return bl != false ? d2 : d3;
    }

    public abstract C kennelled(W var1, C var2);
}

