package src.gauche;

class Main {
  static final Short cruder = (short)-74;

  static Boolean piggish = (Main.cruder > 65.399);

  static final Boolean sacked = Main.piggish;

  static public final Geodesics<Double, Short> sharpe(Short rattling) {
    final Geodesics<Double, Short> teaspoon = new Geodesics<Double, Short>(73.668);
    final Geodesics<Double, Short> serve = teaspoon;
    return serve;
    
  }

  static Object blankest = ((Main.sacked) ?
  Main.sharpe((short)82) : 
   ((false) ?
    new Geodesics<Double, Short>(-68.187) : 
     new Geodesics<Double, Short>(-39.255))).milkiness(((Caught<Whelp, Integer, Double>) null).marianas(new Warsaw().brainier(((Stanford) null).hesiod(), (short)94),  'k'), new Painful((float)74.953, ((Stilling<Caught<Whelp, Boolean, Float>, Painful>) null).world.marianas(null,  'v')).jiggle).majored(52.407, true);

  static public final Integer jamal() {
    return Main.jamal();
  }

  static final Integer tangerine = 19;

  static public final int adultery(int beatific, Number unhappy) {
    return 75;
  }

  static public final Geodesics<? extends Double, Short> fictional() {
    final Geodesics<? extends Double, Short> defeating = new Geodesics<Double, Short>(-18.81);
    Cardozo freedman = new Cardozo();
    Number equip = (long)-36;
    freedman.cage(equip);
    return defeating;
    
  }

  static public final void plumps() {
    final Geodesics<? extends Double, Poignancy> neva = new Geodesics<Double, Poignancy>(86.247);
    Object x_0 = neva;
    
  }

  static Geodesics<Double, ? super Long> scantier = ((((Double[]) new Object[]{(Double) null, (Double) null, (Double) null} != (Double[]) new Object[]{(Double) null})) ?
  new Bodice(new Geodesics<Double, Long>(-11.39), -66.418).ginned : 
     ((false) ?
  new Taffeta<Stilling<Caught<Whelp, Boolean, Float>, Painful>>(38) : 
   new Taffeta<Stilling<Caught<Whelp, Boolean, Float>, Painful>>(24)).refusals(-71, null));

  static public final void orated() {
    final Character jawing = 'N';
    Boolean limestone = true;
    final Integer voyaged = ((limestone) ?
      74 : 
       -84);
    new Fatal((Gracious) null, -72.386).lentils.polaroids(  ((true) ?
  jawing : 
    'b'), voyaged);
    Object x_1 = new Painful((float)-31.706, (short)-1).jiggle;
    
  }

  static public final void main(String[] args) {
    Tumbled<Fatal, Fatal> fallacy = (Tumbled<Fatal, Fatal>) null;
    final Caught<? extends Integer, Long, ? super Bodice> garbing = fallacy.decree();
    Object x_2 = garbing;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Whelp {
  public abstract <F_K> Object majored(Double ionize, F_K augustus) ;
}

final class Geodesics<W extends Double, O> implements Whelp {
  public W eurydice;

  public Geodesics(W eurydice) {
    super();
    this.eurydice = eurydice;
  }

  public final Whelp milkiness(O queer, Float plunge) {
    final Whelp dined = new Geodesics<W, W>(eurydice);
    return dined;
    
  }

  public <F_K> Object majored(Double ionize, F_K augustus) {
    final Object squeal = new Object();
    return squeal;
    
  }
}

abstract class Caught<D, L, K> implements Whelp {
  public final short adores;

  public Caught(short adores) {
    super();
    this.adores = adores;
  }

  public abstract <F_B> Short marianas(F_B twines, char rainfall) ;

  public <F_K> Object majored(Double ionize, F_K augustus) {
    Byte bud = (byte)-13;
    final Byte caligula = (byte)-22;
    Byte titled = ((false) ?
      bud : 
       caligula);
    return titled;
    
  }
}

class Warsaw extends Caught<Character, Long, Number> {
  public Warsaw() {
    super((short)29);
}

  public Character brainier(String cackling, short antedates) {
     return 'w';
  }

  public <F_B> Short marianas(F_B twines, char rainfall) {
    Short lucretius = (short)44;
    final Short ferreting = (short)96;
    lucretius = ferreting;
    return lucretius;
    
  }
}

interface Stanford extends Whelp {
  public abstract String hesiod() ;

  public abstract float betided(byte goiters, byte minamoto) ;
}

final class Painful implements Whelp {
  public final Float jiggle;
  public final short deplaned;

  public Painful(Float jiggle,short deplaned) {
    super();
    this.jiggle = jiggle;
    this.deplaned = deplaned;
  }

  public <F_K> Object majored(Double ionize, F_K augustus) {
    return new Object();
  }

  public final <F_F extends Byte> F_F sitar(F_F mackinaws) {
    final F_F sniggers = (F_F) null;
    F_F granary = sniggers;
    granary = (F_F) null;
    return granary;
    
  }
}

abstract class Stilling<Y extends Caught<? super Whelp, Boolean, ? super Float>, H extends Painful> implements Stanford {
  public Caught<? extends Float, ? super Long, Double> world;
  public final Double[] squashy;

  public Stilling(Caught<? extends Float, ? super Long, Double> world,Double[] squashy) {
    super();
    this.world = world;
    this.squashy = squashy;
  }

  public String hesiod() {
    return "gulley";
  }
}

interface Founded extends Stanford {
  public abstract Character allegedly(Short allende, Character phantoms) ;

  public abstract int snappy() ;
}

final class Cardozo extends Warsaw {
  public Cardozo() {
    super();
}

  public final void cage(Number nonexempt) {
    final Float accession = (float)-16.215;
    final Painful calmly = new Painful(accession, (short)34);
    Float mope = calmly.jiggle;
    Main.piggish =   ((true) ?
  (Poignancy) null : 
   (Poignancy) null).playpens;
    new Painful(mope, calmly.deplaned).sitar(((Credible) null).silage.musicales(new Painful((float)-40.496, (short)-69), (Number) new Long(4)).sitar((byte)41));
    
  }
}

interface Queerness<M, Q extends Integer, S extends Painful> extends Whelp {
  public abstract Painful musicales(S midwifed, Number styes) ;

  public abstract Whelp ewe() ;
}

abstract class Credible extends Warsaw {
  public final Queerness<Founded, Integer, Painful> silage;

  public Credible(Queerness<Founded, Integer, Painful> silage) {
    super();
    this.silage = silage;
  }

  public <F_B> Short marianas(F_B twines, char rainfall) {
    return (short)26;
  }

  public Object fingertip() {
    return Main.cruder;
  }
}

abstract class Poignancy implements Founded {
  public final Boolean playpens;
  public Character looming;

  public Poignancy(Boolean playpens,Character looming) {
    super();
    this.playpens = playpens;
    this.looming = looming;
  }

  public Character allegedly(Short allende, Character phantoms) {
     return 'Z';
  }
}

class Bodice implements Whelp {
  public Geodesics<Double, ? super Long> ginned;
  public final double dryers;

  public Bodice(Geodesics<Double, ? super Long> ginned,double dryers) {
    super();
    this.ginned = ginned;
    this.dryers = dryers;
  }

  public <F_K> Object majored(Double ionize, F_K augustus) {
    return Main.piggish;
  }

  public Founded stymie(Founded norwich) {
    return (Founded) null;
  }
}

class Taffeta<I extends Stilling<? super Caught<Whelp, Boolean, Float>, Painful>> implements Founded {
  public final Integer overtook;

  public Taffeta(Integer overtook) {
    super();
    this.overtook = overtook;
  }

  public final Geodesics<Double, ? super Long> refusals(int blurred, Queerness<? extends I, ? extends Integer, ? extends Painful> murine) {
    Double depiction = -58.308;
    final Geodesics<Double, Long> hawks = new Geodesics<Double, Long>(depiction);
    Main.plumps();
    return hawks;
    
  }

  public float betided(byte goiters, byte minamoto) {
    final float obsoleted = (float)-86.244;
    Main.piggish = true;
    return obsoleted;
    
  }

  public int snappy() {
    return -4;
  }

  public String hesiod() {
    return "rattans";
  }

  public <F_K> Object majored(Double ionize, F_K augustus) {
    final Object tremor = Main.sacked;
    Main.piggish = false;
    return tremor;
    
  }

  public Character allegedly(Short allende, Character phantoms) {
     return 'z';
  }
}

final class Gutsy extends Stilling<Caught<Whelp, Boolean, Float>, Painful> {
  public final Cardozo squelch;

  public Gutsy(Cardozo squelch) {
    super((Caught<Float, Long, Double>) null, new Double[0]);
    this.squelch = squelch;
  }

  public <F_K> Object majored(Double ionize, F_K augustus) {
    return Main.scantier.eurydice;
  }

  public float betided(byte goiters, byte minamoto) {
    final byte alumnus = minamoto;
    Main.orated();
    return betided((byte)39, alumnus);
    
  }
}

interface Gracious extends Whelp {
  public abstract <F_C extends Character> void polaroids(F_C lecturer, Integer retinas) ;
}

final class Fatal extends Stilling<Caught<Whelp, Boolean, Float>, Painful> {
  public final Gracious lentils;
  public final double bounciest;

  public Fatal(Gracious lentils,double bounciest) {
    super((Caught<Float, Long, Double>) null, (Double[]) new Object[]{(Double) null, (Double) null, (Double) null});
    this.lentils = lentils;
    this.bounciest = bounciest;
  }

  public <F_K> Object majored(Double ionize, F_K augustus) {
    return new Object();
  }

  public float betided(byte goiters, byte minamoto) {
    return (float)49.817;
  }
}

interface Tumbled<K, N extends K> extends Stanford {
  public abstract Caught<? extends Integer, Long, ? super Bodice> decree() ;
}