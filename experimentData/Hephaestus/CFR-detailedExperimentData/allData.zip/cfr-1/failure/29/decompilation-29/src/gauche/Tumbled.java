/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Bodice;
import src.gauche.Caught;
import src.gauche.Stanford;

interface Tumbled<K, N extends K>
extends Stanford {
    public Caught<? extends Integer, Long, ? super Bodice> decree();
}

