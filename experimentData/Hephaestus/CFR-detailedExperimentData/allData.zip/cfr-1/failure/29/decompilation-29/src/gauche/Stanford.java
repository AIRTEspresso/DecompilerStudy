/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Whelp;

interface Stanford
extends Whelp {
    public String hesiod();

    public float betided(byte var1, byte var2);
}

