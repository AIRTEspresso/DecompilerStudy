/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Painful;
import src.gauche.Whelp;

interface Queerness<M, Q extends Integer, S extends Painful>
extends Whelp {
    public Painful musicales(S var1, Number var2);

    public Whelp ewe();
}

