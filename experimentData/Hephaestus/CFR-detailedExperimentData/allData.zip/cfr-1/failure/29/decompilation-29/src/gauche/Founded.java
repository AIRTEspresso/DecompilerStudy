/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Stanford;

interface Founded
extends Stanford {
    public Character allegedly(Short var1, Character var2);

    public int snappy();
}

