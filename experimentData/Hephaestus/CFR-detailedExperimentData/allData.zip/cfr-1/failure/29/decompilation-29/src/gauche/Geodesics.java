/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Whelp;

final class Geodesics<W extends Double, O>
implements Whelp {
    public W eurydice;

    public Geodesics(W w) {
        this.eurydice = w;
    }

    public final Whelp milkiness(O o, Float f) {
        Geodesics<W, O> geodesics = new Geodesics<W, O>(this.eurydice);
        return geodesics;
    }

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        Object object = new Object();
        return object;
    }
}

