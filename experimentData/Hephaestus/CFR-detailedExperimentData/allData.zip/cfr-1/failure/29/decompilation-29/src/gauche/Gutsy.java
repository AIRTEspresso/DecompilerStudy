/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Cardozo;
import src.gauche.Caught;
import src.gauche.Main;
import src.gauche.Painful;
import src.gauche.Stilling;
import src.gauche.Whelp;

final class Gutsy
extends Stilling<Caught<Whelp, Boolean, Float>, Painful> {
    public final Cardozo squelch;

    public Gutsy(Cardozo cardozo) {
        super(null, new Double[0]);
        this.squelch = cardozo;
    }

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        return Main.scantier.eurydice;
    }

    @Override
    public float betided(byte by, byte by2) {
        byte by3 = by2;
        Main.orated();
        return this.betided((byte)39, by3);
    }
}

