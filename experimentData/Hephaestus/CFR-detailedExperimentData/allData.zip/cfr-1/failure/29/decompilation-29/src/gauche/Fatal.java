/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Caught;
import src.gauche.Gracious;
import src.gauche.Painful;
import src.gauche.Stilling;
import src.gauche.Whelp;

final class Fatal
extends Stilling<Caught<Whelp, Boolean, Float>, Painful> {
    public final Gracious lentils;
    public final double bounciest;

    public Fatal(Gracious gracious, double d) {
        super(null, (Double[])new Object[]{null, null, null});
        this.lentils = gracious;
        this.bounciest = d;
    }

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        return new Object();
    }

    @Override
    public float betided(byte by, byte by2) {
        return 49.817f;
    }
}

