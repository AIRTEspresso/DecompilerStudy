/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Whelp;

abstract class Caught<D, L, K>
implements Whelp {
    public final short adores;

    public Caught(short s) {
        this.adores = s;
    }

    public abstract <F_B> Short marianas(F_B var1, char var2);

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        Byte by;
        Byte by2 = -13;
        Byte by3 = by = Byte.valueOf((byte)-22);
        return by3;
    }
}

