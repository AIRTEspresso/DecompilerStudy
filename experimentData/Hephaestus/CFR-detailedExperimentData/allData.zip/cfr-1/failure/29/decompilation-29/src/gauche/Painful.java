/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Whelp;

final class Painful
implements Whelp {
    public final Float jiggle;
    public final short deplaned;

    public Painful(Float f, short s) {
        this.jiggle = f;
        this.deplaned = s;
    }

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        return new Object();
    }

    public final <F_F extends Byte> F_F sitar(F_F F_F) {
        Byte by;
        Byte by2 = by = (Byte)null;
        by2 = null;
        return (F_F)by2;
    }
}

