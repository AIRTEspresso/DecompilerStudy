/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Founded;

abstract class Poignancy
implements Founded {
    public final Boolean playpens;
    public Character looming;

    public Poignancy(Boolean bl, Character c) {
        this.playpens = bl;
        this.looming = c;
    }

    @Override
    public Character allegedly(Short s, Character c) {
        return Character.valueOf('Z');
    }
}

