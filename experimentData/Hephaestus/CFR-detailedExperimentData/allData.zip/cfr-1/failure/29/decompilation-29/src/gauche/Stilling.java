/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Caught;
import src.gauche.Painful;
import src.gauche.Stanford;
import src.gauche.Whelp;

abstract class Stilling<Y extends Caught<? super Whelp, Boolean, ? super Float>, H extends Painful>
implements Stanford {
    public Caught<? extends Float, ? super Long, Double> world;
    public final Double[] squashy;

    public Stilling(Caught<? extends Float, ? super Long, Double> caught, Double[] doubleArray) {
        this.world = caught;
        this.squashy = doubleArray;
    }

    @Override
    public String hesiod() {
        return "gulley";
    }
}

