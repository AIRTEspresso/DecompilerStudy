/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Bodice;
import src.gauche.Cardozo;
import src.gauche.Caught;
import src.gauche.Fatal;
import src.gauche.Geodesics;
import src.gauche.Gracious;
import src.gauche.Painful;
import src.gauche.Stanford;
import src.gauche.Stilling;
import src.gauche.Taffeta;
import src.gauche.Tumbled;
import src.gauche.Warsaw;

class Main {
    static final Short cruder = -74;
    static Boolean piggish;
    static final Boolean sacked;
    static Object blankest;
    static final Integer tangerine;
    static Geodesics<Double, ? super Long> scantier;

    Main() {
    }

    public static final Geodesics<Double, Short> sharpe(Short s) {
        Geodesics<Double, Short> geodesics;
        Geodesics<Double, Short> geodesics2 = geodesics = new Geodesics<Double, Short>(73.668);
        return geodesics2;
    }

    public static final Integer jamal() {
        return Main.jamal();
    }

    public static final int adultery(int n, Number number) {
        return 75;
    }

    public static final Geodesics<? extends Double, Short> fictional() {
        Geodesics<Double, Short> geodesics = new Geodesics<Double, Short>(-18.81);
        Cardozo cardozo = new Cardozo();
        Long l = -36L;
        cardozo.cage(l);
        return geodesics;
    }

    public static final void plumps() {
        Geodesics geodesics;
        Geodesics geodesics2 = geodesics = new Geodesics(86.247);
    }

    public static final void orated() {
        Character c = Character.valueOf('N');
        Boolean bl = true;
        Integer n = bl != false ? 74 : -84;
        new Fatal((Gracious)((Gracious)null), (double)-72.386).lentils.polaroids(Character.valueOf(c.charValue()), n);
        Float f = new Painful((Float)Float.valueOf((float)-31.706f), (short)-1).jiggle;
    }

    public static final void main(String[] stringArray) {
        Caught<Integer, Long, Bodice> caught;
        Tumbled tumbled = null;
        Caught<Integer, Long, Bodice> caught2 = caught = tumbled.decree();
    }

    static {
        sacked = piggish = Boolean.valueOf((double)cruder.shortValue() > 65.399);
        blankest = (sacked != false ? Main.sharpe((short)82) : new Geodesics<Double, Short>(-39.255)).milkiness(((Caught)null).marianas(new Warsaw().brainier(((Stanford)null).hesiod(), (short)94), 'k'), new Painful((Float)Float.valueOf((float)74.953f), (short)((Stilling)null).world.marianas(null, (char)'v').shortValue()).jiggle).majored(52.407, true);
        tangerine = 19;
        scantier = (Double[])new Object[]{null, null, null} != (Double[])new Object[]{null} ? new Bodice(new Geodesics<Double, O>(Double.valueOf((double)-11.39)), (double)-66.418).ginned : new Taffeta(24).refusals(-71, null);
    }
}

