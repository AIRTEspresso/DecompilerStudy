/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Caught;
import src.gauche.Founded;
import src.gauche.Geodesics;
import src.gauche.Main;
import src.gauche.Painful;
import src.gauche.Queerness;
import src.gauche.Stilling;
import src.gauche.Whelp;

class Taffeta<I extends Stilling<? super Caught<Whelp, Boolean, Float>, Painful>>
implements Founded {
    public final Integer overtook;

    public Taffeta(Integer n) {
        this.overtook = n;
    }

    public final Geodesics<Double, ? super Long> refusals(int n, Queerness<? extends I, ? extends Integer, ? extends Painful> queerness) {
        Double d = -58.308;
        Geodesics geodesics = new Geodesics(d);
        Main.plumps();
        return geodesics;
    }

    @Override
    public float betided(byte by, byte by2) {
        Main.piggish = true;
        return -86.244f;
    }

    @Override
    public int snappy() {
        return -4;
    }

    @Override
    public String hesiod() {
        return "rattans";
    }

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        Boolean bl = Main.sacked;
        Main.piggish = false;
        return bl;
    }

    @Override
    public Character allegedly(Short s, Character c) {
        return Character.valueOf('z');
    }
}

