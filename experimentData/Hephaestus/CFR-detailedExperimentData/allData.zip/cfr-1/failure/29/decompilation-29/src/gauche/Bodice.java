/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Founded;
import src.gauche.Geodesics;
import src.gauche.Main;
import src.gauche.Whelp;

class Bodice
implements Whelp {
    public Geodesics<Double, ? super Long> ginned;
    public final double dryers;

    public Bodice(Geodesics<Double, ? super Long> geodesics, double d) {
        this.ginned = geodesics;
        this.dryers = d;
    }

    @Override
    public <F_K> Object majored(Double d, F_K F_K) {
        return Main.piggish;
    }

    public Founded stymie(Founded founded) {
        return null;
    }
}

