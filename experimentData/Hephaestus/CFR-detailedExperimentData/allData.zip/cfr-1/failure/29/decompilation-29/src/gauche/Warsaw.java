/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Caught;

class Warsaw
extends Caught<Character, Long, Number> {
    public Warsaw() {
        super((short)29);
    }

    public Character brainier(String string, short s) {
        return Character.valueOf('w');
    }

    @Override
    public <F_B> Short marianas(F_B F_B, char c) {
        Short s;
        Short s2 = 44;
        s2 = s = Short.valueOf((short)96);
        return s2;
    }
}

