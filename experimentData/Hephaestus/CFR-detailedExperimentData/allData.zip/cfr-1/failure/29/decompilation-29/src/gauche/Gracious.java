/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Whelp;

interface Gracious
extends Whelp {
    public <F_C extends Character> void polaroids(F_C var1, Integer var2);
}

