/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Credible;
import src.gauche.Main;
import src.gauche.Painful;
import src.gauche.Poignancy;
import src.gauche.Warsaw;

final class Cardozo
extends Warsaw {
    public final void cage(Number number) {
        Float f = Float.valueOf(-16.215f);
        Painful painful = new Painful(f, 34);
        Float f2 = painful.jiggle;
        Main.piggish = ((Poignancy)null).playpens;
        new Painful(f2, painful.deplaned).sitar(((Credible)null).silage.musicales(new Painful(Float.valueOf(-40.496f), -69), new Long(4L)).sitar((byte)41));
    }
}

