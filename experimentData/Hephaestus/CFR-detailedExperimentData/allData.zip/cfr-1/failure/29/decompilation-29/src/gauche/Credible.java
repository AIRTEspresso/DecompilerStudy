/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.gauche;

import src.gauche.Founded;
import src.gauche.Main;
import src.gauche.Painful;
import src.gauche.Queerness;
import src.gauche.Warsaw;

abstract class Credible
extends Warsaw {
    public final Queerness<Founded, Integer, Painful> silage;

    public Credible(Queerness<Founded, Integer, Painful> queerness) {
        this.silage = queerness;
    }

    @Override
    public <F_B> Short marianas(F_B F_B, char c) {
        return (short)26;
    }

    public Object fingertip() {
        return Main.cruder;
    }
}

