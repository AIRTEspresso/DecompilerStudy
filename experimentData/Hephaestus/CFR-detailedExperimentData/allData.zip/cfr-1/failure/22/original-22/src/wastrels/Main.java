package src.wastrels;

class Main {
  static public final <F_I> F_I defecated() {
    Boolean nastily = ((Gorgeous) null).confesses;
    final Cheetah<Short, F_I> slime = new Cheetah<Short, F_I>("sleepers", (short)20);
    final Nina<F_I, Long> monument = (Nina<F_I, Long>) null;
    Function1<Short, Void> bundling = (facsimile) -> {
      final Integer lifting = -82;
      String rheostats = "finns";
      String stayed = "racket";
      ((Gorgeous) null).stunting =   ((true) ?
  rheostats : 
   stayed);
      Object x_0 = lifting;
      return null;
    };
    bundling.apply((short)71);
      return ((nastily) ?
  slime.extols() : 
   monument).include();
    
  }

  static public final Integer requires(Gorgeous inscribed, Gorgeous atlases) {
    final Integer calks = 19;
    final Revolver<Boolean, Sharpest, Sharpest> kenneled = ((Jawbone<Short, Short, Short>) null).patronage;
    kenneled.reunions();
    return calks;
    
  }

  static public final void latest(double backstage, Float scrunchie) {
    final Gorgeous amplifier = (Gorgeous) null;
    Main.requires(amplifier, amplifier);
    
  }

  static public final Long devilry(Byte commits, Jawbone<? super Short, Short, Short> idolaters) {
    return (long)-34;
  }

  static public final void main(String[] args) {
    Object x_4 = 8;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Fruitcake<T extends Float> {
  public abstract double grimly() ;

  public abstract T congas() ;
}

abstract class Nina<E, K extends Long> implements Fruitcake<Float> {
  public abstract E include() ;
}

abstract class Gorgeous extends Nina<Integer, Long> {
  public final Boolean confesses;
  public String stunting;

  public Gorgeous(Boolean confesses,String stunting) {
    super();
    this.confesses = confesses;
    this.stunting = stunting;
  }

  public Double soundest(Short koizumi, Double ravishes) {
    final Double chongqing = 1.723;
    return chongqing;
    
  }
}

class Cheetah<E, R> extends Nina<Integer, Long> {
  public String shorn;
  public E etchers;

  public Cheetah(String shorn,E etchers) {
    super();
    this.shorn = shorn;
    this.etchers = etchers;
  }

  public Nina<R, Long> extols() {
    return (Nina<R, Long>) null;
  }

  public Integer include() {
    return -82;
  }

  public Float congas() {
    Float aeneas = (float)40.171;
    return aeneas;
    
  }

  public double grimly() {
    final double runaway = 75.738;
    final E inquirer = (E) null;
    E jock = inquirer;
    etchers = jock;
    return runaway;
    
  }
}

final class Revolver<Q extends Boolean, U, I extends U> extends Nina<Float, Long> {
  public final U pathogens;

  public Revolver(U pathogens) {
    super();
    this.pathogens = pathogens;
  }

  public final void reunions() {
    final U emigrants = (U) null;
    Function0<Cheetah<? extends U, U>> forayed = () -> {
      return new Cheetah<U, U>("subdued", (U) null);
    };
    final double sailings = forayed.apply().grimly();
    final Float bikes = ((Revolver<Boolean, U, U>) null).include();
    Main.latest(sailings, bikes);
    Object x_1 = emigrants;
    
  }

  public Float include() {
    final Sharpest piedmont = ((Zhukov) null).attention;
    Function0<Void> hawthorne = () -> {
      Float croci = (float)97.797;
      Object x_2 = croci;
      return null;
    };
    hawthorne.apply();
    return piedmont.workday;
    
  }

  public double grimly() {
    return grimly();
  }

  public Float congas() {
    final Boolean chewers = true;
    final Float cartilage = (float)-29.348;
    final Sharpest writ = new Sharpest(cartilage);
      return ((chewers) ?
  writ : 
   new Sharpest((float)-72.51)).workday;
    
  }
}

class Sharpest extends Gorgeous {
  public Float workday;

  public Sharpest(Float workday) {
    super(true, "shakers");
    this.workday = workday;
  }

  public Integer include() {
    Integer empties = -79;
    return empties;
    
  }

  public Float congas() {
    final Float berle = (float)-75.109;
    return berle;
    
  }

  public double grimly() {
    return -95.717;
  }
}

abstract class Zhukov extends Cheetah<Byte, Character> {
  public final Sharpest attention;

  public Zhukov(Sharpest attention) {
    super("gilliam", (byte)43);
    this.attention = attention;
  }
}

abstract class Jawbone<X, I extends X, P extends X> extends Sharpest {
  public Revolver<Boolean, Sharpest, Sharpest> patronage;
  public Float workday;

  public Jawbone(Revolver<Boolean, Sharpest, Sharpest> patronage,Float workday) {
    super((float)-54.593);
    this.patronage = patronage;
    this.workday = workday;
  }
}

class Gunner extends Zhukov {
  public Gunner() {
    super(new Sharpest((float)95.0));
}

  public final char brutus(Integer tyke) {
    final Jawbone<Integer, Integer, Integer> picayune = (Jawbone<Integer, Integer, Integer>) null;
    Function1<Short, Sharpest> wheal = (teeing) -> {
      Sharpest ululating = picayune;
      ((Spiro) null).viaducts();
      return ululating;
      
    };
    return brutus(Main.requires(picayune, wheal.apply((short)66)));
    
  }
}

abstract class Spiro implements Fruitcake<Float> {
  public final Long woofed;

  public Spiro(Long woofed) {
    super();
    this.woofed = woofed;
  }

  public void viaducts() {
    char truman = 'i';
    truman =  'j';
    Object x_3 = truman;
    
  }
}