/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Gorgeous;

class Sharpest
extends Gorgeous {
    public Float workday;

    public Sharpest(Float f) {
        super(true, "shakers");
        this.workday = f;
    }

    @Override
    public Integer include() {
        Integer n = -79;
        return n;
    }

    @Override
    public Float congas() {
        Float f = Float.valueOf(-75.109f);
        return f;
    }

    @Override
    public double grimly() {
        return -95.717;
    }
}

