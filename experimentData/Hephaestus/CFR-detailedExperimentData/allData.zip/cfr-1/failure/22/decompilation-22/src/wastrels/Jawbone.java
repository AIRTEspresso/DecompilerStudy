/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Revolver;
import src.wastrels.Sharpest;

abstract class Jawbone<X, I extends X, P extends X>
extends Sharpest {
    public Revolver<Boolean, Sharpest, Sharpest> patronage;
    public Float workday;

    public Jawbone(Revolver<Boolean, Sharpest, Sharpest> revolver, Float f) {
        super(Float.valueOf(-54.593f));
        this.patronage = revolver;
        this.workday = f;
    }
}

