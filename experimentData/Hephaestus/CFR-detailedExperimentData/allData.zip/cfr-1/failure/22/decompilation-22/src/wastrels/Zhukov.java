/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Cheetah;
import src.wastrels.Sharpest;

abstract class Zhukov
extends Cheetah<Byte, Character> {
    public final Sharpest attention;

    public Zhukov(Sharpest sharpest) {
        super("gilliam", (byte)43);
        this.attention = sharpest;
    }
}

