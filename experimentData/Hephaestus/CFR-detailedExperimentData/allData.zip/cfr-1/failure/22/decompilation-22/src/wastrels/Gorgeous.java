/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Nina;

abstract class Gorgeous
extends Nina<Integer, Long> {
    public final Boolean confesses;
    public String stunting;

    public Gorgeous(Boolean bl, String string) {
        this.confesses = bl;
        this.stunting = string;
    }

    public Double soundest(Short s, Double d) {
        Double d2 = 1.723;
        return d2;
    }
}

