/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Cheetah;
import src.wastrels.Function1;
import src.wastrels.Gorgeous;
import src.wastrels.Jawbone;
import src.wastrels.Nina;
import src.wastrels.Revolver;
import src.wastrels.Sharpest;

class Main {
    Main() {
    }

    public static final <F_I> F_I defecated() {
        Boolean bl = ((Gorgeous)null).confesses;
        Cheetah cheetah = new Cheetah("sleepers", (short)20);
        Nina nina = null;
        Function1<Short, Void> function1 = s -> {
            Integer n = -82;
            String string = "finns";
            String string2 = "racket";
            ((Gorgeous)null).stunting = string;
            Integer n2 = n;
            return null;
        };
        function1.apply((short)71);
        return (F_I)(bl != false ? cheetah.extols() : nina).include();
    }

    public static final Integer requires(Gorgeous gorgeous, Gorgeous gorgeous2) {
        Integer n = 19;
        Revolver<Boolean, Sharpest, Sharpest> revolver = ((Jawbone)null).patronage;
        revolver.reunions();
        return n;
    }

    public static final void latest(double d, Float f) {
        Gorgeous gorgeous = null;
        Main.requires(gorgeous, gorgeous);
    }

    public static final Long devilry(Byte by, Jawbone<? super Short, Short, Short> jawbone) {
        return -34L;
    }

    public static final void main(String[] stringArray) {
        Integer n = 8;
    }
}

