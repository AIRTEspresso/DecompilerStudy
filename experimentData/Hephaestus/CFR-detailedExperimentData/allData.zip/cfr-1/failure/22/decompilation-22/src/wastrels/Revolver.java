/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Cheetah;
import src.wastrels.Function0;
import src.wastrels.Main;
import src.wastrels.Nina;
import src.wastrels.Sharpest;
import src.wastrels.Zhukov;

final class Revolver<Q extends Boolean, U, I extends U>
extends Nina<Float, Long> {
    public final U pathogens;

    public Revolver(U u) {
        this.pathogens = u;
    }

    public final void reunions() {
        Object var1_1 = null;
        Function0<Cheetah> function0 = () -> new Cheetah("subdued", null);
        double d = function0.apply().grimly();
        Float f = ((Revolver)null).include();
        Main.latest(d, f);
        Object var6_5 = var1_1;
    }

    @Override
    public Float include() {
        Sharpest sharpest = ((Zhukov)null).attention;
        Function0<Void> function0 = () -> {
            Float f;
            Float f2 = f = Float.valueOf(97.797f);
            return null;
        };
        function0.apply();
        return sharpest.workday;
    }

    @Override
    public double grimly() {
        return this.grimly();
    }

    @Override
    public Float congas() {
        Boolean bl = true;
        Float f = Float.valueOf(-29.348f);
        Sharpest sharpest = new Sharpest(f);
        return (bl.booleanValue() ? sharpest : new Sharpest((Float)Float.valueOf((float)-72.51f))).workday;
    }
}

