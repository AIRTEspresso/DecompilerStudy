/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Nina;

class Cheetah<E, R>
extends Nina<Integer, Long> {
    public String shorn;
    public E etchers;

    public Cheetah(String string, E e) {
        this.shorn = string;
        this.etchers = e;
    }

    public Nina<R, Long> extols() {
        return null;
    }

    @Override
    public Integer include() {
        return -82;
    }

    @Override
    public Float congas() {
        Float f = Float.valueOf(40.171f);
        return f;
    }

    @Override
    public double grimly() {
        Object var3_1;
        Object var4_2 = var3_1 = null;
        this.etchers = var4_2;
        return 75.738;
    }
}

