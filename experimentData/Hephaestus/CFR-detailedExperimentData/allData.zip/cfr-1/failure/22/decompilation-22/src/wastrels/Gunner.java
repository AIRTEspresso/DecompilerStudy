/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Function1;
import src.wastrels.Jawbone;
import src.wastrels.Main;
import src.wastrels.Sharpest;
import src.wastrels.Spiro;
import src.wastrels.Zhukov;

class Gunner
extends Zhukov {
    public Gunner() {
        super(new Sharpest(Float.valueOf(95.0f)));
    }

    public final char brutus(Integer n) {
        Jawbone jawbone = null;
        Function1<Short, Sharpest> function1 = s -> {
            Jawbone jawbone2 = jawbone;
            ((Spiro)null).viaducts();
            return jawbone2;
        };
        return this.brutus(Main.requires(jawbone, function1.apply((short)66)));
    }
}

