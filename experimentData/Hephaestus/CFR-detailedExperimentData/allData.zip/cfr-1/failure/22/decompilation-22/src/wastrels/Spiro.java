/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Fruitcake;

abstract class Spiro
implements Fruitcake<Float> {
    public final Long woofed;

    public Spiro(Long l) {
        this.woofed = l;
    }

    public void viaducts() {
        char c = 'i';
        c = 'j';
        Character c2 = Character.valueOf(c);
    }
}

