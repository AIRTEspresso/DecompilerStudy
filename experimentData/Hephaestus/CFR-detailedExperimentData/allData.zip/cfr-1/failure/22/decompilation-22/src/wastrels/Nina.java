/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wastrels;

import src.wastrels.Fruitcake;

abstract class Nina<E, K extends Long>
implements Fruitcake<Float> {
    Nina() {
    }

    public abstract E include();
}

