package src.burgher;

class Main {
  static public final long batiks() {
    long lucretius = (long)47;
    ((Mincemeat) null).gusts((byte)-99);
    return lucretius;
    
  }

  static public final Long cantor(Number hum, Double unties) {
    Long antietam = (long)-42;
    final Long dribbling = (long)60;
    antietam = dribbling;
    return antietam;
    
  }

  static public final <F_L extends Object> Continent<? super Object> acutest(F_L anemic, Continent<? super Object> test) {
    Continent<? super Object> pints = (Continent<Object>) null;
    return pints;
    
  }

  static public final void main(String[] args) {
    Cromwell<Object, Double> pitts = (Cromwell<Object, Double>) null;
    Object x_4 = pitts;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Maugham<J, C> {
  public Float enos;
  public C envelope;

  public Maugham(Float enos,C envelope) {
    this.enos = enos;
    this.envelope = envelope;
  }

  public final Long merit() {
    return ((false) ?
      (long)-95 : 
       (long)-49);
  }
}

abstract class Mincemeat {
  public final String dies;
  public Integer workaday;

  public Mincemeat(String dies,Integer workaday) {
    this.dies = dies;
    this.workaday = workaday;
  }

  public void gusts(byte boleros) {
    Function0<Character> fiches = () -> {
      final Character lineups = 'T';
      Continent<Float> patronage = (Continent<Float>) null;
      final Smallest typifies = new Smallest(patronage);
      typifies.curried.dreyfus();
      return lineups;
      
    };
    fiches.apply();
    
  }
}

interface Continent<B> {
  public abstract void dreyfus() ;
}

final class Smallest implements Continent<Float> {
  public Continent<Float> curried;

  public Smallest(Continent<Float> curried) {
    super();
    this.curried = curried;
  }

  public void dreyfus() {
    Long responses = (long)-96;
    curried = new Smallest(null);
    Object x_0 = responses;
    
  }

  public final Continent<? extends Byte> advisable(long pesetas, Mincemeat petites) {
    return (Continent<Byte>) null;
  }
}

interface Cromwell<B, L> extends Continent<B> {
  public abstract B finance(B bullocks, L sheathing) ;

  public abstract Short leukocyte(Short invisible, long arranges) ;
}

final class Musty<Z extends Boolean> implements Continent<Z> {
  public final Double homophone;

  public Musty(Double homophone) {
    super();
    this.homophone = homophone;
  }

  public void dreyfus() {
    final Musty<? extends Boolean> dredged = (Musty<Boolean>) null;
    double evidence = dredged.homophone;
    double exploiter = 22.395;
    evidence = exploiter;
    Object x_1 = evidence;
    
  }
}

class Rasp implements Cromwell<Object, Long> {
  public Short leukocyte(Short invisible, long arranges) {
    final Kennelled<Integer, Short> exploited = (Kennelled<Integer, Short>) null;
    Short spyglass = exploited.mambo;
    return spyglass;
    
  }

  public Object finance(Object bullocks, Long sheathing) {
    Boolean drives = true;
    String adultery = "hydras";
    final Byte puckett = (byte)-98;
    adultery = "keyboards";
    return ((drives) ?
      adultery : 
       (Byte[]) new Object[]{puckett});
    
  }

  public void dreyfus() {
    Long dopier = (long)-47;
    Object x_2 = dopier;
    
  }
}

abstract class Kennelled<M extends Integer, K> implements Continent<Character> {
  public final Short mambo;
  public M elections;

  public Kennelled(Short mambo,M elections) {
    super();
    this.mambo = mambo;
    this.elections = elections;
  }

  public void dreyfus() {
    Object x_3 = 2.987;
    
  }

  public abstract M landscape(double hold, K overlook) ;
}

abstract class Leanness implements Cromwell<Boolean, Integer> {
  public int delores;

  public Leanness(int delores) {
    super();
    this.delores = delores;
  }

  public abstract Musty<Boolean> westwards() ;

  public abstract <F_D extends Long> F_D caves(F_D selfless) ;
}

interface Delusion extends Cromwell<Leanness, Delusion> {
  public abstract Double outtake(Smallest susanna, char embeds) ;

  public abstract Mincemeat confabbed(Mincemeat degree, Object patchwork) ;
}