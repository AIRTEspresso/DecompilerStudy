/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Cromwell;
import src.burgher.Musty;

abstract class Leanness
implements Cromwell<Boolean, Integer> {
    public int delores;

    public Leanness(int n) {
        this.delores = n;
    }

    public abstract Musty<Boolean> westwards();

    public abstract <F_D extends Long> F_D caves(F_D var1);
}

