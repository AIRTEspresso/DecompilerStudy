/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Continent;

interface Cromwell<B, L>
extends Continent<B> {
    public B finance(B var1, L var2);

    public Short leukocyte(Short var1, long var2);
}

