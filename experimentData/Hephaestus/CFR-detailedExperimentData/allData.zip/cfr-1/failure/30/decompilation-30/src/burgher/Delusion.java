/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Cromwell;
import src.burgher.Leanness;
import src.burgher.Mincemeat;
import src.burgher.Smallest;

interface Delusion
extends Cromwell<Leanness, Delusion> {
    public Double outtake(Smallest var1, char var2);

    public Mincemeat confabbed(Mincemeat var1, Object var2);
}

