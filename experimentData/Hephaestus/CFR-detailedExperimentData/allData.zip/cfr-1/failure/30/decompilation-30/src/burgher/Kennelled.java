/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Continent;

abstract class Kennelled<M extends Integer, K>
implements Continent<Character> {
    public final Short mambo;
    public M elections;

    public Kennelled(Short s, M m) {
        this.mambo = s;
        this.elections = m;
    }

    @Override
    public void dreyfus() {
        Double d = 2.987;
    }

    public abstract M landscape(double var1, K var3);
}

