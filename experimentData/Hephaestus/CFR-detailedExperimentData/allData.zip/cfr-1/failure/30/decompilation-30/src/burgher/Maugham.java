/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

final class Maugham<J, C> {
    public Float enos;
    public C envelope;

    public Maugham(Float f, C c) {
        this.enos = f;
        this.envelope = c;
    }

    public final Long merit() {
        return -49L;
    }
}

