/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Cromwell;
import src.burgher.Kennelled;

class Rasp
implements Cromwell<Object, Long> {
    Rasp() {
    }

    @Override
    public Short leukocyte(Short s, long l) {
        Kennelled kennelled = null;
        Short s2 = kennelled.mambo;
        return s2;
    }

    @Override
    public Object finance(Object object, Long l) {
        Boolean bl = true;
        Byte[] byteArray = "hydras";
        Byte by = -98;
        byteArray = "keyboards";
        return bl != false ? byteArray : (Byte[])new Object[]{by};
    }

    @Override
    public void dreyfus() {
        Long l;
        Long l2 = l = Long.valueOf(-47L);
    }
}

