/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Continent;

final class Musty<Z extends Boolean>
implements Continent<Z> {
    public final Double homophone;

    public Musty(Double d) {
        this.homophone = d;
    }

    @Override
    public void dreyfus() {
        double d;
        Musty musty = null;
        double d2 = musty.homophone;
        d2 = d = 22.395;
        Double d3 = d2;
    }
}

