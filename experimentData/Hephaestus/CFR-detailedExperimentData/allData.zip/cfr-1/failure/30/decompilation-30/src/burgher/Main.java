/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Continent;
import src.burgher.Cromwell;
import src.burgher.Mincemeat;

class Main {
    Main() {
    }

    public static final long batiks() {
        long l = 47L;
        ((Mincemeat)null).gusts((byte)-99);
        return l;
    }

    public static final Long cantor(Number number, Double d) {
        Long l;
        Long l2 = -42L;
        l2 = l = Long.valueOf(60L);
        return l2;
    }

    public static final <F_L> Continent<? super Object> acutest(F_L F_L, Continent<? super Object> continent) {
        Continent continent2 = null;
        return continent2;
    }

    public static final void main(String[] stringArray) {
        Cromwell cromwell;
        Cromwell cromwell2 = cromwell = (Cromwell)null;
    }
}

