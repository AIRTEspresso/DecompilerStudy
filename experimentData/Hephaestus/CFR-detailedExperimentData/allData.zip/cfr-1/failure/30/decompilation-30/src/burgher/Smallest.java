/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Continent;
import src.burgher.Mincemeat;

final class Smallest
implements Continent<Float> {
    public Continent<Float> curried;

    public Smallest(Continent<Float> continent) {
        this.curried = continent;
    }

    @Override
    public void dreyfus() {
        Long l = -96L;
        this.curried = new Smallest(null);
        Long l2 = l;
    }

    public final Continent<? extends Byte> advisable(long l, Mincemeat mincemeat) {
        return null;
    }
}

