/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

import src.burgher.Continent;
import src.burgher.Function0;
import src.burgher.Smallest;

abstract class Mincemeat {
    public final String dies;
    public Integer workaday;

    public Mincemeat(String string, Integer n) {
        this.dies = string;
        this.workaday = n;
    }

    public void gusts(byte by) {
        Function0<Character> function0 = () -> {
            Character c = Character.valueOf('T');
            Continent continent = null;
            Smallest smallest = new Smallest(continent);
            smallest.curried.dreyfus();
            return c;
        };
        function0.apply();
    }
}

