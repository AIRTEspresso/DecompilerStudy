/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.burgher;

interface Function1<A1, R> {
    public R apply(A1 var1);
}

