/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Bookmaker;
import src.wive.Brows;
import src.wive.Centrist;
import src.wive.Chortling;
import src.wive.Cranking;
import src.wive.Daedalus;
import src.wive.Edens;
import src.wive.Enforced;
import src.wive.Entreat;
import src.wive.Extension;
import src.wive.Function2;
import src.wive.Iowans;
import src.wive.Nagpur;
import src.wive.Occlude;
import src.wive.Rambo;
import src.wive.Sierra;
import src.wive.Vizors;

class Main {
    static final Boolean fined = ((Entreat)null).medal;
    static final Enforced<Character> chichi = new Enforced(null, Float.valueOf(-6.28f));
    static final Enforced<Character> formica = chichi;
    static final Number clicked = (fined != false ? Main.formica.kathie : new Brows((Iowans)((Iowans)null), (Boolean)Boolean.valueOf((boolean)true)).woodchuck.deadpan(Character.valueOf('e'))).jansen(null, ((Nagpur)null).viking);
    static Daedalus<? super Character, ? extends Integer> swahilis = new Brows(new Brows((Iowans)((Iowans)null), (Boolean)Boolean.valueOf((boolean)true)).woodchuck, fined);
    static final Short limps = new Bookmaker((Short)Short.valueOf((short)81), (String)"tactical").writings;

    Main() {
    }

    public static final void lightly(Float f, Number number) {
        Byte by = 71;
    }

    public static final <F_O> void bonny(F_O F_O) {
        Object var1_1 = null;
    }

    public static final Long viaducts(Character c) {
        Long l = 26L;
        Character c2 = Character.valueOf('V');
        new Chortling<Character, Integer>(-84, chichi.westwards(c2, c2)).wryer();
        return l;
    }

    public static final Long[] jangles() {
        Rambo rambo = null;
        Long l = (Long)rambo.blushed();
        return (Long[])new Object[]{l, new Occlude<D>((Long)Long.valueOf((long)-39L)).summered, rambo.blushed()};
    }

    public static final Object wily(Daedalus<Character, Integer> daedalus, Nagpur nagpur) {
        Object object = new Object();
        return object;
    }

    public static final Boolean trudged(Boolean bl) {
        Boolean bl2 = bl;
        Vizors vizors = new Vizors();
        Occlude occlude = new Occlude(21L);
        Main.strangles(vizors, occlude.summered);
        return bl2;
    }

    public static final void strangles(Entreat entreat, Number number) {
        Bookmaker bookmaker = new Bookmaker((short)25, "upwardly");
        Function2<Rambo, Double, Vizors> function2 = (rambo, d) -> new Vizors();
        double d2 = -5.979;
        Vizors vizors = function2.apply(null, d2);
        vizors.ghoulish('4', (byte)97);
        Bookmaker bookmaker2 = bookmaker;
    }

    public static final Double landowner(Occlude<? extends String> occlude, Double d) {
        Boolean bl = true;
        Sierra sierra = bl != false ? (Sierra)null : (Sierra)null;
        Object x = sierra.putsches;
        return formica.jansen((Daedalus<Character, Integer>)null, sierra.pawning(x));
    }

    public static final Occlude<? super String> signaled() {
        Occlude occlude = new Occlude(54L);
        Edens edens = null;
        Centrist<Rambo<Number, Character>, Double, Number> centrist = edens.lampreys;
        centrist.helots(formica.jansen((Daedalus<Character, Integer>)null, -56));
        return occlude;
    }

    public static final void exigent(Cranking cranking) {
        swahilis = null;
        Extension extension = null;
    }

    public static final void main(String[] stringArray) {
        Enforced<Character> enforced = chichi;
    }
}

