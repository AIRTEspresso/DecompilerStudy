/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Chortling;
import src.wive.Iowans;

interface Chilly<H, W>
extends Iowans {
    public H avoidably(Chortling<? super Boolean, ? super Long> var1);
}

