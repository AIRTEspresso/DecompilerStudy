/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Brows;
import src.wive.Chilly;
import src.wive.Main;

final class Vizors
extends Brows {
    public Vizors() {
        super(null, false);
    }

    public final void ghoulish(char c, byte by) {
        Double d = -63.252;
        Main.swahilis = null;
        Double d2 = d;
    }

    public final Chilly<? super Character, ? extends Integer> dapples(Chilly<? super Character, ? extends Integer> chilly) {
        return null;
    }
}

