/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Chilly;
import src.wive.Function2;
import src.wive.Nagpur;

final class Chortling<V, A>
extends Nagpur {
    public A impeach;
    public final V guerillas;

    public Chortling(A a, V v) {
        super(-30);
        this.impeach = a;
        this.guerillas = v;
    }

    public final void wryer() {
        Function2<Object, Integer, Object> function2 = (object, n) -> {
            Object var2_2 = null;
            Chortling chortling = null;
            chortling.impeach = ((Chilly)null).avoidably(null);
            return var2_2;
        };
        Object A1 = null;
        function2.apply(A1, 71);
    }
}

