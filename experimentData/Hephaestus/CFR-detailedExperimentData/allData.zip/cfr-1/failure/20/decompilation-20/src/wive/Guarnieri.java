/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Iowans;
import src.wive.Nagpur;

interface Guarnieri
extends Iowans {
    public Nagpur balcony(Boolean var1);
}

