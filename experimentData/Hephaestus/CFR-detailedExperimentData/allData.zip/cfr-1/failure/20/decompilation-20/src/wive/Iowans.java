/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;

interface Iowans
extends Daedalus<Character, Integer> {
    public Daedalus<Character, Integer> deadpan(Character var1);
}

