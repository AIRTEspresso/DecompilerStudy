/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;
import src.wive.Main;

abstract class Nagpur
implements Daedalus<Character, Integer> {
    public final Integer viking;

    public Nagpur(Integer n) {
        this.viking = n;
    }

    @Override
    public Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        Double d = -23.665;
        Main.bonny(44.525);
        return d;
    }

    public Boolean rebuses(long l) {
        return false;
    }
}

