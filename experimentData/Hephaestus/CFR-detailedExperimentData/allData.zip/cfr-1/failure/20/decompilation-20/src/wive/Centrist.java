/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Cranking;
import src.wive.Daedalus;
import src.wive.Enforced;
import src.wive.Rambo;

abstract class Centrist<A extends Rambo<? super Number, Character>, X, O>
extends Enforced<Float> {
    public O towheads;

    public Centrist(O o) {
        super(null, Float.valueOf(-98.25f));
        this.towheads = o;
    }

    public void helots(X x) {
        double d = new Cranking((double)31.74, (double)-10.443).goldwyn;
        Double d2 = d;
    }

    @Override
    public final Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        Double d;
        Double d2 = -27.331;
        Double d3 = d = Double.valueOf(-27.816);
        return d3;
    }
}

