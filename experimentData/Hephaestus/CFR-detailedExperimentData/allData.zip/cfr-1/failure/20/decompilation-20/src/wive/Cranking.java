/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;
import src.wive.Extension;
import src.wive.Main;
import src.wive.Nagpur;

class Cranking
extends Nagpur {
    public double goldwyn;
    public double dittos;

    public Cranking(double d, double d2) {
        super(-37);
        this.goldwyn = d;
        this.dittos = d2;
    }

    @Override
    public final Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        Double d = -92.45;
        Integer n2 = 2;
        ((Extension)null).whams((short)-43, n2);
        return d;
    }

    @Override
    public Boolean rebuses(long l) {
        Boolean bl = false;
        Main.exigent(null);
        return bl;
    }
}

