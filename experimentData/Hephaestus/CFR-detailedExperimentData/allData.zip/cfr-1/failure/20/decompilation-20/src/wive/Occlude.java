/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;

final class Occlude<D extends String>
implements Daedalus<Character, Integer> {
    public final Long summered;

    public Occlude(Long l) {
        this.summered = l;
    }

    @Override
    public Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        return 42.811;
    }
}

