/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Brows;
import src.wive.Centrist;
import src.wive.Iowans;
import src.wive.Rambo;

abstract class Edens<Z, D>
extends Brows {
    public Centrist<Rambo<Number, Character>, Double, Number> lampreys;
    public final Iowans woodchuck;

    public Edens(Centrist<Rambo<Number, Character>, Double, Number> centrist, Iowans iowans) {
        super(null, true);
        this.lampreys = centrist;
        this.woodchuck = iowans;
    }

    public abstract Byte tariff(Z var1);
}

