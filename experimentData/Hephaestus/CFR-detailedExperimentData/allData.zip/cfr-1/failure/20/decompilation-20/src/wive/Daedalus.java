/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

interface Daedalus<H extends Character, S extends Integer> {
    public Double jansen(Daedalus<? extends Character, S> var1, S var2);
}

