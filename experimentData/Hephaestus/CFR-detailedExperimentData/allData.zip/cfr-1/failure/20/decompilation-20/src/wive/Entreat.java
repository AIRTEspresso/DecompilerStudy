/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;

abstract class Entreat
implements Daedalus<Character, Integer> {
    public final Boolean medal;

    public Entreat(Boolean bl) {
        this.medal = bl;
    }

    @Override
    public Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        Double d = -29.575;
        return d;
    }
}

