/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Iowans;

abstract class Sierra<N extends Byte, X extends N>
implements Iowans {
    public final long saint;
    public X putsches;

    public Sierra(long l, X x) {
        this.saint = l;
        this.putsches = x;
    }

    public abstract Integer pawning(X var1);
}

