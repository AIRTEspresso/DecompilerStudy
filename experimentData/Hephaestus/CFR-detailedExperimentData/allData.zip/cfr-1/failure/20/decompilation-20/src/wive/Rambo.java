/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;
import src.wive.Entreat;

abstract class Rambo<O, J>
extends Entreat {
    public final Long[] limelight;

    public Rambo(Long[] longArray) {
        super(false);
        this.limelight = longArray;
    }

    @Override
    public final Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        Double d = -65.699;
        return d;
    }

    public O blushed() {
        return null;
    }
}

