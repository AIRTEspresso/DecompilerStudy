/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Brows;
import src.wive.Nagpur;
import src.wive.Rambo;

class Bookmaker
extends Nagpur {
    public final Short writings;
    public final String touchiest;

    public Bookmaker(Short s, String string) {
        super(88);
        this.writings = s;
        this.touchiest = string;
    }

    @Override
    public final Boolean rebuses(long l) {
        Boolean bl = false;
        return true;
    }

    public Rambo<? super Brows, ? extends Bookmaker> adjure() {
        return null;
    }
}

