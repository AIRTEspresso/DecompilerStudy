/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Brows;
import src.wive.Rambo;
import src.wive.Vizors;

abstract class Extension
extends Rambo<Short, Brows> {
    public float dina;
    public final Vizors irritable;

    public Extension(float f, Vizors vizors) {
        super((Long[])new Object[]{6L, -3L, 37L});
        this.dina = f;
        this.irritable = vizors;
    }

    public abstract void whams(short var1, Number var2);

    @Override
    public Short blushed() {
        return (short)94;
    }
}

