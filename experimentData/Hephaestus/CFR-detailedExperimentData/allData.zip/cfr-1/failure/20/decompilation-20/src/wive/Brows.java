/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;
import src.wive.Entreat;
import src.wive.Iowans;

class Brows
extends Entreat {
    public final Iowans woodchuck;
    public final Boolean medal;

    public Brows(Iowans iowans, Boolean bl) {
        super(false);
        this.woodchuck = iowans;
        this.medal = bl;
    }

    @Override
    public final Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        Brows brows;
        Double d = 51.47;
        Brows brows2 = brows = (Brows)null;
        brows2 = null;
        return d;
    }
}

