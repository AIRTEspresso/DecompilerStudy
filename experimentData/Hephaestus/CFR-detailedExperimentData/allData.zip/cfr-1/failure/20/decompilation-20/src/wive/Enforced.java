/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.wive;

import src.wive.Daedalus;
import src.wive.Entreat;
import src.wive.Main;

class Enforced<M>
extends Entreat {
    public final Daedalus<Character, Integer> kathie;
    public final Float bongoes;

    public Enforced(Daedalus<Character, Integer> daedalus, Float f) {
        super(true);
        this.kathie = daedalus;
        this.bongoes = f;
    }

    @Override
    public Double jansen(Daedalus<? extends Character, Integer> daedalus, Integer n) {
        return 63.786;
    }

    public final M westwards(M m, M m2) {
        M m3 = null;
        Main.lightly(Float.valueOf(-88.72f), -65L);
        return m3;
    }
}

