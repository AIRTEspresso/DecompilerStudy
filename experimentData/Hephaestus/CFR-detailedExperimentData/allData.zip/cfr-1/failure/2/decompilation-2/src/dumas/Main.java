/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Beads;
import src.dumas.Caressed;
import src.dumas.Cunninger;
import src.dumas.Function0;
import src.dumas.Function1;
import src.dumas.Lumber;
import src.dumas.Napalmed;
import src.dumas.Omdurman;
import src.dumas.Rastaban;
import src.dumas.Rudyard;
import src.dumas.Shirks;
import src.dumas.Somalis;
import src.dumas.Spewing;
import src.dumas.Tableau;
import src.dumas.Thwart;

class Main {
    static final Omdurman<? extends Double, Byte> punctured = Main.mary();
    static final Shirks[] stiflings = ((Lumber)null).abbess;
    static Shirks[] swirls = stiflings;
    static final Shirks[] zigzags = (Boolean)new Tableau((Double)Double.valueOf((double)68.691)).brevity != false ? Main.atoll() : swirls;
    static final Shirks[] satan = zigzags;

    Main() {
    }

    public static final <F_J> F_J beanbags(F_J F_J) {
        Function1<Object, Thwart> function1 = object -> new Thwart(Float.valueOf(-18.621f), (short)-9);
        Spewing spewing = null;
        Spewing spewing2 = null;
        Object g = spewing2.flatter;
        Function0<Object> function0 = () -> {
            Somalis somalis;
            Somalis somalis2 = somalis = (Somalis)null;
            Object b = somalis2.juicers;
            return b;
        };
        spewing2.flatter = function0.apply();
        return (F_J)function1.apply(g).morpheus().bassists;
    }

    public static final Omdurman<? extends Double, Byte> mary() {
        Cunninger<? extends Double, ? extends Short> cunninger = ((Shirks)null).tweedy;
        byte by = cunninger.stanza;
        Double d = 42.284;
        Function0<Void> function0 = () -> {
            Somalis somalis = null;
            Somalis somalis2 = null;
            Somalis somalis3 = somalis;
            ((Beads)null).groping.stablest = null;
            Somalis somalis4 = somalis3;
            return null;
        };
        function0.apply();
        return new Omdurman<Double, Byte>(by, cunninger.cheese(20.11));
    }

    public static final Long honesty() {
        return 31L;
    }

    public static final Thwart<? extends Integer, Long> myst(Caressed<? super Double, ? extends Long, Double> caressed, Boolean bl) {
        Function0<Thwart> function0 = () -> {
            Boolean bl = false;
            Short s = -76;
            Float f = Float.valueOf(40.325f);
            new Rastaban<Beads>((Beads)null).detests(new Rastaban<Beads>((Beads)null).leftwards).nuclei.foetuses(Main.honesty(), punctured.cheese(((Napalmed)null).lint));
            return bl != false ? new Thwart(Float.valueOf(-74.482f), s) : new Thwart(f, (short)100);
        };
        return function0.apply();
    }

    public static final Shirks[] atoll() {
        Shirks shirks = null;
        return (Shirks[])new Object[]{null, shirks};
    }

    public static final void blamed() {
        Caressed caressed = null;
    }

    public static final void main(String[] stringArray) {
        Rudyard rudyard;
        Rudyard rudyard2 = rudyard = new Rudyard(62L, (Shirks)null);
    }
}

