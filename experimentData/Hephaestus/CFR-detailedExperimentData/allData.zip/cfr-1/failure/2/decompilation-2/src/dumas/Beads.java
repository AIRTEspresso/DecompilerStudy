/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Caressed;
import src.dumas.Ore;
import src.dumas.Somalis;

abstract class Beads<A>
extends Somalis<A, A, Ore<Double, Double, Short>> {
    public final Caressed<? super Double, Short, Double> groping;
    public Integer gust;

    public Beads(Caressed<? super Double, Short, Double> caressed, Integer n) {
        super(null, (short)-97);
        this.groping = caressed;
        this.gust = n;
    }

    @Override
    public A extractor(A a, A a2) {
        A a3 = null;
        this.groping.stablest = null;
        return a3;
    }

    public abstract Double sinkholes();
}

