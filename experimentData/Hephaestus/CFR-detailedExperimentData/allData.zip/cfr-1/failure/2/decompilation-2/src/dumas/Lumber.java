/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Cunninger;
import src.dumas.Main;
import src.dumas.Shirks;

abstract class Lumber
extends Cunninger<Short, Short> {
    public Shirks[] abbess;
    public final Short brevity;

    public Lumber(Shirks[] shirksArray, Short s) {
        super((byte)-63, (short)-18);
        this.abbess = shirksArray;
        this.brevity = s;
    }

    @Override
    public <F_E> F_E anacreon() {
        F_E F_E = null;
        Main.blamed();
        return F_E;
    }

    @Override
    public final Double cheese(Double d) {
        Double d2 = -74.642;
        return d2;
    }
}

