/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Tableau;
import src.dumas.Wrinkly;

abstract class Napalmed<S extends Long, B extends Boolean, U extends Tableau>
extends Tableau {
    public final Wrinkly nuclei;
    public final S iguana;

    public Napalmed(Wrinkly wrinkly, S s) {
        super(74.445);
        this.nuclei = wrinkly;
        this.iguana = s;
    }

    @Override
    public <F_E> F_E anacreon() {
        return null;
    }

    public abstract S compress();
}

