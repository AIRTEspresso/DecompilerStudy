/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Spewing;

abstract class Wrinkly
extends Spewing<Short, Byte, Float> {
    public Integer deadened;

    public Wrinkly(Integer n) {
        super((short)-57, -49);
        this.deadened = n;
    }

    public abstract void foetuses(Object var1, Double var2);

    @Override
    public Short sherries(Short s, Short s2) {
        return s;
    }
}

