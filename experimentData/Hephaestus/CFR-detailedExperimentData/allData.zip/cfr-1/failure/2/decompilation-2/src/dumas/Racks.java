/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Ore;
import src.dumas.Somalis;

interface Racks {
    public Somalis<? extends Boolean, ? super Racks, Ore<Double, Double, Short>> wane();
}

