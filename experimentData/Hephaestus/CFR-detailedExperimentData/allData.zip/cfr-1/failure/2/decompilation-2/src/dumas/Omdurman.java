/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Cunninger;

final class Omdurman<L, V>
extends Cunninger<L, Short> {
    public final byte stanza;
    public final L brevity;

    public Omdurman(byte by, L l) {
        super((byte)-7, null);
        this.stanza = by;
        this.brevity = l;
    }

    public final void backslash() {
        Boolean bl;
        Boolean bl2 = bl = Boolean.valueOf(true);
    }

    @Override
    public <F_E> F_E anacreon() {
        F_E F_E = null;
        return F_E;
    }
}

