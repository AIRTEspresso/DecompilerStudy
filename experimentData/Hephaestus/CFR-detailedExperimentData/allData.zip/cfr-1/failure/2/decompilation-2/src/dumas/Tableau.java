/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Breathe;
import src.dumas.Ore;

class Tableau
extends Ore<Tableau, Tableau, Boolean> {
    public final Double lint;

    public Tableau(Double d) {
        super(null, (byte)1, true);
        this.lint = d;
    }

    @Override
    public <F_E> F_E anacreon() {
        F_E F_E = null;
        Breathe breathe = null;
        breathe.bassists = null;
        return F_E;
    }
}

