/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Caressed;
import src.dumas.Loyally;
import src.dumas.Ore;

final class Thwart<E, X>
extends Ore<Float, Float, Short> {
    public Float deadened;
    public final Short brevity;

    public Thwart(Float f, Short s) {
        super(Float.valueOf(67.769f), (byte)-67, (short)-81);
        this.deadened = f;
        this.brevity = s;
    }

    public final Loyally<E> morpheus() {
        return null;
    }

    @Override
    public <F_E> F_E anacreon() {
        Caressed caressed = null;
        Object v = caressed.stablest;
        return (F_E)v;
    }
}

