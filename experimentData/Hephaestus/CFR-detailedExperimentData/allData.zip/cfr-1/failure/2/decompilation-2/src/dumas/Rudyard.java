/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Ore;
import src.dumas.Shirks;

final class Rudyard
extends Ore<Shirks, Shirks, Long> {
    public final Long brevity;
    public Shirks deadened;

    public Rudyard(Long l, Shirks shirks) {
        super(null, (byte)-6, 19L);
        this.brevity = l;
        this.deadened = shirks;
    }

    public final void stoppered() {
        Shirks shirks;
        Shirks shirks2 = shirks = (Shirks)null;
    }

    @Override
    public <F_E> F_E anacreon() {
        return null;
    }
}

