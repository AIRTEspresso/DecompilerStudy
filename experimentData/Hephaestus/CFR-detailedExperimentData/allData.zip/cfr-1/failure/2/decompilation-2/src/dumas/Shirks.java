/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Cunninger;
import src.dumas.Loyally;
import src.dumas.Spewing;

abstract class Shirks
extends Loyally<Boolean> {
    public Cunninger<? extends Double, ? extends Short> tweedy;
    public Boolean bassists;

    public Shirks(Cunninger<? extends Double, ? extends Short> cunninger, Boolean bl) {
        super(false, (byte)-79);
        this.tweedy = cunninger;
        this.bassists = bl;
    }

    public Object intrigued(Float f, Spewing<Integer, ? super Number, ? extends Byte> spewing) {
        Float f2 = f;
        return f2;
    }
}

