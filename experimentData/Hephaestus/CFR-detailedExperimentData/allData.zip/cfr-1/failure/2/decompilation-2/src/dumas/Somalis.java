/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Ore;
import src.dumas.Spewing;

abstract class Somalis<B, O, T extends Ore<? extends Double, ? extends Double, Short>>
extends Spewing<String, Integer, Long> {
    public final B juicers;
    public final short coppery;

    public Somalis(B b, short s) {
        super("freshen", 91);
        this.juicers = b;
        this.coppery = s;
    }

    public abstract B extractor(B var1, B var2);

    public Number[] copland(B b, Number ... numberArray) {
        return new Number[0];
    }
}

