/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Racks;
import src.dumas.Spewing;

final class Bennett
extends Spewing<Long, Character, Integer> {
    public Integer deadened;
    public final Racks dumb;

    public Bennett(Integer n, Racks racks) {
        super(32L, 98);
        this.deadened = n;
        this.dumb = racks;
    }

    public final void butcher() {
        Spewing spewing;
        Spewing spewing2 = spewing = (Spewing)null;
    }

    @Override
    public Short sherries(Short s, Long l) {
        return (short)99;
    }

    @Override
    public <F_E> F_E anacreon() {
        return null;
    }
}

