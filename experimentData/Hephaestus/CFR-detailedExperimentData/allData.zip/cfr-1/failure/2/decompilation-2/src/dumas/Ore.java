/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Cunninger;

abstract class Ore<B, F extends B, Q>
extends Cunninger<Q, Short> {
    public B deadened;
    public final byte stanza;
    public final Q brevity;

    public Ore(B b, byte by, Q q) {
        super((byte)-85, null);
        this.deadened = b;
        this.stanza = by;
        this.brevity = q;
    }

    @Override
    public final Double cheese(Double d) {
        Double d2 = 78.421;
        Object var3_3 = null;
        this.deadened = var3_3;
        return d2;
    }
}

