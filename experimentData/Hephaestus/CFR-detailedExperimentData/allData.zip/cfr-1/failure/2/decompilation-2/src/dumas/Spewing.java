/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Ore;

abstract class Spewing<G, K, L>
extends Ore<Integer, Integer, Object> {
    public G flatter;
    public Integer deadened;

    public Spewing(G g, Integer n) {
        super(-69, (byte)-12, new Object());
        this.flatter = g;
        this.deadened = n;
    }

    public abstract Short sherries(Short var1, G var2);
}

