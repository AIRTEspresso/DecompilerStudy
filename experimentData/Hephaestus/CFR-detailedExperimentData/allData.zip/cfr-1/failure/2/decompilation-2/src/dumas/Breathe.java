/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Loyally;
import src.dumas.Main;
import src.dumas.Omdurman;
import src.dumas.Spewing;
import src.dumas.Tableau;

abstract class Breathe<D, Q extends Omdurman<? super D, ? extends D>, I>
extends Loyally<I> {
    public I bassists;
    public final byte stanza;

    public Breathe(I i, byte by) {
        super(null, (byte)37);
        this.bassists = i;
        this.stanza = by;
    }

    @Override
    public final Double cheese(Double d) {
        Tableau tableau = new Tableau(63.227);
        return Main.punctured.cheese(tableau.lint);
    }

    public abstract Spewing<? extends Object, ? extends Byte, ? super Double> podcasts(Spewing<? extends Object, ? extends Byte, ? super Double> var1);
}

