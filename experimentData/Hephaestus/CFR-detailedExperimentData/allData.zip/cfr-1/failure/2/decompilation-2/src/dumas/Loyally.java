/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Cunninger;
import src.dumas.Omdurman;
import src.dumas.Ore;

abstract class Loyally<T>
extends Cunninger<Object, Short> {
    public T bassists;
    public final byte stanza;

    public Loyally(T t, byte by) {
        super((byte)80, -16.969);
        this.bassists = t;
        this.stanza = by;
    }

    @Override
    public Double cheese(Double d) {
        Boolean bl = false;
        Double d2 = 71.919;
        Omdurman omdurman = new Omdurman(-58, Character.valueOf('P'));
        new Omdurman(26, Character.valueOf('k')).backslash();
        return bl != false ? d2 : -57.87;
    }

    @Override
    public <F_E> F_E anacreon() {
        Object b = ((Ore)null).deadened;
        return (F_E)b;
    }
}

