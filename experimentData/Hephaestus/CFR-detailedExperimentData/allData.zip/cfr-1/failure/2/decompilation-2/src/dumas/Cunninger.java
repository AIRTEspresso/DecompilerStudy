/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

abstract class Cunninger<N, Q extends Short> {
    public final byte stanza;
    public final N brevity;

    public Cunninger(byte by, N n) {
        this.stanza = by;
        this.brevity = n;
    }

    public abstract <F_E> F_E anacreon();

    public Double cheese(Double d) {
        return d;
    }
}

