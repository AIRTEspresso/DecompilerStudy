/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Beads;
import src.dumas.Bennett;
import src.dumas.Function1;
import src.dumas.Napalmed;
import src.dumas.Ore;
import src.dumas.Racks;
import src.dumas.Rudyard;
import src.dumas.Shirks;
import src.dumas.Somalis;
import src.dumas.Tableau;

class Rastaban<X extends Beads<Number>>
implements Racks {
    public X leftwards;

    public Rastaban(X x) {
        this.leftwards = x;
    }

    public final Napalmed<Long, Boolean, Tableau> detests(X x) {
        return null;
    }

    @Override
    public Somalis<? extends Boolean, ? super Racks, Ore<Double, Double, Short>> wane() {
        Somalis somalis;
        Somalis somalis2 = somalis = (Somalis)null;
        Function1<Beads, Void> function1 = beads -> {
            Integer n = 10;
            Bennett bennett = new Bennett(n, (Racks)null);
            Shirks shirks = null;
            new Rudyard(47L, shirks).stoppered();
            bennett.butcher();
            return null;
        };
        Beads beads2 = null;
        function1.apply(beads2);
        return somalis2;
    }
}

