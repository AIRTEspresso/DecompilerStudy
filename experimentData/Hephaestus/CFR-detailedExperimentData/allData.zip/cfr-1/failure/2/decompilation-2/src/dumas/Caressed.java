/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.dumas;

import src.dumas.Function0;
import src.dumas.Ore;

abstract class Caressed<V, Q, K extends V>
extends Ore<Boolean, Boolean, Object> {
    public V stablest;
    public final Object brevity;

    public Caressed(V v, Object object) {
        super(true, (byte)28, new Object());
        this.stablest = v;
        this.brevity = object;
    }

    public V stromboli(Short s, V v) {
        V v2;
        V v3 = v2 = null;
        Function0<Void> function0 = () -> {
            Object var0;
            Object var1_1 = var0 = null;
            return null;
        };
        function0.apply();
        return v3;
    }

    public K remorse(Q q) {
        return null;
    }
}

