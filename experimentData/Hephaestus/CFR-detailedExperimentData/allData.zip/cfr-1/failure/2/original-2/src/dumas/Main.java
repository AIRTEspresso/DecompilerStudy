package src.dumas;

class Main {
  static public final <F_J> F_J beanbags(F_J freezing) {
    Function1<F_J, Thwart<F_J, F_J>> gulags = (deodorize) -> {
      return new Thwart<F_J, F_J>((float)-18.621, (short)-9);
    };
    Spewing<F_J, F_J, ? extends F_J> rhino = (Spewing<F_J, F_J, F_J>) null;
    final Spewing<F_J, ? extends F_J, ? extends F_J> lends = ((false) ?
      rhino : 
       (Spewing<F_J, F_J, F_J>) null);
    F_J coat = lends.flatter;
    Function0<F_J> loonie = () -> {
      final Somalis<F_J, ? extends F_J, ? super Ore<Double, Double, Short>> snowshed = (Somalis<F_J, F_J, Ore<Double, Double, Short>>) null;
      final Somalis<F_J, ? extends F_J, ? super Ore<Double, Double, Short>> hokkaido = ((false) ?
        (Somalis<F_J, F_J, Ore<Double, Double, Short>>) null : 
         snowshed);
      F_J argonaut = hokkaido.juicers;
      return argonaut;
      
    };
    lends.flatter = loonie.apply();
    return gulags.apply(coat).morpheus().bassists;
    
  }

  static public final Omdurman<? extends Double, Byte> mary() {
    Cunninger<? extends Double, ? extends Short> scatting = ((Shirks) null).tweedy;
    final byte ashe = scatting.stanza;
    Double gearboxes = 42.284;
    Function0<Void> waterbury = () -> {
      Somalis<? super Short, ? extends String, ? super Ore<Double, Double, Short>> gangways = (Somalis<Short, String, Ore<Double, Double, Short>>) null;
      final Somalis<Number, ? extends String, ? super Ore<Double, Double, Short>> stimulus = (Somalis<Number, String, Ore<Double, Double, Short>>) null;
      final Somalis<? super Short, ? extends String, ? super Ore<Double, Double, Short>> ghanian = ((true) ?
        gangways : 
         stimulus);
      ((Beads<Byte>) null).groping.stablest = null;
      Object x_2 = ghanian;
      return null;
    };
    waterbury.apply();
    return new Omdurman<Double, Byte>(ashe, scatting.cheese(  ((false) ?
  gearboxes : 
   20.11)));
    
  }

  static final Omdurman<? extends Double, Byte> punctured = Main.mary();

  static public final Long honesty() {
    return (long)31;
  }

  static public final Thwart<? extends Integer, Long> myst(Caressed<? super Double, ? extends Long, Double> outbids, Boolean gorky) {
    Function0<Thwart<Integer, Long>> darcy = () -> {
      Boolean apostles = false;
      final Short excel = (short)-76;
      Float deiced = (float)40.325;
      new Rastaban<Beads<Number>>((Beads<Number>) null).detests(new Rastaban<Beads<Number>>((Beads<Number>) null).leftwards).nuclei.foetuses(Main.honesty(), Main.punctured.cheese(((Napalmed<Long, Boolean, Tableau>) null).lint));
      return ((apostles) ?
        new Thwart<Integer, Long>((float)-74.482, excel) : 
         new Thwart<Integer, Long>(deiced, (short)100));
      
    };
    return darcy.apply();
    
  }

  static public final Shirks[] atoll() {
    final Shirks wander = (Shirks) null;
    return (Shirks[]) new Object[]{(Shirks) null, wander};
    
  }

  static public final void blamed() {
    Object x_5 = (Caressed<Racks, Float, Racks>) null;
    
  }

  static final Shirks[] stiflings = ((Lumber) null).abbess;

  static Shirks[] swirls = Main.stiflings;

  static final Shirks[] zigzags = ((new Tableau(68.691).brevity) ?
  Main.atoll() : 
   Main.swirls);

  static final Shirks[] satan = Main.zigzags;

  static public final void main(String[] args) {
    Rudyard bobbi = new Rudyard((long)62, (Shirks) null);
    Object x_6 = bobbi;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Cunninger<N, Q extends Short> {
  public final byte stanza;
  public final N brevity;

  public Cunninger(byte stanza,N brevity) {
    this.stanza = stanza;
    this.brevity = brevity;
  }

  public abstract <F_E> F_E anacreon() ;

  public Double cheese(Double dusting) {
    return dusting;
  }
}

abstract class Loyally<T> extends Cunninger<Object, Short> {
  public T bassists;
  public final byte stanza;

  public Loyally(T bassists,byte stanza) {
    super((byte)80, -16.969);
    this.bassists = bassists;
    this.stanza = stanza;
  }

  public Double cheese(Double dusting) {
    final Boolean witticism = false;
    Double lumbered = 71.919;
    Omdurman<Character, Boolean> beaker = new Omdurman<Character, Boolean>((byte)-58,  'P');
      ((true) ?
  new Omdurman<Character, Boolean>((byte)26,  'k') : 
   beaker).backslash();
    return ((witticism) ?
      lumbered : 
       -57.87);
    
  }

  public <F_E> F_E anacreon() {
    F_E insulated = ((Ore<F_E, F_E, Float>) null).deadened;
    return insulated;
    
  }
}

final class Omdurman<L, V> extends Cunninger<L, Short> {
  public final byte stanza;
  public final L brevity;

  public Omdurman(byte stanza,L brevity) {
    super((byte)-7, (L) null);
    this.stanza = stanza;
    this.brevity = brevity;
  }

  public final void backslash() {
    final Boolean festive = true;
    Object x_0 = festive;
    
  }

  public <F_E> F_E anacreon() {
    final F_E mite = (F_E) null;
    return mite;
    
  }
}

abstract class Ore<B, F extends B, Q> extends Cunninger<Q, Short> {
  public B deadened;
  public final byte stanza;
  public final Q brevity;

  public Ore(B deadened,byte stanza,Q brevity) {
    super((byte)-85, (Q) null);
    this.deadened = deadened;
    this.stanza = stanza;
    this.brevity = brevity;
  }

  public final Double cheese(Double dusting) {
    final Double caginess = 78.421;
    final B lafitte = (B) null;
    deadened = lafitte;
    return caginess;
    
  }
}

final class Thwart<E, X> extends Ore<Float, Float, Short> {
  public Float deadened;
  public final Short brevity;

  public Thwart(Float deadened,Short brevity) {
    super((float)67.769, (byte)-67, (short)-81);
    this.deadened = deadened;
    this.brevity = brevity;
  }

  public final Loyally<E> morpheus() {
    return (Loyally<E>) null;
  }

  public <F_E> F_E anacreon() {
    final Caressed<F_E, X, F_E> foremen = (Caressed<F_E, X, F_E>) null;
    F_E elisha = foremen.stablest;
    return elisha;
    
  }
}

abstract class Caressed<V, Q, K extends V> extends Ore<Boolean, Boolean, Object> {
  public V stablest;
  public final Object brevity;

  public Caressed(V stablest,Object brevity) {
    super(true, (byte)28, new Object());
    this.stablest = stablest;
    this.brevity = brevity;
  }

  public V stromboli(Short exchange, V lacey) {
    V vexing = (V) null;
    V continual = vexing;
    Function0<Void> bear = () -> {
      V dirks = (V) null;
      Object x_1 = dirks;
      return null;
    };
    bear.apply();
    return continual;
    
  }

  public K remorse(Q decatur) {
    return (K) null;
  }
}

abstract class Spewing<G, K, L> extends Ore<Integer, Integer, Object> {
  public G flatter;
  public Integer deadened;

  public Spewing(G flatter,Integer deadened) {
    super(-69, (byte)-12, new Object());
    this.flatter = flatter;
    this.deadened = deadened;
  }

  public abstract Short sherries(Short fanboys, G napes) ;
}

abstract class Somalis<B, O, T extends Ore<? extends Double, ? extends Double, Short>> extends Spewing<String, Integer, Long> {
  public final B juicers;
  public final short coppery;

  public Somalis(B juicers,short coppery) {
    super("freshen", 91);
    this.juicers = juicers;
    this.coppery = coppery;
  }

  public abstract B extractor(B nominees, B ameer) ;

  public Number[] copland(B deleted, Number... polanski) {
    return new Number[0];
  }
}

abstract class Shirks extends Loyally<Boolean> {
  public Cunninger<? extends Double, ? extends Short> tweedy;
  public Boolean bassists;

  public Shirks(Cunninger<? extends Double, ? extends Short> tweedy,Boolean bassists) {
    super(false, (byte)-79);
    this.tweedy = tweedy;
    this.bassists = bassists;
  }

  public Object intrigued(Float brady, Spewing<Integer, ? super Number, ? extends Byte> stoppers) {
    Object tumbled = brady;
    return tumbled;
    
  }
}

abstract class Beads<A> extends Somalis<A, A, Ore<Double, Double, Short>> {
  public final Caressed<? super Double, Short, Double> groping;
  public Integer gust;

  public Beads(Caressed<? super Double, Short, Double> groping,Integer gust) {
    super((A) null, (short)-97);
    this.groping = groping;
    this.gust = gust;
  }

  public A extractor(A nominees, A ameer) {
    final A antedates = (A) null;
    groping.stablest = null;
    return antedates;
    
  }

  public abstract Double sinkholes() ;
}

interface Racks {
  public abstract Somalis<? extends Boolean, ? super Racks, Ore<Double, Double, Short>> wane() ;
}

abstract class Breathe<D, Q extends Omdurman<? super D, ? extends D>, I> extends Loyally<I> {
  public I bassists;
  public final byte stanza;

  public Breathe(I bassists,byte stanza) {
    super((I) null, (byte)37);
    this.bassists = bassists;
    this.stanza = stanza;
  }

  public final Double cheese(Double dusting) {
    final Tableau roxy = new Tableau(63.227);
    return Main.punctured.cheese(roxy.lint);
    
  }

  public abstract Spewing<? extends Object, ? extends Byte, ? super Double> podcasts(Spewing<? extends Object, ? extends Byte, ? super Double> beginners) ;
}

class Tableau extends Ore<Tableau, Tableau, Boolean> {
  public final Double lint;

  public Tableau(Double lint) {
    super((Tableau) null, (byte)1, true);
    this.lint = lint;
  }

  public <F_E> F_E anacreon() {
    final F_E cults = (F_E) null;
    Breathe<Double, Omdurman<Double, Double>, ? super Double> dears = (Breathe<Double, Omdurman<Double, Double>, Double>) null;
    dears.bassists = null;
    return cults;
    
  }
}

abstract class Wrinkly extends Spewing<Short, Byte, Float> {
  public Integer deadened;

  public Wrinkly(Integer deadened) {
    super((short)-57, -49);
    this.deadened = deadened;
  }

  public abstract void foetuses(Object bassi, Double goodbys) ;

  public Short sherries(Short fanboys, Short napes) {
    return fanboys;
  }
}

abstract class Napalmed<S extends Long, B extends Boolean, U extends Tableau> extends Tableau {
  public final Wrinkly nuclei;
  public final S iguana;

  public Napalmed(Wrinkly nuclei,S iguana) {
    super(74.445);
    this.nuclei = nuclei;
    this.iguana = iguana;
  }

  public <F_E> F_E anacreon() {
    return (F_E) null;
  }

  public abstract S compress() ;
}

class Rastaban<X extends Beads<Number>> implements Racks {
  public X leftwards;

  public Rastaban(X leftwards) {
    super();
    this.leftwards = leftwards;
  }

  public final Napalmed<Long, Boolean, Tableau> detests(X unfolded) {
    return (Napalmed<Long, Boolean, Tableau>) null;
  }

  public Somalis<? extends Boolean, ? super Racks, Ore<Double, Double, Short>> wane() {
    Somalis<Boolean, ? super Racks, Ore<Double, Double, Short>> parts = (Somalis<Boolean, Racks, Ore<Double, Double, Short>>) null;
    final Somalis<? extends Boolean, ? super Racks, Ore<Double, Double, Short>> luckily = parts;
    Function1<X, Void> curative = (vending) -> {
      final Integer horses = 10;
      Bennett brutus = new Bennett(horses, (Racks) null);
      final Shirks prolog = (Shirks) null;
      new Rudyard((long)47, prolog).stoppered();
      brutus.butcher();
      return null;
    };
    X thatched = (X) null;
    curative.apply(thatched);
    return luckily;
    
  }
}

final class Bennett extends Spewing<Long, Character, Integer> {
  public Integer deadened;
  public final Racks dumb;

  public Bennett(Integer deadened,Racks dumb) {
    super((long)32, 98);
    this.deadened = deadened;
    this.dumb = dumb;
  }

  public final void butcher() {
    Spewing<? super Shirks, ? extends String, Integer> owls = (Spewing<Shirks, String, Integer>) null;
    Object x_3 = owls;
    
  }

  public Short sherries(Short fanboys, Long napes) {
    return (short)99;
  }

  public <F_E> F_E anacreon() {
    return (F_E) null;
  }
}

final class Rudyard extends Ore<Shirks, Shirks, Long> {
  public final Long brevity;
  public Shirks deadened;

  public Rudyard(Long brevity,Shirks deadened) {
    super((Shirks) null, (byte)-6, (long)19);
    this.brevity = brevity;
    this.deadened = deadened;
  }

  public final void stoppered() {
    final Shirks luring = (Shirks) null;
    Object x_4 = luring;
    
  }

  public <F_E> F_E anacreon() {
    return (F_E) null;
  }
}

abstract class Lumber extends Cunninger<Short, Short> {
  public Shirks[] abbess;
  public final Short brevity;

  public Lumber(Shirks[] abbess,Short brevity) {
    super((byte)-63, (short)-18);
    this.abbess = abbess;
    this.brevity = brevity;
  }

  public <F_E> F_E anacreon() {
    F_E ruffles = (F_E) null;
    Main.blamed();
    return ruffles;
    
  }

  public final Double cheese(Double dusting) {
    Double tumble = -74.642;
    return tumble;
    
  }
}