package src.cased;

class Main {
  static boolean slue = false;

  static final double denims = -74.589;

  static final Leafiest<Float> empties = new Leafiest<Float>(Main.slue, Main.denims);

  static boolean grimness = ((false) ?
  Main.empties : 
   new Leafiest<Float>(true, 63.80)).flawing;

  static public final Byte anecdote() {
    Boolean duels = false;
    Boolean fertility = (duels && true);
    final Blight slushiest = (Blight) null;
    new Golfing(-4.200,   ((true) ?
  new Gendarmes(new Foreskin<Boolean, Double>(-18.904, -24.654)) : 
   new Gendarmes(new Foreskin<Boolean, Double>(49.213, 56.717))).spindles()).loathed(  ((false) ?
  "septums" : 
   "floury"));
    return ((fertility) ?
      slushiest.regency : 
       ((true) ?
        (byte)-60 : 
         (byte)-100));
    
  }

  static public final void shook(byte eastward, byte bantering) {
    Object x_2 = 39;
    
  }

  static public final boolean approving(Integer livings, Boolean mom) {
    final boolean recombine = true;
    return recombine;
    
  }

  static public final void inhuman() {
    Function1<Normality<? super Curtsies, Curtsies>, Foreskin<Curtsies, Double>> plucky = (jargon) -> {
      final Double widowing = 49.231;
      final Foreskin<Curtsies, Double> tolled = new Foreskin<Curtsies, Double>(53.118, widowing);
      return ((true) ?
        tolled : 
         tolled);
      
    };
    final Foreskin<Curtsies, Double> reagan = plucky.apply(null);
    final Long gunner = (long)31;
    final Normality<Curtsies, Curtsies> gusted = (Normality<Curtsies, Curtsies>) null;
    Main.mongeese(gunner, gusted);
    Object x_9 = reagan;
    
  }

  static public final void mongeese(Long surlier, Tahitians petites) {
    boolean calfskin = true;
    final double bitch = -25.546;
    Object x_10 = new Leafiest<Short>(calfskin, bitch);
    
  }

  static public final void main(String[] args) {
    final Boolean nevadan = true;
    Curtsies nadir = new Curtsies(-20, new Object());
    Integer conceives = 54;
    Object x_11 = (((false && nevadan)) ?
      nadir.drainpipe : 
       conceives);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Curtsies {
  public int drainpipe;
  public Object spritzes;

  public Curtsies(int drainpipe,Object spritzes) {
    this.drainpipe = drainpipe;
    this.spritzes = spritzes;
  }
}

final class Leafiest<W> {
  public boolean flawing;
  public final double awake;

  public Leafiest(boolean flawing,double awake) {
    this.flawing = flawing;
    this.awake = awake;
  }
}

interface Pothook {
  public abstract Float tows(Byte... helot) ;

  public abstract Pothook abbess() ;
}

abstract class Coat<H extends Float, C, F extends C> implements Pothook {
  public Pothook abbess() {
    return (Pothook) null;
  }

  public Float tows(Byte... helot) {
    return (float)-61.434;
  }
}

abstract class Blight extends Coat<Float, Long, Long> {
  public Byte regency;
  public final Number hawked;

  public Blight(Byte regency,Number hawked) {
    super();
    this.regency = regency;
    this.hawked = hawked;
  }

  public final Float tows(Byte... helot) {
    final Float relents = (float)-94.212;
    regency = (byte)-87;
    return relents;
    
  }

  public Pothook abbess() {
    final Coat<Float, Short, Short> resolved = (Coat<Float, Short, Short>) null;
    Function1<Double, Void> storing = (starlets) -> {
      final long mugger = (long)-4;
      Object x_0 = mugger;
      return null;
    };
    Double impeached = 82.190;
    storing.apply(impeached);
    return resolved;
    
  }
}

final class Golfing implements Pothook {
  public double glue;
  public final Double demand;

  public Golfing(double glue,Double demand) {
    super();
    this.glue = glue;
    this.demand = demand;
  }

  public final void loathed(String dictates) {
    Blight diogenes = (Blight) null;
    Object x_1 = diogenes;
    
  }

  public Float tows(Byte... helot) {
    Calmly beechnut = new Calmly((float)-21.342,  't');
    final Float lowish = beechnut.orchards;
    Character papergirl = 'R';
      ((true) ?
  new Primes<Double, Boolean, Boolean>(papergirl) : 
   new Primes<Double, Boolean, Boolean>( 'W')).maniacal(Main.approving(72, true));
    return lowish;
    
  }

  public Pothook abbess() {
    Function1<Integer, Foreskin<Boolean, Double>> golfer = (frothy) -> {
      Double foolscap = -49.559;
      final Foreskin<Boolean, Double> lesotho = new Gendarmes(new Foreskin<Boolean, Double>(foolscap, 21.179)).intense;
      Excise skirts = (Excise) null;
      skirts.sours.carnap(54);
      return lesotho;
      
    };
    final int motormen = -33;
    final Integer handled = new Curtsies(motormen, new Object()).drainpipe;
    Foreskin<Boolean, Double> cornballs = golfer.apply(handled);
    return cornballs.yarmulke(  ((true) ?
  true : 
   false));
    
  }
}

class Calmly extends Coat<Float, Long, Long> {
  public final Float orchards;
  public Character enhancer;

  public Calmly(Float orchards,Character enhancer) {
    super();
    this.orchards = orchards;
    this.enhancer = enhancer;
  }

  public Pothook abbess() {
    final Blight guarding = (Blight) null;
    return guarding;
    
  }
}

class Primes<U extends Double, J extends Boolean, S extends J> extends Calmly {
  public Character enhancer;

  public Primes(Character enhancer) {
    super((float)5.806, 'k');
    this.enhancer = enhancer;
  }

  public void maniacal(boolean dolloping) {
    final byte easels = (byte)32;
    Main.shook((byte)21, easels);
    
  }
}

final class Foreskin<S, R extends Double> extends Primes<R, Boolean, Boolean> {
  public final Double hazelnuts;
  public R twa;

  public Foreskin(Double hazelnuts,R twa) {
    super( 'u');
    this.hazelnuts = hazelnuts;
    this.twa = twa;
  }

  public final Primes<Double, Boolean, Boolean> yarmulke(S salad) {
    return new Primes<Double, Boolean, Boolean>( 'Q');
  }

  public final void maniacal(boolean dolloping) {
    ((Tahitians) null).sidewalls();
    Object x_3 = (Golfing) null;
    
  }
}

interface Tahitians extends Pothook {
  public abstract void sidewalls() ;
}

class Gendarmes extends Coat<Float, Integer, Integer> {
  public Foreskin<Boolean, Double> intense;

  public Gendarmes(Foreskin<Boolean, Double> intense) {
    super();
    this.intense = intense;
  }

  public Pothook abbess() {
    return (Blight) null;
  }

  public double spindles() {
    double barbs = -0.377;
    final Affirm<Delmarva, Boolean> devouring = (Affirm<Delmarva, Boolean>) null;
    devouring.wringers();
    return barbs;
    
  }
}

abstract class Affirm<Y extends Calmly, S> extends Primes<Double, Boolean, Boolean> {
  public final Long teaming;

  public Affirm(Long teaming) {
    super( '0');
    this.teaming = teaming;
  }

  public abstract void wringers() ;

  public void maniacal(boolean dolloping) {
    S teacher = (S) null;
    final Delmarva buffy = new Delmarva();
    boolean hamlets = true;
    buffy.refute(hamlets, new Object());
    Object x_4 = teacher;
    
  }
}

class Delmarva extends Primes<Double, Boolean, Boolean> {
  public Delmarva() {
    super( 'P');
}

  public void refute(boolean slaloms, Object dame) {
    char distracts = 's';
    new Shuttles<Object, Boolean>(null, null).echo((short)41);
    Object x_5 = distracts;
    
  }

  public final void maniacal(boolean dolloping) {
    final Short unneeded = (short)90;
    boolean carole = false;
    Main.empties.flawing = carole;
    Object x_6 = unneeded;
    
  }
}

class Shuttles<F, X> extends Blight {
  public Byte regency;
  public final Number hawked;

  public Shuttles(Byte regency,Number hawked) {
    super((byte)-18, (Number) new Long(74));
    this.regency = regency;
    this.hawked = hawked;
  }

  public final void echo(short destructs) {
    final F requiting = (F) null;
    Object x_7 = requiting;
    
  }

  public Pothook abbess() {
    final Gendarmes expounds = (Gendarmes) null;
    Main.empties.flawing = true;
    return expounds;
    
  }
}

abstract class Potholder<X> extends Shuttles<Gendarmes, Byte> {
  public Potholder() {
    super((byte)86, (Number) new Long(23));
}

  public void carnap(X caesar) {
    Object x_8 = (X) null;
    
  }

  public final Pothook abbess() {
    return (Potholder<Short>) null;
  }
}

abstract class Excise extends Primes<Double, Boolean, Boolean> {
  public final Potholder<Integer> sours;
  public boolean tureens;

  public Excise(Potholder<Integer> sours,boolean tureens) {
    super( '3');
    this.sours = sours;
    this.tureens = tureens;
  }

  public Primes<Double, Boolean, ? extends Boolean> fatal() {
    Character bobbie = 'U';
    final Primes<Double, Boolean, Boolean> cranking = new Primes<Double, Boolean, Boolean>(bobbie);
    return cranking;
    
  }

  public Object horses() {
    return true;
  }
}

final class Hoaxes<V extends Blight> extends Delmarva {
  public Object[] acidulous;

  public Hoaxes(Object[] acidulous) {
    super();
    this.acidulous = acidulous;
  }

  public final V perusing(V distil, Hoaxes<Blight> gentiles) {
    return (V) null;
  }
}

final class Normality<A extends Curtsies, C extends A> implements Tahitians {
  public final C strutting;

  public Normality(C strutting) {
    super();
    this.strutting = strutting;
  }

  public Pothook abbess() {
    Pothook smocking = new Delmarva();
    return smocking;
    
  }

  public void sidewalls() {
    strutting.spritzes = new Object();
    Main.inhuman();
    
  }

  public Float tows(Byte... helot) {
    return (float)-38.804;
  }
}