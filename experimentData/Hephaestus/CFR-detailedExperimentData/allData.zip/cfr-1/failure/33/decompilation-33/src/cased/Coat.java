/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Pothook;

abstract class Coat<H extends Float, C, F extends C>
implements Pothook {
    Coat() {
    }

    @Override
    public Pothook abbess() {
        return null;
    }

    @Override
    public Float tows(Byte ... byteArray) {
        return Float.valueOf(-61.434f);
    }
}

