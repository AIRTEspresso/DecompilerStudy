/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

interface Pothook {
    public Float tows(Byte ... var1);

    public Pothook abbess();
}

