/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Calmly;
import src.cased.Main;

class Primes<U extends Double, J extends Boolean, S extends J>
extends Calmly {
    public Character enhancer;

    public Primes(Character c) {
        super(Float.valueOf(5.806f), Character.valueOf('k'));
        this.enhancer = c;
    }

    public void maniacal(boolean bl) {
        Main.shook((byte)21, (byte)32);
    }
}

