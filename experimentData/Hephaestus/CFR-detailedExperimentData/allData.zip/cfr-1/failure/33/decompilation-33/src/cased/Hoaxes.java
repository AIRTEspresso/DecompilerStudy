/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Blight;
import src.cased.Delmarva;

final class Hoaxes<V extends Blight>
extends Delmarva {
    public Object[] acidulous;

    public Hoaxes(Object[] objectArray) {
        this.acidulous = objectArray;
    }

    public final V perusing(V v, Hoaxes<Blight> hoaxes) {
        return (V)((Blight)null);
    }
}

