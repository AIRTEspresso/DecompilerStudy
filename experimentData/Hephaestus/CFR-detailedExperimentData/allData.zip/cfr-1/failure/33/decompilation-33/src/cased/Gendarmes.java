/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Affirm;
import src.cased.Coat;
import src.cased.Foreskin;
import src.cased.Pothook;

class Gendarmes
extends Coat<Float, Integer, Integer> {
    public Foreskin<Boolean, Double> intense;

    public Gendarmes(Foreskin<Boolean, Double> foreskin) {
        this.intense = foreskin;
    }

    @Override
    public Pothook abbess() {
        return null;
    }

    public double spindles() {
        double d = -0.377;
        Affirm affirm = null;
        affirm.wringers();
        return d;
    }
}

