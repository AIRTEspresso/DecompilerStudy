/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Calmly;
import src.cased.Delmarva;
import src.cased.Primes;

abstract class Affirm<Y extends Calmly, S>
extends Primes<Double, Boolean, Boolean> {
    public final Long teaming;

    public Affirm(Long l) {
        super(Character.valueOf('0'));
        this.teaming = l;
    }

    public abstract void wringers();

    @Override
    public void maniacal(boolean bl) {
        Object var2_2 = null;
        Delmarva delmarva = new Delmarva();
        boolean bl2 = true;
        delmarva.refute(bl2, new Object());
        Object var5_5 = var2_2;
    }
}

