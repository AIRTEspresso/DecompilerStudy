/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Main;
import src.cased.Primes;
import src.cased.Shuttles;

class Delmarva
extends Primes<Double, Boolean, Boolean> {
    public Delmarva() {
        super(Character.valueOf('P'));
    }

    public void refute(boolean bl, Object object) {
        char c = 's';
        new Shuttles(null, null).echo((short)41);
        Character c2 = Character.valueOf(c);
    }

    @Override
    public final void maniacal(boolean bl) {
        boolean bl2;
        Short s = 90;
        Main.empties.flawing = bl2 = false;
        Short s2 = s;
    }
}

