/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Curtsies;
import src.cased.Delmarva;
import src.cased.Main;
import src.cased.Pothook;
import src.cased.Tahitians;

final class Normality<A extends Curtsies, C extends A>
implements Tahitians {
    public final C strutting;

    public Normality(C c) {
        this.strutting = c;
    }

    @Override
    public Pothook abbess() {
        Delmarva delmarva = new Delmarva();
        return delmarva;
    }

    @Override
    public void sidewalls() {
        ((Curtsies)this.strutting).spritzes = new Object();
        Main.inhuman();
    }

    @Override
    public Float tows(Byte ... byteArray) {
        return Float.valueOf(-38.804f);
    }
}

