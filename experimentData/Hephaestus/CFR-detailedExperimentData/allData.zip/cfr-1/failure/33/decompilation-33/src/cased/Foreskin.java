/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Golfing;
import src.cased.Primes;
import src.cased.Tahitians;

final class Foreskin<S, R extends Double>
extends Primes<R, Boolean, Boolean> {
    public final Double hazelnuts;
    public R twa;

    public Foreskin(Double d, R r) {
        super(Character.valueOf('u'));
        this.hazelnuts = d;
        this.twa = r;
    }

    public final Primes<Double, Boolean, Boolean> yarmulke(S s) {
        return new Primes<Double, Boolean, Boolean>(Character.valueOf('Q'));
    }

    @Override
    public final void maniacal(boolean bl) {
        ((Tahitians)null).sidewalls();
        Golfing golfing = null;
    }
}

