/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

final class Leafiest<W> {
    public boolean flawing;
    public final double awake;

    public Leafiest(boolean bl, double d) {
        this.flawing = bl;
        this.awake = d;
    }
}

