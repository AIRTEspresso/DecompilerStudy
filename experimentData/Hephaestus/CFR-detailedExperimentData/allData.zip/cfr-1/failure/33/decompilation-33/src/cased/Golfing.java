/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Blight;
import src.cased.Calmly;
import src.cased.Curtsies;
import src.cased.Excise;
import src.cased.Foreskin;
import src.cased.Function1;
import src.cased.Gendarmes;
import src.cased.Main;
import src.cased.Pothook;
import src.cased.Primes;

final class Golfing
implements Pothook {
    public double glue;
    public final Double demand;

    public Golfing(double d, Double d2) {
        this.glue = d;
        this.demand = d2;
    }

    public final void loathed(String string) {
        Blight blight;
        Blight blight2 = blight = (Blight)null;
    }

    @Override
    public Float tows(Byte ... byteArray) {
        Calmly calmly = new Calmly(Float.valueOf(-21.342f), Character.valueOf('t'));
        Float f = calmly.orchards;
        Character c = Character.valueOf('R');
        new Primes(c).maniacal(Main.approving(72, true));
        return f;
    }

    @Override
    public Pothook abbess() {
        Function1<Integer, Foreskin> function1 = n -> {
            Double d = -49.559;
            Foreskin<Boolean, Double> foreskin = new Gendarmes(new Foreskin<Boolean, Double>((Double)d, Double.valueOf((double)21.179))).intense;
            Excise excise = null;
            excise.sours.carnap(54);
            return foreskin;
        };
        Integer n2 = new Curtsies((int)-33, (Object)new Object()).drainpipe;
        Foreskin foreskin = function1.apply(n2);
        return foreskin.yarmulke(true);
    }
}

