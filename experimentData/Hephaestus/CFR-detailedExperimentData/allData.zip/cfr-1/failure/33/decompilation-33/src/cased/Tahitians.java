/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Pothook;

interface Tahitians
extends Pothook {
    public void sidewalls();
}

