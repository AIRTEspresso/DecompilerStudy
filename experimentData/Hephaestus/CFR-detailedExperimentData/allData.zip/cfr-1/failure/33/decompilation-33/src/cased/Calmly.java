/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Blight;
import src.cased.Coat;
import src.cased.Pothook;

class Calmly
extends Coat<Float, Long, Long> {
    public final Float orchards;
    public Character enhancer;

    public Calmly(Float f, Character c) {
        this.orchards = f;
        this.enhancer = c;
    }

    @Override
    public Pothook abbess() {
        Blight blight = null;
        return blight;
    }
}

