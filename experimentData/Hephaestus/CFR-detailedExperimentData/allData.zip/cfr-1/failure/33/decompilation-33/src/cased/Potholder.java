/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Gendarmes;
import src.cased.Pothook;
import src.cased.Shuttles;

abstract class Potholder<X>
extends Shuttles<Gendarmes, Byte> {
    public Potholder() {
        super((byte)86, new Long(23L));
    }

    public void carnap(X x) {
        Object var2_2 = null;
    }

    @Override
    public final Pothook abbess() {
        return null;
    }
}

