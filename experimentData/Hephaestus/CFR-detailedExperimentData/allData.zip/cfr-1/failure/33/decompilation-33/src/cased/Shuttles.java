/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Blight;
import src.cased.Gendarmes;
import src.cased.Main;
import src.cased.Pothook;

class Shuttles<F, X>
extends Blight {
    public Byte regency;
    public final Number hawked;

    public Shuttles(Byte by, Number number) {
        super((byte)-18, new Long(74L));
        this.regency = by;
        this.hawked = number;
    }

    public final void echo(short s) {
        Object var2_2;
        Object var3_3 = var2_2 = null;
    }

    @Override
    public Pothook abbess() {
        Gendarmes gendarmes = null;
        Main.empties.flawing = true;
        return gendarmes;
    }
}

