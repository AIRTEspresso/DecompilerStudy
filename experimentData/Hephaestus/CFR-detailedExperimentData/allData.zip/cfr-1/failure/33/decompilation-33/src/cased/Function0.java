/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

interface Function0<R> {
    public R apply();
}

