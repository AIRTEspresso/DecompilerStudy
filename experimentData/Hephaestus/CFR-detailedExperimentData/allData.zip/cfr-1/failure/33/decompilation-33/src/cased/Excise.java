/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Potholder;
import src.cased.Primes;

abstract class Excise
extends Primes<Double, Boolean, Boolean> {
    public final Potholder<Integer> sours;
    public boolean tureens;

    public Excise(Potholder<Integer> potholder, boolean bl) {
        super(Character.valueOf('3'));
        this.sours = potholder;
        this.tureens = bl;
    }

    public Primes<Double, Boolean, ? extends Boolean> fatal() {
        Character c = Character.valueOf('U');
        Primes primes = new Primes(c);
        return primes;
    }

    public Object horses() {
        return true;
    }
}

