/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

final class Curtsies {
    public int drainpipe;
    public Object spritzes;

    public Curtsies(int n, Object object) {
        this.drainpipe = n;
        this.spritzes = object;
    }
}

