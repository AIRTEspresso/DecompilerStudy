/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Coat;
import src.cased.Function1;
import src.cased.Pothook;

abstract class Blight
extends Coat<Float, Long, Long> {
    public Byte regency;
    public final Number hawked;

    public Blight(Byte by, Number number) {
        this.regency = by;
        this.hawked = number;
    }

    @Override
    public final Float tows(Byte ... byteArray) {
        Float f = Float.valueOf(-94.212f);
        this.regency = -87;
        return f;
    }

    @Override
    public Pothook abbess() {
        Coat coat = null;
        Function1<Double, Void> function1 = d -> {
            long l = -4L;
            Long l2 = -4L;
            return null;
        };
        Double d2 = 82.19;
        function1.apply(d2);
        return coat;
    }
}

