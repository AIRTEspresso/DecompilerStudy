/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cased;

import src.cased.Blight;
import src.cased.Curtsies;
import src.cased.Foreskin;
import src.cased.Function1;
import src.cased.Gendarmes;
import src.cased.Golfing;
import src.cased.Leafiest;
import src.cased.Normality;
import src.cased.Tahitians;

class Main {
    static boolean slue = false;
    static final double denims = -74.589;
    static final Leafiest<Float> empties = new Leafiest(slue, -74.589);
    static boolean grimness = new Leafiest<W>((boolean)true, (double)63.8).flawing;

    Main() {
    }

    public static final Byte anecdote() {
        Boolean bl = false;
        Boolean bl2 = bl != false;
        Blight blight = null;
        new Golfing(-4.2, new Gendarmes(new Foreskin<Boolean, Double>(-18.904, -24.654)).spindles()).loathed("floury");
        return bl2 != false ? blight.regency : (byte)-60;
    }

    public static final void shook(byte by, byte by2) {
        Integer n = 39;
    }

    public static final boolean approving(Integer n, Boolean bl) {
        return true;
    }

    public static final void inhuman() {
        Function1<Normality, Foreskin> function1 = normality -> {
            Double d = 49.231;
            Foreskin foreskin = new Foreskin(53.118, d);
            return foreskin;
        };
        Foreskin foreskin = function1.apply(null);
        Long l = 31L;
        Normality normality2 = null;
        Main.mongeese(l, normality2);
        Foreskin foreskin2 = foreskin;
    }

    public static final void mongeese(Long l, Tahitians tahitians) {
        boolean bl = true;
        Leafiest leafiest = new Leafiest(bl, -25.546);
    }

    public static final void main(String[] stringArray) {
        Boolean bl = true;
        Curtsies curtsies = new Curtsies(-20, new Object());
        Integer n = 54;
        Integer n2 = (int)n;
    }
}

