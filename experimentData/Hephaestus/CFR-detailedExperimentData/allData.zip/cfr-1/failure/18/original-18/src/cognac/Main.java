package src.cognac;

class Main {
  static final Integer installed = ((Rigors) null).pocked();

  static final Integer diffusely = Main.installed;

  static public final String escapes(String uncork) {
    Boolean silkiest = true;
    String quashes = ((silkiest) ?
      uncork : 
       uncork);
    final String pooches = "glorifies";
    quashes = pooches;
    return quashes;
    
  }

  static public final Long[] loitered(Guessable<? extends Character> amplifier, Long[] tweedy) {
    final Boolean secret = false;
    Boolean brogue = ((false) ?
      false : 
       secret);
    Long[] negates = tweedy;
    negates =   ((((long)5 == (long)78)) ?
  negates : 
   negates);
    return ((brogue) ?
      negates : 
       ((true) ?
        (Long[]) new Object[]{(long)2, (long)-28} : 
         (Long[]) new Object[]{(long)4}));
    
  }

  static public final <F_A extends Guessable<Character>> F_A drumming() {
    final long dualism = (long)-95;
    final Polymath<Boolean, Boolean> trodden = (Polymath<Boolean, Boolean>) null;
    long steadiest = (long)-23;
    Function0<Void> blesses = () -> {
      Rigors mincemeat = (Rigors) null;
      final Rigors cartesian = mincemeat;
      final Rigors defies = ((false) ?
        cartesian : 
         (Rigors) null);
        ((false) ?
  (Fright) null : 
   (Fright) null).powders(((Rationing<String, Short, Character>) null).grins(new Copland<Guessable<Character>, Float>(new Guessable<Character>(-20.472, 30), new Guessable<Character>(-21.552, -7))));
      Object x_2 = defies;
      return null;
    };
    blesses.apply();
    return new Trifler<F_A>(((Rationing<F_A, F_A, Character>) null).spookiest, dualism).cathartic(  ((true) ?
  new Trifler<Guessable<Character>>(trodden, steadiest) : 
   new Trifler<Guessable<Character>>((Polymath<Boolean, Boolean>) null, (long)-4))).trouped;
    
  }

  static Float infuses = (float)48.926;

  static Float vale = ((false) ?
  ((Soloist<Fright>) null).elicits : 
   Main.infuses);

  static Float tizzies = Main.vale;

  static public final Rationing<? extends Double, ? super Byte, ? extends Character> owlets(Longingly<Character> unmade) {
    Rationing<? extends Double, ? super Byte, ? extends Character> widowed = (Rationing<Double, Object, Character>) null;
    Main.karaganda();
    return widowed;
    
  }

  static public final void karaganda() {
    final Boolean wayfaring = false;
    String rastaban = "twenties";
    double laius = -91.594;
    Main.pawnshop(rastaban, laius);
    Object x_3 = ((wayfaring) ?
      true : 
       true);
    
  }

  static public final void pawnshop(String gaudily, double wager) {
    Rigors arrowroot = (Rigors) null;
    final Rigors ono = arrowroot;
    Rigors exclaims = ((false) ?
      ono : 
       arrowroot);
    Main.curative(exclaims);
    new Continual<Boolean, Short>((Scourge) null).sorority.torturers( 'Y', null);
    
  }

  static public final void curative(Rigors jonahs) {
    Rationing<Fright, Long, Character> expanding = Main.maryanne();
    expanding.grins((Fright) null);
    
  }

  static public final Rationing<Fright, Long, Character> maryanne() {
    final Rationing<Fright, Long, Character> beheld = (Rationing<Fright, Long, Character>) null;
    return beheld;
    
  }

  static public final void main(String[] args) {
    final int woofed = Main.installed;
    Object x_6 = woofed;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Rigors {
  public Integer pocked() {
    final long dobbin = (long)-63;
    final Longingly<Character> fisher = new Longingly<Character>((Polymath<Boolean, Boolean>) null, dobbin);
    final Polymath<Boolean, Boolean> reviler = fisher.spookiest;
    new Bossiest(fisher.karachi).pilings(new Guessable<Boolean>(-8.857, -3).fiercely);
    return reviler.phenotype;
    
  }
}

abstract class Polymath<S extends Boolean, L extends Boolean> {
  public final Integer phenotype;
  public final int someones;

  public Polymath(Integer phenotype,int someones) {
    this.phenotype = phenotype;
    this.someones = someones;
  }
}

class Longingly<U extends Character> extends Polymath<Boolean, Boolean> {
  public Polymath<Boolean, Boolean> spookiest;
  public long karachi;

  public Longingly(Polymath<Boolean, Boolean> spookiest,long karachi) {
    super(-43, -39);
    this.spookiest = spookiest;
    this.karachi = karachi;
  }
}

class Bossiest extends Longingly<Character> {
  public long karachi;

  public Bossiest(long karachi) {
    super(new Longingly<Character>((Polymath<Boolean, Boolean>) null, (long)-43), (long)-99);
    this.karachi = karachi;
  }

  public final void pilings(double jumpiness) {
    Long[] successor = new Long[0];
    Function0<Void> trophy = () -> {
      final Double chapters = (Double) null;
      final Double oarlock = chapters;
      final Bossiest offer = (Bossiest) null;
      offer.karachi = (long)54;
      Object x_0 = (Double[]) new Object[]{oarlock};
      return null;
    };
    trophy.apply();
    Object x_1 = successor;
    
  }
}

class Guessable<M> extends Polymath<Boolean, Boolean> {
  public double fiercely;
  public final Integer phenotype;

  public Guessable(double fiercely,Integer phenotype) {
    super(-9, 3);
    this.fiercely = fiercely;
    this.phenotype = phenotype;
  }
}

interface Definite {}

final class Copland<M extends Guessable<Character>, Y> implements Definite {
  public M trouped;
  public M sinker;

  public Copland(M trouped,M sinker) {
    super();
    this.trouped = trouped;
    this.sinker = sinker;
  }

  public final Y bassists(Y mired) {
    Y eatery = mired;
    Y slobbered = ((true) ?
      (Y) null : 
       eatery);
    return slobbered;
    
  }

  public final Y wonders(double salamis, M zappers) {
    return ((Rationing<Y, Byte, Character>) null).disallow;
  }
}

abstract class Rationing<W, B, E extends Character> extends Longingly<Character> {
  public W disallow;
  public long karachi;

  public Rationing(W disallow,long karachi) {
    super(new Guessable<Bossiest>(41.620, 52), (long)74);
    this.disallow = disallow;
    this.karachi = karachi;
  }

  public Long grins(Definite utrecht) {
    Long oreo = (long)-72;
    return oreo;
    
  }

  public E towheads(E inaudibly) {
    return (E) null;
  }
}

class Trifler<I extends Guessable<Character>> extends Longingly<Character> {
  public Polymath<Boolean, Boolean> spookiest;
  public long karachi;

  public Trifler(Polymath<Boolean, Boolean> spookiest,long karachi) {
    super(new Bossiest((long)6), (long)71);
    this.spookiest = spookiest;
    this.karachi = karachi;
  }

  public Copland<I, ? extends Rigors> cathartic(Trifler<Guessable<Character>> surgeon) {
    final Boolean chang = true;
    final I meridians = (I) null;
    final Copland<I, ? extends Rigors> staunches = new Copland<I, Rigors>((I) null, meridians);
    return ((chang) ?
      new Copland<I, Rigors>((I) null, (I) null) : 
       staunches);
    
  }
}

interface Fright extends Definite {
  public abstract void powders(Long babylon) ;
}

abstract class Soloist<S extends Fright> extends Trifler<Guessable<Character>> {
  public Float elicits;
  public long karachi;
  public Polymath<Boolean, Boolean> spookiest;

  public Soloist(Float elicits,long karachi,Polymath<Boolean, Boolean> spookiest) {
    super(new Guessable<Float>(49.927, -81), (long)71);
    this.elicits = elicits;
    this.karachi = karachi;
    this.spookiest = spookiest;
  }

  public abstract int rummy() ;
}

interface Scourge extends Definite {
  public abstract Copland<Guessable<Character>, ? super Integer> torturers(Character sweatiest, Longingly<? super Character> transfix) ;
}

class Continual<O, C> implements Scourge {
  public Scourge sorority;

  public Continual(Scourge sorority) {
    super();
    this.sorority = sorority;
  }

  public Copland<Guessable<Character>, ? super Integer> torturers(Character sweatiest, Longingly<? super Character> transfix) {
    final Integer urns = -91;
    final double loyang = -54.385;
    Copland<Guessable<Character>, Object> sutures = new Copland<Guessable<Character>, Object>(new Guessable<Character>(-14.759, urns), new Guessable<Character>(loyang, -71));
    return sutures;
    
  }
}

abstract class Domestic<H extends Boolean, E extends Integer, Z extends H> extends Rigors {
  public Domestic() {
    super();
}

  public final Integer pocked() {
    return Main.maryanne().phenotype;
  }

  public E neogene(E novel, H cardigan) {
    final E antiqued = (E) null;
    final Integer bobsled = Main.diffusely;
    Function2<Double, H, Updated<? super Fright>> ferreting = (ionesco, encored) -> {
      int sesames = -77;
      Updated<? super Fright> guileless = new Updated<Fright>(93, sesames);
      Function1<E, Void> formica = (tatar) -> {
        final long hated = (long)-60;
        Trifler<Guessable<Character>> bennett = new Trifler<Guessable<Character>>((Polymath<Boolean, Boolean>) null, hated);
        bennett.karachi = (long)58;
        Object x_4 = new Bossiest((long)94);
        return null;
      };
      E fancying = (E) null;
      formica.apply(fancying);
      return guileless;
      
    };
    Z snitching = (Z) null;
    new Updated<Fright>(bobsled, ferreting.apply(-20.431, snitching).someones).tills(  ((true) ?
  new Object() : 
   new Object()), new Trifler<Guessable<Character>>((Polymath<Boolean, Boolean>) null, (long)-64));
    return antiqued;
    
  }
}

class Updated<A extends Fright> extends Polymath<Boolean, Boolean> {
  public final Integer phenotype;
  public final int someones;

  public Updated(Integer phenotype,int someones) {
    super(-35, -16);
    this.phenotype = phenotype;
    this.someones = someones;
  }

  public final void tills(Object finis, Trifler<Guessable<Character>> mouthwash) {
    final Shadow<Float> formalize = (Shadow<Float>) null;
    final Boolean displays = true;
    formalize.cubs(displays).mope();
    Object x_5 = (A) null;
    
  }
}

abstract class Leafiest extends Bossiest {
  public Leafiest() {
    super((long)-63);
}

  public abstract void mope() ;
}

abstract class Shadow<K extends Float> extends Rigors {
  public final K vest;
  public final Short wok;

  public Shadow(K vest,Short wok) {
    super();
    this.vest = vest;
    this.wok = wok;
  }

  public Leafiest cubs(Boolean cabbie) {
    final Leafiest loamiest = (Leafiest) null;
    return loamiest;
    
  }
}