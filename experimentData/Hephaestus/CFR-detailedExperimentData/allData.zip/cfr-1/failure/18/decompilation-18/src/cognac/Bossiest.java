/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Function0;
import src.cognac.Longingly;
import src.cognac.Polymath;

class Bossiest
extends Longingly<Character> {
    public long karachi;

    public Bossiest(long l) {
        super(new Longingly((Polymath<Boolean, Boolean>)null, -43L), -99L);
        this.karachi = l;
    }

    public final void pilings(double d) {
        Long[] longArray = new Long[]{};
        Function0<Void> function0 = () -> {
            Double d;
            Double d2 = d = (Double)null;
            Bossiest bossiest = null;
            bossiest.karachi = 54L;
            Double[] doubleArray = (Double[])new Object[]{d2};
            return null;
        };
        function0.apply();
        Long[] longArray2 = longArray;
    }
}

