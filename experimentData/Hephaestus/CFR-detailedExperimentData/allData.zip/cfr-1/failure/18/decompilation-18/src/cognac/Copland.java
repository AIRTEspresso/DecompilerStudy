/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Definite;
import src.cognac.Guessable;
import src.cognac.Rationing;

final class Copland<M extends Guessable<Character>, Y>
implements Definite {
    public M trouped;
    public M sinker;

    public Copland(M m, M m2) {
        this.trouped = m;
        this.sinker = m2;
    }

    public final Y bassists(Y y) {
        Y y2 = y;
        Y y3 = null;
        return y3;
    }

    public final Y wonders(double d, M m) {
        return (Y)((Rationing)null).disallow;
    }
}

