/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Fright;
import src.cognac.Guessable;
import src.cognac.Polymath;
import src.cognac.Trifler;

abstract class Soloist<S extends Fright>
extends Trifler<Guessable<Character>> {
    public Float elicits;
    public long karachi;
    public Polymath<Boolean, Boolean> spookiest;

    public Soloist(Float f, long l, Polymath<Boolean, Boolean> polymath) {
        super(new Guessable(49.927, (Integer)-81), 71L);
        this.elicits = f;
        this.karachi = l;
        this.spookiest = polymath;
    }

    public abstract int rummy();
}

