/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

abstract class Polymath<S extends Boolean, L extends Boolean> {
    public final Integer phenotype;
    public final int someones;

    public Polymath(Integer n, int n2) {
        this.phenotype = n;
        this.someones = n2;
    }
}

