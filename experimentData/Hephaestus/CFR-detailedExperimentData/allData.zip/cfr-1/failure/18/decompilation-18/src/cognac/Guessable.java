/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Polymath;

class Guessable<M>
extends Polymath<Boolean, Boolean> {
    public double fiercely;
    public final Integer phenotype;

    public Guessable(double d, Integer n) {
        super(-9, 3);
        this.fiercely = d;
        this.phenotype = n;
    }
}

