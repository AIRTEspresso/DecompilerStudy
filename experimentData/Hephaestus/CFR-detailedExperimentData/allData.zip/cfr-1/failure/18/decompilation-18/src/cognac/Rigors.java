/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Bossiest;
import src.cognac.Guessable;
import src.cognac.Longingly;
import src.cognac.Polymath;

abstract class Rigors {
    Rigors() {
    }

    public Integer pocked() {
        Longingly longingly = new Longingly((Polymath<Boolean, Boolean>)null, -63L);
        Polymath<Boolean, Boolean> polymath = longingly.spookiest;
        new Bossiest(longingly.karachi).pilings(new Guessable<M>((double)-8.857, (Integer)Integer.valueOf((int)-3)).fiercely);
        return polymath.phenotype;
    }
}

