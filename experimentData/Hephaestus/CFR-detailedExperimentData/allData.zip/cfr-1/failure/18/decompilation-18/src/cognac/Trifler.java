/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Bossiest;
import src.cognac.Copland;
import src.cognac.Guessable;
import src.cognac.Longingly;
import src.cognac.Polymath;
import src.cognac.Rigors;

class Trifler<I extends Guessable<Character>>
extends Longingly<Character> {
    public Polymath<Boolean, Boolean> spookiest;
    public long karachi;

    public Trifler(Polymath<Boolean, Boolean> polymath, long l) {
        super(new Bossiest(6L), 71L);
        this.spookiest = polymath;
        this.karachi = l;
    }

    public Copland<I, ? extends Rigors> cathartic(Trifler<Guessable<Character>> trifler) {
        Boolean bl = true;
        Guessable guessable = null;
        Copland copland = new Copland(null, guessable);
        return bl != false ? new Copland(null, null) : copland;
    }
}

