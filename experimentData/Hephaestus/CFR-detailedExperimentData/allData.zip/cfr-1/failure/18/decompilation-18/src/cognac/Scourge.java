/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Copland;
import src.cognac.Definite;
import src.cognac.Guessable;
import src.cognac.Longingly;

interface Scourge
extends Definite {
    public Copland<Guessable<Character>, ? super Integer> torturers(Character var1, Longingly<? super Character> var2);
}

