/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Bossiest;
import src.cognac.Function1;
import src.cognac.Function2;
import src.cognac.Guessable;
import src.cognac.Main;
import src.cognac.Polymath;
import src.cognac.Rigors;
import src.cognac.Trifler;
import src.cognac.Updated;

abstract class Domestic<H extends Boolean, E extends Integer, Z extends H>
extends Rigors {
    @Override
    public final Integer pocked() {
        return Main.maryanne().phenotype;
    }

    public E neogene(E e, H h) {
        Integer n = null;
        Integer n2 = Main.diffusely;
        Function2<Double, Boolean, Updated> function2 = (d, bl) -> {
            int n2 = -77;
            Updated updated = new Updated(93, n2);
            Function1<Integer, Void> function1 = n -> {
                long l = -60L;
                Trifler trifler = new Trifler((Polymath<Boolean, Boolean>)null, -60L);
                trifler.karachi = 58L;
                Bossiest bossiest = new Bossiest(94L);
                return null;
            };
            Integer n3 = null;
            function1.apply(n3);
            return updated;
        };
        Boolean bl2 = null;
        new Updated(n2, function2.apply((Double)Double.valueOf((double)-20.431), (Boolean)bl2).someones).tills(new Object(), new Trifler<Guessable<Character>>((Polymath<Boolean, Boolean>)null, -64L));
        return (E)n;
    }
}

