/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Continual;
import src.cognac.Copland;
import src.cognac.Fright;
import src.cognac.Function0;
import src.cognac.Guessable;
import src.cognac.Longingly;
import src.cognac.Polymath;
import src.cognac.Rationing;
import src.cognac.Rigors;
import src.cognac.Scourge;
import src.cognac.Trifler;

class Main {
    static final Integer installed;
    static final Integer diffusely;
    static Float infuses;
    static Float vale;
    static Float tizzies;

    Main() {
    }

    public static final String escapes(String string) {
        Boolean bl = true;
        String string2 = bl != false ? string : string;
        string2 = "glorifies";
        return string2;
    }

    public static final Long[] loitered(Guessable<? extends Character> guessable, Long[] longArray) {
        Boolean bl = false;
        Boolean bl2 = (boolean)bl;
        Long[] longArray2 = longArray;
        return bl2 != false ? longArray2 : (Long[])new Object[]{2L, -28L};
    }

    public static final <F_A extends Guessable<Character>> F_A drumming() {
        Polymath polymath = null;
        long l = -23L;
        Function0<Void> function0 = () -> {
            Rigors rigors;
            Rigors rigors2 = rigors = (Rigors)null;
            Rigors rigors3 = null;
            ((Fright)null).powders(((Rationing)null).grins(new Copland(new Guessable(-20.472, (Integer)30), new Guessable(-21.552, (Integer)-7))));
            Rigors rigors4 = rigors3;
            return null;
        };
        function0.apply();
        return (F_A)new Trifler<I>((Polymath<Boolean, Boolean>)((Rationing)null).spookiest, (long)-95L).cathartic(new Trifler<Guessable<Character>>((Polymath<Boolean, Boolean>)polymath, (long)l)).trouped;
    }

    public static final Rationing<? extends Double, ? super Byte, ? extends Character> owlets(Longingly<Character> longingly) {
        Rationing rationing = null;
        Main.karaganda();
        return rationing;
    }

    public static final void karaganda() {
        Boolean bl = false;
        String string = "twenties";
        double d = -91.594;
        Main.pawnshop(string, d);
        Boolean bl2 = bl != false ? true : true;
    }

    public static final void pawnshop(String string, double d) {
        Rigors rigors;
        Rigors rigors2 = rigors = (Rigors)null;
        Rigors rigors3 = rigors;
        Main.curative(rigors3);
        new Continual<O, C>((Scourge)((Scourge)null)).sorority.torturers(Character.valueOf('Y'), null);
    }

    public static final void curative(Rigors rigors) {
        Rationing<Fright, Long, Character> rationing = Main.maryanne();
        rationing.grins(null);
    }

    public static final Rationing<Fright, Long, Character> maryanne() {
        Rationing rationing = null;
        return rationing;
    }

    public static final void main(String[] stringArray) {
        int n = installed;
        Integer n2 = n;
    }

    static {
        diffusely = installed = ((Rigors)null).pocked();
        tizzies = vale = (infuses = Float.valueOf(48.926f));
    }
}

