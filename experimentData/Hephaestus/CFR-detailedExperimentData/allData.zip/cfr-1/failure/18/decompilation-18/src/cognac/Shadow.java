/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Leafiest;
import src.cognac.Rigors;

abstract class Shadow<K extends Float>
extends Rigors {
    public final K vest;
    public final Short wok;

    public Shadow(K k, Short s) {
        this.vest = k;
        this.wok = s;
    }

    public Leafiest cubs(Boolean bl) {
        Leafiest leafiest = null;
        return leafiest;
    }
}

