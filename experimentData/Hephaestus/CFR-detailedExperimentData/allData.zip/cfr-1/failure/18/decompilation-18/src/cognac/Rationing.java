/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Definite;
import src.cognac.Guessable;
import src.cognac.Longingly;

abstract class Rationing<W, B, E extends Character>
extends Longingly<Character> {
    public W disallow;
    public long karachi;

    public Rationing(W w, long l) {
        super(new Guessable(41.62, (Integer)52), 74L);
        this.disallow = w;
        this.karachi = l;
    }

    public Long grins(Definite definite) {
        Long l = -72L;
        return l;
    }

    public E towheads(E e) {
        return (E)((Character)null);
    }
}

