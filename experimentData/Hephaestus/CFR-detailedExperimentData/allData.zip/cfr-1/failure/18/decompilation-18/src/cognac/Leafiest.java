/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Bossiest;

abstract class Leafiest
extends Bossiest {
    public Leafiest() {
        super(-63L);
    }

    public abstract void mope();
}

