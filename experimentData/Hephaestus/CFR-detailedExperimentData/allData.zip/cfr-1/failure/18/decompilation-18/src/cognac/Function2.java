/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

interface Function2<A1, A2, R> {
    public R apply(A1 var1, A2 var2);
}

