/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Copland;
import src.cognac.Guessable;
import src.cognac.Longingly;
import src.cognac.Scourge;

class Continual<O, C>
implements Scourge {
    public Scourge sorority;

    public Continual(Scourge scourge) {
        this.sorority = scourge;
    }

    @Override
    public Copland<Guessable<Character>, ? super Integer> torturers(Character c, Longingly<? super Character> longingly) {
        Integer n = -91;
        Copland copland = new Copland(new Guessable(-14.759, n), new Guessable(-54.385, (Integer)-71));
        return copland;
    }
}

