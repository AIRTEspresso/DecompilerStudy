/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Polymath;

class Longingly<U extends Character>
extends Polymath<Boolean, Boolean> {
    public Polymath<Boolean, Boolean> spookiest;
    public long karachi;

    public Longingly(Polymath<Boolean, Boolean> polymath, long l) {
        super(-43, -39);
        this.spookiest = polymath;
        this.karachi = l;
    }
}

