/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.cognac;

import src.cognac.Fright;
import src.cognac.Guessable;
import src.cognac.Polymath;
import src.cognac.Shadow;
import src.cognac.Trifler;

class Updated<A extends Fright>
extends Polymath<Boolean, Boolean> {
    public final Integer phenotype;
    public final int someones;

    public Updated(Integer n, int n2) {
        super(-35, -16);
        this.phenotype = n;
        this.someones = n2;
    }

    public final void tills(Object object, Trifler<Guessable<Character>> trifler) {
        Shadow shadow = null;
        Boolean bl = true;
        shadow.cubs(bl).mope();
        Fright fright = null;
    }
}

