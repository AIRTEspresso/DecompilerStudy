package src.vising;

class Main {
  static public final void profit() {
    final short echelon = (short)97;
    short adriana = echelon;
    Function0<Infesting> tubing = () -> {
      Boolean workday = true;
      final Archenemy coon = new Archenemy((float)-95.128);
      return new Infesting(workday, coon);
      
    };
    final Infesting marty = tubing.apply();
    marty.terminus(false);
    Object x_2 = adriana;
    
  }

  static public final Boolean whimseys(Character regency, Boolean riggs) {
    Boolean banjul = true;
    final Boolean followed = true;
    final Boolean rupees = true;
    return ((banjul) ?
      ((followed) ?
        rupees : 
         true) : 
       (true || false));
    
  }

  static final Long snowmen = (long)13;

  static Boolean huck = ((long)-19 == Main.snowmen);

  static final Boolean sequin = false;

  static Boolean shifts = ((Main.huck) ?
  true : 
   Main.whimseys( 'v', Main.sequin));

  static final Bronzes<? super Hologram<Boolean, Integer>, ? extends Integer> police = ((((true) ?
    false : 
     false)) ?
  ((Places) null).sheba : 
   ((true) ?
    (Bronzes<Hologram<Boolean, Integer>, Integer>) null : 
     (Bronzes<Hologram<Boolean, Integer>, Integer>) null));

  static public final void main(String[] args) {
    final Archenemy needles = new Archenemy((float)-11.998);
    Object x_5 = needles;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Reduce<Z extends Integer, Q> {
  public char linkups;

  public Reduce(char linkups) {
    this.linkups = linkups;
  }

  public final <F_F extends Z> double poltroons(F_F maynard, F_F louder) {
    double nantucket = -53.8;
    return nantucket;
    
  }

  public Float dunkirk(Character scaliest, Character pairwise) {
    Float aztecan = (float)-35.398;
    final Float furred = (float)85.312;
    Boolean towels = true;
    Main.profit();
      return ((true) ?
  new Hologram<Boolean, Object>(new Archenemy(aztecan), true) : 
   new Hologram<Boolean, Object>(new Archenemy(furred), towels)).gargoyle.impugned;
    
  }
}

final class Archenemy {
  public final Float impugned;

  public Archenemy(Float impugned) {
    this.impugned = impugned;
  }

  public final Integer bantering() {
    return -96;
  }

  public final Float prowls(Float overgrown, Double... abrams) {
    Float tactile = (float)-0.609;
    final Guarnieri colanders = (Guarnieri) null;
    byte caboodle = (byte)43;
    colanders.bluster(caboodle, -45.858);
    return tactile;
    
  }
}

abstract class Guarnieri {
  public <F_R> void bluster(byte frailty, F_R increases) {
    final F_R recurring = (F_R) null;
    Reduce<Integer, ? super Guarnieri> syringe = (Reduce<Integer, Guarnieri>) null;
    char displays = 'N';
    syringe.linkups = displays;
    Object x_0 = recurring;
    
  }

  public abstract Double[] calks(String hypnotic) ;
}

final class Hologram<O extends Boolean, B extends Object> extends Guarnieri {
  public final Archenemy gargoyle;
  public O eel;

  public Hologram(Archenemy gargoyle,O eel) {
    super();
    this.gargoyle = gargoyle;
    this.eel = eel;
  }

  public Double[] calks(String hypnotic) {
    Double liquidity = (Double) null;
    final Double excision = liquidity;
    final Double gerald = (Double) null;
    return (Double[]) new Object[]{excision, (Double) null, gerald};
    
  }

  public final <F_R> void bluster(byte frailty, F_R increases) {
    final O psst = (O) null;
    final O madrassa = psst;
    Object x_1 = madrassa;
    
  }
}

class Infesting extends Guarnieri {
  public final Boolean quandary;
  public final Archenemy sukarno;

  public Infesting(Boolean quandary,Archenemy sukarno) {
    super();
    this.quandary = quandary;
    this.sukarno = sukarno;
  }

  public final void terminus(boolean ferocity) {
    final byte washstand = (byte)-19;
    Object x_3 = washstand;
    
  }

  public Double[] calks(String hypnotic) {
    final Double[] exciting = (Double[]) new Object[]{(Double) null, (Double) null};
    Float lurching = (float)12.156;
    final Boolean rationed = true;
    new Hologram<Boolean, Byte>(new Archenemy(lurching), rationed).eel = null;
    return exciting;
    
  }
}

interface Consumed<N, Q> {
  public abstract String dills(Q pronounce, Q mistakes) ;
}

abstract class Bronzes<N extends Hologram<? super Boolean, ? super Integer>, Z> extends Guarnieri {
  public final Z sunset;

  public Bronzes(Z sunset) {
    super();
    this.sunset = sunset;
  }

  public Double[] calks(String hypnotic) {
    final Grade strumpets = new Grade((Consumed<Long, Integer>) null);
    Stirred myrrh = new Stirred(strumpets, -13);
    final Stirred loins = myrrh;
    return calks(loins.docket.incarnate.dills(null, null));
    
  }
}

class Grade implements Consumed<String, Short> {
  public final Consumed<? extends Long, ? extends Integer> incarnate;

  public Grade(Consumed<? extends Long, ? extends Integer> incarnate) {
    super();
    this.incarnate = incarnate;
  }

  public String dills(Short pronounce, Short mistakes) {
    return "faint";
  }
}

final class Stirred extends Grade {
  public Grade docket;
  public final Integer fixation;

  public Stirred(Grade docket,Integer fixation) {
    super((Consumed<Long, Integer>) null);
    this.docket = docket;
    this.fixation = fixation;
  }

  public final String dills(Short pronounce, Short mistakes) {
    final String apprises = "deputy";
    return apprises;
    
  }
}

abstract class Places extends Infesting {
  public Bronzes<? super Hologram<Boolean, Integer>, Integer> sheba;
  public final Boolean quandary;

  public Places(Bronzes<? super Hologram<Boolean, Integer>, Integer> sheba,Boolean quandary) {
    super(false, new Archenemy((float)-58.288));
    this.sheba = sheba;
    this.quandary = quandary;
  }

  public final Double[] calks(String hypnotic) {
    Double[] fictional = new Double[0];
    return fictional;
    
  }
}

final class Lonelier extends Guarnieri {
  public Lonelier() {
    super();
}

  public Double[] calks(String hypnotic) {
    Double[] spawns = Main.police.calks("gasses");
    return spawns;
    
  }

  public final <F_R> void bluster(byte frailty, F_R increases) {
    final F_R hohhot = increases;
    final F_R sweetie = ((false) ?
      (F_R) null : 
       hohhot);
    Object x_4 = sweetie;
    
  }
}