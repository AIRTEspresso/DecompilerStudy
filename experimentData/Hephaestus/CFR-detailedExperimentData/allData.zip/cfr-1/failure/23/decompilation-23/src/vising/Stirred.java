/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Grade;

final class Stirred
extends Grade {
    public Grade docket;
    public final Integer fixation;

    public Stirred(Grade grade, Integer n) {
        super(null);
        this.docket = grade;
        this.fixation = n;
    }

    @Override
    public final String dills(Short s, Short s2) {
        return "deputy";
    }
}

