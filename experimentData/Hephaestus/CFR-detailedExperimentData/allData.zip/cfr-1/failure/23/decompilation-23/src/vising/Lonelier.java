/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Guarnieri;
import src.vising.Main;

final class Lonelier
extends Guarnieri {
    @Override
    public Double[] calks(String string) {
        Double[] doubleArray = Main.police.calks("gasses");
        return doubleArray;
    }

    @Override
    public final <F_R> void bluster(byte by, F_R F_R) {
        F_R F_R2;
        F_R F_R3;
        F_R F_R4 = F_R3 = (F_R2 = F_R);
    }
}

