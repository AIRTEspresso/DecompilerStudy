/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Archenemy;
import src.vising.Guarnieri;

final class Hologram<O extends Boolean, B>
extends Guarnieri {
    public final Archenemy gargoyle;
    public O eel;

    public Hologram(Archenemy archenemy, O o) {
        this.gargoyle = archenemy;
        this.eel = o;
    }

    @Override
    public Double[] calks(String string) {
        Double d;
        Double d2 = d = (Double)null;
        Double d3 = null;
        return (Double[])new Object[]{d2, null, d3};
    }

    @Override
    public final <F_R> void bluster(byte by, F_R F_R) {
        Boolean bl;
        Boolean bl2;
        Boolean bl3 = bl2 = (bl = (Boolean)null);
    }
}

