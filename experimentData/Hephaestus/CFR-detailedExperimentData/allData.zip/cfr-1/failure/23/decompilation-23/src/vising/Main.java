/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Archenemy;
import src.vising.Bronzes;
import src.vising.Function0;
import src.vising.Hologram;
import src.vising.Infesting;

class Main {
    static final Long snowmen = 13L;
    static Boolean huck = -19L == snowmen;
    static final Boolean sequin = false;
    static Boolean shifts = huck != false ? true : Main.whimseys(Character.valueOf('v'), sequin);
    static final Bronzes<? super Hologram<Boolean, Integer>, ? extends Integer> police = null;

    Main() {
    }

    public static final void profit() {
        short s = 97;
        Function0<Infesting> function0 = () -> {
            Boolean bl = true;
            Archenemy archenemy = new Archenemy(Float.valueOf(-95.128f));
            return new Infesting(bl, archenemy);
        };
        Infesting infesting = function0.apply();
        infesting.terminus(false);
        Short s2 = s;
    }

    public static final Boolean whimseys(Character c, Boolean bl) {
        Boolean bl2 = true;
        Boolean bl3 = true;
        Boolean bl4 = true;
        return bl2.booleanValue() ? (bl3.booleanValue() ? bl4 : true) : true;
    }

    public static final void main(String[] stringArray) {
        Archenemy archenemy;
        Archenemy archenemy2 = archenemy = new Archenemy(Float.valueOf(-11.998f));
    }
}

