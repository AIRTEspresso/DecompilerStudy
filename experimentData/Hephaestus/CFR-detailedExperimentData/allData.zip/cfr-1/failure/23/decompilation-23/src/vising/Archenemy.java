/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Guarnieri;

final class Archenemy {
    public final Float impugned;

    public Archenemy(Float f) {
        this.impugned = f;
    }

    public final Integer bantering() {
        return -96;
    }

    public final Float prowls(Float f, Double ... doubleArray) {
        Float f2 = Float.valueOf(-0.609f);
        Guarnieri guarnieri = null;
        byte by = 43;
        guarnieri.bluster(by, -45.858);
        return f2;
    }
}

