/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Archenemy;
import src.vising.Hologram;
import src.vising.Main;

class Reduce<Z extends Integer, Q> {
    public char linkups;

    public Reduce(char c) {
        this.linkups = c;
    }

    public final <F_F extends Z> double poltroons(F_F F_F, F_F F_F2) {
        double d = -53.8;
        return d;
    }

    public Float dunkirk(Character c, Character c2) {
        Float f = Float.valueOf(-35.398f);
        Float f2 = Float.valueOf(85.312f);
        Boolean bl = true;
        Main.profit();
        return new Hologram<Boolean, B>((Archenemy)new Archenemy((Float)f), Boolean.valueOf((boolean)true)).gargoyle.impugned;
    }
}

