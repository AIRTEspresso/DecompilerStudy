/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Consumed;

class Grade
implements Consumed<String, Short> {
    public final Consumed<? extends Long, ? extends Integer> incarnate;

    public Grade(Consumed<? extends Long, ? extends Integer> consumed) {
        this.incarnate = consumed;
    }

    @Override
    public String dills(Short s, Short s2) {
        return "faint";
    }
}

