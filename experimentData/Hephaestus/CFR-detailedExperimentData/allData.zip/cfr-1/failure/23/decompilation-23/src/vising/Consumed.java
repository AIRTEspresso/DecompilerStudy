/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

interface Consumed<N, Q> {
    public String dills(Q var1, Q var2);
}

