/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Archenemy;
import src.vising.Guarnieri;
import src.vising.Hologram;

class Infesting
extends Guarnieri {
    public final Boolean quandary;
    public final Archenemy sukarno;

    public Infesting(Boolean bl, Archenemy archenemy) {
        this.quandary = bl;
        this.sukarno = archenemy;
    }

    public final void terminus(boolean bl) {
        Byte by = -19;
    }

    @Override
    public Double[] calks(String string) {
        Double[] doubleArray = (Double[])new Object[]{null, null};
        Float f = Float.valueOf(12.156f);
        Boolean bl = true;
        new Hologram<Boolean, B>((Archenemy)new Archenemy((Float)f), bl).eel = null;
        return doubleArray;
    }
}

