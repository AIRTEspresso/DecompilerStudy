/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Grade;
import src.vising.Guarnieri;
import src.vising.Hologram;
import src.vising.Stirred;

abstract class Bronzes<N extends Hologram<? super Boolean, ? super Integer>, Z>
extends Guarnieri {
    public final Z sunset;

    public Bronzes(Z z) {
        this.sunset = z;
    }

    @Override
    public Double[] calks(String string) {
        Stirred stirred;
        Grade grade = new Grade(null);
        Stirred stirred2 = stirred = new Stirred(grade, -13);
        return this.calks(stirred2.docket.incarnate.dills(null, null));
    }
}

