/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Reduce;

abstract class Guarnieri {
    Guarnieri() {
    }

    public <F_R> void bluster(byte by, F_R F_R) {
        Object var3_3 = null;
        Reduce reduce = null;
        int n = 78;
        reduce.linkups = (char)n;
        Object var6_6 = var3_3;
    }

    public abstract Double[] calks(String var1);
}

