/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.vising;

import src.vising.Archenemy;
import src.vising.Bronzes;
import src.vising.Hologram;
import src.vising.Infesting;

abstract class Places
extends Infesting {
    public Bronzes<? super Hologram<Boolean, Integer>, Integer> sheba;
    public final Boolean quandary;

    public Places(Bronzes<? super Hologram<Boolean, Integer>, Integer> bronzes, Boolean bl) {
        super(false, new Archenemy(Float.valueOf(-58.288f)));
        this.sheba = bronzes;
        this.quandary = bl;
    }

    @Override
    public final Double[] calks(String string) {
        Double[] doubleArray = new Double[]{};
        return doubleArray;
    }
}

