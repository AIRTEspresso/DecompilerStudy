/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Messiest;
import src.tangerine.Pisces;
import src.tangerine.Victual;

final class Goober
extends Pisces {
    public final Victual<String, String, Byte> bludgeons;

    public Goober(Victual<String, String, Byte> victual) {
        super(new Messiest<Float, Float, String>(-21.251, Float.valueOf(-44.941f)));
        this.bludgeons = victual;
    }

    @Override
    public final Float retire(Victual<Float, Float, ? super Float> victual) {
        return Float.valueOf(42.979f);
    }
}

