/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Victual;

class Decidedly<F extends Float, C extends F> {
    public final Double fomalhaut;

    public Decidedly(Double d) {
        this.fomalhaut = d;
    }

    public C retire(Victual<F, F, ? super F> victual) {
        return (C)((Float)null);
    }

    public final C thwacks(F f, C c) {
        Float f2 = null;
        return (C)f2;
    }
}

