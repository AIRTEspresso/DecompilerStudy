/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Decidedly;
import src.tangerine.Victual;

final class Messiest<A extends Float, B extends A, Y extends String>
extends Decidedly<A, A> {
    public final Double fomalhaut;
    public B mulattos;

    public Messiest(Double d, B b) {
        super(-78.874);
        this.fomalhaut = d;
        this.mulattos = b;
    }

    public final void viaducts(Double d) {
        String string;
        String string2 = string = (String)null;
    }

    @Override
    public final A retire(Victual<A, A, ? super A> victual) {
        return (A)this.mulattos;
    }
}

