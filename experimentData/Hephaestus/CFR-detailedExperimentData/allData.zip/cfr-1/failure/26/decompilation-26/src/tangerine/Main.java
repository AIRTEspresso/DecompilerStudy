/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Apostate;
import src.tangerine.Decidedly;
import src.tangerine.Function2;
import src.tangerine.Goober;
import src.tangerine.Homewards;
import src.tangerine.Messiest;
import src.tangerine.Recline;
import src.tangerine.Victual;
import src.tangerine.Vinegary;

class Main {
    static final Float longingly = Float.valueOf(-44.651f);
    static final Goober robt = new Goober(new Victual<String, String, Byte>());
    static final Victual<String, String, Byte> unhinged = Main.robt.bludgeons;
    static final Double starts = (longingly.floatValue() == -69.762f ? new Victual() : unhinged).crummy(unhinged.crummy(unhinged.crummy(-89.373)));
    static boolean oxidize = false;
    static final Victual<? super Character, Character, ? extends Number> straitens = new Messiest(40.823, Float.valueOf(82.838f)) == new Messiest(-50.929, Float.valueOf(53.253f)) ? Main.artichoke('A', false) : new Victual();
    static Homewards chekhov = new Recline<Boolean>(new Vinegary<Z, Boolean>(new Messiest<A, Float, Y>((Double)Double.valueOf((double)97.509), Float.valueOf((float)-6.237f)), Boolean.valueOf((boolean)false)).eggshell != new Messiest(-15.638, Float.valueOf(-33.775f)), (float)Main.lamented(94).converges().byteValue() <= 90.109f);

    Main() {
    }

    public static final int nay(Number number, int n2) {
        Byte by = 37;
        Boolean bl = by <= 17;
        Function2<Float, Integer, Void> function2 = (f, n) -> {
            Victual victual = new Victual();
            Double d = -48.867;
            Double d2 = victual.crummy((double)d);
            new Messiest<A, Float, Y>((Double)Double.valueOf((double)-95.123), Float.valueOf((float)-51.473f)).mulattos = null;
            Double d3 = d2;
            return null;
        };
        function2.apply(Float.valueOf(-10.9f), -65);
        return bl != false ? -30 : -30;
    }

    public static final Object likelier(Object object) {
        return new Object();
    }

    public static final Integer polo(Decidedly<? extends Float, ? extends Float> decidedly, int n) {
        Homewards homewards = null;
        Boolean bl = homewards.dismissed;
        Integer n2 = -65;
        return bl != false ? n2 : 0;
    }

    public static final void delayed() {
        oxidize = false;
        String string = "turgenev";
    }

    public static final Victual<Character, Character, Double> artichoke(char c, Boolean bl) {
        return new Victual<Character, Character, Double>();
    }

    public static final Long appalling(long l, int n) {
        return 83L;
    }

    public static final Apostate<Float, Float, Goober> lamented(int n) {
        Integer n2 = 50;
        Apostate<Float, Float, Goober> apostate = new Apostate<Float, Float, Goober>(n2);
        oxidize = false;
        return apostate;
    }

    public static final Recline<? super Boolean> armrests(Goober goober, double d) {
        Boolean bl = true;
        double d2 = bl != false ? -2.957 : 100.317;
        return Main.armrests(robt, d2);
    }

    public static final void main(String[] stringArray) {
        Victual victual = new Victual();
    }
}

