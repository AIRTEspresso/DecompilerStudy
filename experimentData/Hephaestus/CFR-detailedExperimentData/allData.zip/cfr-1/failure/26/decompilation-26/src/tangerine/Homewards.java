/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Main;
import src.tangerine.Messiest;
import src.tangerine.Pisces;
import src.tangerine.Victual;

abstract class Homewards
extends Pisces {
    public final Boolean dismissed;

    public Homewards(Boolean bl) {
        super(new Messiest<Float, Float, String>(-45.766, Float.valueOf(-25.922f)));
        this.dismissed = bl;
    }

    @Override
    public final Float retire(Victual<Float, Float, ? super Float> victual) {
        Float f = Float.valueOf(73.954f);
        Main.delayed();
        return f;
    }

    public abstract boolean proffers(boolean var1);
}

