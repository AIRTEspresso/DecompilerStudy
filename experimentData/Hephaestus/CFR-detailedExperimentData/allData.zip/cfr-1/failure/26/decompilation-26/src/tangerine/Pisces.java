/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Decidedly;
import src.tangerine.Messiest;
import src.tangerine.Victual;

abstract class Pisces
extends Decidedly<Float, Float> {
    public Messiest<Float, Float, String> varicose;

    public Pisces(Messiest<Float, Float, String> messiest) {
        super(-60.403);
        this.varicose = messiest;
    }

    @Override
    public Float retire(Victual<Float, Float, ? super Float> victual) {
        Float f = Float.valueOf(39.267f);
        Double d = -97.627;
        Float f2 = Float.valueOf(-50.192f);
        this.varicose = new Messiest(d, f2);
        return f;
    }
}

