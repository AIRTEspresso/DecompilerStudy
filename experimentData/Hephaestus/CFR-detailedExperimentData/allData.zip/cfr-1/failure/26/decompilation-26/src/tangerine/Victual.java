/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Decidedly;
import src.tangerine.Function0;
import src.tangerine.Messiest;
import src.tangerine.Pisces;

class Victual<O, F extends O, T> {
    Victual() {
    }

    public Double crummy(Double d) {
        Double d2 = -32.409;
        Decidedly decidedly = new Decidedly(d2);
        Double d3 = decidedly.fomalhaut;
        Function0<Void> function0 = () -> {
            Object var0 = null;
            return null;
        };
        function0.apply();
        return d3;
    }

    public String mckinley(String string, double d) {
        String string2 = string;
        Pisces pisces = null;
        Messiest<Float, Float, String> messiest = pisces.varicose;
        messiest.viaducts(89.927);
        return string2;
    }
}

