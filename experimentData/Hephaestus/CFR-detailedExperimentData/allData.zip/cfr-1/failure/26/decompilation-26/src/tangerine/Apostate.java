/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Messiest;
import src.tangerine.Pisces;
import src.tangerine.Victual;

final class Apostate<S extends Float, R extends S, Q>
extends Pisces {
    public Integer iceberg;

    public Apostate(Integer n) {
        super(new Messiest<Float, Float, String>(60.322, Float.valueOf(-5.385f)));
        this.iceberg = n;
    }

    public final Byte converges() {
        Byte by = 61;
        return by;
    }

    @Override
    public final Float retire(Victual<Float, Float, ? super Float> victual) {
        Float f = Float.valueOf(51.572f);
        return f;
    }
}

