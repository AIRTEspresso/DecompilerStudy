/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Homewards;

class Recline<C extends Boolean>
extends Homewards {
    public C minoan;
    public C heyday;

    public Recline(C c, C c2) {
        super((Boolean)null);
        this.minoan = c;
        this.heyday = c2;
    }

    @Override
    public boolean proffers(boolean bl) {
        Boolean bl2 = false;
        boolean bl3 = bl2 != false;
        return this.proffers(bl3);
    }
}

