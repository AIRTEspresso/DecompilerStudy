/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.tangerine;

import src.tangerine.Main;
import src.tangerine.Messiest;
import src.tangerine.Pisces;
import src.tangerine.Victual;

class Vinegary<Z, T>
extends Pisces {
    public final Messiest<? extends Float, ? extends Float, ? super String> eggshell;
    public T ayrshire;

    public Vinegary(Messiest<? extends Float, ? extends Float, ? super String> messiest, T t) {
        super(new Messiest<Float, Float, String>(84.946, Float.valueOf(-94.64f)));
        this.eggshell = messiest;
        this.ayrshire = t;
    }

    @Override
    public final Float retire(Victual<Float, Float, ? super Float> victual) {
        Float f = Float.valueOf(32.41f);
        Main.oxidize = true;
        return f;
    }
}

