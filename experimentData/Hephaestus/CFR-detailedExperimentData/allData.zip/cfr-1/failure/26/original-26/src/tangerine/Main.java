package src.tangerine;

class Main {
  static public final int nay(Number earner, int billed) {
    final Byte aberrant = (byte)37;
    Boolean eager = (aberrant <= 17);
    final int fecundity = -30;
    Function2<Float, Integer, Void> hamsters = (allocate, occlusive) -> {
      final Victual<Object, Object, Pisces> massage = new Victual<Object, Object, Pisces>();
      Double quoth = -48.867;
      final Double waterfowl = massage.crummy(  ((true) ?
  quoth : 
   57.897));
        ((false) ?
  new Messiest<Float, Float, String>(-93.466, (float)-91.34) : 
   new Messiest<Float, Float, String>(-95.123, (float)-51.473)).mulattos = null;
      Object x_0 = waterfowl;
      return null;
    };
    hamsters.apply(  ((false) ?
  (float)-88.413 : 
   (float)-10.900), -65);
    return ((eager) ?
      fecundity : 
       fecundity);
    
  }

  static final Float longingly = (float)-44.651;

  static final Goober robt = new Goober(new Victual<String, String, Byte>());

  static final Victual<String, String, Byte> unhinged = Main.robt.bludgeons;

  static final Double starts = (((Main.longingly == (float)-69.762)) ?
  new Victual<String, String, Byte>() : 
   Main.unhinged).crummy(Main.unhinged.crummy(Main.unhinged.crummy(  ((true) ?
  -89.373 : 
   -19.452))));

  static boolean oxidize = false;

  static public final Object likelier(Object rickets) {
    return new Object();
  }

  static public final Integer polo(Decidedly<? extends Float, ? extends Float> ladoga, int fetched) {
    Homewards hipping = (Homewards) null;
    Boolean wing = hipping.dismissed;
    final Integer kilter = -65;
    return ((wing) ?
      kilter : 
       ((true) ?
        0 : 
         63));
    
  }

  static public final void delayed() {
    final boolean day = false;
    Main.oxidize = day;
    Object x_3 = "turgenev";
    
  }

  static public final Victual<Character, Character, Double> artichoke(char andrea, Boolean confiding) {
    return new Victual<Character, Character, Double>();
  }

  static final Victual<? super Character, Character, ? extends Number> straitens = (((new Messiest<Float, Float, String>(40.823, (float)82.838) == new Messiest<Float, Float, String>(-50.929, (float)53.253))) ?
  Main.artichoke( 'A', false) : 
   new Victual<Character, Character, Double>());

  static public final Long appalling(long demons, int foursome) {
    return (long)83;
  }

  static public final Apostate<Float, Float, Goober> lamented(int gymnasts) {
    final Integer scotsman = 50;
    Apostate<Float, Float, Goober> cinched = new Apostate<Float, Float, Goober>(scotsman);
    Main.oxidize = false;
    return cinched;
    
  }

  static Homewards chekhov = new Recline<Boolean>(((new Vinegary<Goober, Boolean>(new Messiest<Float, Float, String>(97.509, (float)-6.237), false).eggshell != new Messiest<Float, Float, String>(-15.638, (float)-33.775)) &&   ((true) ?
  true : 
   false)), ((Main.lamented(94).converges() <=   ((true) ?
  (float)90.109 : 
   (float)58.317)) &&   ((true) ?
  true : 
   true)));

  static public final Recline<? super Boolean> armrests(Goober penchants, double certainly) {
    Boolean tycoons = true;
    final double shoal = 100.317;
    final double encored = ((tycoons) ?
      -2.957 : 
       shoal);
    return Main.armrests(Main.robt, encored);
    
  }

  static public final void main(String[] args) {
    Object x_4 = new Victual<String, String, Double>();
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Victual<O, F extends O, T> {
  public Double crummy(Double bicycling) {
    Double unkindly = -32.409;
    final Decidedly<Float, Float> dorky = new Decidedly<Float, Float>(unkindly);
    final Double swindlers = dorky.fomalhaut;
    Function0<Void> mutinies = () -> {
      Object x_1 = (T) null;
      return null;
    };
    mutinies.apply();
    return swindlers;
    
  }

  public String mckinley(String quintets, double frothed) {
    final String nibelung = quintets;
    Pisces chasten = (Pisces) null;
    final Messiest<Float, Float, String> nearing = chasten.varicose;
    nearing.viaducts(89.927);
    return nibelung;
    
  }
}

class Decidedly<F extends Float, C extends F> {
  public final Double fomalhaut;

  public Decidedly(Double fomalhaut) {
    this.fomalhaut = fomalhaut;
  }

  public C retire(Victual<F, F, ? super F> dinosaurs) {
    return (C) null;
  }

  public final C thwacks(F scummy, C dries) {
    final C unbarred = (C) null;
    return unbarred;
    
  }
}

final class Messiest<A extends Float, B extends A, Y extends String> extends Decidedly<A, A> {
  public final Double fomalhaut;
  public B mulattos;

  public Messiest(Double fomalhaut,B mulattos) {
    super(-78.874);
    this.fomalhaut = fomalhaut;
    this.mulattos = mulattos;
  }

  public final void viaducts(Double vibrators) {
    Y conquers = (Y) null;
    Object x_2 = conquers;
    
  }

  public final A retire(Victual<A, A, ? super A> dinosaurs) {
    return mulattos;
  }
}

abstract class Pisces extends Decidedly<Float, Float> {
  public Messiest<Float, Float, String> varicose;

  public Pisces(Messiest<Float, Float, String> varicose) {
    super(-60.403);
    this.varicose = varicose;
  }

  public Float retire(Victual<Float, Float, ? super Float> dinosaurs) {
    Float buying = (float)39.267;
    final Double absolves = -97.627;
    final Float faggot = (float)-50.192;
    varicose = new Messiest<Float, Float, String>(absolves, faggot);
    return buying;
    
  }
}

final class Goober extends Pisces {
  public final Victual<String, String, Byte> bludgeons;

  public Goober(Victual<String, String, Byte> bludgeons) {
    super(new Messiest<Float, Float, String>(-21.251, (float)-44.941));
    this.bludgeons = bludgeons;
  }

  public final Float retire(Victual<Float, Float, ? super Float> dinosaurs) {
    return (float)42.979;
  }
}

abstract class Homewards extends Pisces {
  public final Boolean dismissed;

  public Homewards(Boolean dismissed) {
    super(new Messiest<Float, Float, String>(-45.766, (float)-25.922));
    this.dismissed = dismissed;
  }

  public final Float retire(Victual<Float, Float, ? super Float> dinosaurs) {
    Float whimsey = (float)73.954;
    Main.delayed();
    return whimsey;
    
  }

  public abstract boolean proffers(boolean leola) ;
}

class Recline<C extends Boolean> extends Homewards {
  public C minoan;
  public C heyday;

  public Recline(C minoan,C heyday) {
    super((C) null);
    this.minoan = minoan;
    this.heyday = heyday;
  }

  public boolean proffers(boolean leola) {
    final Boolean doodlers = false;
    final boolean tuneful = true;
    final boolean playhouse = ((doodlers) ?
      tuneful : 
       false);
    return proffers(playhouse);
    
  }
}

class Vinegary<Z, T> extends Pisces {
  public final Messiest<? extends Float, ? extends Float, ? super String> eggshell;
  public T ayrshire;

  public Vinegary(Messiest<? extends Float, ? extends Float, ? super String> eggshell,T ayrshire) {
    super(new Messiest<Float, Float, String>(84.946, (float)-94.64));
    this.eggshell = eggshell;
    this.ayrshire = ayrshire;
  }

  public final Float retire(Victual<Float, Float, ? super Float> dinosaurs) {
    final Float immuring = (float)32.410;
    Main.oxidize = true;
    return immuring;
    
  }
}

final class Apostate<S extends Float, R extends S, Q> extends Pisces {
  public Integer iceberg;

  public Apostate(Integer iceberg) {
    super(new Messiest<Float, Float, String>(60.322, (float)-5.385));
    this.iceberg = iceberg;
  }

  public final Byte converges() {
    final Byte uranus = (byte)61;
    return uranus;
    
  }

  public final Float retire(Victual<Float, Float, ? super Float> dinosaurs) {
    final Float exuded = (float)51.572;
    return exuded;
    
  }
}