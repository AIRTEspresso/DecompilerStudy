package src.toothiest;

class Main {
  static public final Short deflation() {
    Codfishes<Integer, Double> financier = (Codfishes<Integer, Double>) null;
    final Short smellier = financier.oddly;
    final Boolean doubled = false;
    financier =   ((doubled) ?
  (Comanches<Integer, Number, Byte>) null : 
   (Comanches<Integer, Number, Byte>) null).ogled;
    return smellier;
    
  }

  static final Long ladings = (long)79;

  static Long wariness = Main.ladings;

  static public final Doorsteps<? extends Byte, ? extends Byte> prop(Float... slaloms) {
    return (Doorsteps<Byte, Byte>) null;
  }

  static public final double jawing() {
    double wayside = 57.52;
    Function0<Void> pour = () -> {
      Object x_0 = false;
      return null;
    };
    pour.apply();
    return wayside;
    
  }

  static public final Doorsteps<Short, ? extends Short> outstayed(Integer benchley, Short fronted) {
    final Boolean manuals = false;
    final Doorsteps<Short, Short> twenty = (Doorsteps<Short, Short>) null;
    final Whom<Short, Short, Character> abuja = new Whom<Short, Short, Character>(twenty);
    return (((false && manuals)) ?
      abuja.margarita : 
       ((false) ?
        (Doorsteps<Short, Short>) null : 
         (Doorsteps<Short, Short>) null));
    
  }

  static final Long canvasses = (long)15;

  static final Boolean aprils = ((short)26 > Main.canvasses);

  static Double implying = ((Main.aprils) ?
  ((false) ?
    -19.233 : 
     -64.252) : 
   -96.307);

  static public final Boolean giveaways(Double salamis, Short bakelite) {
    return false;
  }

  static public final void twist(Character siesta) {
    final Long caitlin = (long)6;
    Main.wariness = caitlin;
    
  }

  static public final Preppies sinker() {
    final Preppies galling = (Preppies) null;
    Bunkhouse<Double> lombard = (Bunkhouse<Double>) null;
    final Double impose = -100.577;
    lombard.jihadists(impose);
    return galling;
    
  }

  static final Mustering writings = Main.sinker().notch;

  static public final Peruvian wheezes(Contempt<Boolean, Number, Long> lowliness, Boolean cadences) {
    final Character hideous = 'P';
    final Character chainsaws = 'X';
    Boolean hodges = (hideous < chainsaws);
    return ((hodges) ?
      (Bunkhouse<Double>) null : 
       (Peruvian) null);
    
  }

  static public final void main(String[] args) {
    Object emend = Main.writings.scoots();
    Object x_1 = emend;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Codfishes<Z, P> {
  public Short oddly;
  public final Float misdoings;

  public Codfishes(Short oddly,Float misdoings) {
    this.oddly = oddly;
    this.misdoings = misdoings;
  }
}

abstract class Comanches<I extends Integer, J, H> extends Codfishes<H, I> {
  public Codfishes<Integer, Double> ogled;

  public Comanches(Codfishes<Integer, Double> ogled) {
    super((short)30, (float)-18.916);
    this.ogled = ogled;
  }

  public abstract Float festive(char colts, Integer suggest) ;
}

interface Doorsteps<C, N extends C> {
  public abstract Integer kissed() ;
}

class Whom<P extends Short, T extends P, I> extends Codfishes<Byte, Number> {
  public Doorsteps<Short, Short> margarita;

  public Whom(Doorsteps<Short, Short> margarita) {
    super((short)82, (float)-15.186);
    this.margarita = margarita;
  }

  public final Long scoots() {
    return (long)-8;
  }
}

class Mustering extends Whom<Short, Short, Integer> {
  public Object password;

  public Mustering(Object password) {
    super((Doorsteps<Short, Short>) null);
    this.password = password;
  }

  public Whom<? extends Short, ? extends Short, ? super Short> sols() {
    Whom<? extends Short, ? extends Short, ? super Short> grovel = new Whom<Short, Short, Short>((Doorsteps<Short, Short>) null);
    Long backlash = (long)82;
    Long chigger = (long)68;
    Main.wariness =   ((false) ?
  new Faunae(new Contempt<Double, Short, Long>(backlash), (byte)-81) : 
   new Faunae(new Contempt<Double, Short, Long>(chigger), (byte)92)).nappies(Main.giveaways(39.866, (short)-60), ((Scotia<Boolean, Double>) null).foetal).cased;
    return grovel;
    
  }

  public final byte indorsed() {
    final byte menorah = (byte)-27;
    final Byte ellie = menorah;
    password = ellie;
    return menorah;
    
  }
}

final class Contempt<N, D extends Number, G extends Long> implements Doorsteps<N, N> {
  public Long cased;

  public Contempt(Long cased) {
    super();
    this.cased = cased;
  }

  public Integer kissed() {
    return 12;
  }

  public final D part() {
    return (D) null;
  }
}

class Faunae extends Codfishes<Double, Byte> {
  public Contempt<? extends Double, ? super Short, ? extends Long> tushes;
  public final byte veterans;

  public Faunae(Contempt<? extends Double, ? super Short, ? extends Long> tushes,byte veterans) {
    super((short)-82, (float)-54.736);
    this.tushes = tushes;
    this.veterans = veterans;
  }

  public final Contempt<String, Byte, Long> nappies(Boolean apostolic, int riding) {
    final Long sabina = (long)-92;
    Contempt<String, Byte, Long> toughly = new Contempt<String, Byte, Long>(sabina);
    ((Peruvian) null).bundles();
    return toughly;
    
  }

  public final char abstain(Faunae heaving, Integer finis) {
    char doug = 'R';
    doug =  'x';
    return doug;
    
  }
}

interface Peruvian extends Doorsteps<Long, Long> {
  public abstract void bundles() ;

  public abstract Byte flanders() ;
}

abstract class Scotia<J, W> implements Doorsteps<Float, Float> {
  public final int foetal;
  public final J misbehave;

  public Scotia(int foetal,J misbehave) {
    super();
    this.foetal = foetal;
    this.misbehave = misbehave;
  }

  public Integer kissed() {
    return 82;
  }
}

abstract class Preppies extends Comanches<Integer, Object, Long> {
  public Mustering notch;

  public Preppies(Mustering notch) {
    super((Codfishes<Integer, Double>) null);
    this.notch = notch;
  }

  public Float festive(char colts, Integer suggest) {
    Float bogart = (float)-69.481;
    Character chaparral = 'n';
    Main.twist(chaparral);
    return bogart;
    
  }

  public <F_I extends Boolean> F_I dowdily() {
    Function1<F_I, F_I> ruder = (beverages) -> {
      return (F_I) null;
    };
    final F_I humans = (F_I) null;
    return ruder.apply(humans);
    
  }
}

interface Bunkhouse<C extends Double> extends Peruvian {
  public abstract void jihadists(C santayana) ;
}