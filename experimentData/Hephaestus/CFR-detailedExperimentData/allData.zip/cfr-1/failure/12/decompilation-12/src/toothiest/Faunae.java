/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Codfishes;
import src.toothiest.Contempt;
import src.toothiest.Peruvian;

class Faunae
extends Codfishes<Double, Byte> {
    public Contempt<? extends Double, ? super Short, ? extends Long> tushes;
    public final byte veterans;

    public Faunae(Contempt<? extends Double, ? super Short, ? extends Long> contempt, byte by) {
        super((short)-82, Float.valueOf(-54.736f));
        this.tushes = contempt;
        this.veterans = by;
    }

    public final Contempt<String, Byte, Long> nappies(Boolean bl, int n) {
        Long l = -92L;
        Contempt<String, Byte, Long> contempt = new Contempt<String, Byte, Long>(l);
        ((Peruvian)null).bundles();
        return contempt;
    }

    public final char abstain(Faunae faunae, Integer n) {
        char c = 'R';
        c = 'x';
        return c;
    }
}

