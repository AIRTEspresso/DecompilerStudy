/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Comanches;
import src.toothiest.Function1;
import src.toothiest.Main;
import src.toothiest.Mustering;

abstract class Preppies
extends Comanches<Integer, Object, Long> {
    public Mustering notch;

    public Preppies(Mustering mustering) {
        super(null);
        this.notch = mustering;
    }

    @Override
    public Float festive(char c, Integer n) {
        Float f = Float.valueOf(-69.481f);
        Character c2 = Character.valueOf('n');
        Main.twist(c2);
        return f;
    }

    public <F_I extends Boolean> F_I dowdily() {
        Function1<Boolean, Boolean> function1 = bl -> null;
        Boolean bl2 = null;
        return (F_I)function1.apply(bl2);
    }
}

