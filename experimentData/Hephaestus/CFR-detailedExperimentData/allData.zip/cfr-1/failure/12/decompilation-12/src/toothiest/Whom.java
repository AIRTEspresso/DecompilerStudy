/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Codfishes;
import src.toothiest.Doorsteps;

class Whom<P extends Short, T extends P, I>
extends Codfishes<Byte, Number> {
    public Doorsteps<Short, Short> margarita;

    public Whom(Doorsteps<Short, Short> doorsteps) {
        super((short)82, Float.valueOf(-15.186f));
        this.margarita = doorsteps;
    }

    public final Long scoots() {
        return -8L;
    }
}

