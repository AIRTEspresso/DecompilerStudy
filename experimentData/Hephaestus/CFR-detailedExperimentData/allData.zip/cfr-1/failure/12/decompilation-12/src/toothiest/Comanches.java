/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Codfishes;

abstract class Comanches<I extends Integer, J, H>
extends Codfishes<H, I> {
    public Codfishes<Integer, Double> ogled;

    public Comanches(Codfishes<Integer, Double> codfishes) {
        super((short)30, Float.valueOf(-18.916f));
        this.ogled = codfishes;
    }

    public abstract Float festive(char var1, Integer var2);
}

