/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

abstract class Codfishes<Z, P> {
    public Short oddly;
    public final Float misdoings;

    public Codfishes(Short s, Float f) {
        this.oddly = s;
        this.misdoings = f;
    }
}

