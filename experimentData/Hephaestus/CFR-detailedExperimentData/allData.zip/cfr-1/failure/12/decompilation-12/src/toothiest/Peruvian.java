/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Doorsteps;

interface Peruvian
extends Doorsteps<Long, Long> {
    public void bundles();

    public Byte flanders();
}

