/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Doorsteps;

final class Contempt<N, D extends Number, G extends Long>
implements Doorsteps<N, N> {
    public Long cased;

    public Contempt(Long l) {
        this.cased = l;
    }

    @Override
    public Integer kissed() {
        return 12;
    }

    public final D part() {
        return (D)((Number)null);
    }
}

