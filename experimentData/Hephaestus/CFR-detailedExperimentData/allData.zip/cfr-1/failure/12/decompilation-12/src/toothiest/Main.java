/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Bunkhouse;
import src.toothiest.Codfishes;
import src.toothiest.Comanches;
import src.toothiest.Contempt;
import src.toothiest.Doorsteps;
import src.toothiest.Function0;
import src.toothiest.Mustering;
import src.toothiest.Peruvian;
import src.toothiest.Preppies;
import src.toothiest.Whom;

class Main {
    static final Long ladings;
    static Long wariness;
    static final Long canvasses;
    static final Boolean aprils;
    static Double implying;
    static final Mustering writings;

    Main() {
    }

    public static final Short deflation() {
        Boolean bl;
        Codfishes<Integer, Double> codfishes = null;
        Short s = codfishes.oddly;
        codfishes = ((bl = Boolean.valueOf((boolean)false)).booleanValue() ? (Comanches)null : (Comanches)null).ogled;
        return s;
    }

    public static final Doorsteps<? extends Byte, ? extends Byte> prop(Float ... floatArray) {
        return null;
    }

    public static final double jawing() {
        double d = 57.52;
        Function0<Void> function0 = () -> {
            Boolean bl = false;
            return null;
        };
        function0.apply();
        return d;
    }

    public static final Doorsteps<Short, ? extends Short> outstayed(Integer n, Short s) {
        Boolean bl = false;
        Doorsteps doorsteps = null;
        Whom whom = new Whom(doorsteps);
        return null;
    }

    public static final Boolean giveaways(Double d, Short s) {
        return false;
    }

    public static final void twist(Character c) {
        Long l;
        wariness = l = Long.valueOf(6L);
    }

    public static final Preppies sinker() {
        Preppies preppies = null;
        Bunkhouse bunkhouse = null;
        Double d = -100.577;
        bunkhouse.jihadists(d);
        return preppies;
    }

    public static final Peruvian wheezes(Contempt<Boolean, Number, Long> contempt, Boolean bl) {
        Character c = Character.valueOf('P');
        Character c2 = Character.valueOf('X');
        Boolean bl2 = c.charValue() < c2.charValue();
        return bl2 != false ? (Bunkhouse)null : (Peruvian)null;
    }

    public static final void main(String[] stringArray) {
        Long l;
        Long l2 = l = writings.scoots();
    }

    static {
        wariness = ladings = Long.valueOf(79L);
        canvasses = 15L;
        aprils = 26L > canvasses;
        implying = aprils != false ? -64.252 : -96.307;
        writings = Main.sinker().notch;
    }
}

