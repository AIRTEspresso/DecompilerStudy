/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Peruvian;

interface Bunkhouse<C extends Double>
extends Peruvian {
    public void jihadists(C var1);
}

