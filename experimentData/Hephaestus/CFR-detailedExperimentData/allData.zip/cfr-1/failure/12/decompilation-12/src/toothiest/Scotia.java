/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Doorsteps;

abstract class Scotia<J, W>
implements Doorsteps<Float, Float> {
    public final int foetal;
    public final J misbehave;

    public Scotia(int n, J j) {
        this.foetal = n;
        this.misbehave = j;
    }

    @Override
    public Integer kissed() {
        return 82;
    }
}

