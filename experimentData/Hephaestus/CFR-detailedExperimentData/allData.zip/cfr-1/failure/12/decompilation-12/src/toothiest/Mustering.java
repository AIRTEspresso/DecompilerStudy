/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.toothiest;

import src.toothiest.Contempt;
import src.toothiest.Faunae;
import src.toothiest.Main;
import src.toothiest.Scotia;
import src.toothiest.Whom;

class Mustering
extends Whom<Short, Short, Integer> {
    public Object password;

    public Mustering(Object object) {
        super(null);
        this.password = object;
    }

    public Whom<? extends Short, ? extends Short, ? super Short> sols() {
        Whom whom = new Whom(null);
        Long l = 82L;
        Long l2 = 68L;
        Main.wariness = new Faunae(new Contempt<N, D, G>((Long)l2), (byte)92).nappies((Boolean)Main.giveaways((Double)Double.valueOf((double)39.866), (Short)Short.valueOf((short)-60)), (int)((Scotia)null).foetal).cased;
        return whom;
    }

    public final byte indorsed() {
        Byte by = -27;
        this.password = by;
        return -27;
    }
}

