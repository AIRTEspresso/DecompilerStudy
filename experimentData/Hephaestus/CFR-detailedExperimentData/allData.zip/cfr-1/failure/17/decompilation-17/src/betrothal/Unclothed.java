/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Antigen;
import src.betrothal.Clotho;
import src.betrothal.Miscuing;
import src.betrothal.Starless;

abstract class Unclothed
extends Miscuing<Boolean, Clotho> {
    public final Antigen<Double> acidly;
    public final short mackinaws;

    public Unclothed(Antigen<Double> antigen, short s) {
        super((short)-41);
        this.acidly = antigen;
        this.mackinaws = s;
    }

    @Override
    public Short comprises() {
        return (short)-17;
    }

    public abstract Starless<Character, ? extends Clotho, ? extends Byte> fascist(Starless<Character, ? extends Clotho, ? extends Byte> var1);
}

