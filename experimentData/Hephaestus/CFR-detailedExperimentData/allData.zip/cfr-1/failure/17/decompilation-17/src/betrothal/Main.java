/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Amortized;
import src.betrothal.Barroom;
import src.betrothal.Breton;
import src.betrothal.Ecru;
import src.betrothal.Function1;
import src.betrothal.Mires;
import src.betrothal.Miscuing;
import src.betrothal.Starless;

class Main {
    static Boolean homicide = false;
    static final Mires<Barroom> befouled = null;
    static Mires<Barroom> mysteries = befouled;
    static final Starless<Byte, ? extends Barroom, ? super Byte> cottage = new Starless(homicide != false ? befouled : mysteries, new Breton((Amortized<Float, Float, Float>)((Amortized)null), (short)76).vibrantly.jared);

    Main() {
    }

    public static final short moist(short s) {
        return ((Miscuing)null).mackinaws;
    }

    public static final Integer ginned(Integer n) {
        return -56;
    }

    public static final <F_T> void caps(char c, F_T F_T) {
        Function1<Short, Void> function1 = s -> {
            Object var1_1 = null;
            return null;
        };
        function1.apply((short)76);
        Object var3_3 = null;
    }

    public static final float shopping(Ecru ecru, Breton breton) {
        return -29.393f;
    }

    public static final Long ducats() {
        return -61L;
    }

    public static final void outworn(double d, char c) {
        Character c2 = Character.valueOf('r');
    }

    public static final void main(String[] stringArray) {
        int n = 74;
        Integer n2 = n;
    }
}

