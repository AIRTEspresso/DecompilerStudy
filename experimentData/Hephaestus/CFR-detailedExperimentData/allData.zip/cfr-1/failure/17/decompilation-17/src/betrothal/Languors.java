/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Miscuing;

abstract class Languors<S, A>
extends Miscuing<Boolean, Double> {
    public final short mackinaws;

    public Languors(short s) {
        super((short)-97);
        this.mackinaws = s;
    }

    @Override
    public Short comprises() {
        return this.mackinaws;
    }

    public abstract A rustier(Long var1, S var2);
}

