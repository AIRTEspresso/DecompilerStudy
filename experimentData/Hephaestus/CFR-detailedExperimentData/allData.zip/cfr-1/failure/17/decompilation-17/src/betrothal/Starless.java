/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Barroom;
import src.betrothal.Gherkin;
import src.betrothal.Mires;

final class Starless<T, Z, C extends Byte>
extends Gherkin {
    public Mires<Barroom> rowland;
    public final int respiring;

    public Starless(Mires<Barroom> mires, int n) {
        super(null, -74L);
        this.rowland = mires;
        this.respiring = n;
    }

    public final Gherkin regime(double d) {
        Mires<Barroom> mires = this.rowland;
        return new Gherkin(mires, -33L);
    }
}

