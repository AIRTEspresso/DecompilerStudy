/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Amortized;
import src.betrothal.Languors;

final class Breton
extends Languors<Character, Short> {
    public Amortized<Float, Float, Float> vibrantly;
    public final short mackinaws;

    public Breton(Amortized<Float, Float, Float> amortized, short s) {
        super((short)-55);
        this.vibrantly = amortized;
        this.mackinaws = s;
    }

    @Override
    public Short rustier(Long l, Character c) {
        return (short)72;
    }

    @Override
    public final Short comprises() {
        return (short)72;
    }
}

