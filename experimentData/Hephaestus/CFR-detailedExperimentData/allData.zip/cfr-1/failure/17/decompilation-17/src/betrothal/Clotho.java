/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Barroom;
import src.betrothal.Gherkin;
import src.betrothal.Mires;
import src.betrothal.Miscuing;
import src.betrothal.Pullet;

class Clotho
extends Gherkin {
    public double zhukov;
    public Mires<Barroom> rowland;

    public Clotho(double d, Mires<Barroom> mires) {
        super(null, 79L);
        this.zhukov = d;
        this.rowland = mires;
    }

    @Override
    public final Short comprises() {
        return (short)12;
    }

    @Override
    public Miscuing<? super Boolean, ? super Double> team(Boolean bl, Double d) {
        Pullet pullet;
        Pullet pullet2 = pullet = new Pullet(93);
        return pullet2;
    }
}

