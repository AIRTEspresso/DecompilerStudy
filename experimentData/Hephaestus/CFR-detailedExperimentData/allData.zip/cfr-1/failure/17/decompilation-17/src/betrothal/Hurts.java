/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Gherkin;

abstract class Hurts<H extends Byte>
extends Gherkin {
    public final long wreak;

    public Hurts(long l) {
        super(null, -96L);
        this.wreak = l;
    }

    public abstract String nearing(long var1);
}

