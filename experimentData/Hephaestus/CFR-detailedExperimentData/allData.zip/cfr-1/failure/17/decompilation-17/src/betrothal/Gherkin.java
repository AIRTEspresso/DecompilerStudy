/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Barroom;
import src.betrothal.Ecru;
import src.betrothal.Mires;
import src.betrothal.Miscuing;

class Gherkin
extends Miscuing<Boolean, Character> {
    public Mires<Barroom> rowland;
    public final long wreak;

    public Gherkin(Mires<Barroom> mires, long l) {
        super((short)3);
        this.rowland = mires;
        this.wreak = l;
    }

    @Override
    public Short comprises() {
        Short s = 92;
        return s;
    }

    public Miscuing<? super Boolean, ? super Double> team(Boolean bl, Double d) {
        this.rowland = null;
        return new Ecru(-24);
    }
}

