/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Barroom;
import src.betrothal.Miscuing;
import src.betrothal.Pullet;

abstract class Mires<D>
extends Miscuing<Boolean, D> {
    public final Byte hopped;
    public final short mackinaws;

    public Mires(Byte by, short s) {
        super((short)-14);
        this.hopped = by;
        this.mackinaws = s;
    }

    @Override
    public Short comprises() {
        Short s = 61;
        Integer n = -86;
        Pullet<Double> pullet = new Pullet<Double>(n);
        pullet.seaboard(new Barroom(89), 37.39);
        return s;
    }
}

