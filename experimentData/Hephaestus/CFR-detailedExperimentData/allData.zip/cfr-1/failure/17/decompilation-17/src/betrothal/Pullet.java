/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Barroom;
import src.betrothal.Function0;
import src.betrothal.Main;
import src.betrothal.Miscuing;

class Pullet<R>
extends Miscuing<Boolean, Number> {
    public Integer jared;

    public Pullet(Integer n) {
        super((short)26);
        this.jared = n;
    }

    public final void seaboard(Barroom barroom, R r) {
        Function0<Void> function0 = () -> {
            Object var0;
            Object var1_1 = var0 = null;
            return null;
        };
        function0.apply();
        Double[] doubleArray = new Double[]{};
    }

    @Override
    public Short comprises() {
        Short s = -94;
        char c = '4';
        Object F_T = null;
        Main.caps(c, F_T);
        return s;
    }
}

