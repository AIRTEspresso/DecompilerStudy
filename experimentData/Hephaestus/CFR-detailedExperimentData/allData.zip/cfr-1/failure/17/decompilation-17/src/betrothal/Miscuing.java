/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

abstract class Miscuing<O extends Boolean, N> {
    public final short mackinaws;

    public Miscuing(short s) {
        this.mackinaws = s;
    }

    public abstract Short comprises();
}

