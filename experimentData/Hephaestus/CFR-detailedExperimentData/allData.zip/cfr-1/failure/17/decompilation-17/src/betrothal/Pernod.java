/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Barroom;
import src.betrothal.Clotho;
import src.betrothal.Function2;
import src.betrothal.Hurts;
import src.betrothal.Main;
import src.betrothal.Mires;
import src.betrothal.Miscuing;
import src.betrothal.Starless;
import src.betrothal.Unclothed;

class Pernod
extends Miscuing<Boolean, Integer> {
    public final short mackinaws;

    public Pernod(short s) {
        super((short)-8);
        this.mackinaws = s;
    }

    @Override
    public Short comprises() {
        Short s = this.mackinaws;
        Function2<String, Integer, Void> function2 = (string, n) -> {
            Boolean bl = true;
            Integer n2 = 31;
            Integer n3 = bl != false ? -80 : n2;
            Main.outworn(new Clotho((double)-35.582, (Mires<Barroom>)((Mires)null)).zhukov, 'V');
            Integer n4 = n3;
            return null;
        };
        Function2<Character, Starless, String> function22 = (c, starless) -> {
            Boolean bl = true;
            Hurts hurts = null;
            Hurts hurts2 = bl != false ? hurts : hurts;
            ((Unclothed)null).acidly.hidebound();
            return hurts2.nearing(-78L);
        };
        Boolean bl = false;
        function2.apply(function22.apply(Character.valueOf(bl != false ? (char)'Q' : 'A'), null), -63);
        return s;
    }
}

