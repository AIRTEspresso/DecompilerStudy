/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Miscuing;

final class Barroom
extends Miscuing<Boolean, Short> {
    public final short mackinaws;

    public Barroom(short s) {
        super((short)5);
        this.mackinaws = s;
    }

    @Override
    public Short comprises() {
        return this.mackinaws;
    }
}

