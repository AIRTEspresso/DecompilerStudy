/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Pullet;

abstract class Amortized<O extends Float, A extends O, F extends A>
extends Pullet<A> {
    public final char concavity;
    public Integer jared;

    public Amortized(char c, Integer n) {
        super(66);
        this.concavity = c;
        this.jared = n;
    }

    @Override
    public final Short comprises() {
        return (short)-2;
    }

    public abstract <F_Q> F_Q rabbinate(F_Q var1);
}

