/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

interface Antigen<T> {
    public void hidebound();

    public T bedroll();
}

