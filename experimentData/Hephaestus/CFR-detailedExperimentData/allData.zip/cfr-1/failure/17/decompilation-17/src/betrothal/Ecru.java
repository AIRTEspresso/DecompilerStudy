/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
package src.betrothal;

import src.betrothal.Amortized;
import src.betrothal.Barroom;
import src.betrothal.Function1;
import src.betrothal.Gherkin;
import src.betrothal.Languors;
import src.betrothal.Main;
import src.betrothal.Mires;
import src.betrothal.Pullet;
import src.betrothal.Starless;

class Ecru
extends Languors<Short, Integer> {
    public final short mackinaws;

    public Ecru(short s) {
        super((short)94);
        this.mackinaws = s;
    }

    @Override
    public Integer rustier(Long l, Short s) {
        Boolean bl = true;
        Integer n = bl != false ? 85 : 34;
        Function1<Character, Byte> function1 = c -> {
            Mires mires;
            Mires mires2 = mires = (Mires)null;
            Byte by = mires2.hopped;
            new Pullet<R>((Integer)Integer.valueOf((int)13)).jared = Main.ginned(88);
            return by;
        };
        bl = new Gherkin((Mires<Barroom>)((Mires)null), (long)-86L).rowland.hopped != function1.apply(Character.valueOf(((Amortized)null).concavity));
        return n;
    }

    public <F_V> F_V pestles() {
        F_V F_V = null;
        double d = 33.31;
        new Starless<T, Z, C>((Mires<Barroom>)((Mires)null), (int)-12).regime((double)d).rowland = null;
        return F_V;
    }
}

