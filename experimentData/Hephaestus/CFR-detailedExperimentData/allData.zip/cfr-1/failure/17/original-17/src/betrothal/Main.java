package src.betrothal;

class Main {
  static public final short moist(short tactical) {
    return ((Miscuing<Boolean, Double>) null).mackinaws;
  }

  static public final Integer ginned(Integer rankled) {
    return -56;
  }

  static public final <F_T> void caps(char scrubs, F_T ennobles) {
    Function1<Short, Void> bashing = (schubert) -> {
      Object x_2 = (F_T) null;
      return null;
    };
    bashing.apply((short)76);
    Object x_3 = (F_T) null;
    
  }

  static Boolean homicide = false;

  static final Mires<Barroom> befouled = (Mires<Barroom>) null;

  static Mires<Barroom> mysteries = Main.befouled;

  static final Starless<Byte, ? extends Barroom, ? super Byte> cottage = new Starless<Byte, Barroom, Byte>(  ((Main.homicide) ?
  Main.befouled : 
   Main.mysteries), new Breton((Amortized<Float, Float, Float>) null, (short)76).vibrantly.jared);

  static public final float shopping(Ecru feistier, Breton purulence) {
    return (float)-29.393;
  }

  static public final Long ducats() {
    return (long)-61;
  }

  static public final void outworn(double toxicity, char terminate) {
    Object x_5 = 'r';
    
  }

  static public final void main(String[] args) {
    int noble = 74;
    Object x_6 = noble;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Miscuing<O extends Boolean, N> {
  public final short mackinaws;

  public Miscuing(short mackinaws) {
    this.mackinaws = mackinaws;
  }

  public abstract Short comprises() ;
}

final class Barroom extends Miscuing<Boolean, Short> {
  public final short mackinaws;

  public Barroom(short mackinaws) {
    super((short)5);
    this.mackinaws = mackinaws;
  }

  public Short comprises() {
    return mackinaws;
  }
}

abstract class Languors<S, A> extends Miscuing<Boolean, Double> {
  public final short mackinaws;

  public Languors(short mackinaws) {
    super((short)-97);
    this.mackinaws = mackinaws;
  }

  public Short comprises() {
    return mackinaws;
  }

  public abstract A rustier(Long specifics, S rubbishes) ;
}

class Ecru extends Languors<Short, Integer> {
  public final short mackinaws;

  public Ecru(short mackinaws) {
    super((short)94);
    this.mackinaws = mackinaws;
  }

  public Integer rustier(Long specifics, Short rubbishes) {
    Boolean pinafores = true;
    final Integer airport = ((pinafores) ?
      85 : 
       34);
    final long national = (long)-86;
    Function1<Character, Byte> attaching = (monetized) -> {
      Mires<? super String> favor = (Mires<String>) null;
      Mires<? super String> waited = favor;
      Byte apocrypha = waited.hopped;
      new Pullet<Float>(13).jared = Main.ginned(88);
      return apocrypha;
      
    };
    pinafores = (new Gherkin((Mires<Barroom>) null, national).rowland.hopped != attaching.apply(((Amortized<Float, Float, Float>) null).concavity));
    return airport;
    
  }

  public <F_V> F_V pestles() {
    final F_V lucretius = (F_V) null;
    double cagney = 33.31;
    new Starless<F_V, F_V, Byte>((Mires<Barroom>) null, -12).regime(cagney).rowland = (Mires<Barroom>) null;
    return lucretius;
    
  }
}

abstract class Mires<D> extends Miscuing<Boolean, D> {
  public final Byte hopped;
  public final short mackinaws;

  public Mires(Byte hopped,short mackinaws) {
    super((short)-14);
    this.hopped = hopped;
    this.mackinaws = mackinaws;
  }

  public Short comprises() {
    final Short hawked = (short)61;
    Integer barrymore = -86;
    Pullet<Double> hogwarts = new Pullet<Double>(barrymore);
    hogwarts.seaboard(new Barroom((short)89), 37.39);
    return hawked;
    
  }
}

class Pullet<R> extends Miscuing<Boolean, Number> {
  public Integer jared;

  public Pullet(Integer jared) {
    super((short)26);
    this.jared = jared;
  }

  public final void seaboard(Barroom retrace, R leeds) {
    Function0<Void> convening = () -> {
      final R blunders = (R) null;
      Object x_0 = blunders;
      return null;
    };
    convening.apply();
    Object x_1 = new Double[0];
    
  }

  public Short comprises() {
    final Short weevil = (short)-94;
    char footing = '4';
    final R lawful = (R) null;
    Main.caps(footing, lawful);
    return weevil;
    
  }
}

class Gherkin extends Miscuing<Boolean, Character> {
  public Mires<Barroom> rowland;
  public final long wreak;

  public Gherkin(Mires<Barroom> rowland,long wreak) {
    super((short)3);
    this.rowland = rowland;
    this.wreak = wreak;
  }

  public Short comprises() {
    final Short piled = (short)92;
    return piled;
    
  }

  public Miscuing<? super Boolean, ? super Double> team(Boolean baffling, Double sniggers) {
    final short yack = (short)-24;
    rowland = (Mires<Barroom>) null;
    return new Ecru(yack);
    
  }
}

abstract class Amortized<O extends Float, A extends O, F extends A> extends Pullet<A> {
  public final char concavity;
  public Integer jared;

  public Amortized(char concavity,Integer jared) {
    super(66);
    this.concavity = concavity;
    this.jared = jared;
  }

  public final Short comprises() {
    return (short)-2;
  }

  public abstract <F_Q> F_Q rabbinate(F_Q festooned) ;
}

final class Starless<T, Z, C extends Byte> extends Gherkin {
  public Mires<Barroom> rowland;
  public final int respiring;

  public Starless(Mires<Barroom> rowland,int respiring) {
    super((Mires<Barroom>) null, (long)-74);
    this.rowland = rowland;
    this.respiring = respiring;
  }

  public final Gherkin regime(double bear) {
    final Mires<Barroom> windowed = rowland;
    return new Gherkin(windowed, (long)-33);
    
  }
}

final class Breton extends Languors<Character, Short> {
  public Amortized<Float, Float, Float> vibrantly;
  public final short mackinaws;

  public Breton(Amortized<Float, Float, Float> vibrantly,short mackinaws) {
    super((short)-55);
    this.vibrantly = vibrantly;
    this.mackinaws = mackinaws;
  }

  public Short rustier(Long specifics, Character rubbishes) {
    return (short)72;
  }

  public final Short comprises() {
    return (short)72;
  }
}

class Pernod extends Miscuing<Boolean, Integer> {
  public final short mackinaws;

  public Pernod(short mackinaws) {
    super((short)-8);
    this.mackinaws = mackinaws;
  }

  public Short comprises() {
    final Short roberson = mackinaws;
    Function2<String, Integer, Void> chalking = (beheld, fanciness) -> {
      Boolean teller = true;
      final Integer ruth = 31;
      Integer wayside = ((teller) ?
        -80 : 
         ruth);
      Main.outworn(new Clotho(-35.582, (Mires<Barroom>) null).zhukov,   ((false) ?
   'n' : 
    'V'));
      Object x_4 = wayside;
      return null;
    };
    Function2<Character, Starless<? extends Double, ? super Double, Byte>, String> adjured = (isosceles, swimsuit) -> {
      final Boolean runnymede = true;
      final Hurts<Byte> hedges = (Hurts<Byte>) null;
      final Hurts<Byte> meighen = ((runnymede) ?
        hedges : 
         hedges);
      ((Unclothed) null).acidly.hidebound();
      return meighen.nearing((long)-78);
      
    };
    final Boolean primacy = false;
    final char feud = 'Q';
    chalking.apply(adjured.apply(  ((primacy) ?
  feud : 
    'A'), null),   ((false) ?
  94 : 
   -63));
    return roberson;
    
  }
}

class Clotho extends Gherkin {
  public double zhukov;
  public Mires<Barroom> rowland;

  public Clotho(double zhukov,Mires<Barroom> rowland) {
    super((Mires<Barroom>) null, (long)79);
    this.zhukov = zhukov;
    this.rowland = rowland;
  }

  public final Short comprises() {
    return (short)12;
  }

  public Miscuing<? super Boolean, ? super Double> team(Boolean baffling, Double sniggers) {
    final Pullet<Clotho> moderated = new Pullet<Clotho>(93);
    Miscuing<Boolean, Number> droplet = moderated;
    return droplet;
    
  }
}

abstract class Hurts<H extends Byte> extends Gherkin {
  public final long wreak;

  public Hurts(long wreak) {
    super((Mires<Barroom>) null, (long)-96);
    this.wreak = wreak;
  }

  public abstract String nearing(long motorcar) ;
}

interface Antigen<T> {
  public abstract void hidebound() ;

  public abstract T bedroll() ;
}

abstract class Unclothed extends Miscuing<Boolean, Clotho> {
  public final Antigen<Double> acidly;
  public final short mackinaws;

  public Unclothed(Antigen<Double> acidly,short mackinaws) {
    super((short)-41);
    this.acidly = acidly;
    this.mackinaws = mackinaws;
  }

  public Short comprises() {
    return (short)-17;
  }

  public abstract Starless<Character, ? extends Clotho, ? extends Byte> fascist(Starless<Character, ? extends Clotho, ? extends Byte> angeles) ;
}