/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
class T3
extends T1 {
    public T3(T2 t2, Short s) {
        super(-38L, (short)-37);
    }
}
