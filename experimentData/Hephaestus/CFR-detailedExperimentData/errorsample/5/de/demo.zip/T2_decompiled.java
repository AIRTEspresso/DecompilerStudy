/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
class T2
extends T1 {
    public T2(Short s, long l) {
        super(-38L, (short)-37);
    }
}
