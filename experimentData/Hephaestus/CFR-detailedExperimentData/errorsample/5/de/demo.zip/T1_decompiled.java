/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
class T1 {
    public T1(long l, Short s) {
    }
}
