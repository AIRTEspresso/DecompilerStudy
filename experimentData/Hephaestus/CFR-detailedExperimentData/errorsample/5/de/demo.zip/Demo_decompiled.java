/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
class Demo<M extends String>
extends T3 {
    public Demo() {
        super(new T2((Short)-55, 96L), (Short)-48);
    }
}
