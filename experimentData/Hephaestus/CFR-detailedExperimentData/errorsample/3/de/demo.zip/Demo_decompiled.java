/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
class Demo {
    Demo() {
    }

    public void foo() {
        Character c = Character.valueOf('c');
        I1 i1 = () -> {
            Character c = Character.valueOf('c');
        };
    }
}
