/*
 * Decompiled with CFR 0.153-SNAPSHOT (24c7433-dirty).
 */
class Demo {
    Demo() {
    }

    public static void foo() {
        T1 t1 = new T1(-70);
    }
}
