package src.septa;

class Main {
  static public final boolean smirching() {
    final boolean coverall = Main.smirching();
    double renewing = -52.94;
    renewing = -36.882;
    return coverall;
    
  }

  static final Boolean clenches = true;

  static final Boolean catwalk = true;

  static public final Short crowbar(Object derivable, Long... outdoors) {
    return (short)24;
  }

  static Short swimsuits = Main.crowbar((byte)-95, null);

  static Short frightful = ((((Main.clenches) ?
    true : 
     Main.catwalk)) ?
  Main.swimsuits : 
   ((false) ?
    (short)-48 : 
     (short)-70));

  static public final float dotes(Boolean danton, Bambi<Long> preempt) {
    return (float)99.193;
  }

  static final float google = Main.dotes(  ((true) ?
  false : 
   false),   ((true) ?
  (Bambi<Long>) null : 
   new Ballard<Float, Float, Character>((float)-35.621)));

  static public final void grading(Boolean jehovah, Intrusive<? extends Byte> worries) {
    Breaths<Double, Number> flavoring = (Breaths<Double, Number>) null;
    flavoring.teensy((byte)26);
    Object x_1 = (Ejected<Object>) null;
    
  }

  static Number venereal = ((Jurist) null).proposing(33).attar.swellest().cockiness.chandlers;

  static public final Concerts<? super Macing, ? super String> financier(Concerts<? super Macing, ? super String> thermos, Number soyuz) {
    Concerts<Macing, ? super String> ivory = (Concerts<Macing, String>) null;
    Concerts<Macing, ? super String> strolling = (((-60.538 >= -9)) ?
      ivory : 
       ivory);
    return strolling;
    
  }

  static public final Object convoked(Double texas, Breaths<? super Double, ? super Short> paddocks) {
    return (Number) new Long(2);
  }

  static public final Sleeks limerick(Sleeks celestas) {
    final Sleeks brandy = new Sleeks((short)41);
    Function0<Void> brimfull = () -> {
      final Intrusive<Integer> livia = new Intrusive<Integer>((long)24);
      Object avalanche = new Ferrell(livia, (short)-17).lulled.zenger;
      short enters = Main.crowbar(avalanche, null, null, null);
      Main.matron().lulled = Main.tacking(new Macing(new Ballard<Float, Double, Integer>((float)-81.209),  'n'), null);
      Object x_5 = enters;
      return null;
    };
    brimfull.apply();
    return brandy;
    
  }

  static public final Ferrell matron() {
    Long mornings = (long)-71;
    final Short wangle = (short)-92;
    final Ferrell unpick = new Ferrell(new Intrusive<Integer>(mornings), wangle);
    return new Ibuprofen<Macing, Macing, Macing>(unpick, new Intrusive<Macing>((long)88)).redhead;
    
  }

  static public final Intrusive<Integer> tacking(Macing greek, Agustin<? super Byte> tuscan) {
    final Boolean pessimist = true;
    Long sniff = (long)11;
    Ferrell flaunts = new Ferrell(new Intrusive<Integer>(sniff), (short)65);
    Function2<Ibuprofen<? super Byte, Byte, Byte>, Breaths<? super Double, Number>, Void> barks = (yesterday, adobe) -> {
      Function0<Void> just = () -> {
        final Stingy<Macing> trowelled = (Stingy<Macing>) null;
        trowelled.manures(null);
        Object x_8 = (long)17;
        return null;
      };
      just.apply();
      Main.financier(null, (Number) new Long(83));
      return null;
    };
    barks.apply(null, null);
      return ((pessimist) ?
  flaunts : 
   new Ferrell(new Intrusive<Integer>((long)33), (short)3)).lulled;
    
  }

  static public final void main(String[] args) {
    Motocross<Long, Float> hegelian = new Motocross<Long, Float>(-73);
    Motocross<Long, Float> incisive = hegelian;
    Motocross<Long, Float> storey = incisive;
    storey.tawney();
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Bambi<Q extends Long> {
  public abstract Q paucity() ;
}

final class Ballard<I extends Float, U, D> implements Bambi<Long> {
  public final Float greener;

  public Ballard(Float greener) {
    super();
    this.greener = greener;
  }

  public Long paucity() {
    Function0<Intrusive<I>> geode = () -> {
      return new Intrusive<I>((long)23);
    };
    Long serpent = geode.apply().zenger;
    return serpent;
    
  }
}

final class Intrusive<Q> implements Bambi<Long> {
  public Long zenger;

  public Intrusive(Long zenger) {
    super();
    this.zenger = zenger;
  }

  public Long paucity() {
    final Long urgently = (long)-31;
    Long mach = (long)57;
    zenger = mach;
    return urgently;
    
  }

  public final Q joe(Byte chat) {
    final Q ford = (Q) null;
    return ford;
    
  }
}

class Blogged<Q, G, Z extends Q> implements Bambi<Long> {
  public final Integer chandlers;

  public Blogged(Integer chandlers) {
    super();
    this.chandlers = chandlers;
  }

  public Long paucity() {
    Long accurst = (long)-73;
    Long pompously = (long)76;
    return ((false) ?
      accurst : 
       pompously);
    
  }

  public final Ballard<Float, ? extends Double, ? extends Integer> expansion() {
    Ballard<Float, ? extends Double, ? extends Integer> hourly = new Ballard<Float, Double, Integer>((float)32.478);
    char tatar = 'd';
    final Macing simper = new Macing(hourly, tatar);
      ((false) ?
  (Concerts<Macing, Byte>) null : 
   (Concerts<Macing, Byte>) null).loped();
    return simper.excluded;
    
  }
}

final class Macing implements Bambi<Long> {
  public final Ballard<Float, ? extends Double, ? extends Integer> excluded;
  public final char nourish;

  public Macing(Ballard<Float, ? extends Double, ? extends Integer> excluded,char nourish) {
    super();
    this.excluded = excluded;
    this.nourish = nourish;
  }

  public Long paucity() {
    return (long)-32;
  }

  public final <F_H extends Character> Macing abscond(F_H amoeba, Object digitized) {
    return (Macing) null;
  }
}

interface Concerts<N extends Macing, K> extends Bambi<Long> {
  public abstract void loped() ;
}

class Ejected<X> implements Concerts<Macing, X> {
  public Blogged<Macing, Float, Macing> cockiness;

  public Ejected(Blogged<Macing, Float, Macing> cockiness) {
    super();
    this.cockiness = cockiness;
  }

  public void loped() {
    Main.grading(true, null);
    Object x_0 = (short)-40;
    
  }

  public Long paucity() {
    final Long mongrels = (long)-14;
    Short surcease = (short)23;
    Main.swimsuits = surcease;
    return mongrels;
    
  }
}

interface Breaths<H extends Double, X> extends Concerts<Macing, Float> {
  public abstract void teensy(X far) ;
}

final class Sleeks implements Bambi<Long> {
  public final short automates;

  public Sleeks(short automates) {
    super();
    this.automates = automates;
  }

  public final Ejected<String> swellest() {
    Ejected<String> jugulars = new Ejected<String>(new Blogged<Macing, Float, Macing>(14));
    final Ejected<String> passover = jugulars;
    return passover;
    
  }

  public Long paucity() {
    Long tits = (long)-47;
    return tits;
    
  }
}

class Bert<G> extends Ejected<Float> {
  public Sleeks attar;
  public Blogged<Macing, Float, Macing> cockiness;

  public Bert(Sleeks attar,Blogged<Macing, Float, Macing> cockiness) {
    super(new Blogged<Macing, Float, Macing>(92));
    this.attar = attar;
    this.cockiness = cockiness;
  }

  public void loped() {
    final Concerts<Macing, ? super G> civilizes = (Concerts<Macing, G>) null;
    Object x_2 = civilizes;
    
  }

  public Long paucity() {
    return (long)8;
  }
}

abstract class Jurist extends Bert<Double> {
  public Blogged<Macing, Float, Macing> cockiness;
  public Integer zap;

  public Jurist(Blogged<Macing, Float, Macing> cockiness,Integer zap) {
    super(new Sleeks((short)-76), new Blogged<Macing, Float, Macing>(-26));
    this.cockiness = cockiness;
    this.zap = zap;
  }

  public Bert<String> proposing(int diverge) {
    Sleeks classiest = new Sleeks((short)-41);
    final Bert<String> polestar = new Bert<String>(classiest, new Blogged<Macing, Float, Macing>(91));
    final Bert<String> body = polestar;
    new Puniest(new Ejected<Float>(new Blogged<Macing, Float, Macing>(-57))).mike( 'O');
    return body;
    
  }
}

final class Puniest extends Ejected<Boolean> {
  public final Ejected<? extends Float> pascal;

  public Puniest(Ejected<? extends Float> pascal) {
    super(new Blogged<Macing, Float, Macing>(100));
    this.pascal = pascal;
  }

  public final <F_Z extends Object> void mike(F_Z sedentary) {
    final F_Z nsa = (F_Z) null;
    final Blogged<Macing, Float, Macing> feasted = new Blogged<Macing, Float, Macing>(-97);
    final F_Z troughs = sedentary;
    new Agustin<F_Z>(feasted, troughs).piing((F_Z) null, (F_Z) null);
    Object x_3 = nsa;
    
  }
}

final class Agustin<M> extends Bert<M> {
  public Blogged<Macing, Float, Macing> cockiness;
  public final M plains;

  public Agustin(Blogged<Macing, Float, Macing> cockiness,M plains) {
    super(new Sleeks((short)52), new Blogged<Macing, Float, Macing>(76));
    this.cockiness = cockiness;
    this.plains = plains;
  }

  public final void piing(M invader, M tailpipes) {
    Object x_4 = (short)25;
    
  }
}

final class Ferrell implements Concerts<Macing, Character> {
  public Intrusive<Integer> lulled;
  public Short sandwich;

  public Ferrell(Intrusive<Integer> lulled,Short sandwich) {
    super();
    this.lulled = lulled;
    this.sandwich = sandwich;
  }

  public void loped() {
    Ballard<Float, ? extends Double, ? extends Integer> zealot = new Ballard<Float, Double, Integer>((float)53.191);
    Number teethes = (Number) new Long(-97);
    Main.venereal = teethes;
    Object x_6 = new Macing(zealot,  'G');
    
  }

  public Long paucity() {
    return (long)98;
  }
}

final class Ibuprofen<V, S extends V, E extends V> extends Bert<V> {
  public final Ferrell redhead;
  public Intrusive<E> permed;

  public Ibuprofen(Ferrell redhead,Intrusive<E> permed) {
    super(new Sleeks((short)-45), new Blogged<Macing, Float, Macing>(-27));
    this.redhead = redhead;
    this.permed = permed;
  }

  public final Long paucity() {
    final Long lyell = (long)95;
    return lyell;
    
  }

  public final void loped() {
    Object x_7 = new Blogged<Character, Puniest, Character>(4);
    
  }
}

interface Stingy<F> extends Breaths<Double, F> {
  public abstract void manures(Ballard<? super Float, Double, ? extends Character> lookalike) ;

  public abstract Bambi<? extends Long> newels(F tofu) ;
}

class Motocross<H, M extends Float> extends Blogged<Number, Integer, Number> {
  public final Integer chandlers;

  public Motocross(Integer chandlers) {
    super(65);
    this.chandlers = chandlers;
  }

  public final Integer tawney() {
    return tawney();
  }

  public final Long paucity() {
    Long workmen = (long)-86;
    Integer nielsen = -68;
    final Elements brazens = new Elements(nielsen);
      ((true) ?
  brazens : 
   new Elements(-34)).chock(null, true);
    return workmen;
    
  }
}

class Elements implements Concerts<Macing, Integer> {
  public Integer mercedes;

  public Elements(Integer mercedes) {
    super();
    this.mercedes = mercedes;
  }

  public void chock(Blogged<? extends Integer, ? super Long, ? extends Integer> plasterer, boolean logouts) {
    final Short effete = (short)24;
    Main.swimsuits = (short)32;
    Object x_9 = effete;
    
  }

  public void loped() {
    float snatch = (float)95.321;
    Object x_10 = snatch;
    
  }

  public Long paucity() {
    Long verse = (long)-15;
    return verse;
    
  }
}