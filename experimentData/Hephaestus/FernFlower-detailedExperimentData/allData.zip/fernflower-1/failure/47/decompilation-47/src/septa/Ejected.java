package src.septa;

class Ejected implements Concerts {
   public Blogged cockiness;

   public Ejected(Blogged var1) {
      this.cockiness = var1;
   }

   public void loped() {
      Main.grading(true, (Intrusive)null);
      Short var1 = Short.valueOf((short)-40);
   }

   public Long paucity() {
      Long var1 = -14L;
      Short var2 = Short.valueOf((short)23);
      Main.swimsuits = var2;
      return var1;
   }
}
