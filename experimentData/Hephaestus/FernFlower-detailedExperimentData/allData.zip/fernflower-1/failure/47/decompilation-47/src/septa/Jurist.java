package src.septa;

abstract class Jurist extends Bert {
   public Blogged cockiness;
   public Integer zap;

   public Jurist(Blogged var1, Integer var2) {
      super(new Sleeks((short)-76), new Blogged(-26));
      this.cockiness = var1;
      this.zap = var2;
   }

   public Bert proposing(int var1) {
      Sleeks var2 = new Sleeks((short)-41);
      Bert var3 = new Bert(var2, new Blogged(91));
      (new Puniest(new Ejected(new Blogged(-57)))).mike('O');
      return var3;
   }
}
