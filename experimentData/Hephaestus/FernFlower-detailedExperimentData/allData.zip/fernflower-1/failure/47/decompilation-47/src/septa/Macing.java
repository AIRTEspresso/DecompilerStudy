package src.septa;

final class Macing implements Bambi {
   public final Ballard excluded;
   public final char nourish;

   public Macing(Ballard var1, char var2) {
      this.excluded = var1;
      this.nourish = var2;
   }

   public Long paucity() {
      return -32L;
   }

   public final Macing abscond(Character var1, Object var2) {
      return (Macing)null;
   }
}
