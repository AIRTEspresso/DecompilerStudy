package src.septa;

final class Ballard implements Bambi {
   public final Float greener;

   public Ballard(Float var1) {
      this.greener = var1;
   }

   public Long paucity() {
      Function0 var1 = () -> {
         return new Intrusive(23L);
      };
      Long var2 = ((Intrusive)var1.apply()).zenger;
      return var2;
   }
}
