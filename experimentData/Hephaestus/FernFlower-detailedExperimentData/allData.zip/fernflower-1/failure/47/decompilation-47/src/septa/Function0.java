package src.septa;

interface Function0 {
   Object apply();
}
