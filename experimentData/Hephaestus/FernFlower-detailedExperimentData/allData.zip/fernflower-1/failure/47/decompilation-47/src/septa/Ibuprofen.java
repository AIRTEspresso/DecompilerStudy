package src.septa;

final class Ibuprofen extends Bert {
   public final Ferrell redhead;
   public Intrusive permed;

   public Ibuprofen(Ferrell var1, Intrusive var2) {
      super(new Sleeks((short)-45), new Blogged(-27));
      this.redhead = var1;
      this.permed = var2;
   }

   public final Long paucity() {
      Long var1 = 95L;
      return var1;
   }

   public final void loped() {
      new Blogged(4);
   }
}
