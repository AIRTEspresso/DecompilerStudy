package src.septa;

final class Intrusive implements Bambi {
   public Long zenger;

   public Intrusive(Long var1) {
      this.zenger = var1;
   }

   public Long paucity() {
      Long var1 = -31L;
      Long var2 = 57L;
      this.zenger = var2;
      return var1;
   }

   public final Object joe(Byte var1) {
      Object var2 = null;
      return var2;
   }
}
