package src.septa;

final class Agustin extends Bert {
   public Blogged cockiness;
   public final Object plains;

   public Agustin(Blogged var1, Object var2) {
      super(new Sleeks((short)52), new Blogged(76));
      this.cockiness = var1;
      this.plains = var2;
   }

   public final void piing(Object var1, Object var2) {
      Short var3 = Short.valueOf((short)25);
   }
}
