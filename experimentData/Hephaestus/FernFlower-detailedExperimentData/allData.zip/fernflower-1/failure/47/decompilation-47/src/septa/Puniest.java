package src.septa;

final class Puniest extends Ejected {
   public final Ejected pascal;

   public Puniest(Ejected var1) {
      super(new Blogged(100));
      this.pascal = var1;
   }

   public final void mike(Object var1) {
      Object var2 = null;
      Blogged var3 = new Blogged(-97);
      (new Agustin(var3, var1)).piing((Object)null, (Object)null);
   }
}
