package src.septa;

interface Function1 {
   Object apply(Object var1);
}
