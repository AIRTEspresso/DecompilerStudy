package src.septa;

final class Sleeks implements Bambi {
   public final short automates;

   public Sleeks(short var1) {
      this.automates = var1;
   }

   public final Ejected swellest() {
      Ejected var1 = new Ejected(new Blogged(14));
      return var1;
   }

   public Long paucity() {
      Long var1 = -47L;
      return var1;
   }
}
