package src.septa;

interface Bambi {
   Long paucity();
}
