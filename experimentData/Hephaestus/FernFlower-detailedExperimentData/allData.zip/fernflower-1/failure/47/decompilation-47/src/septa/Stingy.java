package src.septa;

interface Stingy extends Breaths {
   void manures(Ballard var1);

   Bambi newels(Object var1);
}
