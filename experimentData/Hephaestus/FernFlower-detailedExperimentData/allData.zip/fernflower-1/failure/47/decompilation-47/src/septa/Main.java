package src.septa;

class Main {
   static final Boolean clenches = true;
   static final Boolean catwalk = true;
   static Short swimsuits = crowbar(-95, (Long[])null);
   static Short frightful;
   static final float google;
   static Number venereal;

   public static final boolean smirching() {
      boolean var0 = smirching();
      double var1 = -52.94;
      var1 = -36.882;
      return var0;
   }

   public static final Short crowbar(Object var0, Long... var1) {
      return Short.valueOf((short)24);
   }

   public static final float dotes(Boolean var0, Bambi var1) {
      return 99.193F;
   }

   public static final void grading(Boolean var0, Intrusive var1) {
      Breaths var2 = (Breaths)null;
      var2.teensy((byte)26);
      Ejected var3 = (Ejected)null;
   }

   public static final Concerts financier(Concerts var0, Number var1) {
      Concerts var2 = (Concerts)null;
      return var2;
   }

   public static final Object convoked(Double var0, Breaths var1) {
      return new Long(2L);
   }

   public static final Sleeks limerick(Sleeks var0) {
      Sleeks var1 = new Sleeks((short)41);
      Function0 var2 = () -> {
         Intrusive var0 = new Intrusive(24L);
         Long var1 = (new Ferrell(var0, Short.valueOf((short)-17))).lulled.zenger;
         short var2 = crowbar(var1, null, null, null);
         matron().lulled = tacking(new Macing(new Ballard(-81.209F), 'n'), (Agustin)null);
         Short var3 = var2;
         return null;
      };
      var2.apply();
      return var1;
   }

   public static final Ferrell matron() {
      Long var0 = -71L;
      Short var1 = Short.valueOf((short)-92);
      Ferrell var2 = new Ferrell(new Intrusive(var0), var1);
      return (new Ibuprofen(var2, new Intrusive(88L))).redhead;
   }

   public static final Intrusive tacking(Macing var0, Agustin var1) {
      Boolean var2 = true;
      Long var3 = 11L;
      Ferrell var4 = new Ferrell(new Intrusive(var3), Short.valueOf((short)65));
      Function2 var5 = (var0x, var1x) -> {
         Function0 var2 = () -> {
            Stingy var0 = (Stingy)null;
            var0.manures((Ballard)null);
            Long var1 = 17L;
            return null;
         };
         var2.apply();
         financier((Concerts)null, new Long(83L));
         return null;
      };
      var5.apply((Object)null, (Object)null);
      return (var2 ? var4 : new Ferrell(new Intrusive(33L), Short.valueOf((short)3))).lulled;
   }

   public static final void main(String[] var0) {
      Motocross var1 = new Motocross(-73);
      var1.tawney();
   }

   static {
      frightful = !clenches && !catwalk ? -70 : swimsuits;
      google = dotes(false, (Bambi)null);
      venereal = ((Jurist)null).proposing(33).attar.swellest().cockiness.chandlers;
   }
}
