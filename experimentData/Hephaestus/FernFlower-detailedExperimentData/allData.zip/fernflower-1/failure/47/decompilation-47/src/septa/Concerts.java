package src.septa;

interface Concerts extends Bambi {
   void loped();
}
