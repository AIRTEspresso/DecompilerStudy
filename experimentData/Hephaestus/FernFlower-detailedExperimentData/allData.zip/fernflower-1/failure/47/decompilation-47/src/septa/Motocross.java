package src.septa;

class Motocross extends Blogged {
   public final Integer chandlers;

   public Motocross(Integer var1) {
      super(65);
      this.chandlers = var1;
   }

   public final Integer tawney() {
      return this.tawney();
   }

   public final Long paucity() {
      Long var1 = -86L;
      Integer var2 = -68;
      Elements var3 = new Elements(var2);
      var3.chock((Blogged)null, true);
      return var1;
   }
}
