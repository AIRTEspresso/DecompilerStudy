package src.septa;

final class Ferrell implements Concerts {
   public Intrusive lulled;
   public Short sandwich;

   public Ferrell(Intrusive var1, Short var2) {
      this.lulled = var1;
      this.sandwich = var2;
   }

   public void loped() {
      Ballard var1 = new Ballard(53.191F);
      Long var2 = new Long(-97L);
      Main.venereal = var2;
      new Macing(var1, 'G');
   }

   public Long paucity() {
      return 98L;
   }
}
