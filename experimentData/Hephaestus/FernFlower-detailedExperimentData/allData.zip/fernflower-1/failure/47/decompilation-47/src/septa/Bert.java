package src.septa;

class Bert extends Ejected {
   public Sleeks attar;
   public Blogged cockiness;

   public Bert(Sleeks var1, Blogged var2) {
      super(new Blogged(92));
      this.attar = var1;
      this.cockiness = var2;
   }

   public void loped() {
      Concerts var1 = (Concerts)null;
   }

   public Long paucity() {
      return 8L;
   }
}
