package src.septa;

class Elements implements Concerts {
   public Integer mercedes;

   public Elements(Integer var1) {
      this.mercedes = var1;
   }

   public void chock(Blogged var1, boolean var2) {
      Short var3 = Short.valueOf((short)24);
      Main.swimsuits = Short.valueOf((short)32);
   }

   public void loped() {
      float var1 = 95.321F;
      Float var2 = var1;
   }

   public Long paucity() {
      Long var1 = -15L;
      return var1;
   }
}
