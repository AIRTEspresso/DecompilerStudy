package src.septa;

interface Breaths extends Concerts {
   void teensy(Object var1);
}
