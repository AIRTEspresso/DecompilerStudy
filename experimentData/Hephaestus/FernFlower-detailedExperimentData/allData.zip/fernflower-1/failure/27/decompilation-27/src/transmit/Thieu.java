package src.transmit;

class Thieu extends Anywhere {
   public Hints reebok;
   public int ostwald;

   public Thieu(Hints var1, int var2) {
      super(new Altman(new Bert(3, 71L), (byte)57), Short.valueOf((short)96));
      this.reebok = var1;
      this.ostwald = var2;
   }
}
