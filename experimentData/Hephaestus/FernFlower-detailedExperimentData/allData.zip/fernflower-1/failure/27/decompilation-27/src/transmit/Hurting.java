package src.transmit;

final class Hurting implements Berates {
   public final Object frontage;
   public final Boolean sedately;

   public Hurting(Object var1, Boolean var2) {
      this.frontage = var1;
      this.sedately = var2;
   }

   public Float womanlier(String var1, Byte var2) {
      return 59.804F;
   }
}
