package src.transmit;

abstract class Donaldson extends Availed {
   public final Anywhere fluttery;
   public Double lobster;

   public Donaldson(Anywhere var1, Double var2) {
      super("mediaeval", (byte)-77);
      this.fluttery = var1;
      this.lobster = var2;
   }

   public Float womanlier(String var1, Byte var2) {
      return -66.501F;
   }
}
