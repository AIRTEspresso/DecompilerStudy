package src.transmit;

class Availed implements Berates {
   public final String messed;
   public byte oft;

   public Availed(String var1, byte var2) {
      this.messed = var1;
      this.oft = var2;
   }

   public Float womanlier(String var1, Byte var2) {
      Float var3 = 87.724F;
      return var3;
   }
}
