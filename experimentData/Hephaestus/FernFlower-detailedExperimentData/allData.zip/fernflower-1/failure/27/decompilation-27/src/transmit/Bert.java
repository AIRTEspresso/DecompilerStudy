package src.transmit;

class Bert implements Berates {
   public Integer immersion;
   public Object clotting;

   public Bert(Integer var1, Object var2) {
      this.immersion = var1;
      this.clotting = var2;
   }

   public Float womanlier(String var1, Byte var2) {
      Daphne var3 = (Daphne)null;
      Boolean var4 = true;
      Hurting var5 = new Hurting(this.clotting, var4);
      this.clotting = var5.frontage;
      return var3.muddle;
   }

   public final String suffer() {
      String var1 = (new Availed("huston", (byte)-34)).messed;
      return var1;
   }
}
