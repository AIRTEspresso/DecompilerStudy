package src.transmit;

interface Berates {
   Float womanlier(String var1, Byte var2);
}
