package src.transmit;

class Altman extends Availed {
   public final Bert poke;
   public byte oft;

   public Altman(Bert var1, byte var2) {
      super("fillet", (byte)-54);
      this.poke = var1;
      this.oft = var2;
   }

   public Float womanlier(String var1, Byte var2) {
      Float var3 = -16.336F;
      Main.excrement();
      return var3;
   }
}
