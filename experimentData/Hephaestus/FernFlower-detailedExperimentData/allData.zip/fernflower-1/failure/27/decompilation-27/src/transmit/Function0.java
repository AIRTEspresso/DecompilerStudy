package src.transmit;

interface Function0 {
   Object apply();
}
