package src.transmit;

class Anywhere extends Daphne {
   public final Altman keynoting;
   public Short buzzword;

   public Anywhere(Altman var1, Short var2) {
      super(36.324F, false);
      this.keynoting = var1;
      this.buzzword = var2;
   }

   public double superiors(Integer var1) {
      byte var2 = -39;
      this.keynoting.oft = var2;
      return 38.637;
   }

   public final Anywhere keenest() {
      Anywhere var1 = (Anywhere)null;
      return var1;
   }
}
