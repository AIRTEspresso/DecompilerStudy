package src.transmit;

class Main {
   static Berates ornerier = (Berates)null;
   static final Float tightly;
   static final Float utters;
   static Altman upbraided;
   static Byte honed;
   static long hubbies;

   public static final Integer shinnies(Object var0, Object var1) {
      Function2 var2 = (var0x, var1x) -> {
         Integer var2 = (Integer)null;
         Bert var3 = new Bert(var2, var0x);
         Bert var4 = (new Altman(var3, (byte)10)).poke;
         pureed(var1x, false);
         return var4;
      };
      Object var3 = null;
      Boolean var4 = false;
      Integer var5 = (Integer)null;
      return ((Bert)var2.apply(var3, var4 ? var5 : (Integer)null)).immersion;
   }

   public static final void excrement() {
      Berates var0 = (Berates)null;
      ornerier = var0;
      new Availed("doldrums", (byte)-67);
   }

   public static final void pureed(Integer var0, boolean var1) {
      Width var2 = (Width)null;
      Short var4 = Short.valueOf((short)24);
      var2.mastoids(-55, var4);
   }

   public static final byte redraws() {
      Hurting var0 = new Hurting(new Object(), false);
      Float var2 = -93.956F;
      return var0.sedately ? (new Altman(new Bert(-95, var2), (byte)68)).oft : 49;
   }

   public static final Bert abundance() {
      long var0 = hubbies;
      return new Bert(37, new Hints(var0, honed));
   }

   public static final Boolean weakening() {
      return false;
   }

   public static final void main(String[] var0) {
      Integer var1 = -86;
      Long var2 = new Long(27L);
      new Bert(17, new Long(15L));
      if (weakening()) {
         new Bert(var1, var2);
      } else {
         new Bert(-31, new Long(-86L));
      }

   }

   static {
      tightly = ornerier.womanlier("uris", (byte)47);
      utters = tightly;
      upbraided = ((Donaldson)null).fluttery.keynoting;
      honed = upbraided.oft;
      hubbies = (new Hints((new Thieu(new Hints(37L, (byte)66), 74)).reebok.staffer, (byte)47)).staffer;
   }
}
