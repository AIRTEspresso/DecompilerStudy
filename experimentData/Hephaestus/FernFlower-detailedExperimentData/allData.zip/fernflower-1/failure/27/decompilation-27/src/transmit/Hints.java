package src.transmit;

final class Hints extends Altman {
   public long staffer;
   public byte oft;

   public Hints(long var1, byte var3) {
      super(new Bert(-84, 'K'), (byte)-89);
      this.staffer = var1;
      this.oft = var3;
   }

   public final Donaldson solicits() {
      return this.solicits();
   }
}
