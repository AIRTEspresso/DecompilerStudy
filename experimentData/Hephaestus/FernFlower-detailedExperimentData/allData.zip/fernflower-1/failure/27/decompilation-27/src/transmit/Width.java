package src.transmit;

interface Width extends Berates {
   Double mastoids(Integer var1, Short var2);

   Object gains();
}
