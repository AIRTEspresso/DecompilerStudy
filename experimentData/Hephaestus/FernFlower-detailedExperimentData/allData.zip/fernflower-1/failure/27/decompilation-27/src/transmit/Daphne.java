package src.transmit;

abstract class Daphne implements Berates {
   public final Float muddle;
   public final Boolean satiated;

   public Daphne(Float var1, Boolean var2) {
      this.muddle = var1;
      this.satiated = var2;
   }

   public Float womanlier(String var1, Byte var2) {
      return 89.538F;
   }
}
