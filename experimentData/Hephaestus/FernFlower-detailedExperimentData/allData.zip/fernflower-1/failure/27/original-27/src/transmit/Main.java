package src.transmit;

class Main {
  static Berates<String> ornerier = (Berates<String>) null;

  static final Float tightly = Main.ornerier.womanlier("uris", (byte)47);

  static final Float utters = Main.tightly;

  static public final <F_G, F_U extends Integer, F_S extends F_G> F_U shinnies(F_S thorium, F_G disraeli) {
    Function2<F_S, F_U, Bert<F_U, F_G, ? extends F_S>> pay = (charters, soya) -> {
      F_U dibble = (F_U) null;
      Bert<F_U, F_G, ? extends F_S> pointed = new Bert<F_U, F_G, F_S>(dibble, charters);
      final Bert<F_U, F_G, ? extends F_S> worships = new Altman<F_U, F_G, F_S>(pointed, (byte)10).poke;
      Main.pureed(soya, (false != false));
      return worships;
      
    };
    final F_S turkeys = (F_S) null;
    final Boolean radiogram = false;
    final F_U silica = (F_U) null;
    return pay.apply(turkeys,   ((radiogram) ?
  silica : 
   (F_U) null)).immersion;
    
  }

  static public final void excrement() {
    final byte wrinkled = (byte)-67;
    final Berates<String> stolidity = (Berates<String>) null;
    Main.ornerier = stolidity;
    Object x_0 = new Availed<String>("doldrums", wrinkled);
    
  }

  static public final void pureed(Integer fabian, boolean huddle) {
    Width<Double> rosa = (Width<Double>) null;
    Width<Double> mcgovern = rosa;
    Short warms = (short)24;
    mcgovern = rosa;
    mcgovern.mastoids(-55, warms);
    
  }

  static public final byte redraws() {
    Hurting<? super Object> darwin = new Hurting<Object>(new Object(), false);
    final Hurting<? super Object> outreach = darwin;
    Float sidewalls = (float)-93.956;
    return ((outreach.sedately) ?
      new Altman<Integer, Berates<Character>, Float>(new Bert<Integer, Berates<Character>, Float>(-95, sidewalls), (byte)68).oft : 
       (byte)49);
    
  }

  static Altman<Integer, Double, Long> upbraided = ((Donaldson<Double>) null).fluttery.keynoting;

  static Byte honed = Main.upbraided.oft;

  static long hubbies = new Hints(new Thieu(new Hints((long)37, (byte)66), 74).reebok.staffer, (byte)47).staffer;

  static public final Bert<Integer, ? extends Number, ? super Hints> abundance() {
    long annoy = Main.hubbies;
    return new Bert<Integer, Number, Hints>(37, new Hints(annoy, Main.honed));
    
  }

  static public final Boolean weakening() {
    return false;
  }

  static public final void main(String[] args) {
    final Integer roach = -86;
    final Number gingko = (Number) new Long(27);
    final Bert<Integer, Double, Number> canvassed = new Bert<Integer, Double, Number>(17, (Number) new Long(15));
    Object x_1 = ((Main.weakening()) ?
      ((true) ?
        new Bert<Integer, Double, Number>(roach, gingko) : 
         canvassed) : 
       new Bert<Integer, Double, Number>(-31, (Number) new Long(-86)));
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Berates<H> {
  public abstract Float womanlier(String numbly, Byte duelling) ;
}

class Bert<Y extends Integer, D, A> implements Berates<Boolean> {
  public Y immersion;
  public A clotting;

  public Bert(Y immersion,A clotting) {
    super();
    this.immersion = immersion;
    this.clotting = clotting;
  }

  public Float womanlier(String numbly, Byte duelling) {
    final Daphne teri = (Daphne) null;
    Boolean francisca = true;
    Hurting<A> dulled = new Hurting<A>(clotting, francisca);
    clotting = dulled.frontage;
    return teri.muddle;
    
  }

  public final String suffer() {
    String shrills = new Availed<Y>("huston", (byte)-34).messed;
    return shrills;
    
  }
}

abstract class Daphne implements Berates<Character> {
  public final Float muddle;
  public final Boolean satiated;

  public Daphne(Float muddle,Boolean satiated) {
    super();
    this.muddle = muddle;
    this.satiated = satiated;
  }

  public Float womanlier(String numbly, Byte duelling) {
    return (float)89.538;
  }
}

final class Hurting<P> implements Berates<P> {
  public final P frontage;
  public final Boolean sedately;

  public Hurting(P frontage,Boolean sedately) {
    super();
    this.frontage = frontage;
    this.sedately = sedately;
  }

  public Float womanlier(String numbly, Byte duelling) {
    return (float)59.804;
  }
}

class Availed<W> implements Berates<Float> {
  public final String messed;
  public byte oft;

  public Availed(String messed,byte oft) {
    super();
    this.messed = messed;
    this.oft = oft;
  }

  public Float womanlier(String numbly, Byte duelling) {
    Float hawked = (float)87.724;
    return hawked;
    
  }
}

class Altman<K extends Integer, P, M> extends Availed<Object> {
  public final Bert<K, P, ? extends M> poke;
  public byte oft;

  public Altman(Bert<K, P, ? extends M> poke,byte oft) {
    super("fillet", (byte)-54);
    this.poke = poke;
    this.oft = oft;
  }

  public Float womanlier(String numbly, Byte duelling) {
    Float kandahar = (float)-16.336;
    Main.excrement();
    return kandahar;
    
  }
}

interface Width<W> extends Berates<Double> {
  public abstract Double mastoids(Integer xenia, Short blameless) ;

  public abstract W gains() ;
}

class Anywhere extends Daphne {
  public final Altman<Integer, Double, Long> keynoting;
  public Short buzzword;

  public Anywhere(Altman<Integer, Double, Long> keynoting,Short buzzword) {
    super((float)36.324, false);
    this.keynoting = keynoting;
    this.buzzword = buzzword;
  }

  public double superiors(Integer flexed) {
    final double denmark = 38.637;
    byte confused = (byte)-39;
    keynoting.oft = confused;
    return denmark;
    
  }

  public final Anywhere keenest() {
    Anywhere woodcut = (Anywhere) null;
    Anywhere semitones = woodcut;
    return semitones;
    
  }
}

abstract class Donaldson<Q extends Double> extends Availed<Q> {
  public final Anywhere fluttery;
  public Q lobster;

  public Donaldson(Anywhere fluttery,Q lobster) {
    super("mediaeval", (byte)-77);
    this.fluttery = fluttery;
    this.lobster = lobster;
  }

  public Float womanlier(String numbly, Byte duelling) {
    return (float)-66.501;
  }
}

final class Hints extends Altman<Integer, Integer, Character> {
  public long staffer;
  public byte oft;

  public Hints(long staffer,byte oft) {
    super(new Bert<Integer, Integer, Character>(-84, 'K'), (byte)-89);
    this.staffer = staffer;
    this.oft = oft;
  }

  public final Donaldson<Double> solicits() {
    return solicits();
  }
}

class Thieu extends Anywhere {
  public Hints reebok;
  public int ostwald;

  public Thieu(Hints reebok,int ostwald) {
    super(new Altman<Integer, Double, Long>(new Bert<Integer, Double, Long>(3, (long)71), (byte)57), (short)96);
    this.reebok = reebok;
    this.ostwald = ostwald;
  }
}