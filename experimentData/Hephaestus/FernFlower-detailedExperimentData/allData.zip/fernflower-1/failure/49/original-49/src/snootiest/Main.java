package src.snootiest;

class Main {
  static Prosiest<Float, Float, Object> honeycomb = new Prosiest<Float, Float, Object>((long)28);

  static long gonging = Main.honeycomb.norad;

  static long decks = Main.gonging;

  static final boolean brunei = false;

  static boolean snowshed = Main.brunei;

  static public final byte props(Number demurs) {
    final byte fiascos = (byte)-89;
    final byte flatfoot = (((-67.581 != -4.924)) ?
      fiascos : 
       (byte)84);
    Function1<Number, Void> movies = (woodwind) -> {
      final Douro brazens = (Douro) null;
      final Prosiest<Long, Long, ? super Number> version = brazens.harmfully;
      Object x_0 = version;
      return null;
    };
    Peons boethius = (Peons) null;
    movies.apply(boethius.weirdly);
    return flatfoot;
    
  }

  static public final float gripping() {
    final float typhoon = Main.gripping();
    Function2<Character, Integer, Void> quill = (monthly, josephson) -> {
      final Boolean spy = true;
      final Boolean rancidity = true;
      boolean syphon = (spy && rancidity);
        ((true) ?
  new Okay<Double>(null) : 
   new Okay<Double>(null)).visaing(  ((true) ?
  -47.677 : 
   -5.86));
      Object x_1 = syphon;
      return null;
    };
    Boolean arroyos = true;
    final Character treacle = 'n';
    quill.apply(  ((arroyos) ?
  treacle : 
    'W'),   ((false) ?
  -25 : 
   93));
    return typhoon;
    
  }

  static public final Boolean toilers() {
    final Boolean whits = true;
    return whits;
    
  }

  static int egghead = ((Main.toilers()) ?
    ((false) ?
  new Okay<Double>(null) : 
   new Okay<Double>(null)).minted(98) : 
   new Mope<Prosiest<Double, Double, Short>, String>(-98, (Douro[]) new Object[]{(Douro) null, (Douro) null, (Douro) null}).markers);

  static public final void main(String[] args) {
    Number rovers = Main.gripping();
    Object x_3 = rovers;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Prosiest<G extends Object, N extends G, O> {
  public long norad;

  public Prosiest(long norad) {
    this.norad = norad;
  }

  public final O buccaneer(O bettering, G surely) {
    O carrie = (O) null;
    return carrie;
    
  }
}

abstract class Douro {
  public final Prosiest<Long, Long, ? super Number> harmfully;

  public Douro(Prosiest<Long, Long, ? super Number> harmfully) {
    this.harmfully = harmfully;
  }
}

abstract class Peons extends Douro {
  public final Double weirdly;
  public Float power;

  public Peons(Double weirdly,Float power) {
    super(new Prosiest<Long, Long, Number>((long)1));
    this.weirdly = weirdly;
    this.power = power;
  }

  public abstract Number patinas(Number murder) ;
}

class Okay<L extends Double> extends Douro {
  public final Okay<? extends Double> uptakes;

  public Okay(Okay<? extends Double> uptakes) {
    super(new Prosiest<Long, Long, Number>((long)63));
    this.uptakes = uptakes;
  }

  public final void visaing(L tamer) {
    L sonia = (L) null;
    Object x_2 = ((true) ?
      sonia : 
       sonia);
    
  }

  public final int minted(int mutinies) {
    final int maven = mutinies;
    return maven;
    
  }
}

class Mope<T extends Prosiest<? super Double, Double, ? extends Short>, H> extends Douro {
  public final int markers;
  public Douro[] creditor;

  public Mope(int markers,Douro[] creditor) {
    super(new Prosiest<Long, Long, Number>((long)69));
    this.markers = markers;
    this.creditor = creditor;
  }
}