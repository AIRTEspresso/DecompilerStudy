package src.snootiest;

class Okay extends Douro {
   public final Okay uptakes;

   public Okay(Okay var1) {
      super(new Prosiest(63L));
      this.uptakes = var1;
   }

   public final void visaing(Double var1) {
      Double var2 = (Double)null;
   }

   public final int minted(int var1) {
      return var1;
   }
}
