package src.snootiest;

interface Function0 {
   Object apply();
}
