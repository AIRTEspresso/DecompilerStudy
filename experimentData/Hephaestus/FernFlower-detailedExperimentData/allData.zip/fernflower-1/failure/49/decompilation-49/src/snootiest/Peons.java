package src.snootiest;

abstract class Peons extends Douro {
   public final Double weirdly;
   public Float power;

   public Peons(Double var1, Float var2) {
      super(new Prosiest(1L));
      this.weirdly = var1;
      this.power = var2;
   }

   public abstract Number patinas(Number var1);
}
