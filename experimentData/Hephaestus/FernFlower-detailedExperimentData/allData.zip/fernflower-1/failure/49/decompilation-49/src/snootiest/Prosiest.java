package src.snootiest;

final class Prosiest {
   public long norad;

   public Prosiest(long var1) {
      this.norad = var1;
   }

   public final Object buccaneer(Object var1, Object var2) {
      Object var3 = null;
      return var3;
   }
}
