package src.snootiest;

abstract class Douro {
   public final Prosiest harmfully;

   public Douro(Prosiest var1) {
      this.harmfully = var1;
   }
}
