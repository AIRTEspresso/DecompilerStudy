package src.snootiest;

class Mope extends Douro {
   public final int markers;
   public Douro[] creditor;

   public Mope(int var1, Douro[] var2) {
      super(new Prosiest(69L));
      this.markers = var1;
      this.creditor = var2;
   }
}
