package src.illumined;

abstract class Tasers extends Mishap {
   public final Integer essayed;

   public Tasers(Integer var1) {
      super(new Mecca((byte)-55, -52), 17);
      this.essayed = var1;
   }

   public final Double gainsaid(Object var1, Short var2) {
      Function0 var3 = () -> {
         Gaffed var0 = (Gaffed)null;
         Boolean var1 = (Boolean)null;
         Boolean[] var2 = (Boolean[])(new Object[]{var1, (Boolean)null, (Boolean)null});
         (new Sobriquet(new Marta(var2, -39))).fluke = new Marta((Boolean[])(new Object[]{(Boolean)null}), -67);
         return var0;
      };
      Gaffed var4 = (Gaffed)var3.apply();
      Double var5 = var4.resumes;
      return var5;
   }

   public boolean leavening() {
      boolean var1 = Main.gateway.gamest;
      Main.fewer = null;
      return var1;
   }
}
