package src.illumined;

class Marta extends Potty {
   public Boolean[] geegaw;
   public final Integer essayed;

   public Marta(Boolean[] var1, Integer var2) {
      super(-72, true);
      this.geegaw = var1;
      this.essayed = var2;
   }

   public Boolean goodies(Object var1, Short... var2) {
      Boolean var3 = false;
      this.geegaw = null;
      return var3;
   }

   public Double gainsaid(Object var1, Short var2) {
      Gaffed var3 = (Gaffed)null;
      Double var4 = var3.resumes;
      return var4;
   }
}
