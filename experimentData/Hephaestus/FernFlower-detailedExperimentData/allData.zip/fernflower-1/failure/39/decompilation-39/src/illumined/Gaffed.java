package src.illumined;

abstract class Gaffed extends Potty {
   public Double resumes;
   public final boolean gamest;

   public Gaffed(Double var1, boolean var2) {
      super(-70, false);
      this.resumes = var1;
      this.gamest = var2;
   }

   public Boolean goodies(Object var1, Short... var2) {
      return false;
   }
}
