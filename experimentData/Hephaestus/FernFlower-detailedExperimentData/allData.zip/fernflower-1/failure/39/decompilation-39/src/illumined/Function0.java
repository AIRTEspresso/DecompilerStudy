package src.illumined;

interface Function0 {
   Object apply();
}
