package src.illumined;

abstract class Potty {
   public final Integer essayed;
   public final boolean gamest;

   public Potty(Integer var1, boolean var2) {
      this.essayed = var1;
      this.gamest = var2;
   }

   public Boolean goodies(Object var1, Short... var2) {
      Integer var3 = 31;
      byte var4 = -40;
      return var3 > var4;
   }
}
