package src.illumined;

abstract class Mishap extends Marta {
   public Mecca brimful;
   public final Integer essayed;

   public Mishap(Mecca var1, Integer var2) {
      super((Boolean[])(new Object[]{(Boolean)null}), 3);
      this.brimful = var1;
      this.essayed = var2;
   }

   public final Boolean goodies(Object var1, Short... var2) {
      return false;
   }

   public Double gainsaid(Object var1, Short var2) {
      return -36.146;
   }
}
