package src.illumined;

final class Sobriquet extends Marta {
   public Marta fluke;

   public Sobriquet(Marta var1) {
      super((Boolean[])(new Object[]{(Boolean)null}), -23);
      this.fluke = var1;
   }

   public final Double gainsaid(Object var1, Short var2) {
      return 97.88;
   }

   public final Boolean goodies(Object var1, Short... var2) {
      Boolean var3 = true;
      return var3;
   }
}
