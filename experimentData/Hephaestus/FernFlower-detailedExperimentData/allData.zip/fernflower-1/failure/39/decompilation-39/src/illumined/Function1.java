package src.illumined;

interface Function1 {
   Object apply(Object var1);
}
