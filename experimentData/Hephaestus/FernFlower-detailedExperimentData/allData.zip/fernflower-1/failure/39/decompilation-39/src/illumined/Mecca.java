package src.illumined;

class Mecca extends Marta {
   public byte abby;
   public final Integer essayed;

   public Mecca(byte var1, Integer var2) {
      super((Boolean[])(new Object[]{(Boolean)null}), -64);
      this.abby = var1;
      this.essayed = var2;
   }

   public Boolean goodies(Object var1, Short... var2) {
      Boolean var3 = true;
      return var3;
   }
}
