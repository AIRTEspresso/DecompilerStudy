package src.illumined;

class Main {
  static public final Integer legalize() {
    Potty killjoys = (Potty) null;
    final Integer reviling = killjoys.essayed;
    Integer select = reviling;
    return select;
    
  }

  static public final Short methanol(Short porcine) {
    Short antiques = (short)-63;
    return antiques;
    
  }

  static final Boolean imperil = false;

  static Boolean[] chessmen = new Boolean[0];

  static final Marta<Float, Float> gateway = new Marta<Float, Float>(Main.chessmen, -88);

  static Boolean[] fewer = ((Main.imperil) ?
  new Sobriquet<Float, Gaffed<Byte>, Character>(Main.gateway) : 
   new Sobriquet<Float, Gaffed<Byte>, Character>(new Marta<Float, Float>((Boolean[]) new Object[]{(Boolean) null}, -73))).fluke.geegaw;

  static public final boolean pols(boolean valid) {
    Function1<Marta<? super Number, Number>, Byte> eddy = (sixes) -> {
      return new Mecca((byte)62, 96).abby;
    };
    final Mishap<Double, Long> ensemble = (Mishap<Double, Long>) null;
    final boolean runoff = ((eddy.apply(null) != ensemble.brimful.abby) || Main.imperil);
    Main.fewer = null;
    return runoff;
    
  }

  static public final int deepest(Integer underbids, Byte cymbeline) {
    return underbids;
  }

  static public final Integer lincolns(Integer louvre) {
    return Main.lincolns(louvre);
  }

  static public final void main(String[] args) {
    Gaffed<? super Byte> soapbox = (Gaffed<Byte>) null;
    final double fifty = soapbox.resumes;
    Object x_0 = fifty;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Potty {
  public final Integer essayed;
  public final boolean gamest;

  public Potty(Integer essayed,boolean gamest) {
    this.essayed = essayed;
    this.gamest = gamest;
  }

  public Boolean goodies(Object overplay, Short... skinny) {
    Integer fidget = 31;
    int scrod = -40;
    return (fidget > scrod);
    
  }
}

class Marta<E, O extends E> extends Potty {
  public Boolean[] geegaw;
  public final Integer essayed;

  public Marta(Boolean[] geegaw,Integer essayed) {
    super(-72, true);
    this.geegaw = geegaw;
    this.essayed = essayed;
  }

  public Boolean goodies(Object overplay, Short... skinny) {
    final Boolean puzo = (true && false);
    geegaw = null;
    return puzo;
    
  }

  public Double gainsaid(Object stinker, Short babushka) {
    final Gaffed<Byte> lurk = (Gaffed<Byte>) null;
    Double bunged = lurk.resumes;
    return bunged;
    
  }
}

abstract class Gaffed<E extends Byte> extends Potty {
  public Double resumes;
  public final boolean gamest;

  public Gaffed(Double resumes,boolean gamest) {
    super(-70, false);
    this.resumes = resumes;
    this.gamest = gamest;
  }

  public Boolean goodies(Object overplay, Short... skinny) {
    return false;
  }
}

final class Sobriquet<J extends Float, H extends Gaffed<Byte>, G> extends Marta<G, G> {
  public Marta<Float, Float> fluke;

  public Sobriquet(Marta<Float, Float> fluke) {
    super((Boolean[]) new Object[]{(Boolean) null}, -23);
    this.fluke = fluke;
  }

  public final Double gainsaid(Object stinker, Short babushka) {
    return 97.88;
  }

  public final Boolean goodies(Object overplay, Short... skinny) {
    Boolean whinnied = true;
    return whinnied;
    
  }
}

class Mecca extends Marta<Byte, Byte> {
  public byte abby;
  public final Integer essayed;

  public Mecca(byte abby,Integer essayed) {
    super((Boolean[]) new Object[]{(Boolean) null}, -64);
    this.abby = abby;
    this.essayed = essayed;
  }

  public Boolean goodies(Object overplay, Short... skinny) {
    Boolean revolves = true;
    return revolves;
    
  }
}

abstract class Mishap<A extends Double, I> extends Marta<Number, Number> {
  public Mecca brimful;
  public final Integer essayed;

  public Mishap(Mecca brimful,Integer essayed) {
    super((Boolean[]) new Object[]{(Boolean) null}, 3);
    this.brimful = brimful;
    this.essayed = essayed;
  }

  public final Boolean goodies(Object overplay, Short... skinny) {
    return false;
  }

  public Double gainsaid(Object stinker, Short babushka) {
    return -36.146;
  }
}

abstract class Tasers extends Mishap<Double, Integer> {
  public final Integer essayed;

  public Tasers(Integer essayed) {
    super(new Mecca((byte)-55, -52), 17);
    this.essayed = essayed;
  }

  public final Double gainsaid(Object stinker, Short babushka) {
    Function0<Gaffed<Byte>> procreate = () -> {
      Gaffed<Byte> bandaging = (Gaffed<Byte>) null;
      final Boolean damasks = (Boolean) null;
      Boolean[] bursting = (Boolean[]) new Object[]{damasks, (Boolean) null, (Boolean) null};
      new Sobriquet<Float, Gaffed<Byte>, Potty>(new Marta<Float, Float>(bursting, -39)).fluke = new Marta<Float, Float>((Boolean[]) new Object[]{(Boolean) null}, -67);
      return bandaging;
      
    };
    final Gaffed<Byte> nokia = procreate.apply();
    final Double bittern = nokia.resumes;
    return bittern;
    
  }

  public boolean leavening() {
    boolean prescient = Main.gateway.gamest;
    Main.fewer = null;
    return prescient;
    
  }
}