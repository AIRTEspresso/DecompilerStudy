package src.affair;

class Main {
  static public final byte christine() {
    return (byte)67;
  }

  static final byte cairo = (byte)-14;

  static byte deceased = Main.cairo;

  static public final Object bowstring(Double pinprick, Double francine) {
    return 89;
  }

  static public final float tailspins(Boolean giggles, float chomped) {
    return (float)56.5;
  }

  static final Double backs = -8.233;

  static final Double airships = Main.backs;

  static public final void sclerosis(boolean mooed, Character siphon) {
    byte bandaging = (byte)-37;
    final Resin<Byte, Tabued<Byte>> limits = Main.germicide();
    limits.barrings(null, null);
    Object x_0 = bandaging;
    
  }

  static public final Resin<Byte, Tabued<Byte>> germicide() {
    Resin<Byte, Tabued<Byte>> refills = (Resin<Byte, Tabued<Byte>>) null;
    Integer flamings = 94;
    Resin<Byte, Tabued<Byte>> balloon = new Babbler(refills, flamings).atrophy;
    return balloon;
    
  }

  static public final <F_B> F_B danes(F_B monoliths) {
    Function2<F_B, Byte, F_B> gouty = (clung, postdates) -> {
      F_B aureolas = (F_B) null;
      F_B bounced = aureolas;
      return bounced;
      
    };
    Function0<F_B> gargle = () -> {
      final F_B skid = (F_B) null;
      return skid;
      
    };
    Byte snap = Main.cairo;
    F_B eloy = gouty.apply(gargle.apply(), snap);
    return eloy;
    
  }

  static public final void main(String[] args) {
    Spritzes<Float> soyuz = (Spritzes<Float>) null;
    Ora<Long, Double> groveled = soyuz.sputters(soyuz.celtic);
    Object x_2 = groveled;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Purchases {
  public Double amoebic(Double dyke) {
    return dyke;
  }

  public boolean splitting(byte brimstone, Integer appleton) {
    byte naked = Main.christine();
    final byte endowment = Main.christine();
    naked = endowment;
    return splitting(naked, 46);
    
  }
}

class Bandiest<H> extends Purchases {
  public final H factoring;
  public long costars;

  public Bandiest(H factoring,long costars) {
    super();
    this.factoring = factoring;
    this.costars = costars;
  }

  public final Double amoebic(Double dyke) {
    return dyke;
  }

  public boolean splitting(byte brimstone, Integer appleton) {
    return true;
  }
}

class Beam extends Bandiest<Byte> {
  public Beam() {
    super((byte)-37, (long)83);
}

  public final boolean splitting(byte brimstone, Integer appleton) {
    Boolean sobering = true;
    final Integer iberian = -96;
    final Integer louvers = -19;
    Main.deceased = (byte)26;
    return splitting(Main.deceased,   ((sobering) ?
  iberian : 
   louvers));
    
  }

  public Float overeat(Float bumpkins) {
    return bumpkins;
  }
}

abstract class Tabued<P> extends Purchases {
  public P reeled;
  public P knopf;

  public Tabued(P reeled,P knopf) {
    super();
    this.reeled = reeled;
    this.knopf = knopf;
  }

  public final boolean splitting(byte brimstone, Integer appleton) {
    final Integer vigilant = appleton;
    final List<Double, P> injuries = (List<Double, P>) null;
    final Integer rue = injuries.godsons;
    Main.sclerosis(true, ((Ora<Long, P>) null).angst);
    return (vigilant <= rue);
    
  }

  public final Double amoebic(Double dyke) {
    Double narrowly = -3.770;
    return narrowly;
    
  }
}

abstract class List<W extends Double, M> extends Beam {
  public final Integer godsons;
  public final Integer mulder;

  public List(Integer godsons,Integer mulder) {
    super();
    this.godsons = godsons;
    this.mulder = mulder;
  }

  public final Float overeat(Float bumpkins) {
    Float lashes = (float)94.790;
    final Float domains = (float)-36.790;
    lashes = domains;
    return lashes;
    
  }
}

interface Resin<H extends Byte, B extends Tabued<? extends H>> {
  public abstract void barrings(Tabued<? super H> malaysia, Bandiest<? super B> somme) ;

  public abstract H placed() ;
}

final class Babbler extends List<Double, Character> {
  public final Resin<Byte, Tabued<Byte>> atrophy;
  public final Integer mulder;

  public Babbler(Resin<Byte, Tabued<Byte>> atrophy,Integer mulder) {
    super(-39, -77);
    this.atrophy = atrophy;
    this.mulder = mulder;
  }

  public final Number murrow() {
    return (Number) new Long(7);
  }
}

abstract class Ora<L extends Long, U> extends Bandiest<Character> {
  public final Character angst;
  public final long untidy;

  public Ora(Character angst,long untidy) {
    super( 'e', (long)-93);
    this.angst = angst;
    this.untidy = untidy;
  }

  public abstract U usurer(U whip) ;
}

abstract class Laocoon implements Resin<Byte, Tabued<Byte>> {
  public byte phallus;

  public Laocoon(byte phallus) {
    super();
    this.phallus = phallus;
  }

  public void barrings(Tabued<? super Byte> malaysia, Bandiest<? super Tabued<Byte>> somme) {
    final List<? extends Double, Purchases> coasts = (List<Double, Purchases>) null;
    Object x_1 = coasts;
    
  }
}

abstract class Spritzes<O> extends Ora<Long, Float> {
  public final O celtic;
  public final O teletype;

  public Spritzes(O celtic,O teletype) {
    super( '5', (long)-48);
    this.celtic = celtic;
    this.teletype = teletype;
  }

  public abstract Ora<Long, Double> sputters(O foraying) ;

  public Float usurer(Float whip) {
    return whip;
  }
}