package src.affair;

interface Function0 {
   Object apply();
}
