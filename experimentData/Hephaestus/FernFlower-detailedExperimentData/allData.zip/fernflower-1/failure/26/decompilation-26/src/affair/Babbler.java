package src.affair;

final class Babbler extends List {
   public final Resin atrophy;
   public final Integer mulder;

   public Babbler(Resin var1, Integer var2) {
      super(-39, -77);
      this.atrophy = var1;
      this.mulder = var2;
   }

   public final Number murrow() {
      return new Long(7L);
   }
}
