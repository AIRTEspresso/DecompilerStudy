package src.affair;

abstract class Spritzes extends Ora {
   public final Object celtic;
   public final Object teletype;

   public Spritzes(Object var1, Object var2) {
      super('5', -48L);
      this.celtic = var1;
      this.teletype = var2;
   }

   public abstract Ora sputters(Object var1);

   public Float usurer(Float var1) {
      return var1;
   }
}
