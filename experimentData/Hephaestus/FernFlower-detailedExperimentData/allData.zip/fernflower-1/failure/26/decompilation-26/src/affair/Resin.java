package src.affair;

interface Resin {
   void barrings(Tabued var1, Bandiest var2);

   Byte placed();
}
