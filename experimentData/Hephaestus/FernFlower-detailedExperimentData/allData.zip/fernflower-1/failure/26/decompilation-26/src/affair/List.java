package src.affair;

abstract class List extends Beam {
   public final Integer godsons;
   public final Integer mulder;

   public List(Integer var1, Integer var2) {
      this.godsons = var1;
      this.mulder = var2;
   }

   public final Float overeat(Float var1) {
      Float var2 = 94.79F;
      Float var3 = -36.79F;
      return var3;
   }
}
