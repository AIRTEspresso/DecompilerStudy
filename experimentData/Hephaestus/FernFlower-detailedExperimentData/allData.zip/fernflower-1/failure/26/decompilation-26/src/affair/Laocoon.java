package src.affair;

abstract class Laocoon implements Resin {
   public byte phallus;

   public Laocoon(byte var1) {
      this.phallus = var1;
   }

   public void barrings(Tabued var1, Bandiest var2) {
      List var3 = (List)null;
   }
}
