package src.affair;

abstract class Ora extends Bandiest {
   public final Character angst;
   public final long untidy;

   public Ora(Character var1, long var2) {
      super('e', -93L);
      this.angst = var1;
      this.untidy = var2;
   }

   public abstract Object usurer(Object var1);
}
