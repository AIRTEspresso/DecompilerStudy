package src.affair;

abstract class Tabued extends Purchases {
   public Object reeled;
   public Object knopf;

   public Tabued(Object var1, Object var2) {
      this.reeled = var1;
      this.knopf = var2;
   }

   public final boolean splitting(byte var1, Integer var2) {
      List var4 = (List)null;
      Integer var5 = var4.godsons;
      Main.sclerosis(true, ((Ora)null).angst);
      return var2 <= var5;
   }

   public final Double amoebic(Double var1) {
      Double var2 = -3.77;
      return var2;
   }
}
