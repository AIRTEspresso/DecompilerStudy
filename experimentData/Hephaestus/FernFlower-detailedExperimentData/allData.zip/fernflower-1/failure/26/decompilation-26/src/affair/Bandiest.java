package src.affair;

class Bandiest extends Purchases {
   public final Object factoring;
   public long costars;

   public Bandiest(Object var1, long var2) {
      this.factoring = var1;
      this.costars = var2;
   }

   public final Double amoebic(Double var1) {
      return var1;
   }

   public boolean splitting(byte var1, Integer var2) {
      return true;
   }
}
