package src.affair;

abstract class Purchases {
   public Double amoebic(Double var1) {
      return var1;
   }

   public boolean splitting(byte var1, Integer var2) {
      byte var3 = Main.christine();
      byte var4 = Main.christine();
      return this.splitting(var4, 46);
   }
}
