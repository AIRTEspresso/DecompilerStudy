package src.affair;

interface Function1 {
   Object apply(Object var1);
}
