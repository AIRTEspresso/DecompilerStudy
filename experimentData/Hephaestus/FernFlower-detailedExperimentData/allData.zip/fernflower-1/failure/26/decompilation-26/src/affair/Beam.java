package src.affair;

class Beam extends Bandiest {
   public Beam() {
      super(-37, 83L);
   }

   public final boolean splitting(byte var1, Integer var2) {
      Boolean var3 = true;
      Integer var4 = -96;
      Integer var5 = -19;
      Main.deceased = 26;
      return this.splitting(Main.deceased, var3 ? var4 : var5);
   }

   public Float overeat(Float var1) {
      return var1;
   }
}
