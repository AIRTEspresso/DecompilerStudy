package src.standbys;

class Main {
  static public final Integer garrulous(boolean founds) {
    return 40;
  }

  static final Long dittoes = (long)48;

  static Long defensive = Main.dittoes;

  static public final Hostler<Integer> calvin(Bindings rooster, Restudied<? super Number, Short, ? super Long> basque) {
    final Soloed<Long, Long> mention = (Soloed<Long, Long>) null;
    Hostler<Integer> vestments = new Hostler<Integer>(mention);
    Hostler<Integer> arenas = vestments;
    return arenas;
    
  }

  static Bindings boil = new Hostler<Short>((Soloed<Long, Long>) null);

  static Hostler<Integer> orange = Main.calvin(Main.boil, null);

  static public final void lineups() {
    final byte sleet = (byte)-90;
    Object x_1 = sleet;
    
  }

  static public final Dodgers<Byte, Number> busboy() {
    return Main.busboy();
  }

  static final boolean lurch = (Main.orange.diplomat.devoured != Main.busboy().exemption(new Popsicle(-18.707).pomade));

  static final Object india = true;

  static public final void main(String[] args) {
    final Hostler<? extends Bindings> louvers = new Hostler<Bindings>((Soloed<Long, Long>) null);
    Object x_2 = louvers;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Bindings {
  public final Short transmit;

  public Bindings(Short transmit) {
    this.transmit = transmit;
  }

  public <F_F extends Object, F_Q> F_F alyce(Integer hootch, F_Q gucci) {
    final Boolean tiros = true;
    F_F defection = (F_F) null;
    final F_F incite = defection;
    return ((tiros) ?
      (F_F) null : 
       incite);
    
  }
}

interface Restudied<P, L extends Number, C extends Number> {}

abstract class Soloed<N, G extends N> implements Restudied<String, Integer, Float> {
  public final Character devoured;

  public Soloed(Character devoured) {
    super();
    this.devoured = devoured;
  }
}

final class Hostler<L> extends Bindings {
  public Soloed<Long, Long> diplomat;

  public Hostler(Soloed<Long, Long> diplomat) {
    super((short)-51);
    this.diplomat = diplomat;
  }
}

abstract class Dodgers<Q, A> extends Bindings {
  public final Short transmit;
  public final int steep;

  public Dodgers(Short transmit,int steep) {
    super((short)-20);
    this.transmit = transmit;
    this.steep = steep;
  }

  public <F_J> Character exemption(F_J motored) {
     return 'L';
  }

  public <F_F extends Object, F_Q> F_F alyce(Integer hootch, F_Q gucci) {
    Function0<F_F> wren = () -> {
      final F_F clothier = (F_F) null;
      return clothier;
      
    };
    F_F deepness = wren.apply();
    Function1<Soloed<? extends Number, ? extends Number>, Void> assurance = (cached) -> {
      Object glamorous = new Object();
      Main.lineups();
      Object x_0 = glamorous;
      return null;
    };
    assurance.apply(null);
    return deepness;
    
  }
}

class Popsicle implements Restudied<Byte, Byte, Short> {
  public final Double pomade;

  public Popsicle(Double pomade) {
    super();
    this.pomade = pomade;
  }

  public final Float subset() {
    Float exotics = (float)-3.817;
    return exotics;
    
  }
}

interface Gaped extends Restudied<Gaped, Integer, Float> {
  public abstract char mornings(int crux, Double muscatels) ;
}

interface Sterne<N, B> extends Gaped {}

final class Culverts extends Soloed<Long, Long> {
  public final Bindings squiggly;

  public Culverts(Bindings squiggly) {
    super( '1');
    this.squiggly = squiggly;
  }

  public final String retook() {
    final String shiny = "frequents";
    return shiny;
    
  }
}