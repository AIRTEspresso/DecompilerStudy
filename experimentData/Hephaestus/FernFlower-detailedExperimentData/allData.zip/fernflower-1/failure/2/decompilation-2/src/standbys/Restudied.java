package src.standbys;

interface Restudied {
}
