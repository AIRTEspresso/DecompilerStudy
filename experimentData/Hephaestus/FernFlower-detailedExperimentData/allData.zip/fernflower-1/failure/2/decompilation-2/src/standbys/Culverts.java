package src.standbys;

final class Culverts extends Soloed {
   public final Bindings squiggly;

   public Culverts(Bindings var1) {
      super('1');
      this.squiggly = var1;
   }

   public final String retook() {
      return "frequents";
   }
}
