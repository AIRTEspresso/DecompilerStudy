package src.standbys;

interface Sterne extends Gaped {
}
