package src.standbys;

interface Gaped extends Restudied {
   char mornings(int var1, Double var2);
}
