package src.standbys;

interface Function0 {
   Object apply();
}
