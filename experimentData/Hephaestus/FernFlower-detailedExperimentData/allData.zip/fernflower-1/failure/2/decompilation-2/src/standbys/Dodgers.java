package src.standbys;

abstract class Dodgers extends Bindings {
   public final Short transmit;
   public final int steep;

   public Dodgers(Short var1, int var2) {
      super(Short.valueOf((short)-20));
      this.transmit = var1;
      this.steep = var2;
   }

   public Character exemption(Object var1) {
      return 'L';
   }

   public Object alyce(Integer var1, Object var2) {
      Function0 var3 = () -> {
         Object var0 = null;
         return var0;
      };
      Object var4 = var3.apply();
      Function1 var5 = (var0) -> {
         Object var1 = new Object();
         Main.lineups();
         return null;
      };
      var5.apply((Object)null);
      return var4;
   }
}
