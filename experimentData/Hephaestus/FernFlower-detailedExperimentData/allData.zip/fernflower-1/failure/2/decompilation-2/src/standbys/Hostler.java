package src.standbys;

final class Hostler extends Bindings {
   public Soloed diplomat;

   public Hostler(Soloed var1) {
      super(Short.valueOf((short)-51));
      this.diplomat = var1;
   }
}
