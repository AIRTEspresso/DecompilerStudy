package src.standbys;

class Popsicle implements Restudied {
   public final Double pomade;

   public Popsicle(Double var1) {
      this.pomade = var1;
   }

   public final Float subset() {
      Float var1 = -3.817F;
      return var1;
   }
}
