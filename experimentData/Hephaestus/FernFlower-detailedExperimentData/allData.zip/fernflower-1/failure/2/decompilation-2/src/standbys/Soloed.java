package src.standbys;

abstract class Soloed implements Restudied {
   public final Character devoured;

   public Soloed(Character var1) {
      this.devoured = var1;
   }
}
