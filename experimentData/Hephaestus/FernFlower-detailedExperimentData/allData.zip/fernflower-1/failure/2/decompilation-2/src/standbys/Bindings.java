package src.standbys;

abstract class Bindings {
   public final Short transmit;

   public Bindings(Short var1) {
      this.transmit = var1;
   }

   public Object alyce(Integer var1, Object var2) {
      Boolean var3 = true;
      Object var4 = null;
      return var3 ? null : var4;
   }
}
