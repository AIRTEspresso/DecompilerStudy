package src.prokofiev;

class Main {
   static Float hoagy = 24.94F;
   static final Boolean grayness = true;
   static final Leaving fending = (Leaving)null;
   static Leaving unskilled;
   static final Integer contains;
   static final Short killjoys;
   static Float boil;
   static final Hypos lurching;
   static long walleyes;

   public static final Float noggin(Coupons var0, short var1) {
      return hoagy;
   }

   public static final long evener() {
      long var0 = -53L;
      Boolean var4 = false;
      unskilled = var4 ? new Coupons(Short.valueOf((short)-97), -5.542) : new Coupons(Short.valueOf((short)-40), -80.355);
      return var0;
   }

   public static final byte gamuts(char var0, Float var1) {
      Boolean var2 = false;
      byte var3 = 45;
      return var2 ? -33 : fending.erector(var3);
   }

   public static final void main(String[] var0) {
      Short var1 = killjoys;
   }

   static {
      unskilled = fending;
      contains = (grayness ? fending : unskilled).toner.pier;
      killjoys = grayness ? (new Coupons(Short.valueOf((short)-21), -4.691)).surya : (new Coupons(Short.valueOf((short)68), -74.336)).surya;
      boil = noggin(new Coupons(Short.valueOf((short)51), -44.286), (new Coupons(Short.valueOf((short)71), -60.789)).surya);
      lurching = new Coupons(Short.valueOf((short)-89), 78.972);
      walleyes = evener();
   }
}
