package src.prokofiev;

final class Glamours extends Leaving {
   public Boolean dissenter;
   public char hive;

   public Glamours(Boolean var1, char var2) {
      super(new Coupons(Short.valueOf((short)74), 46.291), 66);
      this.dissenter = var1;
      this.hive = var2;
   }

   public final Object imperiled(Double var1) {
      new Pathology();
      Pathology var3 = new Pathology();
      Glamours var4 = (Glamours)null;
      return var3.cardigan(new Long(-51L), var4).hive;
   }

   public final short stubs(short var1) {
      return -28;
   }
}
