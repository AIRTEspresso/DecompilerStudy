package src.prokofiev;

final class Coupons extends Leaving {
   public Short surya;
   public double avior;

   public Coupons(Short var1, double var2) {
      super((Leaving)null, -92);
      this.surya = var1;
      this.avior = var2;
   }
}
