package src.prokofiev;

final class Pathology extends Leaving {
   public Pathology() {
      super(new Glamours(true, '2'), -97);
   }

   public final Glamours cardigan(Number var1, Object var2) {
      Glamours var3 = (Glamours)null;
      return var3;
   }
}
