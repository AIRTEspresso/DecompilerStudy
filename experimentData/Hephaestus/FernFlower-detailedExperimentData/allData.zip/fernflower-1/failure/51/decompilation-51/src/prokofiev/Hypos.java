package src.prokofiev;

abstract class Hypos {
   public Integer pier;
   public int emulates;

   public Hypos(Integer var1, int var2) {
      this.pier = var1;
      this.emulates = var2;
   }

   public byte erector(byte var1) {
      Boolean var2 = false;
      byte var3 = 3;
      byte var4 = var2 ? 45 : var3;
      return var4;
   }

   public Double afterlife() {
      return -60.586;
   }
}
