package src.prokofiev;

interface Function0 {
   Object apply();
}
