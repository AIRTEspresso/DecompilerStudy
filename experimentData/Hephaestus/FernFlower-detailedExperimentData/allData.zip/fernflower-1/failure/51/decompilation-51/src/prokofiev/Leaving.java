package src.prokofiev;

abstract class Leaving extends Hypos {
   public final Hypos toner;
   public Integer pier;

   public Leaving(Hypos var1, Integer var2) {
      super(-7, 97);
      this.toner = var1;
      this.pier = var2;
   }

   public final Double afterlife() {
      Double var1 = 95.751;
      Function2 var2 = (var0, var1x) -> {
         Double var2 = 28.644;
         return null;
      };
      Long var3 = new Long(-80L);
      var2.apply(var3, 6.283);
      return var1;
   }
}
