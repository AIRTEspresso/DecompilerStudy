package src.sojourn;

class Main {
  static public final Short spacy() {
    final Short rugs = (short)-50;
    return rugs;
    
  }

  static final Short chewiest = Main.spacy();

  static Boolean jives = true;

  static final Boolean babying = false;

  static final Boolean woman = ((Main.jives) ?
  true : 
   Main.babying);

  static Integer malaria = ((Main.woman) ?
  ((true) ?
    -84 : 
     69) : 
   -40);

  static public final Boolean rickshaw(double unearthly, Float colbert) {
    Long steiner = (long)-30;
    final double skidding = -55.275;
    return (steiner > skidding);
    
  }

  static public final double optimized() {
    return 99.467;
  }

  static Object educable = ((Main.rickshaw(Main.optimized(), (float)20.470) &&   ((true) ?
  true : 
   false)) || true);

  static final int whoppers = ((false) ?
  new Backpacks((Quarts) null) : 
   new Backpacks((Quarts) null)).appending.satraps((long)78).distorted(((Paddled) null).mouthfuls, (float)-31.518);

  static public final void enumerate(Float phobias, Integer bower) {
    Byte cranking = (byte)7;
    Main.malaria = -44;
    Object x_3 = cranking;
    
  }

  static final Object peeped = Main.rickshaw(93.346, ((Attempts<Double, Float>) null).resources.tiller.philip);

  static public final Boolean fineness(Quarts dazes) {
    final Attempts<? extends Integer, ? extends Float> abased = Main.rattraps(97);
    Boolean algebraic = abased.mouthfuls;
    return algebraic;
    
  }

  static public final Attempts<? extends Integer, ? extends Float> rattraps(int snafus) {
    Attempts<Integer, ? extends Float> extremist = (Attempts<Integer, Float>) null;
    final Attempts<? extends Integer, ? extends Float> lifestyle = (Attempts<Integer, Float>) null;
    final Attempts<? extends Integer, ? extends Float> hurried = ((true) ?
      extremist : 
       lifestyle);
    return hurried;
    
  }

  static public final void calls(Backpacks flan) {
    Backpacks overreact = flan;
    Float teaser = (float)61.492;
    Object x_7 = new Redneck<Object, String, String>(new Cuckolds<Byte, Float>("fillings", overreact), teaser);
    
  }

  static public final <F_I, F_G> void indexed(F_G pale, F_I redcoats) {
    F_I huang = (F_I) null;
    F_I enter = huang;
    final F_I shuttle = enter;
    Object x_8 = shuttle;
    
  }

  static public final Curatives sugarier() {
    Backpacks epic = new Backpacks((Quarts) null);
    final Cuckolds<Byte, Float> lipsticks = new Cuckolds<Byte, Float>("gaslights",   ((true) ?
  new Backpacks((Quarts) null) : 
   epic));
    final Pours eyes = (Pours) null;
    return new Redneck<Integer, String, String>(lipsticks,   ((true) ?
  eyes : 
   (Pours) null).cuckold(-56, ((Assam) null).stallion).snootiest());
    
  }

  static public final void flea(Tattle ikea, Droops hers) {
    Object x_9 = 18;
    
  }

  static public final void main(String[] args) {
    Main.sugarier();
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Colons<K, S extends K, F extends K> {
  public abstract Boolean marksman(K drainer) ;
}

abstract class Fannies<R> implements Colons<Float, Float, Float> {
  public int distorted(R counter, float vizor) {
    final Boolean impended = true;
    final Karyn<Boolean> comrade = new Karyn<Boolean>(-71);
    final Karyn<Boolean> ransomed = ((impended) ?
      comrade : 
       new Karyn<Boolean>(76));
    return ransomed.eggplants;
    
  }

  public abstract String quarks(String towheaded) ;
}

final class Karyn<Y> implements Colons<Y, Y, Y> {
  public int eggplants;

  public Karyn(int eggplants) {
    super();
    this.eggplants = eggplants;
  }

  public Boolean marksman(Y drainer) {
    Boolean mongrels = false;
    String gnus = "redevelop";
    String knack = "twiggiest";
    new Squish<String, Short, Short>(gnus, knack).topically(null);
    return mongrels;
    
  }
}

final class Squish<U extends Object, X extends Short, V extends X> implements Colons<Character, Character, Character> {
  public final U desire;
  public final U guessers;

  public Squish(U desire,U guessers) {
    super();
    this.desire = desire;
    this.guessers = guessers;
  }

  public final void topically(Squish<? extends U, X, ? extends X> lobbyists) {
    U banshees = (U) null;
    Object x_0 = banshees;
    
  }

  public Boolean marksman(Character drainer) {
    Boolean outdid = true;
    return outdid;
    
  }
}

interface Quarts extends Colons<Byte, Byte, Byte> {
  public abstract Fannies<Boolean> satraps(long saks) ;

  public abstract <F_G, F_Z> F_Z bullying(F_G hexagon) ;
}

class Backpacks extends Fannies<Integer> {
  public Quarts appending;

  public Backpacks(Quarts appending) {
    super();
    this.appending = appending;
  }

  public Boolean marksman(Float drainer) {
    final Boolean altoids = false;
    final Boolean fully = (altoids || true);
    return fully;
    
  }

  public String quarks(String towheaded) {
    String duchess = towheaded;
    return duchess;
    
  }
}

abstract class Paddled extends Backpacks {
  public Boolean mouthfuls;
  public Quarts appending;

  public Paddled(Boolean mouthfuls,Quarts appending) {
    super((Quarts) null);
    this.mouthfuls = mouthfuls;
    this.appending = appending;
  }

  public final Boolean marksman(Float drainer) {
    Boolean bronx = true;
    long purer = (long)-53;
    ((Bathhouse) null).augsburg(purer);
    return bronx;
    
  }

  public abstract Backpacks pollution(Backpacks greatness, Double airhead) ;
}

interface Bathhouse extends Quarts {
  public abstract void augsburg(long modulator) ;
}

abstract class Curatives implements Bathhouse {
  public final Float philip;

  public Curatives(Float philip) {
    super();
    this.philip = philip;
  }

  public void augsburg(long modulator) {
    Long fiber = (long)91;
    Boolean spacious = false;
    Steinbeck hollow = new Steinbeck(spacious);
    hollow.strolling((Curatives) null, (byte)-59);
    Object x_1 = fiber;
    
  }

  public Long juanita(Number sprigs, Long egging) {
    Long legalizes = (long)-32;
    return legalizes;
    
  }
}

class Steinbeck extends Paddled {
  public Boolean mouthfuls;

  public Steinbeck(Boolean mouthfuls) {
    super(true, (Quarts) null);
    this.mouthfuls = mouthfuls;
  }

  public final void strolling(Curatives scam, byte traipse) {
    final Karyn<? extends Curatives> wycliffe = new Karyn<Curatives>(-19);
    final Karyn<? extends Curatives> lathing = wycliffe;
    Object x_2 = lathing;
    
  }

  public Backpacks pollution(Backpacks greatness, Double airhead) {
    final Quarts droopiest = (Quarts) null;
    Main.enumerate((float)-1.0, 29);
    return new Backpacks(droopiest);
    
  }
}

class Fondu<T extends Short, K, E> implements Quarts {
  public Curatives tiller;

  public Fondu(Curatives tiller) {
    super();
    this.tiller = tiller;
  }

  public Boolean marksman(Byte drainer) {
    return false;
  }

  public Fannies<Boolean> satraps(long saks) {
    Fannies<Boolean> scuzziest = (Fannies<Boolean>) null;
    return scuzziest;
    
  }

  public <F_G, F_Z> F_Z bullying(F_G hexagon) {
    F_Z rudders = (F_Z) null;
    final F_Z mountains = rudders;
    return mountains;
    
  }
}

abstract class Attempts<A, E extends Float> extends Steinbeck {
  public final Fondu<Short, Character, Backpacks> resources;
  public Boolean mouthfuls;

  public Attempts(Fondu<Short, Character, Backpacks> resources,Boolean mouthfuls) {
    super(true);
    this.resources = resources;
    this.mouthfuls = mouthfuls;
  }

  public E snootiest() {
    E podcasts = (E) null;
    return podcasts;
    
  }
}

abstract class Mists<M> implements Quarts {
  public final Squish<Character, ? extends Short, ? extends Short> seized;

  public Mists(Squish<Character, ? extends Short, ? extends Short> seized) {
    super();
    this.seized = seized;
  }

  public <F_G, F_Z> F_Z bullying(F_G hexagon) {
    return (F_Z) null;
  }

  public Fannies<Boolean> satraps(long saks) {
    final Boolean razing = false;
    final Fannies<Boolean> skeet = (Fannies<Boolean>) null;
    Fannies<Boolean> sasquatch = ((razing) ?
      (Fannies<Boolean>) null : 
       skeet);
    return sasquatch;
    
  }
}

abstract class Droops extends Steinbeck {
  public Boolean mouthfuls;
  public final Droops overeat;

  public Droops(Boolean mouthfuls,Droops overeat) {
    super(true);
    this.mouthfuls = mouthfuls;
    this.overeat = overeat;
  }

  public Backpacks pollution(Backpacks greatness, Double airhead) {
    final Backpacks firmly = new Backpacks((Quarts) null);
    Fondu<Short, Character, Backpacks> dualism = new Fondu<Short, Character, Backpacks>((Curatives) null);
    final Tattle thales = new Tattle(dualism);
      ((true) ?
  new Nicely<Quarts, Byte>(thales) : 
   new Nicely<Quarts, Byte>(new Tattle(new Fondu<Short, Character, Backpacks>((Curatives) null)))).schwartz.leaving(null);
    return firmly;
    
  }
}

final class Tattle extends Attempts<Integer, Float> {
  public final Fondu<Short, Character, Backpacks> resources;

  public Tattle(Fondu<Short, Character, Backpacks> resources) {
    super(new Fondu<Short, Character, Backpacks>((Curatives) null), true);
    this.resources = resources;
  }

  public final void leaving(Squish<Object, ? super Short, Short> jurassic) {
    final Boolean knitted = Main.babying;
    Main.jives = knitted;
    Object x_4 = 2.709;
    
  }

  public final Float snootiest() {
    final Float smirking = (float)4.91;
    Quarts beers = (Quarts) null;
    Cuckolds<Byte, Float> antique = new Cuckolds<Byte, Float>("decca", new Backpacks(beers));
    new Redneck<Short, String, String>(antique, (float)-85.74).attar.cadenza((float)-93.710, (Tattle) null);
    return smirking;
    
  }
}

class Cuckolds<F extends Byte, C> extends Fannies<F> {
  public String swindle;
  public final Backpacks parachute;

  public Cuckolds(String swindle,Backpacks parachute) {
    super();
    this.swindle = swindle;
    this.parachute = parachute;
  }

  public final void cadenza(C pawnshops, Steinbeck soapbox) {
    Object x_5 = -85;
    
  }

  public Boolean marksman(Float drainer) {
    return true;
  }

  public String quarks(String towheaded) {
    return "tabued";
  }
}

final class Redneck<U, Y extends String, H extends Y> extends Curatives {
  public Cuckolds<Byte, Float> attar;
  public final Float philip;

  public Redneck(Cuckolds<Byte, Float> attar,Float philip) {
    super((float)50.289);
    this.attar = attar;
    this.philip = philip;
  }

  public Boolean marksman(Byte drainer) {
    return false;
  }

  public Fannies<Boolean> satraps(long saks) {
    return (Fannies<Boolean>) null;
  }

  public <F_G, F_Z> F_Z bullying(F_G hexagon) {
    F_Z morals = (F_Z) null;
    Function0<Void> asthma = () -> {
      short worlds = (short)-29;
      Object x_6 = worlds;
      return null;
    };
    asthma.apply();
    return morals;
    
  }
}

class Nicely<O, I> extends Fannies<I> {
  public final Tattle schwartz;

  public Nicely(Tattle schwartz) {
    super();
    this.schwartz = schwartz;
  }

  public Boolean marksman(Float drainer) {
    return true;
  }

  public String quarks(String towheaded) {
    return "aspidiske";
  }
}

abstract class Donors<H, Y> extends Nicely<Byte, Curatives> {
  public Bathhouse elias;
  public Y browning;

  public Donors(Bathhouse elias,Y browning) {
    super(new Tattle(new Fondu<Short, Character, Backpacks>((Curatives) null)));
    this.elias = elias;
    this.browning = browning;
  }

  public final Boolean marksman(Float drainer) {
    final Donors<Character, ? super String> rehabs = (Donors<Character, String>) null;
    final Donors<Character, ? super String> sawing = rehabs;
    Tattle steel = sawing.schwartz;
    Main.indexed(new Canker(16.447, (Droops) null).nefertiti,   ((true) ?
  (Bathhouse) null : 
   (Curatives) null));
    return (-77 <= new Ballasted((Float[]) new Object[]{(float)-36.0}, steel.snootiest()).crutches((Mists<Curatives>) null,  'w'));
    
  }
}

final class Ballasted implements Quarts {
  public Float[] sashes;
  public Float capsizing;

  public Ballasted(Float[] sashes,Float capsizing) {
    super();
    this.sashes = sashes;
    this.capsizing = capsizing;
  }

  public final byte crutches(Mists<Curatives> sharpen, char weld) {
    byte epson = (byte)-41;
    return epson;
    
  }

  public Boolean marksman(Byte drainer) {
    Boolean buggier = false;
    return buggier;
    
  }

  public Fannies<Boolean> satraps(long saks) {
    Fannies<Boolean> fireball = (Fannies<Boolean>) null;
    Fannies<Boolean> louvers = fireball;
    return louvers;
    
  }

  public <F_G, F_Z> F_Z bullying(F_G hexagon) {
    F_Z graphic = (F_Z) null;
    Backpacks fixated = new Backpacks((Quarts) null);
    Main.calls(fixated);
    return graphic;
    
  }
}

final class Canker extends Droops {
  public final Double nefertiti;
  public final Droops overeat;

  public Canker(Double nefertiti,Droops overeat) {
    super(true, (Droops) null);
    this.nefertiti = nefertiti;
    this.overeat = overeat;
  }

  public final Attempts<Curatives, ? super Float> sedation(Attempts<Curatives, ? super Float> moused) {
    final Attempts<Curatives, ? super Float> disobeyed = (Attempts<Curatives, Float>) null;
    Boolean vixen = true;
    Main.jives = vixen;
    return disobeyed;
    
  }
}

interface Pours extends Quarts {
  public abstract <F_A extends Integer> Tattle cuckold(F_A salivary, Long baseness) ;
}

abstract class Assam extends Mists<Byte> {
  public Long stallion;

  public Assam(Long stallion) {
    super(new Squish<Character, Short, Short>( 'P', 'e'));
    this.stallion = stallion;
  }

  public final <F_G, F_Z> F_Z bullying(F_G hexagon) {
    F_Z jewelries = (F_Z) null;
    final Tattle search = new Tattle(new Fondu<Short, Character, Backpacks>((Curatives) null));
    final Double revamps = 39.317;
    Main.flea(search, new Canker(revamps, null));
    return jewelries;
    
  }

  public final Fannies<Boolean> satraps(long saks) {
    final Fannies<Boolean> sermons = (Fannies<Boolean>) null;
    return sermons;
    
  }
}