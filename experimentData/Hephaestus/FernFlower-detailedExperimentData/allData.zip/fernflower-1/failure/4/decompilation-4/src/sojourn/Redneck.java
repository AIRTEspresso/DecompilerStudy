package src.sojourn;

final class Redneck extends Curatives {
   public Cuckolds attar;
   public final Float philip;

   public Redneck(Cuckolds var1, Float var2) {
      super(50.289F);
      this.attar = var1;
      this.philip = var2;
   }

   public Boolean marksman(Byte var1) {
      return false;
   }

   public Fannies satraps(long var1) {
      return (Fannies)null;
   }

   public Object bullying(Object var1) {
      Object var2 = null;
      Function0 var3 = () -> {
         byte var0 = -29;
         Short var1 = Short.valueOf(var0);
         return null;
      };
      var3.apply();
      return var2;
   }
}
