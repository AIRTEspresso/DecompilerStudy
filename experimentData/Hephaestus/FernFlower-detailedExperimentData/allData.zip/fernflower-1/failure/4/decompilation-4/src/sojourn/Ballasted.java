package src.sojourn;

final class Ballasted implements Quarts {
   public Float[] sashes;
   public Float capsizing;

   public Ballasted(Float[] var1, Float var2) {
      this.sashes = var1;
      this.capsizing = var2;
   }

   public final byte crutches(Mists var1, char var2) {
      byte var3 = -41;
      return var3;
   }

   public Boolean marksman(Byte var1) {
      Boolean var2 = false;
      return var2;
   }

   public Fannies satraps(long var1) {
      Fannies var3 = (Fannies)null;
      return var3;
   }

   public Object bullying(Object var1) {
      Object var2 = null;
      Backpacks var3 = new Backpacks((Quarts)null);
      Main.calls(var3);
      return var2;
   }
}
