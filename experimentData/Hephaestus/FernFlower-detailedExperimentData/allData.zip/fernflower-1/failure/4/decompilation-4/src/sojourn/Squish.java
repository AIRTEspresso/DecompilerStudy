package src.sojourn;

final class Squish implements Colons {
   public final Object desire;
   public final Object guessers;

   public Squish(Object var1, Object var2) {
      this.desire = var1;
      this.guessers = var2;
   }

   public final void topically(Squish var1) {
      Object var2 = null;
   }

   public Boolean marksman(Character var1) {
      Boolean var2 = true;
      return var2;
   }
}
