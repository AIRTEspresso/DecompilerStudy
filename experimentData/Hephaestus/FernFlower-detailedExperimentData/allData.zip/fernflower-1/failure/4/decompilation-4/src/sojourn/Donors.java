package src.sojourn;

abstract class Donors extends Nicely {
   public Bathhouse elias;
   public Object browning;

   public Donors(Bathhouse var1, Object var2) {
      super(new Tattle(new Fondu((Curatives)null)));
      this.elias = var1;
      this.browning = var2;
   }

   public final Boolean marksman(Float var1) {
      Donors var2 = (Donors)null;
      Tattle var4 = var2.schwartz;
      Main.indexed((new Canker(16.447, (Droops)null)).nefertiti, (Bathhouse)null);
      return -77 <= (new Ballasted((Float[])(new Object[]{-36.0F}), var4.snootiest())).crutches((Mists)null, 'w');
   }
}
