package src.sojourn;

interface Bathhouse extends Quarts {
   void augsburg(long var1);
}
