package src.sojourn;

interface Function1 {
   Object apply(Object var1);
}
