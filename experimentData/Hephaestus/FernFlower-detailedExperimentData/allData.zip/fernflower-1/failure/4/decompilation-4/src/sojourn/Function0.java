package src.sojourn;

interface Function0 {
   Object apply();
}
