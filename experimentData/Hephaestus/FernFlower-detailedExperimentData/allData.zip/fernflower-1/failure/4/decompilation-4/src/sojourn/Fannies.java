package src.sojourn;

abstract class Fannies implements Colons {
   public int distorted(Object var1, float var2) {
      Boolean var3 = true;
      Karyn var4 = new Karyn(-71);
      Karyn var5 = var3 ? var4 : new Karyn(76);
      return var5.eggplants;
   }

   public abstract String quarks(String var1);
}
