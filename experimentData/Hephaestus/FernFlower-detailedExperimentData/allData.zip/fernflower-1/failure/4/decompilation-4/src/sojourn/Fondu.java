package src.sojourn;

class Fondu implements Quarts {
   public Curatives tiller;

   public Fondu(Curatives var1) {
      this.tiller = var1;
   }

   public Boolean marksman(Byte var1) {
      return false;
   }

   public Fannies satraps(long var1) {
      Fannies var3 = (Fannies)null;
      return var3;
   }

   public Object bullying(Object var1) {
      Object var2 = null;
      return var2;
   }
}
