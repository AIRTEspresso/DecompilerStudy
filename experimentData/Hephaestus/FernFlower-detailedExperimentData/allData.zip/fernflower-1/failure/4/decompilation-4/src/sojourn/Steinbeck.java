package src.sojourn;

class Steinbeck extends Paddled {
   public Boolean mouthfuls;

   public Steinbeck(Boolean var1) {
      super(true, (Quarts)null);
      this.mouthfuls = var1;
   }

   public final void strolling(Curatives var1, byte var2) {
      Karyn var3 = new Karyn(-19);
   }

   public Backpacks pollution(Backpacks var1, Double var2) {
      Quarts var3 = (Quarts)null;
      Main.enumerate(-1.0F, 29);
      return new Backpacks(var3);
   }
}
