package src.sojourn;

final class Canker extends Droops {
   public final Double nefertiti;
   public final Droops overeat;

   public Canker(Double var1, Droops var2) {
      super(true, (Droops)null);
      this.nefertiti = var1;
      this.overeat = var2;
   }

   public final Attempts sedation(Attempts var1) {
      Attempts var2 = (Attempts)null;
      Boolean var3 = true;
      Main.jives = var3;
      return var2;
   }
}
