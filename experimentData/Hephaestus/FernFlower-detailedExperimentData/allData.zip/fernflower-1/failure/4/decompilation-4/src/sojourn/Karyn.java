package src.sojourn;

final class Karyn implements Colons {
   public int eggplants;

   public Karyn(int var1) {
      this.eggplants = var1;
   }

   public Boolean marksman(Object var1) {
      Boolean var2 = false;
      String var3 = "redevelop";
      String var4 = "twiggiest";
      (new Squish(var3, var4)).topically((Squish)null);
      return var2;
   }
}
