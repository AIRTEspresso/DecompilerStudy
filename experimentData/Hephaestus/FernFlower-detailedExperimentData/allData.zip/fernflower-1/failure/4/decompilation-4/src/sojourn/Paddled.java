package src.sojourn;

abstract class Paddled extends Backpacks {
   public Boolean mouthfuls;
   public Quarts appending;

   public Paddled(Boolean var1, Quarts var2) {
      super((Quarts)null);
      this.mouthfuls = var1;
      this.appending = var2;
   }

   public final Boolean marksman(Float var1) {
      Boolean var2 = true;
      long var3 = -53L;
      ((Bathhouse)null).augsburg(var3);
      return var2;
   }

   public abstract Backpacks pollution(Backpacks var1, Double var2);
}
