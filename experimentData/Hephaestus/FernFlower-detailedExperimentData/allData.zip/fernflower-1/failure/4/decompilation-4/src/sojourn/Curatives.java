package src.sojourn;

abstract class Curatives implements Bathhouse {
   public final Float philip;

   public Curatives(Float var1) {
      this.philip = var1;
   }

   public void augsburg(long var1) {
      Long var3 = 91L;
      Boolean var4 = false;
      Steinbeck var5 = new Steinbeck(var4);
      var5.strolling((Curatives)null, (byte)-59);
   }

   public Long juanita(Number var1, Long var2) {
      Long var3 = -32L;
      return var3;
   }
}
