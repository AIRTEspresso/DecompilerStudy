package src.sojourn;

interface Colons {
   Boolean marksman(Object var1);
}
