package src.sojourn;

interface Quarts extends Colons {
   Fannies satraps(long var1);

   Object bullying(Object var1);
}
