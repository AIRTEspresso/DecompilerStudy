package src.sojourn;

class Main {
   static final Short chewiest = spacy();
   static Boolean jives = true;
   static final Boolean babying = false;
   static final Boolean woman;
   static Integer malaria;
   static Object educable;
   static final int whoppers;
   static final Object peeped;

   public static final Short spacy() {
      Short var0 = Short.valueOf((short)-50);
      return var0;
   }

   public static final Boolean rickshaw(double var0, Float var2) {
      Long var3 = -30L;
      return (double)var3 > -55.275;
   }

   public static final double optimized() {
      return 99.467;
   }

   public static final void enumerate(Float var0, Integer var1) {
      Byte var2 = 7;
      malaria = -44;
   }

   public static final Boolean fineness(Quarts var0) {
      Attempts var1 = rattraps(97);
      Boolean var2 = var1.mouthfuls;
      return var2;
   }

   public static final Attempts rattraps(int var0) {
      Attempts var1 = (Attempts)null;
      Attempts var2 = (Attempts)null;
      return var1;
   }

   public static final void calls(Backpacks var0) {
      Float var2 = 61.492F;
      new Redneck(new Cuckolds("fillings", var0), var2);
   }

   public static final void indexed(Object var0, Object var1) {
      Object var2 = null;
   }

   public static final Curatives sugarier() {
      new Backpacks((Quarts)null);
      Cuckolds var1 = new Cuckolds("gaslights", new Backpacks((Quarts)null));
      Pours var2 = (Pours)null;
      return new Redneck(var1, var2.cuckold(-56, ((Assam)null).stallion).snootiest());
   }

   public static final void flea(Tattle var0, Droops var1) {
      Integer var2 = 18;
   }

   public static final void main(String[] var0) {
      sugarier();
   }

   static {
      woman = jives ? true : babying;
      malaria = woman ? -84 : -40;
      if (rickshaw(optimized(), 20.47F)) {
      }

      educable = true;
      whoppers = (new Backpacks((Quarts)null)).appending.satraps(78L).distorted(((Paddled)null).mouthfuls, -31.518F);
      peeped = rickshaw(93.346, ((Attempts)null).resources.tiller.philip);
   }
}
