package src.sojourn;

class Backpacks extends Fannies {
   public Quarts appending;

   public Backpacks(Quarts var1) {
      this.appending = var1;
   }

   public Boolean marksman(Float var1) {
      Boolean var2 = false;
      if (!var2) {
      }

      Boolean var3 = true;
      return var3;
   }

   public String quarks(String var1) {
      return var1;
   }
}
