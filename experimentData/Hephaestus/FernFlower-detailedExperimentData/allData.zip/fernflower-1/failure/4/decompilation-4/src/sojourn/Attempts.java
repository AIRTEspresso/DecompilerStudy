package src.sojourn;

abstract class Attempts extends Steinbeck {
   public final Fondu resources;
   public Boolean mouthfuls;

   public Attempts(Fondu var1, Boolean var2) {
      super(true);
      this.resources = var1;
      this.mouthfuls = var2;
   }

   public Float snootiest() {
      Float var1 = (Float)null;
      return var1;
   }
}
