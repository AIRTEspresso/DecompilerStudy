package src.sojourn;

class Nicely extends Fannies {
   public final Tattle schwartz;

   public Nicely(Tattle var1) {
      this.schwartz = var1;
   }

   public Boolean marksman(Float var1) {
      return true;
   }

   public String quarks(String var1) {
      return "aspidiske";
   }
}
