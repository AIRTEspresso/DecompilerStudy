package src.sojourn;

final class Tattle extends Attempts {
   public final Fondu resources;

   public Tattle(Fondu var1) {
      super(new Fondu((Curatives)null), true);
      this.resources = var1;
   }

   public final void leaving(Squish var1) {
      Boolean var2 = Main.babying;
      Main.jives = var2;
      Double var3 = 2.709;
   }

   public final Float snootiest() {
      Float var1 = 4.91F;
      Quarts var2 = (Quarts)null;
      Cuckolds var3 = new Cuckolds("decca", new Backpacks(var2));
      (new Redneck(var3, -85.74F)).attar.cadenza(-93.71F, (Tattle)null);
      return var1;
   }
}
