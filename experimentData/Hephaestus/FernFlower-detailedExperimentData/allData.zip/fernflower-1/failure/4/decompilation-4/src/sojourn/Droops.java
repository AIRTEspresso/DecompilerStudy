package src.sojourn;

abstract class Droops extends Steinbeck {
   public Boolean mouthfuls;
   public final Droops overeat;

   public Droops(Boolean var1, Droops var2) {
      super(true);
      this.mouthfuls = var1;
      this.overeat = var2;
   }

   public Backpacks pollution(Backpacks var1, Double var2) {
      Backpacks var3 = new Backpacks((Quarts)null);
      Fondu var4 = new Fondu((Curatives)null);
      Tattle var5 = new Tattle(var4);
      (new Nicely(var5)).schwartz.leaving((Squish)null);
      return var3;
   }
}
