package src.sojourn;

abstract class Assam extends Mists {
   public Long stallion;

   public Assam(Long var1) {
      super(new Squish('P', 'e'));
      this.stallion = var1;
   }

   public final Object bullying(Object var1) {
      Object var2 = null;
      Tattle var3 = new Tattle(new Fondu((Curatives)null));
      Double var4 = 39.317;
      Main.flea(var3, new Canker(var4, (Droops)null));
      return var2;
   }

   public final Fannies satraps(long var1) {
      Fannies var3 = (Fannies)null;
      return var3;
   }
}
