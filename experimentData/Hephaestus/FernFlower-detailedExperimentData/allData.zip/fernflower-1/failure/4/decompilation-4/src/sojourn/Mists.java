package src.sojourn;

abstract class Mists implements Quarts {
   public final Squish seized;

   public Mists(Squish var1) {
      this.seized = var1;
   }

   public Object bullying(Object var1) {
      return null;
   }

   public Fannies satraps(long var1) {
      Boolean var3 = false;
      Fannies var4 = (Fannies)null;
      Fannies var5 = var3 ? (Fannies)null : var4;
      return var5;
   }
}
