package src.sojourn;

interface Pours extends Quarts {
   Tattle cuckold(Integer var1, Long var2);
}
