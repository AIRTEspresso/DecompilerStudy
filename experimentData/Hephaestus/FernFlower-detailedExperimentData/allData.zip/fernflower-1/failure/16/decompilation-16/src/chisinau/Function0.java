package src.chisinau;

interface Function0 {
   Object apply();
}
