package src.chisinau;

final class Fouler implements Joyridden {
   public Boolean omelettes;
   public Object[] bothers;

   public Fouler(Boolean var1, Object[] var2) {
      this.omelettes = var1;
      this.bothers = var2;
   }

   public Character warthog() {
      Character var1 = 'F';
      this.omelettes = (Boolean)null;
      return var1;
   }
}
