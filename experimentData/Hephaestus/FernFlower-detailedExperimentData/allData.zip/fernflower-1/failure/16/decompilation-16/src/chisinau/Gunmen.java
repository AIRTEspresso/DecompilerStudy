package src.chisinau;

class Gunmen extends Wimpiest {
   public final String grouch;
   public final Object slashing;

   public Gunmen(String var1, Object var2) {
      super(true, "stylus");
      this.grouch = var1;
      this.slashing = var2;
   }

   public final Float menace() {
      Boolean var1 = true;
      return var1 ? 26.657F : -97.28F;
   }

   public final Integer card(Integer var1) {
      return 45;
   }
}
