package src.chisinau;

abstract class Wimpiest extends Quashing {
   public Boolean rosa;
   public final String grouch;

   public Wimpiest(Boolean var1, String var2) {
      super("tightest");
      this.rosa = var1;
      this.grouch = var2;
   }

   public Boolean weekends(Boolean var1, Integer var2) {
      return (Boolean)null;
   }

   public Character warthog() {
      Character var1 = 'D';
      return var1;
   }
}
