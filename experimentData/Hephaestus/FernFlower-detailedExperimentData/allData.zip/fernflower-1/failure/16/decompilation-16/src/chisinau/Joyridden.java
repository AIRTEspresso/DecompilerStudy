package src.chisinau;

interface Joyridden {
   Character warthog();
}
