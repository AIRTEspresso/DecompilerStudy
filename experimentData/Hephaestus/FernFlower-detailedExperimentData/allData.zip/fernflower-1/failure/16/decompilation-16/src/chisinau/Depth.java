package src.chisinau;

interface Depth extends Joyridden {
   long softwood();
}
