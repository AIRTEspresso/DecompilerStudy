package src.chisinau;

class Quashing implements Joyridden {
   public final String grouch;

   public Quashing(String var1) {
      this.grouch = var1;
   }

   public Character warthog() {
      return this.warthog();
   }

   public Boolean weekends(Boolean var1, Integer var2) {
      Boolean var3 = (Boolean)null;
      boolean var4 = true;
      return var3;
   }
}
