package src.chisinau;

class Main {
   static final Boolean sundials = false;
   static Depth perils = (Depth)null;
   static final Depth hines;
   static final Integer mammogram;

   public static final String resultant(String var0, Float var1) {
      Quashing var2 = new Quashing("accident");
      return var2.grouch;
   }

   public static final Integer burch(double var0, long var2) {
      Boolean var4 = ((Wimpiest)null).rosa;
      Integer var5 = var4 ? burch(55.126, -50L) : burch(36.129, -79L);
      return var5;
   }

   public static final void main(String[] var0) {
      Boolean var1 = true;
      String var2 = "brazening";
      Integer var3 = 8;
      Gunmen var4 = (new Evasion(var1 ? new Gunmen(var2, var3) : new Gunmen("raiment", 49), (new Evasion(new Gunmen("buckle", 10), (Wimpiest)null)).homelier)).resume;
   }

   static {
      hines = perils;
      mammogram = burch(sundials ? -100.534 : -76.856, ((Depth)null).softwood());
   }
}
