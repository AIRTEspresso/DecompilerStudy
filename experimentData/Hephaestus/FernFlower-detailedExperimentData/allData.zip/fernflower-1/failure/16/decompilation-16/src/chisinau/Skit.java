package src.chisinau;

class Skit extends Wimpiest {
   public final String grouch;

   public Skit(String var1) {
      super(false, "tailcoats");
      this.grouch = var1;
   }

   public void chickweed(Integer var1) {
      Character var2 = 'W';
   }
}
