package src.chisinau;

class Evasion extends Syllabi {
   public Gunmen resume;
   public final Wimpiest bowed;

   public Evasion(Gunmen var1, Wimpiest var2) {
      super(new Gunmen("aries", (Depth)null), new Skit("caraways"));
      this.resume = var1;
      this.bowed = var2;
   }

   public final Boolean weekends(Boolean var1, Integer var2) {
      Boolean var3 = (Boolean)null;
      this.resume = null;
      return var3;
   }
}
