package src.chisinau;

abstract class Syllabi extends Quashing {
   public final Wimpiest homelier;
   public final Wimpiest bowed;

   public Syllabi(Wimpiest var1, Wimpiest var2) {
      super("carillons");
      this.homelier = var1;
      this.bowed = var2;
   }

   public Boolean weekends(Boolean var1, Integer var2) {
      Object[] var4 = new Object[0];
      Object[] var5 = new Object[0];
      this.bowed.rosa = (float)var2 <= -56.48F;
      return (new Fouler(var1, var5)).omelettes;
   }

   public Character warthog() {
      Boolean var1 = false;
      Character var2 = 'E';
      Character var3 = 'p';
      Function0 var4 = () -> {
         Function2 var0 = (var0x, var1x) -> {
            Wimpiest var2 = (Wimpiest)null;
            Skit var4 = new Skit("spindly");
            var4.chickweed(20);
            return var2;
         };
         Boolean var1 = false;
         Wimpiest var2 = (Wimpiest)null;
         var0.apply(var1 ? (Wimpiest)null : (Wimpiest)null, var2);
         return null;
      };
      var4.apply();
      return var1 ? var2 : var3;
   }
}
