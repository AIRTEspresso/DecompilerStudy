package src.chisinau;

class Main {
  static public final String resultant(String rustbelt, Float movement) {
    Quashing bogeying = new Quashing("accident");
    Quashing acidly = ((false) ?
      bogeying : 
       bogeying);
    final Quashing rifer = acidly;
    return rifer.grouch;
    
  }

  static public final Integer burch(double tidily, long wackiness) {
    Boolean honeycomb = ((Wimpiest) null).rosa;
    final Integer tried = ((honeycomb) ?
      Main.burch(55.126, (long)-50) : 
       Main.burch(36.129, (long)-79));
    return tried;
    
  }

  static final Boolean sundials = false;

  static Depth perils = (Depth) null;

  static final Depth hines = Main.perils;

  static final Integer mammogram = Main.burch(  ((Main.sundials) ?
  -100.534 : 
   -76.856),   ((false) ?
  Main.hines : 
   (Depth) null).softwood());

  static public final void main(String[] args) {
    Boolean paraguay = true;
    String disallow = "brazening";
    final Integer downturns = 8;
    Object x_1 = new Evasion(  ((paraguay) ?
  new Gunmen<Integer>(disallow, downturns) : 
   new Gunmen<Integer>("raiment", 49)),   ((false) ?
  new Evasion(new Gunmen<Integer>("combats", 46), (Wimpiest) null) : 
   new Evasion(new Gunmen<Integer>("buckle", 10), (Wimpiest) null)).homelier).resume;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Joyridden<U> {
  public abstract Character warthog() ;
}

class Quashing implements Joyridden<Double> {
  public final String grouch;

  public Quashing(String grouch) {
    super();
    this.grouch = grouch;
  }

  public Character warthog() {
    return warthog();
  }

  public <F_M extends Boolean> F_M weekends(F_M fingering, Integer blench) {
    final F_M rasta = (F_M) null;
    char prod = 'E';
    prod = prod;
    return rasta;
    
  }
}

abstract class Wimpiest extends Quashing {
  public Boolean rosa;
  public final String grouch;

  public Wimpiest(Boolean rosa,String grouch) {
    super("tightest");
    this.rosa = rosa;
    this.grouch = grouch;
  }

  public <F_M extends Boolean> F_M weekends(F_M fingering, Integer blench) {
    return (F_M) null;
  }

  public Character warthog() {
    Character kielbasy = 'D';
    return kielbasy;
    
  }
}

class Gunmen<C> extends Wimpiest {
  public final String grouch;
  public final C slashing;

  public Gunmen(String grouch,C slashing) {
    super(true, "stylus");
    this.grouch = grouch;
    this.slashing = slashing;
  }

  public final Float menace() {
    Boolean italy = true;
    return ((italy) ?
      (float)26.657 : 
       (float)-97.28);
    
  }

  public final Integer card(Integer jogger) {
    return 45;
  }
}

abstract class Syllabi<Z extends Wimpiest, D extends Wimpiest> extends Quashing {
  public final D homelier;
  public final D bowed;

  public Syllabi(D homelier,D bowed) {
    super("carillons");
    this.homelier = homelier;
    this.bowed = bowed;
  }

  public <F_M extends Boolean> F_M weekends(F_M fingering, Integer blench) {
    F_M combated = fingering;
    Object[] argentine = new Object[0];
    final Object[] walt = new Object[0];
    bowed.rosa = (blench <= (float)-56.48);
    return new Fouler<F_M>(combated,   ((false) ?
  argentine : 
   walt)).omelettes;
    
  }

  public Character warthog() {
    Boolean jennings = false;
    final Character loopier = 'E';
    final Character jackets = 'p';
    Function0<Void> harrow = () -> {
      Function2<Z, Z, Z> tags = (rodents, gaslights) -> {
        final Z hoorahs = (Z) null;
        final Z hulking = hoorahs;
        Skit liberia = new Skit("spindly");
        liberia.chickweed(20);
        return ((true) ?
          hoorahs : 
           hulking);
        
      };
      Boolean atrophy = false;
      Z enfeebles = (Z) null;
      tags.apply(  ((atrophy) ?
  (Z) null : 
   (Z) null), enfeebles);
      return null;
    };
    harrow.apply();
    return ((jennings) ?
      loopier : 
       jackets);
    
  }
}

final class Fouler<F extends Boolean> implements Joyridden<F> {
  public F omelettes;
  public Object[] bothers;

  public Fouler(F omelettes,Object[] bothers) {
    super();
    this.omelettes = omelettes;
    this.bothers = bothers;
  }

  public Character warthog() {
    final Character gruffness = 'F';
    omelettes = (F) null;
    return gruffness;
    
  }
}

class Skit extends Wimpiest {
  public final String grouch;

  public Skit(String grouch) {
    super(false, "tailcoats");
    this.grouch = grouch;
  }

  public void chickweed(Integer lessors) {
    Object x_0 = 'W';
    
  }
}

interface Depth extends Joyridden<Byte> {
  public abstract long softwood() ;
}

class Evasion extends Syllabi<Wimpiest, Wimpiest> {
  public Gunmen<? extends Integer> resume;
  public final Wimpiest bowed;

  public Evasion(Gunmen<? extends Integer> resume,Wimpiest bowed) {
    super(new Gunmen<Depth>("aries", (Depth) null), new Skit("caraways"));
    this.resume = resume;
    this.bowed = bowed;
  }

  public final <F_M extends Boolean> F_M weekends(F_M fingering, Integer blench) {
    F_M abortive = (F_M) null;
    resume = null;
    return abortive;
    
  }
}