package src.reopened;

abstract class Dogfight extends Salivates {
   public Dogfight() {
      super(true, -51L);
   }

   public double norwich(float var1, Penology var2) {
      Affray var3 = (Affray)null;
      Double var4 = 21.2;
      var3.catskills((Penology)null, var4);
      return -85.14;
   }
}
