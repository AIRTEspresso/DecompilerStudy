package src.reopened;

interface Function0 {
   Object apply();
}
