package src.reopened;

abstract class Salivates implements Penology {
   public final Boolean nation;
   public Long redcoats;

   public Salivates(Boolean var1, Long var2) {
      this.nation = var1;
      this.redcoats = var2;
   }

   public Integer almost(Integer var1, Byte[] var2) {
      return (Integer)null;
   }

   public Integer antipas(Integer var1) {
      Integer var2 = 19;
      Long var3 = (Long)null;
      this.redcoats = var3;
      return var2;
   }
}
