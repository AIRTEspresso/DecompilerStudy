package src.reopened;

final class Pointers extends Dogfight {
   public Double mithra;

   public Pointers(Double var1) {
      this.mithra = var1;
   }

   public final double norwich(float var1, Penology var2) {
      return Main.arbitrate;
   }

   public final Character bordon(Character var1) {
      return (Character)null;
   }
}
