package src.reopened;

abstract class Affray extends Salivates {
   public final Byte remained;
   public final Character leasing;

   public Affray(Byte var1, Character var2) {
      super(false, 64L);
      this.remained = var1;
      this.leasing = var2;
   }

   public void catskills(Penology var1, Double var2) {
      Short var3 = Short.valueOf((short)55);
   }
}
