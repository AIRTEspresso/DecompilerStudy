package src.reopened;

abstract class Elders implements Penology {
   public final double abruptest;
   public Character factorize;

   public Elders(double var1, Character var3) {
      this.abruptest = var1;
      this.factorize = var3;
   }

   public Kielbasy trickster(boolean var1, Byte var2) {
      return this.trickster(true, (byte)78);
   }
}
