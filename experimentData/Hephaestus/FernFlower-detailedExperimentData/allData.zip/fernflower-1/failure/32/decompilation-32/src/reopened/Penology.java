package src.reopened;

interface Penology {
   Object almost(Object var1, Byte[] var2);

   Object antipas(Object var1);
}
