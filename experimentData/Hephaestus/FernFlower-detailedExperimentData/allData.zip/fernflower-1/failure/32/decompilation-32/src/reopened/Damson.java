package src.reopened;

interface Damson extends Penology {
   Pointers nagpur(Pointers var1);

   long awkward(long var1);
}
