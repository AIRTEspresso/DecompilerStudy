package src.reopened;

interface Unadvised extends Penology {
   Damson served(Object var1);
}
