package src.reopened;

class Nasal extends Dogfight {
   public Nasal() {
   }

   public final void debacle(int var1, Damson var2) {
      byte var3 = -87;
      Main.belittled = var2.nagpur((Pointers)null);
      Short var4 = Short.valueOf(var3);
   }

   public double norwich(float var1, Penology var2) {
      return 49.972;
   }
}
