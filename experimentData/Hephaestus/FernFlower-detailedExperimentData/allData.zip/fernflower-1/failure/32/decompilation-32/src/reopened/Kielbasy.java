package src.reopened;

abstract class Kielbasy implements Penology {
   public final Integer photos;
   public Object occupied;

   public Kielbasy(Integer var1, Object var2) {
      this.photos = var1;
      this.occupied = var2;
   }

   public Short antipas(Short var1) {
      return var1;
   }

   public Object azures() {
      return null;
   }
}
