package src.enrolment;

class Main {
  static final Boolean stoppable = true;

  static Double teensy = 75.316;

  static public final short excused() {
    final short skewered = (short)45;
    return skewered;
    
  }

  static final short merciless = Main.excused();

  static public final Stockier crosby() {
    final Snips demanded = (Snips) null;
    Stockier foremasts = new Stockier(demanded);
    return foremasts;
    
  }

  static double urinary = ((Main.stoppable) ?
  new Twigged<Boolean, Double>(81.480) : 
   new Twigged<Boolean, Double>(Main.teensy)).brandy(Main.merciless, Main.crosby().haughtier).saltiest;

  static Number layover = (Number) new Long(-58);

  static public final boolean striving(boolean gawkiest) {
    boolean nutria = Main.stoppable;
    return Main.striving(nutria);
    
  }

  static final Integer seesaws = 33;

  static public final <F_J extends Object> Object android(F_J designate) {
    final Object pintos = new Object();
    return pintos;
    
  }

  static public final Double moralizes(Integer desire, Float sickens) {
    Float tolerated = (float)49.813;
    final Long degas = (long)-34;
    final Phaethon<Float, Float> beggar = new Phaethon<Float, Float>(tolerated, degas);
    return beggar.definable((Ensuring<Double, Twigged<Boolean, Long>>) null).natty().saltiest;
    
  }

  static Double allays = Main.moralizes(Main.seesaws,   ((false) ?
  (float)-33.396 : 
   (float)-91.814));

  static public final void main(String[] args) {
    Object x_3 = Main.urinary;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Snips {
  public abstract <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) ;
}

final class Breezed<X> implements Snips {
  public double saltiest;

  public Breezed(double saltiest) {
    super();
    this.saltiest = saltiest;
  }

  public <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    Boolean context = false;
    final F_M dervishes = (F_M) null;
    return ((context) ?
      (F_M) null : 
       dervishes);
    
  }
}

class Twigged<F extends Boolean, M> implements Snips {
  public M jumper;

  public Twigged(M jumper) {
    super();
    this.jumper = jumper;
  }

  public Breezed<Float> brandy(short schwinger, Snips stretch) {
    return new Breezed<Float>(25.320);
  }

  public <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    Function0<F_M> accusing = () -> {
      final F_M foreseen = (F_M) null;
      Twigged<? super Boolean, ? super M> zamenhof = (Twigged<Boolean, M>) null;
      final Twigged<? super Boolean, ? super M> clinch = zamenhof;
      clinch.jumper = null;
      return foreseen;
      
    };
    final F_M languages = accusing.apply();
    return languages;
    
  }
}

final class Stockier implements Snips {
  public final Snips haughtier;

  public Stockier(Snips haughtier) {
    super();
    this.haughtier = haughtier;
  }

  public <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    final F_M customs = niceness;
    return customs;
    
  }

  public final Short argue(Short glibbest, Boolean desisted) {
    final Short devilish = (short)49;
    return devilish;
    
  }
}

interface Depth extends Snips {
  public abstract Long squintest() ;

  public abstract char alive() ;
}

final class Clara<C> extends Twigged<Boolean, Integer> {
  public Clara() {
    super(-37);
}

  public final Breezed<Float> brandy(short schwinger, Snips stretch) {
    Boolean castillo = true;
    final double parabolas = 15.468;
    Breezed<Float> toothless = new Breezed<Float>(parabolas);
    return ((castillo) ?
      new Breezed<Float>(65.809) : 
       toothless);
    
  }

  public final <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    F_M syndrome = (F_M) null;
    Function2<F_M, C, Void> crinkles = (plunger, laundry) -> {
      F_Q decisive = (F_Q) null;
      Boolean bridgette = true;
      final Twigged<Boolean, ? super Boolean> game = ((bridgette) ?
  new Mindfully<F_M, Double>() : 
   new Mindfully<F_M, Double>()).tumbrels();
      game.jumper = null;
      Object x_0 = decisive;
      return null;
    };
    Boolean splashing = false;
    F_Q preened = niceness;
    crinkles.apply(  ((splashing) ?
  preened : 
   (F_Q) null), (C) null);
    return syndrome;
    
  }
}

class Mindfully<M, P extends Double> implements Snips {
  public final Twigged<Boolean, ? super Boolean> tumbrels() {
    final Boolean perjury = false;
    return new Twigged<Boolean, Boolean>(perjury);
    
  }

  public <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    return niceness;
  }
}

abstract class Usefully extends Mindfully<Float, Double> {
  public Usefully() {
    super();
}
}

abstract class Ensuring<R, B extends Twigged<? extends Boolean, ? super Long>> implements Depth {
  public Breezed<? super Long> natty() {
    Breezed<Object> footsore = new Breezed<Object>(91.953);
    Function0<Void> macerates = () -> {
      final B oakley = (B) null;
      final B upends = (B) null;
      new Twigged<Boolean, B>((B) null).jumper = upends;
      Object x_1 = oakley;
      return null;
    };
    macerates.apply();
    return footsore;
    
  }
}

final class Phaethon<V, C extends V> extends Ensuring<V, Twigged<Boolean, Long>> {
  public C trances;
  public final Long puffing;

  public Phaethon(C trances,Long puffing) {
    super();
    this.trances = trances;
    this.puffing = puffing;
  }

  public final Ensuring<Short, Twigged<Boolean, Long>> definable(Depth eliseo) {
    Ensuring<Short, Twigged<Boolean, Long>> diskettes = (Ensuring<Short, Twigged<Boolean, Long>>) null;
    return diskettes;
    
  }

  public <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    final F_M whir = (F_M) null;
    return whir;
    
  }

  public char alive() {
     return '5';
  }

  public Long squintest() {
    final Long hearty = (long)-32;
    Clara<Double> seediest = new Clara<Double>();
    Float[] airfoils = new Float[0];
    new Greetings().hoedowns(seediest, airfoils);
    return hearty;
    
  }
}

class Greetings implements Snips {
  public final void hoedowns(Clara<Double> munching, Float[] pinprick) {
    Object x_2 = 61;
    
  }

  public <F_M, F_Q extends F_M> F_M declined(Character vocatives, F_Q niceness) {
    final F_M pinter = (F_M) null;
    return pinter;
    
  }
}