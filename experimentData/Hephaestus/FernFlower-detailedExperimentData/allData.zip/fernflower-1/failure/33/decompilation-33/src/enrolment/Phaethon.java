package src.enrolment;

final class Phaethon extends Ensuring {
   public Object trances;
   public final Long puffing;

   public Phaethon(Object var1, Long var2) {
      this.trances = var1;
      this.puffing = var2;
   }

   public final Ensuring definable(Depth var1) {
      Ensuring var2 = (Ensuring)null;
      return var2;
   }

   public Object declined(Character var1, Object var2) {
      Object var3 = null;
      return var3;
   }

   public char alive() {
      return '5';
   }

   public Long squintest() {
      Long var1 = -32L;
      Clara var2 = new Clara();
      Float[] var3 = new Float[0];
      (new Greetings()).hoedowns(var2, var3);
      return var1;
   }
}
