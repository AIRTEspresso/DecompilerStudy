package src.enrolment;

final class Stockier implements Snips {
   public final Snips haughtier;

   public Stockier(Snips var1) {
      this.haughtier = var1;
   }

   public Object declined(Character var1, Object var2) {
      return var2;
   }

   public final Short argue(Short var1, Boolean var2) {
      Short var3 = Short.valueOf((short)49);
      return var3;
   }
}
