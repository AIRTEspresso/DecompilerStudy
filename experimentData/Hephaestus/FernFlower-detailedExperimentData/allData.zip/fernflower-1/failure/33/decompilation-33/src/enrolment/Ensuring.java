package src.enrolment;

abstract class Ensuring implements Depth {
   public Breezed natty() {
      Breezed var1 = new Breezed(91.953);
      Function0 var2 = () -> {
         Twigged var0 = (Twigged)null;
         Twigged var1 = (Twigged)null;
         (new Twigged((Twigged)null)).jumper = var1;
         return null;
      };
      var2.apply();
      return var1;
   }
}
