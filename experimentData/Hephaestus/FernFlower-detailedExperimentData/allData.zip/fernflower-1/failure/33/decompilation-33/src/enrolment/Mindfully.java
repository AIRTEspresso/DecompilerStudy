package src.enrolment;

class Mindfully implements Snips {
   public final Twigged tumbrels() {
      Boolean var1 = false;
      return new Twigged(var1);
   }

   public Object declined(Character var1, Object var2) {
      return var2;
   }
}
