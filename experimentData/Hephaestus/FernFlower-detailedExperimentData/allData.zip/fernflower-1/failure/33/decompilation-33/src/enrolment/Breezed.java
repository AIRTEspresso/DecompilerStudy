package src.enrolment;

final class Breezed implements Snips {
   public double saltiest;

   public Breezed(double var1) {
      this.saltiest = var1;
   }

   public Object declined(Character var1, Object var2) {
      Boolean var3 = false;
      Object var4 = null;
      return var3 ? null : var4;
   }
}
