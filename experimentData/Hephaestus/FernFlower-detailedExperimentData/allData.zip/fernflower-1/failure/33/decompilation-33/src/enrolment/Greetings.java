package src.enrolment;

class Greetings implements Snips {
   public final void hoedowns(Clara var1, Float[] var2) {
      Integer var3 = 61;
   }

   public Object declined(Character var1, Object var2) {
      Object var3 = null;
      return var3;
   }
}
