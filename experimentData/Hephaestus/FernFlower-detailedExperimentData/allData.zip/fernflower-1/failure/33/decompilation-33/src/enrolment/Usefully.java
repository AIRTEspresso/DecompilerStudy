package src.enrolment;

abstract class Usefully extends Mindfully {
   public Usefully() {
   }
}
