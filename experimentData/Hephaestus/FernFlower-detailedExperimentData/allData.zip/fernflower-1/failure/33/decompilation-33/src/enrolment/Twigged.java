package src.enrolment;

class Twigged implements Snips {
   public Object jumper;

   public Twigged(Object var1) {
      this.jumper = var1;
   }

   public Breezed brandy(short var1, Snips var2) {
      return new Breezed(25.32);
   }

   public Object declined(Character var1, Object var2) {
      Function0 var3 = () -> {
         Object var0 = null;
         Twigged var1 = (Twigged)null;
         var1.jumper = null;
         return var0;
      };
      Object var4 = var3.apply();
      return var4;
   }
}
