package src.enrolment;

interface Snips {
   Object declined(Character var1, Object var2);
}
