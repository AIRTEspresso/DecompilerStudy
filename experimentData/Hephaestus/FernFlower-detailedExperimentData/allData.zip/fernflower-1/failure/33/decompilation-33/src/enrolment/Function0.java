package src.enrolment;

interface Function0 {
   Object apply();
}
