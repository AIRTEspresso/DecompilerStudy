package src.enrolment;

final class Clara extends Twigged {
   public Clara() {
      super(-37);
   }

   public final Breezed brandy(short var1, Snips var2) {
      Boolean var3 = true;
      Breezed var4 = new Breezed(15.468);
      return var3 ? new Breezed(65.809) : var4;
   }

   public final Object declined(Character var1, Object var2) {
      Object var3 = null;
      Function2 var4 = (var0, var1x) -> {
         Object var2 = null;
         Boolean var3 = true;
         Twigged var4 = (var3 ? new Mindfully() : new Mindfully()).tumbrels();
         var4.jumper = null;
         return null;
      };
      Boolean var5 = false;
      var4.apply(var5 ? var2 : null, (Object)null);
      return var3;
   }
}
