package src.enrolment;

interface Depth extends Snips {
   Long squintest();

   char alive();
}
