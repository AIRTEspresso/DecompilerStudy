package src.moderator;

interface Function1 {
   Object apply(Object var1);
}
