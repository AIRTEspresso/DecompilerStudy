package src.moderator;

abstract class Verb implements Geffen {
   public Short raisin;
   public final Double grins;

   public Verb(Short var1, Double var2) {
      this.raisin = var1;
      this.grins = var2;
   }

   public Long darwin(Long var1) {
      Long var2 = -86L;
      Function0 var3 = () -> {
         Integer var0 = 50;
         Function2 var1 = (var0x, var1x) -> {
            boolean var2 = true;
            Main.seeings();
            Integer var3 = 69;
            return null;
         };
         var1.apply("invade", -4.111);
         return null;
      };
      var3.apply();
      return var2;
   }
}
