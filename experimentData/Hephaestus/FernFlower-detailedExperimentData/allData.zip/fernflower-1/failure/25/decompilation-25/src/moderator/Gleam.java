package src.moderator;

class Gleam {
   public final Byte baedeker;
   public Character cutback;

   public Gleam(Byte var1, Character var2) {
      this.baedeker = var1;
      this.cutback = var2;
   }

   public final Double crouching(String var1) {
      return 51.855;
   }

   public Character keynote(Gleam var1, Float var2) {
      Character var3 = 'Z';
      Function2 var4 = (var0, var1x) -> {
         Character[] var2 = new Character[0];
         return null;
      };
      var4.apply(Short.valueOf((short)34), var1);
      return var3;
   }
}
