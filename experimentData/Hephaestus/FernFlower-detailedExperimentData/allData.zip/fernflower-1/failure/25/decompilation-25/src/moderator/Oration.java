package src.moderator;

abstract class Oration extends Gleam {
   public final Braiding koufax;

   public Oration(Braiding var1) {
      super((byte)-47, 'Q');
      this.koufax = var1;
   }

   public Verb earshot(Object var1) {
      return (Verb)null;
   }

   public final Character keynote(Gleam var1, Float var2) {
      Character var3 = 'w';
      return var3;
   }
}
