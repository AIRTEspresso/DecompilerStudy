package src.moderator;

abstract class Hollowly extends Verb {
   public final Boolean tracery;

   public Hollowly(Boolean var1) {
      super(Short.valueOf((short)-69), 34.114);
      this.tracery = var1;
   }

   public Long darwin(Long var1) {
      return 68L;
   }

   public Integer dairies(Integer var1, Byte var2) {
      return -61;
   }
}
