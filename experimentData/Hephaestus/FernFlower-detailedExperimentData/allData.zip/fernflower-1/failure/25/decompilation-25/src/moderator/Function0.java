package src.moderator;

interface Function0 {
   Object apply();
}
