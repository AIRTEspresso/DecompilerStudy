package src.moderator;

interface Geffen {
   Long darwin(Long var1);
}
