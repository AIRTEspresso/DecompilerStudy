package src.pictorial;

final class Gatherer extends Validates {
   public final boolean exocet;

   public Gatherer(boolean var1) {
      super((Nauseate)null);
      this.exocet = var1;
   }

   public final void gillette() {
      Short var1 = Short.valueOf((short)-20);
      Float var2 = -39.36F;
      Main.tripos = var2;
   }

   public Byte freaking(Market var1, Long var2) {
      return 23;
   }
}
