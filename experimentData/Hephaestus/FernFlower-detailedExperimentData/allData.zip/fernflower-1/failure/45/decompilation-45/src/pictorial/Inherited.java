package src.pictorial;

class Inherited implements Market {
   public Market hitting(Boolean var1) {
      return (Market)null;
   }

   public final Market bareback(String var1, short var2) {
      Boolean var3 = true;
      Pore var4 = var3 ? (Pore)null : (Pore)null;
      Market var5 = var4.nicotine;
      return var5;
   }
}
