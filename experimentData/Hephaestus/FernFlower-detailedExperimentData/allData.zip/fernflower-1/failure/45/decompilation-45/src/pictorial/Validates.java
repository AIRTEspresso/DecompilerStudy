package src.pictorial;

abstract class Validates extends Subteens {
   public final Inherited tornado;

   public Validates(Inherited var1) {
      super(new Serfs((byte)94), new Desiring(false, -70.515F));
      this.tornado = var1;
   }

   public Market hitting(Long var1) {
      return (Market)null;
   }
}
