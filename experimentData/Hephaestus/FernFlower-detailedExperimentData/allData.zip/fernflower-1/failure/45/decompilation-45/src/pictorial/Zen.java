package src.pictorial;

abstract class Zen extends Pore {
   public final short hipping;
   public final Nauseate suits;

   public Zen(short var1, Nauseate var2) {
      super((Market)null, (short)-30);
      this.hipping = var1;
      this.suits = var2;
   }

   public void cutback(Splodge var1, String var2) {
      Long var3 = -78L;
   }
}
