package src.pictorial;

abstract class Pore implements Market {
   public Market nicotine;
   public final short hipping;

   public Pore(Market var1, short var2) {
      this.nicotine = var1;
      this.hipping = var2;
   }

   public abstract Inherited soggy();
}
