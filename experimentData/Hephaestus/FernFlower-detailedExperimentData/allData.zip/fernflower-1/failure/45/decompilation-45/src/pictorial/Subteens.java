package src.pictorial;

abstract class Subteens implements Market {
   public Serfs venuses;
   public Desiring dopey;

   public Subteens(Serfs var1, Desiring var2) {
      this.venuses = var1;
      this.dopey = var2;
   }

   public abstract Byte freaking(Market var1, Object var2);

   public Market hitting(Object var1) {
      return (Market)null;
   }
}
