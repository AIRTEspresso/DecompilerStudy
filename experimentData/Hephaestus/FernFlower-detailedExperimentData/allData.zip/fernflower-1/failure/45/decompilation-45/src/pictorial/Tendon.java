package src.pictorial;

final class Tendon extends Validates {
   public Tendon() {
      super(new Inherited());
   }

   public final void demeanor(Untruer var1) {
      (new Gatherer(true)).gillette();
      Double var2 = 37.71;
   }

   public Byte freaking(Market var1, Long var2) {
      Byte var3 = 30;
      Main.leavening(5, 17L);
      return var3;
   }
}
