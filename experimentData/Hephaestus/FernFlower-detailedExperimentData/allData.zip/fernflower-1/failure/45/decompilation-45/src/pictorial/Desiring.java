package src.pictorial;

final class Desiring {
   public final Boolean bean;
   public Float secession;

   public Desiring(Boolean var1, Float var2) {
      this.bean = var1;
      this.secession = var2;
   }

   public final Float slackly() {
      Float var1 = (Float)null;
      return var1;
   }
}
