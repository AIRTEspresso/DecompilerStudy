package src.pictorial;

interface Vermilion extends Market {
   Validates chloe(Object var1, Object var2);
}
