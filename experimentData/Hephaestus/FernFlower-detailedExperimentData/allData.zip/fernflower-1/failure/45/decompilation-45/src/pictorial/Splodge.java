package src.pictorial;

class Splodge extends Pore {
   public final short hipping;
   public final Boolean coaxed;

   public Splodge(short var1, Boolean var2) {
      super((Market)null, (short)60);
      this.hipping = var1;
      this.coaxed = var2;
   }

   public Inherited soggy() {
      Validates var1 = (Validates)null;
      Inherited var2 = (new Untruer(var1, true)).dregs.tornado;
      return var2;
   }

   public Market hitting(Character var1) {
      Function2 var2 = (var0, var1x) -> {
         Nauseate var2 = (Nauseate)null;
         Vermilion var3 = var2.snootiest;
         Boolean var4 = false;
         (var4 ? (Zen)null : (Zen)null).cutback((Splodge)null, "nylons");
         return var3;
      };
      Byte var3 = 89;
      Serfs var4 = new Serfs(var3);
      Byte var5 = var4.omit;
      return ((Vermilion)var2.apply(var5, (Double[])(new Object[]{6.664, 7.221, -16.89}))).chloe(89L, (Validates)null).tornado;
   }
}
