package src.pictorial;

class Untruer implements Market {
   public Validates dregs;
   public final boolean praia;

   public Untruer(Validates var1, boolean var2) {
      this.dregs = var1;
      this.praia = var2;
   }

   public Market hitting(Integer var1) {
      return (Market)null;
   }

   public final String overseen(Character var1) {
      String var2 = "ranks";
      return var2;
   }
}
