package src.pictorial;

interface Function0 {
   Object apply();
}
