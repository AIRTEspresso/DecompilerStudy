package src.pictorial;

interface Market {
   Market hitting(Object var1);
}
