package src.pictorial;

abstract class Nauseate extends Inherited {
   public Vermilion snootiest;
   public String retains;

   public Nauseate(Vermilion var1, String var2) {
      this.snootiest = var1;
      this.retains = var2;
   }

   public final Market hitting(Boolean var1) {
      Vermilion var2 = this.snootiest;
      return var2;
   }

   public float mesh(float var1, Double var2) {
      return 7.104F;
   }
}
