package src.pictorial;

final class Serfs {
   public Byte omit;

   public Serfs(Byte var1) {
      this.omit = var1;
   }

   public final Number lenin(Object var1, Number var2) {
      Short var3 = Short.valueOf((short)99);
      Float var4 = 95.918F;
      Main.knothole.secession = var4;
      return var3;
   }

   public final Object proneness() {
      Object var1 = null;
      Function0 var2 = () -> {
         Object var0 = null;
         return null;
      };
      var2.apply();
      return var1;
   }
}
