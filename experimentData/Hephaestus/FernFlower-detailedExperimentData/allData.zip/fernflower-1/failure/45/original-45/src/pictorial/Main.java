package src.pictorial;

class Main {
  static final Boolean canoed = false;

  static final Float torpor = (float)-84.757;

  static final Desiring<Float> knothole = new Desiring<Float>(Main.canoed, Main.torpor);

  static final Object guessers = ((Main.knothole.bean) ?
  new Serfs<Boolean, Long>((byte)-60).omit : 
   35.987);

  static Byte offset = ((((false) ?
    false : 
     true)) ?
  ((Subteens<Long, Market<Long, Boolean>, Double>) null).freaking((Market<Long, Boolean>) null, 58.297) : 
   ((false) ?
    (byte)-45 : 
     (byte)10));

  static Float tripos = Main.knothole.slackly();

  static Float muscatels = Main.knothole.secession;

  static public final Long aquifer(String economics) {
    final Long harte = (long)-81;
    final Validates calipered = (Validates) null;
    final Validates randomly = calipered;
    new Tendon().demeanor(new Untruer(randomly, false));
    return harte;
    
  }

  static public final void leavening(int rwandan, long insures) {
    Object x_5 = new Integer[0];
    
  }

  static public final void main(String[] args) {
    final Validates oarlocks = ((Vermilion<Number, Boolean, Integer>) null).chloe(null, (short)48);
    Market<Double, Boolean> squander = (Market<Double, Boolean>) null;
    final Byte pentagons = oarlocks.freaking(squander, Main.aquifer("queried"));
    Object x_2 = new Serfs<Short, Character>(pentagons).omit;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Desiring<J extends Float> {
  public final Boolean bean;
  public J secession;

  public Desiring(Boolean bean,J secession) {
    this.bean = bean;
    this.secession = secession;
  }

  public final J slackly() {
    final J tumbrels = (J) null;
    return tumbrels;
    
  }
}

final class Serfs<G, A> {
  public Byte omit;

  public Serfs(Byte omit) {
    this.omit = omit;
  }

  public final Number lenin(G powdered, Number samoset) {
    final Short alertly = (short)99;
    final Float wallets = (float)95.918;
    Main.knothole.secession = wallets;
    return alertly;
    
  }

  public final A proneness() {
    A advise = (A) null;
    Function0<Void> draws = () -> {
      A mexicans = (A) null;
      Object x_0 = mexicans;
      return null;
    };
    draws.apply();
    return advise;
    
  }
}

interface Market<U, F extends Boolean> {
  public abstract Market<F, ? super F> hitting(U usurped) ;
}

abstract class Subteens<Q extends Number, A extends Market<? super Q, ? extends Boolean>, R> implements Market<R, Boolean> {
  public Serfs<Byte, ? super Double> venuses;
  public Desiring<? extends Float> dopey;

  public Subteens(Serfs<Byte, ? super Double> venuses,Desiring<? extends Float> dopey) {
    super();
    this.venuses = venuses;
    this.dopey = dopey;
  }

  public abstract Byte freaking(A adage, R lew) ;

  public Market<Boolean, ? super Boolean> hitting(R usurped) {
    return (Market<Boolean, Boolean>) null;
  }
}

class Inherited<N extends Integer, X extends Market<? extends Short, Boolean>> implements Market<Boolean, Boolean> {
  public Market<Boolean, ? super Boolean> hitting(Boolean usurped) {
    return (Market<Boolean, Boolean>) null;
  }

  public final X bareback(String beans, short enfolded) {
    Boolean estates = true;
    final Pore<X, ? super Inherited<Integer, Market<Short, Boolean>>, ? super Integer> bareness = ((estates) ?
      (Pore<X, Inherited<Integer, Market<Short, Boolean>>, Integer>) null : 
       (Pore<X, Inherited<Integer, Market<Short, Boolean>>, Integer>) null);
    X xenia = bareness.nicotine;
    return xenia;
    
  }
}

abstract class Pore<K extends Market<? extends Short, Boolean>, C extends Inherited<? super Integer, ? super Market<Short, Boolean>>, X> implements Market<X, Boolean> {
  public K nicotine;
  public final short hipping;

  public Pore(K nicotine,short hipping) {
    super();
    this.nicotine = nicotine;
    this.hipping = hipping;
  }

  public abstract C soggy() ;
}

class Splodge extends Pore<Market<Short, Boolean>, Inherited<Integer, Market<Short, Boolean>>, Character> {
  public final short hipping;
  public final Boolean coaxed;

  public Splodge(short hipping,Boolean coaxed) {
    super((Market<Short, Boolean>) null, (short)60);
    this.hipping = hipping;
    this.coaxed = coaxed;
  }

  public Inherited<Integer, Market<Short, Boolean>> soggy() {
    Validates blunder = (Validates) null;
    Inherited<Integer, Market<Short, Boolean>> pickerel = new Untruer(blunder, true).dregs.tornado;
    return pickerel;
    
  }

  public Market<Boolean, ? super Boolean> hitting(Character usurped) {
    Function2<Byte, Double[], Vermilion<Validates, Long, Byte>> dings = (burbling, fool) -> {
      final Nauseate<Long> coauthors = (Nauseate<Long>) null;
      final Vermilion<Validates, Long, Byte> thinkers = coauthors.snootiest;
      Boolean meet = false;
        ((meet) ?
  (Zen<Splodge>) null : 
   (Zen<Splodge>) null).cutback((Splodge) null, "nylons");
      return thinkers;
      
    };
    final Byte cork = (byte)89;
    Serfs<Object, ? extends Boolean> killjoys = new Serfs<Object, Boolean>(cork);
    Byte timed = killjoys.omit;
    return dings.apply(timed,   ((false) ?
  (Double[]) new Object[]{-77.284, -61.601, -68.196} : 
   (Double[]) new Object[]{6.664, 7.221, -16.89})).chloe(  ((true) ?
  (long)89 : 
   (long)-69), (Validates) null).tornado;
    
  }
}

abstract class Validates extends Subteens<Double, Market<Double, Boolean>, Long> {
  public final Inherited<Integer, Market<Short, Boolean>> tornado;

  public Validates(Inherited<Integer, Market<Short, Boolean>> tornado) {
    super(new Serfs<Byte, Double>((byte)94), new Desiring<Float>(false, (float)-70.515));
    this.tornado = tornado;
  }

  public Market<Boolean, ? super Boolean> hitting(Long usurped) {
    return (Market<Boolean, Boolean>) null;
  }
}

class Untruer implements Market<Integer, Boolean> {
  public Validates dregs;
  public final boolean praia;

  public Untruer(Validates dregs,boolean praia) {
    super();
    this.dregs = dregs;
    this.praia = praia;
  }

  public Market<Boolean, ? super Boolean> hitting(Integer usurped) {
    return (Market<Boolean, Boolean>) null;
  }

  public final String overseen(Character verdi) {
    String refuel = "ranks";
    return refuel;
    
  }
}

interface Vermilion<V, H, P extends Number> extends Market<Boolean, Boolean> {
  public abstract Validates chloe(H octavio, V plectra) ;
}

abstract class Nauseate<B> extends Inherited<Integer, Market<Short, Boolean>> {
  public Vermilion<Validates, Long, Byte> snootiest;
  public String retains;

  public Nauseate(Vermilion<Validates, Long, Byte> snootiest,String retains) {
    super();
    this.snootiest = snootiest;
    this.retains = retains;
  }

  public final Market<Boolean, ? super Boolean> hitting(Boolean usurped) {
    Market<Boolean, ? super Boolean> plights = snootiest;
    return plights;
    
  }

  public float mesh(float snatch, Double encamp) {
    return (float)7.104;
  }
}

abstract class Zen<N extends Splodge> extends Pore<Market<Short, Boolean>, Inherited<Integer, Market<Short, Boolean>>, Boolean> {
  public final short hipping;
  public final Nauseate<? super N> suits;

  public Zen(short hipping,Nauseate<? super N> suits) {
    super((Market<Short, Boolean>) null, (short)-30);
    this.hipping = hipping;
    this.suits = suits;
  }

  public void cutback(N upbraided, String women) {
    final Long malaysia = (long)-78;
    Object x_1 = malaysia;
    
  }
}

final class Tendon extends Validates {
  public Tendon() {
    super(new Inherited<Integer, Market<Short, Boolean>>());
}

  public final void demeanor(Untruer thronging) {
    new Gatherer(true).gillette();
    Object x_3 = 37.710;
    
  }

  public Byte freaking(Market<Double, Boolean> adage, Long lew) {
    Byte anecdota = (byte)30;
    Main.leavening(5, (long)17);
    return anecdota;
    
  }
}

final class Gatherer extends Validates {
  public final boolean exocet;

  public Gatherer(boolean exocet) {
    super((Nauseate<Byte>) null);
    this.exocet = exocet;
  }

  public final void gillette() {
    Short taunt = (short)-20;
    final Float lincolns = (float)-39.360;
    Main.tripos = lincolns;
    Object x_4 = taunt;
    
  }

  public Byte freaking(Market<Double, Boolean> adage, Long lew) {
    return (byte)23;
  }
}