package src.banded;

abstract class Equals extends Poling {
   public final Poling condiment;
   public final String remake;

   public Equals(Poling var1, String var2) {
      super("lebesgue", "desists");
      this.condiment = var1;
      this.remake = var2;
   }

   public Object foreskin() {
      Object var1 = new Object();
      this.condiment.miltonic = "rifer";
      return var1;
   }

   public void mushed() {
      this.condiment.miltonic = "schulz";
      Object var1 = null;
   }
}
