package src.banded;

abstract class Poling extends Slabbing {
   public final String remake;
   public String miltonic;

   public Poling(String var1, String var2) {
      super(true);
      this.remake = var1;
      this.miltonic = var2;
   }

   public abstract void mushed();

   public abstract Object foreskin();
}
