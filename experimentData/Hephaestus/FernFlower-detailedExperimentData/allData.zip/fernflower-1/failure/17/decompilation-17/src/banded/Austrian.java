package src.banded;

class Austrian extends Slabbing {
   public Austrian() {
      super(true);
   }

   public final Boolean comedy(Integer var1, Float var2) {
      Boolean var3 = true;
      Equals var4 = (Equals)null;
      String var5 = "bedpans";
      (new Harassing(var4, "insulted", var5)).dahlia.condiment.mushed();
      return var3;
   }

   public final float dartboard(Austrian var1) {
      return -65.157F;
   }
}
