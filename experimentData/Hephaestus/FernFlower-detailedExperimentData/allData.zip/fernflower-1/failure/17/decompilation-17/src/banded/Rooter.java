package src.banded;

interface Rooter {
   Harassing wardrobes(Double var1);

   String noh();
}
