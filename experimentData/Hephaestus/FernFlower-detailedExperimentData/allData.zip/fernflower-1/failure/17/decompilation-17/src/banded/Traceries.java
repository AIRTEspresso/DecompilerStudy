package src.banded;

interface Traceries extends Rooter {
   void cards(Short var1);
}
