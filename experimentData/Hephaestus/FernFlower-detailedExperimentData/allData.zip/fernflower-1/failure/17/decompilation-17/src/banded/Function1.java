package src.banded;

interface Function1 {
   Object apply(Object var1);
}
