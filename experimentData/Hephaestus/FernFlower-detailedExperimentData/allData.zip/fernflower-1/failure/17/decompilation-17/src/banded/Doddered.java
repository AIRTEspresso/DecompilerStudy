package src.banded;

abstract class Doddered extends Laxatives {
   public final String remake;
   public final long attic;

   public Doddered(String var1, long var2) {
      super('y', "newsflash");
      this.remake = var1;
      this.attic = var2;
   }

   public void tubeless(Byte var1) {
      Lobbyist var2 = (Lobbyist)null;
      var2.baselines((Wombs)null, (Rooter[])null);
      Long var3 = -59L;
   }
}
