package src.banded;

abstract class Laxatives extends Poling {
   public final Character bikini;
   public final String remake;

   public Laxatives(Character var1, String var2) {
      super("rosario", "metallica");
      this.bikini = var1;
      this.remake = var2;
   }

   public void mushed() {
      Laxatives var1 = (Laxatives)null;
      Boolean var2 = var1.pigeon;
      Laxatives var3 = (Laxatives)null;
   }

   public Object foreskin() {
      Long var1 = new Long(-43L);
      return var1;
   }
}
