package src.banded;

abstract class Wombs extends Laxatives {
   public final double span;
   public final String remake;

   public Wombs(double var1, String var3) {
      super('t', "frank");
      this.span = var1;
      this.remake = var3;
   }

   public void mushed() {
      Laxatives var1 = (Laxatives)null;
   }

   public final Object foreskin() {
      Object var1 = new Object();
      Doddered var2 = (Doddered)null;
      var2.tubeless((byte)37);
      return var1;
   }
}
