package src.banded;

abstract class Sidestep extends Austrian {
   public Long commuting;
   public Poling intuiting;

   public Sidestep(Long var1, Poling var2) {
      this.commuting = var1;
      this.intuiting = var2;
   }
}
