package src.banded;

final class Sermons {
   public final Integer[] workhouse(Integer[] var1) {
      Integer[] var2 = (Integer[])(new Object[]{(Integer)null});
      Function1 var3 = (var0) -> {
         Slabbing var1 = Main.banach(-87);
         boolean var2 = var1.pigeon;
         Boolean var3 = var2;
         return null;
      };
      var3.apply((byte)59);
      return var2;
   }
}
