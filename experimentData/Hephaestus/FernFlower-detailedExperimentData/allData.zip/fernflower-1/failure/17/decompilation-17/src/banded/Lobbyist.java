package src.banded;

abstract class Lobbyist extends Sidestep {
   public Lobbyist() {
      super(72L, new Harassing((Equals)null, "beanbags", "snowdrop"));
   }

   public void baselines(Object var1, Rooter[] var2) {
      Rooter var3 = (Rooter)null;
      Short var4 = Short.valueOf((short)71);
      ((Traceries)null).cards(var4);
   }
}
