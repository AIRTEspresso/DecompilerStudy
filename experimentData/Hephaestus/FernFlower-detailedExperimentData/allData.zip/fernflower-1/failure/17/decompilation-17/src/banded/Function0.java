package src.banded;

interface Function0 {
   Object apply();
}
