package src.banded;

class Slabbing {
   public final boolean pigeon;

   public Slabbing(boolean var1) {
      this.pigeon = var1;
   }
}
