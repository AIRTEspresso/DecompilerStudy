package src.banded;

class Harassing extends Poling {
   public Equals dahlia;
   public final String remake;
   public String miltonic;

   public Harassing(Equals var1, String var2, String var3) {
      super("sputnik", "palisade");
      this.dahlia = var1;
      this.remake = var2;
      this.miltonic = var3;
   }

   public void mushed() {
      Long var1 = 10L;
      this.miltonic = "buss";
   }

   public Object foreskin() {
      return 5L;
   }
}
