package src.velez;

interface Function0 {
   Object apply();
}
