package src.velez;

abstract class Icecaps extends Cling {
   public final short repenting;
   public final Sophocles baled;

   public Icecaps(short var1, Sophocles var2) {
      super((byte)-40, (short)-38);
      this.repenting = var1;
      this.baled = var2;
   }
}
