package src.velez;

abstract class Fondu extends Cling {
   public final Gillette minored;
   public final short repenting;

   public Fondu(Gillette var1, short var2) {
      super((byte)-37, (short)-56);
      this.minored = var1;
      this.repenting = var2;
   }

   public abstract Fondu excepted();
}
