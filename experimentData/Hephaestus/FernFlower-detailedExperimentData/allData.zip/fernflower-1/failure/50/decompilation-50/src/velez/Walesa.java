package src.velez;

class Walesa extends Fondu {
   public final Object covets;
   public final Gillette minored;
   public final short repenting;

   public Walesa(Object var1, Gillette var2, short var3) {
      super(new Gillette(-12.472F, (short)12), (short)21);
      this.covets = var1;
      this.minored = var2;
      this.repenting = var3;
   }

   public Fondu excepted() {
      Object var1 = null;
      Gillette var2 = new Gillette(-27.245F, (short)21);
      Main.mocker((Object)null, 34L);
      return new Walesa(var1, var2, (short)16);
   }

   public Byte dissolute(Boolean var1) {
      Byte var2 = -31;
      Main.purplish((Walesa)null);
      return var2;
   }
}
