package src.velez;

class Cling {
   public byte transmit;
   public final short repenting;

   public Cling(byte var1, short var2) {
      this.transmit = var1;
      this.repenting = var2;
   }
}
