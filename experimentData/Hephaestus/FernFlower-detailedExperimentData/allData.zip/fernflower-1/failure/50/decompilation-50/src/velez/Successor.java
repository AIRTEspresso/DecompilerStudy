package src.velez;

final class Successor extends Cling {
   public final short repenting;
   public Object tracker;

   public Successor(short var1, Object var2) {
      super((byte)-57, (short)87);
      this.repenting = var1;
      this.tracker = var2;
   }

   public final Object membranes() {
      Function0 var1 = () -> {
         Walesa var0 = new Walesa((Object)null, new Gillette(64.921F, (short)-59), (short)-88);
         Successor var1 = (Successor)null;
         var1.tracker = new Cling((byte)79, (short)96);
         return var0;
      };
      Walesa var2 = (Walesa)var1.apply();
      Main.stood(var2);
      return var2.covets;
   }
}
