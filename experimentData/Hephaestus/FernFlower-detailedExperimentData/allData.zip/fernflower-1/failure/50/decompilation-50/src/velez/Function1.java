package src.velez;

interface Function1 {
   Object apply(Object var1);
}
