package src.velez;

abstract class Sophocles extends Walesa {
   public final Float covets;

   public Sophocles(Float var1) {
      super(-80.15F, new Gillette(-14.817F, (short)19), (short)46);
      this.covets = var1;
   }

   public abstract void detecting(Successor var1, byte var2);
}
