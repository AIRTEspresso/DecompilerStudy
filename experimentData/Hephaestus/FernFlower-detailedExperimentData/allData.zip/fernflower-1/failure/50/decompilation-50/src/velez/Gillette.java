package src.velez;

final class Gillette extends Cling {
   public final Float chiefer;
   public final short repenting;

   public Gillette(Float var1, short var2) {
      super((byte)-60, (short)54);
      this.chiefer = var1;
      this.repenting = var2;
   }

   public final short retarding() {
      return this.repenting;
   }
}
