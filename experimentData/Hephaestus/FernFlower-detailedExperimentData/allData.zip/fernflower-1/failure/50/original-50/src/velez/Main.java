package src.velez;

class Main {
  static public final Float verb(Float dorky, Short surely) {
    Gillette tristan = ((Fondu) null).minored;
    final Float watches = tristan.chiefer;
    return watches;
    
  }

  static public final <F_S extends Long, F_A> void mocker(F_A comically, F_S esophagi) {
    F_A feminine = (F_A) null;
    Object x_0 = feminine;
    
  }

  static public final void purplish(Walesa<Byte> leitmotif) {
    final char normalize = 'W';
    final Gillette avocados = new Gillette((float)56.971, (short)91);
    Main.lifesaver(avocados, (byte)-79);
    Object x_1 = normalize;
    
  }

  static public final void lifesaver(Gillette scalloped, byte offset) {
    Object x_2 = 59.108;
    
  }

  static public final void stood(Fondu standouts) {
    Short marisol = (short)62;
    Sophocles acoustic = (Sophocles) null;
    final Sophocles satyrs = (Sophocles) null;
      ((false) ?
  acoustic : 
   satyrs).detecting(null, satyrs.dissolute(false));
    Object x_3 = marisol;
    
  }

  static public final Boolean ironic() {
    return false;
  }

  static final Boolean shepherd = Main.ironic();

  static final Integer altruists = 28;

  static Long pitted = (long)-69;

  static boolean simper = ((Main.shepherd) ?
  (Main.altruists > Main.pitted) : 
   Main.shepherd);

  static public final void main(String[] args) {
    Gillette pompeii = new Gillette((float)19.878, (short)-71);
    Gillette spriest = pompeii;
    Object x_4 = spriest;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Cling {
  public byte transmit;
  public final short repenting;

  public Cling(byte transmit,short repenting) {
    this.transmit = transmit;
    this.repenting = repenting;
  }
}

final class Gillette extends Cling {
  public final Float chiefer;
  public final short repenting;

  public Gillette(Float chiefer,short repenting) {
    super((byte)-60, (short)54);
    this.chiefer = chiefer;
    this.repenting = repenting;
  }

  public final short retarding() {
    return repenting;
  }
}

abstract class Fondu extends Cling {
  public final Gillette minored;
  public final short repenting;

  public Fondu(Gillette minored,short repenting) {
    super((byte)-37, (short)-56);
    this.minored = minored;
    this.repenting = repenting;
  }

  public abstract Fondu excepted() ;
}

final class Successor<A extends Gillette, N, C> extends Cling {
  public final short repenting;
  public C tracker;

  public Successor(short repenting,C tracker) {
    super((byte)-57, (short)87);
    this.repenting = repenting;
    this.tracker = tracker;
  }

  public final C membranes() {
    Function0<Walesa<C>> gill = () -> {
      final Walesa<C> piaget = new Walesa<C>((C) null, new Gillette((float)64.921, (short)-59), (short)-88);
      Successor<Gillette, Object, Cling> gaudier = (Successor<Gillette, Object, Cling>) null;
      gaudier.tracker = new Cling((byte)79, (short)96);
      return piaget;
      
    };
    Walesa<C> whites = gill.apply();
    final Walesa<C> obit = whites;
    Fondu jordan = whites;
    Main.stood(jordan);
    return obit.covets;
    
  }
}

class Walesa<W> extends Fondu {
  public final W covets;
  public final Gillette minored;
  public final short repenting;

  public Walesa(W covets,Gillette minored,short repenting) {
    super(new Gillette((float)-12.472, (short)12), (short)21);
    this.covets = covets;
    this.minored = minored;
    this.repenting = repenting;
  }

  public Fondu excepted() {
    final W contrive = (W) null;
    final short achievers = (short)21;
    Gillette tangoed = new Gillette((float)-27.245, achievers);
    Main.mocker((W) null, (long)34);
    return new Walesa<W>(contrive, tangoed, (short)16);
    
  }

  public Byte dissolute(Boolean coverlet) {
    Byte dravidian = (byte)-31;
    Main.purplish((Walesa<Byte>) null);
    return dravidian;
    
  }
}

abstract class Sophocles extends Walesa<Float> {
  public final Float covets;

  public Sophocles(Float covets) {
    super((float)-80.150, new Gillette((float)-14.817, (short)19), (short)46);
    this.covets = covets;
  }

  public abstract void detecting(Successor<? extends Gillette, ? extends Float, ? super Double> manure, byte miscarry) ;
}

abstract class Icecaps<Q extends Cling> extends Cling {
  public final short repenting;
  public final Sophocles baled;

  public Icecaps(short repenting,Sophocles baled) {
    super((byte)-40, (short)-38);
    this.repenting = repenting;
    this.baled = baled;
  }
}