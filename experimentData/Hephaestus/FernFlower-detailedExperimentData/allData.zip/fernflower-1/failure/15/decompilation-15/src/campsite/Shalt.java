package src.campsite;

class Shalt implements Keening {
   public final Integer liberia;
   public final Object canard;

   public Shalt(Integer var1, Object var2) {
      this.liberia = var1;
      this.canard = var2;
   }

   public void iterators() {
      Main.runaways = -62;
      Float var1 = -78.379F;
   }

   public Float expire(Tarim var1) {
      Float var2 = -63.157F;
      Swellings var3 = (Swellings)null;
      var3.insect();
      return var2;
   }

   public void shoehorn(Byte var1, Float var2) {
      Integer var3 = -63;
      Main.runaways = var3;
      Object var4 = null;
   }
}
