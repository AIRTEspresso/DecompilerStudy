package src.campsite;

final class Lowers {
   public Long caucussed;
   public final Character dumber;

   public Lowers(Long var1, Character var2) {
      this.caucussed = var1;
      this.dumber = var2;
   }
}
