package src.campsite;

class Main {
   static Integer runaways = 61;
   static Lowers recliner = chiefer();
   static final Lowers incurable;
   static char sap;

   public static final Short devours(Long var0) {
      Short var1 = Short.valueOf((short)-97);
      griming();
      return var1;
   }

   public static final void griming() {
      Function2 var0 = (var0x, var1x) -> {
         Lowers var2 = chiefer();
         Long var3 = var2.caucussed;
         hostler();
         return var3;
      };
      Integer var1 = runaways;
      Double var2 = 9.348;
      Double var3 = (new Tarim(var2, -52.886)).blockhead;
      Function0 var4 = () -> {
         Function2 var0 = (var0x, var1x) -> {
            Double var2 = tube();
            return var2;
         };
         Byte var1 = -49;
         byte var2 = var1;
         Function2 var3 = (var0x, var1x) -> {
            Boolean var2 = true;
            Shalt var3 = new Shalt(-12, 88.989);
            var3.iterators();
            Short var4 = Short.valueOf((short)(var2 ? 59 : -69));
            return null;
         };
         Integer var4 = 29;
         var3.apply(var4, (new Shalt(40, Short.valueOf((short)-45))).liberia);
         return (Double)var0.apply((byte)41, var2);
      };
      var3 = (Double)var4.apply();
      var0.apply(var1, var3);
   }

   public static final Lowers chiefer() {
      Long var0 = -68L;
      Character var1 = 'O';
      Lowers var2 = new Lowers(var0, var1);
      Function2 var3 = (var0x, var1x) -> {
         Character var2 = 'r';
         return null;
      };
      var3.apply(70.499F, -49.62F);
      return var2;
   }

   public static final void hostler() {
      Long var0 = -67L;
      Character var1 = 'w';
      char var2 = (new Lowers(var0, var1)).dumber;
      runaways = 91;
      Character var3 = var2;
   }

   public static final Double tube() {
      Double var0 = 53.408;
      Keening var1 = (Keening)null;
      Byte var2 = 81;
      var1.shoehorn(var2, 59.406F);
      return var0;
   }

   public static final Lowers kramer() {
      return new Lowers(24L, '8');
   }

   public static final boolean littoral(byte var0) {
      Short var1 = Short.valueOf((short)-60);
      Tarim var2 = new Tarim(54.579, 96.645);
      double var3 = var2.blockhead;
      Function2 var5 = (var0x, var1x) -> {
         Long var2 = -50L;
         return var2;
      };
      return (double)var1 <= var3 && (littoral((byte)20) || (new Babysat(false, 82.29)).confiding) || ((Harelip)null).pensions((Long)var5.apply(-80L, 5)) == new Babysat(false, -71.199);
   }

   public static final Keening brandy(Double var0) {
      Boolean var1 = false;
      Harelip var2 = (Harelip)null;
      Boolean var3 = true;
      return var3 ? (Harelip)null : (Harelip)null;
   }

   public static final void main(String[] var0) {
      long var1 = -53L;
      Long var3 = var1;
   }

   static {
      incurable = recliner;
      sap = incurable.dumber;
   }
}
