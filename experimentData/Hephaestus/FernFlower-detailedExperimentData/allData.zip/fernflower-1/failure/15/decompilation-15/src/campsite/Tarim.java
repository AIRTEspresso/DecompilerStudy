package src.campsite;

class Tarim {
   public final Double blockhead;
   public final Object keynes;

   public Tarim(Double var1, Object var2) {
      this.blockhead = var1;
      this.keynes = var2;
   }

   public int hyperbola(Short var1) {
      return 89;
   }

   public Object bauhaus(Object var1, Double var2) {
      Object var3 = null;
      var3 = null;
      return var3;
   }
}
