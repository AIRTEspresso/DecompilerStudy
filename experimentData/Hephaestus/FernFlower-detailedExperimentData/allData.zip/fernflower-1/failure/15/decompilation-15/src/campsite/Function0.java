package src.campsite;

interface Function0 {
   Object apply();
}
