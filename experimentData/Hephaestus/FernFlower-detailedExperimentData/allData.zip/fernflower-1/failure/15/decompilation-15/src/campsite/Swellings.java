package src.campsite;

abstract class Swellings extends Tarim {
   public Shalt creole;

   public Swellings(Shalt var1) {
      super(69.31, "standbys");
      this.creole = var1;
   }

   public abstract void insect();
}
