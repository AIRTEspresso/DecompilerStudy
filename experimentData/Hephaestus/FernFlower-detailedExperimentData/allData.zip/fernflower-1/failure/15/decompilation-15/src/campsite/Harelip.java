package src.campsite;

interface Harelip extends Keening {
   Babysat pensions(Object var1);
}
