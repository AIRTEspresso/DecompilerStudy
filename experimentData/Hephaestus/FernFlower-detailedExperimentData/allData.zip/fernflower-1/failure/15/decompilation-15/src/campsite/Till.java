package src.campsite;

abstract class Till implements Keening {
   public Object wart;

   public Till(Object var1) {
      this.wart = var1;
   }

   public abstract Till vicarious();
}
