package src.campsite;

interface Keening {
   void shoehorn(Byte var1, Float var2);

   Float expire(Tarim var1);
}
