package src.campsite;

final class Babysat extends Tarim {
   public Boolean confiding;
   public final Double blockhead;

   public Babysat(Boolean var1, Double var2) {
      super(73.673, new Long(57L));
      this.confiding = var1;
      this.blockhead = var2;
   }

   public final int hyperbola(Short var1) {
      this.confiding = true;
      return -90;
   }

   public final Number bauhaus(Number var1, Double var2) {
      Long var3 = new Long(65L);
      return var3;
   }
}
