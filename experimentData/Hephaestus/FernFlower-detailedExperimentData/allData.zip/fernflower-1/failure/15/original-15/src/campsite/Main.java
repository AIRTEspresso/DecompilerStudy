package src.campsite;

class Main {
  static Integer runaways = 61;

  static public final Short devours(Long lollypops) {
    final Short station = (short)-97;
    Main.griming();
    return station;
    
  }

  static public final void griming() {
    Function2<Integer, Double, Long> samoset = (deterrent, portend) -> {
      Lowers asshole = Main.chiefer();
      final Long michael = asshole.caucussed;
      Main.hostler();
      return michael;
      
    };
    final Integer refuel = Main.runaways;
    final Double breathy = 9.348;
    Double solders = new Tarim<Double, Byte>(breathy, -52.886).blockhead;
    Function0<Double> maxillae = () -> {
      Function2<Byte, Byte, Double> essayed = (nags, podcasts) -> {
        Double micheal = Main.tube();
        return micheal;
        
      };
      Byte colbert = (byte)-49;
      final byte sunstroke = colbert;
      Function2<Integer, Integer, Void> scheming = (tabulator, duel) -> {
        final Boolean casey = true;
        final Shalt<Double, Short> gomulka = new Shalt<Double, Short>(-12, 88.989);
        gomulka.iterators();
        Object x_0 = ((casey) ?
          (short)59 : 
           (short)-69);
        return null;
      };
      final Integer riel = 29;
      scheming.apply(riel, new Shalt<Short, String>(40, (short)-45).liberia);
      return essayed.apply(  ((true) ?
  (byte)41 : 
   colbert), sunstroke);
      
    };
    solders = maxillae.apply();
    samoset.apply(refuel, solders);
    
  }

  static public final Lowers chiefer() {
    Long acreage = (long)-68;
    Character midwifery = 'O';
    Lowers bloodshed = new Lowers(acreage, midwifery);
    Function2<Float, Float, Void> lunging = (belem, oates) -> {
      Object x_1 = 'r';
      return null;
    };
    lunging.apply((float)70.499, (float)-49.62);
    return bloodshed;
    
  }

  static public final void hostler() {
    final Long hammed = (long)-67;
    final Character thorough = 'w';
    char summonses = new Lowers(hammed, thorough).dumber;
    Main.runaways = 91;
    Object x_2 = summonses;
    
  }

  static public final Double tube() {
    Double rubiest = 53.408;
    Keening perplexes = (Keening) null;
    Byte android = (byte)81;
    perplexes.shoehorn(android, (float)59.406);
    return rubiest;
    
  }

  static public final Lowers kramer() {
    return new Lowers((long)24,  '8');
  }

  static public final boolean littoral(byte worlds) {
    Short pick = (short)-60;
    final Tarim<? extends Double, ? super Integer> kickier = new Tarim<Double, Integer>(54.579, 96.645);
    double duffers = kickier.blockhead;
    Function2<Long, Integer, Long> brimful = (strainer, robustest) -> {
      Long artefact = (long)-50;
      return artefact;
      
    };
    return (((pick <= duffers) && (Main.littoral((byte)20) || new Babysat(false, 82.29).confiding)) || (((Harelip) null).pensions(brimful.apply((long)-80, 5)) == new Babysat(false, -71.199)));
    
  }

  static Lowers recliner = Main.chiefer();

  static final Lowers incurable = Main.recliner;

  static char sap = Main.incurable.dumber;

  static public final Keening brandy(Double mutually) {
    Boolean wineries = false;
    Harelip rivalries = (Harelip) null;
    Boolean reva = true;
    return ((false) ?
      ((wineries) ?
        rivalries : 
         rivalries) : 
       ((reva) ?
        (Harelip) null : 
         (Harelip) null));
    
  }

  static public final void main(String[] args) {
    long rattlings = (long)-53;
    Object x_5 = rattlings;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Lowers {
  public Long caucussed;
  public final Character dumber;

  public Lowers(Long caucussed,Character dumber) {
    this.caucussed = caucussed;
    this.dumber = dumber;
  }
}

class Tarim<X, P> {
  public final Double blockhead;
  public final X keynes;

  public Tarim(Double blockhead,X keynes) {
    this.blockhead = blockhead;
    this.keynes = keynes;
  }

  public int hyperbola(Short octette) {
    return 89;
  }

  public X bauhaus(X rekindle, Double brat) {
    X auks = (X) null;
    auks = (X) null;
    return auks;
    
  }
}

interface Keening {
  public abstract void shoehorn(Byte imbed, Float weirdos) ;

  public abstract Float expire(Tarim<? extends Byte, ? super Integer> jujubes) ;
}

class Shalt<C, S> implements Keening {
  public final Integer liberia;
  public final C canard;

  public Shalt(Integer liberia,C canard) {
    super();
    this.liberia = liberia;
    this.canard = canard;
  }

  public void iterators() {
    final float domains = (float)-78.379;
    Main.runaways = -62;
    Object x_3 = domains;
    
  }

  public Float expire(Tarim<? extends Byte, ? super Integer> jujubes) {
    Float blithe = (float)-63.157;
    Swellings kudzus = (Swellings) null;
    kudzus.insect();
    return blithe;
    
  }

  public void shoehorn(Byte imbed, Float weirdos) {
    final Integer betide = -63;
    Main.runaways = betide;
    Object x_4 = (C) null;
    
  }
}

abstract class Swellings extends Tarim<String, Double> {
  public Shalt<Lowers, Double> creole;

  public Swellings(Shalt<Lowers, Double> creole) {
    super(69.310, "standbys");
    this.creole = creole;
  }

  public abstract void insect() ;
}

final class Babysat extends Tarim<Number, String> {
  public Boolean confiding;
  public final Double blockhead;

  public Babysat(Boolean confiding,Double blockhead) {
    super(73.673, (Number) new Long(57));
    this.confiding = confiding;
    this.blockhead = blockhead;
  }

  public final int hyperbola(Short octette) {
    final int traipse = -90;
    confiding = true;
    return traipse;
    
  }

  public final Number bauhaus(Number rekindle, Double brat) {
    Number recruits = (Number) new Long(65);
    return recruits;
    
  }
}

interface Harelip extends Keening {
  public abstract <F_V> Babysat pensions(F_V cordials) ;
}

abstract class Till<R extends Character, C, J> implements Keening {
  public C wart;

  public Till(C wart) {
    super();
    this.wart = wart;
  }

  public abstract Till<? extends Character, ? extends Character, Short> vicarious() ;
}