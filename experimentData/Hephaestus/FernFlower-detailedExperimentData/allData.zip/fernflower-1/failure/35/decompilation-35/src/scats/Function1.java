package src.scats;

interface Function1 {
   Object apply(Object var1);
}
