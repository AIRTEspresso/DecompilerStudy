package src.scats;

abstract class Goblet extends Cavern {
   public Character espinoza;
   public final Object caddying;

   public Goblet(Character var1, Object var2) {
      super('8', new Kabob(new Knothole(4L, 32.73F), 38L));
      this.espinoza = var1;
      this.caddying = var2;
   }

   public abstract byte hanukkahs(Object var1);

   public char eardrum() {
      return 'Z';
   }
}
