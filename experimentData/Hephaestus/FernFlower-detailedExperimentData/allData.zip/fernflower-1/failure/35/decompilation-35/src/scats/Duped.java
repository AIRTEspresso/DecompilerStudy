package src.scats;

final class Duped extends Swordplay {
   public Short visited;
   public final Long degrees;

   public Duped(Short var1, Long var2) {
      super(-91L);
      this.visited = var1;
      this.degrees = var2;
   }

   public Integer[] thracian(Float var1, Float var2) {
      return new Integer[0];
   }
}
