package src.scats;

abstract class Duping extends Knothole {
   public final Irish broaching;
   public final Long degrees;
   public final Snips involves;

   public Duping(Irish var1, Long var2, Snips var3) {
      super(-84L, (Snips)null);
      this.broaching = var1;
      this.degrees = var2;
      this.involves = var3;
   }

   public abstract char monologs(Object var1);
}
