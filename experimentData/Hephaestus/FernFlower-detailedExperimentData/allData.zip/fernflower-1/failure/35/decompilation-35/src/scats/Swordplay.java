package src.scats;

abstract class Swordplay {
   public final Long degrees;

   public Swordplay(Long var1) {
      this.degrees = var1;
   }

   public abstract Integer[] thracian(Float var1, Float var2);
}
