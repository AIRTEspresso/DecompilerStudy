package src.scats;

final class Kabob extends Grimaced {
   public Knothole coworker;
   public final Long beefy;

   public Kabob(Knothole var1, Long var2) {
      super((byte)36, -49L);
      this.coworker = var1;
      this.beefy = var2;
   }

   public final Integer[] thracian(Float var1, Float var2) {
      Integer[] var3 = (Integer[])(new Object[]{(Integer)null, (Integer)null, (Integer)null});
      return var3;
   }

   public final Float truanting(double var1) {
      return -8.226F;
   }
}
