package src.scats;

interface Function0 {
   Object apply();
}
