package src.scats;

abstract class Grimaced extends Swordplay {
   public final Byte pittance;
   public final Long degrees;

   public Grimaced(Byte var1, Long var2) {
      super(-92L);
      this.pittance = var1;
      this.degrees = var2;
   }

   public Integer[] thracian(Float var1, Float var2) {
      Integer[] var3 = (Integer[])(new Object[]{(Integer)null, (Integer)null, (Integer)null});
      return var3;
   }
}
