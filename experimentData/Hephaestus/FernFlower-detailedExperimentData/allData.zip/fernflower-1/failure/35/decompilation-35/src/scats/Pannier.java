package src.scats;

final class Pannier extends Cavern {
   public final Cavern biked;
   public Character espinoza;

   public Pannier(Cavern var1, Character var2) {
      super('a', new Cavern('b', (Swordplay)null));
      this.biked = var1;
      this.espinoza = var2;
   }

   public final char eardrum() {
      char var1 = 't';
      return var1;
   }
}
