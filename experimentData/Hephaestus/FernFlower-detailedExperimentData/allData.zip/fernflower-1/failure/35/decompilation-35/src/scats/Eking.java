package src.scats;

abstract class Eking extends Swordplay {
   public float rouses;

   public Eking(float var1) {
      super(75L);
      this.rouses = var1;
   }
}
