package src.scats;

class Knothole extends Swordplay {
   public final Long degrees;
   public final Object involves;

   public Knothole(Long var1, Object var2) {
      super(20L);
      this.degrees = var1;
      this.involves = var2;
   }

   public final Eking raveled(Object var1) {
      Object var2 = null;
      return this.raveled(var2);
   }

   public Integer[] thracian(Float var1, Float var2) {
      Float var3 = -70.228F;
      Integer[] var4 = Main.haziest.thracian(var3, -18.1F);
      Irish var5 = new Irish(-68);
      Main.reprieve = var5.muckier;
      return var4;
   }
}
