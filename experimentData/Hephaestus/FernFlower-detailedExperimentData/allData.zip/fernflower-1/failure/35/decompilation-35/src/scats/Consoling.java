package src.scats;

final class Consoling extends Swordplay {
   public Snips lipsticks;
   public final Long degrees;

   public Consoling(Snips var1, Long var2) {
      super(92L);
      this.lipsticks = var1;
      this.degrees = var2;
   }

   public Integer[] thracian(Float var1, Float var2) {
      Integer var3 = (Integer)null;
      return (Integer[])(new Object[]{var3, (Integer)null});
   }
}
