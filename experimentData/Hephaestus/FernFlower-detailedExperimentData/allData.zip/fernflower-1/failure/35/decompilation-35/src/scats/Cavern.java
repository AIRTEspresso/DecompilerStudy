package src.scats;

class Cavern extends Warmth {
   public Character espinoza;
   public Swordplay alien;

   public Cavern(Character var1, Swordplay var2) {
      super(new Consoling((Snips)null, 86L), 'R');
      this.espinoza = var1;
      this.alien = var2;
   }

   public final void gutsiest(long var1, Short var3) {
      Short var4 = (Short)null;
   }

   public char eardrum() {
      char var1 = this.espinoza;
      Function2 var2 = (var0, var1x) -> {
         Integer var2 = 31;
         return null;
      };
      Short var3 = (Short)null;
      var2.apply(var3, (new Duped(var3, -78L)).visited);
      return var1;
   }
}
