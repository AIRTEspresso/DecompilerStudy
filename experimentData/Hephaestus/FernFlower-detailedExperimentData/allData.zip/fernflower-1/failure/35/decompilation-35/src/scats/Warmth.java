package src.scats;

abstract class Warmth extends Swordplay {
   public Swordplay alien;
   public Character espinoza;

   public Warmth(Swordplay var1, Character var2) {
      super(77L);
      this.alien = var1;
      this.espinoza = var2;
   }

   public Integer[] thracian(Float var1, Float var2) {
      Integer var3 = (Integer)null;
      Integer var4 = -14;
      return (Integer[])(new Object[]{(Integer)null, (Integer)null, var4});
   }

   public abstract char eardrum();
}
