package src.scats;

class Racially extends Grimaced {
   public final Double reefed;

   public Racially(Double var1) {
      super((byte)14, -88L);
      this.reefed = var1;
   }

   public Object deicer(Knothole var1) {
      return null;
   }

   public final String daftest(double var1) {
      return "squibb";
   }
}
