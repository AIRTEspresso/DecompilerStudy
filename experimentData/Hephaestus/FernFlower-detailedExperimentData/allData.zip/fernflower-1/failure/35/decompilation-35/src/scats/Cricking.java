package src.scats;

final class Cricking extends Goblet {
   public Cricking() {
      super('C', -18);
   }

   public final Double[] stiflings(Consoling var1, Snips var2) {
      Double var3 = 44.695;
      Double[] var4 = (Double[])(new Object[]{var3, -10.249});
      return var4;
   }

   public byte hanukkahs(Byte var1) {
      byte var2 = -29;
      return var2;
   }
}
