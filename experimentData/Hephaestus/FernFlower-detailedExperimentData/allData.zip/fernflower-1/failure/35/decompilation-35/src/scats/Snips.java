package src.scats;

abstract class Snips extends Swordplay {
   public final Warmth frisks;
   public final Long degrees;

   public Snips(Warmth var1, Long var2) {
      super(7L);
      this.frisks = var1;
      this.degrees = var2;
   }

   public Integer[] thracian(Float var1, Float var2) {
      Integer var3 = -39;
      Integer var4 = -32;
      return (Integer[])(new Object[]{var3, var4});
   }

   public abstract Integer[] barbarism();
}
