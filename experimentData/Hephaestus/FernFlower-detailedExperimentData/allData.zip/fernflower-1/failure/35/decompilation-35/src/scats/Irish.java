package src.scats;

class Irish extends Grimaced {
   public Integer muckier;

   public Irish(Integer var1) {
      super((byte)-96, -83L);
      this.muckier = var1;
   }

   public final Integer[] thracian(Float var1, Float var2) {
      Integer var3 = (Integer)null;
      Integer var5 = (Integer)null;
      return (Integer[])(new Object[]{(Integer)null, var3, var5});
   }

   public final float platen(Boolean var1) {
      return -96.22F;
   }
}
