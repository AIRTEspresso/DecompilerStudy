package src.scats;

class Greets extends Swordplay {
   public Cricking snitches;
   public final Long degrees;

   public Greets(Cricking var1, Long var2) {
      super(38L);
      this.snitches = var1;
      this.degrees = var2;
   }

   public Integer[] thracian(Float var1, Float var2) {
      return new Integer[0];
   }

   public Greets hard(Irish var1, Boolean var2) {
      Greets var3 = (Greets)null;
      Function0 var4 = () -> {
         Snips var0 = (Snips)null;
         Long var1 = -85L;
         (new Consoling(var0, var1)).lipsticks = (Snips)null;
         Long var2 = 81L;
         return null;
      };
      var4.apply();
      return var3;
   }
}
