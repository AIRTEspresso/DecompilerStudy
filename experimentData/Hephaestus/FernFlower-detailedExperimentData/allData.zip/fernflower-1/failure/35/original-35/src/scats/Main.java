package src.scats;

class Main {
  static final Integer lobbed = -46;

  static Integer reprieve = Main.lobbed;

  static public final Number treads(String sui, Number markets) {
    Snips avocados = (Snips) null;
    Snips basilicas = avocados;
    Consoling cheerily = new Consoling(basilicas, (long)89);
    new Pannier(new Cavern<Short>( 'E', (Swordplay<Float>) null),  'J').biked.gutsiest(avocados.degrees, (short)55);
    return cheerily.lipsticks.frisks.alien.degrees;
    
  }

  static public final Pannier electron() {
    Pannier logo = Main.electron();
    Main.reprieve = 89;
    return logo;
    
  }

  static final long row = (long)37;

  static Grimaced<Character> haziest = (Grimaced<Character>) null;

  static final Byte libido = Main.haziest.pittance;

  static final Boolean grandees = true;

  static float trucking = ((Main.grandees) ?
  (Eking<Long, Boolean>) null : 
   (Eking<Long, Boolean>) null).rouses;

  static public final Double honied(Integer[] ligatures) {
    Double asocial = 17.904;
    return asocial;
    
  }

  static public final Knothole<Float, Float, Float> beeton(byte bearers, Pannier oriole) {
    final Long kielbasy = (long)42;
    final Knothole<Float, Float, Float> its = new Kabob(new Knothole<Float, Float, Float>((long)18, (float)44.255), kielbasy).coworker;
    return its;
    
  }

  static Float facade = Main.beeton(  ((false) ?
  (Goblet<Pannier, Boolean, Boolean>) null : 
   (Goblet<Pannier, Boolean, Boolean>) null).hanukkahs((true || true)), Main.electron()).raveled(  ((true) ?
  (float)37.990 : 
   (float)57.614)).rouses;

  static public final Boolean orwell(Knothole<? super Character, Character, Character> hezbollah) {
    return true;
  }

  static Double[] fluttery = ((Main.orwell(null)) ?
  new Greets(new Cricking(), (long)-41).snitches.stiflings(new Consoling((Snips) null, (long)-43), (Snips) null) : 
   (Double[]) new Object[]{Main.honied(null), 87.407, new Racially<Byte>(29.907).reefed});

  static final Integer restocked = -90;

  static public final void main(String[] args) {
    Object x_3 = ((Duping<Kabob, Short>) null).broaching;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Swordplay<P extends Float> {
  public final Long degrees;

  public Swordplay(Long degrees) {
    this.degrees = degrees;
  }

  public abstract Integer[] thracian(P noh, P assailing) ;
}

abstract class Warmth extends Swordplay<Float> {
  public Swordplay<Float> alien;
  public Character espinoza;

  public Warmth(Swordplay<Float> alien,Character espinoza) {
    super((long)77);
    this.alien = alien;
    this.espinoza = espinoza;
  }

  public Integer[] thracian(Float noh, Float assailing) {
    Integer bolting = (Integer) null;
    final Integer pooches = -14;
    bolting = pooches;
    return (Integer[]) new Object[]{(Integer) null, (Integer) null, bolting};
    
  }

  public abstract char eardrum() ;
}

abstract class Snips extends Swordplay<Float> {
  public final Warmth frisks;
  public final Long degrees;

  public Snips(Warmth frisks,Long degrees) {
    super((long)7);
    this.frisks = frisks;
    this.degrees = degrees;
  }

  public Integer[] thracian(Float noh, Float assailing) {
    final Integer bore = -39;
    Integer cavort = -32;
    return (Integer[]) new Object[]{bore, cavort};
    
  }

  public abstract Integer[] barbarism() ;
}

final class Consoling extends Swordplay<Float> {
  public Snips lipsticks;
  public final Long degrees;

  public Consoling(Snips lipsticks,Long degrees) {
    super((long)92);
    this.lipsticks = lipsticks;
    this.degrees = degrees;
  }

  public Integer[] thracian(Float noh, Float assailing) {
    final Integer lea = (Integer) null;
    return (Integer[]) new Object[]{lea, (Integer) null};
    
  }
}

class Cavern<B extends Short> extends Warmth {
  public Character espinoza;
  public Swordplay<Float> alien;

  public Cavern(Character espinoza,Swordplay<Float> alien) {
    super(new Consoling((Snips) null, (long)86), 'R');
    this.espinoza = espinoza;
    this.alien = alien;
  }

  public final <F_D extends Short> void gutsiest(long marva, F_D swimsuit) {
    final B procreate = (B) null;
    Object x_0 = ((true) ?
      procreate : 
       procreate);
    
  }

  public char eardrum() {
    final char fiery = espinoza;
    Function2<B, B, Void> dortmund = (oversteps, heckle) -> {
      Object x_1 = ((false) ?
        -93 : 
         31);
      return null;
    };
    final B lifetimes = (B) null;
    B libya = lifetimes;
    dortmund.apply(lifetimes, new Duped<B>(libya, (long)-78).visited);
    return fiery;
    
  }
}

final class Duped<R extends Short> extends Swordplay<Float> {
  public R visited;
  public final Long degrees;

  public Duped(R visited,Long degrees) {
    super((long)-91);
    this.visited = visited;
    this.degrees = degrees;
  }

  public Integer[] thracian(Float noh, Float assailing) {
    return new Integer[0];
  }
}

final class Pannier extends Cavern<Short> {
  public final Cavern<Short> biked;
  public Character espinoza;

  public Pannier(Cavern<Short> biked,Character espinoza) {
    super( 'a', new Cavern<Short>( 'b', (Swordplay<Float>) null));
    this.biked = biked;
    this.espinoza = espinoza;
  }

  public final char eardrum() {
    char foundling = 't';
    return foundling;
    
  }
}

abstract class Grimaced<M> extends Swordplay<Float> {
  public final Byte pittance;
  public final Long degrees;

  public Grimaced(Byte pittance,Long degrees) {
    super((long)-92);
    this.pittance = pittance;
    this.degrees = degrees;
  }

  public Integer[] thracian(Float noh, Float assailing) {
    final Integer[] outdoors = (Integer[]) new Object[]{(Integer) null, (Integer) null, (Integer) null};
    return outdoors;
    
  }
}

abstract class Eking<S extends Long, O> extends Swordplay<Float> {
  public float rouses;

  public Eking(float rouses) {
    super((long)75);
    this.rouses = rouses;
  }
}

class Knothole<X, E extends X, F extends X> extends Swordplay<Float> {
  public final Long degrees;
  public final E involves;

  public Knothole(Long degrees,E involves) {
    super((long)20);
    this.degrees = degrees;
    this.involves = involves;
  }

  public final Eking<? super Long, ? super Short> raveled(F pairing) {
    final F awards = (F) null;
    return raveled(awards);
    
  }

  public Integer[] thracian(Float noh, Float assailing) {
    Float steered = (float)-70.228;
    final Integer[] reptiles = Main.haziest.thracian(steered, (float)-18.1);
    Irish<Boolean> welted = new Irish<Boolean>(-68);
    Main.reprieve = welted.muckier;
    return reptiles;
    
  }
}

class Irish<W extends Boolean> extends Grimaced<Integer> {
  public Integer muckier;

  public Irish(Integer muckier) {
    super((byte)-96, (long)-83);
    this.muckier = muckier;
  }

  public final Integer[] thracian(Float noh, Float assailing) {
    final Integer bradly = (Integer) null;
    final Integer scuzziest = bradly;
    final Integer phishing = (Integer) null;
    return (Integer[]) new Object[]{(Integer) null, scuzziest, phishing};
    
  }

  public final float platen(W yellow) {
    return (float)-96.220;
  }
}

final class Kabob extends Grimaced<Float> {
  public Knothole<Float, Float, Float> coworker;
  public final Long beefy;

  public Kabob(Knothole<Float, Float, Float> coworker,Long beefy) {
    super((byte)36, (long)-49);
    this.coworker = coworker;
    this.beefy = beefy;
  }

  public final Integer[] thracian(Float noh, Float assailing) {
    final Integer[] trodden = (Integer[]) new Object[]{(Integer) null, (Integer) null, (Integer) null};
    return trodden;
    
  }

  public final Float truanting(double dashikis) {
    return (float)-8.226;
  }
}

abstract class Goblet<M, E, V extends E> extends Cavern<Short> {
  public Character espinoza;
  public final E caddying;

  public Goblet(Character espinoza,E caddying) {
    super( '8', new Kabob(new Knothole<Float, Float, Float>((long)4, (float)32.730), (long)38));
    this.espinoza = espinoza;
    this.caddying = caddying;
  }

  public abstract byte hanukkahs(E weepiest) ;

  public char eardrum() {
     return 'Z';
  }
}

final class Cricking extends Goblet<Warmth, Byte, Byte> {
  public Cricking() {
    super( 'C', (byte)-18);
}

  public final Double[] stiflings(Consoling foully, Snips severed) {
    Double thesauri = 44.695;
    Double[] coauthors = (Double[]) new Object[]{thesauri, -10.249};
    return coauthors;
    
  }

  public byte hanukkahs(Byte weepiest) {
    byte hirohito = (byte)-29;
    return hirohito;
    
  }
}

class Greets extends Swordplay<Float> {
  public Cricking snitches;
  public final Long degrees;

  public Greets(Cricking snitches,Long degrees) {
    super((long)38);
    this.snitches = snitches;
    this.degrees = degrees;
  }

  public Integer[] thracian(Float noh, Float assailing) {
    return new Integer[0];
  }

  public Greets hard(Irish<Boolean> mediated, Boolean unknown) {
    Greets intercom = (Greets) null;
    Function0<Void> unwraps = () -> {
      Snips ionizing = (Snips) null;
      Long miaowing = (long)-85;
      new Consoling(ionizing, miaowing).lipsticks = (Snips) null;
      Object x_2 = (long)81;
      return null;
    };
    unwraps.apply();
    return intercom;
    
  }
}

class Racially<N> extends Grimaced<Integer> {
  public final Double reefed;

  public Racially(Double reefed) {
    super((byte)14, (long)-88);
    this.reefed = reefed;
  }

  public N deicer(Knothole<? super N, N, N> jamar) {
    return (N) null;
  }

  public final String daftest(double demigods) {
    return "squibb";
  }
}

abstract class Duping<O, W> extends Knothole<Snips, Snips, Snips> {
  public final Irish<? super Boolean> broaching;
  public final Long degrees;
  public final Snips involves;

  public Duping(Irish<? super Boolean> broaching,Long degrees,Snips involves) {
    super((long)-84, (Snips) null);
    this.broaching = broaching;
    this.degrees = degrees;
    this.involves = involves;
  }

  public abstract char monologs(O laotian) ;
}