package src.larges;

abstract class Aughts extends Pitting {
   public Character jehovah;

   public Aughts(Character var1) {
      super((byte)88, (byte)-53);
      this.jehovah = var1;
   }

   public abstract String palpated(String var1, double var2);
}
