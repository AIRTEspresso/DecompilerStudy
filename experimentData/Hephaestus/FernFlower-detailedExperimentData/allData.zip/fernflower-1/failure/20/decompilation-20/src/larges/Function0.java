package src.larges;

interface Function0 {
   Object apply();
}
