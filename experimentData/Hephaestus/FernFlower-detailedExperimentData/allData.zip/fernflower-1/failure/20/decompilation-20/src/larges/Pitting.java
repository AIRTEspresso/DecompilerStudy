package src.larges;

abstract class Pitting {
   public final Byte staler;
   public byte jedi;

   public Pitting(Byte var1, byte var2) {
      this.staler = var1;
      this.jedi = var2;
   }
}
