package src.larges;

abstract class Sensibly extends Aughts {
   public final Long blazoning;
   public final Aughts cotyledon;

   public Sensibly(Long var1, Aughts var2) {
      super('m');
      this.blazoning = var1;
      this.cotyledon = var2;
   }

   public String palpated(String var1, double var2) {
      return "refs";
   }

   public Object roughen(Sensibly var1, Sensibly var2) {
      return null;
   }
}
