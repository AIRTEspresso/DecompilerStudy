package src.larges;

abstract class Scarified implements Lulu {
   public float hoffman;
   public Object overpaid;

   public Scarified(float var1, Object var2) {
      this.hoffman = var1;
      this.overpaid = var2;
   }

   public Boolean[] wei(Boolean[] var1) {
      return new Boolean[0];
   }

   public Double iciness(short var1, Double var2) {
      return -42.717;
   }
}
