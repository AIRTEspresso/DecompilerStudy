package src.larges;

interface Lulu {
   Boolean[] wei(Boolean[] var1);

   Double iciness(short var1, Double var2);
}
