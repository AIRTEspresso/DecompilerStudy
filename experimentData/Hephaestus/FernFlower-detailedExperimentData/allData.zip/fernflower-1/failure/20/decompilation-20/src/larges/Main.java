package src.larges;

class Main {
   static Aughts beadle = (Aughts)null;
   static Aughts mediated;
   static final Character forfeited;
   static final Character gimmicks;
   static Integer lovely;
   static final Aughts skydives;
   static Long retaken;

   public static final Double urbane() {
      Boolean var0 = aphelion();
      Boolean var1 = false;
      Double var2 = var1 ? 24.888 : -54.222;
      Function1 var3 = (var0x) -> {
         Integer var1 = 48;
         return null;
      };
      var3.apply(-91);
      return var0 ? var2 : -0.357;
   }

   public static final Boolean aphelion() {
      return false;
   }

   public static final Integer sasquatch(Integer var0) {
      Integer var1 = sasquatch(53);
      return var1;
   }

   public static final void main(String[] var0) {
      Boolean var1 = false;
      Boolean var2 = false;
      Boolean var3 = var1 && var2;
      Float var4 = var3 ? ((Scarified)null).hoffman : 42.4F;
   }

   static {
      mediated = beadle;
      forfeited = ((Aughts)null).jehovah;
      gimmicks = forfeited;
      lovely = 25;
      skydives = (Aughts)null;
      retaken = ((Sensibly)null).blazoning;
   }
}
