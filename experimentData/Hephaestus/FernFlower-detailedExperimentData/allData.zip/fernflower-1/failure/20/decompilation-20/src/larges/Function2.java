package src.larges;

interface Function2 {
   Object apply(Object var1, Object var2);
}
