package src.larges;

class Main {
  static Aughts<String, Short, Short> beadle = (Aughts<String, Short, Short>) null;

  static Aughts<String, Short, Short> mediated = Main.beadle;

  static final Character forfeited = ((true) ?
  (Aughts<String, Short, Short>) null : 
   Main.mediated).jehovah;

  static final Character gimmicks = Main.forfeited;

  static Integer lovely = (((true && false)) ?
  15 : 
   ((false) ?
    -52 : 
     25));

  static public final Double urbane() {
    Boolean hurling = Main.aphelion();
    Boolean nembutal = false;
    Double bagel = ((nembutal) ?
      24.888 : 
       -54.222);
    Function1<Byte, Void> next = (aghast) -> {
      final Integer succored = 48;
      Object x_0 = succored;
      return null;
    };
    next.apply((byte)-91);
    return ((hurling) ?
      bagel : 
       -0.357);
    
  }

  static public final Boolean aphelion() {
    return false;
  }

  static public final Integer sasquatch(Integer disclose) {
    Integer frizzled = Main.sasquatch(53);
    return frizzled;
    
  }

  static final Aughts<String, Short, ? extends Integer> skydives = (Aughts<String, Short, Integer>) null;

  static Long retaken = (((true != true)) ?
  (long)58 : 
   ((Sensibly<Character, Integer, Character>) null).blazoning);

  static public final void main(String[] args) {
    Boolean ransomed = false;
    final Boolean scoreless = false;
    Boolean spritzes = (ransomed && scoreless);
    Object x_1 = ((spritzes) ?
      ((Scarified<Number, Object>) null).hoffman : 
       ((true) ?
        (float)42.40 : 
         (float)-71.74));
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Pitting {
  public final Byte staler;
  public byte jedi;

  public Pitting(Byte staler,byte jedi) {
    this.staler = staler;
    this.jedi = jedi;
  }
}

abstract class Aughts<Z extends String, G extends Short, I> extends Pitting {
  public Character jehovah;

  public Aughts(Character jehovah) {
    super((byte)88, (byte)-53);
    this.jehovah = jehovah;
  }

  public abstract Z palpated(Z pokier, double snowdrop) ;
}

interface Lulu {
  public abstract Boolean[] wei(Boolean[] leger) ;

  public abstract Double iciness(short commuting, Double sandmen) ;
}

abstract class Sensibly<N, L, X extends N> extends Aughts<String, Short, String> {
  public final Long blazoning;
  public final Aughts<? extends String, ? super Short, Integer> cotyledon;

  public Sensibly(Long blazoning,Aughts<? extends String, ? super Short, Integer> cotyledon) {
    super( 'm');
    this.blazoning = blazoning;
    this.cotyledon = cotyledon;
  }

  public String palpated(String pokier, double snowdrop) {
    return "refs";
  }

  public L roughen(Sensibly<? super Short, Float, Short> differed, Sensibly<? super X, ? super X, X> hampers) {
    return (L) null;
  }
}

abstract class Scarified<S, R> implements Lulu {
  public float hoffman;
  public R overpaid;

  public Scarified(float hoffman,R overpaid) {
    super();
    this.hoffman = hoffman;
    this.overpaid = overpaid;
  }

  public Boolean[] wei(Boolean[] leger) {
    return new Boolean[0];
  }

  public Double iciness(short commuting, Double sandmen) {
    return -42.717;
  }
}