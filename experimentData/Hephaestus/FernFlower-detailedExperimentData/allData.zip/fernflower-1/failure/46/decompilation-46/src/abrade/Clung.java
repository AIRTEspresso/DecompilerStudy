package src.abrade;

interface Clung {
   int voyeurism(Object var1);

   Boolean[] nudity();
}
