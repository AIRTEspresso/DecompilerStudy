package src.abrade;

final class Gauziest implements Clung {
   public boolean trekkie;

   public Gauziest(boolean var1) {
      this.trekkie = var1;
   }

   public int voyeurism(Object var1) {
      return -55;
   }

   public Boolean[] nudity() {
      Boolean var1 = (Boolean)null;
      Boolean var3 = (Boolean)null;
      return (Boolean[])(new Object[]{var1, var3, (Boolean)null});
   }
}
