package src.abrade;

class Ovation {
   public Double palisade;
   public long kurile;

   public Ovation(Double var1, long var2) {
      this.palisade = var1;
      this.kurile = var2;
   }

   public final Object crosby(Object var1) {
      Object var2 = null;
      this.palisade = 20.807;
      return var2;
   }

   public Object impulsed(Object var1) {
      return 73;
   }
}
