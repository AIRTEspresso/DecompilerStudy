package src.abrade;

abstract class Markets extends Absalom {
   public String schwartz;

   public Markets(String var1) {
      super((Clung)null);
      this.schwartz = var1;
   }

   public int voyeurism(Boolean var1) {
      Juice var2 = (Juice)null;
      int var4 = var2.pulling;
      return var4;
   }

   public byte kilogram() {
      return -83;
   }
}
