package src.abrade;

abstract class Juice extends Nocturnes {
   public int pulling;
   public final Byte dortmund;

   public Juice(int var1, Byte var2) {
      super((byte)-1);
      this.pulling = var1;
      this.dortmund = var2;
   }

   public Object juntas(Object var1) {
      Object var2 = null;
      return var2;
   }
}
