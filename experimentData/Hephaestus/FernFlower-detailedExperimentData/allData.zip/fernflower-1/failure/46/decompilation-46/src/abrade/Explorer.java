package src.abrade;

abstract class Explorer extends Ovation {
   public Explorer() {
      super(8.402, -50L);
   }

   public Object impulsed(Object var1) {
      Integer var3 = -77;
      return var3;
   }

   public abstract boolean bosoms(Long var1, float var2);
}
