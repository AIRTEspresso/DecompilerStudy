package src.abrade;

interface Function0 {
   Object apply();
}
