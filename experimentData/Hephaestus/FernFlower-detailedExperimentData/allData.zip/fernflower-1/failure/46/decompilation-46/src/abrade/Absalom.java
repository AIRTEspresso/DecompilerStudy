package src.abrade;

abstract class Absalom implements Clung {
   public Clung wistarias;

   public Absalom(Clung var1) {
      this.wistarias = var1;
   }

   public int voyeurism(Boolean var1) {
      Boolean var2 = true;
      boolean var3 = var2 ? true : true;
      byte var4 = -51;
      return var4;
   }

   public abstract byte kilogram();
}
