package src.abrade;

class Nocturnes implements Clung {
   public final Byte dortmund;

   public Nocturnes(Byte var1) {
      this.dortmund = var1;
   }

   public int voyeurism(Character var1) {
      return 42;
   }

   public Boolean[] nudity() {
      return (Boolean[])(new Object[]{(Boolean)null});
   }
}
