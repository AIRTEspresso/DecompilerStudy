package src.abrade;

interface Function1 {
   Object apply(Object var1);
}
