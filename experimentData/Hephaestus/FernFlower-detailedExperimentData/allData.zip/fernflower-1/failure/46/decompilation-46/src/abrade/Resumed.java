package src.abrade;

class Resumed extends Explorer {
   public Short plumed;

   public Resumed(Short var1) {
      this.plumed = var1;
   }

   public boolean bosoms(Long var1, float var2) {
      Gauziest var3 = new Gauziest(true);
      Function2 var6 = (var0, var1x) -> {
         Number var2 = (Number)null;
         return null;
      };
      var6.apply((String)null, -24);
      return var3.trekkie;
   }

   public Object impulsed(Object var1) {
      return var1;
   }
}
