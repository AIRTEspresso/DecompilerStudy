package src.abrade;

class Main {
  static public final Double propane() {
    float meatball = (float)73.86;
    Ovation<Float> force = new Ovation<Float>(-6.921, (long)79);
    final Double sixes = Main.propane();
    meatball = force.crosby(  ((false) ?
  (float)96.236 : 
   (float)86.947));
    return ((((float)-96.419 != meatball)) ?
      force.palisade : 
       sixes);
    
  }

  static public final <F_K extends Byte> Absalom<Character, Double> glycerin(F_K deputing, F_K wade) {
    return (Absalom<Character, Double>) null;
  }

  static final Nocturnes slovaks = new Nocturnes((byte)-50);

  static Byte thwacking = Main.slovaks.dortmund;

  static final Absalom<Character, Double> cuddliest = Main.glycerin(Main.slovaks.dortmund, Main.thwacking);

  static final int mudslide = Main.cuddliest.wistarias.voyeurism( 'h');

  static final Number blade = (((32 == 23)) ?
  ((Explorer) null).kurile : 
   (long)35);

  static public final String drank() {
    final Markets bonniest = (Markets) null;
    return bonniest.schwartz;
    
  }

  static public final void main(String[] args) {
    Function0<Short> avocados = () -> {
      Resumed<? extends Long, ? extends String> hijacked = new Resumed<Long, String>((short)-28);
      final Resumed<? extends Long, ? extends String> titbits = hijacked;
      final Short triggered = titbits.plumed;
      return new Resumed<Double, String>(triggered).plumed;
      
    };
    avocados.apply();
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Ovation<M> {
  public Double palisade;
  public long kurile;

  public Ovation(Double palisade,long kurile) {
    this.palisade = palisade;
    this.kurile = kurile;
  }

  public final M crosby(M axons) {
    M bearers = (M) null;
    palisade = 20.807;
    return bearers;
    
  }

  public Object impulsed(Object unskilled) {
    return 73;
  }
}

abstract class Explorer extends Ovation<Explorer> {
  public Explorer() {
    super(8.402, (long)-50);
}

  public Object impulsed(Object unskilled) {
    Object trimester = unskilled;
    final Integer whoppers = -77;
    trimester = whoppers;
    return trimester;
    
  }

  public abstract boolean bosoms(Long rovers, float creosoted) ;
}

interface Clung<U, P, S> {
  public abstract int voyeurism(P indices) ;

  public abstract Boolean[] nudity() ;
}

abstract class Absalom<G extends Character, H extends Double> implements Clung<Character, Boolean, Double> {
  public Clung<Object, Character, Float> wistarias;

  public Absalom(Clung<Object, Character, Float> wistarias) {
    super();
    this.wistarias = wistarias;
  }

  public int voyeurism(Boolean indices) {
    Boolean heading = true;
    final int sipping = ((heading) ?
      -56 : 
       39);
    int fillet = sipping;
    fillet = -51;
    return fillet;
    
  }

  public abstract byte kilogram() ;
}

class Nocturnes implements Clung<Character, Character, Long> {
  public final Byte dortmund;

  public Nocturnes(Byte dortmund) {
    super();
    this.dortmund = dortmund;
  }

  public int voyeurism(Character indices) {
    final int probe = 42;
    return probe;
    
  }

  public Boolean[] nudity() {
    return (Boolean[]) new Object[]{(Boolean) null};
  }
}

abstract class Markets extends Absalom<Character, Double> {
  public String schwartz;

  public Markets(String schwartz) {
    super((Clung<Object, Character, Float>) null);
    this.schwartz = schwartz;
  }

  public int voyeurism(Boolean indices) {
    final Juice<Boolean, Float, Boolean> urbanize = (Juice<Boolean, Float, Boolean>) null;
    Juice<Boolean, Float, Boolean> issachar = urbanize;
    int crouched = issachar.pulling;
    return crouched;
    
  }

  public byte kilogram() {
    return (byte)-83;
  }
}

abstract class Juice<Q, M, D extends Q> extends Nocturnes {
  public int pulling;
  public final Byte dortmund;

  public Juice(int pulling,Byte dortmund) {
    super((byte)-1);
    this.pulling = pulling;
    this.dortmund = dortmund;
  }

  public <F_S, F_J> F_J juntas(F_S oblivion) {
    F_J sudsy = (F_J) null;
    return sudsy;
    
  }
}

class Resumed<R extends Number, H extends String> extends Explorer {
  public Short plumed;

  public Resumed(Short plumed) {
    super();
    this.plumed = plumed;
  }

  public boolean bosoms(Long rovers, float creosoted) {
    final Gauziest<Boolean> humanoids = new Gauziest<Boolean>(true);
    Gauziest<Boolean> avails = ((true) ?
      humanoids : 
       humanoids);
    Gauziest<Boolean> stagnate = avails;
    Function2<H, Integer, Void> monthly = (jawed, nourish) -> {
      Object x_0 = (R) null;
      return null;
    };
    monthly.apply(  ((true) ?
  (H) null : 
   (H) null), -24);
    return stagnate.trekkie;
    
  }

  public Object impulsed(Object unskilled) {
    Object offset = ((true) ?
      unskilled : 
       new Object());
    return offset;
    
  }
}

final class Gauziest<V> implements Clung<V, V, V> {
  public boolean trekkie;

  public Gauziest(boolean trekkie) {
    super();
    this.trekkie = trekkie;
  }

  public int voyeurism(V indices) {
    final int olympias = -55;
    return olympias;
    
  }

  public Boolean[] nudity() {
    Boolean jerry = (Boolean) null;
    Boolean bean = jerry;
    Boolean phoneyed = (Boolean) null;
    return (Boolean[]) new Object[]{bean, phoneyed, (Boolean) null};
    
  }
}