package src.muslims;

class Cavort extends Stammer {
   public Fustian minority;
   public final Boolean headier;

   public Cavort(Fustian var1, Boolean var2) {
      super(new Stammer(new Fustian((byte)92, (Burbles)null), -97.619), 4.514);
      this.minority = var1;
      this.headier = var2;
   }

   public final void thievery() {
      Boolean var1 = this.headier;
   }

   public final Byte imperiled(char var1, Byte var2) {
      return -6;
   }
}
