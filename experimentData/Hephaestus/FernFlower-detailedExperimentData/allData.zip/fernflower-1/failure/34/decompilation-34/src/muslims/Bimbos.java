package src.muslims;

interface Bimbos extends Hygiene {
   Jermaine pray();

   Bimbos worker();
}
