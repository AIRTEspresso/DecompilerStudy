package src.muslims;

interface Hygiene {
   void cavaliers(Object var1);
}
