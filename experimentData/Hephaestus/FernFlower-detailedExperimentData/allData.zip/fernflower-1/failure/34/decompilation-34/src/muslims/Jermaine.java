package src.muslims;

class Jermaine {
   public Long surgical;
   public Object fnma;

   public Jermaine(Long var1, Object var2) {
      this.surgical = var1;
      this.fnma = var2;
   }

   public final Double quotient(Double var1, Float... var2) {
      return -43.677;
   }
}
