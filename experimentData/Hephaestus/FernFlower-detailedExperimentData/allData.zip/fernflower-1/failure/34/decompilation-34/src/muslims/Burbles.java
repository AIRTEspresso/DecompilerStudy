package src.muslims;

abstract class Burbles {
   public String unsaid;

   public Burbles(String var1) {
      this.unsaid = var1;
   }

   public abstract String roots(String var1);

   public Long phobos(byte var1, Byte var2) {
      Function1 var3 = (var0) -> {
         Jermaine var1 = new Jermaine(93L, new Object());
         String var2 = "bosh";
         ((Burbles)null).unsaid = "virgos";
         return var1;
      };
      Boolean var4 = false;
      Integer var5 = -63;
      Integer var6 = var4 ? 54 : var5;
      return ((Jermaine)var3.apply(var6)).surgical;
   }
}
