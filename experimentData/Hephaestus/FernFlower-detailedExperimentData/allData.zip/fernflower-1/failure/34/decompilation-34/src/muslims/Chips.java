package src.muslims;

abstract class Chips extends Fustian {
   public final Object martial;
   public byte hellishly;

   public Chips(Object var1, byte var2) {
      super((byte)5, (Burbles)null);
      this.martial = var1;
      this.hellishly = var2;
   }

   public final Byte imperiled(char var1, Byte var2) {
      return 52;
   }
}
