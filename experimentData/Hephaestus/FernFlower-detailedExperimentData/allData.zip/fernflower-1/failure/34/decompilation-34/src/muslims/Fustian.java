package src.muslims;

class Fustian extends Duchess {
   public byte hellishly;
   public final Burbles pintoes;

   public Fustian(byte var1, Burbles var2) {
      super(Short.valueOf((short)88));
      this.hellishly = var1;
      this.pintoes = var2;
   }

   public Byte imperiled(char var1, Byte var2) {
      Byte var3 = (Byte)null;
      ((Hygiene)null).cavaliers(Short.valueOf((short)-74));
      return var3;
   }

   public final Byte whitney(short var1) {
      return (Byte)null;
   }
}
