package src.muslims;

class Remorse extends Burbles {
   public final Chips voodoos;

   public Remorse(Chips var1) {
      super("duller");
      this.voodoos = var1;
   }

   public String roots(String var1) {
      String var2 = "healthful";
      return var2;
   }

   public Long phobos(byte var1, Byte var2) {
      return 10L;
   }
}
