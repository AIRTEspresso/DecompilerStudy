package src.muslims;

class Main {
   static final Boolean computer = false;
   static short colonizer = -59;
   static final short gingko;
   static final short both;

   public static final char retarding(String var0, boolean var1) {
      String var2 = "nastiest";
      boolean var3 = false;
      char var4 = retarding(var2, var3);
      Function0 var5 = () -> {
         Function2 var0 = (var0x, var1x) -> {
            Long var2 = -82L;
            Object var3 = new Object();
            return new Jermaine(var2, var3);
         };
         boolean var1 = true;
         Jermaine var2 = (Jermaine)var0.apply(Short.valueOf((short)17), Short.valueOf((short)-30));
         Fustian var3 = new Fustian((byte)94, (Burbles)null);
         var2.surgical = ((Burbles)null).phobos((new Stammer(var3, 87.71)).minority.hellishly, (byte)-94);
         Integer var4 = -8;
         return null;
      };
      var5.apply();
      return var4;
   }

   public static final void silicon(float var0) {
      Remorse var1 = new Remorse((Chips)null);
   }

   public static final Object treadled(Object var0, Hygiene var1) {
      Ornerier var2 = (Ornerier)null;
      return var2.gonging;
   }

   public static final void main(String[] var0) {
      Boolean var1 = computer;
      Boolean var2 = true;
      Long var3 = var1 ? (var2 ? -63L : 27L) : -63L;
   }

   static {
      gingko = colonizer;
      both = computer ? gingko : gingko;
   }
}
