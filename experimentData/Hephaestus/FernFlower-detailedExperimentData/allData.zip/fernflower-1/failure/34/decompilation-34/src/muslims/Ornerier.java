package src.muslims;

abstract class Ornerier extends Jermaine {
   public Object gonging;
   public double topically;

   public Ornerier(Object var1, double var2) {
      super(-30L, new Object());
      this.gonging = var1;
      this.topically = var2;
   }

   public abstract Byte blanket();
}
