package src.muslims;

final class Errant extends Jermaine {
   public Long surgical;
   public final Object underpass;

   public Errant(Long var1, Object var2) {
      super(-25L, new Object());
      this.surgical = var1;
      this.underpass = var2;
   }

   public final Cavort texas() {
      Cavort var1 = this.texas();
      Main.silicon(23.23F);
      return var1;
   }

   public final Integer report() {
      return -19;
   }
}
