package src.muslims;

interface Function0 {
   Object apply();
}
