package src.muslims;

interface Function1 {
   Object apply(Object var1);
}
