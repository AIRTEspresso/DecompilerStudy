package src.muslims;

class Duchess extends Jermaine {
   public final Short warlord;

   public Duchess(Short var1) {
      super(-88L, Short.valueOf((short)-9));
      this.warlord = var1;
   }
}
