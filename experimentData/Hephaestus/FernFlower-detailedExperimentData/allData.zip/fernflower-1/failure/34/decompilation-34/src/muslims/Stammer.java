package src.muslims;

class Stammer extends Fustian {
   public Fustian minority;
   public Double ventral;

   public Stammer(Fustian var1, Double var2) {
      super((byte)-56, (Burbles)null);
      this.minority = var1;
      this.ventral = var2;
   }

   public Byte imperiled(char var1, Byte var2) {
      return 44;
   }
}
