package src.muslims;

class Main {
  static public final char retarding(String bothering, boolean radiation) {
    String instruct = "nastiest";
    boolean annular = false;
    final char sprayers = Main.retarding(instruct, annular);
    Function0<Void> louie = () -> {
      Function2<Short, Short, Jermaine<? super Character, Character>> nibbled = (amplifier, forehead) -> {
        final Long nutrition = (long)-82;
        final Object laxatives = new Object();
        return new Jermaine<Character, Character>(nutrition, laxatives);
        
      };
      final short refills = (short)-30;
      Jermaine<? super Character, Character> neighbor = nibbled.apply((short)17, refills);
      Fustian<Byte, Byte> bareness = new Fustian<Byte, Byte>((byte)94, (Burbles) null);
      neighbor.surgical = ((Burbles) null).phobos(new Stammer<Burbles, Float>(bareness, 87.71).minority.hellishly, (byte)-94);
      Object x_0 = -8;
      return null;
    };
    louie.apply();
    return sprayers;
    
  }

  static public final void silicon(float institute) {
    Remorse<? super Long, Duchess, Duchess> hegel = new Remorse<Long, Duchess, Duchess>((Chips<Duchess, Duchess, Duchess>) null);
    Object x_3 = hegel;
    
  }

  static final Boolean computer = ( '9' <  '3');

  static short colonizer = (short)-59;

  static final short gingko = Main.colonizer;

  static final short both = ((Main.computer) ?
  Main.gingko : 
   Main.gingko);

  static public final <F_O, F_U extends Hygiene> F_O treadled(F_O bracelets, F_U widowed) {
    Ornerier<F_O> relaxing = (Ornerier<F_O>) null;
      return ((true) ?
  relaxing : 
   relaxing).gonging;
    
  }

  static public final void main(String[] args) {
    Boolean brahmas = Main.computer;
    Boolean welter = true;
    final long murderous = (long)-63;
    Object x_4 = ((brahmas) ?
      ((welter) ?
        murderous : 
         (long)27) : 
       murderous);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Burbles {
  public String unsaid;

  public Burbles(String unsaid) {
    this.unsaid = unsaid;
  }

  public abstract String roots(String satraps) ;

  public Long phobos(byte countless, Byte canceling) {
    Function1<Object, Jermaine<Character, Character>> removers = (wangles) -> {
      Jermaine<Character, Character> bows = new Jermaine<Character, Character>((long)93, new Object());
      String kimberly = "bosh";
      ((Burbles) null).unsaid =   ((true) ?
  "virgos" : 
   kimberly);
      return bows;
      
    };
    Boolean plods = false;
    Integer painless = -63;
    Integer emotion = ((plods) ?
      54 : 
       painless);
    return removers.apply(emotion).surgical;
    
  }
}

class Jermaine<Y extends Character, B extends Y> {
  public Long surgical;
  public Object fnma;

  public Jermaine(Long surgical,Object fnma) {
    this.surgical = surgical;
    this.fnma = fnma;
  }

  public final Double quotient(Double striving, Float... label) {
    return -43.677;
  }
}

class Duchess extends Jermaine<Character, Character> {
  public final Short warlord;

  public Duchess(Short warlord) {
    super((long)-88, (short)-9);
    this.warlord = warlord;
  }
}

class Fustian<Z extends Byte, A extends Byte> extends Duchess {
  public byte hellishly;
  public final Burbles pintoes;

  public Fustian(byte hellishly,Burbles pintoes) {
    super((short)88);
    this.hellishly = hellishly;
    this.pintoes = pintoes;
  }

  public A imperiled(char impels, Z etna) {
    A midas = (A) null;
    ((Hygiene) null).cavaliers((short)-74);
    return midas;
    
  }

  public final Z whitney(short bellow) {
    return (Z) null;
  }
}

interface Hygiene {
  public abstract <F_G> void cavaliers(F_G founds) ;
}

class Stammer<R, C> extends Fustian<Byte, Byte> {
  public Fustian<Byte, Byte> minority;
  public Double ventral;

  public Stammer(Fustian<Byte, Byte> minority,Double ventral) {
    super((byte)-56, (Burbles) null);
    this.minority = minority;
    this.ventral = ventral;
  }

  public Byte imperiled(char impels, Byte etna) {
    return (byte)44;
  }
}

final class Shuffler implements Hygiene {
  public <F_G> void cavaliers(F_G founds) {
    Boolean inculpate = false;
    final Chips<F_G, ? extends F_G, ? extends Duchess> grossed = (Chips<F_G, F_G, Duchess>) null;
    final Chips<F_G, ? extends F_G, ? extends Duchess> sawdust = grossed;
    new Errant<Long, Double>((long)67, (long)-99).texas().thievery();
      Object x_1 = ((inculpate) ?
  new Remorse<F_G, F_G, F_G>(sawdust) : 
   new Remorse<F_G, F_G, F_G>((Chips<F_G, F_G, Duchess>) null)).voodoos.martial;
    
  }

  public final boolean recline(char curtness, Cavort pervade) {
    boolean fulcrums = false;
    return ((true) ?
      fulcrums : 
       false);
    
  }
}

abstract class Chips<Y, Z, F extends Duchess> extends Fustian<Byte, Byte> {
  public final Y martial;
  public byte hellishly;

  public Chips(Y martial,byte hellishly) {
    super((byte)5, (Burbles) null);
    this.martial = martial;
    this.hellishly = hellishly;
  }

  public final Byte imperiled(char impels, Byte etna) {
    return (byte)52;
  }
}

class Remorse<J, D, I extends D> extends Burbles {
  public final Chips<D, ? extends D, ? extends Duchess> voodoos;

  public Remorse(Chips<D, ? extends D, ? extends Duchess> voodoos) {
    super("duller");
    this.voodoos = voodoos;
  }

  public String roots(String satraps) {
    String swarthy = "healthful";
    return swarthy;
    
  }

  public Long phobos(byte countless, Byte canceling) {
    return (long)10;
  }
}

class Cavort extends Stammer<Float, Byte> {
  public Fustian<Byte, Byte> minority;
  public final Boolean headier;

  public Cavort(Fustian<Byte, Byte> minority,Boolean headier) {
    super(new Stammer<Long, Long>(new Fustian<Byte, Byte>((byte)92, (Burbles) null), -97.619), 4.514);
    this.minority = minority;
    this.headier = headier;
  }

  public final void thievery() {
    final Boolean napalm = headier;
    Object x_2 = napalm;
    
  }

  public final Byte imperiled(char impels, Byte etna) {
    return (byte)-6;
  }
}

final class Errant<X, P> extends Jermaine<Character, Character> {
  public Long surgical;
  public final X underpass;

  public Errant(Long surgical,X underpass) {
    super((long)-25, new Object());
    this.surgical = surgical;
    this.underpass = underpass;
  }

  public final Cavort texas() {
    Cavort baristas = texas();
    Main.silicon((float)23.23);
    return baristas;
    
  }

  public final Integer report() {
    return -19;
  }
}

abstract class Ornerier<H> extends Jermaine<Character, Character> {
  public H gonging;
  public double topically;

  public Ornerier(H gonging,double topically) {
    super((long)-30, new Object());
    this.gonging = gonging;
    this.topically = topically;
  }

  public abstract Byte blanket() ;
}

interface Bimbos extends Hygiene {
  public abstract Jermaine<? extends Character, ? extends Character> pray() ;

  public abstract Bimbos worker() ;
}