package src.scottie;

interface Function0 {
   Object apply();
}
