package src.scottie;

abstract class Luftwaffe {
   public final Float malayalam;

   public Luftwaffe(Float var1) {
      this.malayalam = var1;
   }

   public abstract Object nominal(Object var1);
}
