package src.scottie;

final class Jailer {
   public final void bawdiness(Number var1, Number var2) {
      Double var3 = -16.867;
   }

   public final Number apprehend() {
      Number var1 = (Number)null;
      Number var2 = (Number)null;
      return var1;
   }
}
