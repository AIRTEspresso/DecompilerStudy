package src.scottie;

final class Comedies {
   public Jailer syllabus;
   public short possums;

   public Comedies(Jailer var1, short var2) {
      this.syllabus = var1;
      this.possums = var2;
   }

   public final boolean cumquats(Character var1) {
      return true;
   }

   public final Float curdle(Number var1, Float var2) {
      return 73.284F;
   }
}
