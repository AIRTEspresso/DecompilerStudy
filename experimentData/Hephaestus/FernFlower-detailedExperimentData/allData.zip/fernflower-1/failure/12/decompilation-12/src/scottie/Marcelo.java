package src.scottie;

final class Marcelo {
   public final Double headier;

   public Marcelo(Double var1) {
      this.headier = var1;
   }
}
