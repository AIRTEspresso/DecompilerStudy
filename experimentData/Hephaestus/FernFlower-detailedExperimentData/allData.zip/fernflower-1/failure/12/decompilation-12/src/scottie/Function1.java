package src.scottie;

interface Function1 {
   Object apply(Object var1);
}
