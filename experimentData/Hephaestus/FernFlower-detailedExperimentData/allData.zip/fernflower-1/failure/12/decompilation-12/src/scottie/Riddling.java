package src.scottie;

abstract class Riddling extends Punchiest {
   public Punchiest movables;
   public final Float malayalam;

   public Riddling(Punchiest var1, Float var2) {
      super(new Comedies(new Jailer(), (short)-82), 28.1F);
      this.movables = var1;
      this.malayalam = var2;
   }

   public abstract Jailer madame();
}
