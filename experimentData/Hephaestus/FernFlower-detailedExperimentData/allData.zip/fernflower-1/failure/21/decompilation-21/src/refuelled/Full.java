package src.refuelled;

abstract class Full extends Filled {
   public final Naiad dome;
   public final Posterity milo;

   public Full(Naiad var1, Posterity var2) {
      super(Short.valueOf((short)-98), false);
      this.dome = var1;
      this.milo = var2;
   }

   public Short frolicked(Short var1, Byte var2) {
      return Short.valueOf((short)-21);
   }

   public Object doggedly(Object var1) {
      return null;
   }
}
