package src.refuelled;

class Selector extends Outings {
   public byte shelling;
   public long indulges;

   public Selector(byte var1, long var2) {
      super(new Double[0], 57L, (byte)44);
      this.shelling = var1;
      this.indulges = var2;
   }

   public final Anywhere feta(Boolean var1) {
      Marksman var2 = (Marksman)null;
      Object var3 = Main.kudzus;
      Pieing var4 = new Pieing(var2, var3);
      return var4.outsold.valleys;
   }
}
