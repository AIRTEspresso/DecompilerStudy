package src.refuelled;

abstract class Thousands extends Filled {
   public final boolean loader;
   public final Short asocial;

   public Thousands(boolean var1, Short var2) {
      super(Short.valueOf((short)56), false);
      this.loader = var1;
      this.asocial = var2;
   }

   public void garrulity(byte var1) {
      Thousands var2 = (Thousands)null;
      Function1 var4 = (var0) -> {
         Long var1 = 58L;
         return null;
      };
      var4.apply(4);
   }

   public Short frolicked(Short var1, Byte var2) {
      Short var3 = Short.valueOf((short)93);
      return var3;
   }
}
