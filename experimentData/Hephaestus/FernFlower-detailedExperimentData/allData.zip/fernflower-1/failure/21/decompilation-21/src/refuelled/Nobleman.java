package src.refuelled;

abstract class Nobleman extends Prisons {
   public long indulges;
   public byte shelling;

   public Nobleman(long var1, byte var3) {
      super((byte)59, -97L);
      this.indulges = var1;
      this.shelling = var3;
   }

   public Filled panegyric(Character var1, double var2) {
      Filled var4 = (Filled)null;
      ((Captive)null).texas(true);
      return var4;
   }

   public int busses(boolean var1) {
      ((Thousands)null).garrulity((byte)93);
      return -73;
   }
}
