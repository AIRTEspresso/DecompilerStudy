package src.refuelled;

interface Antwerp {
   Selector hometowns(Float var1, Filled var2);

   Antwerp mutinies(Antwerp var1);
}
