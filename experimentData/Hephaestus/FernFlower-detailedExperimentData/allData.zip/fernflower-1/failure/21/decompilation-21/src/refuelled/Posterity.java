package src.refuelled;

class Posterity extends Captive {
   public short emory;
   public Prisons numerals;

   public Posterity(short var1, Prisons var2) {
      super(true, (short)50);
      this.emory = var1;
      this.numerals = var2;
   }

   public final void flimsily() {
      Double[] var1 = new Double[0];
      long var2 = -63L;
      new Outings(var1, var2, (byte)-27);
   }
}
