package src.refuelled;

abstract class Captive extends Filled {
   public final boolean loader;
   public short emory;

   public Captive(boolean var1, short var2) {
      super(Short.valueOf((short)-57), false);
      this.loader = var1;
      this.emory = var2;
   }

   public void texas(Boolean var1) {
      Boolean var2 = false;
   }

   public Short frolicked(Short var1, Byte var2) {
      Short var3 = Short.valueOf((short)-30);
      Main.calumny();
      return var3;
   }
}
