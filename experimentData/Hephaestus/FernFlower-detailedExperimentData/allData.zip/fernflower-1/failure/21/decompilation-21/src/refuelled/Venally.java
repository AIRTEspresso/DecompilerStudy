package src.refuelled;

class Venally {
   public final Object waspish;

   public Venally(Object var1) {
      this.waspish = var1;
   }

   public final void landings(Number var1) {
      Double var2 = -21.251;
      var2 = 69.72;
      Character var3 = 'v';
   }

   public final Double sweeties(Short var1, int var2) {
      Double var3 = Main.rolls;
      return var3;
   }
}
