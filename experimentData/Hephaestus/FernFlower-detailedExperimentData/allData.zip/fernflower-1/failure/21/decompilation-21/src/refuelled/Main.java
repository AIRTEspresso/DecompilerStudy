package src.refuelled;

class Main {
   static final Double rolls = -72.75;
   static final Object kudzus = new Object();
   static final int powell = -79;
   static final int unafraid = -79;
   static byte sleepers;
   static final Double[] fail;

   public static final Short sprees() {
      Short var0 = Short.valueOf((short)-65);
      (new Venally(new Object())).landings(new Long(72L));
      return var0;
   }

   public static final byte tortola(Double var0, Double var1) {
      Boolean var2 = true;
      Prisons var3 = (Prisons)null;
      Prisons var4 = var2 ? var3 : (Prisons)null;
      overmuch(beavering(false), -24);
      return var4.shelling;
   }

   public static final void overmuch(String var0, Integer var1) {
      Short var2 = ((Filled)null).slender;
   }

   public static final String beavering(Boolean var0) {
      return "pretences";
   }

   public static final Number chagrins(Float var0, Number var1) {
      Nobleman var2 = (Nobleman)null;
      Boolean var3 = true;
      Character var4 = 't';
      Function2 var5 = (var1x, var2x) -> {
         long var3 = var2.indulges;
         aimed();
         return var3;
      };
      (new Selector(sleepers, (Long)var5.apply(var0, ((Marksman)null).valleys))).feta(var3).lionel(var2.indulges);
      return ((Filled)null).sweeties(var2.panegyric(var3 ? var4 : 'd', var2.sweeties(Short.valueOf((short)-78), -70)).slender, var2.busses(false));
   }

   public static final void calumny() {
      sleepers = -71;
      Character var0 = '1';
   }

   public static final void aimed() {
      Marksman var0 = (Marksman)null;
      Anywhere var2 = var0.valleys;
   }

   public static final Object stops(Short var0, short var1) {
      Function0 var2 = () -> {
         return null;
      };
      Object var3 = var2.apply();
      Double var4 = rolls;
      Full var5 = (Full)null;
      redraws(var4, var5.dome.mumbler.vices());
      return var3;
   }

   public static final void redraws(Double var0, Long var1) {
      Antwerp var2 = (Antwerp)null;
      Antwerp var3 = var2.mutinies(var2);
      Antwerp var4 = (Antwerp)null;
   }

   public static final byte mead(Number var0) {
      return sleepers;
   }

   public static final void main(String[] var0) {
      Filled var1 = (Filled)null;
   }

   static {
      sleepers = tortola(rolls, (new Venally(kudzus)).sweeties(Short.valueOf((short)22), -79));
      fail = ((Filled)null).loader ? (new Outings((Double[])(new Object[]{(Double)null, (Double)null}), 94L, (byte)20)).axon : (Double[])(new Object[]{(Double)null, (Double)null, (Double)null});
   }
}
