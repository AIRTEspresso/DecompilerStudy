package src.refuelled;

final class Naiad extends Marksman {
   public Rotating mumbler;
   public byte shelling;

   public Naiad(Rotating var1, byte var2) {
      super(new Anywhere(), (byte)63);
      this.mumbler = var1;
      this.shelling = var2;
   }

   public Double desire() {
      return -69.852;
   }

   public final long denis(short var1, Object var2) {
      return -80L;
   }
}
