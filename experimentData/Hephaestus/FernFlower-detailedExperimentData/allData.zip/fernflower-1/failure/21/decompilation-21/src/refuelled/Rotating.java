package src.refuelled;

final class Rotating extends Captive {
   public Rotating() {
      super(true, (short)17);
   }

   public final Long vices() {
      Long var1 = 30L;
      byte var2 = Main.sleepers;
      Main.sleepers = var2;
      return 13L;
   }
}
