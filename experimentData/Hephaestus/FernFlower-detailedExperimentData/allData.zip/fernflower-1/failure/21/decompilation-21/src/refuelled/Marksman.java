package src.refuelled;

abstract class Marksman extends Prisons {
   public final Anywhere valleys;
   public byte shelling;

   public Marksman(Anywhere var1, byte var2) {
      super((byte)-90, -38L);
      this.valleys = var1;
      this.shelling = var2;
   }

   public final int busses(boolean var1) {
      return -74;
   }

   public abstract Double desire();
}
