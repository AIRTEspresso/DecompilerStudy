package src.refuelled;

class Outings extends Prisons {
   public final Double[] axon;
   public long indulges;
   public byte shelling;

   public Outings(Double[] var1, long var2, byte var4) {
      super((byte)46, -73L);
      this.axon = var1;
      this.indulges = var2;
      this.shelling = var4;
   }

   public int busses(boolean var1) {
      return 84;
   }

   public Double malicious(Double var1) {
      Double var2 = (Double)null;
      byte var3 = -13;
      this.shelling = var3;
      return var2;
   }
}
