package src.refuelled;

interface Function0 {
   Object apply();
}
