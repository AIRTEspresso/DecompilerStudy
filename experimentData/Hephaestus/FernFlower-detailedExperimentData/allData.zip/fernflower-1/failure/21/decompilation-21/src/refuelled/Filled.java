package src.refuelled;

abstract class Filled extends Venally {
   public Short slender;
   public final boolean loader;

   public Filled(Short var1, boolean var2) {
      super(-41L);
      this.slender = var1;
      this.loader = var2;
   }

   public abstract Short frolicked(Short var1, Byte var2);
}
