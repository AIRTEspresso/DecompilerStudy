package src.refuelled;

abstract class Prisons extends Venally {
   public byte shelling;
   public long indulges;

   public Prisons(byte var1, long var2) {
      super(-12);
      this.shelling = var1;
      this.indulges = var2;
   }

   public int busses(boolean var1) {
      boolean var2 = true;
      byte var3 = 79;
      return var3;
   }
}
