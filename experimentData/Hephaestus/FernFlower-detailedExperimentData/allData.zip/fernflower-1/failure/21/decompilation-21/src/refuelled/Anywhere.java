package src.refuelled;

class Anywhere extends Venally {
   public Anywhere() {
      super(new Object());
   }

   public final void lionel(long var1) {
      Boolean var3 = true;
      byte var4 = -79;
      Nobleman var5 = (Nobleman)null;
      (var3 ? new Posterity(var4, var5) : new Posterity((short)46, (Nobleman)null)).flimsily();
      Nobleman var6 = (Nobleman)null;
   }
}
