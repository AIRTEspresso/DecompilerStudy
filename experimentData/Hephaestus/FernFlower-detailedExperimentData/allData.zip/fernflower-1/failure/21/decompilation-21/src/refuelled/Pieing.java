package src.refuelled;

final class Pieing extends Outings {
   public Marksman outsold;
   public final Object voyeurism;

   public Pieing(Marksman var1, Object var2) {
      super((Double[])(new Object[]{(Double)null, (Double)null, (Double)null}), 56L, (byte)30);
      this.outsold = var1;
      this.voyeurism = var2;
   }

   public final Double malicious(Double var1) {
      return -43.554;
   }

   public final int busses(boolean var1) {
      byte var2 = 43;
      return var2;
   }
}
