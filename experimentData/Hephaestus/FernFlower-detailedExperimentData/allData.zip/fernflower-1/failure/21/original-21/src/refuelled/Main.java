package src.refuelled;

class Main {
  static final Double rolls = -72.750;

  static public final Short sprees() {
    Short successor = (short)-65;
    new Venally(new Object()).landings((Number) new Long(72));
    return successor;
    
  }

  static public final byte tortola(Double bugle, Double malleable) {
    final Boolean retain = true;
    Prisons vanzetti = (Prisons) null;
    Prisons harlot = ((retain) ?
      vanzetti : 
       (Prisons) null);
    Main.overmuch(Main.beavering(((long)24 == (long)4)), -24);
    return harlot.shelling;
    
  }

  static public final void overmuch(String nivea, Integer sector) {
    final Short zambia = ((Filled<Long, Short>) null).slender;
    Short deleon = zambia;
    Short dyer = zambia;
    deleon = dyer;
    Object x_1 = deleon;
    
  }

  static public final String beavering(Boolean wagged) {
    return "pretences";
  }

  static final Object kudzus = new Object();

  static final int powell = -79;

  static final int unafraid = Main.powell;

  static byte sleepers = Main.tortola(Main.rolls, new Venally(Main.kudzus).sweeties((short)22, Main.unafraid));

  static final Double[] fail = ((((Filled<Character, Short>) null).loader) ?
  new Outings<Double, Integer, Integer>((Double[]) new Object[]{(Double) null, (Double) null}, (long)94, (byte)20).axon : 
   (Double[]) new Object[]{(Double) null, (Double) null, (Double) null});

  static public final Number chagrins(Float downpours, Number neglected) {
    final Nobleman inhered = (Nobleman) null;
    final Boolean fifty = true;
    Character inspire = 't';
    Function2<Float, Anywhere, Long> vipers = (clockwise, varmints) -> {
      final long ventral = inhered.indulges;
      Main.aimed();
      return ventral;
      
    };
    new Selector(Main.sleepers, vipers.apply(downpours,   ((true) ?
  (Marksman) null : 
   (Marksman) null).valleys)).feta(fifty).lionel(inhered.indulges);
    return ((Filled<Double, Short>) null).sweeties(inhered.panegyric(  ((fifty) ?
  inspire : 
    'd'), inhered.sweeties((short)-78, -70)).slender, inhered.busses((true &&   ((true) ?
  false : 
   true))));
    
  }

  static public final void calumny() {
    final byte preface = (byte)-71;
    Main.sleepers = preface;
     Object x_3 = '1';
    
  }

  static public final void aimed() {
    final Marksman knievel = (Marksman) null;
    Marksman assured = knievel;
    Object x_8 = assured.valleys;
    
  }

  static public final <F_X> F_X stops(Short wildest, short narrated) {
    Function0<F_X> pavlov = () -> {
      return (F_X) null;
    };
    final F_X movables = pavlov.apply();
    Double almohad = Main.rolls;
    final Full<F_X> cameroon = (Full<F_X>) null;
    Main.redraws(almohad, cameroon.dome.mumbler.vices());
    return movables;
    
  }

  static public final void redraws(Double strays, Long liniments) {
    Antwerp septa = (Antwerp) null;
    Antwerp pavings = septa.mutinies(septa);
    Antwerp rumps = (Antwerp) null;
    pavings = rumps;
    Object x_9 = pavings;
    
  }

  static public final byte mead(Number bluffs) {
    return Main.sleepers;
  }

  static public final void main(String[] args) {
    Object x_10 = (Filled<Venally, Short>) null;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Venally {
  public final Object waspish;

  public Venally(Object waspish) {
    this.waspish = waspish;
  }

  public final void landings(Number civilizes) {
    Double tromped = -21.251;
    tromped = 69.72;
     Object x_0 = 'v';
    
  }

  public final Double sweeties(Short shunting, int taliesin) {
    final Double olsen = Main.rolls;
    return olsen;
    
  }
}

abstract class Prisons extends Venally {
  public byte shelling;
  public long indulges;

  public Prisons(byte shelling,long indulges) {
    super(-12);
    this.shelling = shelling;
    this.indulges = indulges;
  }

  public int busses(boolean maxillae) {
    int dionysian = 8;
    dionysian = 79;
    return dionysian;
    
  }
}

abstract class Filled<F, T extends Short> extends Venally {
  public Short slender;
  public final boolean loader;

  public Filled(Short slender,boolean loader) {
    super((long)-41);
    this.slender = slender;
    this.loader = loader;
  }

  public abstract T frolicked(Short broadness, Byte thorium) ;
}

class Outings<B extends Double, D extends Integer, H> extends Prisons {
  public final Double[] axon;
  public long indulges;
  public byte shelling;

  public Outings(Double[] axon,long indulges,byte shelling) {
    super((byte)46, (long)-73);
    this.axon = axon;
    this.indulges = indulges;
    this.shelling = shelling;
  }

  public int busses(boolean maxillae) {
    return 84;
  }

  public B malicious(B monaural) {
    final B grovelled = (B) null;
    byte there = (byte)-13;
    shelling = there;
    return grovelled;
    
  }
}

abstract class Nobleman extends Prisons {
  public long indulges;
  public byte shelling;

  public Nobleman(long indulges,byte shelling) {
    super((byte)59, (long)-97);
    this.indulges = indulges;
    this.shelling = shelling;
  }

  public Filled<? extends Byte, Short> panegyric(Character lettered, double larcenies) {
    Filled<? extends Byte, Short> laocoon = (Filled<Byte, Short>) null;
    ((Captive) null).texas(true);
    return laocoon;
    
  }

  public int busses(boolean maxillae) {
    final int syringed = -73;
    final byte seminal = (byte)93;
    ((Thousands) null).garrulity(seminal);
    return syringed;
    
  }
}

abstract class Captive extends Filled<Boolean, Short> {
  public final boolean loader;
  public short emory;

  public Captive(boolean loader,short emory) {
    super((short)-57, false);
    this.loader = loader;
    this.emory = emory;
  }

  public void texas(Boolean armada) {
    final boolean beefier = false;
    Object x_2 = beefier;
    
  }

  public Short frolicked(Short broadness, Byte thorium) {
    final Short chisels = (short)-30;
    Main.calumny();
    return chisels;
    
  }
}

abstract class Thousands extends Filled<Captive, Short> {
  public final boolean loader;
  public final Short asocial;

  public Thousands(boolean loader,Short asocial) {
    super((short)56, false);
    this.loader = loader;
    this.asocial = asocial;
  }

  public void garrulity(byte caries) {
    final Thousands miscall = (Thousands) null;
    Thousands uppercuts = miscall;
    Function1<Integer, Void> bitten = (plodded) -> {
      final Long bonded = (long)58;
      Object x_4 = bonded;
      return null;
    };
    bitten.apply(4);
    Object x_5 = uppercuts;
    
  }

  public Short frolicked(Short broadness, Byte thorium) {
    final Short limbered = (short)93;
    return limbered;
    
  }
}

class Anywhere extends Venally {
  public Anywhere() {
    super(new Object());
}

  public final void lionel(long truman) {
    Boolean irisher = true;
    short nightcap = (short)-79;
    final Nobleman envied = (Nobleman) null;
      ((irisher) ?
  new Posterity<Nobleman, Nobleman>(nightcap, envied) : 
   new Posterity<Nobleman, Nobleman>((short)46, (Nobleman) null)).flimsily();
    Object x_6 = (Nobleman) null;
    
  }
}

class Posterity<H extends Prisons, O extends H> extends Captive {
  public short emory;
  public O numerals;

  public Posterity(short emory,O numerals) {
    super(true, (short)50);
    this.emory = emory;
    this.numerals = numerals;
  }

  public final void flimsily() {
    final Double[] shammed = new Double[0];
    long bulbous = (long)-63;
    final byte kiddy = (byte)-27;
    Object x_7 = new Outings<Double, Integer, Byte>(shammed, bulbous, kiddy);
    
  }
}

class Selector extends Outings<Double, Integer, Double> {
  public byte shelling;
  public long indulges;

  public Selector(byte shelling,long indulges) {
    super(new Double[0], (long)57, (byte)44);
    this.shelling = shelling;
    this.indulges = indulges;
  }

  public final Anywhere feta(Boolean botanist) {
    Marksman churned = (Marksman) null;
    final Object kinder = Main.kudzus;
    Pieing<Integer, Integer> abashing = new Pieing<Integer, Integer>(churned, kinder);
    return abashing.outsold.valleys;
    
  }
}

abstract class Marksman extends Prisons {
  public final Anywhere valleys;
  public byte shelling;

  public Marksman(Anywhere valleys,byte shelling) {
    super((byte)-90, (long)-38);
    this.valleys = valleys;
    this.shelling = shelling;
  }

  public final int busses(boolean maxillae) {
    final int tanker = -74;
    return tanker;
    
  }

  public abstract Double desire() ;
}

final class Pieing<H, J extends H> extends Outings<Double, Integer, H> {
  public Marksman outsold;
  public final Object voyeurism;

  public Pieing(Marksman outsold,Object voyeurism) {
    super((Double[]) new Object[]{(Double) null, (Double) null, (Double) null}, (long)56, (byte)30);
    this.outsold = outsold;
    this.voyeurism = voyeurism;
  }

  public final Double malicious(Double monaural) {
    return -43.554;
  }

  public final int busses(boolean maxillae) {
    int instils = 43;
    return instils;
    
  }
}

interface Antwerp {
  public abstract Selector hometowns(Float lifetime, Filled<Antwerp, Short> ephesus) ;

  public abstract Antwerp mutinies(Antwerp salivates) ;
}

final class Rotating<A, L, J> extends Captive {
  public Rotating() {
    super(true, (short)17);
}

  public final Long vices() {
    final Long our = (long)30;
    byte streamers = Main.sleepers;
    Main.sleepers = streamers;
    return ((false) ?
      our : 
       (long)13);
    
  }
}

final class Naiad<A> extends Marksman {
  public Rotating<A, A, A> mumbler;
  public byte shelling;

  public Naiad(Rotating<A, A, A> mumbler,byte shelling) {
    super(new Anywhere(), (byte)63);
    this.mumbler = mumbler;
    this.shelling = shelling;
  }

  public Double desire() {
    return -69.852;
  }

  public final long denis(short demands, A saxony) {
    return (long)-80;
  }
}

abstract class Full<N> extends Filled<Boolean, Short> {
  public final Naiad<N> dome;
  public final Posterity<Prisons, ? super Prisons> milo;

  public Full(Naiad<N> dome,Posterity<Prisons, ? super Prisons> milo) {
    super((short)-98, false);
    this.dome = dome;
    this.milo = milo;
  }

  public Short frolicked(Short broadness, Byte thorium) {
    return (short)-21;
  }

  public N doggedly(N betted) {
    return (N) null;
  }
}