package src.pollen;

class Main {
  static Uphold<Float, Float> bulimic = (Uphold<Float, Float>) null;

  static final Double vagary = Main.bulimic.factories;

  static final Double punches = Main.vagary;

  static public final void unconcern(Character soft, boolean there) {
    Boolean deceitful = true;
    Double furrow = 22.66;
    Wanderers wangles = new Wanderers(furrow);
    Object x_1 = ((deceitful) ?
      new Wanderers(-73.316) : 
       wangles);
    
  }

  static public final boolean lollipops() {
    return true;
  }

  static public final String khazar() {
    final String pitcairn = "elocution";
    Proposing retarded = new Proposing(pitcairn, 76);
    final Juntas<Double, Double> coast = new Juntas<Double, Double>(retarded, 71);
    Main.teamwork(false, null, null, null);
      return ((true) ?
  coast : 
   new Juntas<Double, Double>(new Proposing("halters", 4), 31)).catchup.mediaeval;
    
  }

  static public final void teamwork(Boolean hijacks, Float... laban) {
    final String wisecrack = "burner";
    Bobcats<Number, Double> substrate = new Bobcats<Number, Double>(3, wisecrack);
    final Bobcats<Number, Double> cassettes = new Bobcats<Number, Double>(-62, "easel");
      ((false) ?
  substrate : 
   cassettes).hegelian(-76.186,   ((true) ?
  (short)76 : 
   (short)-54));
    
  }

  static public final void main(String[] args) {
    Object x_3 = 8;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Uphold<A, E> {
  public Double factories;
  public short adversary;

  public Uphold(Double factories,short adversary) {
    this.factories = factories;
    this.adversary = adversary;
  }

  public abstract long brooms(long integrity, E smuttier) ;

  public abstract double striding(double wronged, Float embraces) ;
}

final class Wanderers extends Uphold<Byte, Number> {
  public Double factories;

  public Wanderers(Double factories) {
    super(-37.395, (short)-18);
    this.factories = factories;
  }

  public long brooms(long integrity, Number smuttier) {
    return integrity;
  }

  public double striding(double wronged, Float embraces) {
    double browning = Main.bulimic.factories;
    final Uphold<Float, Float> meteor = (Uphold<Float, Float>) null;
    Uphold<Float, Float> graveled = ((false) ?
      meteor : 
       meteor);
    Main.bulimic = graveled;
    return browning;
    
  }
}

abstract class Dirtiest<O extends Long, P> extends Uphold<P, O> {
  public Double factories;

  public Dirtiest(Double factories) {
    super(58.790, (short)-72);
    this.factories = factories;
  }

  public O caucusing(Character felonious) {
    Function0<O> preciser = () -> {
      Function1<Number, O> mornings = (slightest) -> {
        O wavelets = (O) null;
        O poorest = wavelets;
        final O manhole = ((true) ?
          (O) null : 
           poorest);
        Function2<O, P, Void> skittish = (bonaparte, defense) -> {
          Object x_0 = -46.624;
          return null;
        };
        skittish.apply((O) null, (P) null);
        return manhole;
        
      };
      Carib<Object, Integer, Float> hoisted = (Carib<Object, Integer, Float>) null;
      Wanderers bitten = hoisted.diced;
      final Float restocked = (float)52.426;
      Main.unconcern(((Whoppers<Character>) null).elanor((O) null, (O) null), (false && false));
      return mornings.apply(bitten.striding(50.116, restocked));
      
    };
    O medicals = preciser.apply();
    Double martin = -6.309;
    Double explore = -42.819;
    factories =   ((false) ?
  martin : 
   explore);
    return medicals;
    
  }
}

abstract class Carib<R extends Object, S extends Integer, M> extends Uphold<R, R> {
  public Wanderers diced;

  public Carib(Wanderers diced) {
    super(-33.718, (short)54);
    this.diced = diced;
  }

  public double striding(double wronged, Float embraces) {
    return 6.111;
  }

  public S sicked() {
    S leased = (S) null;
    final S panama = leased;
    return panama;
    
  }
}

abstract class Whoppers<D extends Character> extends Carib<Float, Integer, Double> {
  public Whoppers() {
    super(new Wanderers(25.574));
}

  public abstract <F_X> Character elanor(F_X peeper, F_X cordoning) ;
}

final class Kopek<M, F> extends Uphold<M, F> {
  public Double factories;
  public M forensics;

  public Kopek(Double factories,M forensics) {
    super(98.479, (short)-10);
    this.factories = factories;
    this.forensics = forensics;
  }

  public long brooms(long integrity, F smuttier) {
    final long logjams = integrity;
    Function0<Void> lobbyist = () -> {
      Boolean nowhere = false;
      Carib<Object, ? extends Integer, ? extends M> evicting = (Carib<Object, Integer, M>) null;
      Carib<Object, ? extends Integer, ? extends M> nicely = evicting;
      Object x_2 = new Wanderers(  ((nowhere) ?
  nicely : 
   (Carib<Object, Integer, M>) null).striding(53.445, (float)73.185));
      return null;
    };
    lobbyist.apply();
    return logjams;
    
  }

  public double striding(double wronged, Float embraces) {
    double ulnas = factories;
    double explored = 92.470;
    double agenda = ((true) ?
      explored : 
       26.41);
    ulnas = striding(striding(agenda, embraces),   ((false) ?
  new Bohemian<Object, Integer>(true, -44.356) : 
   new Bohemian<Object, Integer>(true, -28.58)).schools((short)-2));
    return ulnas;
    
  }
}

final class Bohemian<C, N extends Integer> extends Carib<Object, Integer, N> {
  public boolean chock;
  public Double pluto;

  public Bohemian(boolean chock,Double pluto) {
    super(new Wanderers(-85.275));
    this.chock = chock;
    this.pluto = pluto;
  }

  public final Float schools(short bolshevik) {
    Float vatican = (float)-45.127;
    pluto = 35.157;
    return vatican;
    
  }

  public long brooms(long integrity, Object smuttier) {
    return (long)-27;
  }
}

class Proposing extends Carib<Float, Integer, Object> {
  public final String mediaeval;
  public Integer murphy;

  public Proposing(String mediaeval,Integer murphy) {
    super(new Wanderers(44.392));
    this.mediaeval = mediaeval;
    this.murphy = murphy;
  }

  public long brooms(long integrity, Float smuttier) {
    long reid = (long)-2;
    return reid;
    
  }
}

final class Juntas<V, J extends V> extends Proposing {
  public Proposing catchup;
  public Integer murphy;

  public Juntas(Proposing catchup,Integer murphy) {
    super("abating", -53);
    this.catchup = catchup;
    this.murphy = murphy;
  }

  public final long brooms(long integrity, Float smuttier) {
    return (long)99;
  }

  public final Double lawson() {
    return -82.715;
  }
}

class Bobcats<G extends Object, F> extends Proposing {
  public Integer murphy;
  public final String bakes;

  public Bobcats(Integer murphy,String bakes) {
    super("unclean", -29);
    this.murphy = murphy;
    this.bakes = bakes;
  }

  public short hegelian(double sloping, short hostesses) {
    final short silliness = (short)32;
    return silliness;
    
  }

  public final long brooms(long integrity, Float smuttier) {
    long assists = (long)61;
    final Float brims = (float)-29.804;
    String anti = "melisande";
    murphy = new Juntas<Long, Long>(new Proposing(anti, 21), 81).sicked();
    return brooms(assists, brims);
    
  }
}