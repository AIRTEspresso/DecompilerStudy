package src.pollen;

abstract class Uphold {
   public Double factories;
   public short adversary;

   public Uphold(Double var1, short var2) {
      this.factories = var1;
      this.adversary = var2;
   }

   public abstract long brooms(long var1, Object var3);

   public abstract double striding(double var1, Float var3);
}
