package src.pollen;

class Bobcats extends Proposing {
   public Integer murphy;
   public final String bakes;

   public Bobcats(Integer var1, String var2) {
      super("unclean", -29);
      this.murphy = var1;
      this.bakes = var2;
   }

   public short hegelian(double var1, short var3) {
      return 32;
   }

   public final long brooms(long var1, Float var3) {
      long var4 = 61L;
      Float var6 = -29.804F;
      String var7 = "melisande";
      this.murphy = (new Juntas(new Proposing(var7, 21), 81)).sicked();
      return this.brooms(var4, var6);
   }
}
