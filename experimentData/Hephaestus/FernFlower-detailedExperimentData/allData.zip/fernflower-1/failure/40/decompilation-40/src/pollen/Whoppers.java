package src.pollen;

abstract class Whoppers extends Carib {
   public Whoppers() {
      super(new Wanderers(25.574));
   }

   public abstract Character elanor(Object var1, Object var2);
}
