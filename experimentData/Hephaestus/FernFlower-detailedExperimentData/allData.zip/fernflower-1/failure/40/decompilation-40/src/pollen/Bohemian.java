package src.pollen;

final class Bohemian extends Carib {
   public boolean chock;
   public Double pluto;

   public Bohemian(boolean var1, Double var2) {
      super(new Wanderers(-85.275));
      this.chock = var1;
      this.pluto = var2;
   }

   public final Float schools(short var1) {
      Float var2 = -45.127F;
      this.pluto = 35.157;
      return var2;
   }

   public long brooms(long var1, Object var3) {
      return -27L;
   }
}
