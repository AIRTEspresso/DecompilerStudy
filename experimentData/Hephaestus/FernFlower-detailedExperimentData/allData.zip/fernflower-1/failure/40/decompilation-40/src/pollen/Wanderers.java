package src.pollen;

final class Wanderers extends Uphold {
   public Double factories;

   public Wanderers(Double var1) {
      super(-37.395, (short)-18);
      this.factories = var1;
   }

   public long brooms(long var1, Number var3) {
      return var1;
   }

   public double striding(double var1, Float var3) {
      double var4 = Main.bulimic.factories;
      Uphold var6 = (Uphold)null;
      Main.bulimic = var6;
      return var4;
   }
}
