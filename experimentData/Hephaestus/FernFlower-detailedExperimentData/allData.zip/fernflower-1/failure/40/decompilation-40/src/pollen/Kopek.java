package src.pollen;

final class Kopek extends Uphold {
   public Double factories;
   public Object forensics;

   public Kopek(Double var1, Object var2) {
      super(98.479, (short)-10);
      this.factories = var1;
      this.forensics = var2;
   }

   public long brooms(long var1, Object var3) {
      Function0 var6 = () -> {
         Boolean var0 = false;
         Carib var1 = (Carib)null;
         new Wanderers((var0 ? var1 : (Carib)null).striding(53.445, 73.185F));
         return null;
      };
      var6.apply();
      return var1;
   }

   public double striding(double var1, Float var3) {
      double var4 = this.factories;
      double var6 = 92.47;
      var4 = this.striding(this.striding(var6, var3), (new Bohemian(true, -28.58)).schools((short)-2));
      return var4;
   }
}
