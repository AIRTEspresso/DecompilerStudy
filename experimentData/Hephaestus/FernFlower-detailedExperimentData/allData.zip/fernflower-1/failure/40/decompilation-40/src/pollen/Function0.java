package src.pollen;

interface Function0 {
   Object apply();
}
