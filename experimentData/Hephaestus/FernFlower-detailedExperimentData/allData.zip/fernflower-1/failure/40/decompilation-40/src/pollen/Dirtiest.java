package src.pollen;

abstract class Dirtiest extends Uphold {
   public Double factories;

   public Dirtiest(Double var1) {
      super(58.79, (short)-72);
      this.factories = var1;
   }

   public Long caucusing(Character var1) {
      Function0 var2 = () -> {
         Function1 var0 = (var0x) -> {
            Long var1 = (Long)null;
            Long var3 = (Long)null;
            Function2 var4 = (var0, var1x) -> {
               Double var2 = -46.624;
               return null;
            };
            var4.apply((Long)null, (Object)null);
            return var3;
         };
         Carib var1 = (Carib)null;
         Wanderers var2 = var1.diced;
         Float var3 = 52.426F;
         Main.unconcern(((Whoppers)null).elanor((Long)null, (Long)null), false);
         return (Long)var0.apply(var2.striding(50.116, var3));
      };
      Long var3 = (Long)var2.apply();
      Double var4 = -6.309;
      Double var5 = -42.819;
      this.factories = var5;
      return var3;
   }
}
