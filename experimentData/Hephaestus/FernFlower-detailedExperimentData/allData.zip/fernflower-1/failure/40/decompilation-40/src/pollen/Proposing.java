package src.pollen;

class Proposing extends Carib {
   public final String mediaeval;
   public Integer murphy;

   public Proposing(String var1, Integer var2) {
      super(new Wanderers(44.392));
      this.mediaeval = var1;
      this.murphy = var2;
   }

   public long brooms(long var1, Float var3) {
      long var4 = -2L;
      return var4;
   }
}
