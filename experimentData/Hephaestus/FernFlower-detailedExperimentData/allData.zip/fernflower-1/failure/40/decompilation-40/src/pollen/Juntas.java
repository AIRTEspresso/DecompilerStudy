package src.pollen;

final class Juntas extends Proposing {
   public Proposing catchup;
   public Integer murphy;

   public Juntas(Proposing var1, Integer var2) {
      super("abating", -53);
      this.catchup = var1;
      this.murphy = var2;
   }

   public final long brooms(long var1, Float var3) {
      return 99L;
   }

   public final Double lawson() {
      return -82.715;
   }
}
