package src.pollen;

abstract class Carib extends Uphold {
   public Wanderers diced;

   public Carib(Wanderers var1) {
      super(-33.718, (short)54);
      this.diced = var1;
   }

   public double striding(double var1, Float var3) {
      return 6.111;
   }

   public Integer sicked() {
      Integer var1 = (Integer)null;
      return var1;
   }
}
