package src.pollen;

interface Function1 {
   Object apply(Object var1);
}
