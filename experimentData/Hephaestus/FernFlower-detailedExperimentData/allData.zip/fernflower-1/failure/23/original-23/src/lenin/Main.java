package src.lenin;

class Main {
  static Boolean gaff = true;

  static Boolean pilfered = Main.gaff;

  static public final Double difficult() {
    final Minis sects = (Minis) null;
    Boolean seaport = false;
    final Raps<Number, Number> chinked = new Raps<Number, Number>(new Poppins(new Heptagon<Boolean, Long>((short)35, false), (short)84));
    Main.gaff = ((seaport && chinked.luddite(new Cream<Raps<Character, Character>, Double>((float)37.114, (short)-78).muftis)) == chinked.luddite(  ((false) ?
  (float)-13.504 : 
   (float)-19.12)));
    return sects.borrowing;
    
  }

  static Boolean afoot = true;

  static Short tallying = (short)67;

  static final Raps<? extends Float, ? extends Float> beasts = new Raps<Float, Float>(  ((Main.afoot) ?
  new Poppins(new Heptagon<Boolean, Long>(Main.tallying, true), (short)-79) : 
   new Poppins(new Heptagon<Boolean, Long>((short)11, false), (short)-41)));

  static public final long jib(Object bilateral) {
    final long punker = Main.jib(new Object());
    final Object harrowing = new Object();
    final long gurgles = ((Main.pilfered) ?
      punker : 
       Main.jib(harrowing));
      ((false) ?
  (Ciphered<Double, Moonscape<Double>>) null : 
   (Ciphered<Double, Moonscape<Double>>) null).foraying.whackier((short)36, Main.jib(Main.beasts.lolcat( 'A')));
    return gurgles;
    
  }

  static public final boolean dickinson(Short arbitrate, boolean stockier) {
    final Long unhanded = ((true) ?
  (Stalks<Short>) null : 
   (Stalks<Short>) null).nazism;
    return (unhanded == (long)-17);
    
  }

  static public final void smites(Double president) {
    Object x_2 = -87.846;
    
  }

  static final String stringers = "congaing";

  static final String attack = "nursemaid";

  static public final void main(String[] args) {
    byte imposed = (byte)-76;
    Object x_3 = imposed;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Peddler<R extends Character, P, O extends R> {
  public final Short jeering;

  public Peddler(Short jeering) {
    this.jeering = jeering;
  }

  public final short pioneer(short compactly) {
    Boolean simper = false;
    final short razzing = ((simper) ?
      (short)-97 : 
       (short)-96);
    return razzing;
    
  }

  public final R lolcat(O remits) {
    return new Insureds<O, P, Integer>((Campsites<O, P>) null,  'V').mongoose.plusses;
  }
}

abstract class Campsites<F extends Character, I> {
  public final F plusses;
  public final F mediaeval;

  public Campsites(F plusses,F mediaeval) {
    this.plusses = plusses;
    this.mediaeval = mediaeval;
  }

  public abstract short alibied(short reserving) ;
}

final class Insureds<O extends Character, S, J> extends Campsites<Character, Character> {
  public Campsites<O, S> mongoose;
  public final Character mediaeval;

  public Insureds(Campsites<O, S> mongoose,Character mediaeval) {
    super((O) null, (O) null);
    this.mongoose = mongoose;
    this.mediaeval = mediaeval;
  }

  public short alibied(short reserving) {
    final short relegates = (short)62;
    return relegates;
    
  }

  public final S harmon(J sourced, S larry) {
    final S chimneys = (S) null;
    final Campsites<O, S> surrender = (Campsites<O, S>) null;
    mongoose = surrender;
    return chimneys;
    
  }
}

abstract class Minis extends Campsites<Character, Boolean> {
  public final Double borrowing;
  public final Float[] resultant;

  public Minis(Double borrowing,Float[] resultant) {
    super( 'e', 'M');
    this.borrowing = borrowing;
    this.resultant = resultant;
  }

  public short alibied(short reserving) {
    final short lengths = reserving;
    Short nepotism = (short)63;
    final Poppins clothiers = new Poppins(new Heptagon<Boolean, Long>(nepotism, true), (short)-82);
    clothiers.airmails.ought(false);
    return lengths;
    
  }

  public abstract Short mornings() ;
}

final class Heptagon<N extends Boolean, J extends Long> extends Peddler<Character, J, Character> {
  public final Short jeering;
  public N adopts;

  public Heptagon(Short jeering,N adopts) {
    super((short)28);
    this.jeering = jeering;
    this.adopts = adopts;
  }

  public final void ought(boolean minuteman) {
    final N iroquoian = (N) null;
    Object x_0 = iroquoian;
    
  }
}

final class Poppins extends Peddler<Character, Number, Character> {
  public final Heptagon<Boolean, Long> airmails;
  public final Short jeering;

  public Poppins(Heptagon<Boolean, Long> airmails,Short jeering) {
    super((short)54);
    this.airmails = airmails;
    this.jeering = jeering;
  }

  public final Peddler<? super Character, Character, Character> tizzies(boolean unnerve) {
    return new Peddler<Character, Character, Character>((short)-52);
  }
}

final class Raps<Q, S extends Q> extends Peddler<Character, S, Character> {
  public final Poppins epoxied;

  public Raps(Poppins epoxied) {
    super((short)-6);
    this.epoxied = epoxied;
  }

  public final Boolean luddite(float hibernate) {
    Boolean jimmy = false;
    return jimmy;
    
  }

  public final S disperse(Float maputo, Insureds<Character, Short, ? extends Number> foliage) {
    S reveries = (S) null;
    return reveries;
    
  }
}

class Cream<O extends Raps<Character, Character>, P> extends Peddler<Character, P, Character> {
  public final float muftis;
  public final Short jeering;

  public Cream(float muftis,Short jeering) {
    super((short)-17);
    this.muftis = muftis;
    this.jeering = jeering;
  }

  public final P sputnik(P subtler) {
    final P lividly = (P) null;
    Boolean boilers = false;
    Main.pilfered = boilers;
    return lividly;
    
  }
}

class Papyruses<W, J extends W> extends Peddler<Character, J, Character> {
  public final Short jeering;

  public Papyruses(Short jeering) {
    super((short)-69);
    this.jeering = jeering;
  }

  public final W exigency(short seesaws) {
    return (J) null;
  }
}

final class Moonscape<K> extends Peddler<Character, Long, Character> {
  public final char cairo;
  public final Campsites<? super Character, K> womanly;

  public Moonscape(char cairo,Campsites<? super Character, K> womanly) {
    super((short)83);
    this.cairo = cairo;
    this.womanly = womanly;
  }

  public final void whackier(Short moreover, K armament) {
    K bride = (K) null;
    Object x_1 = bride;
    
  }

  public final Cream<? super Raps<Character, Character>, ? super String> tolling(K kickstand, Cream<? super Raps<Character, Character>, ? super String> hellhole) {
    final Short goofed = Main.tallying;
    return new Cream<Raps<Character, Character>, String>((float)-14.999, goofed);
    
  }
}

abstract class Ciphered<V, Z extends Moonscape<? extends V>> extends Minis {
  public Moonscape<Long> foraying;

  public Ciphered(Moonscape<Long> foraying) {
    super(82.993, (Float[]) new Object[]{(float)-27.806, (float)-0.627, (float)5.31});
    this.foraying = foraying;
  }

  public Short mornings() {
    final Short levelled = foraying.jeering;
    return levelled;
    
  }
}

final class Relaxes extends Papyruses<Integer, Integer> {
  public Relaxes() {
    super((short)66);
}

  public final Integer trudging(Integer adage) {
    Campsites<? extends Character, ? extends Float> longer = (Campsites<Character, Float>) null;
    Lays deepness = new Lays(  ((true) ?
  longer : 
   (Campsites<Character, Float>) null));
    Boolean twirl = true;
    Function1<Double, Relaxes> filthy = (girders) -> {
      final Relaxes scoreless = (Relaxes) null;
      final Earthly<Minis> tsarina = (Earthly<Minis>) null;
      final Earthly<Minis> elevate = tsarina;
      elevate.chummiest();
      return scoreless;
      
    };
    return deepness.errors(  ((twirl) ?
  -23.456 : 
   (byte)-90)).rattlings(filthy.apply(-72.389)).hardtop;
    
  }

  public final Relaxes juanita(Number swells, Relaxes streaks) {
    return (Relaxes) null;
  }
}

abstract class Sung<Q extends Insureds<? super Character, ? super Double, Short>, X, N extends Cream<? extends Raps<Character, Character>, ? extends Q>> extends Campsites<Character, String> {
  public final Integer hardtop;

  public Sung(Integer hardtop) {
    super( 'V', 'q');
    this.hardtop = hardtop;
  }

  public short alibied(short reserving) {
    return (short)12;
  }

  public abstract N renoir() ;
}

interface Inflates<I extends Cream<? extends Raps<Character, Character>, ? extends Double>> {
  public abstract Sung<Insureds<Character, Double, Short>, Long, Cream<Raps<Character, Character>, Insureds<Character, Double, Short>>> rattlings(Relaxes undercut) ;

  public abstract I billed(Integer whinier, I droops) ;
}

final class Lays extends Ciphered<Byte, Moonscape<Byte>> {
  public final Campsites<? extends Character, ? extends Float> parasols;

  public Lays(Campsites<? extends Character, ? extends Float> parasols) {
    super(new Moonscape<Long>( 'v', (Campsites<Character, Long>) null));
    this.parasols = parasols;
  }

  public final Inflates<Cream<Raps<Character, Character>, Double>> errors(Number gonging) {
    return (Inflates<Cream<Raps<Character, Character>, Double>>) null;
  }

  public final Raps<? super Boolean, Boolean> branched(Raps<? super Boolean, Boolean> potluck) {
    final Boolean spineless = false;
    final Heptagon<Boolean, Long> chug = new Heptagon<Boolean, Long>((short)7, spineless);
    Short catkin = (short)28;
    return new Raps<Boolean, Boolean>(new Poppins(chug, catkin));
    
  }
}

interface Earthly<H extends Minis> extends Inflates<Cream<Raps<Character, Character>, Double>> {
  public abstract void chummiest() ;
}

abstract class Stalks<V> extends Ciphered<V, Moonscape<V>> {
  public Long nazism;
  public V snakes;

  public Stalks(Long nazism,V snakes) {
    super(new Moonscape<Long>( 'g', (Campsites<Character, Long>) null));
    this.nazism = nazism;
    this.snakes = snakes;
  }

  public <F_E> F_E pugnacity(F_E outermost) {
    final F_E mao = (F_E) null;
    Main.smites(-88.573);
    return mao;
    
  }

  public Heptagon<? extends Boolean, ? super Long> slaphappy() {
    final Short escorted = (short)39;
    Boolean canister = false;
    final Heptagon<? extends Boolean, ? super Long> lavender = new Heptagon<Boolean, Long>(escorted, canister);
    return lavender;
    
  }
}