package src.lenin;

class Cream extends Peddler {
   public final float muftis;
   public final Short jeering;

   public Cream(float var1, Short var2) {
      super(Short.valueOf((short)-17));
      this.muftis = var1;
      this.jeering = var2;
   }

   public final Object sputnik(Object var1) {
      Object var2 = null;
      Boolean var3 = false;
      Main.pilfered = var3;
      return var2;
   }
}
