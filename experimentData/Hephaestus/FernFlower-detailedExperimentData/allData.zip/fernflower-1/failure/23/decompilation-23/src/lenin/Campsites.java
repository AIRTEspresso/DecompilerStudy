package src.lenin;

abstract class Campsites {
   public final Character plusses;
   public final Character mediaeval;

   public Campsites(Character var1, Character var2) {
      this.plusses = var1;
      this.mediaeval = var2;
   }

   public abstract short alibied(short var1);
}
