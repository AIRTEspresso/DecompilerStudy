package src.lenin;

interface Function3 {
   Object apply(Object var1, Object var2, Object var3);
}
