package src.lenin;

final class Moonscape extends Peddler {
   public final char cairo;
   public final Campsites womanly;

   public Moonscape(char var1, Campsites var2) {
      super(Short.valueOf((short)83));
      this.cairo = var1;
      this.womanly = var2;
   }

   public final void whackier(Short var1, Object var2) {
      Object var3 = null;
   }

   public final Cream tolling(Object var1, Cream var2) {
      Short var3 = Main.tallying;
      return new Cream(-14.999F, var3);
   }
}
