package src.lenin;

class Peddler {
   public final Short jeering;

   public Peddler(Short var1) {
      this.jeering = var1;
   }

   public final short pioneer(short var1) {
      Boolean var2 = false;
      int var3 = var2 ? -97 : -96;
      return (short)var3;
   }

   public final Character lolcat(Character var1) {
      return (new Insureds((Campsites)null, 'V')).mongoose.plusses;
   }
}
