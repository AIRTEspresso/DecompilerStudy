package src.lenin;

interface Inflates {
   Sung rattlings(Relaxes var1);

   Cream billed(Integer var1, Cream var2);
}
