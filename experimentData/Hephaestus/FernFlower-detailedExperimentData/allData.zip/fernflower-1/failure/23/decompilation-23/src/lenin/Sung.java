package src.lenin;

abstract class Sung extends Campsites {
   public final Integer hardtop;

   public Sung(Integer var1) {
      super('V', 'q');
      this.hardtop = var1;
   }

   public short alibied(short var1) {
      return 12;
   }

   public abstract Cream renoir();
}
