package src.lenin;

final class Raps extends Peddler {
   public final Poppins epoxied;

   public Raps(Poppins var1) {
      super(Short.valueOf((short)-6));
      this.epoxied = var1;
   }

   public final Boolean luddite(float var1) {
      Boolean var2 = false;
      return var2;
   }

   public final Object disperse(Float var1, Insureds var2) {
      Object var3 = null;
      return var3;
   }
}
