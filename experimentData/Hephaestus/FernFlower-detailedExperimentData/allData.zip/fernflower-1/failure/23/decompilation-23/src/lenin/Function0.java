package src.lenin;

interface Function0 {
   Object apply();
}
