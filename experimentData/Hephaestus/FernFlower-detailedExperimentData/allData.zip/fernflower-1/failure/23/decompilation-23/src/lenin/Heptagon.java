package src.lenin;

final class Heptagon extends Peddler {
   public final Short jeering;
   public Boolean adopts;

   public Heptagon(Short var1, Boolean var2) {
      super(Short.valueOf((short)28));
      this.jeering = var1;
      this.adopts = var2;
   }

   public final void ought(boolean var1) {
      Boolean var2 = (Boolean)null;
   }
}
