package src.lenin;

final class Lays extends Ciphered {
   public final Campsites parasols;

   public Lays(Campsites var1) {
      super(new Moonscape('v', (Campsites)null));
      this.parasols = var1;
   }

   public final Inflates errors(Number var1) {
      return (Inflates)null;
   }

   public final Raps branched(Raps var1) {
      Boolean var2 = false;
      Heptagon var3 = new Heptagon(Short.valueOf((short)7), var2);
      Short var4 = Short.valueOf((short)28);
      return new Raps(new Poppins(var3, var4));
   }
}
