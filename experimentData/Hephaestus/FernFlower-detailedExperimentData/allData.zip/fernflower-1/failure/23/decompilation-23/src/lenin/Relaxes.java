package src.lenin;

final class Relaxes extends Papyruses {
   public Relaxes() {
      super(Short.valueOf((short)66));
   }

   public final Integer trudging(Integer var1) {
      Campsites var2 = (Campsites)null;
      Lays var3 = new Lays(var2);
      Boolean var4 = true;
      Function1 var5 = (var0) -> {
         Relaxes var1 = (Relaxes)null;
         Earthly var2 = (Earthly)null;
         var2.chummiest();
         return var1;
      };
      return var3.errors(var4 ? -23.456 : -90.0).rattlings((Relaxes)var5.apply(-72.389)).hardtop;
   }

   public final Relaxes juanita(Number var1, Relaxes var2) {
      return (Relaxes)null;
   }
}
