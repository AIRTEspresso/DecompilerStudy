package src.lenin;

interface Function1 {
   Object apply(Object var1);
}
