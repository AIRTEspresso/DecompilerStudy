package src.lenin;

class Papyruses extends Peddler {
   public final Short jeering;

   public Papyruses(Short var1) {
      super(Short.valueOf((short)-69));
      this.jeering = var1;
   }

   public final Object exigency(short var1) {
      return null;
   }
}
