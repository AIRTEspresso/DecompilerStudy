package src.lenin;

final class Insureds extends Campsites {
   public Campsites mongoose;
   public final Character mediaeval;

   public Insureds(Campsites var1, Character var2) {
      super((Character)null, (Character)null);
      this.mongoose = var1;
      this.mediaeval = var2;
   }

   public short alibied(short var1) {
      return 62;
   }

   public final Object harmon(Object var1, Object var2) {
      Object var3 = null;
      Campsites var4 = (Campsites)null;
      this.mongoose = var4;
      return var3;
   }
}
