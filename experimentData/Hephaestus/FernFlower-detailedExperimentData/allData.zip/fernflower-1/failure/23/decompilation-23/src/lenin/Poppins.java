package src.lenin;

final class Poppins extends Peddler {
   public final Heptagon airmails;
   public final Short jeering;

   public Poppins(Heptagon var1, Short var2) {
      super(Short.valueOf((short)54));
      this.airmails = var1;
      this.jeering = var2;
   }

   public final Peddler tizzies(boolean var1) {
      return new Peddler(Short.valueOf((short)-52));
   }
}
