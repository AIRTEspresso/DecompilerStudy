package src.lenin;

interface Earthly extends Inflates {
   void chummiest();
}
