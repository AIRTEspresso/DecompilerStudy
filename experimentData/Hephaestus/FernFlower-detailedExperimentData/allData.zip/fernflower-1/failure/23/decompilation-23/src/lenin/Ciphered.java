package src.lenin;

abstract class Ciphered extends Minis {
   public Moonscape foraying;

   public Ciphered(Moonscape var1) {
      super(82.993, (Float[])(new Object[]{-27.806F, -0.627F, 5.31F}));
      this.foraying = var1;
   }

   public Short mornings() {
      Short var1 = this.foraying.jeering;
      return var1;
   }
}
