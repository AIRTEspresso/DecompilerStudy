package src.lenin;

abstract class Stalks extends Ciphered {
   public Long nazism;
   public Object snakes;

   public Stalks(Long var1, Object var2) {
      super(new Moonscape('g', (Campsites)null));
      this.nazism = var1;
      this.snakes = var2;
   }

   public Object pugnacity(Object var1) {
      Object var2 = null;
      Main.smites(-88.573);
      return var2;
   }

   public Heptagon slaphappy() {
      Short var1 = Short.valueOf((short)39);
      Boolean var2 = false;
      Heptagon var3 = new Heptagon(var1, var2);
      return var3;
   }
}
