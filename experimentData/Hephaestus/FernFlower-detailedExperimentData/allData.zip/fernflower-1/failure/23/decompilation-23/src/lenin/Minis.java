package src.lenin;

abstract class Minis extends Campsites {
   public final Double borrowing;
   public final Float[] resultant;

   public Minis(Double var1, Float[] var2) {
      super('e', 'M');
      this.borrowing = var1;
      this.resultant = var2;
   }

   public short alibied(short var1) {
      Short var3 = Short.valueOf((short)63);
      Poppins var4 = new Poppins(new Heptagon(var3, true), Short.valueOf((short)-82));
      var4.airmails.ought(false);
      return var1;
   }

   public abstract Short mornings();
}
