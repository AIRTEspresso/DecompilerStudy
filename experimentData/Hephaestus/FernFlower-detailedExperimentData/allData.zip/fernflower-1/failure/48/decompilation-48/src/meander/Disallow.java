package src.meander;

final class Disallow extends Forceful {
   public final Factoring overlaid;
   public boolean resound;

   public Disallow(Factoring var1, boolean var2) {
      super(3, false);
      this.overlaid = var1;
      this.resound = var2;
   }
}
