package src.meander;

abstract class Grenoble {
   public final Commend oozing;
   public Integer gentile;

   public Grenoble(Commend var1, Integer var2) {
      this.oozing = var1;
      this.gentile = var2;
   }

   public abstract int playlists();

   public abstract Short[] pane(double var1);
}
