package src.meander;

interface Function0 {
   Object apply();
}
