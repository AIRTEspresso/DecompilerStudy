package src.meander;

final class Commend {
   public final Long prattle;

   public Commend(Long var1) {
      this.prattle = var1;
   }

   public final Character deranged(Boolean var1, Byte var2) {
      Character var3 = 'Z';
      return var3;
   }
}
