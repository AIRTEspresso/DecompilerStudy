package src.meander;

class Dynamism extends Surmounts {
   public final Surmounts silicates;
   public final byte tufts;

   public Dynamism(Surmounts var1, byte var2) {
      super(98, -33.559F);
      this.silicates = var1;
      this.tufts = var2;
   }
}
