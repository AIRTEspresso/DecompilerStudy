package src.meander;

interface Function1 {
   Object apply(Object var1);
}
