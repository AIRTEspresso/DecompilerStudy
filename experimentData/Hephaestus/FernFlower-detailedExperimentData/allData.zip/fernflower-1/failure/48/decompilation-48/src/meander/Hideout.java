package src.meander;

final class Hideout extends Factoring {
   public Double boxes;

   public Hideout(Double var1) {
      super(-72);
      this.boxes = var1;
   }

   public void damndest(Commend var1) {
      Hideout var2 = (Hideout)null;
   }

   public Short[] pane(double var1) {
      Short var3 = Short.valueOf((short)18);
      Short[] var4 = (Short[])(new Object[]{Short.valueOf((short)48), var3});
      return var4;
   }

   public int playlists() {
      return -50;
   }
}
