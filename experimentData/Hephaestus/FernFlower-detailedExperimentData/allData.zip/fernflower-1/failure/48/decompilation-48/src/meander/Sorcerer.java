package src.meander;

final class Sorcerer extends Factoring {
   public Handymen pollen;

   public Sorcerer(Handymen var1) {
      super(4);
      this.pollen = var1;
   }

   public int playlists() {
      return -5;
   }

   public void damndest(Byte var1) {
      Enviable var2 = new Enviable(false, (Factoring)null);
   }

   public Short[] pane(double var1) {
      Short var3 = Short.valueOf((short)-74);
      Float var4 = 7.837F;
      Main.whereof(var4);
      return (Short[])(new Object[]{var3});
   }
}
