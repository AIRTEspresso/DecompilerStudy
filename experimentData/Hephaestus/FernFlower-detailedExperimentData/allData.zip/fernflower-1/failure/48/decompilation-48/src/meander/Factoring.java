package src.meander;

abstract class Factoring extends Grenoble {
   public Integer gentile;

   public Factoring(Integer var1) {
      super(new Commend(-74L), -74);
      this.gentile = var1;
   }

   public abstract void damndest(Object var1);
}
