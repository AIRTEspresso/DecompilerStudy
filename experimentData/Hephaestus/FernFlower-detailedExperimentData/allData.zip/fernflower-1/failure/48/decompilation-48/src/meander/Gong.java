package src.meander;

final class Gong extends Forceful {
   public Hideout duties;
   public boolean resound;

   public Gong(Hideout var1, boolean var2) {
      super(-70, false);
      this.duties = var1;
      this.resound = var2;
   }
}
