package src.meander;

class Enviable extends Forceful {
   public boolean resound;
   public Factoring swimsuits;

   public Enviable(boolean var1, Factoring var2) {
      super(-14, false);
      this.resound = var1;
      this.swimsuits = var2;
   }

   public final Factoring homeliest(Float var1) {
      Factoring var2 = (Factoring)null;
      return var2;
   }
}
