package src.meander;

class Surmounts extends Factoring {
   public final Integer methanol;
   public final Float contends;

   public Surmounts(Integer var1, Float var2) {
      super(34);
      this.methanol = var1;
      this.contends = var2;
   }

   public Forceful seizing(int var1) {
      Forceful var2 = new Forceful(23, true);
      return var2;
   }

   public void damndest(Enviable var1) {
      Hearts var2 = (Hearts)null;
      var2.upchuck(var1.resound, (Hideout)null);
   }

   public int playlists() {
      return this.methanol;
   }

   public Short[] pane(double var1) {
      Short[] var3 = new Short[0];
      Function1 var4 = (var0) -> {
         Enviable var1 = new Enviable(true, (Factoring)null);
         var1.resound = true;
         Integer var2 = 91;
         return null;
      };
      var4.apply((new Sorcerer(Main.airhead)).pollen);
      return var3;
   }
}
