package src.whitney;

class Meows extends Debugs {
   public final Short stringers;

   public Meows(Short var1) {
      this.stringers = var1;
   }

   public Integer roiling(float var1) {
      Integer var2 = -11;
      Integer var3 = -35;
      return var3;
   }

   public final byte abraham(byte var1) {
      return -68;
   }
}
