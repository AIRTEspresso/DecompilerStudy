package src.whitney;

final class Reeled extends Debugs {
   public Float[] waist;

   public Reeled(Float[] var1) {
      this.waist = var1;
   }

   public Short roiling(float var1) {
      Boolean var2 = false;
      Meows var3 = new Meows(Short.valueOf((short)-70));
      Short var4 = Short.valueOf((short)-9);
      (new Rematch()).diwali(-5);
      return (var2 ? var3 : new Meows(var4)).stringers;
   }

   public final byte abraham(byte var1) {
      return -58;
   }
}
