package src.whitney;

interface Function0 {
   Object apply();
}
