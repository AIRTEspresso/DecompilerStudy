package src.whitney;

class Lactated extends Debugs {
   public Lactated budget;
   public final Double hectares;

   public Lactated(Lactated var1, Double var2) {
      this.budget = var1;
      this.hectares = var2;
   }

   public Short roiling(float var1) {
      long var2 = 0L;
      float var4 = Main.novgorod(Main.grower(var2));
      long var5 = -8L;
      return this.budget.roiling(var4);
   }

   public byte abraham(byte var1) {
      Function1 var2 = (var0) -> {
         Boolean var1 = false;
         Float var2 = 70.258F;
         Temperate var3 = new Temperate(var2);
         (var1 ? var3 : new Temperate(-77.83F)).banks = null;
         Debugs var4 = (Debugs)null;
         return null;
      };
      Debugs var3 = (Debugs)null;
      Debugs var4 = (Debugs)null;
      var2.apply(var3 != var4 || ((Eastward)null).lair);
      return -66;
   }
}
