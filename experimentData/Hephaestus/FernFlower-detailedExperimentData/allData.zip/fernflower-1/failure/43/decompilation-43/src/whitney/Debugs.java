package src.whitney;

abstract class Debugs {
   public byte abraham(byte var1) {
      return var1;
   }

   public abstract Object roiling(float var1);
}
