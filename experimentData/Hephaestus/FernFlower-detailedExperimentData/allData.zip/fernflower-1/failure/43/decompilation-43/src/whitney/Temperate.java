package src.whitney;

class Temperate extends Meows {
   public Float banks;

   public Temperate(Float var1) {
      super(Short.valueOf((short)-58));
      this.banks = var1;
   }

   public final Integer roiling(float var1) {
      Integer var2 = 30;
      Main.connector();
      return var2;
   }
}
