package src.whitney;

abstract class Eastward extends Debugs {
   public Boolean lair;
   public Integer hassock;

   public Eastward(Boolean var1, Integer var2) {
      this.lair = var1;
      this.hassock = var2;
   }

   public Long roiling(float var1) {
      Long var2 = -48L;
      return var2;
   }

   public final byte abraham(byte var1) {
      return -91;
   }
}
