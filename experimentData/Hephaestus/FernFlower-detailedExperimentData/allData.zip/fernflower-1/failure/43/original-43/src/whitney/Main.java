package src.whitney;

class Main {
  static Boolean rectify = true;

  static int kilotons = ((false) ?
  24 : 
   91);

  static final int curls = Main.kilotons;

  static int beaming = ((Main.rectify) ?
  Main.curls : 
   ((true) ?
    -21 : 
     5));

  static public final Integer grower(long plucky) {
    long snide = (long)57;
    Integer tongan = Main.grower(snide);
    final Integer retinal = -69;
    Function1<Integer, Void> annoyance = (khalid) -> {
      final int twigged = khalid;
      Object x_0 = twigged;
      return null;
    };
    annoyance.apply(  ((true) ?
  -14 : 
   -62));
    return ((false) ?
      tongan : 
       ((true) ?
        retinal : 
         98));
    
  }

  static final Float editors = ((false) ?
  (float)-100.225 : 
   (float)-6.155);

  static public final Double swindle(Double staler) {
    Double cavaliers = 42.824;
    return cavaliers;
    
  }

  static Long shimming = (long)-82;

  static public final void connector() {
    Byte blogger = (byte)-19;
    Object x_2 = blogger;
    
  }

  static public final Debugs<? super Character> chiefly(Debugs<? super String> alphas, Debugs<? super Character> truly) {
    final Debugs<Character> ritualism = (Debugs<Character>) null;
    final Boolean recasts = false;
    Boolean musicals = recasts;
    Main.rectify = (recasts || musicals);
    return ritualism;
    
  }

  static public final float novgorod(Integer inspiring) {
    float tarrying = Main.editors;
    return tarrying;
    
  }

  static public final void main(String[] args) {
    Boolean gordimer = false;
    Float memo = (float)-6.815;
    Short forks = ((gordimer) ?
  new Temperate<Float, Float, Float>((float)-75.385) : 
   new Temperate<Float, Float, Float>(memo)).stringers;
    Object x_4 = new Meows(forks);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Debugs<W> {
  public byte abraham(byte realist) {
    final byte defeated = realist;
    return defeated;
    
  }

  public abstract W roiling(float soonest) ;
}

final class Reeled extends Debugs<Short> {
  public Float[] waist;

  public Reeled(Float[] waist) {
    super();
    this.waist = waist;
  }

  public Short roiling(float soonest) {
    Boolean socials = false;
    final Meows intones = new Meows((short)-70);
    final Short tissue = (short)-9;
    new Rematch<Float, Float>().diwali(-5);
      return ((socials) ?
  intones : 
   new Meows(tissue)).stringers;
    
  }

  public final byte abraham(byte realist) {
    return (byte)-58;
  }
}

class Meows extends Debugs<Integer> {
  public final Short stringers;

  public Meows(Short stringers) {
    super();
    this.stringers = stringers;
  }

  public Integer roiling(float soonest) {
    Integer sorrier = -11;
    final Integer lifesaver = -35;
    sorrier = lifesaver;
    return sorrier;
    
  }

  public final byte abraham(byte realist) {
    return (byte)-68;
  }
}

final class Rematch<K extends Float, X extends K> extends Debugs<Double> {
  public Rematch() {
    super();
}

  public final void diwali(int poppins) {
    Temperate<K, K, K> opaqued = new Temperate<K, K, K>((K) null);
    K hunkers = opaqued.banks;
    Function2<X, X, Temperate<K, K, K>> coronae = (moe, diligence) -> {
      return new Temperate<K, K, K>((K) null);
    };
    X foremasts = (X) null;
    opaqued = coronae.apply(foremasts, (X) null);
    Object x_1 = hunkers;
    
  }

  public Double roiling(float soonest) {
    Double plowshare = 42.619;
    return plowshare;
    
  }
}

class Temperate<S extends Float, Q extends S, U extends Q> extends Meows {
  public S banks;

  public Temperate(S banks) {
    super((short)-58);
    this.banks = banks;
  }

  public final Integer roiling(float soonest) {
    final Integer azimuths = 30;
    Main.connector();
    return azimuths;
    
  }
}

class Lactated extends Debugs<Short> {
  public Lactated budget;
  public final Double hectares;

  public Lactated(Lactated budget,Double hectares) {
    super();
    this.budget = budget;
    this.hectares = hectares;
  }

  public Short roiling(float soonest) {
    long leased = (long)0;
    final float misuses = Main.novgorod(Main.grower(leased));
    long brunei = ((false) ?
      (long)65 : 
       (long)-8);
    leased = brunei;
    return budget.roiling(misuses);
    
  }

  public byte abraham(byte realist) {
    final byte altoids = ((true) ?
      (byte)-66 : 
       (byte)-23);
    Function1<Boolean, Void> varmints = (jaguars) -> {
      Boolean traces = false;
      final Float oxymora = (float)70.258;
      final Temperate<Float, Float, Float> accusing = new Temperate<Float, Float, Float>(oxymora);
        ((traces) ?
  accusing : 
   new Temperate<Float, Float, Float>((float)-77.83)).banks = null;
      Object x_3 = ((false) ?
        (Debugs<Double>) null : 
         (Debugs<Double>) null);
      return null;
    };
    Debugs<? super Boolean> brazening = (Debugs<Boolean>) null;
    Debugs<? super Boolean> morphine = (Debugs<Boolean>) null;
    varmints.apply(((brazening != morphine) || ((Eastward<Float, Number, Integer>) null).lair));
    return altoids;
    
  }
}

abstract class Eastward<S extends Float, U, B extends Integer> extends Debugs<Long> {
  public Boolean lair;
  public Integer hassock;

  public Eastward(Boolean lair,Integer hassock) {
    super();
    this.lair = lair;
    this.hassock = hassock;
  }

  public Long roiling(float soonest) {
    final Long warranty = (long)-48;
    return warranty;
    
  }

  public final byte abraham(byte realist) {
    return (byte)-91;
  }
}