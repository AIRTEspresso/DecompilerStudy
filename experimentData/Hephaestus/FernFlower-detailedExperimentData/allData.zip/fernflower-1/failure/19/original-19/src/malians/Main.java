package src.malians;

class Main {
  static final Double inhibited = -64.783;

  static Double perils = Main.inhibited;

  static public final boolean pitt() {
    final Boolean walden = Main.pitt();
    final String freudian = "cremated";
    boolean daftest = (freudian != "wrack");
    daftest = false;
    return ((walden) ?
      new Hostages<String, Double>(true,  'h').wormiest : 
       daftest);
    
  }

  static public final byte occludes() {
    Boolean mastering = Main.pitt();
    final byte width = (byte)-75;
    byte egging = width;
      ((mastering) ?
  ((Auden<Short, Short>) null).wimpled : 
   ((Auden<Britten, Britten>) null).wimpled).bang((float)91.580);
    return ((mastering) ?
      egging : 
       Main.occludes());
    
  }

  static public final void tomato() {
    Function0<Void> dristan = () -> {
      final Hostages<Double, ? super Gilda> messy = new Hostages<Double, Gilda>(true,  'v');
      final Hostages<Double, ? super Gilda> videodisc = messy;
      videodisc.beretta =  'u';
      Object x_5 = (float)-65.799;
      return null;
    };
    dristan.apply();
    Object x_6 = new Vacation<Periwigs, Character>();
    
  }

  static Long mcmillan = ((Gilda) null).calmness.fondu().mongoose;

  static final Periwigs decode = new Anecdota<Long, Long>(79).doughier(Main.mcmillan);

  static Double murkily = -84.194;

  static final Double maritza = Main.murkily;

  static public final void main(String[] args) {
    Object x_7 = 'U';
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Hostages<C, G> {
  public boolean wormiest;
  public char beretta;

  public Hostages(boolean wormiest,char beretta) {
    this.wormiest = wormiest;
    this.beretta = beretta;
  }

  public final C abstains() {
    C bonier = (C) null;
    boolean behoove = true;
    wormiest = behoove;
    return bonier;
    
  }
}

final class Vacation<D, E extends Character> {
  public final void bang(Float permeate) {
    Boolean minuting = false;
    D ibuprofen = ((minuting) ?
      (D) null : 
       (D) null);
    D classless = ibuprofen;
    ((Periwigs) null).dialect(52, (byte)14);
    Object x_0 = classless;
    
  }

  public final E phonier() {
    final E forayed = (E) null;
    Main.perils = 63.204;
    return forayed;
    
  }
}

abstract class Periwigs {
  public void dialect(Integer ochre, Byte bess) {
    final Double trowelled = 30.414;
    Object x_1 = trowelled;
    
  }

  public abstract Byte gino(Object seminal) ;
}

abstract class Auden<I, A extends I> extends Periwigs {
  public Vacation<Float, Character> wimpled;

  public Auden(Vacation<Float, Character> wimpled) {
    super();
    this.wimpled = wimpled;
  }

  public final void dialect(Integer ochre, Byte bess) {
    final A englisher = (A) null;
    ((Britten) null).timex(null, -7);
    Object x_2 = englisher;
    
  }

  public abstract A rotating() ;
}

abstract class Britten extends Periwigs {
  public Britten() {
    super();
}

  public abstract void timex(Auden<Long, ? extends Long> fornicate, int defraud) ;
}

abstract class Pimento<N, C> extends Britten {
  public final C badgers;
  public Auden<? super N, N> zara;

  public Pimento(C badgers,Auden<? super N, N> zara) {
    super();
    this.badgers = badgers;
    this.zara = zara;
  }

  public abstract String felting(String coiffure) ;
}

final class Anecdota<L, O extends Number> extends Periwigs {
  public Integer electron;

  public Anecdota(Integer electron) {
    super();
    this.electron = electron;
  }

  public final Periwigs doughier(Long burnished) {
    final Pimento<? super L, O> sawdust = (Pimento<L, O>) null;
    Periwigs crawford = sawdust.zara;
    sawdust.zara = null;
    return crawford;
    
  }

  public Byte gino(Object seminal) {
    final Byte ruckus = (byte)-16;
    return ruckus;
    
  }
}

class Impasses<W extends Long> extends Pimento<Double, Integer> {
  public final Long mongoose;
  public final Impasses<? extends Long> moldiest;

  public Impasses(Long mongoose,Impasses<? extends Long> moldiest) {
    super(-87, (Auden<Double, Double>) null);
    this.mongoose = mongoose;
    this.moldiest = moldiest;
  }

  public String felting(String coiffure) {
    final String squabbled = "footings";
    return squabbled;
    
  }

  public Byte gino(Object seminal) {
    final Byte holidays = (byte)-76;
    return holidays;
    
  }

  public void timex(Auden<Long, ? extends Long> fornicate, int defraud) {
    W automates = (W) null;
    automates = (W) null;
    Object x_3 = automates;
    
  }
}

final class Homeyness extends Pimento<Byte, Boolean> {
  public String[] observes;
  public final Britten telephony;

  public Homeyness(String[] observes,Britten telephony) {
    super(false, (Auden<Byte, Byte>) null);
    this.observes = observes;
    this.telephony = telephony;
  }

  public final Impasses<Long> fondu() {
    return new Impasses<Long>((long)-96, null);
  }

  public void timex(Auden<Long, ? extends Long> fornicate, int defraud) {
    Object x_4 = (Pimento<Double, Periwigs>) null;
    
  }

  public String felting(String coiffure) {
    final String flyby = "applicant";
    Main.perils = 7.495;
    return flyby;
    
  }

  public Byte gino(Object seminal) {
    return (byte)-27;
  }
}

abstract class Gilda extends Auden<Homeyness, Homeyness> {
  public final Homeyness calmness;
  public Vacation<Float, Character> wimpled;

  public Gilda(Homeyness calmness,Vacation<Float, Character> wimpled) {
    super(new Vacation<Float, Character>());
    this.calmness = calmness;
    this.wimpled = wimpled;
  }

  public Homeyness rotating() {
    final Britten yoda = (Britten) null;
    Main.tomato();
    return new Homeyness((String[]) new Object[]{"ranginess"}, yoda);
    
  }
}