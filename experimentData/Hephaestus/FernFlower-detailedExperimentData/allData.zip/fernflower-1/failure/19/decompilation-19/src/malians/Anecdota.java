package src.malians;

final class Anecdota extends Periwigs {
   public Integer electron;

   public Anecdota(Integer var1) {
      this.electron = var1;
   }

   public final Periwigs doughier(Long var1) {
      Pimento var2 = (Pimento)null;
      Auden var3 = var2.zara;
      var2.zara = null;
      return var3;
   }

   public Byte gino(Object var1) {
      Byte var2 = -16;
      return var2;
   }
}
