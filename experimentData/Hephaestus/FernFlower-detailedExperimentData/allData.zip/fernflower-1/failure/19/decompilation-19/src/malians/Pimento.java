package src.malians;

abstract class Pimento extends Britten {
   public final Object badgers;
   public Auden zara;

   public Pimento(Object var1, Auden var2) {
      this.badgers = var1;
      this.zara = var2;
   }

   public abstract String felting(String var1);
}
