package src.malians;

interface Function0 {
   Object apply();
}
