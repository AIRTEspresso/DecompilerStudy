package src.malians;

abstract class Auden extends Periwigs {
   public Vacation wimpled;

   public Auden(Vacation var1) {
      this.wimpled = var1;
   }

   public final void dialect(Integer var1, Byte var2) {
      Object var3 = null;
      ((Britten)null).timex((Auden)null, -7);
   }

   public abstract Object rotating();
}
