package src.malians;

abstract class Britten extends Periwigs {
   public Britten() {
   }

   public abstract void timex(Auden var1, int var2);
}
