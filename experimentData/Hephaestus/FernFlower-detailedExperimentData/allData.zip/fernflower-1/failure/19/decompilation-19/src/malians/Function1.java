package src.malians;

interface Function1 {
   Object apply(Object var1);
}
