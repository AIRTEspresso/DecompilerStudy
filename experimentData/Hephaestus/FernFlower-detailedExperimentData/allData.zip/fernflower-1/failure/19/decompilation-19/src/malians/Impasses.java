package src.malians;

class Impasses extends Pimento {
   public final Long mongoose;
   public final Impasses moldiest;

   public Impasses(Long var1, Impasses var2) {
      super(-87, (Auden)null);
      this.mongoose = var1;
      this.moldiest = var2;
   }

   public String felting(String var1) {
      return "footings";
   }

   public Byte gino(Object var1) {
      Byte var2 = -76;
      return var2;
   }

   public void timex(Auden var1, int var2) {
      Long var3 = (Long)null;
      var3 = (Long)null;
   }
}
