package src.malians;

final class Vacation {
   public final void bang(Float var1) {
      Boolean var2 = false;
      Object var3 = var2 ? null : null;
      ((Periwigs)null).dialect(52, (byte)14);
   }

   public final Character phonier() {
      Character var1 = (Character)null;
      Main.perils = 63.204;
      return var1;
   }
}
