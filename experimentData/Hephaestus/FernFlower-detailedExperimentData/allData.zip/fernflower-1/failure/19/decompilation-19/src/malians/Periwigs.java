package src.malians;

abstract class Periwigs {
   public void dialect(Integer var1, Byte var2) {
      Double var3 = 30.414;
   }

   public abstract Byte gino(Object var1);
}
