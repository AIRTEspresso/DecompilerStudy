package src.malians;

abstract class Gilda extends Auden {
   public final Homeyness calmness;
   public Vacation wimpled;

   public Gilda(Homeyness var1, Vacation var2) {
      super(new Vacation());
      this.calmness = var1;
      this.wimpled = var2;
   }

   public Homeyness rotating() {
      Britten var1 = (Britten)null;
      Main.tomato();
      return new Homeyness((String[])(new Object[]{"ranginess"}), var1);
   }
}
