package src.malians;

final class Hostages {
   public boolean wormiest;
   public char beretta;

   public Hostages(boolean var1, char var2) {
      this.wormiest = var1;
      this.beretta = var2;
   }

   public final Object abstains() {
      Object var1 = null;
      boolean var2 = true;
      this.wormiest = var2;
      return var1;
   }
}
