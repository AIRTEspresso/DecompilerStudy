package src.hunkers;

class Main {
  static public final <F_C> F_C townsman(F_C affray, F_C serial) {
    Francoise<F_C, F_C> swivels = new Francoise<F_C, F_C>((short)36);
    final boolean surtaxed = false;
    final Disputed<F_C, F_C> husking = swivels.reassign(  ((false) ?
  surtaxed : 
   false)).texts;
    swivels =   ((((false) ?
    true : 
     true)) ?
  swivels : 
   ((Scam<F_C, F_C, F_C>) null).updating);
    return husking.bravery();
    
  }

  static public final Francoise<? super Boolean, Boolean> scarves(Francoise<Long, ? super Long> layovers) {
    final short monthly = (short)75;
    final short duality = (short)-35;
    final Francoise<? super Boolean, Boolean> camomile = new Francoise<Boolean, Boolean>(duality);
    return new Wrinkled(  ((true) ?
  new Francoise<Boolean, Boolean>(monthly) : 
   camomile)).fairly;
    
  }

  static public final Double leola() {
    Northward pate = new Francoise<Integer, Integer>((short)88);
    Boolean elysiums = pate.auden;
    final Double reform = -0.629;
    return ((elysiums) ?
      ((false) ?
        reform : 
         -43.94) : 
       ((false) ?
        -29.581 : 
         49.203));
    
  }

  static public final void main(String[] args) {
    Function0<Moldier<Boolean, Character, Integer>> bitchiest = () -> {
      Moldier<Boolean, Character, Integer> adorably = (Moldier<Boolean, Character, Integer>) null;
      final Moldier<Boolean, Character, Integer> wowed = adorably;
      final Moldier<Boolean, Character, Integer> emphasize = new Churchill<Character, Integer, Integer>(wowed, 81).insuring;
      ((Unwisely) null).mooted.texts = new Disputed<Double, Double>();
      return emphasize;
      
    };
    Moldier<Boolean, Character, Integer> blitz = bitchiest.apply();
    Scam<? super Boolean, Byte, ? super Short> garth = blitz.tumbler;
    Object x_5 = garth;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Cryings {
  public final double barbed;
  public final boolean auden;

  public Cryings(double barbed,boolean auden) {
    this.barbed = barbed;
    this.auden = auden;
  }

  public Integer unifies() {
    return -41;
  }

  public String headlined() {
    return "ought";
  }
}

final class Disputed<I, V extends I> extends Cryings {
  public Disputed() {
    super(-76.395, true);
}

  public final I bravery() {
    final I slurpee = (I) null;
    final Ibuprofen<I, V, Float> kelp = (Ibuprofen<I, V, Float>) null;
    final Northward gentility = kelp.anti;
    gentility.demigod((true == true));
    return slurpee;
    
  }
}

abstract class Northward extends Cryings {
  public final boolean auden;
  public short bodices;

  public Northward(boolean auden,short bodices) {
    super(-86.32, false);
    this.auden = auden;
    this.bodices = bodices;
  }

  public void demigod(Boolean stubbiest) {
    Object x_0 = (Northward) null;
    
  }
}

abstract class Ibuprofen<H, R, I extends Float> extends Cryings {
  public final Northward anti;
  public final double barbed;
  public final boolean auden;

  public Ibuprofen(Northward anti,double barbed,boolean auden) {
    super(-45.850, true);
    this.anti = anti;
    this.barbed = barbed;
    this.auden = auden;
  }

  public abstract H mable() ;
}

final class Razzes<G> extends Ibuprofen<Boolean, Long, Float> {
  public Disputed<G, G> texts;
  public final boolean auden;

  public Razzes(Disputed<G, G> texts,boolean auden) {
    super((Northward) null, -28.260, true);
    this.texts = texts;
    this.auden = auden;
  }

  public Boolean mable() {
    Boolean excluded = false;
    final Boolean stoppable = excluded;
    excluded = stoppable;
    return excluded;
    
  }

  public final G tackiness(G tailcoats) {
    final G forearms = (G) null;
    final G ishmael = forearms;
    Function0<Void> disrepute = () -> {
      Disputed<Double, Double> grady = new Disputed<Double, Double>();
      ((Razzes<Double>) null).texts = grady;
      Object x_1 = (G) null;
      return null;
    };
    disrepute.apply();
    return ishmael;
    
  }
}

final class Francoise<B, L extends B> extends Northward {
  public final short rochelle;

  public Francoise(short rochelle) {
    super(true, (short)-15);
    this.rochelle = rochelle;
  }

  public final Razzes<B> reassign(boolean bedazzled) {
    Razzes<B> maritza = reassign(true);
    return maritza;
    
  }

  public final void demigod(Boolean stubbiest) {
    Object x_2 = 'Y';
    
  }
}

abstract class Scam<M, R, C> extends Cryings {
  public Francoise<M, M> updating;
  public final double barbed;
  public final boolean auden;

  public Scam(Francoise<M, M> updating,double barbed,boolean auden) {
    super(42.323, false);
    this.updating = updating;
    this.barbed = barbed;
    this.auden = auden;
  }

  public String headlined() {
    return "liberated";
  }

  public M diced() {
    M excrement = (M) null;
    ((Mirrors) null).peking( '3', -66);
    return excrement;
    
  }
}

abstract class Mirrors extends Northward {
  public short bodices;
  public final Cryings mystery;

  public Mirrors(short bodices,Cryings mystery) {
    super(false, (short)17);
    this.bodices = bodices;
    this.mystery = mystery;
  }

  public void peking(Character diastolic, Integer demurs) {
    final Disputed<Cryings, Cryings> loosen = new Disputed<Cryings, Cryings>();
    final boolean insect = true;
    final Razzes<Cryings> cessation = new Razzes<Cryings>(loosen, insect);
    Object x_3 = cessation;
    
  }

  public void demigod(Boolean stubbiest) {
    bodices = (short)99;
    Object x_4 = (long)22;
    
  }
}

interface Pumas {
  public abstract Cryings carry() ;
}

class Wrinkled implements Pumas {
  public Francoise<? super Boolean, Boolean> fairly;

  public Wrinkled(Francoise<? super Boolean, Boolean> fairly) {
    super();
    this.fairly = fairly;
  }

  public Cryings carry() {
    return fairly;
  }
}

abstract class Moldier<N extends Boolean, Y, S extends Integer> extends Scam<Object, Pumas, Boolean> {
  public Scam<? super Boolean, Byte, ? super Short> tumbler;
  public final double barbed;

  public Moldier(Scam<? super Boolean, Byte, ? super Short> tumbler,double barbed) {
    super(new Francoise<Object, Object>((short)21), 48.103, true);
    this.tumbler = tumbler;
    this.barbed = barbed;
  }

  public Object diced() {
    Object polymers = tumbler.headlined();
    return polymers;
    
  }
}

final class Churchill<V extends Character, P, U extends P> extends Mirrors {
  public final Moldier<Boolean, Character, Integer> insuring;
  public final int valerie;

  public Churchill(Moldier<Boolean, Character, Integer> insuring,int valerie) {
    super((short)10, new Cryings(-29.853, true));
    this.insuring = insuring;
    this.valerie = valerie;
  }

  public final void demigod(Boolean stubbiest) {
    final V funnier = (V) null;
    Object x_6 = funnier;
    
  }

  public final void peking(Character diastolic, Integer demurs) {
    final P jostled = (P) null;
    Object x_7 = jostled;
    
  }
}

abstract class Unwisely implements Pumas {
  public Razzes<Double> mooted;

  public Unwisely(Razzes<Double> mooted) {
    super();
    this.mooted = mooted;
  }

  public Cryings carry() {
    final Cryings adapt = mooted;
    return adapt;
    
  }
}