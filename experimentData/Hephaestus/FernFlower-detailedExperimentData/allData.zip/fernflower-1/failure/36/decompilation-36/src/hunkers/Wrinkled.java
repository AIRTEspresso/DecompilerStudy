package src.hunkers;

class Wrinkled implements Pumas {
   public Francoise fairly;

   public Wrinkled(Francoise var1) {
      this.fairly = var1;
   }

   public Cryings carry() {
      return this.fairly;
   }
}
