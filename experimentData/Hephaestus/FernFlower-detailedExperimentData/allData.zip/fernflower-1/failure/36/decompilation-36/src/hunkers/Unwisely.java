package src.hunkers;

abstract class Unwisely implements Pumas {
   public Razzes mooted;

   public Unwisely(Razzes var1) {
      this.mooted = var1;
   }

   public Cryings carry() {
      Razzes var1 = this.mooted;
      return var1;
   }
}
