package src.hunkers;

abstract class Moldier extends Scam {
   public Scam tumbler;
   public final double barbed;

   public Moldier(Scam var1, double var2) {
      super(new Francoise((short)21), 48.103, true);
      this.tumbler = var1;
      this.barbed = var2;
   }

   public Object diced() {
      String var1 = this.tumbler.headlined();
      return var1;
   }
}
