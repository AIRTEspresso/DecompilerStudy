package src.hunkers;

interface Pumas {
   Cryings carry();
}
