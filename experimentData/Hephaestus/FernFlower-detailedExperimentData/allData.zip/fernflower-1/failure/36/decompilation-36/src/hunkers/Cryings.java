package src.hunkers;

class Cryings {
   public final double barbed;
   public final boolean auden;

   public Cryings(double var1, boolean var3) {
      this.barbed = var1;
      this.auden = var3;
   }

   public Integer unifies() {
      return -41;
   }

   public String headlined() {
      return "ought";
   }
}
