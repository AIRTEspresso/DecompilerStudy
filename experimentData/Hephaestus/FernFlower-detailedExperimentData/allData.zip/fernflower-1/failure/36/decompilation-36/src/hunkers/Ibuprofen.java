package src.hunkers;

abstract class Ibuprofen extends Cryings {
   public final Northward anti;
   public final double barbed;
   public final boolean auden;

   public Ibuprofen(Northward var1, double var2, boolean var4) {
      super(-45.85, true);
      this.anti = var1;
      this.barbed = var2;
      this.auden = var4;
   }

   public abstract Object mable();
}
