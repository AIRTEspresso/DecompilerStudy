package src.hunkers;

class Main {
   public static final Object townsman(Object var0, Object var1) {
      Francoise var2 = new Francoise((short)36);
      Disputed var3 = var2.reassign(false).texts;
      return var3.bravery();
   }

   public static final Francoise scarves(Francoise var0) {
      new Francoise((short)-35);
      return (new Wrinkled(new Francoise((short)75))).fairly;
   }

   public static final Double leola() {
      Francoise var0 = new Francoise((short)88);
      Boolean var1 = var0.auden;
      Double var2 = -0.629;
      return var1 ? -43.94 : 49.203;
   }

   public static final void main(String[] var0) {
      Function0 var1 = () -> {
         Moldier var0 = (Moldier)null;
         Moldier var2 = (new Churchill(var0, 81)).insuring;
         ((Unwisely)null).mooted.texts = new Disputed();
         return var2;
      };
      Moldier var2 = (Moldier)var1.apply();
      Scam var3 = var2.tumbler;
   }
}
