package src.hunkers;

interface Function0 {
   Object apply();
}
