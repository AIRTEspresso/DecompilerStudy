package src.hunkers;

abstract class Northward extends Cryings {
   public final boolean auden;
   public short bodices;

   public Northward(boolean var1, short var2) {
      super(-86.32, false);
      this.auden = var1;
      this.bodices = var2;
   }

   public void demigod(Boolean var1) {
      Northward var2 = (Northward)null;
   }
}
