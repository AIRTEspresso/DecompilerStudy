package src.hunkers;

abstract class Scam extends Cryings {
   public Francoise updating;
   public final double barbed;
   public final boolean auden;

   public Scam(Francoise var1, double var2, boolean var4) {
      super(42.323, false);
      this.updating = var1;
      this.barbed = var2;
      this.auden = var4;
   }

   public String headlined() {
      return "liberated";
   }

   public Object diced() {
      Object var1 = null;
      ((Mirrors)null).peking('3', -66);
      return var1;
   }
}
