package src.hunkers;

final class Disputed extends Cryings {
   public Disputed() {
      super(-76.395, true);
   }

   public final Object bravery() {
      Object var1 = null;
      Ibuprofen var2 = (Ibuprofen)null;
      Northward var3 = var2.anti;
      var3.demigod(true);
      return var1;
   }
}
