package src.hunkers;

abstract class Mirrors extends Northward {
   public short bodices;
   public final Cryings mystery;

   public Mirrors(short var1, Cryings var2) {
      super(false, (short)17);
      this.bodices = var1;
      this.mystery = var2;
   }

   public void peking(Character var1, Integer var2) {
      Disputed var3 = new Disputed();
      Razzes var4 = new Razzes(var3, true);
   }

   public void demigod(Boolean var1) {
      this.bodices = 99;
      Long var2 = 22L;
   }
}
