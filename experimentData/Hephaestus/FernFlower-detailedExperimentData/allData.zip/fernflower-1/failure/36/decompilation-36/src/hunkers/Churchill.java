package src.hunkers;

final class Churchill extends Mirrors {
   public final Moldier insuring;
   public final int valerie;

   public Churchill(Moldier var1, int var2) {
      super((short)10, new Cryings(-29.853, true));
      this.insuring = var1;
      this.valerie = var2;
   }

   public final void demigod(Boolean var1) {
      Character var2 = (Character)null;
   }

   public final void peking(Character var1, Integer var2) {
      Object var3 = null;
   }
}
