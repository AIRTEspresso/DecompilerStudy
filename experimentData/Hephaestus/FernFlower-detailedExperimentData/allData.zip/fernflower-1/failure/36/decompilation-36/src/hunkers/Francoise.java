package src.hunkers;

final class Francoise extends Northward {
   public final short rochelle;

   public Francoise(short var1) {
      super(true, (short)-15);
      this.rochelle = var1;
   }

   public final Razzes reassign(boolean var1) {
      Razzes var2 = this.reassign(true);
      return var2;
   }

   public final void demigod(Boolean var1) {
      Character var2 = 'Y';
   }
}
