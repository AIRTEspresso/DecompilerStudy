package src.hunkers;

final class Razzes extends Ibuprofen {
   public Disputed texts;
   public final boolean auden;

   public Razzes(Disputed var1, boolean var2) {
      super((Northward)null, -28.26, true);
      this.texts = var1;
      this.auden = var2;
   }

   public Boolean mable() {
      Boolean var1 = false;
      return var1;
   }

   public final Object tackiness(Object var1) {
      Object var2 = null;
      Function0 var4 = () -> {
         Disputed var0 = new Disputed();
         ((Razzes)null).texts = var0;
         Object var1 = null;
         return null;
      };
      var4.apply();
      return var2;
   }
}
