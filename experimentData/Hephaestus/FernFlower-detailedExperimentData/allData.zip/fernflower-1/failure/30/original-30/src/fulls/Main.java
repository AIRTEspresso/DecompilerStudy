package src.fulls;

class Main {
  static public final void sheers() {
    final Boolean squirt = true;
    final Twirl<Character> malayalam = ((squirt) ?
  (Levelled<Short, Byte>) null : 
   (Levelled<Short, Byte>) null).basing();
    final Boolean watergate = false;
    ((Blot<Byte, Character>) null).saws = ((Blot<Number, Character>) null).saws;
    malayalam.procedure(  ((watergate) ?
   'f' : 
    'p'), ((Riot<Short>) null).osage("biscay", (short)-32));
    
  }

  static final Blot<? super Byte, ? extends Character> nonrigid = new Blot<Byte, Character>(10.321);

  static final double decors = Main.nonrigid.saws;

  static final double robocalls = Main.decors;

  static final Riot<Epaulet> bar = (Riot<Epaulet>) null;

  static Blot<? extends Short, Character> jives = new Blot<Short, Character>(Main.bar.osage("blithe", null));

  static public final Short bedrolls() {
    Short pique = (short)-82;
    final Short desists = pique;
    Boolean queasily = false;
      ((((queasily) ?
    false : 
     false)) ?
  new Funking<Double>((Riot<Number>) null, 83.262) : 
   new Funking<Double>((Riot<Number>) null, 95.192)).twaddled( 'K');
    return desists;
    
  }

  static byte curlier = ((Epaulet) null).awnings;

  static public final int loyalist() {
    final int prefabbed = -67;
    return prefabbed;
    
  }

  static public final void main(String[] args) {
    Object x_2 = (short)55;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Blot<C, M extends Character> {
  public Double saws;

  public Blot(Double saws) {
    this.saws = saws;
  }

  public final byte clive() {
    Boolean refinance = true;
    Main.sheers();
    return ((refinance) ?
      (byte)50 : 
       (byte)-30);
    
  }
}

class Twirl<S extends Character> {
  public final S hampering;
  public final byte awnings;

  public Twirl(S hampering,byte awnings) {
    this.hampering = hampering;
    this.awnings = awnings;
  }

  public final Blot<? extends String, Character> procedure(S pioneer, double crawled) {
    Blot<? extends String, Character> underacts = (Blot<String, Character>) null;
    return underacts;
    
  }

  public S poppa() {
    return (S) null;
  }
}

interface Levelled<S extends Short, W> {
  public abstract Twirl<Character> basing() ;
}

interface Riot<U> extends Levelled<Short, U> {
  public abstract double osage(String toledo, U jolliest) ;

  public abstract Integer christie() ;
}

abstract class Epaulet extends Twirl<Character> {
  public Epaulet() {
    super( 'E', (byte)-44);
}
}

final class Funking<E> implements Riot<E> {
  public final Riot<? super Number> lobbying;
  public E hush;

  public Funking(Riot<? super Number> lobbying,E hush) {
    super();
    this.lobbying = lobbying;
    this.hush = hush;
  }

  public final void twaddled(char toyoda) {
    Boolean waged = true;
    final Integer slav = 53;
    Integer asymmetry = ((waged) ?
      -74 : 
       slav);
    Object x_0 = asymmetry;
    
  }

  public Integer christie() {
    Integer pokey = 45;
    Integer penknife = pokey;
    return penknife;
    
  }

  public Twirl<Character> basing() {
    final Character broaching = 'v';
    return new Twirl<Character>(broaching, (byte)-51);
    
  }

  public double osage(String toledo, E jolliest) {
    final double downcast = Main.jives.saws;
    Function1<E, Void> typhoon = (income) -> {
      boolean tomboy = false;
      Object x_1 = tomboy;
      return null;
    };
    typhoon.apply((E) null);
    return downcast;
    
  }
}