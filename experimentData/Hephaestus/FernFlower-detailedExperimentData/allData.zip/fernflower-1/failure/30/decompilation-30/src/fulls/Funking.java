package src.fulls;

final class Funking implements Riot {
   public final Riot lobbying;
   public Object hush;

   public Funking(Riot var1, Object var2) {
      this.lobbying = var1;
      this.hush = var2;
   }

   public final void twaddled(char var1) {
      Boolean var2 = true;
      Integer var3 = 53;
      Integer var4 = var2 ? -74 : var3;
   }

   public Integer christie() {
      Integer var1 = 45;
      return var1;
   }

   public Twirl basing() {
      Character var1 = 'v';
      return new Twirl(var1, (byte)-51);
   }

   public double osage(String var1, Object var2) {
      double var3 = Main.jives.saws;
      Function1 var5 = (var0) -> {
         boolean var1 = false;
         Boolean var2 = var1;
         return null;
      };
      var5.apply((Object)null);
      return var3;
   }
}
