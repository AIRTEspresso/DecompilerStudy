package src.fulls;

class Twirl {
   public final Character hampering;
   public final byte awnings;

   public Twirl(Character var1, byte var2) {
      this.hampering = var1;
      this.awnings = var2;
   }

   public final Blot procedure(Character var1, double var2) {
      Blot var4 = (Blot)null;
      return var4;
   }

   public Character poppa() {
      return (Character)null;
   }
}
