package src.fulls;

final class Blot {
   public Double saws;

   public Blot(Double var1) {
      this.saws = var1;
   }

   public final byte clive() {
      Boolean var1 = true;
      Main.sheers();
      return (byte)(var1 ? 50 : -30);
   }
}
