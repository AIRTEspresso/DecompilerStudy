package src.fulls;

interface Riot extends Levelled {
   double osage(String var1, Object var2);

   Integer christie();
}
