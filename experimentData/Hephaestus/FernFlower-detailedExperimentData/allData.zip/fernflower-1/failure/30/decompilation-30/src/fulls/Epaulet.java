package src.fulls;

abstract class Epaulet extends Twirl {
   public Epaulet() {
      super('E', (byte)-44);
   }
}
