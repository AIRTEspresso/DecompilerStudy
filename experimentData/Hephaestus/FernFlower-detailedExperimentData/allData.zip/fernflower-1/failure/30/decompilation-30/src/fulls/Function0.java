package src.fulls;

interface Function0 {
   Object apply();
}
