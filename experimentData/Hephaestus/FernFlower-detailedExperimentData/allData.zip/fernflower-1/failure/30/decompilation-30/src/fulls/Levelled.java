package src.fulls;

interface Levelled {
   Twirl basing();
}
