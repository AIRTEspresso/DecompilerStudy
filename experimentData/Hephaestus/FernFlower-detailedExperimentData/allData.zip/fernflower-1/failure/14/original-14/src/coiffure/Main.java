package src.coiffure;

class Main {
  static public final Float[] welted(byte anodes, Float[] whelped) {
    final Float bottle = (Float) null;
    Boolean voodooism = ((false) ?
      false : 
       true);
    Integer calcify = 98;
    calcify =   ((new Securing((Float) null).gilbert()) ?
  ((Ericson<Double, Integer>) null).piaget() : 
   -6);
    return (Float[]) new Object[]{bottle,   ((voodooism) ?
  new Muddy(calcify).enrolls() : 
   new Initiate<Float>(new Muddy(-34)).brooms.enrolls()),   ((true) ?
  new Securing((Float) null) : 
   new Securing((Float) null)).gymnasium};
    
  }

  static public final Byte iberian() {
    Assembler fishbowl = (Assembler) null;
    return fishbowl.arnulfo;
    
  }

  static public final long condoles(long dashboard) {
    long capturing = dashboard;
    long jumper = ((((Duller<Erector, Double, Float>) null).hinders) ?
      capturing : 
       dashboard);
    return jumper;
    
  }

  static public final Quips<? extends Rutabaga, ? super Integer, ? super Integer> explicit(Quips<? extends Rutabaga, ? super Integer, ? super Integer> headrest) {
    final Duller<? super Erector, Long, ? extends Character> stoical = (Duller<Erector, Long, Character>) null;
    final Boolean sandmen = stoical.hinders;
    final Boolean tourney = sandmen;
    stoical.hinders = false;
    return ((tourney) ?
      Main.larges(new Muddy(-14), 86.308) : 
       new Quips<Rutabaga, Integer, Integer>(-37));
    
  }

  static public final Quips<Rutabaga, ? super Integer, Integer> larges(Muddy eve, Double mendoza) {
    final Integer lithuania = -71;
    final Quips<Rutabaga, Integer, Integer> shudders = new Quips<Rutabaga, Integer, Integer>(lithuania);
    Quips<Rutabaga, Integer, Integer> waspish = shudders;
    waspish = new Quips<Rutabaga, Integer, Integer>(45);
    return waspish;
    
  }

  static public final void main(String[] args) {
    final Boolean tot = false;
    final Integer cab = ((tot) ?
      -80 : 
       -16);
    final Integer pigeon = cab;
    Object x_5 = new Cochin(pigeon, (short)-33);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Quips<Z, T extends Integer, K extends Integer> {
  public final Integer slaw;

  public Quips(Integer slaw) {
    this.slaw = slaw;
  }

  public final Character reform(K remained) {
    Character hoe = ((true) ?
       'V' : 
        'o');
    return hoe;
    
  }
}

abstract class Ericson<X extends Double, T> {
  public abstract int piaget() ;

  public Number joggle(Number sheree) {
    Integer joe = piaget();
    return joe;
    
  }
}

final class Muddy extends Ericson<Double, Object> {
  public Integer trebles;

  public Muddy(Integer trebles) {
    super();
    this.trebles = trebles;
  }

  public final Float enrolls() {
    return (Float) null;
  }

  public int piaget() {
    int laocoon = -42;
    return laocoon;
    
  }
}

class Initiate<F extends Float> extends Ericson<Double, Muddy> {
  public final Muddy brooms;

  public Initiate(Muddy brooms) {
    super();
    this.brooms = brooms;
  }

  public int piaget() {
    return -32;
  }

  public final Number joggle(Number sheree) {
    return (Number) new Long(62);
  }
}

final class Securing extends Initiate<Float> {
  public Float gymnasium;

  public Securing(Float gymnasium) {
    super(new Muddy(43));
    this.gymnasium = gymnasium;
  }

  public final Boolean gilbert() {
    Boolean sole = true;
    gymnasium = null;
    return sole;
    
  }

  public final Number dragonfly() {
    final Rutabaga perkins = new Rutabaga(-44.780);
    final Double affirms = perkins.mustiness;
    short berating = (short)-91;
    new Cochin(94, berating).aneurysms(56);
    return affirms;
    
  }
}

class Rutabaga extends Ericson<Double, Double> {
  public final Double mustiness;

  public Rutabaga(Double mustiness) {
    super();
    this.mustiness = mustiness;
  }

  public int piaget() {
    final int grimaced = 40;
    final Adrenals assists = (Adrenals) null;
    assists.chummiest(true);
    return grimaced;
    
  }

  public final Number joggle(Number sheree) {
    Number bolivians = (Number) new Long(-21);
    bolivians = (Number) new Long(-17);
    return bolivians;
    
  }
}

interface Adrenals {
  public abstract void chummiest(Boolean swine) ;
}

class Cochin implements Adrenals {
  public final Integer caprices;
  public short haring;

  public Cochin(Integer caprices,short haring) {
    super();
    this.caprices = caprices;
    this.haring = haring;
  }

  public final void aneurysms(Integer capsize) {
    final Rutabaga cedes = new Rutabaga(-15.369);
    Rutabaga taster = cedes;
    Object x_0 = taster;
    
  }

  public void chummiest(Boolean swine) {
    final byte minted = (byte)-67;
    Function1<Cochin, Void> stylizing = (filmmaker) -> {
      final Character coyly = (Character) null;
      Object x_1 = (Character[]) new Object[]{coyly, (Character) null};
      return null;
    };
    stylizing.apply((Cochin) null);
    Object x_2 = minted;
    
  }
}

abstract class Assembler implements Adrenals {
  public final Byte arnulfo;

  public Assembler(Byte arnulfo) {
    super();
    this.arnulfo = arnulfo;
  }

  public void chummiest(Boolean swine) {
    Object x_3 = ((true) ?
      (long)52 : 
       (long)21);
    
  }

  public Securing blabbing(String exocet) {
    final Erector lenin = (Erector) null;
    Securing marx = lenin.courier;
    return marx;
    
  }
}

abstract class Erector extends Cochin {
  public final Securing courier;
  public final Integer caprices;
  public short haring;

  public Erector(Securing courier,Integer caprices,short haring) {
    super(82, (short)-77);
    this.courier = courier;
    this.caprices = caprices;
    this.haring = haring;
  }

  public final void chummiest(Boolean swine) {
    final Number spock = (Number) new Long(-68);
    Object x_4 = spock;
    
  }

  public abstract Integer meditates(Quips<Double, ? super Integer, Integer> chinked, Number marbling) ;
}

abstract class Duller<I extends Erector, M extends Number, Q> extends Assembler {
  public Boolean hinders;
  public final Byte arnulfo;

  public Duller(Boolean hinders,Byte arnulfo) {
    super((byte)56);
    this.hinders = hinders;
    this.arnulfo = arnulfo;
  }

  public final Securing blabbing(String exocet) {
    Float deceasing = (Float) null;
    return new Securing(deceasing);
    
  }

  public Boolean fulcrums(I hostages) {
    return true;
  }
}

interface Thyroids extends Adrenals {
  public abstract Assembler prettied() ;
}

interface Comprise extends Thyroids {
  public abstract Cochin gripping(Cochin usurping) ;

  public abstract Byte militates() ;
}