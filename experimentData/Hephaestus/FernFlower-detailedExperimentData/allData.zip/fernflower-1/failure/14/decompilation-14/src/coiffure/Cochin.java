package src.coiffure;

class Cochin implements Adrenals {
   public final Integer caprices;
   public short haring;

   public Cochin(Integer var1, short var2) {
      this.caprices = var1;
      this.haring = var2;
   }

   public final void aneurysms(Integer var1) {
      Rutabaga var2 = new Rutabaga(-15.369);
   }

   public void chummiest(Boolean var1) {
      Function1 var2 = (var0) -> {
         Character var1 = (Character)null;
         Character[] var2 = (Character[])(new Object[]{var1, (Character)null});
         return null;
      };
      var2.apply((Cochin)null);
      Byte var3 = -67;
   }
}
