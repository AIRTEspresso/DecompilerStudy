package src.coiffure;

final class Muddy extends Ericson {
   public Integer trebles;

   public Muddy(Integer var1) {
      this.trebles = var1;
   }

   public final Float enrolls() {
      return (Float)null;
   }

   public int piaget() {
      byte var1 = -42;
      return var1;
   }
}
