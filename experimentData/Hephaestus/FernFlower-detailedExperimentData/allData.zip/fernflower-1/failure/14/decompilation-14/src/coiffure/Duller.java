package src.coiffure;

abstract class Duller extends Assembler {
   public Boolean hinders;
   public final Byte arnulfo;

   public Duller(Boolean var1, Byte var2) {
      super((byte)56);
      this.hinders = var1;
      this.arnulfo = var2;
   }

   public final Securing blabbing(String var1) {
      Float var2 = (Float)null;
      return new Securing(var2);
   }

   public Boolean fulcrums(Erector var1) {
      return true;
   }
}
