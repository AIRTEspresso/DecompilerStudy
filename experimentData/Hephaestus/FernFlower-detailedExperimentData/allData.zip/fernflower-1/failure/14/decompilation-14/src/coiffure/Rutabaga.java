package src.coiffure;

class Rutabaga extends Ericson {
   public final Double mustiness;

   public Rutabaga(Double var1) {
      this.mustiness = var1;
   }

   public int piaget() {
      Adrenals var1 = (Adrenals)null;
      var1.chummiest(true);
      return 40;
   }

   public final Number joggle(Number var1) {
      new Long(-21L);
      Long var2 = new Long(-17L);
      return var2;
   }
}
