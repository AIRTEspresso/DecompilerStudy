package src.coiffure;

abstract class Ericson {
   public abstract int piaget();

   public Number joggle(Number var1) {
      Integer var2 = this.piaget();
      return var2;
   }
}
