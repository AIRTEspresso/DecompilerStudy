package src.coiffure;

abstract class Assembler implements Adrenals {
   public final Byte arnulfo;

   public Assembler(Byte var1) {
      this.arnulfo = var1;
   }

   public void chummiest(Boolean var1) {
      Long var2 = 52L;
   }

   public Securing blabbing(String var1) {
      Erector var2 = (Erector)null;
      Securing var3 = var2.courier;
      return var3;
   }
}
