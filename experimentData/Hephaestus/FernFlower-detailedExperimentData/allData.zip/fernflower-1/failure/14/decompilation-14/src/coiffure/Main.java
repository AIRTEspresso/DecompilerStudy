package src.coiffure;

class Main {
   public static final Float[] welted(byte var0, Float[] var1) {
      Float var2 = (Float)null;
      Boolean var3 = true;
      Integer var4 = 98;
      var4 = (new Securing((Float)null)).gilbert() ? ((Ericson)null).piaget() : -6;
      return (Float[])(new Object[]{var2, var3 ? (new Muddy(var4)).enrolls() : (new Initiate(new Muddy(-34))).brooms.enrolls(), (new Securing((Float)null)).gymnasium});
   }

   public static final Byte iberian() {
      Assembler var0 = (Assembler)null;
      return var0.arnulfo;
   }

   public static final long condoles(long var0) {
      long var4 = ((Duller)null).hinders ? var0 : var0;
      return var4;
   }

   public static final Quips explicit(Quips var0) {
      Duller var1 = (Duller)null;
      Boolean var2 = var1.hinders;
      var1.hinders = false;
      return var2 ? larges(new Muddy(-14), 86.308) : new Quips(-37);
   }

   public static final Quips larges(Muddy var0, Double var1) {
      Integer var2 = -71;
      Quips var3 = new Quips(var2);
      Quips var4 = new Quips(45);
      return var4;
   }

   public static final void main(String[] var0) {
      Boolean var1 = false;
      Integer var2 = var1 ? -80 : -16;
      new Cochin(var2, (short)-33);
   }
}
