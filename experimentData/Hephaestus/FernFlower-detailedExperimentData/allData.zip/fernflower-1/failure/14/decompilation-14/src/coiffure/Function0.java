package src.coiffure;

interface Function0 {
   Object apply();
}
