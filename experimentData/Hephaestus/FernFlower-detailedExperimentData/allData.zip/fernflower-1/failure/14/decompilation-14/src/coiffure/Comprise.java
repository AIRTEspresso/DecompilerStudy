package src.coiffure;

interface Comprise extends Thyroids {
   Cochin gripping(Cochin var1);

   Byte militates();
}
