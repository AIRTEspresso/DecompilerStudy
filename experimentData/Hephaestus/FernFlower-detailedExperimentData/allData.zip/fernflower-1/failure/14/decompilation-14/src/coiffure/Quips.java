package src.coiffure;

final class Quips {
   public final Integer slaw;

   public Quips(Integer var1) {
      this.slaw = var1;
   }

   public final Character reform(Integer var1) {
      Character var2 = 'V';
      return var2;
   }
}
