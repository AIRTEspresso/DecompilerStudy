package src.coiffure;

interface Adrenals {
   void chummiest(Boolean var1);
}
