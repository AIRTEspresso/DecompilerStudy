package src.coiffure;

abstract class Erector extends Cochin {
   public final Securing courier;
   public final Integer caprices;
   public short haring;

   public Erector(Securing var1, Integer var2, short var3) {
      super(82, (short)-77);
      this.courier = var1;
      this.caprices = var2;
      this.haring = var3;
   }

   public final void chummiest(Boolean var1) {
      Long var2 = new Long(-68L);
   }

   public abstract Integer meditates(Quips var1, Number var2);
}
