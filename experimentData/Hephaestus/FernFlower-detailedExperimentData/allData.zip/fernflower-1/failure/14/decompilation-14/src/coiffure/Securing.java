package src.coiffure;

final class Securing extends Initiate {
   public Float gymnasium;

   public Securing(Float var1) {
      super(new Muddy(43));
      this.gymnasium = var1;
   }

   public final Boolean gilbert() {
      Boolean var1 = true;
      this.gymnasium = null;
      return var1;
   }

   public final Number dragonfly() {
      Rutabaga var1 = new Rutabaga(-44.78);
      Double var2 = var1.mustiness;
      byte var3 = -91;
      (new Cochin(94, var3)).aneurysms(56);
      return var2;
   }
}
