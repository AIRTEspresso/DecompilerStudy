package src.coiffure;

class Initiate extends Ericson {
   public final Muddy brooms;

   public Initiate(Muddy var1) {
      this.brooms = var1;
   }

   public int piaget() {
      return -32;
   }

   public final Number joggle(Number var1) {
      return new Long(62L);
   }
}
