package src.coiffure;

interface Thyroids extends Adrenals {
   Assembler prettied();
}
