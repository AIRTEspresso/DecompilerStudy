package src.coiffure;

interface Function1 {
   Object apply(Object var1);
}
