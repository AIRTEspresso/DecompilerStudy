class Demo {
    static final int i1 = -55;

    static final Boolean b1 = false;

    static final boolean b2 = b1;
}
