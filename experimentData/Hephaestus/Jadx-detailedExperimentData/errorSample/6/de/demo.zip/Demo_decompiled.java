package defpackage;
/* renamed from: Demo  reason: default package */
/* loaded from: /home/xiayi/Mine/workspace/gradup/statistic/demo/jadx/6/de/classes.dex */
class Demo {
    static final Boolean b1;
    static final boolean b2;
    static final int i1 = -55;

    Demo() {
    }

    static {
        Boolean valueOf = Boolean.valueOf((boolean) b2);
        b1 = valueOf;
        b2 = valueOf.booleanValue();
    }
}
