package defpackage;
/* renamed from: Demo  reason: default package */
/* loaded from: /home/xiayi/Mine/workspace/gradup/statistic/demo/jadx/9/de/classes.dex */
class Demo<I> {
    public static final T1<Float> t1 = new T1<>();

    Demo() {
    }

    public final void foo() {
        t1.i = (I) Float.valueOf(-92.333f);
    }
}
