package defpackage;
/* compiled from: Demo.java */
/* renamed from: T1  reason: default package */
/* loaded from: /home/xiayi/Mine/workspace/gradup/statistic/demo/jadx/9/de/classes.dex */
class T1<I> {
    public I i;
}
