package defpackage;
/* compiled from: Demo.java */
/* renamed from: I1  reason: default package */
/* loaded from: /home/xiayi/Mine/workspace/gradup/statistic/demo/jadx/10/de/classes.dex */
interface I1 {
    Void apply();
}
