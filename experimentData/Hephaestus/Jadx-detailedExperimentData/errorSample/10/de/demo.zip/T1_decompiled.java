package defpackage;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Demo.java */
/* renamed from: T1  reason: default package */
/* loaded from: /home/xiayi/Mine/workspace/gradup/statistic/demo/jadx/10/de/classes.dex */
public class T1 {
    public Integer i;
}
