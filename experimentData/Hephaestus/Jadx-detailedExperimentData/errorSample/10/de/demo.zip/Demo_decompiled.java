package defpackage;
/* renamed from: Demo  reason: default package */
/* loaded from: /home/xiayi/Mine/workspace/gradup/statistic/demo/jadx/10/de/classes.dex */
class Demo {
    Demo() {
    }

    public void adjusted() {
        final T1 t1 = new T1();
        new I1() { // from class: -$$Lambda$Demo$RotJOYQIGB1iyfHIOKg8TYJP97Q
            @Override // defpackage.I1
            public final Void apply() {
                return Demo.lambda$adjusted$0(T1.this);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$adjusted$0(T1 t1) {
        Integer num = t1.i;
        return null;
    }
}
