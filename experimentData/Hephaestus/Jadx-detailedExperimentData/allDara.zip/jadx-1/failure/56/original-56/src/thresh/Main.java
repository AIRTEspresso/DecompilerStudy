package src.thresh;

class Main {
  static public final Integer smoulders(Integer mummified) {
    return mummified;
  }

  static Double[] peskiest = (Double[]) new Object[]{(Double) null, (Double) null, (Double) null};

  static final Double[] redeemed = ((true) ?
  (Double[]) new Object[]{(Double) null, (Double) null, (Double) null} : 
   Main.peskiest);

  static final Jauntily<Short, Integer> columbine = (Jauntily<Short, Integer>) null;

  static Jauntily<Short, Integer> clarioned = Main.columbine;

  static final Haymows mills = ((true) ?
  Main.columbine : 
   Main.clarioned).namely;

  static public final Melded tacitly() {
    final Boolean ashrams = true;
    Melded communion = (Melded) null;
    final Melded corralled = communion;
    Main.peskiest = null;
      return ((ashrams) ?
  new Blush(corralled) : 
   new Blush((Melded) null)).caudal;
    
  }

  static public final void senility(Blush friskily) {
    Object poisoning = new Object();
    Object x_3 = new Sammie(poisoning);
    
  }

  static public final void main(String[] args) {
    new Blush((Melded) null).gloved(((Maraca<Long, Long>) null).lenders().braddock);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Sammie {
  public final Object euros;

  public Sammie(Object euros) {
    this.euros = euros;
  }
}

interface Haymows {
  public abstract Float puff(int obsession, int shorthorn) ;
}

interface Marchers<V, W extends Sammie, I> extends Haymows {
  public abstract long caper(long relocate, Integer shoots) ;

  public abstract I gloved(I bearskins) ;
}

abstract class Jauntily<H extends Object, C> implements Haymows {
  public Haymows namely;

  public Jauntily(Haymows namely) {
    super();
    this.namely = namely;
  }

  public abstract C moldiest(H cob) ;

  public abstract <F_K> Short assam(C hosteling, F_K architect) ;
}

interface Kingship extends Marchers<Short, Sammie, Short> {
  public abstract int suctioned(Number spirit, double garlands) ;
}

abstract class Melded implements Marchers<Melded, Sammie, Kingship> {
  public long caper(long relocate, Integer shoots) {
    return (long)29;
  }
}

final class Blush implements Kingship {
  public Melded caudal;

  public Blush(Melded caudal) {
    super();
    this.caudal = caudal;
  }

  public int suctioned(Number spirit, double garlands) {
    final int quoited = Main.smoulders(-58);
    Main.peskiest = null;
    return quoited;
    
  }

  public long caper(long relocate, Integer shoots) {
    Integer yammered = 9;
    Function0<Void> armchair = () -> {
      Character gooier = 'B';
      Blush jahangir = (Blush) null;
      final Melded jensen = (Melded) null;
      jahangir.caudal = jensen;
      Object x_0 = gooier;
      return null;
    };
    armchair.apply();
    return caper((long)73, yammered);
    
  }

  public Short gloved(Short bearskins) {
    return gloved((short)63);
  }

  public Float puff(int obsession, int shorthorn) {
    final int sari = -36;
    final Float dactylic = puff(sari, 26);
    Main.columbine.namely = Main.tacitly();
    return dactylic;
    
  }
}

final class Fighter<I, L, G extends L> extends Jauntily<Object, G> {
  public Character sordid;

  public Fighter(Character sordid) {
    super(new Blush((Melded) null));
    this.sordid = sordid;
  }

  public G moldiest(Object cob) {
    Hacksaw<G, L> typesets = new Hacksaw<G, L>();
    final Hacksaw<G, L> fellest = typesets;
    Hacksaw<G, L> pamphlets = ((true) ?
      fellest : 
       new Hacksaw<G, L>());
      ((true) ?
  new Piggies<Pimplier<Short, Boolean, Character>, I, L>(new Pimplier<Short, Boolean, Character>(new Blush((Melded) null),  'X')) : 
   new Piggies<Pimplier<Short, Boolean, Character>, I, L>(new Pimplier<Short, Boolean, Character>(new Blush((Melded) null),  '4'))).decrepit().grimaced((byte)2);
    return pamphlets.chad((L) null, (L) null).colors;
    
  }

  public Float puff(int obsession, int shorthorn) {
    return (float)-64.592;
  }

  public <F_K> Short assam(G hosteling, F_K architect) {
    final Short cleats = (short)-69;
    Blush jacob = new Blush((Melded) null);
    Aboard dotting = new Aboard((Fighter<Float, Byte, Byte>) null, jacob.caper((long)-100, 15));
    new Darnell(dotting.overpaid()).gulags((byte)-80, null);
    return cleats;
    
  }
}

abstract class Stated<V, K, U> implements Haymows {
  public final V colors;
  public final V subtlest;

  public Stated(V colors,V subtlest) {
    super();
    this.colors = colors;
    this.subtlest = subtlest;
  }

  public Float puff(int obsession, int shorthorn) {
    return (float)50.543;
  }
}

final class Hacksaw<M, G> extends Stated<M, M, M> {
  public Hacksaw() {
    super((M) null, (M) null);
}

  public final Stated<M, ? extends M, G> chad(G bitterest, G portable) {
    final Stated<M, ? extends M, G> blandest = (Stated<M, M, G>) null;
    return blandest;
    
  }

  public final Float puff(int obsession, int shorthorn) {
    Float beguiling = (float)46.734;
    return beguiling;
    
  }
}

final class Pimplier<Z, N, H> implements Haymows {
  public final Blush thieving;
  public final H winged;

  public Pimplier(Blush thieving,H winged) {
    super();
    this.thieving = thieving;
    this.winged = winged;
  }

  public final void grimaced(H cavities) {
    final H dignified = (H) null;
    thieving.caudal = thieving.caudal;
    Object x_1 = dignified;
    
  }

  public Float puff(int obsession, int shorthorn) {
    final Float situation = (float)-32.867;
    final Partied<Double> roommates = (Partied<Double>) null;
    final char strikings = 'I';
    roommates.colorful(true).nowhere(strikings, new Blush((Melded) null));
    return situation;
    
  }
}

final class Milder<Q extends Jauntily<Number, Haymows>> implements Haymows {
  public final Q woodshed;

  public Milder(Q woodshed) {
    super();
    this.woodshed = woodshed;
  }

  public final void nowhere(char coasters, Blush primarily) {
    Q crazes = (Q) null;
    Object x_2 = crazes;
    
  }

  public Float puff(int obsession, int shorthorn) {
    Float obligate = (float)-68.166;
    Melded isthmi = (Melded) null;
    Blush hourly = new Blush(isthmi);
    woodshed.namely = new Pimplier<Q, Q, Q>(hourly, (Q) null);
    return obligate;
    
  }
}

interface Partied<P extends Double> extends Haymows {
  public abstract Milder<Jauntily<Number, Haymows>> colorful(boolean stow) ;
}

class Piggies<M extends Pimplier<Short, Boolean, ? super Character>, V, O> implements Haymows {
  public final M scenting;

  public Piggies(M scenting) {
    super();
    this.scenting = scenting;
  }

  public final Pimplier<Float, Short, Byte> decrepit() {
    final Boolean teams = false;
    final Byte raffish = (byte)58;
    final Pimplier<Float, Short, Byte> debbie = new Pimplier<Float, Short, Byte>(new Blush((Melded) null), raffish);
    Main.senility(new Blush((Melded) null));
    return ((teams) ?
      debbie : 
       new Pimplier<Float, Short, Byte>(new Blush((Melded) null), (byte)-88));
    
  }

  public Float puff(int obsession, int shorthorn) {
    return (float)99.968;
  }
}

final class Darnell implements Partied<Double> {
  public Double entertain;

  public Darnell(Double entertain) {
    super();
    this.entertain = entertain;
  }

  public final void gulags(Byte galoshes, Hacksaw<? super Integer, ? extends Double> latiner) {
    Object x_4 = new Milder<Jauntily<Number, Haymows>>((Jauntily<Number, Haymows>) null);
    
  }

  public Milder<Jauntily<Number, Haymows>> colorful(boolean stow) {
    final Jauntily<Number, Haymows> sugary = (Jauntily<Number, Haymows>) null;
    final Milder<Jauntily<Number, Haymows>> intones = new Milder<Jauntily<Number, Haymows>>(sugary);
    final Melded fictions = (Melded) null;
    return new Scrounged(intones, new Piggies<Pimplier<Short, Boolean, Character>, Short, Long>(new Pimplier<Short, Boolean, Character>(new Blush(fictions),  'E'))).yessed;
    
  }

  public Float puff(int obsession, int shorthorn) {
    return (float)13.739;
  }
}

final class Scrounged extends Sammie {
  public Milder<Jauntily<Number, Haymows>> yessed;
  public Piggies<? super Pimplier<Short, Boolean, Character>, ? super Short, Long> foretold;

  public Scrounged(Milder<Jauntily<Number, Haymows>> yessed,Piggies<? super Pimplier<Short, Boolean, Character>, ? super Short, Long> foretold) {
    super(new Object());
    this.yessed = yessed;
    this.foretold = foretold;
  }
}

class Aboard extends Jauntily<Character, Object> {
  public Fighter<? super Float, ? extends Byte, ? extends Byte> script;
  public Long modular;

  public Aboard(Fighter<? super Float, ? extends Byte, ? extends Byte> script,Long modular) {
    super(new Blush((Melded) null));
    this.script = script;
    this.modular = modular;
  }

  public Double overpaid() {
    return -64.882;
  }

  public Object moldiest(Character cob) {
    final Melded[] blades = (Melded[]) new Object[]{(Melded) null};
    modular = (long)43;
    return blades;
    
  }

  public Float puff(int obsession, int shorthorn) {
    Float sheila = (float)-84.697;
    return sheila;
    
  }

  public <F_K> Short assam(Object hosteling, F_K architect) {
    final Short genaro = (short)-99;
    return genaro;
    
  }
}

abstract class Anarchy<Q extends Character, H extends Stated<? extends Integer, ? super Kingship, Melded>, Z extends Double> extends Jauntily<Object, Q> {
  public final Short braddock;
  public byte unmissed;

  public Anarchy(Short braddock,byte unmissed) {
    super(new Piggies<Pimplier<Short, Boolean, Character>, Float, Character>(new Pimplier<Short, Boolean, Character>(new Blush((Melded) null), 'P')));
    this.braddock = braddock;
    this.unmissed = unmissed;
  }

  public Q moldiest(Object cob) {
    final Q fishers = (Q) null;
    return fishers;
    
  }

  public <F_K> Short assam(Q hosteling, F_K architect) {
    return (short)-74;
  }
}

interface Maraca<U, V extends U> extends Marchers<U, Sammie, V> {
  public abstract Anarchy<Character, Stated<Integer, Kingship, Melded>, Double> lenders() ;
}