package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
interface Maraca<U, V extends U> extends Marchers<U, Sammie, V> {
    Anarchy<Character, Stated<Integer, Kingship, Melded>, Double> lenders();
}
