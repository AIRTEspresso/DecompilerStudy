package src.thresh;

import src.thresh.Sammie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
interface Marchers<V, W extends Sammie, I> extends Haymows {
    long caper(long j, Integer num);

    I gloved(I i);
}
