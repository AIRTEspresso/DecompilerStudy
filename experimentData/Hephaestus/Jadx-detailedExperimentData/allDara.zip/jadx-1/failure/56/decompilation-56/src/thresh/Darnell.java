package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
final class Darnell implements Partied<Double> {
    public Double entertain;

    public Darnell(Double d) {
        this.entertain = d;
    }

    public final void gulags(Byte b, Hacksaw<? super Integer, ? extends Double> hacksaw) {
        new Milder(null);
    }

    @Override // src.thresh.Partied
    public Milder<Jauntily<Number, Haymows>> colorful(boolean z) {
        return new Scrounged(new Milder(null), new Piggies(new Pimplier(new Blush(null), 'E'))).yessed;
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        return Float.valueOf(13.739f);
    }
}
