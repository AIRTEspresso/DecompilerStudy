package src.thresh;

import src.thresh.Pimplier;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
class Piggies<M extends Pimplier<Short, Boolean, ? super Character>, V, O> implements Haymows {
    public final M scenting;

    public Piggies(M m) {
        this.scenting = m;
    }

    public final Pimplier<Float, Short, Byte> decrepit() {
        Boolean bool = false;
        Melded melded = null;
        Pimplier<Float, Short, Byte> pimplier = new Pimplier<>(new Blush(melded), (byte) 58);
        Main.senility(new Blush(melded));
        if (bool.booleanValue()) {
            return pimplier;
        }
        return new Pimplier<>(new Blush(melded), (byte) -88);
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        return Float.valueOf(99.968f);
    }
}
