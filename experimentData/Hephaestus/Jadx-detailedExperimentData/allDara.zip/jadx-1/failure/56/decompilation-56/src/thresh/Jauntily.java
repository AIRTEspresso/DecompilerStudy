package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
abstract class Jauntily<H, C> implements Haymows {
    public Haymows namely;

    public abstract <F_K> Short assam(C c, F_K f_k);

    public abstract C moldiest(H h);

    public Jauntily(Haymows haymows) {
        this.namely = haymows;
    }
}
