package src.thresh;

import src.thresh.Jauntily;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
final class Milder<Q extends Jauntily<Number, Haymows>> implements Haymows {
    public final Q woodshed;

    public Milder(Q q) {
        this.woodshed = q;
    }

    public final void nowhere(char c, Blush blush) {
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        Float valueOf = Float.valueOf(-68.166f);
        Blush blush = new Blush(null);
        this.woodshed.namely = new Pimplier(blush, null);
        return valueOf;
    }
}
