package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
final class Pimplier<Z, N, H> implements Haymows {
    public final Blush thieving;
    public final H winged;

    public Pimplier(Blush blush, H h) {
        this.thieving = blush;
        this.winged = h;
    }

    public final void grimaced(H h) {
        Blush blush = this.thieving;
        blush.caudal = blush.caudal;
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        Float valueOf = Float.valueOf(-32.867f);
        Partied partied = null;
        partied.colorful(true).nowhere('I', new Blush(null));
        return valueOf;
    }
}
