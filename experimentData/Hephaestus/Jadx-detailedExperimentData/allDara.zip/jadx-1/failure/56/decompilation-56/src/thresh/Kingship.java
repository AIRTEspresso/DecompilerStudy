package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
interface Kingship extends Marchers<Short, Sammie, Short> {
    int suctioned(Number number, double d);
}
