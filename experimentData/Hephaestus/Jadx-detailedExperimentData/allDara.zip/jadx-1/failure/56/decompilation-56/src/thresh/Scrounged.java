package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
final class Scrounged extends Sammie {
    public Piggies<? super Pimplier<Short, Boolean, Character>, ? super Short, Long> foretold;
    public Milder<Jauntily<Number, Haymows>> yessed;

    public Scrounged(Milder<Jauntily<Number, Haymows>> milder, Piggies<? super Pimplier<Short, Boolean, Character>, ? super Short, Long> piggies) {
        super(new Object());
        this.yessed = milder;
        this.foretold = piggies;
    }
}
