package src.thresh;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
public class Main {
    static Jauntily<Short, Integer> clarioned;
    static final Jauntily<Short, Integer> columbine;
    static final Haymows mills;
    static Double[] peskiest;
    static final Double[] redeemed;

    Main() {
    }

    public static final Integer smoulders(Integer num) {
        return num;
    }

    static {
        Double d = null;
        peskiest = (Double[]) new Object[]{d, d, d};
        redeemed = (Double[]) new Object[]{d, d, d};
        Jauntily<Short, Integer> jauntily = null;
        columbine = jauntily;
        clarioned = jauntily;
        mills = jauntily.namely;
    }

    public static final Melded tacitly() {
        Blush blush;
        Boolean bool = true;
        Melded melded = null;
        peskiest = null;
        if (bool.booleanValue()) {
            blush = new Blush(melded);
        } else {
            blush = new Blush(melded);
        }
        return blush.caudal;
    }

    public static final void senility(Blush blush) {
        new Sammie(new Object());
    }

    public static final void main(String[] strArr) {
        Maraca maraca = null;
        new Blush(null).gloved(maraca.lenders().braddock);
    }
}
