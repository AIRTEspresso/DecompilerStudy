package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
abstract class Stated<V, K, U> implements Haymows {
    public final V colors;
    public final V subtlest;

    public Stated(V v, V v2) {
        this.colors = v;
        this.subtlest = v2;
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        return Float.valueOf(50.543f);
    }
}
