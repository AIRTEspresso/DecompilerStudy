package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
class Aboard extends Jauntily<Character, Object> {
    public Long modular;
    public Fighter<? super Float, ? extends Byte, ? extends Byte> script;

    public Aboard(Fighter<? super Float, ? extends Byte, ? extends Byte> fighter, Long l) {
        super(new Blush(null));
        this.script = fighter;
        this.modular = l;
    }

    public Double overpaid() {
        return Double.valueOf(-64.882d);
    }

    @Override // src.thresh.Jauntily
    public Object moldiest(Character ch) {
        Melded[] meldedArr = (Melded[]) new Object[]{null};
        this.modular = 43L;
        return meldedArr;
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        return Float.valueOf(-84.697f);
    }

    @Override // src.thresh.Jauntily
    public <F_K> Short assam(Object obj, F_K f_k) {
        return (short) -99;
    }
}
