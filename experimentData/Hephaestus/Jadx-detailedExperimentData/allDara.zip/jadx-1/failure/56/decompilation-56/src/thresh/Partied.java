package src.thresh;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
interface Partied<P extends Double> extends Haymows {
    Milder<Jauntily<Number, Haymows>> colorful(boolean z);
}
