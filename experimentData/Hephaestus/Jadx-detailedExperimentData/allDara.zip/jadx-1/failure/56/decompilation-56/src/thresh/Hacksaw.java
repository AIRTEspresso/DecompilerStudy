package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
final class Hacksaw<M, G> extends Stated<M, M, M> {
    public Hacksaw() {
        super(null, null);
    }

    public final Stated<M, ? extends M, G> chad(G g, G g2) {
        return null;
    }

    @Override // src.thresh.Stated, src.thresh.Haymows
    public final Float puff(int i, int i2) {
        return Float.valueOf(46.734f);
    }
}
