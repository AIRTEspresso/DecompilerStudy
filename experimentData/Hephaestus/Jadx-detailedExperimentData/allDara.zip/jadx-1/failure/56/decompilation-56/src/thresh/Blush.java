package src.thresh;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
public final class Blush implements Kingship {
    public Melded caudal;

    public Blush(Melded melded) {
        this.caudal = melded;
    }

    @Override // src.thresh.Kingship
    public int suctioned(Number number, double d) {
        int intValue = Main.smoulders(-58).intValue();
        Main.peskiest = null;
        return intValue;
    }

    @Override // src.thresh.Marchers
    public long caper(long j, Integer num) {
        new Function0() { // from class: src.thresh.-$$Lambda$Blush$SK3w0-r5kwTEwmT-fgYSKVeS3DQ
            @Override // src.thresh.Function0
            public final Object apply() {
                return Blush.lambda$caper$0();
            }
        }.apply();
        return caper(73L, 9);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$caper$0() {
        Character.valueOf('B');
        Blush blush = null;
        blush.caudal = null;
        return null;
    }

    @Override // src.thresh.Marchers
    public Short gloved(Short sh) {
        return gloved((Short) 63);
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        Float puff = puff(-36, 26);
        Main.columbine.namely = Main.tacitly();
        return puff;
    }
}
