package src.thresh;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
public abstract class Melded implements Marchers<Melded, Sammie, Kingship> {
    Melded() {
    }

    @Override // src.thresh.Marchers
    public long caper(long j, Integer num) {
        return 29L;
    }
}
