package src.thresh;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
public final class Fighter<I, L, G extends L> extends Jauntily<Object, G> {
    public Character sordid;

    public Fighter(Character ch) {
        super(new Blush(null));
        this.sordid = ch;
    }

    @Override // src.thresh.Jauntily
    public G moldiest(Object obj) {
        Hacksaw hacksaw = new Hacksaw();
        new Piggies(new Pimplier(new Blush(null), 'X')).decrepit().grimaced((byte) 2);
        return (G) hacksaw.chad(null, null).colors;
    }

    @Override // src.thresh.Haymows
    public Float puff(int i, int i2) {
        return Float.valueOf(-64.592f);
    }

    @Override // src.thresh.Jauntily
    public <F_K> Short assam(G g, F_K f_k) {
        new Darnell(new Aboard(null, Long.valueOf(new Blush(null).caper(-100L, 15))).overpaid()).gulags((byte) -80, null);
        return (short) -69;
    }
}
