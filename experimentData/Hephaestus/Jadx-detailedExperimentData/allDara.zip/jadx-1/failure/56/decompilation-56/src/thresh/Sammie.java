package src.thresh;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
class Sammie {
    public final Object euros;

    public Sammie(Object obj) {
        this.euros = obj;
    }
}
