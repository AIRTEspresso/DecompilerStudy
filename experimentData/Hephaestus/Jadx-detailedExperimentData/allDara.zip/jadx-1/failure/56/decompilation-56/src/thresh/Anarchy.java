package src.thresh;

import java.lang.Character;
import java.lang.Double;
import src.thresh.Stated;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/56/original-56/Test.dex */
abstract class Anarchy<Q extends Character, H extends Stated<? extends Integer, ? super Kingship, Melded>, Z extends Double> extends Jauntily<Object, Q> {
    public final Short braddock;
    public byte unmissed;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // src.thresh.Jauntily
    public /* bridge */ /* synthetic */ Short assam(Object obj, Object obj2) {
        return assam((Anarchy<Q, H, Z>) ((Character) obj), (Character) obj2);
    }

    public Anarchy(Short sh, byte b) {
        super(new Piggies(new Pimplier(new Blush(null), 'P')));
        this.braddock = sh;
        this.unmissed = b;
    }

    @Override // src.thresh.Jauntily
    public Q moldiest(Object obj) {
        return null;
    }

    public <F_K> Short assam(Q q, F_K f_k) {
        return (short) -74;
    }
}
