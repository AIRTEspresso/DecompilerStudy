package src.rejoinder;

class Main {
  static Sopping<Byte> squads = (Sopping<Byte>) null;

  static int catered = Main.squads.sweeper;

  static public final char cymbeline() {
    char awaking = Main.cymbeline();
    Main.catered = Main.catered;
    return awaking;
    
  }

  static public final double bernstein(double corsair) {
    return -50.455;
  }

  static Boolean rattles = true;

  static final Sopping<Object> exponent = ((Bouffant) null).ringing(  ((Main.rattles) ?
   'i' : 
    'H'));

  static Sopping<? super Integer> periods = Main.exponent;

  static final char reveal = ((false) ?
  ((Thorax<Double>) null).ruffed : 
   ((Thorax<Double>) null).ruffed);

  static public final Float denuded(int jets) {
    final Float derides = ((Biassing) null).downsized;
    Boolean braddock = true;
    final double isiah = -43.638;
    ((Synch<Long, Short, Float>) null).inventing(  ((braddock) ?
  -80.558 : 
   isiah), Main.denuded(Main.periods.sweeper));
    return derides;
    
  }

  static final Number bluntly = Main.denuded(Main.catered);

  static public final void main(String[] args) {
    Object x_0 = new Politicos(-78);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Sopping<P> {
  public final int sweeper;
  public P bullish;

  public Sopping(int sweeper,P bullish) {
    this.sweeper = sweeper;
    this.bullish = bullish;
  }

  public abstract Byte influenza(Short binge, P disarms) ;
}

final class Earldoms extends Sopping<Short> {
  public Short bullish;
  public double strollers;

  public Earldoms(Short bullish,double strollers) {
    super(76, (short)-51);
    this.bullish = bullish;
    this.strollers = strollers;
  }

  public Byte influenza(Short binge, Short disarms) {
    Byte sampson = (byte)-74;
    return sampson;
    
  }
}

interface Bouffant {
  public abstract Sopping<Object> ringing(char virtue) ;
}

abstract class Thorax<H> implements Bouffant {
  public final char ruffed;

  public Thorax(char ruffed) {
    super();
    this.ruffed = ruffed;
  }

  public Sopping<Object> ringing(char virtue) {
    Sopping<Object> third = (Sopping<Object>) null;
    return third;
    
  }
}

final class Politicos extends Sopping<Boolean> {
  public final int sweeper;

  public Politicos(int sweeper) {
    super(25, false);
    this.sweeper = sweeper;
  }

  public Byte influenza(Short binge, Boolean disarms) {
    Function2<String, Long, Short> midgets = (cabals, japed) -> {
      return (short)74;
    };
    Apia<Bouffant, Number, Bouffant> inca = (Apia<Bouffant, Number, Bouffant>) null;
    String roof = "dustiness";
    final Short maligns = midgets.apply(  ((true) ?
  "sucre" : 
   "consigns"), new Salvoes(inca, roof).crankier.dourly(false, inca));
    return Main.periods.influenza(maligns, null);
    
  }

  public final Bouffant blanker(Bouffant guile) {
    Apia<Bouffant, Number, Bouffant> legion = (Apia<Bouffant, Number, Bouffant>) null;
    String tinning = "potpies";
    final Apia<Bouffant, Number, Bouffant> driest = new Salvoes(legion, tinning).crankier;
    Main.exponent.bullish = -15;
    return new Salvoes(driest, "halibut");
    
  }
}

interface Apia<B, W, M extends B> extends Bouffant {
  public abstract long dourly(boolean collating, B patching) ;

  public abstract W everglade() ;
}

class Salvoes implements Bouffant {
  public Apia<Bouffant, Number, Bouffant> crankier;
  public String reviewer;

  public Salvoes(Apia<Bouffant, Number, Bouffant> crankier,String reviewer) {
    super();
    this.crankier = crankier;
    this.reviewer = reviewer;
  }

  public Sopping<Object> ringing(char virtue) {
    Sopping<Object> toss = Main.exponent;
    int mazzini = 39;
    Main.catered = mazzini;
    return toss;
    
  }

  public long rollicks(long decease, boolean usurers) {
    return (long)-44;
  }
}

class Hernias extends Salvoes {
  public Apia<Bouffant, Number, Bouffant> crankier;

  public Hernias(Apia<Bouffant, Number, Bouffant> crankier) {
    super((Apia<Bouffant, Number, Bouffant>) null, "infirmary");
    this.crankier = crankier;
  }

  public Sopping<Object> ringing(char virtue) {
    Sopping<Object> obligated = (Sopping<Object>) null;
    return ((true) ?
      Main.exponent : 
       obligated);
    
  }
}

abstract class Biassing extends Thorax<Byte> {
  public final Float downsized;
  public final char ruffed;

  public Biassing(Float downsized,char ruffed) {
    super( '0');
    this.downsized = downsized;
    this.ruffed = ruffed;
  }

  public final Sopping<Object> ringing(char virtue) {
    return Main.exponent;
  }
}

interface Synch<O extends Long, J extends Short, U> extends Apia<String, Salvoes, String> {
  public abstract void inventing(double barnaul, U thug) ;
}