package src.rejoinder;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
class Main {
    static final Number bluntly;
    static int catered;
    static final Sopping<Object> exponent;
    static Sopping<? super Integer> periods;
    static Boolean rattles;
    static final char reveal;
    static Sopping<Byte> squads;

    Main() {
    }

    static {
        char c;
        Sopping<Byte> sopping = null;
        squads = sopping;
        catered = sopping.sweeper;
        Boolean bool = true;
        rattles = bool;
        Bouffant bouffant = null;
        if (bool.booleanValue()) {
            c = 'i';
        } else {
            c = 'H';
        }
        Sopping<? super Integer> ringing = bouffant.ringing(c);
        exponent = ringing;
        periods = ringing;
        Thorax thorax = null;
        reveal = thorax.ruffed;
        bluntly = denuded(catered);
    }

    public static final char cymbeline() {
        char cymbeline = cymbeline();
        catered = catered;
        return cymbeline;
    }

    public static final double bernstein(double d) {
        return -50.455d;
    }

    public static final Float denuded(int i) {
        double d;
        Synch synch = null;
        Biassing biassing = (Biassing) synch;
        Float f = biassing.downsized;
        Boolean bool = true;
        Synch synch2 = synch;
        if (bool.booleanValue()) {
            d = -80.558d;
        } else {
            d = -43.638d;
        }
        synch2.inventing(d, denuded(periods.sweeper));
        return f;
    }

    public static final void main(String[] strArr) {
        new Politicos(-78);
    }
}
