package src.rejoinder;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
public abstract class Sopping<P> {
    public P bullish;
    public final int sweeper;

    public abstract Byte influenza(Short sh, P p);

    public Sopping(int i, P p) {
        this.sweeper = i;
        this.bullish = p;
    }
}
