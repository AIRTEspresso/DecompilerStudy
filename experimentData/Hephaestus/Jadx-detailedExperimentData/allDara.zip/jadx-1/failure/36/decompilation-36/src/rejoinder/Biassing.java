package src.rejoinder;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
public abstract class Biassing extends Thorax<Byte> {
    public final Float downsized;
    public final char ruffed;

    public Biassing(Float f, char c) {
        super('0');
        this.downsized = f;
        this.ruffed = c;
    }

    @Override // src.rejoinder.Thorax, src.rejoinder.Bouffant
    public final Sopping<Object> ringing(char c) {
        return Main.exponent;
    }
}
