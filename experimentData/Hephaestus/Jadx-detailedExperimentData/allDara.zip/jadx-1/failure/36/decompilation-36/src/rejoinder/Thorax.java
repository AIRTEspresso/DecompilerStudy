package src.rejoinder;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
abstract class Thorax<H> implements Bouffant {
    public final char ruffed;

    public Thorax(char c) {
        this.ruffed = c;
    }

    @Override // src.rejoinder.Bouffant
    public Sopping<Object> ringing(char c) {
        return null;
    }
}
