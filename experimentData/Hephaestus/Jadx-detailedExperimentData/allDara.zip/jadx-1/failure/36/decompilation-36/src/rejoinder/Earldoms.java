package src.rejoinder;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
final class Earldoms extends Sopping<Short> {
    public Short bullish;
    public double strollers;

    public Earldoms(Short sh, double d) {
        super(76, (short) -51);
        this.bullish = sh;
        this.strollers = d;
    }

    @Override // src.rejoinder.Sopping
    public Byte influenza(Short sh, Short sh2) {
        return (byte) -74;
    }
}
