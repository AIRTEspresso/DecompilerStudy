package src.rejoinder;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
class Hernias extends Salvoes {
    public Apia<Bouffant, Number, Bouffant> crankier;

    public Hernias(Apia<Bouffant, Number, Bouffant> apia) {
        super(null, "infirmary");
        this.crankier = apia;
    }

    @Override // src.rejoinder.Salvoes, src.rejoinder.Bouffant
    public Sopping<Object> ringing(char c) {
        return Main.exponent;
    }
}
