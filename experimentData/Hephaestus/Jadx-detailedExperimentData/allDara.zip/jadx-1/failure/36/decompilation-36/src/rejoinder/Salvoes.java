package src.rejoinder;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
class Salvoes implements Bouffant {
    public Apia<Bouffant, Number, Bouffant> crankier;
    public String reviewer;

    public Salvoes(Apia<Bouffant, Number, Bouffant> apia, String str) {
        this.crankier = apia;
        this.reviewer = str;
    }

    @Override // src.rejoinder.Bouffant
    public Sopping<Object> ringing(char c) {
        Sopping<Object> sopping = Main.exponent;
        Main.catered = 39;
        return sopping;
    }

    public long rollicks(long j, boolean z) {
        return -44L;
    }
}
