package src.rejoinder;

import java.lang.Long;
import java.lang.Short;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
public interface Synch<O extends Long, J extends Short, U> extends Apia<String, Salvoes, String> {
    void inventing(double d, U u);
}
