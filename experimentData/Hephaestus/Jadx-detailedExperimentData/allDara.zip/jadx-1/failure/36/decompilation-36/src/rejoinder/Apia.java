package src.rejoinder;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
interface Apia<B, W, M extends B> extends Bouffant {
    long dourly(boolean z, B b);

    W everglade();
}
