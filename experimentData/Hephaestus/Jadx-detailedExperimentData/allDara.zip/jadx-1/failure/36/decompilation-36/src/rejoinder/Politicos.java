package src.rejoinder;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/36/original-36/Test.dex */
final class Politicos extends Sopping<Boolean> {
    public final int sweeper;

    public Politicos(int i) {
        super(25, false);
        this.sweeper = i;
    }

    @Override // src.rejoinder.Sopping
    public Byte influenza(Short sh, Boolean bool) {
        Apia apia = null;
        return Main.periods.influenza((Short) new Function2() { // from class: src.rejoinder.-$$Lambda$Politicos$SX3aZcW3-2XtkcI9QEGve7ZIhm0
            @Override // src.rejoinder.Function2
            public final Object apply(Object obj, Object obj2) {
                return Politicos.lambda$influenza$0((String) obj, (Long) obj2);
            }
        }.apply("sucre", Long.valueOf(new Salvoes(apia, "dustiness").crankier.dourly(false, apia))), null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Short lambda$influenza$0(String str, Long l) {
        return (short) 74;
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [P, java.lang.Integer] */
    public final Bouffant blanker(Bouffant bouffant) {
        Apia<Bouffant, Number, Bouffant> apia = new Salvoes(null, "potpies").crankier;
        Main.exponent.bullish = -15;
        return new Salvoes(apia, "halibut");
    }
}
