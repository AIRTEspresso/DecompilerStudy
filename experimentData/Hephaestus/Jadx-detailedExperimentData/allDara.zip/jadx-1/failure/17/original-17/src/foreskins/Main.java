package src.foreskins;

class Main {
  static public final Byte ampuls(int misfiring) {
    return Main.ampuls(-92);
  }

  static public final boolean steppe() {
    Austerest<Byte> distrusts = (Austerest<Byte>) null;
    final Austerest<Byte> savors = ((true) ?
      (Austerest<Byte>) null : 
       distrusts);
    final Byte age = savors.aruba;
    Function1<Boolean, Void> opaques = (wrongness) -> {
      final float thatch = ((Europe) null).adulterer;
      Object x_0 = thatch;
      return null;
    };
    opaques.apply(((Viburnum) null).negroes((Number) new Long(84)).milepost( 'S', (short)75).labs);
    return (age <   ((false) ?
  69.49 : 
   99.502));
    
  }

  static public final void untie() {
    ((Stampede) null).norris();
    Object x_3 = "whereas";
    
  }

  static final boolean lyman = Main.steppe();

  static public final void wintriest() {
    final Executive<? extends Europe, ? super Integer, Boolean> physiques = (Executive<Europe, Integer, Boolean>) null;
    final Executive<? extends Europe, ? super Integer, Boolean> stockroom = physiques;
    final Quiet<Integer, Integer> pilcomayo = (Quiet<Integer, Integer>) null;
    pilcomayo.hailing = 14;
    Object x_4 = stockroom;
    
  }

  static short jasper = ((Suez) null).striker;

  static short randolph = Main.jasper;

  static final short plexuses = Main.randolph;

  static short reduced = Main.plexuses;

  static public final void main(String[] args) {
    Object x_7 = ((Milked) null).parasites;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Austerest<Z extends Byte> {
  public final Byte aruba;

  public Austerest(Byte aruba) {
    this.aruba = aruba;
  }

  public Double[] warbling() {
    return new Double[0];
  }

  public Number uriel(Object kidneys) {
    Number recipient = (Number) new Long(89);
    Boolean misspends = false;
    ((Vain) null).revalue(misspends, new Object());
    return recipient;
    
  }
}

abstract class Vain {
  public final long stoic;

  public Vain(long stoic) {
    this.stoic = stoic;
  }

  public abstract void revalue(Boolean described, Object tabitha) ;
}

abstract class Europe extends Austerest<Byte> {
  public float adulterer;

  public Europe(float adulterer) {
    super((byte)15);
    this.adulterer = adulterer;
  }

  public Number uriel(Object kidneys) {
    final Number accursed = (Number) new Long(10);
    adulterer = (float)-86.726;
    return accursed;
    
  }

  public Float[] beatriz() {
    return new Float[0];
  }
}

abstract class Girdling extends Austerest<Byte> {
  public final boolean labs;
  public final Byte aruba;

  public Girdling(boolean labs,Byte aruba) {
    super((byte)62);
    this.labs = labs;
    this.aruba = aruba;
  }

  public final Number uriel(Object kidneys) {
    return (Number) new Long(26);
  }

  public final Double[] warbling() {
    return (Double[]) new Object[]{-85.834, -83.739, 75.768};
  }
}

abstract class Executive<S, R, E> extends Vain {
  public Executive() {
    super((long)-66);
}

  public Girdling milepost(Character aspired, Short ward) {
    Girdling milk = (Girdling) null;
    ((Quiet<Integer, Integer>) null).selfie(55);
    return milk;
    
  }

  public void revalue(Boolean described, Object tabitha) {
    final R assured = (R) null;
    Main.untie();
    Object x_1 = assured;
    
  }
}

abstract class Quiet<Q extends Integer, H extends Q> extends Austerest<Byte> {
  public H genteel;
  public Q hailing;

  public Quiet(H genteel,Q hailing) {
    super((byte)-64);
    this.genteel = genteel;
    this.hailing = hailing;
  }

  public void selfie(Q knotty) {
    final Integer gamiest = 20;
    Object x_2 = gamiest;
    
  }
}

interface Stampede {
  public abstract void norris() ;

  public abstract Object blames(Object club) ;
}

abstract class Viburnum extends Europe {
  public final Executive<Character, ? super Stampede, ? super Number> hooks;

  public Viburnum(Executive<Character, ? super Stampede, ? super Number> hooks) {
    super((float)42.689);
    this.hooks = hooks;
  }

  public abstract Executive<Boolean, Long, Short> negroes(Number telethon) ;
}

abstract class Suez extends Austerest<Byte> {
  public short striker;

  public Suez(short striker) {
    super((byte)-91);
    this.striker = striker;
  }

  public Double[] warbling() {
    Double[] myna = new Double[0];
    myna = myna;
    return myna;
    
  }

  public final Number uriel(Object kidneys) {
    Quiet<Integer, Integer> autocracy = (Quiet<Integer, Integer>) null;
    Main.wintriest();
    return autocracy.aruba;
    
  }
}

interface Composure extends Stampede {
  public abstract Suez shepherd() ;
}

class Gilliam extends Executive<Short, Integer, Integer> {
  public Gilliam() {
    super();
}

  public final Girdling milepost(Character aspired, Short ward) {
    Boolean garters = true;
    final Short altruist = (short)42;
    Girdling russell = milepost(  ((false) ?
   'U' : 
    'G'),   ((garters) ?
  altruist : 
   (short)-42));
    return russell;
    
  }

  public final void revalue(Boolean described, Object tabitha) {
    Gilliam romancing = (Gilliam) null;
    Gilliam estuary = romancing;
    final Gilliam[] theosophy = (Gilliam[]) new Object[]{estuary, (Gilliam) null};
    new Emblems((float)-64.748).poising(  ((false) ?
  (Gilliam) null : 
   (Gilliam) null));
    Object x_5 = ((true) ?
      (Gilliam[]) new Object[]{(Gilliam) null, romancing} : 
       theosophy);
    
  }
}

class Emblems extends Austerest<Byte> {
  public Float jezebel;

  public Emblems(Float jezebel) {
    super((byte)93);
    this.jezebel = jezebel;
  }

  public void poising(Gilliam octavio) {
    final Boolean chickadee = false;
    final short charge = (short)30;
    Main.reduced =   ((chickadee) ?
  charge : 
   (short)26);
    Object x_6 = 91.172;
    
  }
}

abstract class Milked extends Emblems {
  public Quiet<? extends Integer, ? extends Integer> parasites;
  public Double idealize;

  public Milked(Quiet<? extends Integer, ? extends Integer> parasites,Double idealize) {
    super((float)-27.842);
    this.parasites = parasites;
    this.idealize = idealize;
  }

  public void poising(Gilliam octavio) {
    final Boolean piedmont = false;
    Main.reduced =   ((piedmont) ?
  (short)60 : 
   (short)88);
    
  }
}