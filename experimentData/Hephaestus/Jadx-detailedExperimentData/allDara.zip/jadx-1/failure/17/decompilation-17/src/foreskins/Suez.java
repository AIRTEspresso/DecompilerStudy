package src.foreskins;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
abstract class Suez extends Austerest<Byte> {
    public short striker;

    public Suez(short s) {
        super((byte) -91);
        this.striker = s;
    }

    @Override // src.foreskins.Austerest
    public Double[] warbling() {
        return new Double[0];
    }

    @Override // src.foreskins.Austerest
    public final Number uriel(Object obj) {
        Quiet quiet = null;
        Main.wintriest();
        return quiet.aruba;
    }
}
