package src.foreskins;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
class Gilliam extends Executive<Short, Integer, Integer> {
    @Override // src.foreskins.Executive
    public final Girdling milepost(Character ch, Short sh) {
        short s;
        Boolean bool = true;
        Short sh2 = 42;
        if (bool.booleanValue()) {
            s = sh2.shortValue();
        } else {
            s = -42;
        }
        return milepost('G', Short.valueOf(s));
    }

    @Override // src.foreskins.Executive, src.foreskins.Vain
    public final void revalue(Boolean bool, Object obj) {
        Gilliam gilliam = null;
        Gilliam[] gilliamArr = (Gilliam[]) new Object[]{gilliam, gilliam};
        new Emblems(Float.valueOf(-64.748f)).poising(gilliam);
        Gilliam[] gilliamArr2 = (Gilliam[]) new Object[]{gilliam, gilliam};
    }
}
