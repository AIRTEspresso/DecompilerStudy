package src.foreskins;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
public class Main {
    static short jasper;
    static final boolean lyman = steppe();
    static final short plexuses;
    static short randolph;
    static short reduced;

    Main() {
    }

    public static final Byte ampuls(int i) {
        return ampuls(-92);
    }

    public static final boolean steppe() {
        Viburnum viburnum = null;
        Viburnum viburnum2 = viburnum;
        Byte b = viburnum2.aruba;
        Viburnum viburnum3 = viburnum;
        new Function1() { // from class: src.foreskins.-$$Lambda$Main$nJwMD3Gb5dg8_I87e5mPG6EjHOQ
            @Override // src.foreskins.Function1
            public final Object apply(Object obj) {
                return Main.lambda$steppe$0((Boolean) obj);
            }
        }.apply(Boolean.valueOf(viburnum3.negroes(new Long(84L)).milepost('S', (short) 75).labs));
        return ((double) b.byteValue()) < 99.502d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$steppe$0(Boolean bool) {
        Europe europe = null;
        Float.valueOf(europe.adulterer);
        return null;
    }

    public static final void untie() {
        Stampede stampede = null;
        stampede.norris();
    }

    static {
        Suez suez = null;
        short s = suez.striker;
        jasper = s;
        randolph = s;
        plexuses = s;
        reduced = s;
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [Q extends java.lang.Integer, java.lang.Integer] */
    public static final void wintriest() {
        Quiet quiet = null;
        quiet.hailing = 14;
    }

    public static final void main(String[] strArr) {
        Milked milked = null;
        Quiet<? extends Integer, ? extends Integer> quiet = milked.parasites;
    }
}
