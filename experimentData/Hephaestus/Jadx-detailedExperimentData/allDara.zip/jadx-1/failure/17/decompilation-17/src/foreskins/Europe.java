package src.foreskins;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
public abstract class Europe extends Austerest<Byte> {
    public float adulterer;

    public Europe(float f) {
        super((byte) 15);
        this.adulterer = f;
    }

    @Override // src.foreskins.Austerest
    public Number uriel(Object obj) {
        Long l = new Long(10L);
        this.adulterer = -86.726f;
        return l;
    }

    public Float[] beatriz() {
        return new Float[0];
    }
}
