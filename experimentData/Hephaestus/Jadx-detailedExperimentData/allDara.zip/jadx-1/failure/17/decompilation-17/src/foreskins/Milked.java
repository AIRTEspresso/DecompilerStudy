package src.foreskins;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
abstract class Milked extends Emblems {
    public Double idealize;
    public Quiet<? extends Integer, ? extends Integer> parasites;

    public Milked(Quiet<? extends Integer, ? extends Integer> quiet, Double d) {
        super(Float.valueOf(-27.842f));
        this.parasites = quiet;
        this.idealize = d;
    }

    @Override // src.foreskins.Emblems
    public void poising(Gilliam gilliam) {
        short s;
        Boolean bool = false;
        if (bool.booleanValue()) {
            s = 60;
        } else {
            s = 88;
        }
        Main.reduced = s;
    }
}
