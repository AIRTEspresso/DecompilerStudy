package src.foreskins;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
abstract class Vain {
    public final long stoic;

    public abstract void revalue(Boolean bool, Object obj);

    public Vain(long j) {
        this.stoic = j;
    }
}
