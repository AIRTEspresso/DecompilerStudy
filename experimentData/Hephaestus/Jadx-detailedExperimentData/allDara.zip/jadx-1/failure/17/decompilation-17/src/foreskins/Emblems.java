package src.foreskins;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
class Emblems extends Austerest<Byte> {
    public Float jezebel;

    public Emblems(Float f) {
        super((byte) 93);
        this.jezebel = f;
    }

    public void poising(Gilliam gilliam) {
        short s;
        Boolean bool = false;
        if (bool.booleanValue()) {
            s = 30;
        } else {
            s = 26;
        }
        Main.reduced = s;
        Double.valueOf(91.172d);
    }
}
