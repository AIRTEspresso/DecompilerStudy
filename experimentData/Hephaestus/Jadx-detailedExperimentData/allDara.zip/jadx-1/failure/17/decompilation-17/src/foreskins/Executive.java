package src.foreskins;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
public abstract class Executive<S, R, E> extends Vain {
    public Executive() {
        super(-66L);
    }

    public Girdling milepost(Character ch, Short sh) {
        Girdling girdling = null;
        Quiet quiet = null;
        quiet.selfie(55);
        return girdling;
    }

    @Override // src.foreskins.Vain
    public void revalue(Boolean bool, Object obj) {
        Main.untie();
    }
}
