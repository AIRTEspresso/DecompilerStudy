package src.foreskins;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
abstract class Girdling extends Austerest<Byte> {
    public final Byte aruba;
    public final boolean labs;

    public Girdling(boolean z, Byte b) {
        super((byte) 62);
        this.labs = z;
        this.aruba = b;
    }

    @Override // src.foreskins.Austerest
    public final Number uriel(Object obj) {
        return new Long(26L);
    }

    @Override // src.foreskins.Austerest
    public final Double[] warbling() {
        return (Double[]) new Object[]{Double.valueOf(-85.834d), Double.valueOf(-83.739d), Double.valueOf(75.768d)};
    }
}
