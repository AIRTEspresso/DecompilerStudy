package src.foreskins;

import java.lang.Byte;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
abstract class Austerest<Z extends Byte> {
    public final Byte aruba;

    public Austerest(Byte b) {
        this.aruba = b;
    }

    public Double[] warbling() {
        return new Double[0];
    }

    public Number uriel(Object obj) {
        Long l = new Long(89L);
        Vain vain = null;
        vain.revalue(false, new Object());
        return l;
    }
}
