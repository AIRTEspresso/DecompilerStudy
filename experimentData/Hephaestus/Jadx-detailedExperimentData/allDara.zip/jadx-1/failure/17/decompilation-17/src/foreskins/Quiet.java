package src.foreskins;

import java.lang.Integer;
/* JADX INFO: Access modifiers changed from: package-private */
/* JADX WARN: Incorrect field signature: TH; */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
public abstract class Quiet<Q extends Integer, H extends Q> extends Austerest<Byte> {
    public Integer genteel;
    public Q hailing;

    /* JADX WARN: Incorrect types in method signature: (TH;TQ;)V */
    /* JADX WARN: Multi-variable type inference failed */
    public Quiet(Integer num, Integer num2) {
        super((byte) -64);
        this.genteel = num;
        this.hailing = num2;
    }

    public void selfie(Q q) {
        Integer.valueOf(20);
    }
}
