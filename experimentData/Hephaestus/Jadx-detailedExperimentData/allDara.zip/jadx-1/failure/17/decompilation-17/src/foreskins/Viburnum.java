package src.foreskins;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/17/original-17/Test.dex */
public abstract class Viburnum extends Europe {
    public final Executive<Character, ? super Stampede, ? super Number> hooks;

    public abstract Executive<Boolean, Long, Short> negroes(Number number);

    public Viburnum(Executive<Character, ? super Stampede, ? super Number> executive) {
        super(42.689f);
        this.hooks = executive;
    }
}
