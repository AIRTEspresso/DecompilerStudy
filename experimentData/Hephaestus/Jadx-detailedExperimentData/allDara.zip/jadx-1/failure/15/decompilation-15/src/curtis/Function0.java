package src.curtis;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/15/original-15/Test.dex */
public interface Function0<R> {
    R apply();
}
