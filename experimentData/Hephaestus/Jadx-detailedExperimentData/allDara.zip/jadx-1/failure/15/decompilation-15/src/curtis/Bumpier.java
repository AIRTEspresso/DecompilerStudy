package src.curtis;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/15/original-15/Test.dex */
class Bumpier implements Commended {
    public Long indra() {
        indra();
        return 91L;
    }

    public Character karroo(short s, Double d) {
        float f;
        Boolean bool = true;
        Lapping lapping = null;
        if (bool.booleanValue()) {
            f = 29.564f;
        } else {
            f = 9.731f;
        }
        lapping.saving = f;
        return 'f';
    }
}
