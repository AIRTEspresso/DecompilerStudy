package src.curtis;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/15/original-15/Test.dex */
interface Commended {
}
