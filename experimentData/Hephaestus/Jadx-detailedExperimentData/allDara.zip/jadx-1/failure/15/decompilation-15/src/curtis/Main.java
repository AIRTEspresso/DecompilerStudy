package src.curtis;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/15/original-15/Test.dex */
class Main {
    static final byte doodad = -64;
    static final byte traveler = -64;
    static final Byte skyward = (byte) 15;
    static final Number cowslips = (byte) 15;

    Main() {
    }

    public static final float bagging() {
        Lapping lapping = null;
        return lapping.saving;
    }

    public static final <F_F extends Integer> F_F raucously(F_F f_f, Object obj) {
        return null;
    }

    public static final void main(String[] strArr) {
        long j;
        $$Lambda$Main$UasPpwGEylu9rhcyWFGqTPDBH5U __lambda_main_uasppwgeylu9rhcywfgqtpdbh5u = new Function2() { // from class: src.curtis.-$$Lambda$Main$UasPpwGEylu9rhcyWFGqTPDBH5U
            @Override // src.curtis.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$main$1((Long) obj, (Long) obj2);
            }
        };
        Boolean bool = true;
        if (bool.booleanValue()) {
            j = -99;
        } else {
            j = -44;
        }
        __lambda_main_uasppwgeylu9rhcywfgqtpdbh5u.apply(Long.valueOf(j), new Bumpier().indra());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Boolean lambda$main$1(Long l, Long l2) {
        ((Lapping) new Function0() { // from class: src.curtis.-$$Lambda$Main$_ETVT7WgENT7wqvUk8-ZWepavT4
            @Override // src.curtis.Function0
            public final Object apply() {
                return Main.lambda$main$0();
            }
        }.apply()).saving = 75.995f;
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Lapping lambda$main$0() {
        return null;
    }
}
