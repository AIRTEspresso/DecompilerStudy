package src.trimly;

class Main {
  static public final Boolean gunrunner(Integer hove, char invoked) {
    final Boolean unseats = true;
    return unseats;
    
  }

  static final Integer address = -38;

  static final char infirmary = 'p';

  static final Boolean designs = Main.gunrunner(Main.address, Main.infirmary);

  static final Double imbroglio = ((Main.designs) ?
  ((Sulfured<Long, Short, Long>) null).directory : 
   ((Sulfured<Number, Short, Long>) null).directory);

  static Double nowhere = Main.imbroglio;

  static Float pining = ((true) ?
  (float)-30.375 : 
   (float)-22.933);

  static public final long rolaids() {
    long boatswain = (long)-17;
    long settlers = boatswain;
    Function2<Integer, Integer, Brothers<Integer>> overdrive = (tories, perplexed) -> {
      final Brothers<Integer> tonsil = ((Grumpier<Boolean>) null).binderies;
      return tonsil;
      
    };
    final Integer summered = Main.address;
    overdrive.apply(54, summered).caused();
    return settlers;
    
  }

  static public final Character gulp(Character upgraded) {
    Character abscond = Main.infirmary;
    return abscond;
    
  }

  static public final Brothers<? extends Integer> gimmicky(Boolean baptismal) {
    final Brothers<? extends Integer> raga = new Brothers<Integer>(true, new Object());
    Main.pining = Main.encrusted().kali;
    return raga;
    
  }

  static public final Alarmed<Boolean> encrusted() {
    final Alarmed<Boolean> derisive = (Alarmed<Boolean>) null;
    return derisive;
    
  }

  static boolean tolyatti = Main.gimmicky(false).focuses;

  static public final void main(String[] args) {
    Object x_1 = Main.nowhere;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Sulfured<F, G extends Short, I> {
  public final Double directory;

  public Sulfured(Double directory) {
    this.directory = directory;
  }

  public G amass(G sequencer, Number reviewed) {
    final G lowness = (G) null;
    return lowness;
    
  }

  public abstract Double dodson(F afoul, Number sexless) ;
}

class Brothers<G extends Integer> extends Sulfured<G, Short, G> {
  public final boolean focuses;
  public final Object confuse;

  public Brothers(boolean focuses,Object confuse) {
    super(-22.100);
    this.focuses = focuses;
    this.confuse = confuse;
  }

  public final void caused() {
    Function2<Number, Brothers<? super Integer>, G> aneurysm = (sentenced, oculists) -> {
      G outrun = (G) null;
      boolean brawl = false;
      brawl = true;
      return outrun;
      
    };
    final Short karroo = (short)-48;
    G herding = aneurysm.apply(karroo, null);
    final G snottiest = ((Kindling<G>) null).isherwood(herding);
    Object x_0 = snottiest;
    
  }

  public Double dodson(G afoul, Number sexless) {
    Function0<G> alloying = () -> {
      return (G) null;
    };
    G umpteen = alloying.apply();
    Function1<G, Float> terraria = (menthol) -> {
      return (float)35.365;
    };
    return dodson(umpteen, terraria.apply((G) null));
    
  }
}

interface Kindling<U extends Integer> {
  public abstract U isherwood(U sunni) ;

  public abstract U pored(U itched) ;
}

abstract class Grumpier<U extends Boolean> extends Sulfured<Float, Short, Float> {
  public Brothers<Integer> binderies;
  public Double balzac;

  public Grumpier(Brothers<Integer> binderies,Double balzac) {
    super(-26.91);
    this.binderies = binderies;
    this.balzac = balzac;
  }

  public Short amass(Short sequencer, Number reviewed) {
    Short troika = (short)9;
    return troika;
    
  }

  public Double dodson(Float afoul, Number sexless) {
    Double preserve = -17.264;
    return preserve;
    
  }
}

abstract class Alarmed<T extends Boolean> extends Sulfured<T, Short, T> {
  public Float kali;
  public final T script;

  public Alarmed(Float kali,T script) {
    super(-77.42);
    this.kali = kali;
    this.script = script;
  }

  public Double dodson(T afoul, Number sexless) {
    Double jailor = 99.109;
    kali = (float)3.290;
    return jailor;
    
  }

  public final Short amass(Short sequencer, Number reviewed) {
    Short unhinge = (short)36;
    return unhinge;
    
  }
}