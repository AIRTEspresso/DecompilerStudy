package src.trimly;

import java.lang.Boolean;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/47/original-47/Test.dex */
public abstract class Grumpier<U extends Boolean> extends Sulfured<Float, Short, Float> {
    public Double balzac;
    public Brothers<Integer> binderies;

    public Grumpier(Brothers<Integer> brothers, Double d) {
        super(Double.valueOf(-26.91d));
        this.binderies = brothers;
        this.balzac = d;
    }

    @Override // src.trimly.Sulfured
    public Short amass(Short sh, Number number) {
        return (short) 9;
    }

    @Override // src.trimly.Sulfured
    public Double dodson(Float f, Number number) {
        return Double.valueOf(-17.264d);
    }
}
