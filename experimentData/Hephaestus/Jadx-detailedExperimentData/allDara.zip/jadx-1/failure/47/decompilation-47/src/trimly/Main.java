package src.trimly;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/47/original-47/Test.dex */
class Main {
    static final Integer address = -38;
    static final Boolean designs;
    static final Double imbroglio;
    static final char infirmary = 'p';
    static Double nowhere;
    static Float pining;
    static boolean tolyatti;

    Main() {
    }

    public static final Boolean gunrunner(Integer num, char c) {
        return true;
    }

    static {
        Double d;
        Boolean gunrunner = gunrunner(-38, infirmary);
        designs = gunrunner;
        Sulfured sulfured = null;
        if (gunrunner.booleanValue()) {
            Sulfured sulfured2 = sulfured;
            d = sulfured2.directory;
        } else {
            Sulfured sulfured3 = sulfured;
            d = sulfured3.directory;
        }
        imbroglio = d;
        nowhere = d;
        pining = Float.valueOf(-30.375f);
        tolyatti = gimmicky(false).focuses;
    }

    public static final long rolaids() {
        ((Brothers) new Function2() { // from class: src.trimly.-$$Lambda$Main$N9pH7d-_k4tCNWnsPnd2scWgJ1U
            @Override // src.trimly.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$rolaids$0((Integer) obj, (Integer) obj2);
            }
        }.apply(54, address)).caused();
        return -17L;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Brothers lambda$rolaids$0(Integer num, Integer num2) {
        Grumpier grumpier = null;
        return grumpier.binderies;
    }

    public static final Character gulp(Character ch) {
        return Character.valueOf(infirmary);
    }

    public static final Brothers<? extends Integer> gimmicky(Boolean bool) {
        Brothers<? extends Integer> brothers = new Brothers<>(true, new Object());
        pining = encrusted().kali;
        return brothers;
    }

    public static final Alarmed<Boolean> encrusted() {
        return null;
    }

    public static final void main(String[] strArr) {
    }
}
