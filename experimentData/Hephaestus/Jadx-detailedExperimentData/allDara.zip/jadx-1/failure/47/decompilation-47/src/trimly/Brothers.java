package src.trimly;

import java.lang.Integer;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/47/original-47/Test.dex */
public class Brothers<G extends Integer> extends Sulfured<G, Short, G> {
    public final Object confuse;
    public final boolean focuses;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // src.trimly.Sulfured
    public /* bridge */ /* synthetic */ Double dodson(Object obj, Number number) {
        return dodson((Brothers<G>) ((Integer) obj), number);
    }

    public Brothers(boolean z, Object obj) {
        super(Double.valueOf(-22.1d));
        this.focuses = z;
        this.confuse = obj;
    }

    public final void caused() {
        Kindling kindling = null;
        kindling.isherwood((Integer) new Function2() { // from class: src.trimly.-$$Lambda$Brothers$jLKRp57mq95qnB6AJ7soW2S7MA4
            @Override // src.trimly.Function2
            public final Object apply(Object obj, Object obj2) {
                return Brothers.lambda$caused$0((Number) obj, (Brothers) obj2);
            }
        }.apply((short) -48, null));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Integer lambda$caused$0(Number number, Brothers brothers) {
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public Double dodson(G g, Number number) {
        return dodson((Brothers<G>) ((Integer) new Function0() { // from class: src.trimly.-$$Lambda$Brothers$bLaPmuucPUAwl0KpT88gKkP2Tqo
            @Override // src.trimly.Function0
            public final Object apply() {
                return Brothers.lambda$dodson$1();
            }
        }.apply()), (Number) new Function1() { // from class: src.trimly.-$$Lambda$Brothers$66ROS3N9TG55ZNSQnBpjOxQH8Oo
            @Override // src.trimly.Function1
            public final Object apply(Object obj) {
                Float valueOf;
                Integer num = (Integer) obj;
                valueOf = Float.valueOf(35.365f);
                return valueOf;
            }
        }.apply(null));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Integer lambda$dodson$1() {
        return null;
    }
}
