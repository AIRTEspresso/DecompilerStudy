package src.trimly;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/47/original-47/Test.dex */
interface Kindling<U extends Integer> {
    U isherwood(U u);

    U pored(U u);
}
