package src.trimly;

import java.lang.Short;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/47/original-47/Test.dex */
abstract class Sulfured<F, G extends Short, I> {
    public final Double directory;

    public abstract Double dodson(F f, Number number);

    public Sulfured(Double d) {
        this.directory = d;
    }

    public G amass(G g, Number number) {
        return null;
    }
}
