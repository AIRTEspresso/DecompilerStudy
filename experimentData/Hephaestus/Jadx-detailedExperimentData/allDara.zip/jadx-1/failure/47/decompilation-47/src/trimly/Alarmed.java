package src.trimly;

import java.lang.Boolean;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/47/original-47/Test.dex */
abstract class Alarmed<T extends Boolean> extends Sulfured<T, Short, T> {
    public Float kali;
    public final T script;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // src.trimly.Sulfured
    public /* bridge */ /* synthetic */ Double dodson(Object obj, Number number) {
        return dodson((Alarmed<T>) ((Boolean) obj), number);
    }

    public Alarmed(Float f, T t) {
        super(Double.valueOf(-77.42d));
        this.kali = f;
        this.script = t;
    }

    public Double dodson(T t, Number number) {
        Double valueOf = Double.valueOf(99.109d);
        this.kali = Float.valueOf(3.29f);
        return valueOf;
    }

    @Override // src.trimly.Sulfured
    public final Short amass(Short sh, Number number) {
        return (short) 36;
    }
}
