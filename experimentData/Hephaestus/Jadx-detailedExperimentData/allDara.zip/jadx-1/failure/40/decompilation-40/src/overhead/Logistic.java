package src.overhead;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
interface Logistic {
    void mom();
}
