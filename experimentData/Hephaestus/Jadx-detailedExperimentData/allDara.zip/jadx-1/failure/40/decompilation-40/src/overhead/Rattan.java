package src.overhead;

import java.lang.Character;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public class Rattan<I extends Character, B> extends Dignified<Character> {
    public final Dignified<I> restrains;
    public Character walt;

    public Rattan(Dignified<I> dignified, Character ch) {
        super('W');
        this.restrains = dignified;
        this.walt = ch;
    }
}
