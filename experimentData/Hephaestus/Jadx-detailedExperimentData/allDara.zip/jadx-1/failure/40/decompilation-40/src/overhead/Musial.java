package src.overhead;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
final class Musial<G, L extends G> implements Logistic {
    public final G hanna;
    public long inferior;

    public Musial(long j, G g) {
        this.inferior = j;
        this.hanna = g;
    }

    @Override // src.overhead.Logistic
    public void mom() {
        new Function0() { // from class: src.overhead.-$$Lambda$Musial$GtE3jcmtSSaOkEpi-zLCF8iPLdE
            @Override // src.overhead.Function0
            public final Object apply() {
                return Musial.lambda$mom$1();
            }
        }.apply();
        Boolean.valueOf(true);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$mom$1() {
        X x = ((Ossifying) new Function2() { // from class: src.overhead.-$$Lambda$Musial$xATXiYRyKbigxDpq4_TQSrXOfGs
            @Override // src.overhead.Function2
            public final Object apply(Object obj, Object obj2) {
                return Musial.lambda$mom$0(obj, (String) obj2);
            }
        }.apply(null, "sidewalls")).gougers(null, null).honeymoon().encounter;
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Ossifying lambda$mom$0(Object obj, String str) {
        Ossifying ossifying = null;
        new Libretti(new Weal(), Double.valueOf(16.86d)).surmounts = Double.valueOf(95.967d);
        return ossifying;
    }

    public final L billy(L l, G g) {
        Trysting trysting = null;
        return (L) trysting.pimply(null);
    }
}
