package src.overhead;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
class Main {
    static final Ossifying<? extends Float, Character> grinned;
    static Ossifying<? extends Float, Character> pangs;
    static final float pressman = new Legislate(-60.398f).violated;
    static final String gyrations = "abraham";
    static String serialize = gyrations;
    static final String averse = gyrations;

    Main() {
    }

    public static final Long taser() {
        Long l;
        Boolean bool = false;
        Tepees tepees = new Tepees(-37L);
        if (bool.booleanValue()) {
            l = taser();
        } else {
            l = tepees.pony;
        }
        Logistic logistic = null;
        logistic.mom();
        return l;
    }

    static {
        Ossifying<? extends Float, Character> ossifying = new Wicca(null).evacuates;
        pangs = ossifying;
        grinned = ossifying;
    }

    public static final double marmots() {
        Double valueOf = Double.valueOf(18.438d);
        new Weal();
        Double.valueOf(-36.708d);
        Story story = null;
        new Compaq(null).writing.slater(null, (short) 36).causing(Boolean.valueOf(new Anarchism(new Cracker(null, (short) -93)).gallagher.laudanum(Boolean.valueOf(story != story)).shortValue() >= -18), false);
        return new Libretti(new Weal(), valueOf).surmounts.doubleValue();
    }

    public static final Niccolo<Story<Float, Float, Integer>, Boolean, Story<Float, Float, Integer>> twelves(Dignified<? super Character> dignified, Story<? extends Wicca, ? extends Wicca, Byte> story) {
        return new Niccolo<>(null);
    }

    public static final void main(String[] strArr) {
        Boolean bool = false;
        Croquette croquette = new Croquette(new Object(), new Tepees(-26L));
        Croquette croquette2 = new Croquette(new Object(), new Tepees(92L));
        if (!bool.booleanValue()) {
            croquette = croquette2;
        }
        croquette.llanos().thought();
    }
}
