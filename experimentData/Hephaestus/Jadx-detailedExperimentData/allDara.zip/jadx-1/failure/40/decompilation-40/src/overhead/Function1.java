package src.overhead;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
interface Function1<A1, R> {
    R apply(A1 a1);
}
