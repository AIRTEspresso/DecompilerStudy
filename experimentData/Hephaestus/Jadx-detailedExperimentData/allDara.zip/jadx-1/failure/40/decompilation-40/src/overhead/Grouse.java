package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public class Grouse<X, F> extends Rattan<Character, X> {
    public final X encounter;

    public Grouse(X x) {
        super(new Rattan(null, '1'), 'x');
        this.encounter = x;
    }

    public F scab() {
        new Function2() { // from class: src.overhead.-$$Lambda$Grouse$ERKDC_KIKdKFnrfeFzPdTKxrLQQ
            @Override // src.overhead.Function2
            public final Object apply(Object obj, Object obj2) {
                return Grouse.lambda$scab$0(obj, obj2);
            }
        }.apply(null, null);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$scab$0(Object obj, Object obj2) {
        Short[] shArr = (Short[]) new Object[]{(short) -48};
        return null;
    }

    public final Weal<? super Character> gobbed(long j, X x) {
        return new Weal<>();
    }
}
