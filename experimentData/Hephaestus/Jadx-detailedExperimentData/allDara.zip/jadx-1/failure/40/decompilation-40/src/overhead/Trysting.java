package src.overhead;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
abstract class Trysting<I, H> extends Grouse<Double, String> {
    public final H disarms;
    public short verticals;

    public abstract I pimply(H h);

    public Trysting(H h, short s) {
        super(Double.valueOf(69.115d));
        this.disarms = h;
        this.verticals = s;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // src.overhead.Grouse
    public String scab() {
        return scab();
    }
}
