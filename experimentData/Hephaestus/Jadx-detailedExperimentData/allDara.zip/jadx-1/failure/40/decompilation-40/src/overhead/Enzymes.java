package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public class Enzymes<L> extends Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> {
    public Enzymes() {
        super(null, (short) 63);
    }

    public Anarchism<? extends Long, ? extends Long, ? extends Integer> thought() {
        return new Anarchism<>(new Cracker(null, (short) 35));
    }
}
