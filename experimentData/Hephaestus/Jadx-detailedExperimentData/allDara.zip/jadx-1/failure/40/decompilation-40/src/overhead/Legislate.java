package src.overhead;

import src.overhead.Logistic;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
final class Legislate<C extends Logistic, U> extends Dignified<Character> {
    public final float violated;

    public Legislate(float f) {
        super('r');
        this.violated = f;
    }

    @Override // src.overhead.Dignified, src.overhead.Logistic
    public final void mom() {
    }

    public final Double attired(Grouse<C, C> grouse, U u) {
        return attired(grouse, null);
    }
}
