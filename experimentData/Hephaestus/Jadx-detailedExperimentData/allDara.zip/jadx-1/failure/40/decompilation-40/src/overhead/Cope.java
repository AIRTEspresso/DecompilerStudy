package src.overhead;

import java.lang.Boolean;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
interface Cope<R extends Boolean, V extends R> extends Cohere<Double, Byte> {
    void causing(R r, R r2);

    R pallets(R r);
}
