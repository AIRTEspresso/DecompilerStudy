package src.overhead;

import java.lang.Character;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public abstract class Dignified<F extends Character> implements Logistic {
    public F walt;

    public Dignified(F f) {
        this.walt = f;
    }

    @Override // src.overhead.Logistic
    public void mom() {
    }

    public String slags(Object obj, F f) {
        Cohere cohere = null;
        cohere.barbecued(-25, Double.valueOf(80.105d));
        return "perched";
    }
}
