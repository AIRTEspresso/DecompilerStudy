package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public interface Ossifying<L, A> extends Logistic {
    Libretti<A> gougers(L l, L l2);
}
