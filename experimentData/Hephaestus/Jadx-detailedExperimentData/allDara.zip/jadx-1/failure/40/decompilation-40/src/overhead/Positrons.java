package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public final class Positrons extends Grouse<Character, Lymphomas> {
    public final Enzymes<Character> pierces;

    public Positrons(Enzymes<Character> enzymes) {
        super('l');
        this.pierces = enzymes;
    }

    public final void croziers(Boolean bool, Cohere<? extends Double, ? extends Byte> cohere) {
        Integer.valueOf(-84);
    }

    @Override // src.overhead.Grouse
    public final Lymphomas scab() {
        Object obj = new Object();
        new Function0() { // from class: src.overhead.-$$Lambda$Positrons$fw3y0gmCnxFh5CewJ63dTQxdllM
            @Override // src.overhead.Function0
            public final Object apply() {
                return Positrons.lambda$scab$0();
            }
        }.apply();
        return new Croquette(obj, new Tepees(-98L));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$scab$0() {
        Weal weal = new Weal();
        new Libretti(new Weal(), Double.valueOf(71.563d)).reunite = new Libretti(new Weal(), Double.valueOf(39.143d));
        new Libretti(weal, Double.valueOf(86.819d));
        return null;
    }
}
