package src.overhead;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
final class Anarchism<R, B extends R, Z> extends Trysting<Z, R> {
    public Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> gallagher;

    public Anarchism(Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> cracker) {
        super(null, (short) -33);
        this.gallagher = cracker;
    }

    @Override // src.overhead.Trysting
    public Z pimply(R r) {
        return null;
    }

    @Override // src.overhead.Trysting, src.overhead.Grouse
    public final String scab() {
        return "pebbled";
    }
}
