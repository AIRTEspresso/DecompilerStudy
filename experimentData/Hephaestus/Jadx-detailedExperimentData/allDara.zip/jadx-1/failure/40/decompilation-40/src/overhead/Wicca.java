package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public class Wicca extends Trysting<Long, String> {
    public final Ossifying<? extends Float, Character> evacuates;

    public Wicca(Ossifying<? extends Float, Character> ossifying) {
        super("urgently", (short) -62);
        this.evacuates = ossifying;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // src.overhead.Trysting
    public Long pimply(String str) {
        Tepees tepees = new Tepees(-79L);
        Wicca wicca = null;
        Main.serialize = (String) wicca.disarms;
        return tepees.pony;
    }

    @Override // src.overhead.Trysting, src.overhead.Grouse
    public final String scab() {
        return Main.serialize;
    }
}
