package src.overhead;

import java.lang.Character;
import java.lang.Float;
import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
final class Tepees<O extends Integer, K extends Character, F extends Float> {
    public final Long pony;

    public Tepees(Long l) {
        this.pony = l;
    }
}
