package src.overhead;

import src.overhead.Tepees;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
class Croquette<O extends Tepees<? super Integer, ? extends Character, ? super Float>> extends Lymphomas {
    public Object focuses;
    public O slatterns;

    public Croquette(Object obj, O o) {
        super(new Object());
        this.focuses = obj;
        this.slatterns = o;
    }

    public Enzymes<Integer> llanos() {
        return new Enzymes<>();
    }

    @Override // src.overhead.Logistic
    public void mom() {
        Boolean bool = true;
        Story story = null;
        Niccolo<Story<Float, Float, Integer>, Boolean, Story<Float, Float, Integer>> twelves = Main.twelves(null, null);
        if (bool.booleanValue()) {
        }
        twelves.londoner(story);
    }
}
