package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public abstract class Story<Y, E extends Y, G> implements Logistic {
    Story() {
    }

    public Float scouts(Float f) {
        return Float.valueOf(73.111f);
    }
}
