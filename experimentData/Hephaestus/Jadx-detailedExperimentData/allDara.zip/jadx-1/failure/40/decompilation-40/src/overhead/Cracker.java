package src.overhead;

import java.lang.Short;
import src.overhead.Libretti;
import src.overhead.Trysting;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
class Cracker<U extends Libretti<? super Integer>, D extends Trysting<U, ? extends U>, C extends Short> implements Logistic {
    public final C crack;
    public final D reorgs;

    public Cracker(D d, C c) {
        this.reorgs = d;
        this.crack = c;
    }

    public Short laudanum(Boolean bool) {
        return (short) 52;
    }

    @Override // src.overhead.Logistic
    public void mom() {
    }
}
