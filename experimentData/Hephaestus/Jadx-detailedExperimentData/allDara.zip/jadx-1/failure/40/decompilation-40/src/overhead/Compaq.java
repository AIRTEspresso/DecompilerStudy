package src.overhead;

import java.lang.Double;
import src.overhead.Weal;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
final class Compaq<D extends Weal<Character>, O extends Double> extends Wicca {
    public final Lymphomas writing;

    public Compaq(Lymphomas lymphomas) {
        super(null);
        this.writing = lymphomas;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // src.overhead.Wicca, src.overhead.Trysting
    public final Long pimply(String str) {
        return 96L;
    }
}
