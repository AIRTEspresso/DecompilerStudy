package src.overhead;

import src.overhead.Story;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public final class Niccolo<P extends Story<Float, ? super Float, ? super Integer>, D, T extends P> extends Enzymes<Double> {
    public final Story<? super D, D, ? extends D> betrays;

    public Niccolo(Story<? super D, D, ? extends D> story) {
        this.betrays = story;
    }

    /* JADX WARN: Incorrect types in method signature: (TT;)V */
    public final void londoner(Story story) {
        new Positrons(new Enzymes()).croziers(false, null);
    }

    @Override // src.overhead.Enzymes
    public final Anarchism<? extends Long, ? extends Long, ? extends Integer> thought() {
        Anarchism<? extends Long, ? extends Long, ? extends Integer> anarchism = new Anarchism<>(new Cracker(null, (short) -30));
        new Function2() { // from class: src.overhead.-$$Lambda$Niccolo$AtUi2fzJUTg4i3c_i-tQvBIsj64
            @Override // src.overhead.Function2
            public final Object apply(Object obj, Object obj2) {
                return Niccolo.lambda$thought$1((Story) obj, (Legislate) obj2);
            }
        }.apply(null, null);
        return anarchism;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$thought$1(Story story, Legislate legislate) {
        new Function0() { // from class: src.overhead.-$$Lambda$Niccolo$IoURRdjB0KGOE4HsOZMfXJhcJxw
            @Override // src.overhead.Function0
            public final Object apply() {
                return Niccolo.lambda$thought$0();
            }
        }.apply();
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$thought$0() {
        return null;
    }
}
