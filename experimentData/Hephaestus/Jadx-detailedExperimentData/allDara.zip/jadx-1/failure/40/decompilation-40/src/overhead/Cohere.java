package src.overhead;

import java.lang.Byte;
import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
interface Cohere<E extends Double, C extends Byte> extends Logistic {
    void barbecued(Integer num, E e);
}
