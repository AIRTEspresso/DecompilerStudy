package src.overhead;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public class Libretti<V> extends Weal<Character> {
    public Weal<Character> reunite;
    public Double surmounts;

    public Libretti(Weal<Character> weal, Double d) {
        this.reunite = weal;
        this.surmounts = d;
    }

    public final Grouse<V, V> honeymoon() {
        return new Grouse<>(null);
    }

    @Override // src.overhead.Weal, src.overhead.Logistic
    public void mom() {
        this.surmounts = Double.valueOf(3.394d);
        new Musial(-87L, null);
    }
}
