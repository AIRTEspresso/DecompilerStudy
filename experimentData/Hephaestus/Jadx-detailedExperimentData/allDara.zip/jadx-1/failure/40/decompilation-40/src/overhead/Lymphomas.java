package src.overhead;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
abstract class Lymphomas implements Logistic {
    public Object focuses;

    public Lymphomas(Object obj) {
        this.focuses = obj;
    }

    public Cope<Boolean, Boolean> slater(Cohere<? extends Double, Byte> cohere, short s) {
        return null;
    }
}
