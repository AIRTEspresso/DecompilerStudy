package src.overhead;

import java.lang.Character;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/40/original-40/Test.dex */
public class Weal<Z extends Character> implements Logistic {
    @Override // src.overhead.Logistic
    public void mom() {
        int i;
        Boolean bool = false;
        Integer num = 17;
        if (bool.booleanValue()) {
            i = num.intValue();
        } else {
            i = -47;
        }
        Integer.valueOf(i);
    }

    public final Z linker() {
        return (Z) ((Dignified) new Function0() { // from class: src.overhead.-$$Lambda$Weal$kHCt_AJUl8NoXXyded6GbkqLZAo
            @Override // src.overhead.Function0
            public final Object apply() {
                Dignified dignified;
                dignified = new Rattan(null, 'A').restrains;
                return dignified;
            }
        }.apply()).walt;
    }
}
