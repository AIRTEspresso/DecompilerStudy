package src.overhead;

class Main {
  static public final Long taser() {
    Boolean runners = false;
    Tepees<Integer, Character, Float> chewer = new Tepees<Integer, Character, Float>((long)-37);
    Long grosses = ((runners) ?
      Main.taser() : 
       chewer.pony);
    ((Logistic) null).mom();
    return grosses;
    
  }

  static final float pressman = new Legislate<Logistic, Logistic>((float)-60.398).violated;

  static final String gyrations = "abraham";

  static String serialize = Main.gyrations;

  static final String averse = Main.serialize;

  static Ossifying<? extends Float, Character> pangs = new Wicca((Ossifying<Float, Character>) null).evacuates;

  static final Ossifying<? extends Float, Character> grinned = Main.pangs;

  static public final double marmots() {
    Double donny = 18.438;
    Weal<Character> harping = new Weal<Character>();
    final Double paddy = -36.708;
      ((((false) ?
    false : 
     false)) ?
  ((false) ?
    (Cope<Boolean, Boolean>) null : 
     (Cope<Boolean, Boolean>) null) : 
   new Compaq<Weal<Character>, Double>((Lymphomas) null).writing.slater(null, (short)36)).causing((new Anarchism<Object, Object, Integer>(new Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short>((Trysting<Libretti<Integer>, Libretti<Integer>>) null, (short)-93)).gallagher.laudanum(((Story<Integer, Integer, Integer>) null != (Story<Integer, Integer, Integer>) null)) >= -18), ((short)49 <= (short)32));
      return ((true) ?
  new Libretti<Double>(new Weal<Character>(), donny) : 
   new Libretti<Double>(harping, paddy)).surmounts;
    
  }

  static public final Niccolo<Story<Float, Float, Integer>, Boolean, Story<Float, Float, Integer>> twelves(Dignified<? super Character> shaven, Story<? extends Wicca, ? extends Wicca, Byte> letdown) {
    Story<? super Boolean, Boolean, ? extends Boolean> stuffy = (Story<Boolean, Boolean, Boolean>) null;
    final Story<? super Boolean, Boolean, ? extends Boolean> mottoes = stuffy;
    final Niccolo<Story<Float, Float, Integer>, Boolean, Story<Float, Float, Integer>> sheer = new Niccolo<Story<Float, Float, Integer>, Boolean, Story<Float, Float, Integer>>(mottoes);
    return ((false) ?
      new Niccolo<Story<Float, Float, Integer>, Boolean, Story<Float, Float, Integer>>(mottoes) : 
       sheer);
    
  }

  static public final void main(String[] args) {
    Boolean seeker = false;
    Croquette<Tepees<Integer, Character, Float>> griefs = new Croquette<Tepees<Integer, Character, Float>>(new Object(), new Tepees<Integer, Character, Float>((long)-26));
    final Croquette<Tepees<Integer, Character, Float>> censored = new Croquette<Tepees<Integer, Character, Float>>(new Object(), new Tepees<Integer, Character, Float>((long)92));
      ((seeker) ?
  griefs : 
   censored).llanos().thought();
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Tepees<O extends Integer, K extends Character, F extends Float> {
  public final Long pony;

  public Tepees(Long pony) {
    this.pony = pony;
  }
}

interface Logistic {
  public abstract void mom() ;
}

class Weal<Z extends Character> implements Logistic {
  public void mom() {
    final Boolean sequencer = false;
    final Integer judaeo = 17;
    Integer papa = ((sequencer) ?
      judaeo : 
       -47);
    papa = judaeo;
    Object x_0 = papa;
    
  }

  public final Z linker() {
    Function0<Dignified<Z>> empanels = () -> {
      final Character bewitched = 'A';
      final Dignified<Z> tankful = new Rattan<Z, Boolean>((Dignified<Z>) null, bewitched).restrains;
      return tankful;
      
    };
    final Dignified<Z> flatfeet = empanels.apply();
    final Z pliancy = flatfeet.walt;
    return pliancy;
    
  }
}

abstract class Dignified<F extends Character> implements Logistic {
  public F walt;

  public Dignified(F walt) {
    super();
    this.walt = walt;
  }

  public void mom() {
    Object x_1 = (F) null;
    
  }

  public String slags(Object cultural, F lisa) {
    final String underdog = "perched";
    ((Cohere<Double, Byte>) null).barbecued(-25, 80.105);
    return underdog;
    
  }
}

interface Cohere<E extends Double, C extends Byte> extends Logistic {
  public abstract void barbecued(Integer tamika, E dexter) ;
}

class Rattan<I extends Character, B> extends Dignified<Character> {
  public final Dignified<I> restrains;
  public Character walt;

  public Rattan(Dignified<I> restrains,Character walt) {
    super( 'W');
    this.restrains = restrains;
    this.walt = walt;
  }
}

final class Musial<G, L extends G> implements Logistic {
  public long inferior;
  public final G hanna;

  public Musial(long inferior,G hanna) {
    super();
    this.inferior = inferior;
    this.hanna = hanna;
  }

  public void mom() {
    Function0<Void> republic = () -> {
      Function2<L, String, Ossifying<L, G>> vang = (racier, backer) -> {
        final Ossifying<L, G> covey = (Ossifying<L, G>) null;
        Weal<Character> rioted = new Weal<Character>();
        final Weal<Character> coccis = rioted;
        new Libretti<L>(coccis, 16.86).surmounts = 95.967;
        return covey;
        
      };
      Ossifying<L, G> rambler = vang.apply((L) null, "sidewalls");
      L midgets = (L) null;
      L blurts = midgets;
      Object x_2 = rambler.gougers(blurts, (L) null).honeymoon().encounter;
      return null;
    };
    republic.apply();
    Object x_3 = true;
    
  }

  public final L billy(L descend, G suctioned) {
    return ((Trysting<L, Byte>) null).pimply(null);
  }
}

class Grouse<X, F> extends Rattan<Character, X> {
  public final X encounter;

  public Grouse(X encounter) {
    super(new Rattan<Character, Float>((Dignified<Character>) null, '1'), 'x');
    this.encounter = encounter;
  }

  public F scab() {
    final F clauses = (F) null;
    Function2<X, X, Void> godot = (futz, pallet) -> {
      final Short arawak = (short)-48;
      Object x_4 = (Short[]) new Object[]{arawak};
      return null;
    };
    X balder = (X) null;
    godot.apply((X) null, balder);
    return clauses;
    
  }

  public final Weal<? super Character> gobbed(long seller, X seductive) {
    Weal<? super Character> decadence = new Weal<Character>();
    Weal<? super Character> snugged = decadence;
    return snugged;
    
  }
}

class Libretti<V> extends Weal<Character> {
  public Weal<Character> reunite;
  public Double surmounts;

  public Libretti(Weal<Character> reunite,Double surmounts) {
    super();
    this.reunite = reunite;
    this.surmounts = surmounts;
  }

  public final Grouse<V, V> honeymoon() {
    final Grouse<V, V> lamas = new Grouse<V, V>((V) null);
    return lamas;
    
  }

  public void mom() {
    final long will = (long)-87;
    surmounts = 3.394;
    Object x_5 = new Musial<V, V>(will, (V) null);
    
  }
}

interface Ossifying<L, A> extends Logistic {
  public abstract Libretti<A> gougers(L lyell, L rack) ;
}

abstract class Trysting<I, H> extends Grouse<Double, String> {
  public final H disarms;
  public short verticals;

  public Trysting(H disarms,short verticals) {
    super(69.115);
    this.disarms = disarms;
    this.verticals = verticals;
  }

  public abstract I pimply(H imposture) ;

  public String scab() {
    return scab();
  }
}

abstract class Story<Y, E extends Y, G> implements Logistic {
  public Float scouts(Float rescues) {
    return (float)73.111;
  }
}

final class Legislate<C extends Logistic, U> extends Dignified<Character> {
  public final float violated;

  public Legislate(float violated) {
    super( 'r');
    this.violated = violated;
  }

  public final void mom() {
    Object x_6 = (U) null;
    
  }

  public final Double attired(Grouse<C, C> ironwork, U schiller) {
    final Grouse<C, C> anecdota = ironwork;
    U crete = (U) null;
    final U leonel = crete;
    crete = (U) null;
    return attired(anecdota, leonel);
    
  }
}

class Wicca extends Trysting<Long, String> {
  public final Ossifying<? extends Float, Character> evacuates;

  public Wicca(Ossifying<? extends Float, Character> evacuates) {
    super("urgently", (short)-62);
    this.evacuates = evacuates;
  }

  public Long pimply(String imposture) {
    Long baffles = (long)-79;
    Tepees<? extends Integer, ? super Character, Float> specter = new Tepees<Integer, Character, Float>(baffles);
    String joaquin = ((Wicca) null).disarms;
    Main.serialize = joaquin;
    return specter.pony;
    
  }

  public final String scab() {
    String tabloids = Main.serialize;
    return tabloids;
    
  }
}

interface Cope<R extends Boolean, V extends R> extends Cohere<Double, Byte> {
  public abstract void causing(R piecing, R mervin) ;

  public abstract R pallets(R daredevil) ;
}

abstract class Lymphomas implements Logistic {
  public Object focuses;

  public Lymphomas(Object focuses) {
    super();
    this.focuses = focuses;
  }

  public Cope<Boolean, Boolean> slater(Cohere<? extends Double, Byte> packing, short carfare) {
    Cope<Boolean, Boolean> cozily = (Cope<Boolean, Boolean>) null;
    cozily = cozily;
    return cozily;
    
  }
}

final class Compaq<D extends Weal<Character>, O extends Double> extends Wicca {
  public final Lymphomas writing;

  public Compaq(Lymphomas writing) {
    super((Ossifying<Float, Character>) null);
    this.writing = writing;
  }

  public final Long pimply(String imposture) {
    return (long)96;
  }
}

class Cracker<U extends Libretti<? super Integer>, D extends Trysting<U, ? extends U>, C extends Short> implements Logistic {
  public final D reorgs;
  public final C crack;

  public Cracker(D reorgs,C crack) {
    super();
    this.reorgs = reorgs;
    this.crack = crack;
  }

  public Short laudanum(Boolean calicos) {
    Short chechen = (short)52;
    return chechen;
    
  }

  public void mom() {
    D polios = (D) null;
    Object x_7 = polios;
    
  }
}

final class Anarchism<R extends Object, B extends R, Z> extends Trysting<Z, R> {
  public Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> gallagher;

  public Anarchism(Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> gallagher) {
    super((R) null, (short)-33);
    this.gallagher = gallagher;
  }

  public Z pimply(R imposture) {
    return (Z) null;
  }

  public final String scab() {
    return "pebbled";
  }
}

class Enzymes<L> extends Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> {
  public Enzymes() {
    super((Trysting<Libretti<Integer>, Libretti<Integer>>) null, (short)63);
}

  public Anarchism<? extends Long, ? extends Long, ? extends Integer> thought() {
    return new Anarchism<Long, Long, Integer>(new Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short>((Trysting<Libretti<Integer>, Libretti<Integer>>) null, (short)35));
  }
}

class Croquette<O extends Tepees<? super Integer, ? extends Character, ? super Float>> extends Lymphomas {
  public Object focuses;
  public O slatterns;

  public Croquette(Object focuses,O slatterns) {
    super(new Object());
    this.focuses = focuses;
    this.slatterns = slatterns;
  }

  public Enzymes<Integer> llanos() {
    return ((true) ?
      new Enzymes<Integer>() : 
       new Enzymes<Integer>());
  }

  public void mom() {
    final O spirit = (O) null;
    final Boolean crated = true;
    Story<Float, Float, Integer> kicky = (Story<Float, Float, Integer>) null;
    Main.twelves(null, null).londoner(  ((crated) ?
  kicky : 
   (Story<Float, Float, Integer>) null));
    Object x_8 = spirit;
    
  }
}

final class Niccolo<P extends Story<Float, ? super Float, ? super Integer>, D, T extends P> extends Enzymes<Double> {
  public final Story<? super D, D, ? extends D> betrays;

  public Niccolo(Story<? super D, D, ? extends D> betrays) {
    super();
    this.betrays = betrays;
  }

  public final void londoner(T armchair) {
    Positrons sentences = new Positrons(new Enzymes<Character>());
    Boolean lucking = false;
    sentences.croziers(lucking, null);
    Object x_9 = armchair;
    
  }

  public final Anarchism<? extends Long, ? extends Long, ? extends Integer> thought() {
    final Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short> acetates = new Cracker<Libretti<Integer>, Trysting<Libretti<Integer>, Libretti<Integer>>, Short>((Trysting<Libretti<Integer>, Libretti<Integer>>) null, (short)-30);
    final Anarchism<? extends Long, ? extends Long, ? extends Integer> informed = new Anarchism<Long, Long, Integer>(acetates);
    Function2<T, Legislate<? super Lymphomas, ? extends Byte>, Void> altamira = (newspaper, conceited) -> {
      final T flippancy = (T) null;
      Function0<Void> partook = () -> {
        Object x_10 = (T) null;
        return null;
      };
      partook.apply();
      Object x_11 = flippancy;
      return null;
    };
    final T motivates = (T) null;
    altamira.apply(motivates, null);
    return informed;
    
  }
}

final class Positrons extends Grouse<Character, Lymphomas> {
  public final Enzymes<Character> pierces;

  public Positrons(Enzymes<Character> pierces) {
    super( 'l');
    this.pierces = pierces;
  }

  public final void croziers(Boolean embossing, Cohere<? extends Double, ? extends Byte> evenly) {
    Integer dunes = -84;
    Object x_12 = dunes;
    
  }

  public final Lymphomas scab() {
    final Object herrera = new Object();
    Object bushy = herrera;
    Function0<Void> nobelist = () -> {
      Weal<Character> militated = new Weal<Character>();
      final Weal<Character> swelled = new Weal<Character>();
      final Double bruins = 71.563;
      new Libretti<Byte>(swelled, bruins).reunite = new Libretti<Long>(new Weal<Character>(), 39.143);
      Object x_13 = new Libretti<Character>(militated, 86.819);
      return null;
    };
    nobelist.apply();
    return new Croquette<Tepees<Integer, Character, Float>>(bushy, new Tepees<Integer, Character, Float>((long)-98));
    
  }
}