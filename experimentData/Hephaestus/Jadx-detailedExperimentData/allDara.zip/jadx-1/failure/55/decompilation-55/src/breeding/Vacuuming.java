package src.breeding;

import java.lang.Float;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
abstract class Vacuuming<S extends Float, H extends S> {
    public S solemn;

    public Vacuuming(S s) {
        this.solemn = s;
    }
}
