package src.breeding;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
interface Function2<A1, A2, R> {
    R apply(A1 a1, A2 a2);
}
