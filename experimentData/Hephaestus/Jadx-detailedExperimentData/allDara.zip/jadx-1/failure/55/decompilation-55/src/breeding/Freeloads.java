package src.breeding;

import java.lang.Boolean;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
interface Freeloads<I extends Boolean> {
    I battery(I i);

    I kneading();
}
