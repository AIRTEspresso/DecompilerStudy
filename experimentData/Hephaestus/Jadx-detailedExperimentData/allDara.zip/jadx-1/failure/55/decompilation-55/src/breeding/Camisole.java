package src.breeding;

import java.lang.Byte;
import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
abstract class Camisole<Z extends Integer, N, I extends Byte> extends Rescuers<Number> {
    public final Z jauntily;

    public abstract N benumb(I i);

    public Camisole(Z z) {
        super(null, 77);
        this.jauntily = z;
    }

    @Override // src.breeding.Rescuers, src.breeding.Freeloads
    public final Boolean battery(Boolean bool) {
        return true;
    }
}
