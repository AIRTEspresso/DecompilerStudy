package src.breeding;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
final class Unsavory<T extends Integer> extends Molds<Integer, Double> {
    public T shirting;
    public T voyaged;

    public Unsavory(T t, T t2) {
        super(true, Float.valueOf(-17.712f));
        this.voyaged = t;
        this.shirting = t2;
    }

    @Override // src.breeding.Molds
    public Integer sols(short s, Integer num) {
        Unsavory unsavory = null;
        T t = unsavory.voyaged;
        new Function2() { // from class: src.breeding.-$$Lambda$Unsavory$uhZty0x_ct4RwFp90q_7051SqGQ
            @Override // src.breeding.Function2
            public final Object apply(Object obj, Object obj2) {
                return Unsavory.lambda$sols$0((Float) obj, (Integer) obj2);
            }
        }.apply(Float.valueOf(20.343f), null);
        return t;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$sols$0(Float f, Integer num) {
        return null;
    }

    public final T tanker(T t) {
        Camisole camisole = null;
        return (T) camisole.jauntily;
    }
}
