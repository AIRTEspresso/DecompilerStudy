package src.breeding;

import java.lang.Double;
import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
abstract class Molds<Y extends Integer, N extends Double> extends Vacuuming<Float, Float> {
    public Boolean ebert;
    public Float lacquer;

    public abstract Y sols(short s, Y y);

    public Molds(Boolean bool, Float f) {
        super(Float.valueOf(-83.531f));
        this.ebert = bool;
        this.lacquer = f;
    }
}
