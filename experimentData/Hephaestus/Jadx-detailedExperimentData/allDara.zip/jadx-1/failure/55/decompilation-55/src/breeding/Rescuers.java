package src.breeding;

import java.lang.Number;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
abstract class Rescuers<B extends Number> implements Freeloads<Boolean> {
    public int apes;
    public final Freeloads<Boolean> greasier;

    public Rescuers(Freeloads<Boolean> freeloads, int i) {
        this.greasier = freeloads;
        this.apes = i;
    }

    @Override // src.breeding.Freeloads
    public Boolean kneading() {
        return this.greasier.kneading();
    }

    @Override // src.breeding.Freeloads
    public Boolean battery(Boolean bool) {
        Main.spatially();
        return true;
    }
}
