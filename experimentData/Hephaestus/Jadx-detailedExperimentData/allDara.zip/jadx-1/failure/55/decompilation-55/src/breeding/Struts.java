package src.breeding;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
class Struts extends Rescuers<Byte> {
    public Short coventry;
    public Vacuuming<Float, ? extends Float> maces;

    public Struts(Vacuuming<Float, ? extends Float> vacuuming, Short sh) {
        super(null, 42);
        this.maces = vacuuming;
        this.coventry = sh;
    }

    @Override // src.breeding.Rescuers, src.breeding.Freeloads
    public final Boolean battery(Boolean bool) {
        this.coventry = this.coventry;
        return true;
    }

    @Override // src.breeding.Rescuers, src.breeding.Freeloads
    public final Boolean kneading() {
        boolean z = true;
        Boolean bool = true;
        if (!bool.booleanValue()) {
            z = false;
        }
        return Boolean.valueOf(z);
    }
}
