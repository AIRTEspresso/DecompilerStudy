package src.breeding;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/55/original-55/Test.dex */
class Main {
    Main() {
    }

    public static final int hyacinth(Number number, int i) {
        return i;
    }

    public static final Freeloads<Boolean> outhouses() {
        Boolean bool = true;
        Rescuers rescuers = null;
        if (bool.booleanValue()) {
        }
        return rescuers.greasier;
    }

    public static final void spatially() {
        Character.valueOf('W');
    }

    public static final <F_S extends Integer> F_S culottes() {
        Boolean bool = false;
        Integer num = null;
        if (bool.booleanValue()) {
        }
        return (F_S) new Unsavory(num, num).voyaged;
    }

    public static final void main(String[] strArr) {
        new Struts(null, (short) 3);
    }
}
