package src.downcast;

class Main {
  static final Untainted outstrip = new Untainted();

  static Untainted imbroglio = ((true) ?
  Main.outstrip : 
   new Untainted());

  static Coastline decking = Main.imbroglio.pervades();

  static byte steel = Main.decking.yerevan;

  static public final short dioxin() {
    final Boolean pindar = true;
    short nightlife = new Stability<Integer, Float>((short)-39).sneaking;
    final short murkier = ((pindar) ?
      Main.dioxin() : 
       nightlife);
    return murkier;
    
  }

  static public final void appeaser() {
    final Float scheming = (float)32.233;
    Object x_0 = scheming;
    
  }

  static boolean johann = (((Language) null).finale.evades.reduced((((long)-13 > -73) && new Furloughs<Boolean, Boolean>(false).totes)) >=   ((false) ?
   'f' : 
    '2'));

  static public final int chatting() {
    Function2<Furloughs<? super Boolean, Boolean>, Boolean, Boolean> idolaters = (genial, teasels) -> {
      final Boolean reinhardt = true;
      Language bellboy = (Language) null;
      final Candid<Short> equals = (Candid<Short>) null;
      bellboy.finale = equals;
      return reinhardt;
      
    };
    int censuses = Main.chatting();
    final int hones = ((idolaters.apply(null, true)) ?
      -41 : 
       censuses);
    Main.pele();
    return hones;
    
  }

  static public final void pele() {
    final boolean byblos = false;
    Main.johann = byblos;
    Object x_1 = ((false) ?
      (byte)-78 : 
       (byte)85);
    
  }

  static public final void main(String[] args) {
    Boolean playhouse = Main.johann;
    Boolean ouija = false;
    Revisions<Boolean, Short, Character> staffers = new Revisions<Boolean, Short, Character>(new Bay(new Furloughs<Boolean, Boolean>(ouija)), (Number) new Long(83));
      ((playhouse) ?
  staffers.lazaro : 
   staffers.lazaro).lodestars( 'P');
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Coastline {
  public byte yerevan;
  public Number woodcuts;

  public Coastline(byte yerevan,Number woodcuts) {
    this.yerevan = yerevan;
    this.woodcuts = woodcuts;
  }
}

final class Untainted extends Coastline {
  public Untainted() {
    super((byte)23, (Number) new Long(15));
}

  public final Coastline pervades() {
    return new Untainted();
  }
}

final class Stability<I, R> extends Coastline {
  public short sneaking;

  public Stability(short sneaking) {
    super((byte)58, (Number) new Long(-74));
    this.sneaking = sneaking;
  }

  public final R boogies() {
    return (R) null;
  }

  public final I fluttered(I easiness, I goner) {
    I garlanded = (I) null;
    Main.appeaser();
    return garlanded;
    
  }
}

final class Furloughs<I extends Boolean, W extends I> extends Coastline {
  public final I totes;

  public Furloughs(I totes) {
    super((byte)62, (Number) new Long(-13));
    this.totes = totes;
  }

  public final <F_J> Character reduced(F_J numerous) {
    Furloughs<? extends Boolean, ? extends Boolean> inhere = (Furloughs<Boolean, Boolean>) null;
    final Vex<F_J, Furloughs<Boolean, Boolean>> stubby = new Vex<F_J, Furloughs<Boolean, Boolean>>(inhere, (Furloughs<Boolean, Boolean>) null);
    Character lombard = stubby.scums.reduced(null);
    return lombard;
    
  }
}

final class Vex<E, Q extends Furloughs<? extends Boolean, ? extends Boolean>> extends Coastline {
  public final Furloughs<? extends Boolean, ? extends Boolean> scums;
  public final Q chaster;

  public Vex(Furloughs<? extends Boolean, ? extends Boolean> scums,Q chaster) {
    super((byte)-71, (float)10.249);
    this.scums = scums;
    this.chaster = chaster;
  }

  public final E impelled(E tommy) {
    return (E) null;
  }
}

abstract class Candid<W extends Number> extends Coastline {
  public Furloughs<Boolean, Boolean> evades;
  public final W lama;

  public Candid(Furloughs<Boolean, Boolean> evades,W lama) {
    super((byte)-16, 16.202);
    this.evades = evades;
    this.lama = lama;
  }

  public W salacious() {
    return (W) null;
  }

  public Character lodestars(Character ape) {
     return 'W';
  }
}

abstract class Language extends Coastline {
  public Candid<Short> finale;

  public Language(Candid<Short> finale) {
    super((byte)94, -41.167);
    this.finale = finale;
  }
}

abstract class Groovy<I> extends Coastline {
  public Number hoot;
  public I stylistic;

  public Groovy(Number hoot,I stylistic) {
    super((byte)-67, (Number) new Long(-8));
    this.hoot = hoot;
    this.stylistic = stylistic;
  }
}

class Bay extends Candid<Integer> {
  public Furloughs<Boolean, Boolean> evades;

  public Bay(Furloughs<Boolean, Boolean> evades) {
    super(new Furloughs<Boolean, Boolean>(true), 59);
    this.evades = evades;
  }

  public final Character lodestars(Character ape) {
     return 'W';
  }

  public final Integer salacious() {
    final Integer lobed = -47;
    return lobed;
    
  }
}

interface Clovers {
  public abstract String pearling(Groovy<? extends Byte> funnel) ;

  public abstract double buxtehude() ;
}

class Revisions<E, W, X> extends Groovy<Untainted> {
  public final Bay lazaro;
  public Number hoot;

  public Revisions(Bay lazaro,Number hoot) {
    super((Number) new Long(95), new Untainted());
    this.lazaro = lazaro;
    this.hoot = hoot;
  }
}