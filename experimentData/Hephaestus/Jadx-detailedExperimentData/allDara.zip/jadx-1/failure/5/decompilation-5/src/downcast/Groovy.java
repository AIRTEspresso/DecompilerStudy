package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
abstract class Groovy<I> extends Coastline {
    public Number hoot;
    public I stylistic;

    public Groovy(Number number, I i) {
        super((byte) -67, new Long(-8L));
        this.hoot = number;
        this.stylistic = i;
    }
}
