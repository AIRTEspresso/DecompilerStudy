package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
class Bay extends Candid<Integer> {
    public Furloughs<Boolean, Boolean> evades;

    public Bay(Furloughs<Boolean, Boolean> furloughs) {
        super(new Furloughs(true), 59);
        this.evades = furloughs;
    }

    @Override // src.downcast.Candid
    public final Character lodestars(Character ch) {
        return 'W';
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // src.downcast.Candid
    public final Integer salacious() {
        return -47;
    }
}
