package src.downcast;

import java.lang.Boolean;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
public final class Furloughs<I extends Boolean, W extends I> extends Coastline {
    public final I totes;

    public Furloughs(I i) {
        super((byte) 62, new Long(-13L));
        this.totes = i;
    }

    public final <F_J> Character reduced(F_J f_j) {
        Furloughs furloughs = null;
        return new Vex(furloughs, furloughs).scums.reduced(null);
    }
}
