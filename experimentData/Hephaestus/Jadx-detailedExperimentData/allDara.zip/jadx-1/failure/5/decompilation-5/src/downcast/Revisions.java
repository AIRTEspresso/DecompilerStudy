package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
class Revisions<E, W, X> extends Groovy<Untainted> {
    public Number hoot;
    public final Bay lazaro;

    public Revisions(Bay bay, Number number) {
        super(new Long(95L), new Untainted());
        this.lazaro = bay;
        this.hoot = number;
    }
}
