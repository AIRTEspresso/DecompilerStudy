package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
final class Untainted extends Coastline {
    public Untainted() {
        super((byte) 23, new Long(15L));
    }

    public final Coastline pervades() {
        return new Untainted();
    }
}
