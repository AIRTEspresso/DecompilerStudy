package src.downcast;

import src.downcast.Furloughs;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
final class Vex<E, Q extends Furloughs<? extends Boolean, ? extends Boolean>> extends Coastline {
    public final Q chaster;
    public final Furloughs<? extends Boolean, ? extends Boolean> scums;

    public Vex(Furloughs<? extends Boolean, ? extends Boolean> furloughs, Q q) {
        super((byte) -71, Float.valueOf(10.249f));
        this.scums = furloughs;
        this.chaster = q;
    }

    public final E impelled(E e) {
        return null;
    }
}
