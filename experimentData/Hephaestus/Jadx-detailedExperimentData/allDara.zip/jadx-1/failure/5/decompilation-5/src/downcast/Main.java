package src.downcast;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
class Main {
    static Coastline decking;
    static Untainted imbroglio;
    static boolean johann;
    static final Untainted outstrip;
    static byte steel;

    Main() {
    }

    static {
        Untainted untainted = new Untainted();
        outstrip = untainted;
        imbroglio = untainted;
        Coastline pervades = untainted.pervades();
        decking = pervades;
        steel = pervades.yerevan;
        Language language = null;
        johann = language.finale.evades.reduced(Boolean.valueOf(new Furloughs(false).totes.booleanValue())).charValue() >= '2';
    }

    public static final short dioxin() {
        Boolean bool = true;
        short s = new Stability((short) -39).sneaking;
        if (bool.booleanValue()) {
            return dioxin();
        }
        return s;
    }

    public static final void appeaser() {
        Float.valueOf(32.233f);
    }

    public static final int chatting() {
        $$Lambda$Main$9wut6uzDVHcYBIHpcatnefQ1yp0 __lambda_main_9wut6uzdvhcybihpcatnefq1yp0 = new Function2() { // from class: src.downcast.-$$Lambda$Main$9wut6uzDVHcYBIHpcatnefQ1yp0
            @Override // src.downcast.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$chatting$0((Furloughs) obj, (Boolean) obj2);
            }
        };
        int chatting = chatting();
        if (((Boolean) __lambda_main_9wut6uzdvhcybihpcatnefq1yp0.apply(null, true)).booleanValue()) {
            chatting = -41;
        }
        pele();
        return chatting;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Boolean lambda$chatting$0(Furloughs furloughs, Boolean bool) {
        Language language = null;
        language.finale = null;
        return true;
    }

    public static final void pele() {
        johann = false;
        Byte.valueOf((byte) 85);
    }

    public static final void main(String[] strArr) {
        Bay bay;
        Boolean valueOf = Boolean.valueOf(johann);
        Revisions revisions = new Revisions(new Bay(new Furloughs(false)), new Long(83L));
        if (valueOf.booleanValue()) {
            bay = revisions.lazaro;
        } else {
            bay = revisions.lazaro;
        }
        bay.lodestars('P');
    }
}
