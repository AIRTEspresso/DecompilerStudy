package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
abstract class Coastline {
    public Number woodcuts;
    public byte yerevan;

    public Coastline(byte b, Number number) {
        this.yerevan = b;
        this.woodcuts = number;
    }
}
