package src.downcast;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
public abstract class Language extends Coastline {
    public Candid<Short> finale;

    public Language(Candid<Short> candid) {
        super((byte) 94, Double.valueOf(-41.167d));
        this.finale = candid;
    }
}
