package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
interface Clovers {
    double buxtehude();

    String pearling(Groovy<? extends Byte> groovy);
}
