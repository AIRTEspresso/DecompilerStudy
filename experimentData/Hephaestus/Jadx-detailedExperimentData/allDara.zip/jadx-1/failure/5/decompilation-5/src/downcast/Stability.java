package src.downcast;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
final class Stability<I, R> extends Coastline {
    public short sneaking;

    public Stability(short s) {
        super((byte) 58, new Long(-74L));
        this.sneaking = s;
    }

    public final R boogies() {
        return null;
    }

    public final I fluttered(I i, I i2) {
        Main.appeaser();
        return null;
    }
}
