package src.downcast;

import java.lang.Number;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/5/original-5/Test.dex */
public abstract class Candid<W extends Number> extends Coastline {
    public Furloughs<Boolean, Boolean> evades;
    public final W lama;

    public Candid(Furloughs<Boolean, Boolean> furloughs, W w) {
        super((byte) -16, Double.valueOf(16.202d));
        this.evades = furloughs;
        this.lama = w;
    }

    public W salacious() {
        return null;
    }

    public Character lodestars(Character ch) {
        return 'W';
    }
}
