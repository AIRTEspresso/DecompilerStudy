package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
class Smoothy<A> extends Lofted<String, String, Double> {
    public final A bayonets;
    public final A toward;

    public Smoothy(A a, A a2) {
        super((short) 31);
        this.bayonets = a;
        this.toward = a2;
    }

    public final Lofted<String, String, ? extends Sodden> linotype(Lofted<String, String, ? extends Sodden> lofted) {
        Main.serving = -69;
        return new Lofted<>((short) -27);
    }

    public A fogies(A a) {
        return null;
    }
}
