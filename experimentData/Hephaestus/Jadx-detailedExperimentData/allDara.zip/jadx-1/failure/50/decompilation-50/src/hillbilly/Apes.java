package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
class Apes extends Saar<Integer, Sodden> {
    public final Denis<Double, Byte> hectors;

    public Apes(Denis<Double, Byte> denis) {
        this.hectors = denis;
    }

    public Character quixote(Character ch) {
        return 'c';
    }
}
