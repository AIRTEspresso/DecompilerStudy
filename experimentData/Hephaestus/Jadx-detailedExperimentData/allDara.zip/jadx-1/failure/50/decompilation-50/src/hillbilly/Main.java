package src.hillbilly;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
class Main {
    static Sodden bultmann;
    static Integer coddles;
    static final Saar<? extends Float, ? extends Number> goddard;
    static Integer handsome;
    static Integer serving;

    Main() {
    }

    static {
        Sodden sodden = new Sodden(12);
        bultmann = sodden;
        Integer num = sodden.bedtime;
        handsome = num;
        coddles = num;
        serving = num;
        goddard = new Saar<>();
    }

    public static final <F_U> F_U worry(F_U f_u) {
        Schneider schneider = new Schneider(null);
        coddles = bultmann.bedtime;
        return (F_U) schneider.phillip;
    }

    public static final String scruples(String str, Character ch) {
        Voyaged voyaged = null;
        String scruples = scruples("mortified", voyaged.unknowing);
        new Clergies(new Navigable(new Sodden(62), new Saar()), new Navigable(new Sodden(29), new Saar())).enhanced.snuffing(Double.valueOf(-25.946d));
        return scruples;
    }

    public static final Double wizard() {
        double d;
        Boolean bool = true;
        if (Boolean.valueOf(Double.valueOf(31.806d).doubleValue() < -22.0d).booleanValue()) {
            d = -71.551d;
        } else if (bool.booleanValue()) {
            d = -32.688d;
        } else {
            d = 62.508d;
        }
        return Double.valueOf(d);
    }

    public static final void main(String[] strArr) {
        Boolean bool = false;
        Serous serous = new Serous();
        if (bool.booleanValue()) {
        }
        Saar<? super Byte, Integer> saar = serous.gawkily((byte) 74, 50).scares.hectors.falloff;
    }
}
