package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
final class Serous extends Melded {
    public Serous() {
        super(new Apes(null));
    }

    public final Melded gawkily(byte b, Integer num) {
        return new Serous();
    }

    @Override // src.hillbilly.Melded
    public Sodden buffed(Sodden sodden) {
        return Main.bultmann;
    }
}
