package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
class Saar<U, C> {
    public final U reissuing(Number number) {
        $$Lambda$Saar$OZpxBAT5KDANBbZrJBfNDQ5s6gQ __lambda_saar_ozpxbat5kdanbbzrjbfndq5s6gq = new Function2() { // from class: src.hillbilly.-$$Lambda$Saar$OZpxBAT5KDANBbZrJBfNDQ5s6gQ
            @Override // src.hillbilly.Function2
            public final Object apply(Object obj, Object obj2) {
                return Saar.lambda$reissuing$0((Float) obj, (Float) obj2);
            }
        };
        Float valueOf = Float.valueOf(58.366f);
        return (U) __lambda_saar_ozpxbat5kdanbbzrjbfndq5s6gq.apply(valueOf, valueOf);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Object lambda$reissuing$0(Float f, Float f2) {
        return null;
    }
}
