package src.hillbilly;

import java.lang.Long;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
final class Clergies<J extends Long, S extends J, Y extends J> extends Lofted<String, String, Y> {
    public final Navigable enhanced;
    public final Navigable sin;

    public Clergies(Navigable navigable, Navigable navigable2) {
        super((short) 8);
        this.enhanced = navigable;
        this.sin = navigable2;
    }

    /* JADX WARN: Incorrect return type in method signature: (FTY;)TY; */
    public final Long bells(float f, Long l) {
        return null;
    }

    public final Long haymows(Long l, long j) {
        return Long.valueOf(j);
    }
}
