package src.hillbilly;

import java.lang.String;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
class Lofted<E extends String, U extends E, F> extends Saar<E, F> {
    public final short girt;

    public Lofted(short s) {
        this.girt = s;
    }
}
