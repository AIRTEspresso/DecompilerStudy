package src.hillbilly;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
abstract class Denis<B extends Double, A> extends Voyaged {
    public Saar<? super Byte, Integer> falloff;
    public final Character unknowing;

    public Denis(Saar<? super Byte, Integer> saar, Character ch) {
        super('S', Float.valueOf(-10.74f));
        this.falloff = saar;
        this.unknowing = ch;
    }

    @Override // src.hillbilly.Voyaged
    public Double runnels(Integer num, Character ch) {
        return Double.valueOf(57.315d);
    }
}
