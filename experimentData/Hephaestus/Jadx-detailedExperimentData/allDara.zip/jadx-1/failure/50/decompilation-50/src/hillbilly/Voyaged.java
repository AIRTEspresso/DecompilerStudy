package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
abstract class Voyaged extends Saar<Long, Float> {
    public final Float chignons;
    public final Character unknowing;

    public abstract Double runnels(Integer num, Character ch);

    public Voyaged(Character ch, Float f) {
        this.unknowing = ch;
        this.chignons = f;
    }
}
