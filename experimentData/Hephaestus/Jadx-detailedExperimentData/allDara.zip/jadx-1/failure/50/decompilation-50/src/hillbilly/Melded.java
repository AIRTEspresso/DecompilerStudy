package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
abstract class Melded extends Lofted<String, String, Voyaged> {
    public Apes scares;

    public abstract Sodden buffed(Sodden sodden);

    public Melded(Apes apes) {
        super((short) 5);
        this.scares = apes;
    }

    public <F_D extends Boolean> F_D sisal() {
        F_D f_d = null;
        Main.serving = 95;
        return f_d;
    }
}
