package src.hillbilly;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/50/original-50/Test.dex */
final class Navigable extends Saar<Voyaged, String> {
    public final Sodden hove;
    public Saar<? super Double, ? extends Short> today;

    public Navigable(Sodden sodden, Saar<? super Double, ? extends Short> saar) {
        this.hove = sodden;
        this.today = saar;
    }

    public final void snuffing(Double d) {
        Boolean.valueOf(false);
    }
}
