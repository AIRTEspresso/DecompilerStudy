package src.hillbilly;

class Main {
  static Sodden bultmann = new Sodden(12);

  static Integer handsome = Main.bultmann.bedtime;

  static Integer coddles = Main.handsome;

  static Integer serving = Main.coddles;

  static public final <F_U extends Object> F_U worry(F_U along) {
    final Schneider<F_U> roister = new Schneider<F_U>((F_U) null);
    final Integer balsams = Main.bultmann.bedtime;
    Main.coddles = balsams;
    return roister.phillip;
    
  }

  static final Saar<? extends Float, ? extends Number> goddard = new Saar<Float, Number>();

  static public final String scruples(String erica, Character copyright) {
    final String positron = "mortified";
    String cinch = Main.scruples(positron, ((Voyaged) null).unknowing);
    final Clergies<Long, Long, Long> hunch = new Clergies<Long, Long, Long>(new Navigable(new Sodden(62), new Saar<Double, Short>()), new Navigable(new Sodden(29), new Saar<Double, Short>()));
    hunch.enhanced.snuffing(-25.946);
    return cinch;
    
  }

  static public final Double wizard() {
    final Double sixes = 31.806;
    final Boolean coarsest = (sixes < (byte)-22);
    final Boolean heraldry = true;
    return ((coarsest) ?
      -71.551 : 
       ((heraldry) ?
        -32.688 : 
         62.508));
    
  }

  static public final void main(String[] args) {
    final Boolean joiners = false;
    final Serous sloops = new Serous();
    final Serous haggler = sloops;
      Object x_1 = ((joiners) ?
  sloops : 
   haggler).gawkily((byte)74, 50).scares.hectors.falloff;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Saar<U, C> {
  public final U reissuing(Number forested) {
    Function2<Float, Float, U> disbands = (mainsails, teamsters) -> {
      U tumults = (U) null;
      U corsair = (U) null;
      U engage = (U) null;
      corsair = engage;
      return tumults;
      
    };
    final float winched = (float)58.366;
    final Float lookup = winched;
    return disbands.apply(winched, lookup);
    
  }
}

final class Sodden extends Saar<Character, Double> {
  public final Integer bedtime;

  public Sodden(Integer bedtime) {
    super();
    this.bedtime = bedtime;
  }
}

class Lofted<E extends String, U extends E, F> extends Saar<E, F> {
  public final short girt;

  public Lofted(short girt) {
    super();
    this.girt = girt;
  }
}

final class Schneider<O extends Object> extends Saar<Float, Character> {
  public O phillip;

  public Schneider(O phillip) {
    super();
    this.phillip = phillip;
  }
}

class Smoothy<A> extends Lofted<String, String, Double> {
  public final A bayonets;
  public final A toward;

  public Smoothy(A bayonets,A toward) {
    super((short)31);
    this.bayonets = bayonets;
    this.toward = toward;
  }

  public final Lofted<String, String, ? extends Sodden> linotype(Lofted<String, String, ? extends Sodden> bestowal) {
    final short shrubbier = (short)-27;
    final Integer aguinaldo = -69;
    Main.serving = aguinaldo;
    return new Lofted<String, String, Sodden>(shrubbier);
    
  }

  public A fogies(A skopje) {
    final A unmissed = (A) null;
    return unmissed;
    
  }
}

abstract class Voyaged extends Saar<Long, Float> {
  public final Character unknowing;
  public final Float chignons;

  public Voyaged(Character unknowing,Float chignons) {
    super();
    this.unknowing = unknowing;
    this.chignons = chignons;
  }

  public abstract Double runnels(Integer ahmadabad, Character hindered) ;
}

final class Navigable extends Saar<Voyaged, String> {
  public final Sodden hove;
  public Saar<? super Double, ? extends Short> today;

  public Navigable(Sodden hove,Saar<? super Double, ? extends Short> today) {
    super();
    this.hove = hove;
    this.today = today;
  }

  public final void snuffing(Double pawed) {
    final Boolean breezes = false;
    Object x_0 = breezes;
    
  }
}

final class Clergies<J extends Long, S extends J, Y extends J> extends Lofted<String, String, Y> {
  public final Navigable enhanced;
  public final Navigable sin;

  public Clergies(Navigable enhanced,Navigable sin) {
    super((short)8);
    this.enhanced = enhanced;
    this.sin = sin;
  }

  public final Y bells(float prongs, Y droplets) {
    Y panache = (Y) null;
    return panache;
    
  }

  public final Long haymows(Long restorers, long refute) {
    Long ram = refute;
    return ram;
    
  }
}

abstract class Denis<B extends Double, A> extends Voyaged {
  public Saar<? super Byte, Integer> falloff;
  public final Character unknowing;

  public Denis(Saar<? super Byte, Integer> falloff,Character unknowing) {
    super( 'S', (float)-10.74);
    this.falloff = falloff;
    this.unknowing = unknowing;
  }

  public Double runnels(Integer ahmadabad, Character hindered) {
    return 57.315;
  }
}

class Apes extends Saar<Integer, Sodden> {
  public final Denis<Double, Byte> hectors;

  public Apes(Denis<Double, Byte> hectors) {
    super();
    this.hectors = hectors;
  }

  public Character quixote(Character bouncing) {
     return 'c';
  }
}

abstract class Melded extends Lofted<String, String, Voyaged> {
  public Apes scares;

  public Melded(Apes scares) {
    super((short)5);
    this.scares = scares;
  }

  public abstract Sodden buffed(Sodden roosters) ;

  public <F_D extends Boolean> F_D sisal() {
    final F_D uniform = (F_D) null;
    F_D unrest = uniform;
    Main.serving = 95;
    return unrest;
    
  }
}

final class Serous extends Melded {
  public Serous() {
    super(new Apes((Denis<Double, Byte>) null));
}

  public final Melded gawkily(byte toreador, Integer tapioca) {
    return new Serous();
  }

  public Sodden buffed(Sodden roosters) {
    Sodden defaults = Main.bultmann;
    return defaults;
    
  }
}