package src.rosie;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
public final class Stylizes<N, A, X extends A> implements Fool {
    public final void adjudged() {
        Integer.valueOf(-89);
    }

    @Override // src.rosie.Fool
    public Object finnegan() {
        return Main.withered;
    }

    @Override // src.rosie.Shortcut
    public double book(Number number) {
        return -69.866d;
    }

    @Override // src.rosie.Fool
    public Quivers<? extends Float, ? extends Float> frat(Quivers<? extends Float, ? extends Float> quivers) {
        new Bohemia(null, -21.705d).redolence(null, new Bohemia(Double.valueOf(30.249d), -87.61d));
        return quivers;
    }
}
