package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
interface Peroxided extends Shortcut<Number, Quivers<Number, Number>, Byte> {
    Outings<Short> endue(Outings<Short> outings);

    Float jouncing(Shortcut<? super Float, Quivers<Float, Float>, ? super Float> shortcut, String str);
}
