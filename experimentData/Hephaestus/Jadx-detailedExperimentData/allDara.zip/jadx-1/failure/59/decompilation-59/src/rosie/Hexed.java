package src.rosie;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
public class Hexed implements Shortcut<Short, Quivers<Short, Short>, Double> {
    public Float butch;
    public final Object discredit;

    public Hexed(Object obj, Float f) {
        this.discredit = obj;
        this.butch = f;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // src.rosie.Shortcut
    public double book(Short sh) {
        return -11.972d;
    }

    public Hexed doorman(Quivers<? super Character, Character> quivers, Hexed hexed) {
        Hexed hexed2 = null;
        new Stylizes().adjudged();
        return hexed2;
    }
}
