package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
final class Quivers<G, I extends G> {
    public G augurs;
    public I prompted;

    public Quivers(I i, G g) {
        this.prompted = i;
        this.augurs = g;
    }
}
