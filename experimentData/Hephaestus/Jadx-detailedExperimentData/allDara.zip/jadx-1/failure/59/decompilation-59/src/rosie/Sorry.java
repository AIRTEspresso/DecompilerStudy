package src.rosie;

import java.lang.Short;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
abstract class Sorry<H extends Short, C, I> extends Hexed {
    public boolean customize;
    public final Drivel<? extends I, ? extends C> tommy;

    public Sorry(Drivel<? extends I, ? extends C> drivel, boolean z) {
        super(new Object(), Float.valueOf(-51.592f));
        this.tommy = drivel;
        this.customize = z;
    }
}
