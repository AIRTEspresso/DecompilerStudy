package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
class Optioned<X, D extends X> implements Fool {
    Optioned() {
    }

    @Override // src.rosie.Fool
    public Object finnegan() {
        Object obj = new Object();
        Peroxided peroxided = null;
        peroxided.jouncing(null, "filial");
        $$Lambda$Optioned$d2yNLr2xhQ8Np8eyCG1yxjrC6h0 __lambda_optioned_d2ynlr2xhq8np8eycg1yxjrc6h0 = new Function0() { // from class: src.rosie.-$$Lambda$Optioned$d2yNLr2xhQ8Np8eyCG1yxjrC6h0
            @Override // src.rosie.Function0
            public final Object apply() {
                return Optioned.lambda$finnegan$0();
            }
        };
        return new Hexed(obj, ((Austrians) __lambda_optioned_d2ynlr2xhq8np8eycg1yxjrc6h0.apply()).mining.doorman(null, (Hexed) __lambda_optioned_d2ynlr2xhq8np8eycg1yxjrc6h0.apply()).butch).discredit;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Austrians lambda$finnegan$0() {
        Austrians austrians = new Austrians(new Hexed(new Object(), Float.valueOf(20.128f)));
        austrians.butch = Float.valueOf(-20.916f);
        return austrians;
    }

    @Override // src.rosie.Shortcut
    public double book(Number number) {
        return Main.mound.doubleValue();
    }

    @Override // src.rosie.Fool
    public Quivers<? extends Float, ? extends Float> frat(Quivers<? extends Float, ? extends Float> quivers) {
        return new Quivers<>(new Austrians(new Hexed(new Object(), Float.valueOf(50.693f))).butch, Float.valueOf(-20.684f));
    }
}
