package src.rosie;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
class Main {
    static String closures;
    static final String jays;
    static final Double mound;
    static Double withered;

    Main() {
    }

    public static final Integer fer(char c) {
        return fer(((Character) new Function1() { // from class: src.rosie.-$$Lambda$Main$PhdmbAkxkWld-MHJnmx1q8m9JV0
            @Override // src.rosie.Function1
            public final Object apply(Object obj) {
                return Main.lambda$fer$0(obj);
            }
        }.apply("arouses")).charValue());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Character lambda$fer$0(Object obj) {
        return '4';
    }

    public static final double slouchy() {
        Boolean.valueOf(false);
        new Drivel();
        new Drivel().asbestos();
        return 20.271d;
    }

    public static final <F_E> String iguanas(F_E f_e) {
        Boolean bool = false;
        if (bool.booleanValue()) {
            return "pizzeria";
        }
        return "bosun";
    }

    static {
        String iguanas = iguanas(92);
        closures = iguanas;
        jays = iguanas;
        Double valueOf = Double.valueOf(65.565d);
        mound = valueOf;
        withered = valueOf;
    }

    public static final <F_I, F_H extends F_I, F_E extends F_H> Drivel<? extends F_I, ? extends F_H> lives(F_E f_e) {
        Sorry sorry = null;
        return (Drivel<? extends F_I, ? extends F_H>) sorry.tommy;
    }

    public static final Optioned<? extends Integer, ? extends Integer> leveling(Optioned<? extends Integer, ? extends Integer> optioned) {
        double d;
        Boolean bool = true;
        Double valueOf = Double.valueOf(-25.268d);
        Sorry sorry = null;
        if (sorry.customize) {
            if (bool.booleanValue()) {
                d = valueOf.doubleValue();
            } else {
                d = 42.103d;
            }
        } else {
            d = -46.663d;
        }
        withered = Double.valueOf(d);
        return optioned;
    }

    public static final void main(String[] strArr) {
        Double.valueOf(slouchy());
    }
}
