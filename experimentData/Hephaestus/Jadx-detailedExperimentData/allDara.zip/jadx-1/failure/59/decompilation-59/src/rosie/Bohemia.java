package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
final class Bohemia<L, V, I extends L> implements Fool {
    public final L broadside;
    public double prejudged;

    public Bohemia(L l, double d) {
        this.broadside = l;
        this.prejudged = d;
    }

    public final void redolence(Stylizes<Boolean, Long, Long> stylizes, L l) {
        Outings outings = null;
        this.prejudged = 53.733d;
        outings.funky((short) -23, (short) 73);
    }

    @Override // src.rosie.Fool
    public Object finnegan() {
        String str = Main.jays;
        Main.withered = Double.valueOf(-22.387d);
        return str;
    }

    @Override // src.rosie.Fool
    public Quivers<? extends Float, ? extends Float> frat(Quivers<? extends Float, ? extends Float> quivers) {
        Float valueOf = Float.valueOf(71.991f);
        quivers.prompted = null;
        return new Quivers<>(Float.valueOf(11.374f), valueOf);
    }

    @Override // src.rosie.Shortcut
    public double book(Number number) {
        return -64.314d;
    }
}
