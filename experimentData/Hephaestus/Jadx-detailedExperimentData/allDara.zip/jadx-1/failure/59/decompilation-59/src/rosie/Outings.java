package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
abstract class Outings<N> implements Shortcut<N, Quivers<N, N>, N> {
    public abstract void funky(N n, N n2);

    Outings() {
    }

    @Override // src.rosie.Shortcut
    public double book(N n) {
        return -22.62d;
    }
}
