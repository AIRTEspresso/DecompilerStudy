package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
interface Fool extends Shortcut<Number, Quivers<Number, Number>, Byte> {
    Object finnegan();

    Quivers<? extends Float, ? extends Float> frat(Quivers<? extends Float, ? extends Float> quivers);
}
