package src.rosie;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
final class Drivel<L, G> {
    public final void asbestos() {
        Byte[] bArr = new Byte[0];
        Byte[] bArr2 = (Byte[]) new Object[]{(byte) -62, (byte) 80, (byte) 86};
    }
}
