package src.rosie;

import java.lang.Character;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
interface Stripped<W extends Character> extends Shortcut<W, Quivers<W, W>, W> {
    void angering(W w);
}
