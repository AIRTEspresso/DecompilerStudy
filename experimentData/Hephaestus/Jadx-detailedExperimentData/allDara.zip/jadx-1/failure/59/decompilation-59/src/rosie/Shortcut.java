package src.rosie;

import src.rosie.Quivers;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
interface Shortcut<T, S extends Quivers<T, ? super T>, U> {
    double book(T t);
}
