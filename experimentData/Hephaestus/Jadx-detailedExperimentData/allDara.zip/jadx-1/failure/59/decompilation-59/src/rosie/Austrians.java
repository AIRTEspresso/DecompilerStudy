package src.rosie;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/59/original-59/Test.dex */
public class Austrians extends Hexed {
    public Hexed mining;

    public Austrians(Hexed hexed) {
        super(new Object(), Float.valueOf(-48.977f));
        this.mining = hexed;
    }

    @Override // src.rosie.Hexed
    public final Hexed doorman(Quivers<? super Character, Character> quivers, Hexed hexed) {
        return new Hexed(new Object(), Float.valueOf(-19.9f));
    }

    @Override // src.rosie.Hexed, src.rosie.Shortcut
    public final double book(Short sh) {
        Stripped stripped = null;
        stripped.angering('n');
        return 35.805d;
    }
}
