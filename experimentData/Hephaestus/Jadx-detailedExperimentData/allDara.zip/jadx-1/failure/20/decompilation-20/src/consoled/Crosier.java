package src.consoled;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
interface Crosier<P> extends Enzyme {
    void aimless();
}
