package src.consoled;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
public class Main {
    static final Worksheet<Long> aeschylus;
    static final Repulsing filigree = null;
    static Integer guesswork;
    static final Worksheet<Long> overtone;
    static char showiest;

    Main() {
    }

    public static final boolean efface(boolean z, Integer num) {
        Boolean bool = false;
        Boolean bool2 = true;
        Repulsing repulsing = null;
        repulsing.domiciles('s', new Apollos(new Apollos(44).distorted).distorted);
        return bool.booleanValue() || bool2.booleanValue();
    }

    public static final float secluded(long j) {
        Boolean bool = false;
        surfs();
        if (bool.booleanValue()) {
            return -29.926f;
        }
        return 37.314f;
    }

    public static final void surfs() {
        new Object();
        Character.valueOf('C');
        Character.valueOf('D');
    }

    public static final Integer polar(Long l) {
        Integer polar = polar(l);
        Long.valueOf(-73L);
        return polar;
    }

    static {
        char c;
        Worksheet<Long> worksheet = new Worksheet<>(filigree);
        aeschylus = worksheet;
        overtone = worksheet;
        guesswork = polar(new Missal(-14L, overtone.cadmium).gnarl);
        if (efface(false, 79)) {
            c = new Inoculate('O').swastika;
        } else {
            c = new Inoculate('n').swastika;
        }
        showiest = c;
    }

    public static final Exerts<String, ? extends Long> seraphs() {
        Boolean bool = false;
        Enzyme enzyme = null;
        guesswork = polar(new Missal(-90L, new Object()).gnarl);
        if (bool.booleanValue()) {
        }
        return enzyme.giants('z', null).moldiest;
    }

    public static final void mead(Exerts<String, ? extends Object> exerts) {
        Boolean bool = false;
        Double valueOf = Double.valueOf(38.228d);
        Double valueOf2 = Double.valueOf(81.19d);
        if (!bool.booleanValue()) {
            valueOf = valueOf2;
        }
        Boolean.valueOf(valueOf.doubleValue() <= 31.0d);
    }

    public static final Long pushes() {
        return -7L;
    }

    public static final void tearooms() {
        Integer.valueOf(-57);
    }

    public static final Object[] evidently() {
        if (Boolean.valueOf(Double.valueOf(59.473d) == Double.valueOf(70.205d)).booleanValue()) {
            return evidently();
        }
        Overstay overstay = null;
        return overstay.nominates;
    }

    public static final boolean tiff() {
        $$Lambda$Main$72o25nU6jd40Lt1GKRizry74cS8 __lambda_main_72o25nu6jd40lt1gkrizry74cs8 = new Function2() { // from class: src.consoled.-$$Lambda$Main$72o25nU6jd40Lt1GKRizry74cS8
            @Override // src.consoled.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$tiff$0((Apollos) obj, (Exerts) obj2);
            }
        };
        new Missal(-45L, (byte) -40);
        ((Byte) __lambda_main_72o25nu6jd40lt1gkrizry74cs8.apply(new Effacing(new Missal(45L, (byte) 18), (byte) 98).regale(new Long(45L)), null)).byteValue();
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Byte lambda$tiff$0(Apollos apollos, Exerts exerts) {
        new Inoculate('S').swastika = 'r';
        return (byte) 56;
    }

    public static final void aurelia(Integer num, String str) {
        Short.valueOf((short) -53);
        guesswork = -46;
    }

    public static final void main(String[] strArr) {
        Long.valueOf(-34L);
    }
}
