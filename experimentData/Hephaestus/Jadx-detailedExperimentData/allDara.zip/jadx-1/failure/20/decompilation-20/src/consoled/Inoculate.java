package src.consoled;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
public final class Inoculate implements Enzyme {
    public char swastika;

    public Inoculate(char c) {
        this.swastika = c;
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        new Maims().nunez(new Missal(-1L, null), Double.valueOf(-79.77d));
        return 'F';
    }

    @Override // src.consoled.Enzyme
    public Extravert<Long> giants(char c, Short[] shArr) {
        return new Extravert<>(null, Main.filigree);
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Main.tearooms();
        Boolean.valueOf(false);
    }
}
