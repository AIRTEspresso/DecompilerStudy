package src.consoled;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
class Disarm extends Exerts<String, Short> {
    public final String demented;

    public Disarm(String str) {
        this.demented = str;
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        int i;
        Boolean bool = true;
        if (bool.booleanValue()) {
            i = -32;
        } else {
            i = -81;
        }
        int i2 = (i > 20.39d ? 1 : (i == 20.39d ? 0 : -1));
        Boolean.valueOf(false);
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        Boolean bool2 = false;
        Main.mead(null);
        if (bool2.booleanValue()) {
            return '5';
        }
        return 'm';
    }
}
