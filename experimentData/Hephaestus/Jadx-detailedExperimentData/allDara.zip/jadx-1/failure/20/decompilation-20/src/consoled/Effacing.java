package src.consoled;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
class Effacing extends Exerts<String, Float> {
    public byte bunsen;
    public Missal<? super Character, ? extends Byte, Float> spooking;

    public Effacing(Missal<? super Character, ? extends Byte, Float> missal, byte b) {
        this.spooking = missal;
        this.bunsen = b;
    }

    public final Apollos regale(Number number) {
        Apollos apollos = new Apollos(-28);
        new Function0() { // from class: src.consoled.-$$Lambda$Effacing$08hNNO72FwsqBaZP9wEAHSw-CUw
            @Override // src.consoled.Function0
            public final Object apply() {
                return Effacing.lambda$regale$0();
            }
        }.apply();
        return apollos;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$regale$0() {
        new Inoculate('d');
        Main.aurelia(-86, "felon");
        return null;
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Worksheet<Long> worksheet = Main.overtone;
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        this.bunsen = (byte) 12;
        return 'g';
    }
}
