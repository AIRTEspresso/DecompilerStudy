package src.consoled;

import java.lang.String;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
abstract class Exerts<J extends String, Q> implements Repulsing {
    public void omelet() {
    }
}
