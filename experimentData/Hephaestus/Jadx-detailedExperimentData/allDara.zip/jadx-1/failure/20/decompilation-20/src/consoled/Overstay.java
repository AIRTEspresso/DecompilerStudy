package src.consoled;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
abstract class Overstay extends Worksheet<Byte> {
    public final Repulsing cadmium;
    public Object[] nominates;

    public Overstay(Object[] objArr, Repulsing repulsing) {
        super(null);
        this.nominates = objArr;
        this.cadmium = repulsing;
    }

    @Override // src.consoled.Worksheet, src.consoled.Repulsing
    public final Character dieresis(boolean z, Boolean bool) {
        return '6';
    }

    @Override // src.consoled.Worksheet, src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Main.showiest = 'E';
        Integer.valueOf(-38);
    }
}
