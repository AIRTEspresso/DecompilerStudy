package src.consoled;

import src.consoled.Missal;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
class Maims<M extends Missal<? extends Character, Enzyme, ? super Float>, V> implements Enzyme {
    public final void nunez(M m, V v) {
    }

    @Override // src.consoled.Enzyme
    public Extravert<Long> giants(char c, Short[] shArr) {
        return new Extravert<>(null, null);
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Crosier crosier = null;
        crosier.aimless();
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        return 'N';
    }
}
