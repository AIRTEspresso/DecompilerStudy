package src.consoled;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
public class Worksheet<Q> implements Repulsing {
    public final Repulsing cadmium;

    public Worksheet(Repulsing repulsing) {
        this.cadmium = repulsing;
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        Exerts exerts = null;
        exerts.omelet();
        return 'k';
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Short.valueOf((short) -82);
    }
}
