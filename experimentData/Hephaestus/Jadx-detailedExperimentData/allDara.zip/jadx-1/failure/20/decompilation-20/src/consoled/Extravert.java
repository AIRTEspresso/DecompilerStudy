package src.consoled;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
final class Extravert<Y> extends Worksheet<Y> {
    public final Repulsing cadmium;
    public final Exerts<String, ? extends Long> moldiest;

    public Extravert(Exerts<String, ? extends Long> exerts, Repulsing repulsing) {
        super(new Worksheet(null));
        this.moldiest = exerts;
        this.cadmium = repulsing;
    }

    @Override // src.consoled.Worksheet, src.consoled.Repulsing
    public final Character dieresis(boolean z, Boolean bool) {
        return 'F';
    }

    @Override // src.consoled.Worksheet, src.consoled.Repulsing
    public final void domiciles(Character ch, Integer num) {
        Character.valueOf('T');
        Main.guesswork = new Apollos(-91).distorted;
    }
}
