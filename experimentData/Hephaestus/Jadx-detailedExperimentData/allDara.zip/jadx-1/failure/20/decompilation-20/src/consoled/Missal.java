package src.consoled;

import java.lang.Character;
import java.lang.Float;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
final class Missal<B extends Character, Z, W extends Float> implements Repulsing {
    public final Long gnarl;
    public final Z worry;

    public Missal(Long l, Z z) {
        this.gnarl = l;
        this.worry = z;
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        return null;
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Byte.valueOf((byte) 5);
    }
}
