package src.consoled;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/20/original-20/Test.dex */
final class Apollos implements Repulsing {
    public final Integer distorted;

    public Apollos(Integer num) {
        this.distorted = num;
    }

    @Override // src.consoled.Repulsing
    public Character dieresis(boolean z, Boolean bool) {
        return 'l';
    }

    @Override // src.consoled.Repulsing
    public void domiciles(Character ch, Integer num) {
        Byte.valueOf((byte) -92);
        Byte.valueOf((byte) 37);
        Short.valueOf((short) -14);
    }
}
