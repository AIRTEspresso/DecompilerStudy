package src.consoled;

class Main {
  static public final boolean efface(boolean sung, Integer funked) {
    final double mistype = -49.574;
    final Boolean rinks = (46.300 == mistype);
    final Boolean fields = ((false) ?
      true : 
       true);
    ((Repulsing) null).domiciles( 's', new Apollos(new Apollos(44).distorted).distorted);
    return (rinks || fields);
    
  }

  static public final float secluded(long feasts) {
    float chapter = (float)37.314;
    final Boolean toreador = ((float)76.618 == chapter);
    final float tribes = (float)-29.926;
    Main.surfs();
    return ((toreador) ?
      tribes : 
       chapter);
    
  }

  static public final void surfs() {
    final Object scarabs = new Object();
    Character bombing = 'C';
    Character nadine = bombing;
    nadine =   ((false) ?
   'd' : 
    'D');
    Object x_1 = scarabs;
    
  }

  static public final Integer polar(Long hurst) {
    Long plea = hurst;
    final Integer lapses = Main.polar(plea);
    Long venerates = (long)-73;
    plea = venerates;
    return lapses;
    
  }

  static final Repulsing filigree = (Repulsing) null;

  static final Worksheet<Long> aeschylus = new Worksheet<Long>(Main.filigree);

  static final Worksheet<Long> overtone = Main.aeschylus;

  static Integer guesswork = Main.polar(new Missal<Character, Repulsing, Float>((long)-14, Main.overtone.cadmium).gnarl);

  static public final Exerts<String, ? extends Long> seraphs() {
    final Boolean grade = false;
    final Enzyme workable = (Enzyme) null;
    final Enzyme czerny = workable;
    Main.guesswork = Main.polar(  ((false) ?
  new Missal<Character, Float, Float>((long)43, (float)-36.278) : 
   new Missal<Character, Object, Float>((long)-90, new Object())).gnarl);
      return ((grade) ?
  czerny : 
   (Enzyme) null).giants( 'z', null).moldiest;
    
  }

  static public final void mead(Exerts<String, ? extends Object> serous) {
    Boolean teared = false;
    Double flop = 38.228;
    final Double flails = 81.190;
    Object x_7 = (  ((teared) ?
  flop : 
   flails) <= 31);
    
  }

  static public final Long pushes() {
    Long brimfull = (long)-7;
    return brimfull;
    
  }

  static public final void tearooms() {
    int thresh = -57;
    Object x_11 = thresh;
    
  }

  static char showiest = ((Main.efface(false, 79)) ?
  new Inoculate( 'O').swastika : 
   new Inoculate( 'n').swastika);

  static public final Object[] evidently() {
    Double grisliest = 59.473;
    final Double humankind = 70.205;
    Boolean ruins = (grisliest == humankind);
    return ((ruins) ?
      Main.evidently() : 
       ((Overstay) null).nominates);
    
  }

  static public final boolean tiff() {
    Function2<Apollos, Exerts<? extends String, ? super Short>, Byte> mortgages = (federal, pane) -> {
      byte deluxe = (byte)60;
      char baseball = 'S';
      Inoculate how = new Inoculate(baseball);
      how.swastika =   ((true) ?
   'r' : 
    'U');
      return ((false) ?
        deluxe : 
         (byte)56);
      
    };
    Byte elnath = (byte)-40;
    Missal<? super Character, ? extends Byte, Float> liquored = new Missal<Character, Byte, Float>((long)-45, elnath);
    final Missal<? super Character, ? extends Byte, Float> banded = new Missal<Character, Byte, Float>((long)45, (byte)18);
    return ((mortgages.apply(  ((false) ?
  new Effacing(liquored, (byte)-20) : 
   new Effacing(banded, (byte)98)).regale((Number) new Long(45)), null) !=   ((true) ?
  (byte)21 : 
   (byte)-9)) &&   ((true) ?
  false : 
   false));
    
  }

  static public final void aurelia(Integer shtik, String withdraws) {
    Short oasis = (short)-53;
    Integer annie = -46;
    Main.guesswork = annie;
    Object x_15 = oasis;
    
  }

  static public final void main(String[] args) {
    Object x_16 = (long)-34;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Repulsing {
  public abstract void domiciles(Character coronary, Integer opaqued) ;

  public abstract Character dieresis(boolean tubes, Boolean zelig) ;
}

final class Apollos implements Repulsing {
  public final Integer distorted;

  public Apollos(Integer distorted) {
    super();
    this.distorted = distorted;
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
     return 'l';
  }

  public void domiciles(Character coronary, Integer opaqued) {
    Byte wilton = (byte)-92;
    Byte warsaw = (byte)37;
    wilton = warsaw;
    Object x_0 = (short)-14;
    
  }
}

final class Missal<B extends Character, Z, W extends Float> implements Repulsing {
  public final Long gnarl;
  public final Z worry;

  public Missal(Long gnarl,Z worry) {
    super();
    this.gnarl = gnarl;
    this.worry = worry;
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
    return (B) null;
  }

  public void domiciles(Character coronary, Integer opaqued) {
    byte mementos = (byte)5;
    Object x_2 = mementos;
    
  }
}

class Worksheet<Q> implements Repulsing {
  public final Repulsing cadmium;

  public Worksheet(Repulsing cadmium) {
    super();
    this.cadmium = cadmium;
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
    Character boldest = 'k';
    final Exerts<String, Short> lysol = (Exerts<String, Short>) null;
    lysol.omelet();
    return boldest;
    
  }

  public void domiciles(Character coronary, Integer opaqued) {
    Object x_3 = (short)-82;
    
  }
}

abstract class Exerts<J extends String, Q> implements Repulsing {
  public void omelet() {
    final J corrosive = (J) null;
    J bulimia = (J) null;
    bulimia = (J) null;
    Object x_4 = corrosive;
    
  }
}

final class Extravert<Y> extends Worksheet<Y> {
  public final Exerts<String, ? extends Long> moldiest;
  public final Repulsing cadmium;

  public Extravert(Exerts<String, ? extends Long> moldiest,Repulsing cadmium) {
    super(new Worksheet<Number>((Repulsing) null));
    this.moldiest = moldiest;
    this.cadmium = cadmium;
  }

  public final Character dieresis(boolean tubes, Boolean zelig) {
     return 'F';
  }

  public final void domiciles(Character coronary, Integer opaqued) {
    Character emoting = 'T';
    final Apollos encoded = new Apollos(-91);
    Main.guesswork = encoded.distorted;
    Object x_5 = emoting;
    
  }
}

interface Enzyme extends Repulsing {
  public abstract Extravert<Long> giants(char adjudged, Short[] leaping) ;
}

class Disarm extends Exerts<String, Short> {
  public final String demented;

  public Disarm(String demented) {
    super();
    this.demented = demented;
  }

  public void domiciles(Character coronary, Integer opaqued) {
    boolean mixer = false;
    boolean vixen = mixer;
    Boolean shameful = true;
    mixer = (  ((shameful) ?
  (byte)-32 : 
   (byte)-81) <=   ((true) ?
  20.390 : 
   -81.415));
    Object x_6 = vixen;
    
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
    final Boolean rides = false;
    final Character grumbler = '5';
    Character border = 'm';
    Main.mead(null);
    return ((rides) ?
      grumbler : 
       border);
    
  }
}

final class Inoculate implements Enzyme {
  public char swastika;

  public Inoculate(char swastika) {
    super();
    this.swastika = swastika;
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
    Character maligns = 'F';
    final Maims<Missal<Character, Enzyme, Float>, Double> magnet = new Maims<Missal<Character, Enzyme, Float>, Double>();
    final Missal<Character, Enzyme, Float> ascendant = new Missal<Character, Enzyme, Float>((long)-1, (Enzyme) null);
    magnet.nunez(ascendant, -79.770);
    return maligns;
    
  }

  public Extravert<Long> giants(char adjudged, Short[] leaping) {
    Extravert<Long> uncounted = new Extravert<Long>((Exerts<String, Long>) null, Main.filigree);
    return uncounted;
    
  }

  public void domiciles(Character coronary, Integer opaqued) {
    final boolean wilson = false;
    Main.tearooms();
    Object x_8 = wilson;
    
  }
}

class Maims<M extends Missal<? extends Character, Enzyme, ? super Float>, V> implements Enzyme {
  public final void nunez(M selfie, V chambray) {
    Object x_9 = (M) null;
    
  }

  public Extravert<Long> giants(char adjudged, Short[] leaping) {
    Exerts<String, ? extends Long> digitally = (Exerts<String, Long>) null;
    Repulsing dowels = (Repulsing) null;
    return new Extravert<Long>(digitally, dowels);
    
  }

  public void domiciles(Character coronary, Integer opaqued) {
    final M plants = (M) null;
    ((Crosier<Character>) null).aimless();
    Object x_10 = plants;
    
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
     return 'N';
  }
}

interface Crosier<P> extends Enzyme {
  public abstract void aimless() ;
}

abstract class Overstay extends Worksheet<Byte> {
  public Object[] nominates;
  public final Repulsing cadmium;

  public Overstay(Object[] nominates,Repulsing cadmium) {
    super((Exerts<String, Float>) null);
    this.nominates = nominates;
    this.cadmium = cadmium;
  }

  public final Character dieresis(boolean tubes, Boolean zelig) {
    Character kfc = '6';
    return kfc;
    
  }

  public void domiciles(Character coronary, Integer opaqued) {
    Main.showiest =  'E';
    Object x_12 = -38;
    
  }
}

class Effacing extends Exerts<String, Float> {
  public Missal<? super Character, ? extends Byte, Float> spooking;
  public byte bunsen;

  public Effacing(Missal<? super Character, ? extends Byte, Float> spooking,byte bunsen) {
    super();
    this.spooking = spooking;
    this.bunsen = bunsen;
  }

  public final Apollos regale(Number untidiest) {
    Integer freewill = -28;
    final Apollos stated = new Apollos(freewill);
    Function0<Void> coddled = () -> {
      final char clowns = 'd';
      final Inoculate ban = new Inoculate(clowns);
      Main.aurelia(-86, "felon");
      Object x_13 = ban;
      return null;
    };
    coddled.apply();
    return stated;
    
  }

  public void domiciles(Character coronary, Integer opaqued) {
    final Worksheet<Long> downwards = Main.overtone;
    Object x_14 = downwards;
    
  }

  public Character dieresis(boolean tubes, Boolean zelig) {
    final Character thumbing = 'g';
    byte shooing = (byte)12;
    bunsen = shooing;
    return thumbing;
    
  }
}