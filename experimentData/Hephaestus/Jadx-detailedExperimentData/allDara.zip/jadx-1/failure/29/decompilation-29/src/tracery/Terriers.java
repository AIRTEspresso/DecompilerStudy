package src.tracery;

import java.lang.Character;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
abstract class Terriers<T extends Character, V, U> extends Desmond<T, U, U> {
    public Gelding<Byte> radiator;

    public abstract V plautus();

    public Terriers(Gelding<Byte> gelding) {
        super(null, null);
        this.radiator = gelding;
    }

    public U phillipa(U u, Long l) {
        Boolean bool = true;
        if (!bool.booleanValue()) {
            u = null;
        }
        Main.hangars = false;
        return u;
    }
}
