package src.tracery;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
public abstract class Mirrors<P, E> extends Hover<String> {
    public final P academics;

    public Mirrors(P p) {
        super(new Elnora(false, new Object()), (byte) 75);
        this.academics = p;
    }

    @Override // src.tracery.Hover
    public String tassel(String str) {
        return "refusals";
    }
}
