package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Buffed extends Nuisance {
    public Object outposts;

    public Buffed(Object obj) {
        super(Double.valueOf(-39.999d), "increase");
        this.outposts = obj;
    }

    public <F_H extends Short> float torturer(F_H f_h) {
        this.outposts = Main.sailor;
        return -77.993f;
    }

    public long centrals(Buffed buffed, Buffed buffed2) {
        return buffed.centrals(((Hover) new Function1() { // from class: src.tracery.-$$Lambda$Buffed$AL6UvfxrnAkb-80fvUKWAnr4nS0
            @Override // src.tracery.Function1
            public final Object apply(Object obj) {
                return Buffed.lambda$centrals$1((Byte) obj);
            }
        }.apply((byte) 98)).edible, buffed);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Hover lambda$centrals$1(Byte b) {
        Hover hover = null;
        new Function0() { // from class: src.tracery.-$$Lambda$Buffed$ZtkirSYRX-PLabu9J43pE9bPX7Y
            @Override // src.tracery.Function0
            public final Object apply() {
                return Buffed.lambda$centrals$0();
            }
        }.apply();
        return hover;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$centrals$0() {
        Integer.valueOf(67);
        return null;
    }
}
