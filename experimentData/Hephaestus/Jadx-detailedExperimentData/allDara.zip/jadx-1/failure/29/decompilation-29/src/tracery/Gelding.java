package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
final class Gelding<M> extends Buffed {
    public Gelding() {
        super(new Object());
    }

    public final void reining() {
        new Long(-43L);
        new Desmond(null, null).mas(null);
    }
}
