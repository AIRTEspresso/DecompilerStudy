package src.tracery;

import java.lang.Number;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Kyoto<G extends Number, P, U> extends Nuisance {
    public final Short glummer;
    public Object outposts;

    public Kyoto(Short sh, Object obj) {
        super(Double.valueOf(-55.41d), new Object());
        this.glummer = sh;
        this.outposts = obj;
    }

    public final Object baseboard(Object obj, String str) {
        return new Object();
    }
}
