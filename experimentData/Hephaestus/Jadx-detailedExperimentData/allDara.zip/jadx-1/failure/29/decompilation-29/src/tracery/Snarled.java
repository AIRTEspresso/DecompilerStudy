package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Snarled extends Elnora {
    public Object outposts;
    public Kyoto<? super Number, Object, Elnora> shortwave;

    public Snarled(Kyoto<? super Number, Object, Elnora> kyoto, Object obj) {
        super(true, (byte) 25);
        this.shortwave = kyoto;
        this.outposts = obj;
    }

    public final boolean mangroves() {
        return false;
    }
}
