package src.tracery;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
public class Desmond<H, V, B> extends Nuisance {
    public V costly;
    public final B weeded;

    public Desmond(V v, B b) {
        super(Double.valueOf(33.536d), new Object());
        this.costly = v;
        this.weeded = b;
    }

    public void mas(V v) {
    }
}
