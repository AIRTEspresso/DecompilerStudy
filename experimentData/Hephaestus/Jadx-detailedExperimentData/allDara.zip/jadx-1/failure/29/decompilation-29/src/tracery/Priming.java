package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
interface Priming {
    Buffed gutting(Buffed buffed, Arrays<? super String> arrays);

    <F_C> void less(F_C f_c, F_C f_c2);
}
