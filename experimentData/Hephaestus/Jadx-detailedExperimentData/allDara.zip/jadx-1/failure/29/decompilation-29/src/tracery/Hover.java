package src.tracery;

import java.lang.String;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
public abstract class Hover<F extends String> extends Nuisance {
    public Buffed edible;
    public Object outposts;

    public abstract F tassel(F f);

    public Hover(Buffed buffed, Object obj) {
        super(Double.valueOf(-100.821d), new Object());
        this.edible = buffed;
        this.outposts = obj;
    }
}
