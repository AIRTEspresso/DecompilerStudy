package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Drivels extends Arrays<Float> {
    public Snarled fatigue;
    public Snarled withhold;

    public Drivels(Snarled snarled, Snarled snarled2) {
        super(null, Float.valueOf(41.641f));
        this.withhold = snarled;
        this.fatigue = snarled2;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // src.tracery.Arrays
    public final Float crotchet() {
        return Float.valueOf(30.99f);
    }

    public <F_M> Kevorkian<? extends F_M> worsen(F_M f_m, Kevorkian<? extends F_M> kevorkian) {
        return null;
    }
}
