package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
abstract class Essays<H> extends Kevorkian<H> {
    public Integer transpire;

    public abstract H ladybug(H h);

    public Essays(Integer num) {
        super("ventolin", null);
        this.transpire = num;
    }

    public H carlyle(H h) {
        Hadrian hadrian = new Hadrian(new Object());
        Mirrors mirrors = null;
        new Catalpas(26L).seldom(new Arrays(mirrors, null).innovates.edible);
        return (H) hadrian.flotsam(mirrors.academics, 'I');
    }
}
