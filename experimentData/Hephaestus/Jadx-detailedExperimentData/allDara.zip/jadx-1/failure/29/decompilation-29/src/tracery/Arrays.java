package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Arrays<H> extends Desmond<H, H, H> {
    public H costly;
    public Mirrors<H, ? extends H> innovates;

    public Arrays(Mirrors<H, ? extends H> mirrors, H h) {
        super(null, null);
        this.innovates = mirrors;
        this.costly = h;
    }

    public H crotchet() {
        return null;
    }

    public final long prowling(Short sh, H h) {
        Priming priming = null;
        priming.less(null, null);
        return 38L;
    }
}
