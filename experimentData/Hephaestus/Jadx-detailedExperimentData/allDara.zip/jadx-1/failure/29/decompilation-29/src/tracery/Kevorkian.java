package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
abstract class Kevorkian<F> extends Hover<String> {
    public final String crocodile;
    public final F lords;

    public abstract F cymbals(Integer num, F f);

    public Kevorkian(String str, F f) {
        super(new Buffed(new Object()), new Object());
        this.crocodile = str;
        this.lords = f;
    }

    public F backus(Terriers<? super Character, ? extends F, ? super F> terriers) {
        return null;
    }
}
