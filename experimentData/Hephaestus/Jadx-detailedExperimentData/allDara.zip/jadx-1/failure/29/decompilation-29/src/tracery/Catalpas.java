package src.tracery;

import src.tracery.Buffed;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
final class Catalpas<R extends Buffed, Q extends R> extends Kyoto<Number, Q, Q> {
    public final Long rashers;

    public Catalpas(Long l) {
        super((short) -49, new Long(-22L));
        this.rashers = l;
    }

    public final void seldom(Buffed buffed) {
        Double.valueOf(-7.394d);
    }
}
