package src.tracery;

import java.lang.Float;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Hadrian<S, Y extends Float> extends Nuisance {
    public Object outposts;

    public Hadrian(Object obj) {
        super(Double.valueOf(13.824d), new Object());
        this.outposts = obj;
    }

    public S flotsam(S s, Character ch) {
        Main.tanning();
        return null;
    }
}
