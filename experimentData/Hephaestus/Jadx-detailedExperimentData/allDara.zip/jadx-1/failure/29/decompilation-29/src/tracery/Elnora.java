package src.tracery;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
class Elnora extends Buffed {
    public Boolean janis;
    public Object outposts;

    public Elnora(Boolean bool, Object obj) {
        super((short) 12);
        this.janis = bool;
        this.outposts = obj;
    }

    @Override // src.tracery.Buffed
    public <F_H extends Short> float torturer(F_H f_h) {
        return -93.474f;
    }
}
