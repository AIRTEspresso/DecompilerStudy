package src.tracery;

import java.lang.Byte;
import java.lang.Character;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
public interface Hanoi<V extends Character, Z extends Byte> extends Priming {
    Drivels saladin(Elnora elnora);
}
