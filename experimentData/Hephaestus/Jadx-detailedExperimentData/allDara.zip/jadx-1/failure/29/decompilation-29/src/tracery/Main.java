package src.tracery;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/29/original-29/Test.dex */
public class Main {
    static final String blanking;
    static boolean hangars;
    static Nuisance lifespans;
    static String packing;
    static final Byte sailor;
    static int scriabin;
    static Byte thrill;

    Main() {
    }

    static {
        boolean z;
        Byte b = (byte) -53;
        thrill = b;
        Byte valueOf = Byte.valueOf(b.byteValue());
        sailor = valueOf;
        scriabin = 15;
        Kevorkian kevorkian = null;
        if (valueOf == chaucer(10, chaucer(15, (byte) -80))) {
            Kevorkian kevorkian2 = kevorkian;
            if (kevorkian2.lacing.doubleValue() >= new Kyoto((short) 71, new Object()).glummer.shortValue()) {
                z = false;
                hangars = z;
                Kevorkian kevorkian3 = kevorkian;
                blanking = kevorkian3.crocodile;
                packing = "pairs";
                lifespans = new Buffed(new Kyoto((short) 75, new Object()).baseboard(-60, kevorkian3.crocodile));
            }
        }
        z = true;
        hangars = z;
        Kevorkian kevorkian32 = kevorkian;
        blanking = kevorkian32.crocodile;
        packing = "pairs";
        lifespans = new Buffed(new Kyoto((short) 75, new Object()).baseboard(-60, kevorkian32.crocodile));
    }

    public static final Byte chaucer(int i, Byte b) {
        return (byte) -37;
    }

    public static final Character prawning(Number number) {
        return 'Q';
    }

    public static final Short trampling(Object obj, Integer num) {
        short s;
        Boolean bool = new Elnora(true, obj).janis;
        Short trampling = trampling(false, -71);
        Terriers terriers = null;
        terriers.radiator.reining();
        if (bool.booleanValue()) {
            s = trampling.shortValue();
        } else {
            s = 99;
        }
        return Short.valueOf(s);
    }

    public static final Nuisance fridays(Nuisance nuisance) {
        return fridays(new Kyoto((short) 42, new Object()));
    }

    public static final void tanning() {
        Long.valueOf(40L);
    }

    public static final Float wharfs() {
        Boolean valueOf = Boolean.valueOf(hangars);
        Float wharfs = wharfs();
        if (valueOf.booleanValue()) {
        }
        return wharfs;
    }

    public static final void main(String[] strArr) {
        Kyoto<? super Number, Object, Elnora> kyoto = ((Hanoi) new Function0() { // from class: src.tracery.-$$Lambda$Main$ES8UjgsNKra7nC-muCz5vvTw34I
            @Override // src.tracery.Function0
            public final Object apply() {
                return Main.lambda$main$0();
            }
        }.apply()).saladin(new Snarled(new Kyoto((short) -42, new Object()), new Object())).withhold.shortwave;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Hanoi lambda$main$0() {
        Boolean bool = false;
        Hanoi hanoi = null;
        if (bool.booleanValue()) {
        }
        return hanoi;
    }
}
