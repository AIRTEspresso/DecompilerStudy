package src.octopi;

import java.lang.Character;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/45/original-45/Test.dex */
abstract class Rehab<D extends Character, N extends D> {
    public abstract short forest(short s, D d);
}
