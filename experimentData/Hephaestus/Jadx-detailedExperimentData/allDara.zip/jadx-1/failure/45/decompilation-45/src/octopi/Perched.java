package src.octopi;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/45/original-45/Test.dex */
public final class Perched extends Cantaloup<Boolean, Number> {
    public Number composed;
    public final Cantaloup<? super Float, ? super Boolean> swanson;

    public Perched(Cantaloup<? super Float, ? super Boolean> cantaloup, Number number) {
        super(52L);
        this.swanson = cantaloup;
        this.composed = number;
    }

    @Override // src.octopi.Cantaloup, src.octopi.Rehab
    public final short forest(short s, Character ch) {
        return (short) 2;
    }

    public final Character genteel(Character ch) {
        return '8';
    }
}
