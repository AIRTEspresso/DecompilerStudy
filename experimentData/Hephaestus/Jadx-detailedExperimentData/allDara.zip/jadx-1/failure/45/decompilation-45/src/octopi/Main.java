package src.octopi;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/45/original-45/Test.dex */
class Main {
    Main() {
    }

    public static final int primarily(char c) {
        return ((Bracelets) new Function1() { // from class: src.octopi.-$$Lambda$Main$vEQDZRp1b-0w68ErM0EvEZZOSyI
            @Override // src.octopi.Function1
            public final Object apply(Object obj) {
                return Main.lambda$primarily$2((Byte) obj);
            }
        }.apply((byte) 32)).talmuds;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Bracelets lambda$primarily$2(Byte b) {
        $$Lambda$Main$XN6bSWp0IX_AFd1iQVXpJbfiRys __lambda_main_xn6bswp0ix_afd1iqvxpjbfirys = new Function1() { // from class: src.octopi.-$$Lambda$Main$XN6bSWp0IX_AFd1iQVXpJbfiRys
            @Override // src.octopi.Function1
            public final Object apply(Object obj) {
                Bracelets cymbeline;
                Boolean bool = (Boolean) obj;
                cymbeline = Main.cymbeline('y');
                return cymbeline;
            }
        };
        boolean z = false;
        Boolean bool = false;
        if (bool.booleanValue() && bool.booleanValue()) {
            z = true;
        }
        new Function1() { // from class: src.octopi.-$$Lambda$Main$gZdPTrIPGsS98W6X8BJX6V-8LWM
            @Override // src.octopi.Function1
            public final Object apply(Object obj) {
                return Main.lambda$primarily$1((Number) obj);
            }
        }.apply(Short.valueOf(new Perched(null, new Long(-11L)).swanson.forest((short) 25, '4')));
        return (Bracelets) __lambda_main_xn6bswp0ix_afd1iqvxpjbfirys.apply(Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$primarily$1(Number number) {
        Cantaloup cantaloup = null;
        Long.valueOf(cantaloup.odorous);
        return null;
    }

    public static final Bracelets cymbeline(Character ch) {
        Bracelets bracelets = null;
        bracelets.manhattan = Double.valueOf(81.676d);
        return bracelets;
    }

    public static final char retrieve(long j) {
        return retrieve(j);
    }

    public static final Rehab<Character, Character> drivels(double d, Rehab<Character, Character> rehab) {
        double d2;
        Bracelets bracelets = null;
        bracelets.manhattan.doubleValue();
        boolean z = true;
        Boolean bool = true;
        if (bool.booleanValue()) {
            z = false;
        }
        if (Boolean.valueOf(z).booleanValue()) {
            d2 = bracelets.manhattan.doubleValue();
        } else {
            d2 = -90.329d;
        }
        return drivels(d2, null);
    }

    public static final <F_J> Short mango(F_J f_j) {
        short forest;
        Boosting boosting = null;
        Short sh = 92;
        if (boosting.rose.booleanValue()) {
            forest = sh.shortValue();
        } else {
            forest = boosting.forest((short) -58, 'n');
        }
        return Short.valueOf(forest);
    }

    public static final void main(String[] strArr) {
        Float.valueOf(56.271f);
        Float.valueOf(29.503f);
    }
}
