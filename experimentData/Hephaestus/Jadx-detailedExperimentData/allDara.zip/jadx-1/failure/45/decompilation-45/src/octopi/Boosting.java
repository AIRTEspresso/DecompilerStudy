package src.octopi;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/45/original-45/Test.dex */
abstract class Boosting<V> extends Rehab<Character, Character> {
    public final Boolean rose;

    public Boosting(Boolean bool) {
        this.rose = bool;
    }

    @Override // src.octopi.Rehab
    public short forest(short s, Character ch) {
        return (short) -28;
    }
}
