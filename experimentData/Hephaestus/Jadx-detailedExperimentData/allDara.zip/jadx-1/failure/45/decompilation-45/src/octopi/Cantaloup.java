package src.octopi;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/45/original-45/Test.dex */
public abstract class Cantaloup<L, H> extends Rehab<Character, Character> {
    public final long odorous;

    public Cantaloup(long j) {
        this.odorous = j;
    }

    @Override // src.octopi.Rehab
    public short forest(short s, Character ch) {
        return (short) -88;
    }
}
