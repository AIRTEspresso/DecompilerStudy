package src.octopi;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/45/original-45/Test.dex */
public abstract class Bracelets extends Rehab<Character, Character> {
    public Double manhattan;
    public int talmuds;

    public abstract Byte mendeleev(Long l, Number number);

    public Bracelets(int i, Double d) {
        this.talmuds = i;
        this.manhattan = d;
    }
}
