package src.sculpt;

class Main {
  static Boolean derides = true;

  static final Sensors<Byte, Byte> surmounts = (Sensors<Byte, Byte>) null;

  static final Sensors<Byte, Byte> chaucer = ((Main.derides) ?
  (Sensors<Byte, Byte>) null : 
   Main.surmounts);

  static final short anted = Main.chaucer.lasso(  ((true) ?
  (byte)84 : 
   (byte)26), Main.surmounts.rent(((Tamping<Long, Byte, String>) null).stressing)).curly;

  static public final void poole(Short undersold) {
    final Boolean pencilled = false;
    Catholic<Integer> mobility = new Catholic<Integer>((Boolean[]) new Object[]{false, pencilled}, (short)57);
    Short gossip = (short)61;
    new Adrenals<Short>(mobility, gossip).carlyle(true);
    Object x_0 = 100;
    
  }

  static public final void main(String[] args) {
    Thermals<Object> pronged = (Thermals<Object>) null;
    Thermals<Object> diluting = pronged;
      Object x_7 = ((true) ?
  diluting : 
   (Thermals<Object>) null).shocker;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Catholic<S> {
  public Boolean[] bestiary;
  public short curly;

  public Catholic(Boolean[] bestiary,short curly) {
    this.bestiary = bestiary;
    this.curly = curly;
  }

  public final long redolence(Integer cannibal, long beseeched) {
    final long dynamited = (long)-4;
    return dynamited;
    
  }

  public final double seeings(double cruddiest) {
    return -77.496;
  }
}

interface Sensors<O, Q extends O> {
  public abstract <F_T extends Q> Catholic<Integer> lasso(O wadi, F_T snit) ;

  public abstract Q rent(Q hui) ;
}

abstract class Tamping<V, L, I> implements Sensors<L, L> {
  public final Byte stressing;

  public Tamping(Byte stressing) {
    super();
    this.stressing = stressing;
  }

  public abstract char showroom() ;
}

final class Decreeing extends Tamping<Double, Double, Integer> {
  public Decreeing() {
    super((byte)-38);
}

  public <F_T extends Double> Catholic<Integer> lasso(Double wadi, F_T snit) {
    return ((Aviatrix<Decreeing, Character, Short>) null).corrugate;
  }

  public char showroom() {
    final Boolean strutting = false;
    final char adriatic = 'H';
    final char abscond = ((strutting) ?
       'E' : 
       adriatic);
    Main.derides = true;
    return abscond;
    
  }

  public Double rent(Double hui) {
    final Boolean disbands = false;
    Double soundless = 64.478;
    Double snugging = -47.654;
    return ((disbands) ?
      soundless : 
       snugging);
    
  }
}

abstract class Aviatrix<L, I, N> extends Tamping<N, N, L> {
  public Catholic<Integer> corrugate;

  public Aviatrix(Catholic<Integer> corrugate) {
    super((byte)-77);
    this.corrugate = corrugate;
  }

  public char showroom() {
    char teams = 'z';
    return teams;
    
  }
}

class Hostlers<A extends Integer, H, P extends A> extends Tamping<Double, Byte, Character> {
  public final A enures;

  public Hostlers(A enures) {
    super((byte)-10);
    this.enures = enures;
  }

  public <F_T extends Byte> Catholic<Integer> lasso(Byte wadi, F_T snit) {
    Catholic<Integer> availing = new Catholic<Integer>((Boolean[]) new Object[]{true, false, true}, (short)90);
    final Catholic<Integer> mfume = availing;
    return mfume;
    
  }

  public Byte rent(Byte hui) {
    return hui;
  }

  public char showroom() {
    Boolean mystic = false;
    Dubiety<Number, Number, Number> foaling = new Dubiety<Number, Number, Number>( 'A');
    Dubiety<Number, Number, Number> maharajah = foaling;
      ((false) ?
  new Indued<Double, P>((Effacing<P, P>) null, (byte)53) : 
   new Indued<Double, P>((Effacing<P, P>) null, (byte)-15)).shocker.alyson.prop();
      return ((mystic) ?
  new Cadenzas<Boolean, Boolean, H>(maharajah) : 
   new Cadenzas<Boolean, Boolean, H>(new Dubiety<Number, Number, Number>( '3'))).reuses.seeds;
    
  }
}

class Dubiety<F, D extends F, M extends F> extends Tamping<Byte, Integer, String> {
  public final char seeds;

  public Dubiety(char seeds) {
    super((byte)90);
    this.seeds = seeds;
  }

  public Integer rent(Integer hui) {
    return 51;
  }

  public <F_T extends Integer> Catholic<Integer> lasso(Integer wadi, F_T snit) {
    Boolean setups = false;
    Boolean emotions = true;
    final Catholic<Integer> orville = new Catholic<Integer>((Boolean[]) new Object[]{true, setups, emotions}, (short)63);
    return orville;
    
  }

  public char showroom() {
    char catalpa = 'M';
    final Pang<Float, Decreeing, Number> purebreds = (Pang<Float, Decreeing, Number>) null;
    purebreds.overdue((byte)19, null);
    return catalpa;
    
  }
}

interface Pang<M, X, T> extends Sensors<Double, Double> {
  public abstract void overdue(byte spent, Sensors<? super Boolean, Boolean> canonical) ;
}

class Cadenzas<F extends Boolean, K extends F, U> implements Sensors<K, K> {
  public final Dubiety<Number, Number, Number> reuses;

  public Cadenzas(Dubiety<Number, Number, Number> reuses) {
    super();
    this.reuses = reuses;
  }

  public <F_T extends K> Catholic<Integer> lasso(K wadi, F_T snit) {
    Boolean consents = false;
    final Boolean[] parabola = (Boolean[]) new Object[]{true, consents};
    final Short scout = (short)5;
    Main.poole(scout);
    return new Catholic<Integer>(parabola, (short)-13);
    
  }

  public K rent(K hui) {
    return (K) null;
  }
}

class Adrenals<I> extends Aviatrix<I, I, I> {
  public Catholic<Integer> corrugate;
  public final I lisps;

  public Adrenals(Catholic<Integer> corrugate,I lisps) {
    super(new Catholic<Integer>((Boolean[]) new Object[]{false, true}, (short)6));
    this.corrugate = corrugate;
    this.lisps = lisps;
  }

  public void carlyle(Boolean vanuatu) {
    Object x_1 = (I) null;
    
  }

  public <F_T extends I> Catholic<Integer> lasso(I wadi, F_T snit) {
    short traci = (short)-61;
    final Catholic<Integer> hermes = new Catholic<Integer>(new Boolean[0], traci);
    return hermes;
    
  }

  public I rent(I hui) {
    final I geffen = (I) null;
    Attrition<Sensors<Integer, Integer>, I, I> exceeding = (Attrition<Sensors<Integer, Integer>, I, I>) null;
    exceeding.maynard();
    return geffen;
    
  }
}

interface Attrition<J extends Sensors<? super Integer, Integer>, G, T> extends Pang<Double, Integer, Character> {
  public abstract void maynard() ;

  public abstract J bricks() ;
}

class Leasehold<T, X extends T, K> extends Tamping<Character, Integer, Double> {
  public K scoff;

  public Leasehold(K scoff) {
    super((byte)-3);
    this.scoff = scoff;
  }

  public void prop() {
    Knacker<K, ? super Byte> kemerovo = (Knacker<K, Byte>) null;
    Object x_2 = kemerovo.foul;
    
  }

  public <F_T extends Integer> Catholic<Integer> lasso(Integer wadi, F_T snit) {
    final Catholic<Integer> shove = new Catholic<Integer>(new Boolean[0], (short)64);
    shove.curly = (short)-56;
    return shove;
    
  }

  public Integer rent(Integer hui) {
    return 94;
  }

  public char showroom() {
    final char maydays = 'j';
    return maydays;
    
  }
}

abstract class Knacker<Y, N> extends Aviatrix<Character, Integer, Short> {
  public final Y foul;
  public Catholic<Integer> corrugate;

  public Knacker(Y foul,Catholic<Integer> corrugate) {
    super(new Catholic<Integer>(new Boolean[0], (short)28));
    this.foul = foul;
    this.corrugate = corrugate;
  }

  public Knacker<? extends String, Object> ilene(Integer gerardo, Byte tumult) {
    Knacker<? extends String, Object> dermis = (Knacker<String, Object>) null;
    Function2<Integer, Byte, Void> fibula = (longhairs, butch) -> {
      final N teat = (N) null;
      final Boolean[] illicitly = (Boolean[]) new Object[]{true};
      short entreated = (short)11;
      new Catholic<Short>(illicitly, entreated).curly = (short)-13;
      Object x_3 = teat;
      return null;
    };
    fibula.apply(-17, (byte)-2);
    return dermis;
    
  }
}

abstract class Effacing<W extends Integer, S extends W> extends Cadenzas<Boolean, Boolean, W> {
  public final Leasehold<W, W, W> alyson;
  public final W yowled;

  public Effacing(Leasehold<W, W, W> alyson,W yowled) {
    super(new Dubiety<Number, Number, Number>( '4'));
    this.alyson = alyson;
    this.yowled = yowled;
  }

  public final <F_T extends Boolean> Catholic<Integer> lasso(Boolean wadi, F_T snit) {
    Boolean ovulate = false;
    final Boolean ornery = false;
    Boolean canvasser = true;
    Function1<Tamping<Character, Object, Double>, Void> cross = (retakes) -> {
      final W perish = (W) null;
      Boolean revere = false;
      Shine settee = new Shine(revere);
      settee.swamping((short)54);
      Object x_4 = perish;
      return null;
    };
    cross.apply((Tamping<Character, Object, Double>) null);
    return new Catholic<Integer>((Boolean[]) new Object[]{ovulate, ornery, canvasser}, (short)44);
    
  }

  public final Boolean rent(Boolean hui) {
    return false;
  }
}

class Shine extends Leasehold<Boolean, Boolean, Boolean> {
  public Boolean scoff;

  public Shine(Boolean scoff) {
    super(true);
    this.scoff = scoff;
  }

  public final void swamping(short rodin) {
    final Catholic<Integer> supervise = new Catholic<Integer>(new Boolean[0], (short)-49);
    scoff = true;
    Object x_5 = new Adrenals<Shine>(supervise, (Shine) null);
    
  }
}

class Indued<I extends Double, V extends Integer> extends Knacker<I, V> {
  public final Effacing<V, V> shocker;
  public byte sallower;

  public Indued(Effacing<V, V> shocker,byte sallower) {
    super((I) null, new Catholic<Integer>((Boolean[]) new Object[]{false, false, false}, (short)-35));
    this.shocker = shocker;
    this.sallower = sallower;
  }

  public <F_T extends Short> Catholic<Integer> lasso(Short wadi, F_T snit) {
    Boolean[] caches = (Boolean[]) new Object[]{false};
    return new Catholic<Integer>(caches, (short)85);
    
  }

  public Short rent(Short hui) {
    return (short)-59;
  }
}

interface Piggiest extends Pang<Piggiest, Character, Integer> {
  public abstract Effacing<? extends Integer, ? extends Integer> rover() ;

  public abstract Long octavio(Hostlers<? extends Integer, Number, ? extends Integer> daubed) ;
}

abstract class Moll implements Pang<Long, Short, String> {
  public final Sensors<? super Boolean, Boolean> wounds;
  public Pang<? extends Number, ? extends Boolean, ? extends Long> used;

  public Moll(Sensors<? super Boolean, Boolean> wounds,Pang<? extends Number, ? extends Boolean, ? extends Long> used) {
    super();
    this.wounds = wounds;
    this.used = used;
  }

  public void overdue(byte spent, Sensors<? super Boolean, Boolean> canonical) {
    Boolean[] clog = (Boolean[]) new Object[]{true, true, true};
    Short lockets = Main.anted;
    Catholic<? super Integer> pence = new Catholic<Integer>(clog, ((Thermals<Byte>) null).rhythm.rent(lockets));
    clog =   ((false) ?
  (Boolean[]) new Object[]{false, false, false} : 
   (Boolean[]) new Object[]{true, true, false});
    Object x_6 = pence;
    
  }

  public abstract Moll continua() ;
}

abstract class Thermals<Z> extends Indued<Double, Integer> {
  public Indued<Double, ? extends Integer> rhythm;
  public final Z sheered;

  public Thermals(Indued<Double, ? extends Integer> rhythm,Z sheered) {
    super((Effacing<Integer, Integer>) null, (byte)65);
    this.rhythm = rhythm;
    this.sheered = sheered;
  }

  public <F_T extends Short> Catholic<Integer> lasso(Short wadi, F_T snit) {
    final Boolean slangier = false;
    Boolean clampdown = false;
    Boolean[] gains = (Boolean[]) new Object[]{slangier, clampdown};
    return new Catholic<Integer>(gains, (short)-15);
    
  }
}

interface Fancily<S, R> extends Sensors<S, S> {}