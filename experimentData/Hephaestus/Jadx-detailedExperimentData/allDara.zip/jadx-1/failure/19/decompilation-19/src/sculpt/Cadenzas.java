package src.sculpt;

import java.lang.Boolean;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
class Cadenzas<F extends Boolean, K extends F, U> implements Sensors<K, K> {
    public final Dubiety<Number, Number, Number> reuses;

    public Cadenzas(Dubiety<Number, Number, Number> dubiety) {
        this.reuses = dubiety;
    }

    /* JADX WARN: Incorrect types in method signature: <F_T:TK;>(TK;TF_T;)Lsrc/sculpt/Catholic<Ljava/lang/Integer;>; */
    @Override // src.sculpt.Sensors
    public Catholic lasso(Boolean bool, Boolean bool2) {
        Object[] objArr = {true, false};
        Main.poole((short) 5);
        return new Catholic((Boolean[]) objArr, (short) -13);
    }

    /* JADX WARN: Incorrect return type in method signature: (TK;)TK; */
    @Override // src.sculpt.Sensors
    public Boolean rent(Boolean bool) {
        return null;
    }
}
