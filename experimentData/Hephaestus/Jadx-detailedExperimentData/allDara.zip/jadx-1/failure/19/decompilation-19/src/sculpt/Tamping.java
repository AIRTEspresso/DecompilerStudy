package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
abstract class Tamping<V, L, I> implements Sensors<L, L> {
    public final Byte stressing;

    public abstract char showroom();

    public Tamping(Byte b) {
        this.stressing = b;
    }
}
