package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
interface Sensors<O, Q extends O> {
    <F_T extends Q> Catholic<Integer> lasso(O o, F_T f_t);

    Q rent(Q q);
}
