package src.sculpt;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
class Hostlers<A extends Integer, H, P extends A> extends Tamping<Double, Byte, Character> {
    public final A enures;

    public Hostlers(A a) {
        super((byte) -10);
        this.enures = a;
    }

    @Override // src.sculpt.Sensors
    public <F_T extends Byte> Catholic<Integer> lasso(Byte b, F_T f_t) {
        return new Catholic<>((Boolean[]) new Object[]{true, false, true}, (short) 90);
    }

    @Override // src.sculpt.Sensors
    public Byte rent(Byte b) {
        return b;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // src.sculpt.Tamping
    public char showroom() {
        Cadenzas cadenzas;
        Boolean bool = false;
        Dubiety dubiety = new Dubiety('A');
        new Indued(null, (byte) -15).shocker.alyson.prop();
        if (bool.booleanValue()) {
            cadenzas = new Cadenzas(dubiety);
        } else {
            cadenzas = new Cadenzas(new Dubiety('3'));
        }
        return cadenzas.reuses.seeds;
    }
}
