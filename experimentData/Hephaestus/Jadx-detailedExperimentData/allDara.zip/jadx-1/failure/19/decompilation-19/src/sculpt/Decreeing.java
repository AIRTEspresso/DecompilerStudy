package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
final class Decreeing extends Tamping<Double, Double, Integer> {
    public Decreeing() {
        super((byte) -38);
    }

    @Override // src.sculpt.Sensors
    public <F_T extends Double> Catholic<Integer> lasso(Double d, F_T f_t) {
        Aviatrix aviatrix = null;
        return aviatrix.corrugate;
    }

    @Override // src.sculpt.Tamping
    public char showroom() {
        char c;
        Boolean bool = false;
        if (bool.booleanValue()) {
            c = 'E';
        } else {
            c = 'H';
        }
        Main.derides = true;
        return c;
    }

    @Override // src.sculpt.Sensors
    public Double rent(Double d) {
        Boolean bool = false;
        Double valueOf = Double.valueOf(64.478d);
        Double valueOf2 = Double.valueOf(-47.654d);
        if (bool.booleanValue()) {
            return valueOf;
        }
        return valueOf2;
    }
}
