package src.sculpt;

import java.lang.Double;
import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
class Indued<I extends Double, V extends Integer> extends Knacker<I, V> {
    public byte sallower;
    public final Effacing<V, V> shocker;

    public Indued(Effacing<V, V> effacing, byte b) {
        super(null, new Catholic((Boolean[]) new Object[]{false, false, false}, (short) -35));
        this.shocker = effacing;
        this.sallower = b;
    }

    @Override // src.sculpt.Sensors
    public <F_T extends Short> Catholic<Integer> lasso(Short sh, F_T f_t) {
        return new Catholic<>((Boolean[]) new Object[]{false}, (short) 85);
    }

    @Override // src.sculpt.Sensors
    public Short rent(Short sh) {
        return (short) -59;
    }
}
