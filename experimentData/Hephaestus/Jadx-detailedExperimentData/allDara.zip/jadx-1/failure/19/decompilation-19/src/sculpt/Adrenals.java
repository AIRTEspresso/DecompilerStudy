package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
class Adrenals<I> extends Aviatrix<I, I, I> {
    public Catholic<Integer> corrugate;
    public final I lisps;

    public Adrenals(Catholic<Integer> catholic, I i) {
        super(new Catholic((Boolean[]) new Object[]{false, true}, (short) 6));
        this.corrugate = catholic;
        this.lisps = i;
    }

    public void carlyle(Boolean bool) {
    }

    @Override // src.sculpt.Sensors
    public <F_T extends I> Catholic<Integer> lasso(I i, F_T f_t) {
        return new Catholic<>(new Boolean[0], (short) -61);
    }

    @Override // src.sculpt.Sensors
    public I rent(I i) {
        Attrition attrition = null;
        attrition.maynard();
        return null;
    }
}
