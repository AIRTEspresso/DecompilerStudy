package src.sculpt;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
public class Main {
    static final short anted;
    static final Sensors<Byte, Byte> chaucer;
    static Boolean derides;
    static final Sensors<Byte, Byte> surmounts;

    Main() {
    }

    static {
        Boolean bool = true;
        derides = bool;
        Sensors<Byte, Byte> sensors = null;
        surmounts = sensors;
        if (!bool.booleanValue()) {
            sensors = surmounts;
        }
        chaucer = sensors;
        Tamping tamping = null;
        anted = sensors.lasso((byte) 84, surmounts.rent(tamping.stressing)).curly;
    }

    public static final void poole(Short sh) {
        new Adrenals(new Catholic((Boolean[]) new Object[]{false, false}, (short) 57), (short) 61).carlyle(true);
        Integer.valueOf(100);
    }

    public static final void main(String[] strArr) {
        Thermals thermals = null;
        Cadenzas cadenzas = thermals.shocker;
    }
}
