package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
class Leasehold<T, X extends T, K> extends Tamping<Character, Integer, Double> {
    public K scoff;

    public Leasehold(K k) {
        super((byte) -3);
        this.scoff = k;
    }

    public void prop() {
        Knacker knacker = null;
        Y y = knacker.foul;
    }

    @Override // src.sculpt.Sensors
    public <F_T extends Integer> Catholic<Integer> lasso(Integer num, F_T f_t) {
        Catholic<Integer> catholic = new Catholic<>(new Boolean[0], (short) 64);
        catholic.curly = (short) -56;
        return catholic;
    }

    @Override // src.sculpt.Sensors
    public Integer rent(Integer num) {
        return 94;
    }

    @Override // src.sculpt.Tamping
    public char showroom() {
        return 'j';
    }
}
