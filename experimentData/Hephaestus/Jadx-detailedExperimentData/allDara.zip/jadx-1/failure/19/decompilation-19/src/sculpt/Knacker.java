package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
abstract class Knacker<Y, N> extends Aviatrix<Character, Integer, Short> {
    public Catholic<Integer> corrugate;
    public final Y foul;

    public Knacker(Y y, Catholic<Integer> catholic) {
        super(new Catholic(new Boolean[0], (short) 28));
        this.foul = y;
        this.corrugate = catholic;
    }

    public Knacker<? extends String, Object> ilene(Integer num, Byte b) {
        Knacker<? extends String, Object> knacker = null;
        new Function2() { // from class: src.sculpt.-$$Lambda$Knacker$pOxCOMZ8_aqOm1erc6_Z1C1twbM
            @Override // src.sculpt.Function2
            public final Object apply(Object obj, Object obj2) {
                return Knacker.lambda$ilene$0((Integer) obj, (Byte) obj2);
            }
        }.apply(-17, (byte) -2);
        return knacker;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$ilene$0(Integer num, Byte b) {
        new Catholic((Boolean[]) new Object[]{true}, (short) 11).curly = (short) -13;
        return null;
    }
}
