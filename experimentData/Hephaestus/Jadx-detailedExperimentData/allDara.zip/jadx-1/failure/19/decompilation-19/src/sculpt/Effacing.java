package src.sculpt;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
abstract class Effacing<W extends Integer, S extends W> extends Cadenzas<Boolean, Boolean, W> {
    public final Leasehold<W, W, W> alyson;
    public final W yowled;

    public Effacing(Leasehold<W, W, W> leasehold, W w) {
        super(new Dubiety('4'));
        this.alyson = leasehold;
        this.yowled = w;
    }

    @Override // src.sculpt.Cadenzas, src.sculpt.Sensors
    public final <F_T extends Boolean> Catholic<Integer> lasso(Boolean bool, F_T f_t) {
        new Function1() { // from class: src.sculpt.-$$Lambda$Effacing$BOe-cLP19cpiSJtexj5P20ItOjA
            @Override // src.sculpt.Function1
            public final Object apply(Object obj) {
                return Effacing.lambda$lasso$0((Tamping) obj);
            }
        }.apply(null);
        return new Catholic<>((Boolean[]) new Object[]{false, false, true}, (short) 44);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$lasso$0(Tamping tamping) {
        new Shine(false).swamping((short) 54);
        return null;
    }

    @Override // src.sculpt.Cadenzas, src.sculpt.Sensors
    public final Boolean rent(Boolean bool) {
        return false;
    }
}
