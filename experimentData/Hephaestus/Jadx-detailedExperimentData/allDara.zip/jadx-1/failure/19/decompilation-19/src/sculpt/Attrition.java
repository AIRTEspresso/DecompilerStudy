package src.sculpt;

import src.sculpt.Sensors;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
interface Attrition<J extends Sensors<? super Integer, Integer>, G, T> extends Pang<Double, Integer, Character> {
    J bricks();

    void maynard();
}
