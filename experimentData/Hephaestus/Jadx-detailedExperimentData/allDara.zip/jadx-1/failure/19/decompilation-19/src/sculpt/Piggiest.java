package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
interface Piggiest extends Pang<Piggiest, Character, Integer> {
    Long octavio(Hostlers<? extends Integer, Number, ? extends Integer> hostlers);

    Effacing<? extends Integer, ? extends Integer> rover();
}
