package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
abstract class Moll implements Pang<Long, Short, String> {
    public Pang<? extends Number, ? extends Boolean, ? extends Long> used;
    public final Sensors<? super Boolean, Boolean> wounds;

    public abstract Moll continua();

    public Moll(Sensors<? super Boolean, Boolean> sensors, Pang<? extends Number, ? extends Boolean, ? extends Long> pang) {
        this.wounds = sensors;
        this.used = pang;
    }

    @Override // src.sculpt.Pang
    public void overdue(byte b, Sensors<? super Boolean, Boolean> sensors) {
        Thermals thermals = null;
        new Catholic((Boolean[]) new Object[]{true, true, true}, thermals.rhythm.rent(Short.valueOf(Main.anted)).shortValue());
        Boolean[] boolArr = (Boolean[]) new Object[]{true, true, false};
    }
}
