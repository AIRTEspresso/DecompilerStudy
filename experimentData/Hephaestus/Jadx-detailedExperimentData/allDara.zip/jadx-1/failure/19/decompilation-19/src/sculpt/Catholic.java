package src.sculpt;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
public final class Catholic<S> {
    public Boolean[] bestiary;
    public short curly;

    public Catholic(Boolean[] boolArr, short s) {
        this.bestiary = boolArr;
        this.curly = s;
    }

    public final long redolence(Integer num, long j) {
        return -4L;
    }

    public final double seeings(double d) {
        return -77.496d;
    }
}
