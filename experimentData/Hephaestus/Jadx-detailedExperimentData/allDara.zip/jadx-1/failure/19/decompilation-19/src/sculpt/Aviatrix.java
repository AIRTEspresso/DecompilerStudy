package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
abstract class Aviatrix<L, I, N> extends Tamping<N, N, L> {
    public Catholic<Integer> corrugate;

    public Aviatrix(Catholic<Integer> catholic) {
        super((byte) -77);
        this.corrugate = catholic;
    }

    @Override // src.sculpt.Tamping
    public char showroom() {
        return 'z';
    }
}
