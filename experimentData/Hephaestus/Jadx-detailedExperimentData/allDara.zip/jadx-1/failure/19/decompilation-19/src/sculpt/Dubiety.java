package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
class Dubiety<F, D extends F, M extends F> extends Tamping<Byte, Integer, String> {
    public final char seeds;

    public Dubiety(char c) {
        super((byte) 90);
        this.seeds = c;
    }

    @Override // src.sculpt.Sensors
    public Integer rent(Integer num) {
        return 51;
    }

    @Override // src.sculpt.Sensors
    public <F_T extends Integer> Catholic<Integer> lasso(Integer num, F_T f_t) {
        return new Catholic<>((Boolean[]) new Object[]{true, false, true}, (short) 63);
    }

    @Override // src.sculpt.Tamping
    public char showroom() {
        Pang pang = null;
        pang.overdue((byte) 19, null);
        return 'M';
    }
}
