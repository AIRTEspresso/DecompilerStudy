package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
abstract class Thermals<Z> extends Indued<Double, Integer> {
    public Indued<Double, ? extends Integer> rhythm;
    public final Z sheered;

    public Thermals(Indued<Double, ? extends Integer> indued, Z z) {
        super(null, (byte) 65);
        this.rhythm = indued;
        this.sheered = z;
    }

    @Override // src.sculpt.Indued, src.sculpt.Sensors
    public <F_T extends Short> Catholic<Integer> lasso(Short sh, F_T f_t) {
        return new Catholic<>((Boolean[]) new Object[]{false, false}, (short) -15);
    }
}
