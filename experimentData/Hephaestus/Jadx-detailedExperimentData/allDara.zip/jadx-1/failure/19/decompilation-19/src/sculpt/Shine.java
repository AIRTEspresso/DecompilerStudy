package src.sculpt;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
public class Shine extends Leasehold<Boolean, Boolean, Boolean> {
    public Boolean scoff;

    public Shine(Boolean bool) {
        super(true);
        this.scoff = bool;
    }

    public final void swamping(short s) {
        Catholic catholic = new Catholic(new Boolean[0], (short) -49);
        this.scoff = true;
        new Adrenals(catholic, null);
    }
}
