package src.sculpt;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/19/original-19/Test.dex */
interface Pang<M, X, T> extends Sensors<Double, Double> {
    void overdue(byte b, Sensors<? super Boolean, Boolean> sensors);
}
