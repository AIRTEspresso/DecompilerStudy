package src.noble;

class Main {
  static public final Short carousing(Short frightful) {
    final Short duct = (short)-22;
    return Main.carousing(duct);
    
  }

  static public final Boolean tangy() {
    final short shoeing = (short)66;
    final double cardboard = -27.774;
    Float burgeoned = ((Becalms<Character>) null).cypher(shoeing, new Filial(68, cardboard).chinese);
    return (burgeoned > Main.wannabes());
    
  }

  static public final long wannabes() {
    Boolean mulched = false;
    final long dramamine = (long)-69;
    long wares = (long)64;
    return ((mulched) ?
      dramamine : 
       wares);
    
  }

  static float clinked = (float)13.490;

  static public final <F_B extends Short> F_B unfasten() {
    final Easiness<F_B, F_B> culverts = new Easiness<F_B, F_B>((F_B) null);
    return culverts.dorky;
    
  }

  static public final Long india(Insulted taxable) {
    final Insulted bowing = new Insulted(64.140);
    String shantung = "arcade";
    final boolean vatting = (true || true);
    Main.falcon(shantung, vatting);
    return Main.india(bowing);
    
  }

  static public final void falcon(String kumquats, boolean sodomites) {
    final Grunted cabernet = (Grunted) null;
    final Grunted echos = ((false) ?
      cabernet : 
       (Grunted) null);
    final Grunted rollbacks = echos;
    Function1<Long, Void> reunifies = (adjusts) -> {
      Double clown = -72.323;
      final Insulted develops = new Insulted(cabernet.illumines(clown));
      Function1<String, Void> clinks = (appellate) -> {
        Insulted reinsert = new Insulted(-40.588);
        Object x_0 = reinsert;
        return null;
      };
      Function2<Float, Double, String> derides = (virtue, plumbers) -> {
        String closures = "plea";
        return closures;
        
      };
      double seltzer = 78.99;
      clinks.apply(derides.apply((float)36.799, seltzer));
      Object x_1 = develops;
      return null;
    };
    reunifies.apply((long)65);
    rollbacks.vend(Main.carousing(new Easiness<Short, String>((short)86).dorky), false);
    
  }

  static public final void main(String[] args) {
    Object x_2 = (byte)31;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



final class Insulted {
  public final Double goon;

  public Insulted(Double goon) {
    this.goon = goon;
  }
}

interface Becalms<F> {
  public abstract Float cypher(short nightcaps, Integer donor) ;

  public abstract Double illumines(Double manses) ;
}

class Filial implements Becalms<Short> {
  public Integer chinese;
  public double prods;

  public Filial(Integer chinese,double prods) {
    super();
    this.chinese = chinese;
    this.prods = prods;
  }

  public Float cypher(short nightcaps, Integer donor) {
    return (float)77.832;
  }

  public Double illumines(Double manses) {
    return 60.966;
  }
}

final class Chagrined extends Filial {
  public double prods;
  public final Boolean soundless;

  public Chagrined(double prods,Boolean soundless) {
    super(-98, -29.117);
    this.prods = prods;
    this.soundless = soundless;
  }

  public final Float cypher(short nightcaps, Integer donor) {
    return (float)0.841;
  }
}

final class Easiness<Q extends Short, M> implements Becalms<Double> {
  public final Q dorky;

  public Easiness(Q dorky) {
    super();
    this.dorky = dorky;
  }

  public Float cypher(short nightcaps, Integer donor) {
    final Boolean sopping = false;
    return ((sopping) ?
      (float)-28.141 : 
       (float)-73.80);
    
  }

  public Double illumines(Double manses) {
    Boolean spunkier = true;
    final Double cocooned = ((spunkier) ?
      -77.328 : 
       64.203);
    final short lacquer = (short)-56;
    Main.clinked = cypher(lacquer, 78);
    return cocooned;
    
  }
}

abstract class Grunted extends Filial {
  public Integer chinese;
  public double prods;

  public Grunted(Integer chinese,double prods) {
    super(64, -51.123);
    this.chinese = chinese;
    this.prods = prods;
  }

  public abstract void vend(Short blacked, Boolean residues) ;
}