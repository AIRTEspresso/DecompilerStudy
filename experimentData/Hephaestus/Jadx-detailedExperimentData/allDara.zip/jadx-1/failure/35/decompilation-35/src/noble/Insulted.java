package src.noble;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
public final class Insulted {
    public final Double goon;

    public Insulted(Double d) {
        this.goon = d;
    }
}
