package src.noble;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
public class Filial implements Becalms<Short> {
    public Integer chinese;
    public double prods;

    public Filial(Integer num, double d) {
        this.chinese = num;
        this.prods = d;
    }

    @Override // src.noble.Becalms
    public Float cypher(short s, Integer num) {
        return Float.valueOf(77.832f);
    }

    @Override // src.noble.Becalms
    public Double illumines(Double d) {
        return Double.valueOf(60.966d);
    }
}
