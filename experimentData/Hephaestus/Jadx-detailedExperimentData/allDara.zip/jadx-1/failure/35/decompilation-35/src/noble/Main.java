package src.noble;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
class Main {
    static float clinked = 13.49f;

    Main() {
    }

    public static final Short carousing(Short sh) {
        return carousing((short) -22);
    }

    public static final Boolean tangy() {
        Becalms becalms = null;
        return Boolean.valueOf(becalms.cypher((short) 66, new Filial(68, -27.774d).chinese).floatValue() > ((float) wannabes()));
    }

    public static final long wannabes() {
        Boolean bool = false;
        if (bool.booleanValue()) {
            return -69L;
        }
        return 64L;
    }

    public static final <F_B extends Short> F_B unfasten() {
        return (F_B) new Easiness(null).dorky;
    }

    public static final Long india(Insulted insulted) {
        Insulted insulted2 = new Insulted(Double.valueOf(64.14d));
        falcon("arcade", true);
        return india(insulted2);
    }

    public static final void falcon(String str, boolean z) {
        final Grunted grunted = null;
        new Function1() { // from class: src.noble.-$$Lambda$Main$sy4AWApS8v81TAloELSNqgRskoY
            @Override // src.noble.Function1
            public final Object apply(Object obj) {
                return Main.lambda$falcon$2(Grunted.this, (Long) obj);
            }
        }.apply(65L);
        grunted.vend(carousing(new Easiness((short) 86).dorky), false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$falcon$2(Grunted grunted, Long l) {
        new Insulted(grunted.illumines(Double.valueOf(-72.323d)));
        new Function1() { // from class: src.noble.-$$Lambda$Main$PfGC2lgfM-ou61nLZdKOymZ47s4
            @Override // src.noble.Function1
            public final Object apply(Object obj) {
                return Main.lambda$falcon$0((String) obj);
            }
        }.apply((String) new Function2() { // from class: src.noble.-$$Lambda$Main$J8HMtscVrnqsfkoypy5i-mCSHkQ
            @Override // src.noble.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$falcon$1((Float) obj, (Double) obj2);
            }
        }.apply(Float.valueOf(36.799f), Double.valueOf(78.99d)));
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$falcon$0(String str) {
        new Insulted(Double.valueOf(-40.588d));
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ String lambda$falcon$1(Float f, Double d) {
        return "plea";
    }

    public static final void main(String[] strArr) {
        Byte.valueOf((byte) 31);
    }
}
