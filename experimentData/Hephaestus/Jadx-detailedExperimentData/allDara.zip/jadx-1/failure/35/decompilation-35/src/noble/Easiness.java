package src.noble;

import java.lang.Short;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
public final class Easiness<Q extends Short, M> implements Becalms<Double> {
    public final Q dorky;

    public Easiness(Q q) {
        this.dorky = q;
    }

    @Override // src.noble.Becalms
    public Float cypher(short s, Integer num) {
        float f;
        Boolean bool = false;
        if (bool.booleanValue()) {
            f = -28.141f;
        } else {
            f = -73.8f;
        }
        return Float.valueOf(f);
    }

    @Override // src.noble.Becalms
    public Double illumines(Double d) {
        double d2;
        Boolean bool = true;
        if (bool.booleanValue()) {
            d2 = -77.328d;
        } else {
            d2 = 64.203d;
        }
        Double valueOf = Double.valueOf(d2);
        Main.clinked = cypher((short) -56, 78).floatValue();
        return valueOf;
    }
}
