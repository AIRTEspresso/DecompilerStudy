package src.noble;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
interface Becalms<F> {
    Float cypher(short s, Integer num);

    Double illumines(Double d);
}
