package src.noble;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
final class Chagrined extends Filial {
    public double prods;
    public final Boolean soundless;

    public Chagrined(double d, Boolean bool) {
        super(-98, -29.117d);
        this.prods = d;
        this.soundless = bool;
    }

    @Override // src.noble.Filial, src.noble.Becalms
    public final Float cypher(short s, Integer num) {
        return Float.valueOf(0.841f);
    }
}
