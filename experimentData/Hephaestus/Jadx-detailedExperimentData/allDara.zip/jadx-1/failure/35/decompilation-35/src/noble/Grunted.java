package src.noble;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/35/original-35/Test.dex */
public abstract class Grunted extends Filial {
    public Integer chinese;
    public double prods;

    public abstract void vend(Short sh, Boolean bool);

    public Grunted(Integer num, double d) {
        super(64, -51.123d);
        this.chinese = num;
        this.prods = d;
    }
}
