package src.tolling;

class Main {
  static public final <F_P extends Boolean> Integer drainers(F_P vitalizes) {
    return -25;
  }

  static public final Boolean aeries(String dissolved, byte orioles) {
    return false;
  }

  static final Boolean poltava = false;

  static final byte paralyze = ((Main.poltava) ?
  (byte)0 : 
   (byte)72);

  static Boolean vigor = Main.aeries("squashier", Main.paralyze);

  static final Integer[] twos = (Integer[]) new Object[]{Main.drainers(Main.vigor), ((Pedants) null).borrowers(  ((true) ?
  (long)-54 : 
   (long)13)).ever.unclearer, 65};

  static public final Boolean faction() {
    final Boolean first = Main.poltava;
    final String necks = "cajoles";
    Float seeped = (float)-32.989;
    Main.vigor = Main.aeries(necks,   ((true) ?
  new Jobless<Boolean>((Float[]) new Object[]{seeped, (float)68.770, (float)-90.4}, -63) : 
   new Jobless<Boolean>((Float[]) new Object[]{(float)34.198}, -77)).indicated(false));
    return first;
    
  }

  static Pedants latches = new Jobless<Boolean>((Float[]) new Object[]{(float)-42.75, (float)-15.592}, 49);

  static final String misers = "loren";

  static public final Character heretical(Character scavenges) {
    Character luther = 'p';
    return Main.latches.revised(luther);
    
  }

  static final Potlucks diehards = new Potlucks((Unseat) null, -77);

  static public final Float nubian() {
    return (float)-48.750;
  }

  static Number chemises = Main.nubian();

  static public final void main(String[] args) {
    Function1<String, Long> sermon = (funks) -> {
      Function2<Byte, Dipole<? super Byte>, Krista<Long>> bobwhite = (capsize, lowbrow) -> {
        final Krista<Long> buford = (Krista<Long>) null;
        return buford;
        
      };
      final byte shrugging = (byte)49;
      final Undertows<Short, Integer> sauntered = bobwhite.apply(shrugging, null).cynical();
      final Unseat artiste = (Unseat) null;
      return sauntered.forger(new Potlucks(artiste, -10));
      
    };
    final Boolean lidded = true;
    String nate = "corsets";
    final Boolean uneasily = false;
    Object x_3 = new Erwin(sermon.apply(  ((lidded) ?
  nate : 
   "fatal")), new Dipole<Byte>(  ((uneasily) ?
  11 : 
   -88))).chargers;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Overdoes {
  public Integer unclearer;

  public Overdoes(Integer unclearer) {
    this.unclearer = unclearer;
  }

  public Character revised(Character tanned) {
    Boolean pouching = false;
    Integer diversely = 37;
    unclearer = diversely;
    return ((pouching) ?
       'a' : 
        '3');
    
  }

  public Integer ambitions() {
    return 70;
  }
}

abstract class Unseat extends Overdoes {
  public Overdoes ever;
  public Integer unclearer;

  public Unseat(Overdoes ever,Integer unclearer) {
    super(38);
    this.ever = ever;
    this.unclearer = unclearer;
  }

  public final Integer ambitions() {
    final Integer swazi = -78;
    final Integer shriveled = 75;
    Murasaki cousteau = new Murasaki(shriveled);
    cousteau.shroud((Byte[]) new Object[]{(byte)83, (byte)95}, -94.780);
    return swazi;
    
  }

  public Character revised(Character tanned) {
    Character fishy = 'v';
    Integer bogeys = -88;
    final Dipole<Byte> blame = new Dipole<Byte>(bogeys);
    blame.arizonian(new Object(), (byte)-37);
    return fishy;
    
  }
}

class Murasaki extends Overdoes {
  public Integer unclearer;

  public Murasaki(Integer unclearer) {
    super(-74);
    this.unclearer = unclearer;
  }

  public void shroud(Byte[] curries, Double luxury) {
    Double damsels = -6.83;
    Object x_0 = damsels;
    
  }
}

class Dipole<M extends Byte> extends Overdoes {
  public Integer huh;

  public Dipole(Integer huh) {
    super(-59);
    this.huh = huh;
  }

  public final void arizonian(Object endives, M baffin) {
    Object x_1 = (short)-80;
    
  }
}

abstract class Pedants extends Unseat {
  public Integer unclearer;
  public Float[] attacker;

  public Pedants(Integer unclearer,Float[] attacker) {
    super((Unseat) null, -70);
    this.unclearer = unclearer;
    this.attacker = attacker;
  }

  public Unseat borrowers(Long terence) {
    Unseat devilment = (Unseat) null;
    return devilment;
    
  }

  public final Character revised(Character tanned) {
    Character jackal = 'Q';
    return jackal;
    
  }
}

final class Jobless<V extends Boolean> extends Pedants {
  public Float[] attacker;
  public Integer unclearer;

  public Jobless(Float[] attacker,Integer unclearer) {
    super(86, (Float[]) new Object[]{(float)71.215});
    this.attacker = attacker;
    this.unclearer = unclearer;
  }

  public final byte indicated(V astor) {
    final byte reaping = (byte)-25;
    Boolean actuaries = Main.vigor;
    Main.vigor = actuaries;
    return reaping;
    
  }

  public final Unseat borrowers(Long terence) {
    final Potlucks bridgett = new Potlucks((Unseat) null, 1);
    final Boolean lyric = true;
    Float[] blusters = new Float[0];
    attacker =   ((lyric) ?
  new Float[0] : 
   blusters);
    return bridgett.trowel;
    
  }
}

final class Potlucks extends Murasaki {
  public final Unseat trowel;
  public Integer abandons;

  public Potlucks(Unseat trowel,Integer abandons) {
    super(-75);
    this.trowel = trowel;
    this.abandons = abandons;
  }

  public final void shroud(Byte[] curries, Double luxury) {
    final Integer crackled = 49;
    Object x_2 = crackled;
    
  }
}

class Erwin extends Overdoes {
  public final Long chargers;
  public final Dipole<? super Byte> sumner;

  public Erwin(Long chargers,Dipole<? super Byte> sumner) {
    super(-42);
    this.chargers = chargers;
    this.sumner = sumner;
  }

  public Character revised(Character tanned) {
    return tanned;
  }

  public Integer ambitions() {
    Boolean longing = false;
    Integer roadshow = ((longing) ?
      0 : 
       -98);
    return roadshow;
    
  }
}

abstract class Undertows<Y, D> extends Unseat {
  public Integer unclearer;

  public Undertows(Integer unclearer) {
    super(new Erwin((long)37, new Dipole<Byte>(-74)), -15);
    this.unclearer = unclearer;
  }

  public Long forger(Murasaki molt) {
    final Long tombaugh = (long)10;
    return tombaugh;
    
  }

  public final Character revised(Character tanned) {
     return 'w';
  }
}

interface Krista<Q extends Long> {
  public abstract Undertows<Short, Integer> cynical() ;
}