package src.tolling;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
class Erwin extends Overdoes {
    public final Long chargers;
    public final Dipole<? super Byte> sumner;

    public Erwin(Long l, Dipole<? super Byte> dipole) {
        super(-42);
        this.chargers = l;
        this.sumner = dipole;
    }

    @Override // src.tolling.Overdoes
    public Character revised(Character ch) {
        return ch;
    }

    @Override // src.tolling.Overdoes
    public Integer ambitions() {
        int i = 0;
        Boolean bool = false;
        if (!bool.booleanValue()) {
            i = -98;
        }
        return Integer.valueOf(i);
    }
}
