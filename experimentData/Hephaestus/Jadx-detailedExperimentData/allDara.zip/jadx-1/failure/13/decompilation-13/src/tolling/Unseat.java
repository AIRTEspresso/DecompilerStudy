package src.tolling;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public abstract class Unseat extends Overdoes {
    public Overdoes ever;
    public Integer unclearer;

    public Unseat(Overdoes overdoes, Integer num) {
        super(38);
        this.ever = overdoes;
        this.unclearer = num;
    }

    @Override // src.tolling.Overdoes
    public final Integer ambitions() {
        new Murasaki(75).shroud((Byte[]) new Object[]{(byte) 83, (byte) 95}, Double.valueOf(-94.78d));
        return -78;
    }

    @Override // src.tolling.Overdoes
    public Character revised(Character ch) {
        new Dipole(-88).arizonian(new Object(), (byte) -37);
        return 'v';
    }
}
