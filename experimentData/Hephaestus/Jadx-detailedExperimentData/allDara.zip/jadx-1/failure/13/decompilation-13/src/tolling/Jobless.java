package src.tolling;

import java.lang.Boolean;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
final class Jobless<V extends Boolean> extends Pedants {
    public Float[] attacker;
    public Integer unclearer;

    public Jobless(Float[] fArr, Integer num) {
        super(86, (Float[]) new Object[]{Float.valueOf(71.215f)});
        this.attacker = fArr;
        this.unclearer = num;
    }

    public final byte indicated(V v) {
        Main.vigor = Main.vigor;
        return (byte) -25;
    }

    @Override // src.tolling.Pedants
    public final Unseat borrowers(Long l) {
        Potlucks potlucks = new Potlucks(null, 1);
        Boolean bool = true;
        Float[] fArr = new Float[0];
        if (bool.booleanValue()) {
            fArr = new Float[0];
        }
        this.attacker = fArr;
        return potlucks.trowel;
    }
}
