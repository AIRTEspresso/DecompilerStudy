package src.tolling;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public final class Potlucks extends Murasaki {
    public Integer abandons;
    public final Unseat trowel;

    public Potlucks(Unseat unseat, Integer num) {
        super(-75);
        this.trowel = unseat;
        this.abandons = num;
    }

    @Override // src.tolling.Murasaki
    public final void shroud(Byte[] bArr, Double d) {
        Integer.valueOf(49);
    }
}
