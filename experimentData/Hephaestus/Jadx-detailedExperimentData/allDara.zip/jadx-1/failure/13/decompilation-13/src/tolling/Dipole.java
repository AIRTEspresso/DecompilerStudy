package src.tolling;

import java.lang.Byte;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
class Dipole<M extends Byte> extends Overdoes {
    public Integer huh;

    public Dipole(Integer num) {
        super(-59);
        this.huh = num;
    }

    public final void arizonian(Object obj, M m) {
        Short.valueOf((short) -80);
    }
}
