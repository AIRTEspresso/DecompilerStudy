package src.tolling;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
abstract class Pedants extends Unseat {
    public Float[] attacker;
    public Integer unclearer;

    public Pedants(Integer num, Float[] fArr) {
        super(null, -70);
        this.unclearer = num;
        this.attacker = fArr;
    }

    public Unseat borrowers(Long l) {
        return null;
    }

    @Override // src.tolling.Unseat, src.tolling.Overdoes
    public final Character revised(Character ch) {
        return 'Q';
    }
}
