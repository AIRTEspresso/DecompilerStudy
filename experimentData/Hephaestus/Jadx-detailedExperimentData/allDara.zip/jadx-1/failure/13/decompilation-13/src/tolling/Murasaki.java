package src.tolling;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public class Murasaki extends Overdoes {
    public Integer unclearer;

    public Murasaki(Integer num) {
        super(-74);
        this.unclearer = num;
    }

    public void shroud(Byte[] bArr, Double d) {
        Double.valueOf(-6.83d);
    }
}
