package src.tolling;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
abstract class Overdoes {
    public Integer unclearer;

    public Overdoes(Integer num) {
        this.unclearer = num;
    }

    public Character revised(Character ch) {
        char c;
        Boolean bool = false;
        this.unclearer = 37;
        if (bool.booleanValue()) {
            c = 'a';
        } else {
            c = '3';
        }
        return Character.valueOf(c);
    }

    public Integer ambitions() {
        return 70;
    }
}
