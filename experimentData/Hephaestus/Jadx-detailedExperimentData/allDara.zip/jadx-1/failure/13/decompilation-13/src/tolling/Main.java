package src.tolling;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public class Main {
    static Number chemises = null;
    static final Potlucks diehards;
    static Pedants latches = null;
    static final String misers = "loren";
    static final byte paralyze;
    static final Boolean poltava;
    static final Integer[] twos;
    static Boolean vigor;

    Main() {
    }

    public static final <F_P extends Boolean> Integer drainers(F_P f_p) {
        return -25;
    }

    public static final Boolean aeries(String str, byte b) {
        return false;
    }

    static {
        byte b;
        Boolean bool = false;
        poltava = bool;
        if (bool.booleanValue()) {
            b = 0;
        } else {
            b = 72;
        }
        paralyze = b;
        Boolean aeries = aeries("squashier", b);
        vigor = aeries;
        Pedants pedants = null;
        twos = (Integer[]) new Object[]{drainers(aeries), pedants.borrowers(-54L).ever.unclearer, 65};
        latches = new Jobless((Float[]) new Object[]{Float.valueOf(-42.75f), Float.valueOf(-15.592f)}, 49);
        diehards = new Potlucks(null, -77);
        chemises = nubian();
    }

    public static final Boolean faction() {
        Boolean bool = poltava;
        vigor = aeries("cajoles", new Jobless((Float[]) new Object[]{Float.valueOf(-32.989f), Float.valueOf(68.77f), Float.valueOf(-90.4f)}, -63).indicated(false));
        return bool;
    }

    public static final Character heretical(Character ch) {
        return latches.revised('p');
    }

    public static final Float nubian() {
        return Float.valueOf(-48.75f);
    }

    public static final void main(String[] strArr) {
        String str;
        int i;
        $$Lambda$Main$HQXSHcSBajJyuQZ2ZvDwHArZx4 __lambda_main_hqxshcsbajjyuqz2zvdwharzx4 = new Function1() { // from class: src.tolling.-$$Lambda$Main$HQXSHcSBajJyuQZ2-ZvDwHArZx4
            @Override // src.tolling.Function1
            public final Object apply(Object obj) {
                Long forger;
                String str2 = (String) obj;
                forger = ((Krista) new Function2() { // from class: src.tolling.-$$Lambda$Main$N0eFxXToQ1tNz_IopcGPWsNLp1k
                    @Override // src.tolling.Function2
                    public final Object apply(Object obj2, Object obj3) {
                        return Main.lambda$main$0((Byte) obj2, (Dipole) obj3);
                    }
                }.apply((byte) 49, null)).cynical().forger(new Potlucks(null, -10));
                return forger;
            }
        };
        Boolean bool = true;
        Boolean bool2 = false;
        if (bool.booleanValue()) {
            str = "corsets";
        } else {
            str = "fatal";
        }
        Long l = (Long) __lambda_main_hqxshcsbajjyuqz2zvdwharzx4.apply(str);
        if (bool2.booleanValue()) {
            i = 11;
        } else {
            i = -88;
        }
        Long l2 = new Erwin(l, new Dipole(Integer.valueOf(i))).chargers;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Krista lambda$main$0(Byte b, Dipole dipole) {
        return null;
    }
}
