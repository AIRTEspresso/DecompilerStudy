package src.tolling;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public interface Function2<A1, A2, R> {
    R apply(A1 a1, A2 a2);
}
