package src.tolling;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public abstract class Undertows<Y, D> extends Unseat {
    public Integer unclearer;

    public Undertows(Integer num) {
        super(new Erwin(37L, new Dipole(-74)), -15);
        this.unclearer = num;
    }

    public Long forger(Murasaki murasaki) {
        return 10L;
    }

    @Override // src.tolling.Unseat, src.tolling.Overdoes
    public final Character revised(Character ch) {
        return 'w';
    }
}
