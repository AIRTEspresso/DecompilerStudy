package src.tolling;

import java.lang.Long;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/13/original-13/Test.dex */
public interface Krista<Q extends Long> {
    Undertows<Short, Integer> cynical();
}
