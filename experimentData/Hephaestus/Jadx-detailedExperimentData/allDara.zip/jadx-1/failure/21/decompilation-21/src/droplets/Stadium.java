package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public final class Stadium extends Mangles<Spectra> {
    public final Mewls darker;
    public Spectra needled;

    public Stadium(Spectra spectra, Mewls mewls) {
        super(-33, new Mewls((Integer[]) new Object[]{89, -98}));
        this.needled = spectra;
        this.darker = mewls;
    }

    public final Long achieved(Spectra spectra, Long l) {
        return new Lakota(6L).sailboats;
    }

    public final Long ephraim() {
        return new Lakota(-38L).sailboats;
    }
}
