package src.droplets;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
class Halibuts extends Mewls {
    public final Mewls arthurian;

    public Halibuts(Mewls mewls) {
        super((Integer[]) new Object[]{36, -45});
        this.arthurian = mewls;
    }

    public final byte sallower(Float f) {
        return (byte) -51;
    }
}
