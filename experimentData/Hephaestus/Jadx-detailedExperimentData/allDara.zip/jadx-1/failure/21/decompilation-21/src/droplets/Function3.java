package src.droplets;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
interface Function3<A1, A2, A3, R> {
    R apply(A1 a1, A2 a2, A3 a3);
}
