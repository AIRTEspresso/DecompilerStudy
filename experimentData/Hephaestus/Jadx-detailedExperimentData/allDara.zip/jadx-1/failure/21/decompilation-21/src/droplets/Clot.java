package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public final class Clot<W> extends Spoonful {
    public Spoonful encores;

    public Clot(Spoonful spoonful) {
        super(new Mewls((Integer[]) new Object[]{47}));
        this.encores = spoonful;
    }

    @Override // src.droplets.Spoonful
    public long soaks(long j, Integer num) {
        return 32L;
    }

    @Override // src.droplets.Spoonful
    public final void wry(Character ch, short s) {
    }
}
