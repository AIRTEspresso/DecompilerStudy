package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public class Main {
    static float extracts = 0.0f;
    static final int galen = 29;
    static final Character greyish;
    static final Mangles<Mewls> sexless = new Mangles<>(-90, new Mewls((Integer[]) new Object[]{71}));
    static Integer japed = 33;
    static final Number[] bombers = sexless.reviewers().arthurian.drooped;
    static Byte croziers = (byte) -61;

    Main() {
    }

    static {
        Spectra spectra = null;
        Chambray chambray = (Chambray) spectra;
        greyish = chambray.pundits;
        Spectra spectra2 = spectra;
        extracts = spectra2.wintrier;
    }

    public static final Long mistiest(float f, Long l) {
        return mistiest(f, l);
    }

    public static final int shannon() {
        Boolean.valueOf(false);
        return galen;
    }

    public static final <F_B extends Double> Spectra asleep(F_B f_b, Character ch) {
        return crusting().needled;
    }

    public static final Stadium crusting() {
        Stadium crusting = crusting();
        ((Clot) new Function1() { // from class: src.droplets.-$$Lambda$Main$r4DBEcg7O6OVWJn9evuF-_kyjRs
            @Override // src.droplets.Function1
            public final Object apply(Object obj) {
                return Main.lambda$crusting$0((String) obj);
            }
        }.apply("selling")).encores.wry('p', (short) -23);
        return crusting;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Clot lambda$crusting$0(String str) {
        return new Clot(null);
    }

    public static final Boolean uniting() {
        new Function1() { // from class: src.droplets.-$$Lambda$Main$Vhh2lM9Qo0_CtI4NUcGrWAsZTXY
            @Override // src.droplets.Function1
            public final Object apply(Object obj) {
                return Main.lambda$uniting$1((Character) obj);
            }
        }.apply('f');
        return true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$uniting$1(Character ch) {
        Spectra spectra = null;
        spectra.wintrier = 13.28f;
        new Stadium(spectra, new Mewls((Integer[]) new Object[]{42, -19}));
        return null;
    }

    public static final void main(String[] strArr) {
        double doubleValue;
        Boolean uniting = uniting();
        Double valueOf = Double.valueOf(98.674d);
        if (uniting.booleanValue()) {
            doubleValue = 84.82d;
        } else {
            doubleValue = valueOf.doubleValue();
        }
        Double.valueOf(doubleValue);
    }
}
