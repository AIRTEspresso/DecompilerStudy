package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public class Mewls {
    public Integer[] drooped;

    public Mewls(Integer[] numArr) {
        this.drooped = numArr;
    }
}
