package src.droplets;

import src.droplets.Mewls;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
class Mangles<V extends Mewls> extends Halibuts {
    public final Mewls darker;
    public final int dominos;

    public Mangles(int i, Mewls mewls) {
        super(new Mewls((Integer[]) new Object[]{-10, 27, -43}));
        this.dominos = i;
        this.darker = mewls;
    }

    public final Halibuts reviewers() {
        this.darker.drooped = new Integer[0];
        return new Halibuts(new Mewls(new Integer[0]));
    }

    public final float pynchon(V v, Mangles<? super Mewls> mangles) {
        return -77.752f;
    }
}
