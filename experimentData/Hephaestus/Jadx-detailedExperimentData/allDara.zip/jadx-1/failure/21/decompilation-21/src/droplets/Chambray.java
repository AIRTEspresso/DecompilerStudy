package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public abstract class Chambray extends Mangles<Halibuts> {
    public final Mewls darker;
    public Character pundits;

    public Chambray(Character ch, Mewls mewls) {
        super(-81, new Mangles(73, new Mewls((Integer[]) new Object[]{-49, 20})));
        this.pundits = ch;
        this.darker = mewls;
    }
}
