package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public abstract class Spectra extends Mangles<Mewls> {
    public final Mewls darker;
    public float wintrier;

    public abstract Integer truckling(Integer num, int i);

    public Spectra(float f, Mewls mewls) {
        super(2, new Halibuts(new Mewls((Integer[]) new Object[]{90, 62, -90})));
        this.wintrier = f;
        this.darker = mewls;
    }
}
