package src.droplets;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
final class Blush extends Chambray {
    public final Mewls darker;

    public Blush(Mewls mewls) {
        super('V', new Mewls((Integer[]) new Object[]{-4}));
        this.darker = mewls;
    }

    public final Chambray decoding(Chambray chambray, Halibuts halibuts) {
        new Function0() { // from class: src.droplets.-$$Lambda$Blush$N4-aPRo8_rB3WM7iHgjeQgZJwlE
            @Override // src.droplets.Function0
            public final Object apply() {
                return Blush.lambda$decoding$0();
            }
        }.apply();
        return chambray;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$decoding$0() {
        Character ch = Main.greyish;
        new Blush(new Mewls((Integer[]) new Object[]{-98, 76})).pundits = 'J';
        return null;
    }
}
