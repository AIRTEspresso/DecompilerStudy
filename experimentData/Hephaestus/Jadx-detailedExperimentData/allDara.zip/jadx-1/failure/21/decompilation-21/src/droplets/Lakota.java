package src.droplets;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
final class Lakota extends Mewls {
    public final Long sailboats;

    public Lakota(Long l) {
        super((Integer[]) new Object[]{77, -75});
        this.sailboats = l;
    }

    public final Lakota idahoan() {
        return null;
    }

    public final String rhythm(String str, Long... lArr) {
        return "modulates";
    }
}
