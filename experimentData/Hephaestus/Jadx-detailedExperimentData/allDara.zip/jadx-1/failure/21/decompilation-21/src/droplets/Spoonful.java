package src.droplets;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/21/original-21/Test.dex */
public abstract class Spoonful extends Mangles<Mewls> {
    public final Mewls darker;

    public abstract long soaks(long j, Integer num);

    public Spoonful(Mewls mewls) {
        super(93, new Mewls((Integer[]) new Object[]{79, 72, 68}));
        this.darker = mewls;
    }

    public void wry(Character ch, short s) {
        new Stadium(null, new Mewls(new Integer[0]));
        new Function0() { // from class: src.droplets.-$$Lambda$Spoonful$JlHD4zjH4pPcwV1EEqRhD_qsMGE
            @Override // src.droplets.Function0
            public final Object apply() {
                return Spoonful.lambda$wry$0();
            }
        }.apply();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$wry$0() {
        Boolean.valueOf(true);
        return null;
    }
}
