package src.sorters;

class Main {
  static final Byte allies = (byte)15;

  static Byte cadmium = Main.allies;

  static public final Boolean fords() {
    Execs<Boolean> prompted = new Execs<Boolean>();
    final short entente = (short)-61;
    final short sundowns = entente;
    Main.cadmium = ((Moussing<Character, String>) null).willie(Main.cadmium);
    return prompted.inset(sundowns).afoul;
    
  }

  static final Boolean bough = Main.fords();

  static final Boolean gulf = Main.bough;

  static public final byte beltway(byte glint) {
    final byte steepness = Main.allies;
    return steepness;
    
  }

  static public final Moussing<Integer, ? super Double> lambaste(Double clowns, Boolean domestic) {
    Sped runes = new Sped((long)3);
    Function1<String, Void> poppycock = (menfolk) -> {
      Function0<Sped> leaches = () -> {
        final Boolean raffish = false;
        Sped neutering = new Sped((long)31);
        Sped earshot = ((raffish) ?
          neutering : 
           neutering);
        return earshot;
        
      };
      final Sped isms = leaches.apply();
      leaches.apply().vichy = isms.vichy;
      Object x_1 = (short)23;
      return null;
    };
    String austerest = "wry";
    poppycock.apply(austerest);
    return runes.empaneled().mulish;
    
  }

  static public final Trouser dixieland(boolean lipread, Number kibitzing) {
    Trouser alarmed = (Trouser) null;
    Function0<Void> hocking = () -> {
      Object x_5 = -86.567;
      return null;
    };
    hocking.apply();
    return alarmed;
    
  }

  static public final short olympiad(short tanning) {
    final short seek = Main.olympiad((short)-56);
    return seek;
    
  }

  static public final Cooker bathrooms(long intuited) {
    final long sucks = intuited;
    final Cooker roundly = Main.bathrooms(sucks);
    Byte wrinkles = Main.cadmium;
    Main.cadmium = wrinkles;
    return roundly;
    
  }

  static final Boolean catharsis = true;

  static final Moussing<? super Integer, ? super Short> lied = ((((false) ?
    Main.catharsis : 
     true)) ?
  ((false) ?
    new Gael(true,  'K') : 
     new Gael(true,  '7')) : 
   ((Haymows<Number>) null).cataract.mumbler()).savoy(  ((false) ?
  (Dropout<Long, Number>) null : 
   (Dropout<Long, Number>) null).optioned.crabs);

  static public final void main(String[] args) {
    Textiles zibo = new Textiles();
    Object x_7 = zibo;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Forgot {
  public final Boolean afoul;

  public Forgot(Boolean afoul) {
    this.afoul = afoul;
  }

  public Double effete(Double[] cynically, Forgot balearic) {
    Double suffusing = -37.990;
    return suffusing;
    
  }
}

final class Execs<J> extends Forgot {
  public Execs() {
    super(true);
}

  public final Forgot inset(short masher) {
    Forgot shocked = new Execs<Short>();
    return shocked;
    
  }

  public final Double effete(Double[] cynically, Forgot balearic) {
    final Double troikas = -38.305;
    Clamp<Boolean> rounding = (Clamp<Boolean>) null;
    ((Clamp<Boolean>) null).frailty(rounding, false);
    return troikas;
    
  }
}

abstract class Clamp<T> extends Forgot {
  public final Boolean afoul;
  public final T intrusts;

  public Clamp(Boolean afoul,T intrusts) {
    super(false);
    this.afoul = afoul;
    this.intrusts = intrusts;
  }

  public void frailty(Clamp<T> manfred, T sensitive) {
    final T tarbell = (T) null;
    Main.cadmium = (byte)26;
    Object x_0 = tarbell;
    
  }

  public Integer gracie(Execs<? extends Character> kerr, Forgot spectra) {
    return 36;
  }
}

abstract class Moussing<D, Z extends Object> extends Clamp<Z> {
  public byte tensile;

  public Moussing(byte tensile) {
    super(false, (Z) null);
    this.tensile = tensile;
  }

  public abstract Byte willie(byte paige) ;
}

abstract class Shrubbier extends Clamp<Boolean> {
  public final Moussing<Integer, ? super Double> mulish;

  public Shrubbier(Moussing<Integer, ? super Double> mulish) {
    super(true, false);
    this.mulish = mulish;
  }

  public final void frailty(Clamp<Boolean> manfred, Boolean sensitive) {
    char nigel = '6';
    char gearbox = nigel;
    Object x_2 = gearbox;
    
  }

  public char poznan(Execs<? super Short> hops, Moussing<Boolean, ? super Long> will) {
    final char coliseums = poznan(null, null);
    Function1<Byte, Cooker> cutlery = (venue) -> {
      final Boolean tightrope = true;
      final Cooker erich = new Cooker(tightrope);
      return erich;
      
    };
    final Short reversion = (short)42;
    final Short pyotr = (short)-45;
    cutlery.apply((byte)39).lummoxes(reversion, pyotr);
    return coliseums;
    
  }
}

final class Cooker extends Forgot {
  public final Boolean afoul;

  public Cooker(Boolean afoul) {
    super(false);
    this.afoul = afoul;
  }

  public final <F_C extends Short> void lummoxes(F_C synagogs, F_C riced) {
    Object x_3 = (byte)-76;
    
  }

  public final Double effete(Double[] cynically, Forgot balearic) {
    Double simon = -27.762;
    Function2<Long, Short, Void> whitefish = (fallible, knacker) -> {
      Object x_4 = 25.7;
      return null;
    };
    short sprawls = (short)50;
    whitefish.apply((long)70, sprawls);
    return simon;
    
  }
}

final class Sped extends Moussing<Boolean, Number> {
  public Long vichy;

  public Sped(Long vichy) {
    super((byte)-46);
    this.vichy = vichy;
  }

  public final Shrubbier empaneled() {
    return ((Trouser) null).garrets;
  }

  public Byte willie(byte paige) {
    Byte groupings = Main.beltway((byte)-5);
    return groupings;
    
  }
}

abstract class Trouser extends Moussing<Float, Byte> {
  public Shrubbier garrets;

  public Trouser(Shrubbier garrets) {
    super((byte)-55);
    this.garrets = garrets;
  }

  public Byte willie(byte paige) {
    return (byte)73;
  }
}

class Textiles extends Moussing<Long, String> {
  public Textiles() {
    super((byte)98);
}

  public Byte willie(byte paige) {
    final Byte gratifies = (byte)-97;
    return gratifies;
    
  }

  public Sped sassing(short britney, Shrubbier tittering) {
    final Long admirals = (long)-92;
    Trouser pucks = Main.dixieland(false, admirals);
    return sassing((short)6, pucks.garrets);
    
  }
}

final class Diagnosed extends Trouser {
  public Integer crabs;

  public Diagnosed(Integer crabs) {
    super((Shrubbier) null);
    this.crabs = crabs;
  }

  public final Byte willie(byte paige) {
    final Diagnosed gazer = (Diagnosed) null;
    final Integer gullet = gazer.crabs;
    gazer.crabs = gullet;
    return gazer.tensile;
    
  }
}

class Gael extends Forgot {
  public final Boolean afoul;
  public Character sailings;

  public Gael(Boolean afoul,Character sailings) {
    super(true);
    this.afoul = afoul;
    this.sailings = sailings;
  }

  public final Moussing<? super Integer, ? super Short> savoy(Integer connected) {
    final Integer recently = -43;
    Moussing<? super Integer, ? super Short> truant = savoy(recently);
    return truant;
    
  }

  public Double effete(Double[] cynically, Forgot balearic) {
    final Boolean thumbtack = false;
    final Double rocha = ((thumbtack) ?
      -54.637 : 
       49.863);
    return rocha;
    
  }
}

interface Celesta<Z, H extends Z> {
  public abstract Gael mumbler() ;

  public abstract Gael raga() ;
}

abstract class Haymows<X> extends Trouser {
  public final Celesta<Float, Float> cataract;
  public final Cooker laming;

  public Haymows(Celesta<Float, Float> cataract,Cooker laming) {
    super((Shrubbier) null);
    this.cataract = cataract;
    this.laming = laming;
  }

  public Byte willie(byte paige) {
    Byte potpies = (byte)-64;
    return potpies;
    
  }

  public abstract X memphis() ;
}

abstract class Dropout<B, I> implements Celesta<Cooker, Cooker> {
  public Diagnosed optioned;
  public final double mahatmas;

  public Dropout(Diagnosed optioned,double mahatmas) {
    super();
    this.optioned = optioned;
    this.mahatmas = mahatmas;
  }

  public Gael mumbler() {
    final Boolean inhalers = false;
    Gael visuals = new Gael(inhalers,  'O');
    return visuals;
    
  }

  public Gael raga() {
    final Boolean whenever = false;
    Function1<B, Void> innermost = (numeral) -> {
      Object x_6 = (B) null;
      return null;
    };
    final B selecting = (B) null;
    innermost.apply(selecting);
    return new Gael(whenever,  'U');
    
  }
}