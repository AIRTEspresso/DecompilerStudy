package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
class Gael extends Forgot {
    public final Boolean afoul;
    public Character sailings;

    public Gael(Boolean bool, Character ch) {
        super(true);
        this.afoul = bool;
        this.sailings = ch;
    }

    public final Moussing<? super Integer, ? super Short> savoy(Integer num) {
        return savoy(-43);
    }

    @Override // src.sorters.Forgot
    public Double effete(Double[] dArr, Forgot forgot) {
        double d;
        Boolean bool = false;
        if (bool.booleanValue()) {
            d = -54.637d;
        } else {
            d = 49.863d;
        }
        return Double.valueOf(d);
    }
}
