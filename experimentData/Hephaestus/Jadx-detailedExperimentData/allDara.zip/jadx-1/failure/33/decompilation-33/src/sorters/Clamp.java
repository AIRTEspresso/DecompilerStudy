package src.sorters;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
public abstract class Clamp<T> extends Forgot {
    public final Boolean afoul;
    public final T intrusts;

    public Clamp(Boolean bool, T t) {
        super(false);
        this.afoul = bool;
        this.intrusts = t;
    }

    public void frailty(Clamp<T> clamp, T t) {
        Main.cadmium = (byte) 26;
    }

    public Integer gracie(Execs<? extends Character> execs, Forgot forgot) {
        return 36;
    }
}
