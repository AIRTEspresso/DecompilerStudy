package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
abstract class Haymows<X> extends Trouser {
    public final Celesta<Float, Float> cataract;
    public final Cooker laming;

    public abstract X memphis();

    public Haymows(Celesta<Float, Float> celesta, Cooker cooker) {
        super(null);
        this.cataract = celesta;
        this.laming = cooker;
    }

    @Override // src.sorters.Trouser, src.sorters.Moussing
    public Byte willie(byte b) {
        return (byte) -64;
    }
}
