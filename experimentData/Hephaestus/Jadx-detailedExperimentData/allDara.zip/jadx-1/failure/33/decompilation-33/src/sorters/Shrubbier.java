package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
abstract class Shrubbier extends Clamp<Boolean> {
    public final Moussing<Integer, ? super Double> mulish;

    public Shrubbier(Moussing<Integer, ? super Double> moussing) {
        super(true, false);
        this.mulish = moussing;
    }

    @Override // src.sorters.Clamp
    public final void frailty(Clamp<Boolean> clamp, Boolean bool) {
        Character.valueOf('6');
    }

    public char poznan(Execs<? super Short> execs, Moussing<Boolean, ? super Long> moussing) {
        char poznan = poznan(null, null);
        ((Cooker) new Function1() { // from class: src.sorters.-$$Lambda$Shrubbier$e3Jc94m_Il72gdV_2Y-Bg-qP-7E
            @Override // src.sorters.Function1
            public final Object apply(Object obj) {
                return Shrubbier.lambda$poznan$0((Byte) obj);
            }
        }.apply((byte) 39)).lummoxes((short) 42, (short) -45);
        return poznan;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Cooker lambda$poznan$0(Byte b) {
        return new Cooker(true);
    }
}
