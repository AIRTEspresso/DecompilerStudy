package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
interface Celesta<Z, H extends Z> {
    Gael mumbler();

    Gael raga();
}
