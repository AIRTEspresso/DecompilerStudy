package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
final class Diagnosed extends Trouser {
    public Integer crabs;

    public Diagnosed(Integer num) {
        super(null);
        this.crabs = num;
    }

    @Override // src.sorters.Trouser, src.sorters.Moussing
    public final Byte willie(byte b) {
        Diagnosed diagnosed = null;
        diagnosed.crabs = diagnosed.crabs;
        return Byte.valueOf(diagnosed.tensile);
    }
}
