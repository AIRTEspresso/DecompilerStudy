package src.sorters;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
public final class Sped extends Moussing<Boolean, Number> {
    public Long vichy;

    public Sped(Long l) {
        super((byte) -46);
        this.vichy = l;
    }

    public final Shrubbier empaneled() {
        Trouser trouser = null;
        return trouser.garrets;
    }

    @Override // src.sorters.Moussing
    public Byte willie(byte b) {
        return Byte.valueOf(Main.beltway((byte) -5));
    }
}
