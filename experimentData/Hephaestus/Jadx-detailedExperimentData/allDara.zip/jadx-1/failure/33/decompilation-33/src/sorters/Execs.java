package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
final class Execs<J> extends Forgot {
    public Execs() {
        super(true);
    }

    public final Forgot inset(short s) {
        return new Execs();
    }

    @Override // src.sorters.Forgot
    public final Double effete(Double[] dArr, Forgot forgot) {
        Double valueOf = Double.valueOf(-38.305d);
        Clamp clamp = null;
        clamp.frailty(clamp, false);
        return valueOf;
    }
}
