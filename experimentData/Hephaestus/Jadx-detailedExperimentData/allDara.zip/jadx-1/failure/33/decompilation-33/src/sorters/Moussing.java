package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
abstract class Moussing<D, Z> extends Clamp<Z> {
    public byte tensile;

    public abstract Byte willie(byte b);

    public Moussing(byte b) {
        super(false, null);
        this.tensile = b;
    }
}
