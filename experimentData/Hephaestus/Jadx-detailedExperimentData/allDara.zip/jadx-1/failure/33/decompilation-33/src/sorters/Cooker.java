package src.sorters;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
public final class Cooker extends Forgot {
    public final Boolean afoul;

    public Cooker(Boolean bool) {
        super(false);
        this.afoul = bool;
    }

    public final <F_C extends Short> void lummoxes(F_C f_c, F_C f_c2) {
        Byte.valueOf((byte) -76);
    }

    @Override // src.sorters.Forgot
    public final Double effete(Double[] dArr, Forgot forgot) {
        Double valueOf = Double.valueOf(-27.762d);
        new Function2() { // from class: src.sorters.-$$Lambda$Cooker$6Wwq1jJSQdZjY3k-DqsSFWRF-Bg
            @Override // src.sorters.Function2
            public final Object apply(Object obj, Object obj2) {
                return Cooker.lambda$effete$0((Long) obj, (Short) obj2);
            }
        }.apply(70L, (short) 50);
        return valueOf;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$effete$0(Long l, Short sh) {
        Double.valueOf(25.7d);
        return null;
    }
}
