package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
class Textiles extends Moussing<Long, String> {
    public Textiles() {
        super((byte) 98);
    }

    @Override // src.sorters.Moussing
    public Byte willie(byte b) {
        return (byte) -97;
    }

    public Sped sassing(short s, Shrubbier shrubbier) {
        return sassing((short) 6, Main.dixieland(false, -92L).garrets);
    }
}
