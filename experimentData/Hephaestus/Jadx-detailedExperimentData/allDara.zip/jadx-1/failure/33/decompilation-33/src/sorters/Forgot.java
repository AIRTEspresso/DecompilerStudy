package src.sorters;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
public abstract class Forgot {
    public final Boolean afoul;

    public Forgot(Boolean bool) {
        this.afoul = bool;
    }

    public Double effete(Double[] dArr, Forgot forgot) {
        return Double.valueOf(-37.99d);
    }
}
