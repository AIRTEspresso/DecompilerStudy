package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
abstract class Trouser extends Moussing<Float, Byte> {
    public Shrubbier garrets;

    public Trouser(Shrubbier shrubbier) {
        super((byte) -55);
        this.garrets = shrubbier;
    }

    @Override // src.sorters.Moussing
    public Byte willie(byte b) {
        return (byte) 73;
    }
}
