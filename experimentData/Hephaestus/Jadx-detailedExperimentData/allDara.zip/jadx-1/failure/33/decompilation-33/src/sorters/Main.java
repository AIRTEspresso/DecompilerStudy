package src.sorters;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
public class Main {
    static final Boolean bough;
    static final Boolean catharsis;
    static final Boolean gulf;
    static final Moussing<? super Integer, ? super Short> lied;
    static final Byte allies = (byte) 15;
    static Byte cadmium = (byte) 15;

    Main() {
    }

    static {
        Boolean fords = fords();
        bough = fords;
        gulf = fords;
        catharsis = true;
        Dropout dropout = null;
        lied = new Gael(true, '7').savoy(dropout.optioned.crabs);
    }

    public static final Boolean fords() {
        Execs execs = new Execs();
        Moussing moussing = null;
        cadmium = moussing.willie(cadmium.byteValue());
        return execs.inset((short) -61).afoul;
    }

    public static final byte beltway(byte b) {
        return allies.byteValue();
    }

    public static final Moussing<Integer, ? super Double> lambaste(Double d, Boolean bool) {
        Sped sped = new Sped(3L);
        new Function1() { // from class: src.sorters.-$$Lambda$Main$EATOxxxPwm9srlzgZXotOGsrHOU
            @Override // src.sorters.Function1
            public final Object apply(Object obj) {
                return Main.lambda$lambaste$1((String) obj);
            }
        }.apply("wry");
        return sped.empaneled().mulish;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$lambaste$1(String str) {
        $$Lambda$Main$2zdwG_Mu6xqg_OGDc00sE2bK7WA __lambda_main_2zdwg_mu6xqg_ogdc00se2bk7wa = new Function0() { // from class: src.sorters.-$$Lambda$Main$2zdwG_Mu6xqg_OGDc00sE2bK7WA
            @Override // src.sorters.Function0
            public final Object apply() {
                return Main.lambda$lambaste$0();
            }
        };
        ((Sped) __lambda_main_2zdwg_mu6xqg_ogdc00se2bk7wa.apply()).vichy = ((Sped) __lambda_main_2zdwg_mu6xqg_ogdc00se2bk7wa.apply()).vichy;
        Short.valueOf((short) 23);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Sped lambda$lambaste$0() {
        Boolean bool = false;
        Sped sped = new Sped(31L);
        if (bool.booleanValue()) {
        }
        return sped;
    }

    public static final Trouser dixieland(boolean z, Number number) {
        Trouser trouser = null;
        new Function0() { // from class: src.sorters.-$$Lambda$Main$3gXT9CeIFgB8GV-y6FVNYw7bxto
            @Override // src.sorters.Function0
            public final Object apply() {
                return Main.lambda$dixieland$2();
            }
        }.apply();
        return trouser;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$dixieland$2() {
        Double.valueOf(-86.567d);
        return null;
    }

    public static final short olympiad(short s) {
        return olympiad((short) -56);
    }

    public static final Cooker bathrooms(long j) {
        Cooker bathrooms = bathrooms(j);
        cadmium = cadmium;
        return bathrooms;
    }

    public static final void main(String[] strArr) {
        new Textiles();
    }
}
