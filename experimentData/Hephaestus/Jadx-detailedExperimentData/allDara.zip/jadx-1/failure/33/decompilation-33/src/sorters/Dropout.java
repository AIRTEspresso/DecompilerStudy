package src.sorters;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/33/original-33/Test.dex */
abstract class Dropout<B, I> implements Celesta<Cooker, Cooker> {
    public final double mahatmas;
    public Diagnosed optioned;

    public Dropout(Diagnosed diagnosed, double d) {
        this.optioned = diagnosed;
        this.mahatmas = d;
    }

    @Override // src.sorters.Celesta
    public Gael mumbler() {
        return new Gael(false, 'O');
    }

    @Override // src.sorters.Celesta
    public Gael raga() {
        new Function1() { // from class: src.sorters.-$$Lambda$Dropout$Nob3W8peAtDP0RQUTheu2TKi6Cw
            @Override // src.sorters.Function1
            public final Object apply(Object obj) {
                return Dropout.lambda$raga$0(obj);
            }
        }.apply(null);
        return new Gael(false, 'U');
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$raga$0(Object obj) {
        return null;
    }
}
