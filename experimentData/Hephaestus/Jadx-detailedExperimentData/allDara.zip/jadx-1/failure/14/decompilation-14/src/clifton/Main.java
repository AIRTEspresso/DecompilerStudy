package src.clifton;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
public class Main {
    static final Integer chirping = 14;
    static Integer furls = 14;
    static final Integer instruct = 14;
    static Entreated<? super Character, ? super Number, Character> scribbler;
    static Boolean standard;
    static Short tulsa;

    Main() {
    }

    public static final Byte lollygags(Integer num) {
        return lollygags(num);
    }

    static {
        Boolean bool = true;
        standard = bool;
        bool.booleanValue();
        scribbler = new Nsa(new Menzies()).forswears.opera(standard);
        tulsa = new Goldfinch(Short.valueOf(scribbler.buttons()), new Cynical(new Object()).sequel(16)).cheapness;
    }

    public static final Jigsawing afire(Float f) {
        return new Jigsawing();
    }

    public static final byte attar(byte b) {
        Caring caring = new Caring((byte) -34, (short) 62);
        new Function2() { // from class: src.clifton.-$$Lambda$Main$NUufl_GMaPjz-CYhZqSKFVBWD3o
            @Override // src.clifton.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$attar$1((Float) obj, (String) obj2);
            }
        }.apply(Float.valueOf(100.482f), "trinkets");
        return caring.husky;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$attar$1(Float f, String str) {
        $$Lambda$Main$rav3zgpkOI0PSgK_7k1F5ukrw2g __lambda_main_rav3zgpkoi0psgk_7k1f5ukrw2g = new Function2() { // from class: src.clifton.-$$Lambda$Main$rav3zgpkOI0PSgK_7k1F5ukrw2g
            @Override // src.clifton.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$attar$0((Boolean) obj, (Float) obj2);
            }
        };
        Long.valueOf(-13L);
        Long l = -12L;
        __lambda_main_rav3zgpkoi0psgk_7k1f5ukrw2g.apply(Boolean.valueOf(-21.174d < ((double) l.longValue())), Float.valueOf(-65.953f));
        Short.valueOf((short) -27);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$attar$0(Boolean bool, Float f) {
        Bicuspids bicuspids = new Bicuspids(new Menzies());
        new Wino(bicuspids).snarkiest.smells = bicuspids.smells;
        Integer.valueOf(-59);
        return null;
    }

    public static final <F_Q extends Hutches<? super Float, Short>> void idlers(F_Q f_q) {
        Long.valueOf(85L);
    }

    public static final void main(String[] strArr) {
        Feeble feeble = null;
        feeble.dressing.jansen(Double.valueOf(44.219d), 62);
        Boolean.valueOf(standard.booleanValue());
    }
}
