package src.clifton;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
class Jigsawing implements Entreated<Object, Integer, Double> {
    public final Menzies<Boolean, Appear> manes() {
        return new Menzies<>();
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return (short) 56;
    }
}
