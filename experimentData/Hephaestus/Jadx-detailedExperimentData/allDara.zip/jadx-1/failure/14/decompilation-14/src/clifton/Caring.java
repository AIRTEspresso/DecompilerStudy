package src.clifton;

import java.lang.Short;
/* JADX WARN: Incorrect field signature: TL; */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
final class Caring<A extends Short, L extends A> implements Entreated<Character, Integer, Long> {
    public byte husky;
    public Short negotiate;

    /* JADX WARN: Incorrect types in method signature: (BTL;)V */
    public Caring(byte b, Short sh) {
        this.husky = b;
        this.negotiate = sh;
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return new Goldfinch((short) 37, null).cheapness.shortValue();
    }

    /* JADX WARN: Incorrect return type in method signature: ()TL; */
    public final Short facings() {
        Short sh = this.negotiate;
        Main.scribbler = null;
        return sh;
    }
}
