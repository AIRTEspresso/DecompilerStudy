package src.clifton;

import java.lang.Short;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
class Goldfinch<I extends Short> implements Entreated<I, I, Object> {
    public final I cheapness;
    public final Entreated<? super Double, String, ? extends Integer> karats;

    public Goldfinch(I i, Entreated<? super Double, String, ? extends Integer> entreated) {
        this.cheapness = i;
        this.karats = entreated;
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return (short) -77;
    }
}
