package src.clifton;

import java.lang.Short;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
class Hutches<Q, Z extends Short> implements Entreated<Integer, Float, Object> {
    @Override // src.clifton.Entreated
    public short buttons() {
        return new Goldfinch(null, null).cheapness.shortValue();
    }
}
