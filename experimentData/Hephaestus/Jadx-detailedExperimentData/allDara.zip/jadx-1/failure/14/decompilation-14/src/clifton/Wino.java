package src.clifton;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
public final class Wino implements Entreated<Appear, Byte, Short> {
    public Bicuspids snarkiest;

    public Wino(Bicuspids bicuspids) {
        this.snarkiest = bicuspids;
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return (short) -18;
    }
}
