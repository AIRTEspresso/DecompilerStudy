package src.clifton;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
public final class Bicuspids extends Jigsawing {
    public Menzies<Boolean, Boolean> smells;

    public Bicuspids(Menzies<Boolean, Boolean> menzies) {
        this.smells = menzies;
    }

    @Override // src.clifton.Jigsawing, src.clifton.Entreated
    public final short buttons() {
        return buttons();
    }

    public final Double swiveled(double d) {
        return Double.valueOf(-16.933d);
    }
}
