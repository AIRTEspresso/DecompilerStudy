package src.clifton;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
final class Nsa implements Entreated<Float, Double, Boolean> {
    public Menzies<Boolean, Appear> forswears;

    public Nsa(Menzies<Boolean, Appear> menzies) {
        this.forswears = menzies;
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return (short) 43;
    }
}
