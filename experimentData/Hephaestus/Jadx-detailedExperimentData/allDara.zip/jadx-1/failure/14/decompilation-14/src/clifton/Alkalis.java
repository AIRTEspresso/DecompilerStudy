package src.clifton;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
final class Alkalis<M extends Integer, H> implements Entreated<M, M, Object> {
    Alkalis() {
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return Main.scribbler.buttons();
    }
}
