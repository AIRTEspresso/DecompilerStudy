package src.clifton;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
final class Cynical extends Goldfinch<Short> {
    public Object salads;

    public Cynical(Object obj) {
        super((short) 42, null);
        this.salads = obj;
    }

    public final Entreated<? super Double, String, ? extends Integer> sequel(int i) {
        Entreated<? super Double, String, ? extends Integer> entreated = null;
        Main.standard = true;
        return entreated;
    }

    @Override // src.clifton.Goldfinch, src.clifton.Entreated
    public final short buttons() {
        return (short) -70;
    }
}
