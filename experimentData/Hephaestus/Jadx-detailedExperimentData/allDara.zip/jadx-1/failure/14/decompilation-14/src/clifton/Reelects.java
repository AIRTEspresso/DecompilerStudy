package src.clifton;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
class Reelects extends Jigsawing {
    public final boolean jansen(Double d, int i) {
        Main.idlers(new Hutches());
        return true;
    }

    @Override // src.clifton.Jigsawing, src.clifton.Entreated
    public short buttons() {
        return (short) 15;
    }
}
