package src.clifton;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
abstract class Feeble extends Goldfinch<Short> {
    public Goldfinch<? super Short> crabbier;
    public Reelects dressing;

    public Feeble(Reelects reelects, Goldfinch<? super Short> goldfinch) {
        super((short) 14, null);
        this.dressing = reelects;
        this.crabbier = goldfinch;
    }

    @Override // src.clifton.Goldfinch, src.clifton.Entreated
    public final short buttons() {
        return (short) 9;
    }

    public <F_S> F_S glory(F_S f_s) {
        return null;
    }
}
