package src.clifton;

import java.lang.Boolean;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/14/original-14/Test.dex */
public final class Menzies<U extends Boolean, M> implements Entreated<M, U, Object> {
    public final Entreated<? super Character, ? super Number, Character> opera(Boolean bool) {
        return null;
    }

    @Override // src.clifton.Entreated
    public short buttons() {
        return buttons();
    }
}
