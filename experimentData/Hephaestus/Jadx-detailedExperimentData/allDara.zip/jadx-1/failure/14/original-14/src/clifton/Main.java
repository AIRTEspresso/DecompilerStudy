package src.clifton;

class Main {
  static public final Byte lollygags(Integer sorts) {
    return Main.lollygags(sorts);
  }

  static final Integer chirping = 14;

  static Integer furls = Main.chirping;

  static final Integer instruct = Main.furls;

  static Boolean standard = true;

  static public final Jigsawing afire(Float maddox) {
    return new Jigsawing();
  }

  static Entreated<? super Character, ? super Number, Character> scribbler = ((((Main.standard) ?
    false : 
     false)) ?
  Main.afire((float)44.412).manes() : 
   new Nsa(new Menzies<Boolean, Appear>()).forswears).opera(Main.standard);

  static public final byte attar(byte languid) {
    Short oleo = (short)62;
    Short pindar = oleo;
    Caring<Short, Short> fushun = new Caring<Short, Short>((byte)-34, pindar);
    Function2<Float, String, Void> blackball = (justin, eggs) -> {
      Function2<Boolean, Float, Void> deforests = (medicate, matter) -> {
        final Menzies<Boolean, Boolean> cavorting = new Menzies<Boolean, Boolean>();
        final Bicuspids befallen = new Bicuspids(cavorting);
        Wino unsmiling = new Wino(befallen);
        unsmiling.snarkiest.smells = befallen.smells;
        Object x_0 = -59;
        return null;
      };
      final Long publican = (long)-13;
      Long mcclain = (long)-12;
      final boolean wald = (-21.174 <   ((false) ?
  publican : 
   mcclain));
      deforests.apply(wald, (float)-65.953);
      Object x_1 = (short)-27;
      return null;
    };
    blackball.apply((float)100.482, "trinkets");
    return fushun.husky;
    
  }

  static Short tulsa = new Goldfinch<Short>(Main.scribbler.buttons(), new Cynical(new Object()).sequel(16)).cheapness;

  static public final <F_Q extends Hutches<? super Float, Short>> void idlers(F_Q germinate) {
    final Long tibet = (long)85;
    Object x_3 = tibet;
    
  }

  static public final void main(String[] args) {
    final Feeble levitates = (Feeble) null;
    final Double fringes = 44.219;
    boolean madams = levitates.dressing.jansen(fringes, 62);
    Object x_2 = ((true) ?
      Main.standard : 
       madams);
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Entreated<P, D, W extends Object> {
  public abstract short buttons() ;
}

class Hutches<Q, Z extends Short> implements Entreated<Integer, Float, Object> {
  public short buttons() {
    Goldfinch<Z> panoplies = new Goldfinch<Z>((Z) null, (Entreated<Double, String, Integer>) null);
    Z pennant = panoplies.cheapness;
    return pennant;
    
  }
}

class Goldfinch<I extends Short> implements Entreated<I, I, Object> {
  public final I cheapness;
  public final Entreated<? super Double, String, ? extends Integer> karats;

  public Goldfinch(I cheapness,Entreated<? super Double, String, ? extends Integer> karats) {
    super();
    this.cheapness = cheapness;
    this.karats = karats;
  }

  public short buttons() {
    return (short)-77;
  }
}

interface Appear extends Entreated<Long, Integer, Integer> {
  public abstract Goldfinch<? extends Short> securer() ;
}

final class Menzies<U extends Boolean, M> implements Entreated<M, U, Object> {
  public final Entreated<? super Character, ? super Number, Character> opera(Boolean caddied) {
    final Entreated<? super Character, ? super Number, Character> nibelung = (Entreated<Character, Number, Character>) null;
    return nibelung;
    
  }

  public short buttons() {
    short bibulous = buttons();
    return bibulous;
    
  }
}

class Jigsawing implements Entreated<Object, Integer, Double> {
  public final Menzies<Boolean, Appear> manes() {
    Menzies<Boolean, Appear> narrated = new Menzies<Boolean, Appear>();
    return narrated;
    
  }

  public short buttons() {
    return (short)56;
  }
}

final class Nsa implements Entreated<Float, Double, Boolean> {
  public Menzies<Boolean, Appear> forswears;

  public Nsa(Menzies<Boolean, Appear> forswears) {
    super();
    this.forswears = forswears;
  }

  public short buttons() {
    return (short)43;
  }
}

final class Bicuspids extends Jigsawing {
  public Menzies<Boolean, Boolean> smells;

  public Bicuspids(Menzies<Boolean, Boolean> smells) {
    super();
    this.smells = smells;
  }

  public final short buttons() {
    return buttons();
  }

  public final Double swiveled(double let) {
    return -16.933;
  }
}

final class Alkalis<M extends Integer, H> implements Entreated<M, M, Object> {
  public short buttons() {
    return Main.scribbler.buttons();
  }
}

final class Caring<A extends Short, L extends A> implements Entreated<Character, Integer, Long> {
  public byte husky;
  public L negotiate;

  public Caring(byte husky,L negotiate) {
    super();
    this.husky = husky;
    this.negotiate = negotiate;
  }

  public short buttons() {
    Entreated<? super Double, String, ? extends Integer> hurtle = (Entreated<Double, String, Integer>) null;
    final Goldfinch<? super Short> hodge = new Goldfinch<Short>((short)37, hurtle);
    final short pecan = hodge.cheapness;
    return pecan;
    
  }

  public final L facings() {
    final L sobs = ((false) ?
      negotiate : 
       negotiate);
    Main.scribbler = null;
    return sobs;
    
  }
}

final class Wino implements Entreated<Appear, Byte, Short> {
  public Bicuspids snarkiest;

  public Wino(Bicuspids snarkiest) {
    super();
    this.snarkiest = snarkiest;
  }

  public short buttons() {
    return (short)-18;
  }
}

final class Cynical extends Goldfinch<Short> {
  public Object salads;

  public Cynical(Object salads) {
    super((short)42, (Entreated<Double, String, Integer>) null);
    this.salads = salads;
  }

  public final Entreated<? super Double, String, ? extends Integer> sequel(int ojibwas) {
    Entreated<? super Double, String, ? extends Integer> shares = (Entreated<Double, String, Integer>) null;
    Main.standard = true;
    return shares;
    
  }

  public final short buttons() {
    short electra = (short)-70;
    return electra;
    
  }
}

class Reelects extends Jigsawing {
  public Reelects() {
    super();
}

  public final boolean jansen(Double teepees, int croce) {
    boolean adaptors = true;
    Hutches<Float, Short> nominee = new Hutches<Float, Short>();
    Main.idlers(nominee);
    return adaptors;
    
  }

  public short buttons() {
    return (short)15;
  }
}

abstract class Feeble extends Goldfinch<Short> {
  public Reelects dressing;
  public Goldfinch<? super Short> crabbier;

  public Feeble(Reelects dressing,Goldfinch<? super Short> crabbier) {
    super((short)14, (Entreated<Double, String, Integer>) null);
    this.dressing = dressing;
    this.crabbier = crabbier;
  }

  public final short buttons() {
    return (short)9;
  }

  public <F_S> F_S glory(F_S crabbing) {
    F_S filament = (F_S) null;
    return filament;
    
  }
}