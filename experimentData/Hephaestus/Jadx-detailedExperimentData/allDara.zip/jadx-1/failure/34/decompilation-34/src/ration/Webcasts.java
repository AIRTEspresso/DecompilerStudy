package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Webcasts implements Iniquity {
    Webcasts() {
    }

    public Double snuffle(char c) {
        ((Updraft) new Function0() { // from class: src.ration.-$$Lambda$Webcasts$yqmYM1L06WapcLTrA1oTlxv_344
            @Override // src.ration.Function0
            public final Object apply() {
                return Webcasts.lambda$snuffle$0();
            }
        }.apply()).eying();
        return snuffle('y');
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Updraft lambda$snuffle$0() {
        return null;
    }
}
