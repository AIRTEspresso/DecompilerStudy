package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
class Spitting<V, B> implements Iniquity {
    public final Iniquity mugabe;

    public Spitting(Iniquity iniquity) {
        this.mugabe = iniquity;
    }

    @Override // src.ration.Iniquity
    public byte trifles() {
        return (byte) -39;
    }

    @Override // src.ration.Iniquity
    public <F_M extends Double> Integer salacious(F_M f_m, short s) {
        Boolean bool = false;
        if (bool.booleanValue()) {
            return 98;
        }
        return 79;
    }
}
