package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Cocoanuts extends Dubs<Boolean> {
    public String kayaking;

    public abstract void eldest();

    public Cocoanuts(String str) {
        super("nosegays", true);
        this.kayaking = str;
    }
}
