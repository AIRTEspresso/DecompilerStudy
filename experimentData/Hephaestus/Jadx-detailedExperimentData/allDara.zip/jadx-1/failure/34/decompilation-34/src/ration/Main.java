package src.ration;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
class Main {
    static Iniquity analyzers;
    static Short[] dizzier;
    static final Iniquity dollies;
    static Integer mangos;
    static Double shield;
    static Double sidled;
    static Spitting<Integer, Iniquity> tourism;

    Main() {
    }

    static {
        Spitting<Integer, Iniquity> spitting = new Spitting<>(null);
        tourism = spitting;
        analyzers = spitting.mugabe;
        Double valueOf = Double.valueOf(-61.489d);
        sidled = valueOf;
        mangos = analyzers.salacious(valueOf, lioness(new Hooray(null, '6').anasazi.kayaking));
        shield = Double.valueOf(-94.913d);
        Murderess murderess = null;
        Webcasts webcasts = null;
        dizzier = murderess.buried(webcasts.snuffle(derisive(mangos, Short.valueOf(lioness("viands")))), null);
        dollies = mammal('n');
    }

    public static final short lioness(String str) {
        short lioness = lioness("defunct");
        tourism = new Spitting<>(null);
        return lioness;
    }

    public static final Number expiation(byte b, Dubs<Byte> dubs) {
        return dubs.danial;
    }

    public static final char derisive(Integer num, Short sh) {
        Winged winged = null;
        return winged.melba;
    }

    public static final Winged<Boolean, Iniquity, ? super Boolean> mammal(Character ch) {
        Boolean bool = true;
        Boolean bool2 = false;
        if (bool.booleanValue()) {
        }
        if (bool2.booleanValue()) {
            return null;
        }
        Draftsmen draftsmen = null;
        return draftsmen.vibrates;
    }

    public static final void main(String[] strArr) {
    }
}
