package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Murderess extends Spitting<Murderess, Float> {
    public Double blurts;
    public final Iniquity mugabe;

    public abstract Short[] buried(Double d, Float... fArr);

    public Murderess(Iniquity iniquity, Double d) {
        super(new Hooray(null, Double.valueOf(67.518d)));
        this.mugabe = iniquity;
        this.blurts = d;
    }
}
