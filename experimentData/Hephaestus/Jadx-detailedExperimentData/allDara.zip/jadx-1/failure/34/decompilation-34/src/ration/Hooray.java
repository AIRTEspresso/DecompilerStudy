package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
class Hooray<G, S, F> implements Iniquity {
    public Dubs<Boolean> anasazi;
    public S oversells;

    public Hooray(Dubs<Boolean> dubs, S s) {
        this.anasazi = dubs;
        this.oversells = s;
    }

    @Override // src.ration.Iniquity
    public byte trifles() {
        this.oversells = null;
        return (byte) -47;
    }

    @Override // src.ration.Iniquity
    public <F_M extends Double> Integer salacious(F_M f_m, short s) {
        return 88;
    }
}
