package src.ration;

import src.ration.Dubs;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Draftsmen<V extends Dubs<Updraft>> extends Hooray<Object, V, V> {
    public Winged<Boolean, Iniquity, Boolean> vibrates;

    public abstract V tarot(Dubs<? super Hinted> dubs, Integer num);

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public Draftsmen(src.ration.Winged<java.lang.Boolean, src.ration.Iniquity, java.lang.Boolean> r2) {
        /*
            r1 = this;
            r0 = 0
            src.ration.Dubs r0 = (src.ration.Dubs) r0
            r1.<init>(r0, r0)
            r1.vibrates = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: src.ration.Draftsmen.<init>(src.ration.Winged):void");
    }

    @Override // src.ration.Hooray, src.ration.Iniquity
    public final <F_M extends Double> Integer salacious(F_M f_m, short s) {
        Cocoanuts cocoanuts = null;
        cocoanuts.eldest();
        return -17;
    }
}
