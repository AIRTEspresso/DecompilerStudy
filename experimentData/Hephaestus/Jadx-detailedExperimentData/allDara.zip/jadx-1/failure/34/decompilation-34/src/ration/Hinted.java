package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Hinted implements Iniquity {
    public int feigns;
    public double hurley;

    public abstract void wavy(Short sh);

    public Hinted(int i, double d) {
        this.feigns = i;
        this.hurley = d;
    }
}
