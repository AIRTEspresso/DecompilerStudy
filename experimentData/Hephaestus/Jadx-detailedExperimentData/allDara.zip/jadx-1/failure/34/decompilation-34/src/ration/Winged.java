package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Winged<R, A, G extends R> implements Iniquity {
    public final R louvre;
    public final char melba;

    public Winged(char c, R r) {
        this.melba = c;
        this.louvre = r;
    }

    public String socialism(String str) {
        return "stoker";
    }
}
