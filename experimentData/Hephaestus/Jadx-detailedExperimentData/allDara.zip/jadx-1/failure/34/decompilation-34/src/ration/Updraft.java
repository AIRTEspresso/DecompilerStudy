package src.ration;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
public abstract class Updraft implements Iniquity {
    public final Hooray<Number, Integer, ? extends Boolean> venn;

    public Updraft(Hooray<Number, Integer, ? extends Boolean> hooray) {
        this.venn = hooray;
    }

    public void eying() {
    }
}
