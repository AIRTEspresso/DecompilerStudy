package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
interface Win<G> extends Iniquity {
    <F_D extends Updraft> Number edible(F_D f_d);

    <F_I extends G> F_I sitters(F_I f_i, F_I f_i2);
}
