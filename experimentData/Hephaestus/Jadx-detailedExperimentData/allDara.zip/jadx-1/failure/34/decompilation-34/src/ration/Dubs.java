package src.ration;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/34/original-34/Test.dex */
abstract class Dubs<R> implements Iniquity {
    public final R danial;
    public String kayaking;

    public Dubs(String str, R r) {
        this.kayaking = str;
        this.danial = r;
    }

    @Override // src.ration.Iniquity
    public byte trifles() {
        return (byte) -90;
    }

    @Override // src.ration.Iniquity
    public <F_M extends Double> Integer salacious(F_M f_m, short s) {
        Hinted hinted = null;
        hinted.wavy((short) 4);
        return 37;
    }
}
