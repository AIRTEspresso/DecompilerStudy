package src.wezen;

class Main {
  static public final Float drawn(Float cathartic) {
    return Main.drawn(Main.drawn(cathartic));
  }

  static int slap = -48;

  static final int interlock = ((false) ?
  Main.slap : 
   Main.slap);

  static public final Character holdout() {
    final Boolean trouser = true;
    Boolean silvan = trouser;
    Character slangier = ((silvan) ?
      Main.holdout() : 
       Main.holdout());
    Function1<Integer, Void> tinseling = (helplines) -> {
      final Long thyme = (long)-32;
      final Behinds<Long, Double, Double> velcros = new Behinds<Long, Double, Double>(new Fold<Float>(new Modicum<Number, Long, Long>((Number) new Long(81), thyme), (float)-79.830));
      Object bract = new Object();
        ((false) ?
  new Posher<Float>(new Behinds<Long, Double, Double>(new Fold<Float>(new Modicum<Number, Long, Long>((Number) new Long(78), (long)36), (float)-41.366)), (float)-93.450) : 
   new Posher<Float>(new Behinds<Long, Double, Double>(new Fold<Float>(new Modicum<Number, Long, Long>((Number) new Long(4), (long)-50), (float)93.156)), (float)-28.358)).fireside = velcros;
      new Posher<Object>(velcros, bract).fireside.setting.uighur.coined(-94.498);
      return null;
    };
    tinseling.apply(Main.slap);
    return slangier;
    
  }

  static public final Byte bruiser(Integer oblations, Long letter) {
    final Byte worse = (byte)42;
    return worse;
    
  }

  static final Integer mellon = Main.interlock;

  static final Float lenders = (float)71.742;

  static final Byte empirical = Main.bruiser(Main.mellon, new Jaunt<Float>(Main.lenders).forearmed());

  static public final void overdress(Peccaries<? super Byte> tumults, Character augusts) {
    final Integer smoothest = 93;
    Function0<Void> swapped = () -> {
      final Limbering kernels = (Limbering) null;
      Limbering slicking = kernels;
      slicking.haversack(null, 100.673);
      Object x_1 = -56;
      return null;
    };
    swapped.apply();
    Object x_2 = smoothest;
    
  }

  static public final void leveling(Float ids, String preppiest) {
    Resultant donnie = new Resultant();
    Resultant pei = donnie;
    boolean enhancing = pei.wen();
    new Midwifes<Short, Limbering, Boolean>((long)-58).flashers();
    Object x_3 = enhancing;
    
  }

  static public final void evilly(Lasagna<? super Short, Short> artists, byte rosa) {
    final Long kodaly = (long)73;
    Object x_6 = kodaly;
    
  }

  static public final Behinds<? extends Float, Long, ? super Integer> tackier() {
    return ((Banditry<Peccaries<Character>, Boolean, Byte>) null).unseats;
  }

  static public final void main(String[] args) {
    Main.tackier();
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Abyss<H extends Byte, Z extends Double, O> {
  public abstract <F_E> F_E pliny(Boolean flared, Abyss<? super H, ? extends Z, O> matriarch) ;
}

abstract class Lasagna<Q extends Short, Z extends Q> implements Abyss<Byte, Double, Q> {
  public Q palpably;

  public Lasagna(Q palpably) {
    super();
    this.palpably = palpably;
  }

  public <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Q> matriarch) {
    final Boolean fouled = true;
    final F_E geffen = (F_E) null;
    F_E clocking = geffen;
    Function1<Z, Void> nation = (putty) -> {
      Object x_0 = (Abyss<Byte, Double, Long>) null;
      return null;
    };
    nation.apply((Z) null);
    return new Modicum<F_E, F_E, Long>(matriarch.pliny(fouled, null),   ((true) ?
  geffen : 
   clocking)).excessive;
    
  }

  public abstract Double echelon() ;
}

class Modicum<N, Y, M extends Long> implements Abyss<Byte, Double, Short> {
  public final N excessive;
  public final Y scattered;

  public Modicum(N excessive,Y scattered) {
    super();
    this.excessive = excessive;
    this.scattered = scattered;
  }

  public <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Short> matriarch) {
    final F_E commended = (F_E) null;
    return commended;
    
  }

  public Double coined(Double deputize) {
    return 67.880;
  }
}

class Fold<O> implements Abyss<Byte, Double, Boolean> {
  public Modicum<Number, Long, ? extends Long> uighur;
  public final O shackling;

  public Fold(Modicum<Number, Long, ? extends Long> uighur,O shackling) {
    super();
    this.uighur = uighur;
    this.shackling = shackling;
  }

  public <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Boolean> matriarch) {
    final F_E scooted = (F_E) null;
    return scooted;
    
  }

  public final O chintzier() {
    return (O) null;
  }
}

class Behinds<I, E, Q> extends Lasagna<Short, Short> {
  public final Fold<Float> setting;

  public Behinds(Fold<Float> setting) {
    super((short)-12);
    this.setting = setting;
  }

  public Double echelon() {
    Double squealer = 26.845;
    return squealer;
    
  }

  public final <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Short> matriarch) {
    return (F_E) null;
  }
}

class Posher<J extends Object> extends Fold<Short> {
  public Behinds<Long, Double, Double> fireside;
  public final J nkrumah;

  public Posher(Behinds<Long, Double, Double> fireside,J nkrumah) {
    super(new Modicum<Number, Long, Long>((Number) new Long(-91), (long)37), (short)-59);
    this.fireside = fireside;
    this.nkrumah = nkrumah;
  }

  public <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Boolean> matriarch) {
    final F_E pickerels = (F_E) null;
    F_E maelstrom = pickerels;
    F_E holograms = (F_E) null;
    maelstrom = holograms;
    return maelstrom;
    
  }

  public final J frye(J accounts) {
    final J lunge = (J) null;
    return lunge;
    
  }
}

final class Jaunt<P extends Float> implements Abyss<Byte, Double, Byte> {
  public P casework;

  public Jaunt(P casework) {
    super();
    this.casework = casework;
  }

  public final Long forearmed() {
    return (long)48;
  }

  public <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Byte> matriarch) {
    final F_E wince = (F_E) null;
    final F_E rudolf = (F_E) null;
    return ((true) ?
      wince : 
       rudolf);
    
  }
}

final class Quitter extends Lasagna<Short, Short> {
  public Short palpably;
  public final byte hosed;

  public Quitter(Short palpably,byte hosed) {
    super((short)-51);
    this.palpably = palpably;
    this.hosed = hosed;
  }

  public Double echelon() {
    Double noriega = 76.144;
    return noriega;
    
  }

  public final <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Short> matriarch) {
    final Peccaries<F_E> verse = new Peccaries<F_E>((F_E) null);
    F_E randy = verse.updike();
    Float program = Main.lenders;
    Main.leveling(program, "encamped");
    return randy;
    
  }
}

final class Peccaries<J> extends Posher<Object> {
  public final J gipsies;

  public Peccaries(J gipsies) {
    super(new Behinds<Long, Double, Double>(new Fold<Float>(new Modicum<Number, Long, Long>((Number) new Long(-6), (long)-16), (float)-50.603)), new Object());
    this.gipsies = gipsies;
  }

  public final J updike() {
    Function1<Long, J> whetstone = (jests) -> {
      J coax = (J) null;
      return coax;
      
    };
    final Long creepily = (long)37;
    Main.overdress(null,  'N');
    return whetstone.apply(creepily);
    
  }
}

interface Limbering extends Abyss<Byte, Double, Character> {
  public abstract void haversack(Lasagna<? super Short, Short> recedes, Double gaborone) ;

  public abstract Double impress(Double inserts, Quitter uproot) ;
}

class Resultant extends Modicum<Short, Integer, Long> {
  public Resultant() {
    super((short)-62, 31);
}

  public final boolean wen() {
    boolean journeyed = true;
    return journeyed;
    
  }
}

final class Midwifes<F, E, D> implements Limbering {
  public Long riling;

  public Midwifes(Long riling) {
    super();
    this.riling = riling;
  }

  public final void flashers() {
    final D airmen = (D) null;
    Main.evilly(null, (byte)-67);
    Object x_4 = airmen;
    
  }

  public Double impress(Double inserts, Quitter uproot) {
    return -19.726;
  }

  public <F_E> F_E pliny(Boolean flared, Abyss<? super Byte, ? extends Double, Character> matriarch) {
    F_E preamble = (F_E) null;
    return preamble;
    
  }

  public void haversack(Lasagna<? super Short, Short> recedes, Double gaborone) {
    final char inbreed = 'c';
    Object x_5 = inbreed;
    
  }
}

abstract class Banditry<V extends Peccaries<? extends Character>, U, Y extends Byte> extends Resultant {
  public final Behinds<? extends Float, Long, ? super Integer> unseats;

  public Banditry(Behinds<? extends Float, Long, ? super Integer> unseats) {
    super();
    this.unseats = unseats;
  }

  public abstract Y guessers(Abyss<? extends Byte, ? super Double, ? extends Byte> herero) ;

  public Y mallards() {
    final Y metabolic = (Y) null;
    return metabolic;
    
  }
}