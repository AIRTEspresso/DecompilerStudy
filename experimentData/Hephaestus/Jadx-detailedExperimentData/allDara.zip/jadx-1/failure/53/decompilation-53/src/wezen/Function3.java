package src.wezen;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
interface Function3<A1, A2, A3, R> {
    R apply(A1 a1, A2 a2, A3 a3);
}
