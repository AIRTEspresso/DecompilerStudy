package src.wezen;

import java.lang.Byte;
import java.lang.Double;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public interface Abyss<H extends Byte, Z extends Double, O> {
    <F_E> F_E pliny(Boolean bool, Abyss<? super H, ? extends Z, O> abyss);
}
