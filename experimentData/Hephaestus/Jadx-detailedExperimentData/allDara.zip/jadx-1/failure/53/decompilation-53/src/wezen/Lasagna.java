package src.wezen;

import java.lang.Short;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public abstract class Lasagna<Q extends Short, Z extends Q> implements Abyss<Byte, Double, Q> {
    public Q palpably;

    public abstract Double echelon();

    public Lasagna(Q q) {
        this.palpably = q;
    }

    @Override // src.wezen.Abyss
    public <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Q> abyss) {
        new Function1() { // from class: src.wezen.-$$Lambda$Lasagna$sW_nfcxbvriWx8fP-vdUyf2PcPA
            @Override // src.wezen.Function1
            public final Object apply(Object obj) {
                return Lasagna.lambda$pliny$0((Short) obj);
            }
        }.apply(null);
        return (F_E) new Modicum(abyss.pliny(true, null), null).excessive;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$pliny$0(Short sh) {
        return null;
    }
}
