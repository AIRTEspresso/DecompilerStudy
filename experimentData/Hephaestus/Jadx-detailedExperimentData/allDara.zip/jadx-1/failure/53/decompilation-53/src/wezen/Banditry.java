package src.wezen;

import java.lang.Byte;
import src.wezen.Peccaries;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
abstract class Banditry<V extends Peccaries<? extends Character>, U, Y extends Byte> extends Resultant {
    public final Behinds<? extends Float, Long, ? super Integer> unseats;

    public abstract Y guessers(Abyss<? extends Byte, ? super Double, ? extends Byte> abyss);

    public Banditry(Behinds<? extends Float, Long, ? super Integer> behinds) {
        this.unseats = behinds;
    }

    public Y mallards() {
        return null;
    }
}
