package src.wezen;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public class Behinds<I, E, Q> extends Lasagna<Short, Short> {
    public final Fold<Float> setting;

    public Behinds(Fold<Float> fold) {
        super((short) -12);
        this.setting = fold;
    }

    @Override // src.wezen.Lasagna
    public Double echelon() {
        return Double.valueOf(26.845d);
    }

    @Override // src.wezen.Lasagna, src.wezen.Abyss
    public final <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Short> abyss) {
        return null;
    }
}
