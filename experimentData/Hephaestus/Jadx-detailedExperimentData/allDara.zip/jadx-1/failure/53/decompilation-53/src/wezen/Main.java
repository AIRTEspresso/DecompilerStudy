package src.wezen;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public class Main {
    static int slap = -48;
    static final int interlock = -48;
    static final Integer mellon = -48;
    static final Float lenders = Float.valueOf(71.742f);
    static final Byte empirical = bruiser(mellon, new Jaunt(lenders).forearmed());

    Main() {
    }

    public static final Float drawn(Float f) {
        return drawn(drawn(f));
    }

    public static final Character holdout() {
        Character holdout;
        Boolean bool = true;
        if (bool.booleanValue()) {
            holdout = holdout();
        } else {
            holdout = holdout();
        }
        new Function1() { // from class: src.wezen.-$$Lambda$Main$G3kkjR79QZjgjRsKeMWX9LWBj4g
            @Override // src.wezen.Function1
            public final Object apply(Object obj) {
                return Main.lambda$holdout$0((Integer) obj);
            }
        }.apply(Integer.valueOf(slap));
        return holdout;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$holdout$0(Integer num) {
        Behinds<Long, Double, Double> behinds = new Behinds<>(new Fold(new Modicum(new Long(81L), -32L), Float.valueOf(-79.83f)));
        Object obj = new Object();
        new Posher(new Behinds(new Fold(new Modicum(new Long(4L), -50L), Float.valueOf(93.156f))), Float.valueOf(-28.358f)).fireside = behinds;
        new Posher(behinds, obj).fireside.setting.uighur.coined(Double.valueOf(-94.498d));
        return null;
    }

    public static final Byte bruiser(Integer num, Long l) {
        return (byte) 42;
    }

    public static final void overdress(Peccaries<? super Byte> peccaries, Character ch) {
        Integer.valueOf(93);
        new Function0() { // from class: src.wezen.-$$Lambda$Main$ZlutyjYLo5qIj8DoAC4zSgO1ejw
            @Override // src.wezen.Function0
            public final Object apply() {
                return Main.lambda$overdress$1();
            }
        }.apply();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$overdress$1() {
        Limbering limbering = null;
        limbering.haversack(null, Double.valueOf(100.673d));
        Integer.valueOf(-56);
        return null;
    }

    public static final void leveling(Float f, String str) {
        boolean wen = new Resultant().wen();
        new Midwifes(-58L).flashers();
        Boolean.valueOf(wen);
    }

    public static final void evilly(Lasagna<? super Short, Short> lasagna, byte b) {
        Long.valueOf(73L);
    }

    public static final Behinds<? extends Float, Long, ? super Integer> tackier() {
        Banditry banditry = null;
        return banditry.unseats;
    }

    public static final void main(String[] strArr) {
        tackier();
    }
}
