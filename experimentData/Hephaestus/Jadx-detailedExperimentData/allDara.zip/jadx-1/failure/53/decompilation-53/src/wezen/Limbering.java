package src.wezen;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public interface Limbering extends Abyss<Byte, Double, Character> {
    void haversack(Lasagna<? super Short, Short> lasagna, Double d);

    Double impress(Double d, Quitter quitter);
}
