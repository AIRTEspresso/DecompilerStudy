package src.wezen;

import java.lang.Float;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
final class Jaunt<P extends Float> implements Abyss<Byte, Double, Byte> {
    public P casework;

    public Jaunt(P p) {
        this.casework = p;
    }

    public final Long forearmed() {
        return 48L;
    }

    @Override // src.wezen.Abyss
    public <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Byte> abyss) {
        return null;
    }
}
