package src.wezen;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
final class Midwifes<F, E, D> implements Limbering {
    public Long riling;

    public Midwifes(Long l) {
        this.riling = l;
    }

    public final void flashers() {
        Main.evilly(null, (byte) -67);
    }

    @Override // src.wezen.Limbering
    public Double impress(Double d, Quitter quitter) {
        return Double.valueOf(-19.726d);
    }

    @Override // src.wezen.Abyss
    public <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Character> abyss) {
        return null;
    }

    @Override // src.wezen.Limbering
    public void haversack(Lasagna<? super Short, Short> lasagna, Double d) {
        Character.valueOf('c');
    }
}
