package src.wezen;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public class Posher<J> extends Fold<Short> {
    public Behinds<Long, Double, Double> fireside;
    public final J nkrumah;

    public Posher(Behinds<Long, Double, Double> behinds, J j) {
        super(new Modicum(new Long(-91L), 37L), (short) -59);
        this.fireside = behinds;
        this.nkrumah = j;
    }

    @Override // src.wezen.Fold, src.wezen.Abyss
    public <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Boolean> abyss) {
        return null;
    }

    public final J frye(J j) {
        return null;
    }
}
