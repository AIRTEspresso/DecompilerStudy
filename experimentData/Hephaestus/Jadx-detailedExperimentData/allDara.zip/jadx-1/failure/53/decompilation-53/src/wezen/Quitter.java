package src.wezen;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
final class Quitter extends Lasagna<Short, Short> {
    public final byte hosed;
    public Short palpably;

    public Quitter(Short sh, byte b) {
        super((short) -51);
        this.palpably = sh;
        this.hosed = b;
    }

    @Override // src.wezen.Lasagna
    public Double echelon() {
        return Double.valueOf(76.144d);
    }

    @Override // src.wezen.Lasagna, src.wezen.Abyss
    public final <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Short> abyss) {
        F_E f_e = (F_E) new Peccaries(null).updike();
        Main.leveling(Main.lenders, "encamped");
        return f_e;
    }
}
