package src.wezen;

import java.lang.Long;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public class Modicum<N, Y, M extends Long> implements Abyss<Byte, Double, Short> {
    public final N excessive;
    public final Y scattered;

    public Modicum(N n, Y y) {
        this.excessive = n;
        this.scattered = y;
    }

    @Override // src.wezen.Abyss
    public <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Short> abyss) {
        return null;
    }

    public Double coined(Double d) {
        return Double.valueOf(67.88d);
    }
}
