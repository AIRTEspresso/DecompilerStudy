package src.wezen;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
final class Peccaries<J> extends Posher<Object> {
    public final J gipsies;

    public Peccaries(J j) {
        super(new Behinds(new Fold(new Modicum(new Long(-6L), -16L), Float.valueOf(-50.603f))), new Object());
        this.gipsies = j;
    }

    public final J updike() {
        $$Lambda$Peccaries$CXB_kWue7SF24DAyvCVjtJd8cH8 __lambda_peccaries_cxb_kwue7sf24dayvcvjtjd8ch8 = new Function1() { // from class: src.wezen.-$$Lambda$Peccaries$CXB_kWue7SF24DAyvCVjtJd8cH8
            @Override // src.wezen.Function1
            public final Object apply(Object obj) {
                return Peccaries.lambda$updike$0((Long) obj);
            }
        };
        Main.overdress(null, 'N');
        return (J) __lambda_peccaries_cxb_kwue7sf24dayvcvjtjd8ch8.apply(37L);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Object lambda$updike$0(Long l) {
        return null;
    }
}
