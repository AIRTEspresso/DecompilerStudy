package src.wezen;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
class Resultant extends Modicum<Short, Integer, Long> {
    public Resultant() {
        super((short) -62, 31);
    }

    public final boolean wen() {
        return true;
    }
}
