package src.wezen;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/53/original-53/Test.dex */
public class Fold<O> implements Abyss<Byte, Double, Boolean> {
    public final O shackling;
    public Modicum<Number, Long, ? extends Long> uighur;

    public Fold(Modicum<Number, Long, ? extends Long> modicum, O o) {
        this.uighur = modicum;
        this.shackling = o;
    }

    @Override // src.wezen.Abyss
    public <F_E> F_E pliny(Boolean bool, Abyss<? super Byte, ? extends Double, Boolean> abyss) {
        return null;
    }

    public final O chintzier() {
        return null;
    }
}
