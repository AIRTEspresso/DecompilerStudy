package src.tutorial;

class Main {
  static public final void cornball(String keratin, String simulcast) {
    final byte scurf = (byte)37;
    Main.unlimited(35.98, scurf);
    
  }

  static public final void unlimited(Double reappear, byte debs) {
    Boolean bern = true;
    Object x_0 = bern;
    
  }

  static public final void goalies() {
    final Boolean argentine = false;
    final Snottiest<Double, Boolean, Double> durable = ((argentine) ?
      (Snottiest<Double, Boolean, Double>) null : 
       (Snottiest<Double, Boolean, Double>) null);
    final Friskiest sheer = durable.scooted;
    sheer.hunker(new Orienting<Byte, Byte>(-53).oculists);
    
  }

  static public final void lorraine(Maxim<String, String, ? super Long> drudgery, int divorce) {
    final Short shunts = (short)4;
    ((Whams<String, String>) null).workshops = null;
    Object x_1 = shunts;
    
  }

  static Snottiest<Boolean, Integer, Boolean> lifelong = (Snottiest<Boolean, Integer, Boolean>) null;

  static Byte workable = (byte)-84;

  static Byte yanking = ((false) ?
  Main.workable : 
   (byte)38);

  static public final Integer vase(Defunct<? extends Byte, ? extends Byte, ? super Long> agonize) {
    Integer impolitic = -29;
    final Integer forlornly = -34;
    Friskiest dyeing = (Friskiest) null;
    new Flamings(forlornly, (Friskiest[]) new Object[]{dyeing}).dicks();
    return impolitic;
    
  }

  static final Character spiffier = new Defunct<Byte, Byte, Byte>(Main.lifelong, Main.yanking).whining.nudes(new Orienting<Friskiest, Chortled>(Main.vase(null)).hospices);

  static public final Double snarled(Spillway<Integer, ? super Long> roseau) {
    final Double tracheae = 48.943;
    Double demented = tracheae;
    return ((true) ?
      Main.snarled(null) : 
       demented);
    
  }

  static public final Maxim<? super String, String, ? super Long> crushes(Double[] troikas, Maxim<? super String, String, ? super Long> marcher) {
    final Short macron = (short)5;
    final Boolean aureoles = true;
    final String bunts = "labials";
    return ((true) ?
      new Maxim<String, String, Long>("mothballs", macron) : 
       ((aureoles) ?
        new Maxim<String, String, Long>(bunts, (short)74) : 
         new Maxim<String, String, Long>("afro", (short)-99)));
    
  }

  static Double imposture = Main.lifelong.flails;

  static public final void main(String[] args) {
    final Character bond = Main.spiffier;
    Object x_4 = bond;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



class Enif {
  public Character nudes(String soreness) {
    final Character goddesses = 's';
    return goddesses;
    
  }

  public Enif calmer() {
    Kerr murderess = (Kerr) null;
    return murderess.klutzier;
    
  }
}

abstract class Kerr {
  public final Enif klutzier;
  public final Short innovate;

  public Kerr(Enif klutzier,Short innovate) {
    this.klutzier = klutzier;
    this.innovate = innovate;
  }

  public Double flies(long garbed, short livable) {
    return 53.625;
  }
}

abstract class Verticals<I, O, C> extends Kerr {
  public final Enif klutzier;
  public final Short innovate;

  public Verticals(Enif klutzier,Short innovate) {
    super(new Enif(), (short)11);
    this.klutzier = klutzier;
    this.innovate = innovate;
  }

  public final Double flies(long garbed, short livable) {
    final Spillway<Integer, Short> sneeze = (Spillway<Integer, Short>) null;
    Double besetting = sneeze.flails;
    final Double stroller = besetting;
    return stroller;
    
  }
}

abstract class Spillway<S extends Integer, O> extends Enif {
  public Double flails;

  public Spillway(Double flails) {
    super();
    this.flails = flails;
  }

  public Enif calmer() {
    Enif zambian = new Enif();
    zambian = zambian;
    return zambian;
    
  }

  public Character nudes(String soreness) {
     return '3';
  }
}

final class Whams<O extends String, F extends O> extends Verticals<Integer, Short, Float> {
  public final Short innovate;
  public F workshops;

  public Whams(Short innovate,F workshops) {
    super(new Enif(), (short)30);
    this.innovate = innovate;
    this.workshops = workshops;
  }

  public final Spillway<Integer, ? extends Float> aesthete(F snuffle) {
    final Boolean legends = true;
    final Coccis<F, Long, O> tenuously = (Coccis<F, Long, O>) null;
    final Coccis<F, Long, O> moll = (Coccis<F, Long, O>) null;
    return aesthete(  ((legends) ?
  tenuously : 
   moll).hospices);
    
  }

  public final O features(O students, O kookie) {
    Function0<O> freewill = () -> {
      final Expelling<F, O, F> braining = (Expelling<F, O, F>) null;
      final Maxim<O, O, ? super Long> oblate = braining.scarabs;
      final O mordred = oblate.woofing;
      Main.cornball(((Chortled) null).megacycle.ats( 'a').features("bullhorn", "nassau"), "yaobang");
      return mordred;
      
    };
    Main.goalies();
    return freewill.apply();
    
  }
}

abstract class Coccis<O extends String, A extends Long, X> extends Verticals<X, A, A> {
  public final O hospices;
  public final Short innovate;

  public Coccis(O hospices,Short innovate) {
    super(new Enif(), (short)24);
    this.hospices = hospices;
    this.innovate = innovate;
  }

  public X repealing() {
    final X clouds = (X) null;
    final Ara<Character, Long> defecate = (Ara<Character, Long>) null;
    defecate.recycle( 't');
    return clouds;
    
  }
}

interface Ara<A, U> {
  public abstract void recycle(A scottie) ;
}

class Maxim<W extends String, E extends W, P extends Long> extends Verticals<Boolean, Enif, Boolean> {
  public final W woofing;
  public final Short innovate;

  public Maxim(W woofing,Short innovate) {
    super(new Enif(), (short)21);
    this.woofing = woofing;
    this.innovate = innovate;
  }
}

abstract class Expelling<Q, E extends String, T extends Q> extends Enif {
  public Maxim<E, E, ? super Long> scarabs;

  public Expelling(Maxim<E, E, ? super Long> scarabs) {
    super();
    this.scarabs = scarabs;
  }

  public Enif calmer() {
    return new Enif();
  }

  public Kerr beachhead(Kerr gelbvieh) {
    Kerr drywall = scarabs;
    return drywall;
    
  }
}

class Adoptive extends Spillway<Integer, Boolean> {
  public Double flails;
  public float obstructs;

  public Adoptive(Double flails,float obstructs) {
    super(88.871);
    this.flails = flails;
    this.obstructs = obstructs;
  }

  public Whams<String, ? extends String> ats(char friskily) {
    final Whams<String, ? extends String> yowled = (Whams<String, String>) null;
    return yowled;
    
  }
}

abstract class Chortled extends Kerr {
  public Adoptive megacycle;
  public final Short innovate;

  public Chortled(Adoptive megacycle,Short innovate) {
    super(new Enif(), (short)-27);
    this.megacycle = megacycle;
    this.innovate = innovate;
  }

  public Double flies(long garbed, short livable) {
    return -90.745;
  }

  public <F_V> boolean shock(F_V britain, boolean surplused) {
    final boolean overrules = true;
    return overrules;
    
  }
}

final class Friskiest extends Kerr {
  public Friskiest() {
    super(new Enif(), (short)68);
}

  public final <F_R extends Integer> Float hunker(F_R hussite) {
    final Float sakai = (float)89.99;
    final Chortled lemming = (Chortled) null;
    Adoptive viewed = new Adoptive(-66.85, (float)99.413);
    lemming.megacycle = viewed;
    return sakai;
    
  }

  public final Double flies(long garbed, short livable) {
    return 31.639;
  }
}

abstract class Snottiest<V, B, H extends V> extends Spillway<Integer, B> {
  public Friskiest scooted;
  public Double flails;

  public Snottiest(Friskiest scooted,Double flails) {
    super(63.723);
    this.scooted = scooted;
    this.flails = flails;
  }

  public Enif calmer() {
    final Spillway<Integer, Long> troika = (Spillway<Integer, Long>) null;
    final Spillway<Integer, Long> minnesota = troika;
    Main.lorraine(null, 62);
    return minnesota;
    
  }

  public abstract Whams<String, ? super String> pinochle(boolean staple, V pathogens) ;
}

class Orienting<B, Y> extends Coccis<String, Long, B> {
  public Integer oculists;

  public Orienting(Integer oculists) {
    super("suffusing", (short)-88);
    this.oculists = oculists;
  }

  public final B repealing() {
    B encoring = (B) null;
    return encoring;
    
  }

  public final Y rocco(Object scattered, Y sundering) {
    return (Y) null;
  }
}

class Defunct<U extends Byte, M extends U, K> extends Adoptive {
  public Snottiest<Boolean, Integer, Boolean> whining;
  public M vesuvius;

  public Defunct(Snottiest<Boolean, Integer, Boolean> whining,M vesuvius) {
    super(79.989, (float)-32.179);
    this.whining = whining;
    this.vesuvius = vesuvius;
  }
}

final class Flamings extends Orienting<Enif, Long> {
  public Integer oculists;
  public Friskiest[] lyricists;

  public Flamings(Integer oculists,Friskiest[] lyricists) {
    super(-44);
    this.oculists = oculists;
    this.lyricists = lyricists;
  }

  public final void dicks() {
    final Ara<? extends Byte, ? super Boolean> maydays = (Ara<Byte, Boolean>) null;
    final Ara<? extends Byte, ? super Boolean> micheal = maydays;
    Double racers = 20.652;
    new Colanders(racers).billets(null, -96.697);
    Object x_2 = micheal;
    
  }

  public final Whams<String, ? super String> leftovers(Snottiest<? super Float, Character, Float> argus, Whams<String, ? super String> axed) {
    Short felipe = (short)-65;
    String fingertip = "cassette";
    lyricists = null;
    return new Whams<String, String>(felipe, fingertip);
    
  }
}

final class Colanders extends Spillway<Integer, String> {
  public Double flails;

  public Colanders(Double flails) {
    super(-49.267);
    this.flails = flails;
  }

  public final void billets(Expelling<Float, ? extends String, Float> chartres, double ascribed) {
    Object x_3 = (Snottiest<Friskiest, Double, Friskiest>) null;
    
  }
}