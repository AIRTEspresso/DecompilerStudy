package src.tutorial;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
class Enif {
    public Character nudes(String str) {
        return 's';
    }

    public Enif calmer() {
        Kerr kerr = null;
        return kerr.klutzier;
    }
}
