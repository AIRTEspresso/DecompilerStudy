package src.tutorial;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
interface Ara<A, U> {
    void recycle(A a);
}
