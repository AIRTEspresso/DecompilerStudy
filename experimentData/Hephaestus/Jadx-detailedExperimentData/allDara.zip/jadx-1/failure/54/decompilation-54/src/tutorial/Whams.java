package src.tutorial;

import java.lang.String;
/* JADX INFO: Access modifiers changed from: package-private */
/* JADX WARN: Incorrect field signature: TF; */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public final class Whams<O extends String, F extends O> extends Verticals<Integer, Short, Float> {
    public final Short innovate;
    public String workshops;

    /* JADX WARN: Incorrect types in method signature: (Ljava/lang/Short;TF;)V */
    public Whams(Short sh, String str) {
        super(new Enif(), (short) 30);
        this.innovate = sh;
        this.workshops = str;
    }

    /* JADX WARN: Incorrect types in method signature: (TF;)Lsrc/tutorial/Spillway<Ljava/lang/Integer;+Ljava/lang/Float;>; */
    public final Spillway aesthete(String str) {
        Boolean bool = true;
        Coccis coccis = null;
        if (bool.booleanValue()) {
        }
        return aesthete(coccis.hospices);
    }

    public final O features(O o, O o2) {
        $$Lambda$Whams$zj8KuJDHA8llFuvvmznlGKjLLPk __lambda_whams_zj8kujdha8llfuvvmznlgkjllpk = new Function0() { // from class: src.tutorial.-$$Lambda$Whams$zj8KuJDHA8llFuvvmznlGKjLLPk
            @Override // src.tutorial.Function0
            public final Object apply() {
                return Whams.lambda$features$0();
            }
        };
        Main.goalies();
        return (O) __lambda_whams_zj8kujdha8llfuvvmznlgkjllpk.apply();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ String lambda$features$0() {
        Chortled chortled = null;
        Expelling expelling = (Expelling) chortled;
        W w = expelling.scarabs.woofing;
        Chortled chortled2 = chortled;
        Main.cornball(chortled2.megacycle.ats('a').features("bullhorn", "nassau"), "yaobang");
        return w;
    }
}
