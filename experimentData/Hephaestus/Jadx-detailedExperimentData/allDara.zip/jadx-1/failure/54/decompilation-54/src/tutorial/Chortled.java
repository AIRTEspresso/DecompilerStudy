package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public abstract class Chortled extends Kerr {
    public final Short innovate;
    public Adoptive megacycle;

    public Chortled(Adoptive adoptive, Short sh) {
        super(new Enif(), (short) -27);
        this.megacycle = adoptive;
        this.innovate = sh;
    }

    @Override // src.tutorial.Kerr
    public Double flies(long j, short s) {
        return Double.valueOf(-90.745d);
    }

    public <F_V> boolean shock(F_V f_v, boolean z) {
        return true;
    }
}
