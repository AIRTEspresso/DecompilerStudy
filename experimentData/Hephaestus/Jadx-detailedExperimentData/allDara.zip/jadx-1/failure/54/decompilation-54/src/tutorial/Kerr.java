package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public abstract class Kerr {
    public final Short innovate;
    public final Enif klutzier;

    public Kerr(Enif enif, Short sh) {
        this.klutzier = enif;
        this.innovate = sh;
    }

    public Double flies(long j, short s) {
        return Double.valueOf(53.625d);
    }
}
