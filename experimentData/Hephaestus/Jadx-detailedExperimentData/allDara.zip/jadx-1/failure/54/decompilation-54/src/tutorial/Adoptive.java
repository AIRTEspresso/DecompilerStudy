package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public class Adoptive extends Spillway<Integer, Boolean> {
    public Double flails;
    public float obstructs;

    public Adoptive(Double d, float f) {
        super(Double.valueOf(88.871d));
        this.flails = d;
        this.obstructs = f;
    }

    public Whams<String, ? extends String> ats(char c) {
        return null;
    }
}
