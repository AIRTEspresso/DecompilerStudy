package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public final class Friskiest extends Kerr {
    public Friskiest() {
        super(new Enif(), (short) 68);
    }

    public final <F_R extends Integer> Float hunker(F_R f_r) {
        Float valueOf = Float.valueOf(89.99f);
        Chortled chortled = null;
        chortled.megacycle = new Adoptive(Double.valueOf(-66.85d), 99.413f);
        return valueOf;
    }

    @Override // src.tutorial.Kerr
    public final Double flies(long j, short s) {
        return Double.valueOf(31.639d);
    }
}
