package src.tutorial;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
abstract class Verticals<I, O, C> extends Kerr {
    public final Short innovate;
    public final Enif klutzier;

    public Verticals(Enif enif, Short sh) {
        super(new Enif(), (short) 11);
        this.klutzier = enif;
        this.innovate = sh;
    }

    @Override // src.tutorial.Kerr
    public final Double flies(long j, short s) {
        Spillway spillway = null;
        return spillway.flails;
    }
}
