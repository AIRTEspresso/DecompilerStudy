package src.tutorial;

import java.lang.Long;
import java.lang.String;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public class Maxim<W extends String, E extends W, P extends Long> extends Verticals<Boolean, Enif, Boolean> {
    public final Short innovate;
    public final W woofing;

    public Maxim(W w, Short sh) {
        super(new Enif(), (short) 21);
        this.woofing = w;
        this.innovate = sh;
    }
}
