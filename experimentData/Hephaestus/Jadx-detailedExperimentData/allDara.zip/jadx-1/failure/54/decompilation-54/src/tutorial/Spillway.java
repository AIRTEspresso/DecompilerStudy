package src.tutorial;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
abstract class Spillway<S extends Integer, O> extends Enif {
    public Double flails;

    public Spillway(Double d) {
        this.flails = d;
    }

    @Override // src.tutorial.Enif
    public Enif calmer() {
        return new Enif();
    }

    @Override // src.tutorial.Enif
    public Character nudes(String str) {
        return '3';
    }
}
