package src.tutorial;

import java.lang.Long;
import java.lang.String;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
abstract class Coccis<O extends String, A extends Long, X> extends Verticals<X, A, A> {
    public final O hospices;
    public final Short innovate;

    public Coccis(O o, Short sh) {
        super(new Enif(), (short) 24);
        this.hospices = o;
        this.innovate = sh;
    }

    public X repealing() {
        Ara ara = null;
        ara.recycle('t');
        return null;
    }
}
