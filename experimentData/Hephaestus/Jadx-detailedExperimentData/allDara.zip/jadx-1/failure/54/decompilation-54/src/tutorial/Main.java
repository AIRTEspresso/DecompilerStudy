package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public class Main {
    static Snottiest<Boolean, Integer, Boolean> lifelong = null;
    static Byte workable = (byte) -84;
    static Byte yanking = (byte) 38;
    static final Character spiffier = new Defunct(lifelong, yanking).whining.nudes(new Orienting(vase(null)).hospices);
    static Double imposture = lifelong.flails;

    Main() {
    }

    public static final void cornball(String str, String str2) {
        unlimited(Double.valueOf(35.98d), (byte) 37);
    }

    public static final void unlimited(Double d, byte b) {
        Boolean.valueOf(true);
    }

    public static final void goalies() {
        Snottiest snottiest;
        Boolean bool = false;
        if (bool.booleanValue()) {
            snottiest = null;
        } else {
            snottiest = null;
        }
        snottiest.scooted.hunker(new Orienting(-53).oculists);
    }

    public static final void lorraine(Maxim<String, String, ? super Long> maxim, int i) {
        Short.valueOf((short) 4);
        Whams whams = null;
        whams.workshops = null;
    }

    public static final Integer vase(Defunct<? extends Byte, ? extends Byte, ? super Long> defunct) {
        new Flamings(-34, (Friskiest[]) new Object[]{null}).dicks();
        return -29;
    }

    public static final Double snarled(Spillway<Integer, ? super Long> spillway) {
        Double.valueOf(48.943d);
        return snarled(null);
    }

    public static final Maxim<? super String, String, ? super Long> crushes(Double[] dArr, Maxim<? super String, String, ? super Long> maxim) {
        Boolean.valueOf(true);
        return new Maxim<>("mothballs", (short) 5);
    }

    public static final void main(String[] strArr) {
    }
}
