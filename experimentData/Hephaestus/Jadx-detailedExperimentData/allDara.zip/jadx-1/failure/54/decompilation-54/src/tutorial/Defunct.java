package src.tutorial;

import java.lang.Byte;
/* JADX WARN: Incorrect field signature: TM; */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
class Defunct<U extends Byte, M extends U, K> extends Adoptive {
    public Byte vesuvius;
    public Snottiest<Boolean, Integer, Boolean> whining;

    /* JADX WARN: Incorrect types in method signature: (Lsrc/tutorial/Snottiest<Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Boolean;>;TM;)V */
    public Defunct(Snottiest snottiest, Byte b) {
        super(Double.valueOf(79.989d), -32.179f);
        this.whining = snottiest;
        this.vesuvius = b;
    }
}
