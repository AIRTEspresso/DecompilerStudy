package src.tutorial;

import java.lang.String;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public abstract class Expelling<Q, E extends String, T extends Q> extends Enif {
    public Maxim<E, E, ? super Long> scarabs;

    public Expelling(Maxim<E, E, ? super Long> maxim) {
        this.scarabs = maxim;
    }

    @Override // src.tutorial.Enif
    public Enif calmer() {
        return new Enif();
    }

    public Kerr beachhead(Kerr kerr) {
        return this.scarabs;
    }
}
