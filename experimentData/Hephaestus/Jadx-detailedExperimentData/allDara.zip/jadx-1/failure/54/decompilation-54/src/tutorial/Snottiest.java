package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public abstract class Snottiest<V, B, H extends V> extends Spillway<Integer, B> {
    public Double flails;
    public Friskiest scooted;

    public abstract Whams<String, ? super String> pinochle(boolean z, V v);

    public Snottiest(Friskiest friskiest, Double d) {
        super(Double.valueOf(63.723d));
        this.scooted = friskiest;
        this.flails = d;
    }

    @Override // src.tutorial.Spillway, src.tutorial.Enif
    public Enif calmer() {
        Spillway spillway = null;
        Main.lorraine(null, 62);
        return spillway;
    }
}
