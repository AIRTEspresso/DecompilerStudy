package src.tutorial;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
public class Orienting<B, Y> extends Coccis<String, Long, B> {
    public Integer oculists;

    public Orienting(Integer num) {
        super("suffusing", (short) -88);
        this.oculists = num;
    }

    @Override // src.tutorial.Coccis
    public final B repealing() {
        return null;
    }

    public final Y rocco(Object obj, Y y) {
        return null;
    }
}
