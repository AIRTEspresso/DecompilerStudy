package src.tutorial;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
final class Flamings extends Orienting<Enif, Long> {
    public Friskiest[] lyricists;
    public Integer oculists;

    public Flamings(Integer num, Friskiest[] friskiestArr) {
        super(-44);
        this.oculists = num;
        this.lyricists = friskiestArr;
    }

    public final void dicks() {
        new Colanders(Double.valueOf(20.652d)).billets(null, -96.697d);
    }

    public final Whams<String, ? super String> leftovers(Snottiest<? super Float, Character, Float> snottiest, Whams<String, ? super String> whams) {
        this.lyricists = null;
        return new Whams<>((short) -65, "cassette");
    }
}
