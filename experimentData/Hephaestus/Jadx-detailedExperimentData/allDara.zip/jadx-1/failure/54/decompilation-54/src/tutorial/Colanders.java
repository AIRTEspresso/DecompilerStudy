package src.tutorial;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/54/original-54/Test.dex */
final class Colanders extends Spillway<Integer, String> {
    public Double flails;

    public Colanders(Double d) {
        super(Double.valueOf(-49.267d));
        this.flails = d;
    }

    public final void billets(Expelling<Float, ? extends String, Float> expelling, double d) {
    }
}
