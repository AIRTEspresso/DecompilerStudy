package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public abstract class Jinxes extends Maurine<Double> {
    public final Short domain;
    public final Long patience;

    public abstract Spindles<? extends String, ? extends String> tore(Tories<? extends Boolean, ? extends Boolean> tories);

    public Jinxes(Long l, Short sh) {
        super((short) -8);
        this.patience = l;
        this.domain = sh;
    }

    @Override // src.wordplay.Maurine, src.wordplay.Spindles
    public Number deploy(Number number) {
        return new Long(-29L);
    }
}
