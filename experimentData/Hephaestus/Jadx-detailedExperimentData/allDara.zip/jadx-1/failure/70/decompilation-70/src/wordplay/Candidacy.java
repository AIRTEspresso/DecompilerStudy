package src.wordplay;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
abstract class Candidacy<W extends Double> extends Spindles<String, String> {
    public final Short domain;
    public final Poachers<W> mope;

    public Candidacy(Poachers<W> poachers, Short sh) {
        super((short) 99, new Reckoned(true, null));
        this.mope = poachers;
        this.domain = sh;
    }

    public W sedated(double d, W w) {
        return null;
    }

    public W spillway() {
        return null;
    }
}
