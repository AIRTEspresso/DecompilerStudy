package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public final class Dioxins<D> extends Spindles<String, String> {
    public final Short domain;

    public Dioxins(Short sh) {
        super((short) -71, new Reckoned(false, null));
        this.domain = sh;
    }

    public final void tempts(Short sh) {
        Float.valueOf(66.381f);
    }

    @Override // src.wordplay.Spindles
    public final Number deploy(Number number) {
        Double valueOf = Double.valueOf(61.733d);
        Main.purest(Float.valueOf(1.783f));
        return valueOf;
    }
}
