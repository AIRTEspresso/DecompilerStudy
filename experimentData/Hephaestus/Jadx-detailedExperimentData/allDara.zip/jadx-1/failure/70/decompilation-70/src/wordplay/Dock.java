package src.wordplay;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
abstract class Dock<Y, P extends Double> extends Candidacy<Double> {
    public Conning<P, ? super Boolean> declaims;
    public final Short domain;

    public abstract Slurring<Double> uncle(Slurring<Double> slurring);

    public Dock(Conning<P, ? super Boolean> conning, Short sh) {
        super(new Poachers(null), (short) -12);
        this.declaims = conning;
        this.domain = sh;
    }

    public <F_S> F_S roommates() {
        return null;
    }
}
