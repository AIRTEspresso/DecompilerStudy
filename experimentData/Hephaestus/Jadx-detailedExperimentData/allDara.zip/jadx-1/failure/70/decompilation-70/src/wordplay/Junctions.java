package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public final class Junctions extends Candidacy<Double> {
    public final Short domain;

    public Junctions(Short sh) {
        super(new Poachers(null), (short) 20);
        this.domain = sh;
    }

    @Override // src.wordplay.Candidacy
    public final Double sedated(double d, Double d2) {
        return Double.valueOf(20.423d);
    }

    @Override // src.wordplay.Candidacy
    public final Double spillway() {
        Boolean bool = true;
        Mas mas = new Mas(Double.valueOf(-2.968d));
        Mas mas2 = new Mas(Double.valueOf(-45.184d));
        new Overnight(new Reckoned(false, null), -63).belleek('g');
        if (!bool.booleanValue()) {
            mas = mas2;
        }
        return mas.midgets;
    }
}
