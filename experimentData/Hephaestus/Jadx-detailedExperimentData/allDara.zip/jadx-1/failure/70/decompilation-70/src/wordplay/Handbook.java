package src.wordplay;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
class Handbook<T extends Double> extends Maurine<Double> {
    public final T midgets;

    public Handbook(T t) {
        super((short) -69);
        this.midgets = t;
    }

    public final Maurine<T> spent() {
        return new Maurine<>((short) 81);
    }
}
