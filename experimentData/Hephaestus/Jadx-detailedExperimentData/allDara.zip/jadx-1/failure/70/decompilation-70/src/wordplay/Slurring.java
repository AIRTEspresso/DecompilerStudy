package src.wordplay;

import java.lang.Double;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public class Slurring<C extends Double> extends Sightings {
    public C cluttered;
    public final Spindles<String, String> grossest;

    public Slurring(Spindles<String, String> spindles, C c) {
        super(null, new Reckoned(false, null));
        this.grossest = spindles;
        this.cluttered = c;
    }

    public final Lifelines<C> mosquito(Lifelines<C> lifelines) {
        Candidacy candidacy = null;
        return (Lifelines<C>) candidacy.mope.khalid;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final C debuting(C c) {
        Function2 function2 = new Function2() { // from class: src.wordplay.-$$Lambda$Slurring$J21GVQlbSQ8q3rYt9xbNAYJ7fYM
            @Override // src.wordplay.Function2
            public final Object apply(Object obj, Object obj2) {
                return Slurring.this.lambda$debuting$0$Slurring((Double) obj, (Double) obj2);
            }
        };
        Ghettos ghettos = null;
        Conning<P, ? super Boolean> conning = ghettos.splines.declaims;
        Double valueOf = Double.valueOf(-88.696d);
        Main.scissor("cute");
        return (C) ((Maurine) function2.apply(conning.memories(valueOf), null)).pigments(valueOf);
    }

    public /* synthetic */ Maurine lambda$debuting$0$Slurring(Double d, Double d2) {
        Bulking bulking;
        Boolean bool = true;
        if (bool.booleanValue()) {
            bulking = new Bulking((short) -21, (byte) 93);
        } else {
            bulking = new Bulking((short) -61, (byte) -42);
        }
        return bulking.dedicate(new Slurring(null, Double.valueOf(77.397d)), this.grossest).spent();
    }
}
