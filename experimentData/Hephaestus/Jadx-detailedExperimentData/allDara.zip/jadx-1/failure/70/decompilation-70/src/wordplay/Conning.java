package src.wordplay;

import java.lang.Double;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public final class Conning<M extends Double, J> extends Sightings {
    public final Integer wherein;

    public Conning(Integer num) {
        super(new Bulking((short) 55, -47L), new Reckoned(false, null));
        this.wherein = num;
    }

    public final M memories(Double d) {
        return null;
    }
}
