package src.wordplay;

import java.lang.Double;
import src.wordplay.Bulking;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
abstract class Ghettos<E extends Bulking<? super Double, ? super Byte>, T extends Double, L> extends Lifelines<T> {
    public final Dock<T, T> splines;

    public Ghettos(Dock<T, T> dock) {
        super(null);
        this.splines = dock;
    }

    @Override // src.wordplay.Lifelines
    public char outdoing(char c) {
        return 'N';
    }

    @Override // src.wordplay.Lifelines, src.wordplay.Reckoned
    public final byte golf() {
        return (byte) 53;
    }
}
