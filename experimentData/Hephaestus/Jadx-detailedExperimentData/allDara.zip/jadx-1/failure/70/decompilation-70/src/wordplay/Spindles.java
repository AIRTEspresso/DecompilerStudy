package src.wordplay;

import java.lang.String;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public abstract class Spindles<K extends String, W extends K> extends Reckoned {
    public final Short domain;
    public final Reckoned haddock;

    public Spindles(Short sh, Reckoned reckoned) {
        super(true, new Reckoned(false, null));
        this.domain = sh;
        this.haddock = reckoned;
    }

    @Override // src.wordplay.Reckoned
    public final Boolean census() {
        Main.skimps('8', (byte) -80);
        return false;
    }

    public Number deploy(Number number) {
        return number;
    }
}
