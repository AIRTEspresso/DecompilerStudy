package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public abstract class Tories<M, I extends M> extends Reckoned {
    public final char mbini;
    public Byte more;

    public abstract I sex();

    public Tories(Byte b, char c) {
        super(false, new Reckoned(false, null));
        this.more = b;
        this.mbini = c;
    }

    @Override // src.wordplay.Reckoned
    public Boolean census() {
        return false;
    }
}
