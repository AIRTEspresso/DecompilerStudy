package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public abstract class Sightings extends Reckoned {
    public final Spindles<String, String> grossest;
    public final Reckoned haddock;

    public Sightings(Spindles<String, String> spindles, Reckoned reckoned) {
        super(false, new Reckoned(false, null));
        this.grossest = spindles;
        this.haddock = reckoned;
    }
}
