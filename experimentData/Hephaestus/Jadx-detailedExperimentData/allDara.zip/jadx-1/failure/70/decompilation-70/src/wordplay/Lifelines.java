package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public abstract class Lifelines<S> extends Reckoned {
    public final Reckoned haddock;

    public abstract char outdoing(char c);

    public Lifelines(Reckoned reckoned) {
        super(false, new Reckoned(false, null));
        this.haddock = reckoned;
    }

    @Override // src.wordplay.Reckoned
    public byte golf() {
        Boolean bool = true;
        if (bool.booleanValue()) {
            return (byte) 34;
        }
        return (byte) 68;
    }
}
