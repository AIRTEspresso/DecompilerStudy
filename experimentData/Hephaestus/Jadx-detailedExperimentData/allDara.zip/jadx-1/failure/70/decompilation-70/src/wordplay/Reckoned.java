package src.wordplay;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public class Reckoned {
    public final Boolean garroted;
    public final Reckoned haddock;

    public Reckoned(Boolean bool, Reckoned reckoned) {
        this.garroted = bool;
        this.haddock = reckoned;
    }

    public byte golf() {
        return (byte) -64;
    }

    public Boolean census() {
        return Boolean.valueOf(census().booleanValue() || census().booleanValue());
    }
}
