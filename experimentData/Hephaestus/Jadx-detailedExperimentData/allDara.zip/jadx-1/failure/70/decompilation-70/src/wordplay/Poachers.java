package src.wordplay;

import java.lang.Double;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public class Poachers<H extends Double> extends Lifelines<H> {
    public final Lifelines<H> khalid;

    public Poachers(Lifelines<H> lifelines) {
        super(new Reckoned(false, null));
        this.khalid = lifelines;
    }

    @Override // src.wordplay.Lifelines
    public char outdoing(char c) {
        return 'B';
    }

    @Override // src.wordplay.Lifelines, src.wordplay.Reckoned
    public byte golf() {
        return (byte) 41;
    }
}
