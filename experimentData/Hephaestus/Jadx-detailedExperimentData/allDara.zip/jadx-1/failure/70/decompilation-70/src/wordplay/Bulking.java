package src.wordplay;

import java.lang.Double;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public final class Bulking<V extends Double, U> extends Spindles<String, String> {
    public U coerced;
    public final Short domain;

    public Bulking(Short sh, U u) {
        super((short) -80, null);
        this.domain = sh;
        this.coerced = u;
    }

    public final Handbook<V> dedicate(Sightings sightings, Reckoned reckoned) {
        return new Handbook<>(null);
    }

    public final V jaipur() {
        V v = null;
        new Mas(Double.valueOf(85.641d)).maxim(null, v);
        return v;
    }
}
