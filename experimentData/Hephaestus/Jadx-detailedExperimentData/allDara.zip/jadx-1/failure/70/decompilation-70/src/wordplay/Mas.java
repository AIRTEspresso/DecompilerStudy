package src.wordplay;

import java.lang.String;
import src.wordplay.Slurring;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
final class Mas<R extends String, N, I extends Slurring<Double>> extends Handbook<Double> {
    public final Double midgets;

    public Mas(Double d) {
        super(Double.valueOf(64.881d));
        this.midgets = d;
    }

    public final void maxim(I i, N n) {
        new Dioxins((short) -100).tempts((short) -26);
    }

    public final Poachers<Double> rover(I i) {
        return new Poachers<>(null);
    }
}
