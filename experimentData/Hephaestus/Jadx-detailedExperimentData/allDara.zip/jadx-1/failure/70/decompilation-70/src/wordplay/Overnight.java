package src.wordplay;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
class Overnight extends Reckoned {
    public final Integer bedpans;
    public final Reckoned haddock;

    public Overnight(Reckoned reckoned, Integer num) {
        super(false, new Reckoned(true, null));
        this.haddock = reckoned;
        this.bedpans = num;
    }

    public void belleek(Character ch) {
        new Handbook(Double.valueOf(54.205d));
    }
}
