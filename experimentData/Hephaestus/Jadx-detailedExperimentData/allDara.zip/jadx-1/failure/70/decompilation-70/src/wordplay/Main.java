package src.wordplay;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
class Main {
    static final Boolean globs = false;
    static final Number pimply;
    static Object watkins;

    Main() {
    }

    public static final Short tourney() {
        Sightings sightings = null;
        return sightings.grossest.domain;
    }

    public static final void skimps(char c, byte b) {
        new Function1() { // from class: src.wordplay.-$$Lambda$Main$AakOGLXY18X9r7RrTyld8MFse0E
            @Override // src.wordplay.Function1
            public final Object apply(Object obj) {
                return Main.lambda$skimps$0((Float) obj);
            }
        }.apply(Float.valueOf(-0.7f));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$skimps$0(Float f) {
        return null;
    }

    static {
        Long l = new Long(-17L);
        pimply = l;
        watkins = l;
    }

    public static final <F_I extends Float> void purest(F_I f_i) {
        Float.valueOf(16.8f);
    }

    public static final void scissor(String str) {
        Short.valueOf((short) -27);
    }

    public static final Poachers<? super Double> guilty(long j) {
        Boolean bool;
        Boolean.valueOf(false);
        Lifelines lifelines = null;
        Poachers poachers = new Poachers(lifelines);
        Poachers<? super Double> poachers2 = new Poachers<>(lifelines);
        if (poachers.garroted.booleanValue()) {
            bool = globs;
        } else {
            bool = globs;
        }
        if (!bool.booleanValue()) {
            return poachers2;
        }
        return new Mas(Double.valueOf(40.614d)).rover(null);
    }

    public static final Conning<Double, Junctions> rendered(Conning<Double, Junctions> conning) {
        Reckoned dioxins;
        Integer.valueOf(26);
        Boolean bool = globs;
        Boolean bool2 = false;
        if (bool2.booleanValue()) {
            dioxins = (Tories) null;
        } else {
            dioxins = new Dioxins((short) 43);
        }
        currying(bool, dioxins);
        return rendered(new Conning(31));
    }

    public static final void currying(Boolean bool, Reckoned reckoned) {
        Jinxes jinxes = null;
        Long l = jinxes.patience;
    }

    public static final void main(String[] strArr) {
        rendered(new Conning(31));
    }
}
