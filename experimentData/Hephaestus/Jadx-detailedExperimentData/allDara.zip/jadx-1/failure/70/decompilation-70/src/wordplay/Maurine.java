package src.wordplay;

import java.lang.Double;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/70/original-70/Test.dex */
public class Maurine<F extends Double> extends Spindles<String, String> {
    public final Short domain;

    public Maurine(Short sh) {
        super((short) 33, new Reckoned(false, null));
        this.domain = sh;
    }

    public F pigments(Object obj) {
        Boolean bool = false;
        F f = null;
        if (bool.booleanValue()) {
        }
        return f;
    }

    @Override // src.wordplay.Spindles
    public Number deploy(Number number) {
        new Long(54L);
        Maurine maurine = null;
        return maurine.domain;
    }
}
