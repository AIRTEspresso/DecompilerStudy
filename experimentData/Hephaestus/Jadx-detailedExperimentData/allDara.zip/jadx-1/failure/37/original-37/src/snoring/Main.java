package src.snoring;

class Main {
  static long supper = (long)68;

  static final long gutierrez = Main.supper;

  static long bromide = Main.gutierrez;

  static final Long lonnie = (long)0;

  static public final void intensely() {
    Object x_0 = 40.512;
    
  }

  static public final Splice revives(long mulched) {
    Fruitful hostlers = (Fruitful) null;
    Main.whist(85.159);
    return hostlers.postmark;
    
  }

  static public final void whist(Double gigabytes) {
    Aligns<Fruitful, Object, Number> hemingway = (Aligns<Fruitful, Object, Number>) null;
    Aligns<Fruitful, Object, Number> folds = ((false) ?
      (Aligns<Fruitful, Object, Number>) null : 
       hemingway);
    Fruitful redefines = Main.nearing();
    Function1<Byte, Void> zillion = (rubik) -> {
      final Double braking = -37.193;
      Double canonical = 74.712;
      final Double patience = ((false) ?
        braking : 
         canonical);
      new Laminates(-20, (Fruitful) null).tracy(  ((false) ?
  true : 
   true), (Naughty) null).droops(new Daredevil(82.400, 98));
      Object x_1 = patience;
      return null;
    };
    zillion.apply((byte)-64);
    folds.woodman(redefines, Main.gutierrez);
    
  }

  static public final Fruitful nearing() {
    final Fruitful nubile = Main.nearing();
    Function1<Integer, Void> measured = (ampoule) -> {
      Function2<Byte, Splice, Void> wriggles = (terrible, archduke) -> {
        final Aligns<Fruitful, Integer, ? super Float> blunderer = (Aligns<Fruitful, Integer, Float>) null;
        Object x_2 = blunderer;
        return null;
      };
      new Thieving<String, String, Double>().gunnery((Fruitful) null, nubile);
      wriggles.apply((byte)-77, nubile);
      return null;
    };
    measured.apply(63);
    return nubile;
    
  }

  static public final <F_P extends Integer> void passable(F_P prosiest, Boolean busboy) {
    Main.supper = (long)-4;
    Object x_6 = -18;
    
  }

  static public final Number steered() {
    Integer yaws = 92;
    Main.supper = Main.supper;
    return yaws;
    
  }

  static final Boolean gabon = true;

  static public final Flintiest<Long, Short, Splice> logbook(Fruitful graveling) {
    return (Flintiest<Long, Short, Splice>) null;
  }

  static Fruitful value = ((Main.gabon) ?
  Main.logbook((Fruitful) null) : 
   (Flintiest<Long, Short, Splice>) null);

  static public final void main(String[] args) {
    Object x_7 = Main.value.postmark;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



abstract class Splice {
  public Short slangier;
  public Integer gigabyte;

  public Splice(Short slangier,Integer gigabyte) {
    this.slangier = slangier;
    this.gigabyte = gigabyte;
  }

  public abstract <F_T extends Double> Double gunpowder(F_T spectator) ;

  public abstract byte meekest(double bulbous) ;
}

abstract class Naughty extends Splice {
  public Short slangier;
  public char jinny;

  public Naughty(Short slangier,char jinny) {
    super((short)24, -61);
    this.slangier = slangier;
    this.jinny = jinny;
  }

  public <F_T extends Double> Double gunpowder(F_T spectator) {
    F_T shorthorn = (F_T) null;
    final Double picnicked = ((Naughty) null).gunpowder(  ((true) ?
  shorthorn : 
   (F_T) null));
    return picnicked;
    
  }

  public double drive() {
    Function2<Byte, Integer, Daredevil> working = (bellows, scotty) -> {
      Daredevil dioxins = ((Fruitful) null).postmark;
      return dioxins;
      
    };
    Rat<Long, Boolean, Byte> recenter = (Rat<Long, Boolean, Byte>) null;
    final byte giddy = recenter.baptistry;
    int bullfrog = 66;
    return working.apply(giddy, bullfrog).sluggard;
    
  }
}

final class Daredevil extends Splice {
  public double sluggard;
  public Integer gigabyte;

  public Daredevil(double sluggard,Integer gigabyte) {
    super((short)52, 44);
    this.sluggard = sluggard;
    this.gigabyte = gigabyte;
  }

  public byte meekest(double bulbous) {
    final byte vagrant = (byte)-17;
    return vagrant;
    
  }

  public <F_T extends Double> Double gunpowder(F_T spectator) {
    final Double strews = 36.726;
    return strews;
    
  }
}

abstract class Fruitful extends Splice {
  public Daredevil postmark;
  public Short slangier;

  public Fruitful(Daredevil postmark,Short slangier) {
    super((short)-25, 68);
    this.postmark = postmark;
    this.slangier = slangier;
  }

  public byte meekest(double bulbous) {
    final byte writhed = (byte)-96;
    return writhed;
    
  }

  public <F_T extends Double> Double gunpowder(F_T spectator) {
    Double shockley = 71.660;
    return shockley;
    
  }
}

abstract class Rat<Z extends Long, E extends Boolean, Q> extends Splice {
  public byte baptistry;
  public final Daredevil catherine;

  public Rat(byte baptistry,Daredevil catherine) {
    super((short)26, -52);
    this.baptistry = baptistry;
    this.catherine = catherine;
  }

  public <F_T extends Double> Double gunpowder(F_T spectator) {
    final F_T falstaff = (F_T) null;
    F_T shrub = falstaff;
    Main.intensely();
    return shrub;
    
  }
}

interface Aligns<K extends Fruitful, B, P> {
  public abstract Naughty woodman(K messy, Long nodal) ;

  public abstract B eatable(K permeate, Integer marathon) ;
}

class Thieving<N extends String, F extends String, G> implements Aligns<Fruitful, Splice, Double> {
  public <F_X> void gunnery(F_X adapted, F_X promenade) {
    Object x_3 = (F) null;
    
  }

  public Splice eatable(Fruitful permeate, Integer marathon) {
    final double toward = 18.917;
    Integer voodoos = 61;
    Function0<Void> base = () -> {
      double narrowest = 90.320;
      final Daredevil serra = new Daredevil(narrowest, 99);
      ((Fruitful) null).postmark = serra;
      Object x_4 = (N) null;
      return null;
    };
    base.apply();
    return new Daredevil(toward, voodoos);
    
  }

  public Naughty woodman(Fruitful messy, Long nodal) {
    return (Naughty) null;
  }
}

abstract class Flintiest<F extends Long, B, E> extends Fruitful {
  public Short slangier;

  public Flintiest(Short slangier) {
    super(new Daredevil(20.837, -4), (short)84);
    this.slangier = slangier;
  }

  public void droops(Splice walt) {
    Integer slowdowns = -76;
    final Boolean northern = true;
    Main.passable(-62, northern);
    Object x_5 = slowdowns;
    
  }
}

final class Laminates extends Splice {
  public Integer gigabyte;
  public final Fruitful forbad;

  public Laminates(Integer gigabyte,Fruitful forbad) {
    super((short)-3, -36);
    this.gigabyte = gigabyte;
    this.forbad = forbad;
  }

  public final Flintiest<Long, String, Fruitful> tracy(Boolean patella, Naughty snorkeled) {
    return (Flintiest<Long, String, Fruitful>) null;
  }

  public byte meekest(double bulbous) {
    byte mediaeval = (byte)-12;
    return mediaeval;
    
  }

  public <F_T extends Double> Double gunpowder(F_T spectator) {
    return 81.825;
  }
}