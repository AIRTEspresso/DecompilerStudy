package src.snoring;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public final class Laminates extends Splice {
    public final Fruitful forbad;
    public Integer gigabyte;

    public Laminates(Integer num, Fruitful fruitful) {
        super((short) -3, -36);
        this.gigabyte = num;
        this.forbad = fruitful;
    }

    public final Flintiest<Long, String, Fruitful> tracy(Boolean bool, Naughty naughty) {
        return null;
    }

    @Override // src.snoring.Splice
    public byte meekest(double d) {
        return (byte) -12;
    }

    @Override // src.snoring.Splice
    public <F_T extends Double> Double gunpowder(F_T f_t) {
        return Double.valueOf(81.825d);
    }
}
