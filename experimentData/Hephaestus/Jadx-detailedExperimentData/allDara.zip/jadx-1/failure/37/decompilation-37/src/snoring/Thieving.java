package src.snoring;

import java.lang.String;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public class Thieving<N extends String, F extends String, G> implements Aligns<Fruitful, Splice, Double> {
    public <F_X> void gunnery(F_X f_x, F_X f_x2) {
    }

    @Override // src.snoring.Aligns
    public Splice eatable(Fruitful fruitful, Integer num) {
        new Function0() { // from class: src.snoring.-$$Lambda$Thieving$R_LZzb1f_UjSD8uxRvKV-1MbDw4
            @Override // src.snoring.Function0
            public final Object apply() {
                return Thieving.lambda$eatable$0();
            }
        }.apply();
        return new Daredevil(18.917d, 61);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$eatable$0() {
        Fruitful fruitful = null;
        fruitful.postmark = new Daredevil(90.32d, 99);
        return null;
    }

    @Override // src.snoring.Aligns
    public Naughty woodman(Fruitful fruitful, Long l) {
        return null;
    }
}
