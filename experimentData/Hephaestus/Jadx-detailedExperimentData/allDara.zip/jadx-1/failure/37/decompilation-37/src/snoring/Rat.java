package src.snoring;

import java.lang.Boolean;
import java.lang.Long;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
abstract class Rat<Z extends Long, E extends Boolean, Q> extends Splice {
    public byte baptistry;
    public final Daredevil catherine;

    public Rat(byte b, Daredevil daredevil) {
        super((short) 26, -52);
        this.baptistry = b;
        this.catherine = daredevil;
    }

    @Override // src.snoring.Splice
    public <F_T extends Double> Double gunpowder(F_T f_t) {
        Double d = null;
        Main.intensely();
        return d;
    }
}
