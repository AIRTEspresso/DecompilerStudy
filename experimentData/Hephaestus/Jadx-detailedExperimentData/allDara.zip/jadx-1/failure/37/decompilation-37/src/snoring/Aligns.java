package src.snoring;

import src.snoring.Fruitful;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public interface Aligns<K extends Fruitful, B, P> {
    B eatable(K k, Integer num);

    Naughty woodman(K k, Long l);
}
