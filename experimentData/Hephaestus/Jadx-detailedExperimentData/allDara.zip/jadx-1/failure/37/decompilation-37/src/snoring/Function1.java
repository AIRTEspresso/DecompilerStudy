package src.snoring;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
interface Function1<A1, R> {
    R apply(A1 a1);
}
