package src.snoring;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public abstract class Splice {
    public Integer gigabyte;
    public Short slangier;

    public abstract <F_T extends Double> Double gunpowder(F_T f_t);

    public abstract byte meekest(double d);

    public Splice(Short sh, Integer num) {
        this.slangier = sh;
        this.gigabyte = num;
    }
}
