package src.snoring;

import java.lang.Long;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public abstract class Flintiest<F extends Long, B, E> extends Fruitful {
    public Short slangier;

    public Flintiest(Short sh) {
        super(new Daredevil(20.837d, -4), (short) 84);
        this.slangier = sh;
    }

    public void droops(Splice splice) {
        Integer.valueOf(-76);
        Main.passable(-62, true);
    }
}
