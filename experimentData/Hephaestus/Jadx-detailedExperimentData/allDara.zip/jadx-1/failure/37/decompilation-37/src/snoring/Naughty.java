package src.snoring;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public abstract class Naughty extends Splice {
    public char jinny;
    public Short slangier;

    public Naughty(Short sh, char c) {
        super((short) 24, -61);
        this.slangier = sh;
        this.jinny = c;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // src.snoring.Splice
    public <F_T extends Double> Double gunpowder(F_T f_t) {
        Naughty naughty = (Naughty) 0;
        return naughty.gunpowder(null);
    }

    public double drive() {
        Rat rat = null;
        return ((Daredevil) new Function2() { // from class: src.snoring.-$$Lambda$Naughty$mHWp09nljlda8lMOWAMJo1ebGOg
            @Override // src.snoring.Function2
            public final Object apply(Object obj, Object obj2) {
                return Naughty.lambda$drive$0((Byte) obj, (Integer) obj2);
            }
        }.apply(Byte.valueOf(rat.baptistry), 66)).sluggard;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Daredevil lambda$drive$0(Byte b, Integer num) {
        Fruitful fruitful = null;
        return fruitful.postmark;
    }
}
