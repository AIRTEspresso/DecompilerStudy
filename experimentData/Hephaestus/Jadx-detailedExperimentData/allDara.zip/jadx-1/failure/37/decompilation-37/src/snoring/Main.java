package src.snoring;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public class Main {
    static final Boolean gabon;
    static Fruitful value;
    static long supper = 68;
    static final long gutierrez = 68;
    static long bromide = 68;
    static final Long lonnie = 0L;

    Main() {
    }

    static {
        Flintiest<Long, Short, Splice> flintiest;
        Boolean bool = true;
        gabon = bool;
        if (bool.booleanValue()) {
            flintiest = logbook(null);
        } else {
            flintiest = null;
        }
        value = flintiest;
    }

    public static final void intensely() {
        Double.valueOf(40.512d);
    }

    public static final Splice revives(long j) {
        Fruitful fruitful = null;
        whist(Double.valueOf(85.159d));
        return fruitful.postmark;
    }

    public static final void whist(Double d) {
        Aligns aligns = null;
        Fruitful nearing = nearing();
        new Function1() { // from class: src.snoring.-$$Lambda$Main$ugbNclhhluIG84EvVHL8P6EumQs
            @Override // src.snoring.Function1
            public final Object apply(Object obj) {
                return Main.lambda$whist$0((Byte) obj);
            }
        }.apply((byte) -64);
        aligns.woodman(nearing, Long.valueOf(gutierrez));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$whist$0(Byte b) {
        Double.valueOf(-37.193d);
        Double.valueOf(74.712d);
        new Laminates(-20, null).tracy(true, null).droops(new Daredevil(82.4d, 98));
        return null;
    }

    public static final Fruitful nearing() {
        final Fruitful nearing = nearing();
        new Function1() { // from class: src.snoring.-$$Lambda$Main$D1tva5Nz4fBZ0m5zo9010UTqKvo
            @Override // src.snoring.Function1
            public final Object apply(Object obj) {
                return Main.lambda$nearing$2(Fruitful.this, (Integer) obj);
            }
        }.apply(63);
        return nearing;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$nearing$2(Fruitful fruitful, Integer num) {
        $$Lambda$Main$P8woYDsYJPuObNZCPD0mzVCqJlg __lambda_main_p8woydsyjpuobnzcpd0mzvcqjlg = new Function2() { // from class: src.snoring.-$$Lambda$Main$P8woYDsYJPuObNZCPD0mzVCqJlg
            @Override // src.snoring.Function2
            public final Object apply(Object obj, Object obj2) {
                return Main.lambda$nearing$1((Byte) obj, (Splice) obj2);
            }
        };
        new Thieving().gunnery(null, fruitful);
        __lambda_main_p8woydsyjpuobnzcpd0mzvcqjlg.apply((byte) -77, fruitful);
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$nearing$1(Byte b, Splice splice) {
        return null;
    }

    public static final <F_P extends Integer> void passable(F_P f_p, Boolean bool) {
        supper = -4L;
        Integer.valueOf(-18);
    }

    public static final Number steered() {
        supper = supper;
        return 92;
    }

    public static final Flintiest<Long, Short, Splice> logbook(Fruitful fruitful) {
        return null;
    }

    public static final void main(String[] strArr) {
        Daredevil daredevil = value.postmark;
    }
}
