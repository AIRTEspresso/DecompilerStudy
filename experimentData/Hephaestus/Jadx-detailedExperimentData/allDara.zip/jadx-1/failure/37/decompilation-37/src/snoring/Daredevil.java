package src.snoring;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/37/original-37/Test.dex */
public final class Daredevil extends Splice {
    public Integer gigabyte;
    public double sluggard;

    public Daredevil(double d, Integer num) {
        super((short) 52, 44);
        this.sluggard = d;
        this.gigabyte = num;
    }

    @Override // src.snoring.Splice
    public byte meekest(double d) {
        return (byte) -17;
    }

    @Override // src.snoring.Splice
    public <F_T extends Double> Double gunpowder(F_T f_t) {
        return Double.valueOf(36.726d);
    }
}
