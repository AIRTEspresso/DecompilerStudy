package src.blushes;

import java.lang.Boolean;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
final class Stink<I extends Boolean> implements Argonne<I, Double, Double> {
    public final Charwoman discounts;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // src.blushes.Argonne
    public /* bridge */ /* synthetic */ Object deli(Object obj) {
        return deli((Stink<I>) ((Boolean) obj));
    }

    public Stink(Charwoman charwoman) {
        this.discounts = charwoman;
    }

    @Override // src.blushes.Argonne
    public String debuting(String str) {
        this.discounts.unfounded = str;
        return "bestowals";
    }

    @Override // src.blushes.Lolling
    public char treated(Long l, char c) {
        return 'R';
    }

    public I deli(I i) {
        return null;
    }
}
