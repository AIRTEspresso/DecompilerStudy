package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
abstract class Loath extends Simply<Short, Short, Short> {
    public final Simply<Short, Short, Short> despised;
    public final Integer thriftily;

    public Loath(Simply<Short, Short, Short> simply, Integer num) {
        super(-50, (short) 16);
        this.despised = simply;
        this.thriftily = num;
    }

    public Double shoo() {
        return Double.valueOf(-18.45d);
    }
}
