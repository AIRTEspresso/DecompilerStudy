package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
interface Function2<A1, A2, R> {
    R apply(A1 a1, A2 a2);
}
