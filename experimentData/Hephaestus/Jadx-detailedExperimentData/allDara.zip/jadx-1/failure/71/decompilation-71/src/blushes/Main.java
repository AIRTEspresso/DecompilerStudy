package src.blushes;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
class Main {
    Main() {
    }

    public static final Float creating(Long l) {
        float f;
        Boolean froze = new Hamlets((Long[]) new Object[]{34L, -66L, 6L}).froze();
        Float valueOf = Float.valueOf(8.58f);
        if (froze.booleanValue()) {
            f = valueOf.floatValue();
        } else {
            f = 8.581f;
        }
        return Float.valueOf(f);
    }

    public static final void braked(Boolean bool) {
        Integer.valueOf(-86);
    }

    public static final <F_M> void dinners(F_M f_m, Byte b) {
        Loath loath = null;
        new Stink(null).discounts.unfounded = loath.jarvis;
    }

    public static final Salvoes<? super Unmaking> divert(Salvoes<? super Unmaking> salvoes) {
        return new Rookie(null).mesozoic;
    }

    public static final void main(String[] strArr) {
        creating(-9L);
    }
}
