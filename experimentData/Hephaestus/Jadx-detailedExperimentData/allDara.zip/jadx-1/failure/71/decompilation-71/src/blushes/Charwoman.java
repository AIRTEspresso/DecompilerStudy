package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
abstract class Charwoman implements Argonne<Object, Double, Double> {
    public Object unfounded;

    public Charwoman(Object obj) {
        this.unfounded = obj;
    }

    public Kshatriya<Object> musical(Character ch, Integer num) {
        return null;
    }
}
