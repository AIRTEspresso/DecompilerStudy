package src.blushes;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
interface Argonne<S, M extends Double, I extends M> extends Lolling {
    String debuting(String str);

    S deli(S s);
}
