package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
abstract class Salvoes<B> implements Lolling {
    @Override // src.blushes.Lolling
    public char treated(Long l, char c) {
        Boolean bool = true;
        Long.valueOf(-26L);
        Long.valueOf(-10L);
        Main.braked(new Hamlets(new Long[0]).froze());
        if (bool.booleanValue()) {
            return 'y';
        }
        return '4';
    }

    public Integer tweaks() {
        Boolean bool = false;
        if (bool.booleanValue()) {
            return 19;
        }
        return -73;
    }
}
