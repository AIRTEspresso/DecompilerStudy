package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
final class Rookie<P> implements Carton {
    public final Salvoes<Unmaking> mesozoic;

    public Rookie(Salvoes<Unmaking> salvoes) {
        this.mesozoic = salvoes;
    }

    @Override // src.blushes.Carton
    public void skyrocket() {
        Dearer dearer = null;
        Charwoman charwoman = (Charwoman) dearer;
        charwoman.unfounded = (short) -100;
        Dearer dearer2 = dearer;
        F f = dearer2.antonia;
    }

    @Override // src.blushes.Lolling
    public char treated(Long l, char c) {
        new Function0() { // from class: src.blushes.-$$Lambda$Rookie$JsxfhtbCqL8faUBYbljZE2-3wFo
            @Override // src.blushes.Function0
            public final Object apply() {
                return Rookie.lambda$treated$0();
            }
        }.apply();
        return c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$treated$0() {
        return null;
    }
}
