package src.blushes;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
public final class Unmaking extends Salvoes<Character> {
    @Override // src.blushes.Salvoes
    public final Integer tweaks() {
        Charwoman charwoman = null;
        Main.dinners(Boolean.valueOf(new Quibblers((short) -76, -59).bastards(null) == null), (byte) -9);
        return new Stink(charwoman).discounts.musical('J', -82).gruffness().despised.thriftily;
    }

    public final String commandos() {
        return "frostings";
    }
}
