package src.blushes;

import java.lang.Short;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
abstract class Simply<E extends Short, P extends E, S extends P> extends Salvoes<Integer> {
    public final E jarvis;
    public final Integer thriftily;

    public Simply(Integer num, E e) {
        this.thriftily = num;
        this.jarvis = e;
    }

    @Override // src.blushes.Salvoes, src.blushes.Lolling
    public final char treated(Long l, char c) {
        Carton carton = null;
        carton.skyrocket();
        return 'y';
    }

    public E empowered(int i, E e) {
        return null;
    }
}
