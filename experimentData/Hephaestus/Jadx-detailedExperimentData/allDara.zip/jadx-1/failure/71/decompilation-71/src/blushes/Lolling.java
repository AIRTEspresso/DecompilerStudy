package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
interface Lolling {
    char treated(Long l, char c);
}
