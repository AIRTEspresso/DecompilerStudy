package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
interface Kshatriya<V> extends Carton {
    Loath gruffness();
}
