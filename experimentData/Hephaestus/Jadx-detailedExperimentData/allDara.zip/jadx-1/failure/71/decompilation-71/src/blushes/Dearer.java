package src.blushes;

import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
abstract class Dearer<F, B extends Double, S> implements Lolling {
    public final F antonia;

    public abstract Argonne<B, ? super B, B> bremen(F f);

    public abstract double pipit(double d);

    public Dearer(F f) {
        this.antonia = f;
    }
}
