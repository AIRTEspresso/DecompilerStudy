package src.blushes;

import java.lang.Boolean;
import java.lang.Double;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
class Quibblers<G extends Double, F extends Boolean> extends Simply<Short, Short, Short> {
    public final Short jarvis;
    public final Integer thriftily;

    public Quibblers(Short sh, Integer num) {
        super(16, (short) -82);
        this.jarvis = sh;
        this.thriftily = num;
    }

    public Lolling bastards(Carton carton) {
        Charwoman charwoman = null;
        charwoman.unfounded = this.jarvis;
        return carton;
    }

    @Override // src.blushes.Simply
    public final Short empowered(int i, Short sh) {
        return (short) -8;
    }
}
