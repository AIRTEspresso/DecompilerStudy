package src.blushes;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/71/original-71/Test.dex */
final class Talkative implements Argonne<Long, Double, Double> {
    Talkative() {
    }

    @Override // src.blushes.Argonne
    public String debuting(String str) {
        return "reproving";
    }

    @Override // src.blushes.Lolling
    public char treated(Long l, char c) {
        return c;
    }

    @Override // src.blushes.Argonne
    public Long deli(Long l) {
        Long l2 = 48L;
        return Long.valueOf(l2.longValue());
    }
}
