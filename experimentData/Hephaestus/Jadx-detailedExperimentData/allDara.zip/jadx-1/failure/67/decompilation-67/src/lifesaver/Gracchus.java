package src.lifesaver;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/67/original-67/Test.dex */
abstract class Gracchus<F, G, P> {
    public final G hunch;
    public final F readers;

    public abstract G elisa();

    public Gracchus(F f, G g) {
        this.readers = f;
        this.hunch = g;
    }
}
