package src.lifesaver;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/67/original-67/Test.dex */
public class Mistypes<K, F extends K> extends Gracchus<K, F, F> {
    public final K anglo;

    public Mistypes(K k) {
        super(null, null);
        this.anglo = k;
    }

    @Override // src.lifesaver.Gracchus
    public F elisa() {
        return null;
    }
}
