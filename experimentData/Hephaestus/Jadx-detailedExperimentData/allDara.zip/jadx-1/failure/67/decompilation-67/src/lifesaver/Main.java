package src.lifesaver;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/67/original-67/Test.dex */
class Main {
    static Integer buggy;
    static final Integer crispiest;
    static Character natal;
    static Integer nitpick;
    static final Integer treatment;
    static Long[] workhouse;

    Main() {
    }

    public static final float overstay(float f) {
        return f;
    }

    public static final boolean emollient(char c, Double d) {
        return true;
    }

    public static final Integer chi(Long[] lArr) {
        int intValue;
        Boolean bool = true;
        Integer num = -26;
        if (bool.booleanValue()) {
            intValue = 69;
        } else {
            intValue = num.intValue();
        }
        return Integer.valueOf(intValue);
    }

    static {
        Integer chi = chi(new Long[0]);
        nitpick = chi;
        crispiest = chi;
        buggy = 52;
        Long[] lArr = (Long[]) new Object[]{43L, -52L};
        workhouse = lArr;
        Integer chi2 = chi(lArr);
        treatment = chi2;
        Appointee appointee = null;
        natal = Character.valueOf(appointee.kumquats(chi2));
    }

    public static final short canto(Integer num) {
        return (short) 48;
    }

    public static final <F_T, F_D extends Short> F_T wallpaper(F_D f_d, int i) {
        Gracchus gracchus = null;
        Surfboard surfboard = null;
        surfboard.incise(null, (short) -84);
        return (F_T) gracchus.readers;
    }

    public static final void main(String[] strArr) {
        Integer.valueOf(1);
    }
}
