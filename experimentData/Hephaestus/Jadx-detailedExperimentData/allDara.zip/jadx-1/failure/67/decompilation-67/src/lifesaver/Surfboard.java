package src.lifesaver;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/67/original-67/Test.dex */
abstract class Surfboard<B, I extends B, G> extends Gracchus<G, G, B> {
    public abstract void incise(Surfboard<Integer, ? extends Integer, ? extends Long> surfboard, I i);

    public Surfboard() {
        super(null, null);
    }

    @Override // src.lifesaver.Gracchus
    public G elisa() {
        Boolean bool = false;
        Wryest wryest = new Wryest(null, null);
        Appointee appointee = null;
        new Function1() { // from class: src.lifesaver.-$$Lambda$Surfboard$dhatzssnvDU01gCQ5roUbjs6f9I
            @Override // src.lifesaver.Function1
            public final Object apply(Object obj) {
                return Surfboard.lambda$elisa$0((Character) obj);
            }
        }.apply(Character.valueOf(appointee.kumquats(7)));
        if (!bool.booleanValue()) {
            wryest = new Wryest(null, null);
        }
        return wryest.repairs;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$elisa$0(Character ch) {
        K k = new Mistypes(null).anglo;
        Double.valueOf(-11.926d);
        Double.valueOf(-6.408d);
        return null;
    }
}
