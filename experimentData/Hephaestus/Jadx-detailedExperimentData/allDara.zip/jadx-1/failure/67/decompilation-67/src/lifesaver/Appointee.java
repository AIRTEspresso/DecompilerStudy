package src.lifesaver;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/67/original-67/Test.dex */
interface Appointee {
    char kumquats(Integer num);
}
