package src.lifesaver;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/67/original-67/Test.dex */
final class Wryest<G> extends Gracchus<G, G, G> {
    public final G readers;
    public final G repairs;

    public Wryest(G g, G g2) {
        super(null, null);
        this.repairs = g;
        this.readers = g2;
    }

    @Override // src.lifesaver.Gracchus
    public G elisa() {
        return null;
    }
}
