package src.hyaena;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
public abstract class Thesauri<B> implements Scoops {
    public B yelped;

    public Thesauri(B b) {
        this.yelped = b;
    }

    public Double overthink(B b) {
        Double valueOf = Double.valueOf(64.996d);
        new Impanel(null).toasty.televised((short) -36);
        return valueOf;
    }

    @Override // src.hyaena.Scoops
    public <F_V> F_V jimmie(F_V f_v) {
        F_V f_v2 = (F_V) new Womanhood(new Impanel(null).toasty).jules(null);
        new Function1() { // from class: src.hyaena.-$$Lambda$Thesauri$JdkTMU0yTAot9-M78uADXJfKwbk
            @Override // src.hyaena.Function1
            public final Object apply(Object obj) {
                return Thesauri.lambda$jimmie$0(obj);
            }
        }.apply(null);
        return f_v2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ Void lambda$jimmie$0(Object obj) {
        Scoops scoops = new Secondly(null).chitlins;
        return null;
    }
}
