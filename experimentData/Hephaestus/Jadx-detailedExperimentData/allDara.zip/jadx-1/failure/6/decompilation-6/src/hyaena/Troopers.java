package src.hyaena;

import java.lang.Integer;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
abstract class Troopers<F, Y extends Integer> extends Womanhood<Boolean, Integer, Integer> {
    public final F coolie;

    public abstract Y misquotes(Y y, Y y2);

    public abstract Y policeman();

    public Troopers(F f) {
        super(new Secondly(null));
        this.coolie = f;
    }
}
