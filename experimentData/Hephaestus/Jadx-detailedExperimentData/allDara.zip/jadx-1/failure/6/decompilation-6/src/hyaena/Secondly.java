package src.hyaena;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
public final class Secondly<K> extends Womanhood<Character, Integer, Integer> {
    public Thesauri<K> chitlins;

    public Secondly(Thesauri<K> thesauri) {
        super(new Impanel(null));
        this.chitlins = thesauri;
    }
}
