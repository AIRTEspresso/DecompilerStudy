package src.hyaena;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
interface Scoops {
    <F_V> F_V jimmie(F_V f_v);
}
