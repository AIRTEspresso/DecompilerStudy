package src.hyaena;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
class Main {
    static final Double paltriest;
    static final Character prenups;
    static final Character refs;
    static Thesauri<Integer> sainthood;
    static Character tapped;
    static Double yerevan;

    Main() {
    }

    public static final Thesauri<Integer> earlene() {
        return null;
    }

    static {
        Thesauri<Integer> earlene = earlene();
        sainthood = earlene;
        Double overthink = earlene.overthink(earlene.yelped);
        paltriest = overthink;
        yerevan = overthink;
        Character jules = new Secondly(null).jules(sainthood.yelped);
        prenups = jules;
        refs = jules;
        tapped = 'B';
    }

    public static final Double wolf(Double d) {
        return Double.valueOf(-80.118d);
    }

    public static final void main(String[] strArr) {
        new Secondly(null);
    }
}
