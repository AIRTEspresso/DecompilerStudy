package src.hyaena;

import java.lang.Integer;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
public class Womanhood<H, R extends Integer, B extends R> extends Impanel {
    public Impanel toasty;

    public Womanhood(Impanel impanel) {
        super(new Impanel(null));
        this.toasty = impanel;
    }

    public final H jules(R r) {
        return null;
    }
}
