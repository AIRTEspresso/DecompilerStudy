package src.hyaena;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/6/original-6/Test.dex */
class Impanel implements Scoops {
    public Impanel toasty;

    public Impanel(Impanel impanel) {
        this.toasty = impanel;
    }

    public void televised(short s) {
        Byte.valueOf((byte) 55);
    }

    @Override // src.hyaena.Scoops
    public <F_V> F_V jimmie(F_V f_v) {
        return null;
    }
}
