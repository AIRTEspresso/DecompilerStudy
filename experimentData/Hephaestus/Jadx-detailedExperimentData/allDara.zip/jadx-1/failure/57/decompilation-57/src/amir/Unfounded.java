package src.amir;

import java.lang.Long;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
final class Unfounded<P, Y extends Long, L> extends Ribbed {
    public Ribbed abducts;
    public final Monickers<Long, Float> hailed;

    public Unfounded(Monickers<Long, Float> monickers, Ribbed ribbed) {
        super((byte) -76);
        this.hailed = monickers;
        this.abducts = ribbed;
    }

    public final Y usurers() {
        return null;
    }
}
