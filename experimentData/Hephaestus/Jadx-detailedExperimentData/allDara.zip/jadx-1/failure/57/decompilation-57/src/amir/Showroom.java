package src.amir;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
class Showroom extends Attends {
    public final Double lam;
    public Boolean rubbished;

    public Showroom(Boolean bool, Double d) {
        super(Double.valueOf(-36.546d), -75.551d);
        this.rubbished = bool;
        this.lam = d;
    }

    public final <F_K> int egyptian(F_K f_k, F_K f_k2) {
        return -37;
    }

    public String execs() {
        return "duteous";
    }
}
