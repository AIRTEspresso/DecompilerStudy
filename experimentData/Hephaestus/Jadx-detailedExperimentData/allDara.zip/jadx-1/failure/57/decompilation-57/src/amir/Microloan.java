package src.amir;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
abstract class Microloan extends Ribbed {
    public Character curricula;
    public final Fan mischief;

    public abstract Double winnie();

    public Microloan(Fan fan, Character ch) {
        super((byte) -22);
        this.mischief = fan;
        this.curricula = ch;
    }

    public Proffers cronus(Microloan microloan) {
        return microloan.cronus(null);
    }
}
