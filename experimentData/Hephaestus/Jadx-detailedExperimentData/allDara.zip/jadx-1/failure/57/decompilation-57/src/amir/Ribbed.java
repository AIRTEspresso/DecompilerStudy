package src.amir;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
public class Ribbed implements Proffers {
    public final byte timely;

    public Ribbed(byte b) {
        this.timely = b;
    }

    public final void lyra(Object obj) {
    }

    @Override // src.amir.Proffers
    public Integer maserati() {
        return -1;
    }
}
