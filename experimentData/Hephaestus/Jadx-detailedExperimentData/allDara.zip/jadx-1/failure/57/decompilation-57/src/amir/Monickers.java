package src.amir;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
public class Monickers<M, K> implements Proffers {
    public final Float[] smarting;

    public Monickers(Float[] fArr) {
        this.smarting = fArr;
    }

    public double spirea(double d) {
        return 39.314d;
    }

    @Override // src.amir.Proffers
    public Integer maserati() {
        Integer maserati = maserati();
        Ribbed ribbed = new Ribbed((byte) 83);
        Boolean bool = false;
        bool.booleanValue();
        ribbed.lyra(bool);
        return maserati;
    }
}
