package src.amir;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
abstract class Attends extends Ribbed {
    public final double hen;
    public final Double lam;

    public Attends(Double d, double d2) {
        super((byte) 64);
        this.lam = d;
        this.hen = d2;
    }

    @Override // src.amir.Ribbed, src.amir.Proffers
    public final Integer maserati() {
        return Main.beyond.maserati();
    }
}
