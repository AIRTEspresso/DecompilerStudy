package src.amir;

import java.lang.Number;
/* compiled from: Main.java */
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
abstract class Neonatal<R extends Number, J, X> implements Proffers {
    public R cigarets;
    public final Showroom roomy;

    public Neonatal(Showroom showroom, R r) {
        this.roomy = showroom;
        this.cigarets = r;
    }

    @Override // src.amir.Proffers
    public Integer maserati() {
        return -52;
    }
}
