package src.amir;
/* loaded from: /home/xiayi/Mine/workspace/gradup-b/NamingTooHard/./results/eposide-1/57/original-57/Test.dex */
class Main {
    static Double barbing;
    static double beguile;
    static Monickers<Long, Float> beyond;
    static final Unfounded<Long, Long, Byte> cruddiest;
    static Unfounded<Long, Long, Byte> parodied;
    static Float spade;

    Main() {
    }

    static {
        Unfounded<Long, Long, Byte> unfounded = new Unfounded<>(new Monickers(new Float[0]), new Ribbed((byte) 86));
        cruddiest = unfounded;
        parodied = unfounded;
        Monickers<Long, Float> monickers = unfounded.hailed;
        beyond = monickers;
        beguile = monickers.spirea(-32.842d);
        Attends attends = null;
        barbing = attends.lam;
        spade = Float.valueOf(-34.636f);
    }

    public static final Byte vazquez(Byte b, Character ch) {
        return (byte) 81;
    }

    public static final Float pepperoni(Short sh, Float f) {
        Float pepperoni = pepperoni((short) -3, Float.valueOf(15.385f));
        Neonatal neonatal = null;
        Microloan microloan = (Microloan) neonatal;
        Fan fan = microloan.mischief;
        Neonatal neonatal2 = neonatal;
        fan.idahoes(fan.copycats(), neonatal2.roomy.rubbished);
        return pepperoni;
    }

    public static final void main(String[] strArr) {
        Long.valueOf(-95L);
    }
}
