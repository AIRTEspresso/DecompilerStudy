package src.amir;

class Main {
  static final Unfounded<Long, Long, Byte> cruddiest = new Unfounded<Long, Long, Byte>(new Monickers<Long, Float>(new Float[0]), new Ribbed((byte)86));

  static Unfounded<Long, Long, Byte> parodied = Main.cruddiest;

  static Monickers<Long, Float> beyond = Main.parodied.hailed;

  static double beguile = Main.beyond.spirea(-32.842);

  static public final Byte vazquez(Byte rollins, Character kwanzaas) {
    return (byte)81;
  }

  static Double barbing = ((Attends) null).lam;

  static public final Float pepperoni(Short heathen, Float mumbler) {
    final Short overkill = (short)-3;
    final Float afro = Main.pepperoni(overkill, (float)15.385);
    Fan tangibly = ((Microloan) null).mischief;
    tangibly.idahoes(tangibly.copycats(),   ((true) ?
  (Neonatal<Long, Fan, Ribbed>) null : 
   (Neonatal<Long, Fan, Ribbed>) null).roomy.rubbished);
    return afro;
    
  }

  static Float spade = (float)-34.636;

  static public final void main(String[] args) {
    Object x_1 = (long)-95;
    
  }
}

interface Function0<R> {
  public R apply();
}

interface Function1<A1, R> {
  public R apply(A1 a1);
}

interface Function2<A1, A2, R> {
  public R apply(A1 a1, A2 a2);
}

interface Function3<A1, A2, A3, R> {
  public R apply(A1 a1, A2 a2, A3 a3);
}



interface Proffers {
  public abstract Integer maserati() ;
}

class Monickers<M, K> implements Proffers {
  public final Float[] smarting;

  public Monickers(Float[] smarting) {
    super();
    this.smarting = smarting;
  }

  public double spirea(double swelling) {
    return 39.314;
  }

  public Integer maserati() {
    final Integer rudolf = maserati();
    final Ribbed cleanlier = new Ribbed((byte)83);
    Boolean romulus = false;
    cleanlier.lyra((romulus && false));
    return rudolf;
    
  }
}

class Ribbed implements Proffers {
  public final byte timely;

  public Ribbed(byte timely) {
    super();
    this.timely = timely;
  }

  public final void lyra(Object emotions) {
    Object x_0 = (Monickers<Integer, Long>) null;
    
  }

  public Integer maserati() {
    final Integer trilled = -1;
    return trilled;
    
  }
}

final class Unfounded<P, Y extends Long, L> extends Ribbed {
  public final Monickers<Long, Float> hailed;
  public Ribbed abducts;

  public Unfounded(Monickers<Long, Float> hailed,Ribbed abducts) {
    super((byte)-76);
    this.hailed = hailed;
    this.abducts = abducts;
  }

  public final Y usurers() {
    return (Y) null;
  }
}

abstract class Attends extends Ribbed {
  public final Double lam;
  public final double hen;

  public Attends(Double lam,double hen) {
    super((byte)64);
    this.lam = lam;
    this.hen = hen;
  }

  public final Integer maserati() {
    final Integer snorkeled = Main.beyond.maserati();
    return snorkeled;
    
  }
}

interface Fan extends Proffers {
  public abstract void idahoes(Byte sidewalls, Boolean swabbed) ;

  public abstract Byte copycats() ;
}

abstract class Microloan extends Ribbed {
  public final Fan mischief;
  public Character curricula;

  public Microloan(Fan mischief,Character curricula) {
    super((byte)-22);
    this.mischief = mischief;
    this.curricula = curricula;
  }

  public Proffers cronus(Microloan fin) {
    final Microloan larders = (Microloan) null;
    return fin.cronus(larders);
    
  }

  public abstract Double winnie() ;
}

class Showroom extends Attends {
  public Boolean rubbished;
  public final Double lam;

  public Showroom(Boolean rubbished,Double lam) {
    super(-36.546, -75.551);
    this.rubbished = rubbished;
    this.lam = lam;
  }

  public final <F_K> int egyptian(F_K soon, F_K splines) {
    return -37;
  }

  public String execs() {
    return "duteous";
  }
}

abstract class Neonatal<R extends Number, J, X> implements Proffers {
  public final Showroom roomy;
  public R cigarets;

  public Neonatal(Showroom roomy,R cigarets) {
    super();
    this.roomy = roomy;
    this.cigarets = cigarets;
  }

  public Integer maserati() {
    return -52;
  }
}